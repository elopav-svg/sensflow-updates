"""
server.py — точка входу. Легкий HTTP-сервер на стандартній бібліотеці.

Запуск:  python server.py
Відкрити: http://127.0.0.1:7799

Жодних зовнішніх залежностей для самого сервера. Потрібен лише API-ключ LLM
у orchestrator_py/.env.local (OPENAI_API_KEY або ANTHROPIC_API_KEY).
"""

import json
import sys
import os
import time
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# Дозволяємо плоскі імпорти (import config, import llm, ...)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
import models_live   # ⭐ 11.08.2026: перелiк моделей для екрана — вiд провайдера
import registry
import store
import engine
import scheduler
import artifacts
import filetext
import discovery
import capabilities
import threads
import projects
import llm
import tools


def _json_bytes(payload) -> bytes:
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")


def _persist_turn(tid, user_message, incoming_fc, reply, result_obj=None) -> bool:
    """ОДИН ПИСАР ХОДУ В ТРЕД (30.07.2026).

    НАВІЩО. Запис ходу жив ЛИШЕ на успішній гілці обох дверей чату: якщо рушій
    падав винятком, користувач бачив текст аварії, але в треді не лишалось НІ
    його питання, НІ відповіді. Після перезапуску діалогу просто не існувало —
    людина не могла ні повторити, ні показати, що саме питала.

    ⛔ ХІД, ЗАПИСАНИЙ ЛИШЕ НА УСПІШНІЙ ГІЛЦІ, ЗНИКАЄ САМЕ ТОДІ, КОЛИ ПОТРІБЕН.

    Тому писар ОДИН і викликається на ОБОХ гілках (успіх і виняток) обох дверей
    (`/api/chat` і `/api/chat/stream`). Сам він мовчазним бути не має права:
    якщо не зміг записати — каже про це в журнал, а не «пас».
    """
    if not tid:
        return False
    try:
        threads.append(tid, "user", user_message or "(прикріплені файли)",
                       files_context=incoming_fc or None)
        _r = result_obj or {}
        threads.append(tid, "assistant", reply or "",
                       extra=({"result": {
                           "final_markdown": _r.get("final_markdown", ""),
                           "artifacts": _r.get("artifacts", []),
                           "sources": _r.get("sources", []),
                           "verification": _r.get("verification"),
                           "brain_trace": [x for x in (_r.get("brain_trace") or [])
                                           if x.get("type") == "tool"],
                       }} if _r else None))
        return True
    except Exception as e:
        try:
            llm._log("[server] ХІД НЕ ЗАПИСАНО В ТРЕД %s: %s" % (tid, e))
        except Exception:
            pass
        return False


# ── RBAC-lite: роль із ліцензії (operator = обмежені права) ──────────────────
# Адмінські дії (налаштування, керування системами/ключами/Telegram) недоступні
# в режимі оператора. Запуск задач, читання й свої чати — доступні.
_ADMIN_POST_PATHS = {"/api/automations/toggle", "/api/automations/schedule",
                     "/api/automations/run_now", "/api/automations/delete",
                     "/api/discover", "/api/llm/config",
                     "/api/system/status",
                     "/api/setup", "/api/setup/local", "/api/llm/stealth",
                     "/api/license", "/api/license/generate",
                     "/api/telegram/token", "/api/telegram/tasks_token",
                     "/api/telegram/support_mode", "/api/support/log",
                     "/api/update/apply", "/api/llm/demo",
                     "/api/crm/note", "/api/crm/history",
                     "/api/crm/profile", "/api/crm/contact", "/api/crm/contact_remove",
                     "/api/crm/systems",
                     "/api/crm/comm", "/api/crm/dossier",
                     "/api/crm/inbound", "/api/crm/inbox_clear",
                     # ⭐⭐⭐ C1 (15.08.2026): ПРОДАЖ ПЕРЕЇХАВ В УГОДУ. Двері
                     # `/stage`, `/attention`, `/next_action`, `/deal`,
                     # `/action_done`, `/archive`, `/unarchive` ПРИБРАНІ разом
                     # із полями картки — двері до неіснуючого поля гірші за їх
                     # відсутність. Нижче — двері самої угоди.
                     "/api/crm/deal_new", "/api/crm/deal_name", "/api/crm/deal_stage",
                     "/api/crm/deal_amount", "/api/crm/deal_next_action",
                     "/api/crm/deal_action_done", "/api/crm/deal_attention",
                     "/api/crm/deal_archive", "/api/crm/deal_delete",
                     "/api/crm/deal_client", "/api/crm/deal_person",
                     "/api/crm/deal_person_remove", "/api/crm/deal_note",
                     "/api/crm/deal_mail", "/api/crm/deal_mail_sent",
                     "/api/crm/spread_assign", "/api/crm/spread_drop",
                     "/api/crm/promote", "/api/crm/party",
                     # ⭐ 13.08.2026: розділ «Клієнти» був вітриною без дверей —
                     # картку не відкрити, контрагента не завести й не прибрати.
                     "/api/crm/party_new", "/api/crm/party_delete",
                     # ⭐ D1 (15.08.2026): хто веде клієнта. НОВИЙ ВХІД ІДЕ
                     # СТАРИМИ ВОРОТАМИ — той самий адмінський перелік, що
                     # й решта CRM. Забути тут = зробити двері повз охорону.
                     "/api/crm/party_manager",
                     # ⭐⭐⭐ D3 (16.08.2026): ГРУПОВІ ДІЇ над клієнтською базою.
                     # НОВИЙ ВХІД ІДЕ СТАРИМИ ВОРОТАМИ — той самий адмінський
                     # перелік, що й решта CRM. Забути тут = зробити двері повз
                     # охорону, причому двері, за якими міняються СОТНІ карток.
                     "/api/crm/bulk_preview", "/api/crm/bulk_apply",
                     # ⭐ C3 (15.08.2026): закріплення події у стрічці. НОВИЙ ВХІД
                     # ІДЕ СТАРИМИ ВОРОТАМИ — той самий адмінський перелік, що й
                     # решта CRM. Забути тут = зробити двері повз охорону.
                     "/api/crm/pin",
                     "/api/crm/inbox_attach"}
_ADMIN_GET_PATHS = {"/setup", "/setup.html", "/telegram", "/telegram.html",
                    "/genkey", "/genkey.html", "/api/telegram/users", "/api/license/admin",
                    "/api/support",
                    # ⭐ 17.08.2026: безкоштовна діагностика тендера. НОВИЙ ВХІД ІДЕ
                    # СТАРИМИ ВОРОТАМИ — той самий адмінський перелік. Двері лише
                    # читають, але показують внутрішню кухню розбору, і стороннім
                    # у ній робити нічого.
                    "/api/tender/diagnose",
                    "/api/crm/list", "/api/crm/card", "/api/crm/board", "/api/crm/channels",
                    "/api/crm/products",
                    "/api/crm/pipeline", "/api/crm/inbox", "/api/crm/parties",
                    # ⭐ B3: розділ «Історія взаємовідносин» у картці контакту.
                    # НОВИЙ ВХІД ІДЕ СТАРИМИ ВОРОТАМИ — той самий адмінський
                    # перелік, що й решта CRM. Адреса нічого не відмикає.
                    "/api/crm/party_card",
                    # ⭐ C1: перелік угод, картка угоди і ЗАГАЛЬНИЙ читач картки
                    # будь-якої сутності (той самий `relations.card`).
                    "/api/crm/deals", "/api/crm/deal_card", "/api/crm/entity_card",
                    # ⭐ D2 (16.08.2026): пошук по клієнтській базі. НОВИЙ ВХІД
                    # ІДЕ СТАРИМИ ВОРОТАМИ — той самий адмінський перелік, що й
                    # решта CRM. Забути тут = зробити двері повз охорону.
                    "/api/crm/party_search",
                    "/api/crm/spread"}


def _is_admin_request() -> bool:
    """True, якщо поточне посвідчення має адмінські права. Fail-open: за будь-якої
    помилки перевірки — НЕ блокуємо (щоб не зламати роботу)."""
    try:
        import license as _lic
        return _lic.is_admin()
    except Exception:
        return True


def _me_for_screen(session_actor):
    """ОДНА відповідь «хто я» для екранів — через того самого `resolve_actor()`,
    що вирішує, хто діє. Друга відповідь у другому місці розійшлася б із першою."""
    import taskdesk_identity as _tdid
    try:
        acc = _tdid.resolve_actor(session_actor)
    except Exception:
        acc = None
    if not acc or not acc.get("employee_id"):
        return None
    return {"employee_id": acc.get("employee_id"),
            "name": acc.get("employee_name") or "",
            "is_admin": bool(acc.get("is_admin"))}


def _oauth_page(title: str, message: str, ok: bool) -> bytes:
    """Сторінка, яку бачить людина після згоди сервісу.

    ⛒ Ця вкладка відкрита ОКРЕМО від консолі, тож вона мусить сама сказати, що
    сталося і куди йти далі: «повідомлення без жодної дії — глухий кут».
    """
    import html as _html
    return ("""<!doctype html><html lang="uk"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%s</title><style>
 body{margin:0;background:#0f1216;color:#e8edf3;font:16px/1.6 system-ui,Segoe UI,Roboto,sans-serif;
      display:flex;align-items:center;justify-content:center;min-height:100vh}
 .card{max-width:560px;padding:32px 36px;background:#171c23;border:1px solid #2a323d;border-radius:16px}
 h1{margin:0 0 12px;font-size:22px;color:%s}
 p{margin:0 0 20px;color:#c2cbd6}
 a{display:inline-block;padding:10px 18px;border-radius:10px;background:#3b82f6;
   color:#fff;text-decoration:none;font-weight:600}
</style></head><body><div class="card">
<h1>%s</h1><p>%s</p><a href="/">Повернутися в платформу</a>
</div></body></html>""" % (_html.escape(title), ("#5eead4" if ok else "#fca5a5"),
                           _html.escape(title), _html.escape(message))
            ).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    server_version = "AIOrchestratorPy/1.0"

    # ---- утиліти ----------------------------------------------------------
    def _send(self, status, payload, content_type="application/json; charset=utf-8",
              headers=None):
        body = payload if isinstance(payload, (bytes, bytearray)) else _json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    # ⭐⭐⭐ ВОРОТА 1 «ХТО ЦЕ» (крок 1.3 Task Desk, 06.08.2026).
    # Стоять В ОДНОМУ місці на всі ~60 обробників: інакше кожен новий обробник
    # мусив би памʼятати про перевірку — а той, хто забуде, і стане дірою.
    # Поки в компанії один обліковий запис (як у Каспера), ворота пропускають
    # усе, як і раніше: живу роботу клієнта вони не чіпають.
    def _taskdesk_gate(self):
        import taskdesk_identity as _tdid
        ok, who, why = _tdid.web_gate(self.path.split("?", 1)[0],
                                      self.headers.get("Cookie") or "")
        self.actor = who
        return ok, why

    # ⭐ ХТО ДІЄ В ЦЬОМУ ЗАПИТІ (крок 1.5). Консоль не вирішує сама: питає
    # єдиного відповідача. `self.actor` сюди кладуть ворота `_taskdesk_gate`.
    def _actor(self):
        import taskdesk_identity as _tdid
        return _tdid.resolve_actor(getattr(self, "actor", None))

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        if not length:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def log_message(self, fmt, *args):  # тихіший лог
        sys.stderr.write("[srv] " + (fmt % args) + "\n")

    # ---- GET --------------------------------------------------------------
    def do_GET(self):
        path = self.path.split("?", 1)[0]

        _ok, _why = self._taskdesk_gate()
        if not _ok:
            return self._send(401, {"error": "login_required", "message": _why})

        if path == "/api/taskdesk/whoami":
            import taskdesk_identity as _tdid
            who = getattr(self, "actor", None)
            import taskdesk_api as _tdapi0
            return self._send(200, {"enabled": _tdapi0.enabled(),
                                    "login_required": _tdid.login_required(),
                                    "light_mode": _tdid.light_mode(),
                                    "actor": ({"id": who["id"], "login": who["login"],
                                               "name": who["employee_name"],
                                               "is_admin": who["is_admin"],
                                               "layers": who["layers"],
                                               "orchestrator": who["orchestrator"]}
                                              if who else None),
                                    # ⭐ «Хто я» для екрана — це РОЗВʼЯЗАНИЙ актор
                                    # (`resolve_actor`), а не лише жива сесія: в
                                    # одноосібного клієнта сесії немає, а людина є.
                                    # Без цього кнопці «Моя картка» нема куди вести.
                                    "me": _me_for_screen(who)})

        # ── ПАЛІТРА Й ПЕРЕМИКАЧ ТЕМИ (зміна 184, 15.08.2026).
        # Один файл кольорів на весь продукт і один перемикач: доти кольори
        # жили в пʼятьох сторінках окремо, і світла тема означала б пʼять
        # правок замість однієї. Віддається ДО будь-якої перевірки прав —
        # сторінка входу мусить бути пофарбована ще до того, як стало
        # відомо, хто прийшов.
        if path in ("/theme.css", "/theme.js"):
            page = config.UI_DIR / path.lstrip("/")
            if not page.exists():
                return self._send(404, {"error": "not_found"})
            kind = ("text/css" if path.endswith(".css")
                    else "application/javascript")
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="%s; charset=utf-8" % kind)

        # ── Екрани Task Desk (крок 1.4). Поки робота вимкнена — їх немає зовсім:
        # вимкнена річ не мусить світитись у клієнта навіть сторінкою.
        if path in ("/taskdesk.css", "/taskdesk.js"):
            page = config.UI_DIR / path.lstrip("/")
            if not page.exists():
                return self._send(404, {"error": "not_found"})
            kind = ("text/css" if path.endswith(".css") else "application/javascript")
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="%s; charset=utf-8" % kind)

        if path in ("/login", "/people", "/access", "/employee", "/tasks", "/task"):
            import taskdesk_api as _tdapi
            if not _tdapi.enabled():
                return self._send(404, {"error": "not_found"})
            names = {"/login": "taskdesk_login.html", "/people": "taskdesk_people.html",
                     "/access": "taskdesk_access.html",
                     "/employee": "taskdesk_employee.html",
                     "/tasks": "taskdesk_tasks.html", "/task": "taskdesk_task.html"}
            page = config.UI_DIR / names[path]
            if not page.exists():
                return self._send(500, {"error": "taskdesk_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        if path in ("/api/taskdesk/people", "/api/taskdesk/accounts",
                    "/api/taskdesk/employee_card"):
            import taskdesk_api as _tdapi
            who = getattr(self, "actor", None)
            try:
                if path == "/api/taskdesk/people":
                    return self._send(200, _tdapi.people_state(who))
                if path == "/api/taskdesk/accounts":
                    return self._send(200, _tdapi.accounts_state(who))
                from urllib.parse import urlparse as _up, parse_qs as _pq
                q = _pq(_up(self.path).query)
                return self._send(200, _tdapi.employee_card(who, (q.get("id") or [""])[0]))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path in ("/api/taskdesk/board", "/api/taskdesk/task"):
            import taskdesk_api as _tdapi
            from urllib.parse import urlparse as _upb, parse_qs as _pqb
            q = _pqb(_upb(self.path).query)
            # ⭐ «Хто діє» питаємо ЄДИНОГО відповідача (крок 1.5), а не сирий
            # actor сесії: інакше єдиний власник без входу перестає бути людиною.
            who = self._actor()
            try:
                if path == "/api/taskdesk/board":
                    return self._send(200, _tdapi.board_state(
                        who, (q.get("scope") or ["all"])[0],
                        (q.get("closed") or [""])[0] == "1",
                        None, (q.get("q") or [""])[0],
                        (q.get("fresh") or [""])[0] == "1"))
                return self._send(200, _tdapi.task_state(who, (q.get("id") or [""])[0]))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/photo":
            import taskdesk_api as _tdapi
            from urllib.parse import urlparse as _up2, parse_qs as _pq2
            q = _pq2(_up2(self.path).query)
            try:
                raw, mime = _tdapi.photo_get(getattr(self, "actor", None),
                                             (q.get("id") or [""])[0])
                return self._send(200, raw, content_type=mime)
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/light_list":
            # Легкий режим: список людей для вибору себе без пароля. Поза легким
            # режимом список нікому не показується — це не довідник для чужих.
            import taskdesk_identity as _tdid
            if not _tdid.light_mode():
                return self._send(403, {"error": "light_mode_off",
                                        "message": "Вхід без пароля вимкнений."})
            return self._send(200, {"accounts": [
                {"id": a["id"], "name": a["employee_name"], "login": a["login"]}
                for a in _tdid.accounts() if a["can_login"]]})

        # Сервіс-центр (CRM) — ЛИШЕ у збірці адміністратора (LICENSE_ADMIN=1).
        # У клієнтських/тріальних збірках LICENSE_ADMIN відсутній → повна відмова.
        if path.startswith("/api/crm") and not config.LICENSE_ADMIN:
            return self._send(403, {"error": "admin_only",
                                     "message": "Сервіс-центр доступний лише у збірці адміністратора."})

        if path in _ADMIN_GET_PATHS and not _is_admin_request():
            return self._send(403, {"error": "operator_forbidden",
                                     "message": "Сторінка доступна лише адміністратору (режим оператора)."})

        if path == "/" or path == "/index.html":
            return self._serve_ui()

        if path == "/setup" or path == "/setup.html":
            page = config.UI_DIR / "setup.html"
            if not page.exists():
                return self._send(500, {"error": "setup_ui_missing"})
            return self._send(200, self._localized_html(page),
                              content_type="text/html; charset=utf-8")

        if path == "/telegram" or path == "/telegram.html":
            page = config.UI_DIR / "telegram.html"
            if not page.exists():
                return self._send(500, {"error": "telegram_ui_missing"})
            return self._send(200, self._localized_html(page),
                              content_type="text/html; charset=utf-8")

        if path == "/genkey" or path == "/genkey.html":
            page = config.UI_DIR / "genkey.html"
            if not page.exists():
                return self._send(500, {"error": "genkey_ui_missing"})
            body = page.read_text(encoding="utf-8").encode("utf-8")
            return self._send(200, body, content_type="text/html; charset=utf-8")

        if path == "/i18n.js":
            page = config.UI_DIR / "i18n.js"
            if not page.exists():
                return self._send(500, {"error": "i18n_missing"})
            body = page.read_text(encoding="utf-8").encode("utf-8")
            return self._send(200, body,
                              content_type="application/javascript; charset=utf-8")

        if path == "/api/telegram/users":
            import telegram_access, telegram_bot
            import config as _cfg
            snap = telegram_access.snapshot()
            snap["bot"] = telegram_bot.status()
            snap["support_mode"] = _cfg.TELEGRAM_SUPPORT_MODE
            return self._send(200, snap)

        if path == "/api/update/check":
            import update as _upd
            return self._send(200, _upd.check_for_update())

        if path == "/api/health":
            try:
                import license as _lic
                _role = _lic.role()
            except Exception:
                _role = "admin"
            try:
                import costs as _costs
                _sess = _costs.session()
            except Exception:
                _sess = {}
            return self._send(200, {
                "ok": True,
                "orchestrator": "python_global_orchestrator",
                "brain": config.provider_status(),
                "artifacts": artifacts.capabilities(),
                "role": _role,
                "is_admin": _role != "operator",
                "costs": {"session_usd": round(_sess.get("usd", 0.0), 4),
                          "session_calls": _sess.get("calls", 0)},
            })

        if path == "/api/support":
            import support
            return self._send(200, support.summary())

        # ── Кнопка «Допомога з технічних питань» ─────────────────────────────
        # Доступна КЛІЄНТУ (не адмінська): це його спосіб покликати підтримку.
        # Сервер нічого не надсилає — лише показує, що піде у файл.
        if path == "/api/support_report/preview":
            import support_report
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            opts = {"task_texts": (q.get("task_texts", ["0"])[0] == "1")}
            rep = support_report.build(opts)
            rep["folder"] = str(support_report.reports_dir())
            return self._send(200, rep)

        if path == "/api/automations":
            return self._send(200, {"automations": scheduler.list_automations()})

        if path == "/api/llm/config":
            st = config.provider_status()
            # ⭐ 11.08.2026: перелiк для екрана дає ОДИН писар — той, що
            # питає провайдера. Зашитий рядок лишився тiльки запасним.
            st["suggestions"] = models_live.suggestions()
            st["model_ranks"] = models_live.ranks_for(st["suggestions"])
            st["demo"] = (config.ENV.get("DEMO_MODE") == "1")
            return self._send(200, st)

        if path == "/api/capabilities":
            return self._send(200, capabilities.self_model())

        if path == "/api/styles":
            import styles
            return self._send(200, {"styles": styles.list_styles()})

        if path == "/api/threads":
            return self._send(200, {"threads": threads.list_threads()})

        if path.startswith("/api/threads/"):
            tid = path.split("/api/threads/", 1)[1]
            rec = threads.get(tid)
            if not rec:
                return self._send(404, {"error": "thread_not_found"})
            return self._send(200, rec)

        if path == "/api/projects":
            return self._send(200, {"projects": projects.list_projects()})

        if path.startswith("/api/projects/"):
            rest = path.split("/api/projects/", 1)[1]
            if rest.endswith("/documents"):
                pid = rest[:-len("/documents")]
                return self._send(200, {"documents": projects.documents(pid)})
            rec = projects.get(rest)
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/registry":
            return self._send(200, {"systems": registry.load_systems()})

        if path == "/api/connectors":
            return self._send(200, {"connectors": registry.connector_inventory()})

        # ⭐⭐⭐ ДВЕРІ ДО ЧУЖОГО СЕРВІСУ (12.08.2026, зміна 163).
        # Два кроки одного шляху: людина натискає «Підключити» → ми ведемо її
        # на екран згоди сервісу → сервіс повертає її сюди з разовим кодом →
        # ми міняємо код на ключ і кладемо його туди, куди дивляться ворота.
        # ⛒ Ендпоінти ЗАГАЛЬНІ (по `<id>`): новий конектор = новий рядок у
        # `connector_oauth.DOORS`, і цього файла чіпати не треба.
        if path.startswith("/api/connectors/") and path.endswith("/auth/start"):
            cid = path[len("/api/connectors/"):-len("/auth/start")]
            import connector_oauth
            # ⛒ Платний рівень: вимкненої речі не існує навіть як сторінки.
            if not connector_oauth.enabled():
                return self._send(404, {"error": "not_found"})
            url, err = connector_oauth.start(cid)
            if err:
                return self._send(200, _oauth_page("Підключення не почалось", err, False),
                                  content_type="text/html; charset=utf-8")
            return self._send(302, b"", content_type="text/html; charset=utf-8",
                              headers={"Location": url})

        if path.startswith("/api/connectors/") and path.endswith("/oauth/callback"):
            cid = path[len("/api/connectors/"):-len("/oauth/callback")]
            import connector_oauth
            if not connector_oauth.enabled():
                return self._send(404, {"error": "not_found"})
            from urllib.parse import urlparse as _up, parse_qs as _pq
            q = _pq(_up(self.path).query)
            ok, err = connector_oauth.finish(
                cid,
                (q.get("code", [""])[0] or ""),
                (q.get("state", [""])[0] or ""),
                (q.get("error", [""])[0] or ""))
            if not ok:
                return self._send(200, _oauth_page("Не підключено", err, False),
                                  content_type="text/html; charset=utf-8")
            caveat = connector_oauth.caveat(cid)
            return self._send(200, _oauth_page(
                "Підключено",
                ("Доступ надано. Поверніться в платформу — картка конектора вже "
                 "показує «підключено». " + caveat).strip(), True),
                content_type="text/html; charset=utf-8")

        if path == "/api/runs":
            return self._send(200, {"runs": store.list_runs()})

        if path == "/api/egress/log":
            # Журнал виходів назовні (режим максимального збереження) — доказ, що
            # жоден вихід не стався без явного дозволу. Найновіші — в кінці.
            import egress_guard
            return self._send(200, {"log": egress_guard.tail(100),
                                    "stealth": egress_guard.stealth_on()})

        if path == "/api/version":
            import update
            return self._send(200, {"version": update.current_version()})

        if path == "/api/license":
            import license as licensing
            st = licensing.status()
            st["entitlement"] = licensing.entitlement()
            return self._send(200, st)

        if path == "/api/license/admin":
            return self._send(200, {"admin": config.LICENSE_ADMIN})

        # ═══════ ДІАГНОСТИКА ТЕНДЕРА БЕЗ ГРОШЕЙ (17.08.2026, зміна 194) ═══════
        # 🩸🩸🩸 СЛОВО АНДРІЯ 17.08: «прогін ми робимо ТІЛЬКИ тоді, коли всі засоби
        # використані». Я двічі за день платив за живий прогін лише для того, щоб
        # подивитись, ЩО платформа прочитала з документації і ЯКИЙ перелік із
        # цього вийшов. Обидві відповіді дає КОД, а не модель, — але дістатись до
        # них можна було лише через платний конвеєр із чотирма агентами.
        # ⛒ ЦІ ДВЕРІ — ТОЙ САМИЙ КОД БЕЗ ЖОДНОГО ВИКЛИКУ МОДЕЛІ. Вони читають
        # документацію з Прозорро (безкоштовне джерело) і показують рівно те, що
        # побачить складач пакета: які файли прочитано, чого не прочитано, чи не
        # обрізано, який обсяг вимог видно, який перелік дає код і що з нього
        # прибрало правило «графа бланка — не документ». Ціна виклику — НУЛЬ.
        # ⚠ Двері адмінські й лише ЧИТАЮТЬ: свого стану не пишуть, нічого не
        # надсилають, у пакет не втручаються.
        if path == "/api/tender/diagnose":
            from urllib.parse import urlparse as _upd, parse_qs as _pqd
            tid = (_pqd(_upd(self.path).query).get("id") or [""])[0].strip()
            if not tid:
                return self._send(400, {"error": "потрібен номер: ?id=UA-…"})
            try:
                import filetext as _ft
                import tender_docs as _td
                import tender_pack as _tp
                res = _td.read_docs(tid, max_files=_td.MAX_FILES_DEFAULT)
                if not res.get("ok"):
                    return self._send(200, {"ok": False, "tender_id": tid,
                                            "reason": res.get("reason") or ""})
                files = res.get("files") or []
                material, cut_notes = _td.material_blocks(files)
                gaps = ["%s — %s" % (s.get("title") or "документ",
                                     s.get("why") or "причина невідома")
                        for s in (res.get("skipped") or [])] + list(cut_notes)
                items = _tp.extra_requirements_in(material)
                fields = [i for i in items if _tp.is_form_field(i)]
                state = _tp.tender_state(tid)
                return self._send(200, {
                    "ok": True, "tender_id": tid,
                    "stan": {"strok": state.get("deadline"),
                             "dniv_lyshylos": state.get("days_left"),
                             "vidmina": state.get("cancelled"),
                             "zakryta": state.get("closed"),
                             "chomu": state.get("why")},
                    "fayly": [{"nazva": f.get("title"), "znakiv": f.get("chars"),
                               "obrizano": _ft.was_capped(f.get("text") or "")}
                              for f in files],
                    "ne_prochytano": gaps,
                    "use_prochytano": bool(res.get("complete")) and not cut_notes,
                    "znakiv_materialu": len(material),
                    "obsyah_vymoh": _tp.requirements_volume(material),
                    "perelik_z_materialu": items,
                    "hrafy_blankiv": fields,
                    "ne_vyznani_vymohamy": [b.get("heading")
                                            for b in _tp.unclaimed_lists(material)][:12],
                })
            except Exception as e:
                return self._send(500, {"ok": False, "tender_id": tid,
                                        "error": "%s: %s" % (type(e).__name__, e)})

        if path == "/api/update/check":
            import update
            return self._send(200, update.check_for_update())

        if path == "/api/crm/list":
            import crm
            return self._send(200, {"active": crm.list_clients(False),
                                    "archived": crm.list_clients(True),
                                    "counts": crm.counts()})

        if path == "/api/crm/products":
            # ⭐ ЕТАП 4: що взагалі можна купити. Перелік — з ОДНОГО місця
            # (`make_client_build.PRODUCT_SYSTEMS`), назви — з реєстру.
            import make_client_build as _mcb
            import registry as _reg
            _names = {x.get("id"): (x.get("name") or x.get("id"))
                      for x in _reg.load_systems()}
            return self._send(200, {"systems": [
                {"id": _sid, "name": _names.get(_sid, _sid)}
                for _sid in sorted(_mcb.PRODUCT_SYSTEMS,
                                   key=lambda i: (_names.get(i, i) or "").lower())]})

        if path == "/api/crm/card":
            import crm
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            cust = (q.get("customer", [""])[0] or "").strip()
            card = crm.card_public(cust)
            if not card:
                return self._send(404, {"error": "client_not_found"})
            return self._send(200, card)

        if path == "/api/crm/board":
            import crm
            return self._send(200, crm.board())

        if path == "/api/crm/pipeline":
            import crm
            return self._send(200, crm.pipeline())

        if path == "/api/crm/inbox":
            import crm
            return self._send(200, {"inbox": crm.inbox()})

        if path in ("/api/crm/party_card", "/api/crm/entity_card"):
            # ⭐⭐⭐ ІСТОРІЯ ВЗАЄМОВІДНОСИН (крок B3, 14.08.2026). Дві частини —
            # «що існує» (реєстр звʼязків) і «що сталось» (протокол + спілкування) —
            # рахує ОДИН читач `relations`. Сервер їх не змішує і не складає
            # власних формулювань: другий писар правди розійшовся б із першим.
            import relations as _rel
            import entity as _ent
            from urllib.parse import urlparse as _up4, parse_qs as _pq4
            q4 = {k: v[0] for k, v in _pq4(_up4(self.path).query or "").items()}
            # ⭐ C1: та сама відповідь про БУДЬ-ЯКУ сутність. `relations.card`
            # від першого дня написаний про будь-який вид — другого читача
            # (окремо «картка угоди») ми не заводимо.
            raw_ref = (q4.get("ref") or "").strip()
            pid = (q4.get("id") or "").strip()
            if not raw_ref and not pid:
                return self._send(400, {"error": "no_party"})
            try:
                ref = _ent.norm(raw_ref) if raw_ref else _ent.ref(_ent.KIND_PARTY, pid)
                limit = int(q4.get("limit") or _rel.FEED_PAGE)
            except Exception as ex:
                return self._send(400, {"error": str(ex)})
            # ⭐ C3: фільтр і сторінка ЇДУТЬ У ЧИТАЧА, а не робляться на екрані.
            # Порахувати «показано N із M» у браузері означало б завести другого
            # писаря тієї самої арифметики — і телеграм показав би своє число.
            try:
                _card = _rel.card(
                    ref, limit,
                    offset=int(q4.get("offset") or 0),
                    source=(q4.get("source") or "").strip(),
                    kind=(q4.get("kind") or "").strip(),
                    about=(q4.get("about") or "").strip(),
                    since=(q4.get("since") or "").strip(),
                    until=(q4.get("until") or "").strip())
                # ⭐ C1: картка КОНТРАГЕНТА несе перелік його угод — і бере його
                # в того самого писаря, що й решта екранів. Інакше контакт без
                # картки-ліцензії показував би «угод немає», маючи їх.
                if _ent.kind_of(ref) == _ent.KIND_PARTY:
                    import deals as _dl2
                    _card["deals"] = _dl2.tiles_of_party(_ent.ident_of(ref))
                    # ⭐ D1: хто веде цього клієнта й з кого вибирати. Дані
                    # складає ПИСАР ДОВІДНИКА (`parties.manager_card`): екран не
                    # питає оргструктуру сам, інакше писарів «хто веде» стало б двоє.
                    import parties as _pt3
                    _card["manager"] = _pt3.manager_card(_ent.ident_of(ref))
                return self._send(200, _card)
            except Exception as ex:
                # Невідомий вид у фільтрі «про кого» — відмова СЛОВАМИ, а не 500.
                return self._send(400, {"error": str(ex)})

        if path == "/api/crm/spread":
            # ⭐ C2: черга «Рознести» — сестра черги «Не оброблені». Тут лежать
            # листи від ВІДОМИХ контактів, у яких немає адреси угоди. Кожен
            # рядок каже, ЧОМУ платформа не рознесла його сама.
            import deal_mail as _dm
            from urllib.parse import urlparse as _up6, parse_qs as _pq6
            q6 = {k: v[0] for k, v in _pq6(_up6(self.path).query or "").items()}
            rows = _dm.pending((q6.get("party") or "").strip())
            return self._send(200, {"items": rows, "count": len(rows)})

        if path == "/api/crm/deals":
            # ⭐ C1: воронка й плитка тепер про УГОДИ. Форма відповіді та сама,
            # що й у `board()`, — екран канбану не переписується.
            import deals as _dl
            return self._send(200, {"board": _dl.board(), "counts": _dl.count(),
                                    "stages": _dl.STAGES})

        if path == "/api/crm/deal_card":
            import deals as _dl
            from urllib.parse import urlparse as _up5, parse_qs as _pq5
            q5 = {k: v[0] for k, v in _pq5(_up5(self.path).query or "").items()}
            did = (q5.get("id") or "").strip()
            if not did:
                return self._send(400, {"error": "no_deal"})
            card = _dl.card(did)
            if card is None:
                return self._send(404, {"error": "Угоди %s немає в реєстрі." % did})
            return self._send(200, card)

        if path == "/api/crm/parties":
            # ⭐ КЛІЄНТСЬКА БАЗА (довідник контрагентів). Тип і роль — необовʼязкові
            # фільтри; картку угоди тут не показуємо — це різні сутності.
            import crm as _crm
            import parties as _pt
            from urllib.parse import urlparse as _up3, parse_qs as _pq3
            q = {k: v[0] for k, v in _pq3(_up3(self.path).query or "").items()}
            try:
                items = _pt.all_parties(role=q.get("role", ""), kind=q.get("kind", ""))
            except _pt.PartyError as ex:
                return self._send(400, {"error": str(ex)})
            for it in items:
                it["customer"] = _crm.card_of_party(it.get("id", ""))
            return self._send(200, {"parties": items, "counts": _pt.count(),
                                    "kinds": _pt.KIND_NAMES, "roles": _pt.ROLE_NAMES})

        if path == "/api/crm/party_search":
            # ⭐⭐⭐ D2 (16.08.2026): ЗНАЙТИ клієнта, коли їх три тисячі.
            # ⛒ Сервер нічого не шукає сам і нічого не фільтрує: і пошук, і
            # словник фільтрів, і сторінки — в ОДНОГО писаря `party_search`.
            # Другий пошук (у розмітці чи тут) розійшовся б із ним назавтра.
            import parties as _pt5
            import party_search as _ps
            from urllib.parse import urlparse as _up6, parse_qs as _pq6
            q6 = {k: v[0] for k, v in _pq6(_up6(self.path).query or "").items()}
            try:
                res = _ps.search(query=q6.get("q", ""),
                                 filter=q6.get("filter", ""),
                                 page=q6.get("page", ""),
                                 per=q6.get("per", ""),
                                 sort=q6.get("sort", ""),
                                 dir=q6.get("dir", ""),
                                 # ⭐ D3: стан (у роботі / архів) і фільтр
                                 # «клієнти менеджера X» — слова їдуть у того
                                 # самого писаря, а не розбираються тут.
                                 state=q6.get("state", ""),
                                 manager=q6.get("manager", ""))
            except _ps.SearchError as ex:
                return self._send(400, {"error": str(ex)})
            res["kinds"] = _pt5.KIND_NAMES
            res["roles"] = _pt5.ROLE_NAMES
            return self._send(200, res)

        if path == "/api/crm/channels":
            import config as _cfg
            return self._send(200, {
                "email": {"available": True, "mode": "mailto",
                          "hint": "Лист відкривається у вашій поштовій програмі; пряму відправку (SMTP) можна підключити пізніше."},
                "telegram": {"available": bool(getattr(_cfg, "TELEGRAM_BOT_TOKEN", "") or _cfg.ENV.get("TELEGRAM_BOT_TOKEN")),
                             "connect": "/telegram",
                             "hint": "Підключіть бота у розділі Telegram, щоб писати клієнту з картки."},
                "call": {"available": True, "mode": "log",
                         "hint": "Дзвоніть через месенджер/телефон, а тут фіксуйте результат у історію."},
            })

        if path.startswith("/artifacts/"):
            return self._serve_artifact(path)

        return self._send(404, {"error": "not_found", "path": path})

    # ---- POST -------------------------------------------------------------
    def do_POST(self):
        path = self.path.split("?", 1)[0]

        _ok, _why = self._taskdesk_gate()
        if not _ok:
            return self._send(401, {"error": "login_required", "message": _why})

        # ⭐ ДВЕРІ НАЗИВАЮТЬ СЕБЕ (зміна 171, 13.08.2026). «Хто натиснув і звідки»
        # відоме лише ТУТ, на вході; писарі протоколу цього не знають і знати не
        # мусять. Без цього рядка звіт протоколу чесно казав: «джерело не назвав
        # ЖОДЕН рядок — це прогалина». Крок роботи ВІДКРИВАЄ той, хто його починає
        # (той самий закон, що й `costs.start_run` у зміні 169).
        # ⚠ `clear()` перед `bind()`: сервер потоковий (потік на запит), але якби
        # потік колись перевикористали, контекст сусіднього запиту мовчки приписав
        # би роботу не тому клієнту.
        try:
            import protocol as _proto
            import entity as _ent
            _proto.clear()
            # 🩸 ХТО ДІЄ — ПИТАЄМО ЄДИНОГО ВІДПОВІДАЧА (`self._actor`), А НЕ ПОЛЕ.
            # Перший захід 171 читав сиру `self.actor` — сесію. Сесії в консолі
            # немає (Task Desk вимкнений), і журнал писав «діяч: (немає)», хоча
            # платформа чудово знає, що діє ВЛАСНИК. Поле зі схожою назвою — не
            # відповідь; відповідає `taskdesk_identity.resolve_actor`.
            _proto.bind(source=_proto.S_CONSOLE,
                        actor=_ent.person_of_actor(self._actor()))
        except Exception:
            pass

        if path == "/api/taskdesk/login":
            import taskdesk_identity as _tdid
            data = self._read_json()
            try:
                if data.get("account_id"):
                    token = _tdid.login_light(data.get("account_id"))
                else:
                    token = _tdid.login(data.get("login") or "", data.get("password") or "")
            except _tdid.IdentityError as e:
                return self._send(401, {"error": "login_failed", "message": str(e)})
            return self._send(200, {"ok": True},
                              headers={"Set-Cookie": _tdid.cookie_header(token)})

        if path == "/api/taskdesk/photo":
            import taskdesk_api as _tdapi
            data = self._read_json()
            try:
                return self._send(200, _tdapi.photo_set(getattr(self, "actor", None),
                                                        data.get("id") or "",
                                                        data.get("data") or ""))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/tasks/action":
            import taskdesk_api as _tdapi
            try:
                return self._send(200, _tdapi.run_task_action(
                    self._actor(), self._read_json()))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        # Вигляд списку, фільтр, збережені набори і вивантаження в Excel. Ворота
        # тут ті самі, що в задачах: веде сама людина, не адміністратор.
        if path == "/api/taskdesk/prefs/action":
            import taskdesk_api as _tdapi
            try:
                return self._send(200, _tdapi.run_prefs_action(
                    self._actor(), self._read_json()))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path in ("/api/taskdesk/people/action", "/api/taskdesk/access/action"):
            import taskdesk_api as _tdapi
            table = "people" if path.endswith("/people/action") else "access"
            try:
                return self._send(200, _tdapi.run_action(getattr(self, "actor", None),
                                                         table, self._read_json()))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/logout":
            import taskdesk_identity as _tdid
            _tdid.logout(_tdid.token_from_cookies(self.headers.get("Cookie") or ""))
            return self._send(200, {"ok": True},
                              headers={"Set-Cookie": _tdid.clear_cookie_header()})

        # Сервіс-центр (CRM) — ЛИШЕ у збірці адміністратора (LICENSE_ADMIN=1).
        if path.startswith("/api/crm") and not config.LICENSE_ADMIN:
            return self._send(403, {"error": "admin_only",
                                     "message": "Сервіс-центр доступний лише у збірці адміністратора."})

        if path in _ADMIN_POST_PATHS and not _is_admin_request():
            return self._send(403, {"error": "operator_forbidden",
                                     "message": "Дія доступна лише адміністратору (режим оператора)."})

        if path == "/api/support_report/save":
            import support_report
            data = self._read_json()
            keys = data.get("keys")
            opts = {"task_texts": bool(data.get("task_texts"))}
            res = support_report.save(message=(data.get("message") or ""),
                                      keys=(list(keys) if isinstance(keys, list) else None),
                                      options=opts)
            if data.get("open_folder", True):
                res["opened"] = support_report.open_folder(res.get("path"))
            return self._send(200, res)

        if path == "/api/support_report/open":
            import support_report
            data = self._read_json()
            return self._send(200, {"ok": support_report.open_folder(data.get("path"))})

        if path == "/api/chat/stream":
            import runstate
            data = self._read_json()
            message = (data.get("message") or "").strip()
            files = data.get("files") or []
            cancel_token = data.get("cancel_token") or ""
            runstate.clear(cancel_token)
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self.close_connection = True  # закрити сокет після стріму

            def emit(etype, payload):
                try:
                    self.wfile.write(("data: " + json.dumps({"type": etype, "data": payload},
                                                             ensure_ascii=False) + "\n\n").encode("utf-8"))
                    self.wfile.flush()
                except Exception:
                    pass

            # Тред заводимо ДО спроби виконати: інакше на винятку немає куди
            # записати хід — і питання людини зникає разом з аварією.
            tid, incoming_fc = "", ""
            try:
                tid = data.get("thread_id") or threads.create()["id"]
            except Exception:
                pass
            try:
                # Новий чат, створений у проєкті: спершу зробити його членом проєкту,
                # ЩОБ контекст проєкту дійшов до мозку вже в ПЕРШОМУ повідомленні.
                _pid = data.get("project_id")
                if _pid:
                    try:
                        projects.add_thread(_pid, tid)
                    except Exception:
                        pass
                incoming_fc, _m = filetext.build_files_context(files) if files else ("", [])
                if not incoming_fc:
                    incoming_fc = data.get("files_context") or ""
                # Успадкувати документ із попередніх ходів, якщо зараз нічого не прикріплено.
                files_context = incoming_fc or threads.latest_files_context(tid)
                _url_ctx = tools.fetch_urls_in_text(message)
                if _url_ctx:
                    files_context = (files_context + "\n\n" + _url_ctx).strip()
                # ⭐ КАРТКА РОЗУМІННЯ (зміна 152): поправка людини живе ВЕСЬ ЧАТ,
                # тому лягає у файл чату, а не в памʼять вкладки.
                _und_cl = threads.understanding_of(tid)
                _cf = data.get("confirm")
                if isinstance(_cf, dict) and (_cf.get("domain") or _cf.get("jurisdiction")):
                    _und_cl = threads.set_understanding(tid, _cf) or _und_cl
                result = engine.handle_message(
                    self._actor(),
                    message=message or "(див. прикріплені файли)",
                    history=threads.history_for_brain(tid),
                    files_context=files_context,
                    pending=data.get("pending"),
                    confirm=data.get("confirm"),
                    understanding_client=_und_cl,
                    can_ask=True,
                    emit=emit,
                    should_cancel=(lambda: runstate.is_cancelled(cancel_token)) if cancel_token else None,
                    project_context=projects.context_for_thread(tid),
                    egress_allowed=bool(data.get("egress_allowed")),
                )
                _persist_turn(tid, message, incoming_fc,
                              result.get("reply", ""), result.get("result"))
                result["thread_id"] = tid
                emit("final", result)
            except Exception as e:
                import traceback
                traceback.print_exc()
                # Аварія — теж хід розмови: питання людини й чесна відповідь
                # лягають у тред ТИМ САМИМ писарем, що й успішна відповідь.
                import failure
                _reply = failure.client_text(e, "server/chat_stream")
                _persist_turn(tid, message, incoming_fc, _reply)
                emit("final", {"reply": _reply, "thread_id": tid,
                               "decision": {"status": "error"}, "result": None, "pending": None})
            finally:
                runstate.clear(cancel_token)
            return

        if path == "/api/chat":
            data = self._read_json()
            message = (data.get("message") or "").strip()
            files = data.get("files") or []
            if not message and not data.get("pending") and not files:
                return self._send(400, {"error": "empty_message"})
            # Тред заводимо ДО спроби виконати (див. _persist_turn): хід мусить
            # мати куди лягти й тоді, коли рушій упав.
            tid, incoming_fc = "", ""
            try:
                tid = data.get("thread_id") or threads.create()["id"]
            except Exception:
                pass
            try:
                # Новий чат, створений у проєкті: спершу зробити його членом проєкту,
                # ЩОБ контекст проєкту дійшов до мозку вже в ПЕРШОМУ повідомленні.
                _pid = data.get("project_id")
                if _pid:
                    try:
                        projects.add_thread(_pid, tid)
                    except Exception:
                        pass
                incoming_fc, _meta = filetext.build_files_context(files) if files else ("", [])
                if not incoming_fc:
                    incoming_fc = data.get("files_context") or ""
                # Успадкувати документ із попередніх ходів, якщо зараз нічого не прикріплено.
                files_context = incoming_fc or threads.latest_files_context(tid)
                _url_ctx = tools.fetch_urls_in_text(message)
                if _url_ctx:
                    files_context = (files_context + "\n\n" + _url_ctx).strip()
                _und_cl = threads.understanding_of(tid)
                _cf = data.get("confirm")
                if isinstance(_cf, dict) and (_cf.get("domain") or _cf.get("jurisdiction")):
                    _und_cl = threads.set_understanding(tid, _cf) or _und_cl
                result = engine.handle_message(
                    self._actor(),
                    message=message or "(див. прикріплені файли)",
                    history=threads.history_for_brain(tid),
                    files_context=files_context,
                    pending=data.get("pending"),
                    confirm=data.get("confirm"),
                    understanding_client=_und_cl,
                    can_ask=True,
                    project_context=projects.context_for_thread(tid),
                    egress_allowed=bool(data.get("egress_allowed")),
                )
                # Збереження у архів чатів — ОДИН писар (див. _persist_turn)
                _persist_turn(tid, message, incoming_fc,
                              result.get("reply", ""), result.get("result"))
                result["thread_id"] = tid
                return self._send(200, result)
            except Exception as e:  # ніколи не падаємо мовчки
                import traceback
                traceback.print_exc()
                import failure
                _reply = failure.client_text(e, "server/chat")
                _persist_turn(tid, message, incoming_fc, _reply)
                return self._send(500, {
                    "reply": _reply, "thread_id": tid,
                    "decision": {"status": "error"}, "result": None, "pending": None,
                })

        if path == "/api/automations/toggle":
            data = self._read_json()
            ok = scheduler.set_enabled(data.get("id"), bool(data.get("enabled")))
            return self._send(200, {"ok": ok})

        # ⭐ 28.07.2026: розклад можна не лише вмикати, а й НАЛАШТОВУВАТИ —
        # періодичність і час наступного запуску. Раніше був самий вимикач.
        if path == "/api/automations/schedule":
            data = self._read_json()
            res = scheduler.set_schedule(data.get("id"),
                                         cadence=data.get("cadence"),
                                         next_run_at=data.get("next_run_at"))
            return self._send(200 if res.get("ok") else 400, res)

        # ⭐ 30.07.2026 (Зміна B). Двері НІЧОГО не виконують і нічого не стирають:
        # вони лише переказують прохання дошці. «Запустити зараз» пересуває час і
        # віддає задачу тому самому єдиному виконавцеві; «видалити» переносить
        # теку в архів. Обидві відповідають словами людини, а не кодом помилки.
        if path == "/api/automations/run_now":
            data = self._read_json()
            res = scheduler.request_run_now(data.get("id"))
            return self._send(200 if res.get("ok") else 400, res)

        if path == "/api/automations/delete":
            data = self._read_json()
            res = scheduler.delete(data.get("id"))
            return self._send(200 if res.get("ok") else 400, res)

        if path == "/api/discover":
            result = discovery.sync(register=True)
            return self._send(200, result)

        if path == "/api/system/status":
            # Активація/деактивація системи однією кнопкою в UI (лише адмін — див.
            # _ADMIN_POST_PATHS). Активація також пише статус у папку системи
            # (management → registry.write_folder_state), щоб пережити оновлення.
            import management
            data = self._read_json()
            sid = (data.get("system_id") or "").strip()
            status = (data.get("status") or "").strip().lower()
            if status not in ("active", "inactive"):
                return self._send(400, {"ok": False, "message": "status має бути active або inactive."})
            action = "activate" if status == "active" else "deactivate"
            res = management.apply_action(self._actor(), action, sid)
            return self._send(200 if res.get("ok") else 400, res)

        if path == "/api/llm/config":
            data = self._read_json()
            st = config.set_llm(
                provider=(data.get("provider") or "").strip().lower() or None,
                brain=(data.get("brain") or "").strip() or None,
                worker=(data.get("worker") or "").strip() or None,
            )
            # Самомодель залежить від активної моделі — скинути кеш, щоб мозок знав про зміну.
            try:
                capabilities.invalidate()
            except Exception:
                pass
            # ⭐ 11.08.2026: перелiк для екрана дає ОДИН писар — той, що
            # питає провайдера. Зашитий рядок лишився тiльки запасним.
            st["suggestions"] = models_live.suggestions()
            st["model_ranks"] = models_live.ranks_for(st["suggestions"])
            return self._send(200, st)

        if path == "/api/llm/demo":
            data = self._read_json()
            on = bool(data.get("on"))
            ks = config.keys_status()
            if on:
                # ⭐⭐⭐ 10.08.2026, зміни 146 і 148. ДЕМО-РЕЖИМ — ЦЕ ПЕРШИЙ
                # ДОТИК НОВОГО КЛІЄНТА, а зашиті тут назви моделей робили його
                # першим враженням помилку 404 (Google зняв модель для нових
                # ключів). Тепер жодного імені: беремо ЖИВІ моделі провайдера
                # за РОЛЛЮ — дешевий виконавець і сильніший мозок.
                _prov = ""
                for _p in ("gemini", "openai", "anthropic"):
                    if ks.get(_p):
                        _prov = _p
                        break
                if _prov:
                    b = config.live_default_model(_prov, "brain")
                    w = config.live_default_model(_prov, "worker")
                else:
                    return self._send(200, {"error": "no_keys", "demo": False,
                                            "message": "Немає ключа жодного хмарного провайдера."})
                if config.ENV.get("DEMO_MODE") != "1":
                    prev = {"DEMO_PREV_BRAIN": config.brain_model(),
                            "DEMO_PREV_WORKER": config.worker_model()}
                    config.update_env_local(prev)
                    config.ENV.update(prev)
                st = config.set_llm(brain=b, worker=w)
                config.update_env_local({"DEMO_MODE": "1"}); config.ENV["DEMO_MODE"] = "1"
                st["demo"] = True
            else:
                pb = (config.ENV.get("DEMO_PREV_BRAIN") or "").strip()
                pw = (config.ENV.get("DEMO_PREV_WORKER") or "").strip()
                st = config.set_llm(brain=pb or None, worker=pw or None)
                config.update_env_local({"DEMO_MODE": "0"}); config.ENV["DEMO_MODE"] = "0"
                st["demo"] = False
            try:
                capabilities.invalidate()
            except Exception:
                pass
            # ⭐ 11.08.2026: перелiк для екрана дає ОДИН писар — той, що
            # питає провайдера. Зашитий рядок лишився тiльки запасним.
            st["suggestions"] = models_live.suggestions()
            st["model_ranks"] = models_live.ranks_for(st["suggestions"])
            return self._send(200, st)

        if path == "/api/setup":
            # Майстер налаштування: зберегти ключі (локально в .env.local) і перевірити звʼязок.
            data = self._read_json()
            st = config.set_keys({
                "openai": data.get("openai"),
                "anthropic": data.get("anthropic"),
                "gemini": data.get("gemini"),
            })
            ping_ok, ping_msg = (False, "немає ключа")
            if st.get("ready"):
                try:
                    ping_ok, ping_msg = llm.ping()
                except Exception as e:
                    ping_ok, ping_msg = False, str(e)
            st["ping"] = {"ok": ping_ok, "message": ping_msg}
            st["keys"] = config.keys_status()
            return self._send(200, st)

        if path == "/api/setup/local":
            # Локальна / on-prem модель: зберегти base_url+модель і зробити активною,
            # потім перевірити зв'язок із локальним сервером (Ollama/vLLM/LM Studio).
            data = self._read_json()
            st = config.set_local(
                base_url=(data.get("base_url") or "").strip() or None,
                model=(data.get("model") or "").strip() or None,
                worker=(data.get("worker") or "").strip() or None,
            )
            try:
                capabilities.invalidate()
            except Exception:
                pass
            ping_ok, ping_msg = (False, "не задано base_url/модель")
            if st.get("local") and config.LOCAL_MODEL:
                try:
                    ping_ok, ping_msg = llm.ping()
                except Exception as e:
                    ping_ok, ping_msg = False, str(e)
            st["ping"] = {"ok": ping_ok, "message": ping_msg}
            st["keys"] = config.keys_status()
            return self._send(200, st)

        if path == "/api/llm/stealth":
            # Режим Стелс: повна локальна ізоляція. on=true вмикає локальну модель
            # (за потреби з переданими base_url+model), on=false повертає хмару.
            data = self._read_json()
            st = config.set_stealth(
                bool(data.get("on")),
                base_url=(data.get("base_url") or "").strip() or None,
                model=(data.get("model") or "").strip() or None,
                worker=(data.get("worker") or "").strip() or None,
            )
            try:
                capabilities.invalidate()
            except Exception:
                pass
            ping_ok, ping_msg = (True, "")
            if st.get("stealth"):
                try:
                    ping_ok, ping_msg = llm.ping()
                except Exception as e:
                    ping_ok, ping_msg = False, str(e)
            st["ping"] = {"ok": ping_ok, "message": ping_msg}
            # ⭐ 11.08.2026: перелiк для екрана дає ОДИН писар — той, що
            # питає провайдера. Зашитий рядок лишився тiльки запасним.
            st["suggestions"] = models_live.suggestions()
            st["model_ranks"] = models_live.ranks_for(st["suggestions"])
            return self._send(200, st)

        if path == "/api/cancel":
            import runstate
            data = self._read_json()
            ok = runstate.request_cancel(data.get("cancel_token") or "")
            return self._send(200, {"ok": ok})

        if path == "/api/license":
            import license as licensing
            data = self._read_json()
            config.set_license(data.get("key") or "")
            st = licensing.status()
            st["entitlement"] = licensing.entitlement()
            return self._send(200, st)

        if path == "/api/license/generate":
            if not config.LICENSE_ADMIN:
                return self._send(403, {"error": "admin_disabled",
                                        "message": "Генерація вимкнена. Увімкніть LICENSE_ADMIN=1 у .env.local."})
            import license as licensing
            data = self._read_json()
            try:
                days = int(data.get("days") or 365)
            except Exception:
                days = 365
            key = licensing.generate((data.get("customer") or "").strip(),
                                     (data.get("edition") or "pilot").strip(), days)
            return self._send(200, {"key": key, "info": licensing.parse(key)})

        if path == "/api/telegram/token":
            import telegram_bot
            data = self._read_json()
            return self._send(200, telegram_bot.set_token(data.get("token") or ""))

        if path == "/api/telegram/tasks_token":
            import telegram_bot
            data = self._read_json()
            return self._send(200, telegram_bot.set_tasks_token(data.get("token") or ""))

        if path == "/api/telegram/support_mode":
            import config as _cfg
            data = self._read_json()
            return self._send(200, _cfg.set_support_mode(bool(data.get("on"))))

        if path == "/api/update/apply":
            import update as _upd
            data = self._read_json()
            ids = data.get("ids")
            return self._send(200, _upd.apply_updates(ids=ids or None))

        if path in ("/api/telegram/allow", "/api/telegram/revoke", "/api/telegram/dismiss"):
            import telegram_access
            data = self._read_json()
            cid = data.get("id")
            try:
                cid = int(cid)
            except Exception:
                return self._send(400, {"error": "bad_chat_id"})
            if path.endswith("/allow"):
                snap = telegram_access.allow(cid, (data.get("label") or "").strip())
            elif path.endswith("/revoke"):
                snap = telegram_access.revoke(cid)
            else:
                snap = telegram_access.dismiss_pending(cid)
            return self._send(200, snap)

        if path == "/api/threads/new":
            return self._send(200, threads.create())

        if path == "/api/threads/delete":
            data = self._read_json()
            return self._send(200, {"ok": threads.delete(data.get("id"))})

        if path == "/api/projects/new":
            data = self._read_json()
            return self._send(200, projects.create(data.get("name")))

        if path == "/api/projects/update":
            data = self._read_json()
            rec = projects.update(data.get("id"), name=data.get("name"),
                                  context=data.get("context"))
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/projects/delete":
            data = self._read_json()
            return self._send(200, {"ok": projects.delete(data.get("id"))})

        if path == "/api/projects/add-thread":
            data = self._read_json()
            rec = projects.add_thread(data.get("id"), data.get("thread_id"))
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/projects/remove-thread":
            data = self._read_json()
            rec = projects.remove_thread(data.get("id"), data.get("thread_id"))
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/support/log":
            import support
            data = self._read_json()
            e = support.log(data.get("hours"), data.get("note", ""))
            return self._send(200, {"ok": bool(e), "entry": e, "summary": support.summary()})

        if path == "/api/crm/inbound":
            # Зовнішній інбаунд-сигнал (ранкова автоперевірка пошти). Зіставляє
            # відправника з карткою й піднімає «увагу». ⛔ 12.08.2026: НОВОГО ЛІДА
            # БІЛЬШЕ НЕ СТВОРЮЄ САМ — невпізнане йде в чергу «Не оброблені», а в базу
            # його кладе людина кнопкою (/api/crm/promote).
            import inbound
            data = self._read_json()
            channel = (data.get("channel") or "email").strip()
            if channel == "telegram":
                res = inbound.from_telegram(data.get("chat_id"),
                                            username=data.get("username", ""),
                                            name=data.get("name", ""),
                                            text=data.get("preview", ""))
            else:
                email = (data.get("email") or "").strip()
                if not email:
                    return self._send(400, {"error": "no_email"})
                res = inbound.from_email(email, name=data.get("name", ""),
                                         subject=data.get("subject", ""),
                                         preview=data.get("preview", ""),
                                         org=data.get("org", ""))
            import crm
            return self._send(200, {"ok": True, "result": res, "counts": crm.counts()})

        if path == "/api/crm/promote":
            # ⭐ КНОПКА МЕНЕДЖЕРА: невпізнане вхідне → контрагент у базі «Клієнти».
            # Мінімум — сама ручка (пошта/телеграм) і назва; тип і ролі можна
            # уточнити пізніше на стадіях «Збір даних» і «Кваліфікація».
            import inbound as _inb
            import parties as _pt
            import crm as _crm
            data = self._read_json()
            roles = data.get("roles") or [_pt.ROLE_CLIENT]
            if isinstance(roles, str):
                roles = [roles]
            try:
                res = _inb.promote((data.get("channel") or "").strip(),
                                   (data.get("identity") or "").strip(),
                                   name=data.get("name", ""),
                                   kind=data.get("kind", _pt.KIND_UNKNOWN),
                                   roles=roles,
                                   create_card=bool(data.get("create_card", True)),
                                   note=data.get("note", ""))
            except _pt.PartyError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "result": res,
                                    "inbox": _crm.inbox(), "counts": _pt.count()})

        if path == "/api/crm/party_manager":
            # ⭐ D1 (15.08.2026): призначити або зняти відповідального за клієнта.
            # ⛒ Сервер нічого не вирішує й нічого не вгадує: «чи можна» судить
            # писар довідника, а відмова їде СЛОВАМИ, а не кодом 500.
            import entity as _ent5
            import parties as _pt4
            data = self._read_json()
            pid = (data.get("id") or "").strip()
            try:
                card = _pt4.set_manager(pid, (data.get("employee") or "").strip(),
                                        by=_ent5.person_of_actor(self._actor()))
            except Exception as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "manager": card})

        if path == "/api/crm/party":
            # Правка запису клієнтської бази: назва, тип, ролі, примітка, ручки.
            # ⭐ Номер контрагента не міняється НІКОЛИ — на ньому тримається історія.
            import parties as _pt
            data = self._read_json()
            pid = (data.get("id") or "").strip()
            try:
                if not _pt.exists(pid):
                    return self._send(404, {"error": "Контрагента %s немає в довіднику." % (pid or "«»")})
                if "name" in data:
                    _pt.set_name(pid, data.get("name", ""))
                if "kind" in data:
                    _pt.set_kind(pid, data.get("kind", ""))
                if "roles" in data:
                    _pt.set_roles(pid, data.get("roles") or [])
                if "note" in data:
                    _pt.set_note(pid, data.get("note", ""))
                if data.get("add_handle"):
                    h = data["add_handle"]
                    _pt.add_handle(pid, h.get("kind", ""), h.get("value", ""))
                if data.get("remove_handle"):
                    h = data["remove_handle"]
                    _pt.remove_handle(pid, h.get("kind", ""), h.get("value", ""))
            except _pt.PartyError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "party": _pt.get(pid)})

        if path == "/api/crm/pin":
            # ⭐⭐ ЗАКРІПЛЕННЯ ПОДІЇ (C3, 15.08.2026). Реєстр окремий, бо журнал
            # append-only переписувати не можна; ключ події рахує ОДИН писар
            # (`relations.event_key`), а сервер його лише передає.
            # ⛒ ВІДМОВА ПРО МЕЖУ ЇДЕ СЛОВАМИ (їх людина й побачить), а не кодом.
            import pins as _pins
            data = self._read_json()
            ref = (data.get("ref") or "").strip()
            key = (data.get("key") or "").strip()
            on = bool(data.get("on"))
            try:
                res = _pins.pin(ref, key) if on else _pins.unpin(ref, key)
            except Exception as ex:
                return self._send(400, {"error": str(ex)})
            res["ok"] = True
            return self._send(200, res)

        if path in ("/api/crm/bulk_preview", "/api/crm/bulk_apply"):
            # ⭐⭐⭐ D3 (16.08.2026): ЗРОБИТИ ЩОСЬ ІЗ ВІДІБРАНИМ, не перебираючи
            # по одному. ⛒ Сервер тут — лише двері: ані відбору, ані дії, ані
            # переліку він не рахує сам. Усе — в ОДНОГО писаря `party_bulk`,
            # інакше «вибрано 743» на екрані і «змінено 743» в базі були б
            # двома різними числами.
            import entity as _ent6
            import party_bulk as _pb
            import party_search as _ps2
            data = self._read_json()
            raw = dict(data.get("criteria") or {})
            try:
                # ⛒ Умови відбору ПЕРЕВІРЯЄ той самий писар, що й пошук: сміття
                # в стані чи невідомий працівник — відмова СЛОВАМИ ще до того,
                # як хоч одна картка змінилась.
                crit = _ps2.criteria(query=raw.get("query", ""),
                                     filter=raw.get("filter", ""),
                                     sort=raw.get("sort", ""),
                                     dir=raw.get("dir", ""),
                                     state=raw.get("state", ""),
                                     manager=raw.get("manager", ""))
                args = dict(action=data.get("action", ""),
                            scope=data.get("scope", ""),
                            ids=data.get("ids") or [],
                            crit=crit,
                            employee=(data.get("employee") or ""))
                if path.endswith("preview"):
                    res = _pb.preview(**args)
                else:
                    # 🩸🩸🩸 `by` — ЦЕ ПОСИЛАННЯ НА ЛЮДИНУ, А НЕ ПІДПИС СЛОВАМИ
                    # (спіймано ЖИВИМ прогоном 16.08.2026). Я поставив сюди
                    # текст «менеджер (консоль)» — реєстр звʼязків його прийняв,
                    # і картки p0016/p0017 перестали ВІДКРИВАТИСЬ узагалі.
                    # ⛒ Беремо ТОЙ САМИЙ писар, що й одинарні двері D1
                    # (`/api/crm/party_manager`): два способи назвати діяча —
                    # це два писарі однієї правди.
                    res = _pb.apply(by=_ent6.person_of_actor(self._actor()), **args)
            except (_pb.BulkError, _ps2.SearchError) as ex:
                return self._send(400, {"error": str(ex)})
            res["ok"] = True
            return self._send(200, res)

        if path == "/api/crm/party_new":
            # ⭐ ЗАВЕСТИ КОНТРАГЕНТА РУКАМИ (13.08.2026). Досі в базу вів РІВНО ОДИН
            # шлях — кнопка «У базу» з черги вхідних. Але клієнт народжується і на
            # зустрічі, і в телефонній розмові: контакт, який не має як потрапити в
            # базу, живе в чиїйсь голові, а не в активі компанії.
            import parties as _pt
            data = self._read_json()
            try:
                party = _pt.create(name=(data.get("name") or "").strip(),
                                   kind=(data.get("kind") or ""),
                                   roles=data.get("roles") or [_pt.ROLE_CLIENT],
                                   handles=data.get("handles") or {},
                                   source="manual",
                                   note=(data.get("note") or ""))
            except _pt.PartyError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "party": party})

        if path == "/api/crm/party_delete":
            # ⭐ ВИДАЛЕННЯ НЕ ВГАДУЄ ФОРМУ (рішення Андрія 10.08, підтверджене 13.08).
            # Спершу віддаємо ПЕРЕЛІК: що саме зникне і що ЗАЛИШИТЬСЯ. Видаляємо лише
            # другим викликом, із `confirm`. Картку угоди не чіпаємо НІКОЛИ: історія
            # взаємин і ліцензія — окрема цінність, і зносити її заразом ніхто не просив.
            import crm as _crm
            import parties as _pt
            data = self._read_json()
            pid = (data.get("id") or "").strip()
            if not _pt.exists(pid):
                return self._send(404, {"error": "Контрагента %s немає в довіднику." % (pid or "«»")})
            party = _pt.get(pid)
            card = _crm.card_of_party(pid)
            handles = []
            for hk, vals in (party.get("handles") or {}).items():
                for v in (vals or []):
                    handles.append("%s: %s" % (_pt.HANDLE_NAMES.get(hk, hk), v))
            plan = {
                "party": party,
                "goes": ["контрагент %s «%s»" % (pid, party.get("name") or "")] + handles,
                "stays": ([("картка угоди «%s» з усією історією, ліцензією та "
                            "нотатками — вона лишиться, але без звʼязку з довідником") % card]
                          if card else ["картки угоди в Сервіс-центрі немає"]),
                "protocol": ("Рядки протоколу з посиланням party:%s НЕ зникають: журнал "
                             "дописується в кінець і не переписується назад." % pid),
            }
            if not data.get("confirm"):
                return self._send(200, {"ok": False, "plan": plan})
            if card:
                try:
                    _crm.set_party(card, "")
                except Exception:
                    pass
            ok = _pt.delete(pid)
            return self._send(200, {"ok": bool(ok), "deleted": pid, "plan": plan})

        if path == "/api/crm/inbox_attach":
            # ⭐ ПРИВʼЯЗАТИ ДО НАЯВНОГО (борг із 12.08). У черзі стояв телеграм
            # «Boris Mamlin», а в базі вже був p0004 «Борис Мамлін»: єдина кнопка
            # «У базу» завела б ДУБЛЬ руками — тобто зіпсувала б саме той актив,
            # заради якого писався довідник.
            import crm as _crm
            import parties as _pt
            data = self._read_json()
            pid = (data.get("party_id") or "").strip()
            channel = (data.get("channel") or "").strip()
            identity = (data.get("identity") or "").strip()
            name = (data.get("name") or "").strip()
            if not _pt.exists(pid):
                return self._send(404, {"error": "Контрагента %s немає в довіднику." % (pid or "«»")})
            hk = _pt.H_EMAIL if channel == "email" else _pt.H_TG_ID
            try:
                _pt.add_handle(pid, hk, identity)
                if name and channel != "email":
                    user = name.split("(@")[-1].rstrip(")") if "(@" in name else ""
                    if user:
                        try:
                            _pt.add_handle(pid, _pt.H_TG_USER, user)
                        except _pt.PartyError:
                            pass
            except _pt.PartyError as ex:
                return self._send(400, {"error": str(ex)})
            _crm.clear_inbox(channel, identity)
            return self._send(200, {"ok": True, "party": _pt.get(pid),
                                    "inbox": _crm.inbox()})

        if path == "/api/crm/inbox_clear":
            import crm
            data = self._read_json()
            ok = crm.clear_inbox((data.get("channel") or "").strip(),
                                 (data.get("identity") or "").strip())
            return self._send(200, {"ok": bool(ok), "inbox": crm.inbox()})

        # ⭐⭐⭐ ДВЕРІ УГОДИ (крок C1, 15.08.2026). Кожна дія називає себе окремо:
        # одні двері «зміни щось в угоді» приймали б будь-що і мовчки губили
        # незнайоме поле — рівно те, на чому нас спіймав власний чек.
        # ⭐⭐⭐ КРОК C2 (15.08.2026) — ЛИСТУВАННЯ З АДРЕСОЮ УГОДИ.
        # ⚠ Стоїть ПЕРЕД загальним `deal_*`, інакше цей самий префікс проковтне
        # маршрут і віддасть «not_found» — тиха відмова на рівному місці.
        if path in ("/api/crm/deal_mail", "/api/crm/deal_mail_sent",
                    "/api/crm/spread_assign", "/api/crm/spread_drop"):
            import deal_mail as _dm
            data = self._read_json()
            try:
                if path.endswith("/deal_mail"):
                    # Заготовка листа. Нічого ще не сталось — сліду не пишемо.
                    return self._send(200, _dm.compose(
                        (data.get("id") or "").strip(),
                        subject=data.get("subject", ""),
                        to=data.get("to", "")))
                if path.endswith("/deal_mail_sent"):
                    # ⛒ «Сформовано», а не «надіслано»: шле поштова програма людини.
                    return self._send(200, _dm.note_sent(
                        (data.get("id") or "").strip(),
                        subject=data.get("subject", ""),
                        to=data.get("to", "")))
                if path.endswith("/spread_assign"):
                    res = _dm.assign((data.get("item") or "").strip(),
                                     (data.get("deal") or "").strip())
                    import deals as _dl3
                    return self._send(200, {"ok": True, "deal": _dl3.card(res["deal"]),
                                            "spread": _dm.pending()})
                _dm.drop((data.get("item") or "").strip(), data.get("why", ""))
                return self._send(200, {"ok": True, "spread": _dm.pending()})
            except Exception as ex:
                # ⛒ ВІДМОВА СЛОВАМИ, а не 500.
                return self._send(400, {"error": str(ex)})

        if path.startswith("/api/crm/deal_"):
            import deals as _dl
            data = self._read_json()
            did = (data.get("id") or "").strip()
            try:
                if path.endswith("/deal_new"):
                    row = _dl.create((data.get("name") or "").strip(),
                                     (data.get("party") or "").strip(),
                                     stage=(data.get("stage") or _dl.DEFAULT_STAGE),
                                     amount=data.get("amount") or {},
                                     note=(data.get("note") or ""))
                    did = row["id"]
                elif not did:
                    return self._send(400, {"error": "Не сказано, про яку угоду йдеться."})
                elif path.endswith("/deal_name"):
                    _dl.set_name(did, data.get("name", ""))
                elif path.endswith("/deal_stage"):
                    _dl.set_stage(did, data.get("stage", ""))
                elif path.endswith("/deal_amount"):
                    _dl.set_amount(did, data.get("amount") or {})
                elif path.endswith("/deal_next_action"):
                    _dl.set_next_action(did, data.get("text", ""), data.get("date", ""))
                elif path.endswith("/deal_action_done"):
                    _dl.mark_action_done(did)
                elif path.endswith("/deal_attention"):
                    _dl.set_attention(did, value=data.get("value"),
                                      inc=int(data.get("inc") or 0))
                elif path.endswith("/deal_archive"):
                    _dl.set_archived(did, bool(data.get("on", True)))
                elif path.endswith("/deal_note"):
                    _dl.set_note(did, data.get("note", ""))
                elif path.endswith("/deal_client"):
                    _dl.set_client(did, (data.get("party") or "").strip())
                elif path.endswith("/deal_person_remove"):
                    _dl.remove_person(did, (data.get("party") or "").strip())
                elif path.endswith("/deal_person"):
                    _dl.add_person(did, (data.get("party") or "").strip(),
                                   note=(data.get("note") or ""))
                elif path.endswith("/deal_delete"):
                    # ⛒ Видалення НЕ ВГАДУЄ ФОРМУ: прибираємо рівно за номером.
                    if not _dl.delete(did):
                        return self._send(404, {"error": "Угоди %s немає в реєстрі." % did})
                    return self._send(200, {"ok": True, "deleted": did,
                                            "board": _dl.board()})
                else:
                    return self._send(404, {"error": "not_found", "path": path})
            except Exception as ex:
                # ⛒ ВІДМОВА СЛОВАМИ, а не 500: людина мусить прочитати причину.
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "deal": _dl.card(did),
                                    "board": _dl.board()})

        if path in ("/api/crm/note", "/api/crm/history",
                    "/api/crm/profile", "/api/crm/contact", "/api/crm/contact_remove",
                    "/api/crm/comm", "/api/crm/dossier",
                    "/api/crm/systems"):
            import crm
            data = self._read_json()
            cust = (data.get("customer") or "").strip()
            if not cust:
                return self._send(400, {"error": "no_customer"})
            if path.endswith("/note"):
                crm.set_notes(cust, data.get("notes", ""))
            elif path.endswith("/profile"):
                crm.set_profile(cust, data.get("profile") or {})
                if "name_en" in data:
                    crm.ensure_client(cust, name_en=(data.get("name_en") or "").strip())
            elif path.endswith("/contact_remove"):
                crm.remove_contact(cust, data.get("index"))
            elif path.endswith("/contact"):
                crm.add_contact(cust, data.get("contact") or {})
            elif path.endswith("/comm"):
                ch = (data.get("channel") or "note").strip()
                crm.add_history(cust, ch, data.get("note", ""))
            elif path.endswith("/systems"):
                # ⭐⭐⭐ ЕТАП 4. Набір судить ОДИН суддя — той самий, що й збірка.
                # Помилку показуємо людині ТУТ, а не в мовчазній збірці потім.
                _raw = data.get("systems")
                if _raw is not None:
                    import make_client_build as _mcb
                    try:
                        _mcb.client_systems(cust, card={"systems": _raw})
                    except _mcb.EntitlementError as _e:
                        return self._send(400, {"error": "bad_systems", "message": str(_e)})
                crm.set_systems(cust, _raw)
            elif path.endswith("/dossier"):
                crm.set_dossier(cust, data.get("text", ""))
            else:
                crm.add_history(cust, (data.get("type") or "note"), data.get("note", ""))
            return self._send(200, {"ok": True, "card": crm.card_public(cust),
                                    "counts": crm.counts()})

        return self._send(404, {"error": "not_found", "path": path})

    # ---- статика ----------------------------------------------------------
    def _localized_html(self, page):
        """Читає HTML-сторінку UI й підставляє дефолтну мову зі збірки.
        Вибір користувача в localStorage має пріоритет (логіка в ui/i18n.js).
        Спільний шлях для index/setup/telegram → один шов на всі сторінки."""
        lang = (getattr(config, "UI_DEFAULT_LANG", "uk") or "uk").lower()
        if lang not in ("uk", "ru", "en"):
            lang = "uk"
        html = page.read_text(encoding="utf-8").replace("__UI_DEFAULT_LANG__", lang)
        return html.encode("utf-8")

    def _serve_ui(self):
        index = config.UI_DIR / "index.html"
        if not index.exists():
            return self._send(500, {"error": "ui_missing"})
        return self._send(200, self._localized_html(index),
                          content_type="text/html; charset=utf-8")

    def _serve_artifact(self, path):
        parts = path.split("/")
        # /artifacts/<run_id>/<filename>
        if len(parts) < 4:
            return self._send(404, {"error": "bad_artifact_path"})
        run_id, filename = parts[2], "/".join(parts[3:])
        fpath = store.artifact_path(run_id, filename)
        if not fpath.exists():
            return self._send(404, {"error": "artifact_not_found"})
        data = fpath.read_bytes()
        ctypes = {
            ".md": "text/markdown; charset=utf-8",
            ".html": "text/html; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".csv": "text/csv; charset=utf-8",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        }
        ext = "." + filename.rsplit(".", 1)[-1] if "." in filename else ""
        return self._send(200, data, content_type=ctypes.get(ext, "application/octet-stream"))


def _scheduler_loop():
    # Фоновий потік: перевіряє автоматизації, що настали.
    while True:
        try:
            executed = scheduler.run_due(engine.automation_runner)
            for e in executed:
                print(f"[auto] виконано: {e['name']} -> {e['entry'].get('status')}")
        except Exception as ex:
            sys.stderr.write(f"[auto] помилка планувальника: {ex}\n")
        time.sleep(60)


def main():
    # ⭐ 29.07.2026. Консоль продукту існувала ЛИШЕ на екрані: коли в клієнта
    # щось падало, від збою не лишалось нічого, крім слів. Тепер той самий
    # вивід іде і у файл logs\\server_*.log — його бере звіт підтримки
    # (support_report). Один прийом, що вже працює в наших пробах.
    try:
        import run_log
        run_log.start("server")
        run_log.prune("server", 20)
    except Exception as ex:
        sys.stderr.write("[log] журнал сервера не увімкнувся: %s\n" % ex)
    # ⭐ 30.07.2026. Клієнт міг відредагувати .env.local руками або отримати
    # збірку із запіненою моделлю чужого провайдера — тоді продукт казав
    # «немає API-ключа», хоча ключі є. Канал «правка файлу» повз set_keys не
    # проходить, тому звіряємо досяжність ролей ще й на старті — і НАЗИВАЄМО
    # зміну в журналі, а не підмінюємо вибір клієнта мовчки.
    try:
        _rt = config.ensure_reachable_models()
        if _rt.get("changed"):
            for _role in ("brain", "worker"):
                _r = _rt.get(_role)
                if _r:
                    print("[llm] %s: модель %s недосяжна (немає ключа) -> %s (%s)"
                          % (_role, _r["was"], _r["now"], _r["provider"]))
    except Exception as _ex:
        sys.stderr.write("[llm] звірка досяжності моделей не виконалась: %s\n" % _ex)
    brain = config.provider_status()
    print("=" * 64)
    print(" AI Orchestrator Platform — Python engine")
    print("=" * 64)
    print(f" Робочий простір : {config.WORKSPACE_ROOT}")
    print(f" Реєстр систем   : {config.REGISTRY_JSON}")
    print(f" Провайдер       : {brain['provider']} [{'готовий' if brain['ready'] else 'НЕМАЄ КЛЮЧА'}]")
    print(f" Мозок (думання) : {brain.get('brain_model')}")
    print(f" Виконавець      : {brain.get('worker_model')}")
    if brain["ready"]:
        ok, msg = llm.ping()
        print(f" Перевірка мозку : {'✓ OK' if ok else '✗ ПОМИЛКА'} — {msg}")
    if not brain["ready"]:
        print("  УВАГА: додайте OPENAI_API_KEY або ANTHROPIC_API_KEY у orchestrator_py/.env.local")
    print(f" Консоль         : http://127.0.0.1:{config.PORT}")
    try:
        import keepawake
        if keepawake.start():
            print(" Енергозбереження : сон ПК вимкнено, поки працює застосунок")
    except Exception:
        pass
    caps = artifacts.capabilities()
    fmts = "md, html" + (", docx" if caps["docx"] else "") + (", xlsx" if caps["xlsx"] else "") + (", pptx" if caps.get("pptx") else "")
    missing = ([] + (["python-docx"] if not caps["docx"] else []) + (["openpyxl"] if not caps["xlsx"] else []) + (["python-pptx"] if not caps.get("pptx") else []))
    print(f" Артефакти       : {fmts}"
          + (f"   [для повного набору: pip install {' '.join(missing)}]" if missing else "   (повний набір доступний)"))
    print(f" Планувальник    : активний (фонова перевірка щохвилини)")
    # Виявлення ресурсів: знайти нові системи у проєктах і додати в оркестр
    try:
        disc = discovery.sync(register=True)
        if disc.get("added"):
            print(f" Виявлено нових систем: {len(disc['added'])} -> {', '.join(disc['added'])}")
        if disc.get("missing"):
            print(f" Позначено зниклими: {', '.join(disc['missing'])}")
        if disc.get("healed"):
            print(f" Відновлено статус із папки: {', '.join(disc['healed'])}")
        print(f" Систем в оркестрі: {len(registry.load_systems())}")
    except Exception as ex:
        sys.stderr.write(f"[discovery] помилка: {ex}\n")
    print("=" * 64)

    url = f"http://127.0.0.1:{config.PORT}"
    threading.Thread(target=_scheduler_loop, daemon=True).start()
    # ⭐ СТОРОЖ СТРОКІВ (зміна 172): протермінування стає ФАКТОМ у протоколі, а не
    # лише картинкою на екрані. ОКРЕМИЙ потік навмисно: довгий прогін автоматизації
    # не сміє відкладати факт, а поломка сторожа — зупиняти автоматизації.
    try:
        import taskdesk_overdue as _overdue
        threading.Thread(target=_overdue.loop, daemon=True).start()
        print(" Сторож строків  : активний (перевірка щохвилини)"
              if _overdue.on() else
              " Сторож строків  : мовчить (Task Desk вимкнений)")
    except Exception as ex:
        sys.stderr.write("[строки] сторож не запустився: %s\n" % ex)
    # Telegram-вхід (опційно): активується, якщо в .env.local є TELEGRAM_BOT_TOKEN
    try:
        import telegram_bot
        if telegram_bot.start_in_background():
            print(" Telegram-бот     : активний (long-polling)")
            print(f" Доступ до бота    : керування на http://127.0.0.1:{config.PORT}/telegram")
        else:
            print(" Telegram-бот     : вимкнено (немає TELEGRAM_BOT_TOKEN у .env.local)")
    except Exception as ex:
        sys.stderr.write(f"[telegram] не вдалося запустити: {ex}\n")
    # РОТ TASK DESK: доставка подій нерва в телеграм. Окремий потік, окремий
    # курсор. Немає бота задач — рота просто немає, і це нормальний стан
    # (закритий контур): нерв від цього не страждає.
    try:
        import taskdesk_telegram as _mouth
        if _mouth.start_in_background():
            print(" Задачі в телеграм : доставка активна")
        else:
            print(" Задачі в телеграм : вимкнено (немає TELEGRAM_TASKS_BOT_TOKEN)")
    except Exception as ex:
        sys.stderr.write(f"[рот] не вдалося запустити доставку: {ex}\n")
    # Зайнятий порт = SensFlow уже працює (часта ситуація: лишилось кілька відкритих
    # вікон). НЕ падаємо з трасою OSError[Errno 48] — просто відкриваємо вже запущену
    # консоль і виходимо чисто. Це прибирає цілий клас «не запускается» у клієнтів.
    try:
        httpd = ThreadingHTTPServer(("127.0.0.1", config.PORT), Handler)
    except OSError as ex:
        import errno
        if ex.errno in (errno.EADDRINUSE, 48, 98, 10048):
            print("=" * 64)
            print(f" SensFlow вже запущено на {url} — відкриваю наявну консоль.")
            print(" Це друге вікно можна закрити. Якщо консоль відкрилась не та —")
            print(" закрийте ВСІ вікна SensFlow і запустіть лише один раз.")
            print("=" * 64)
            try:
                webbrowser.open(url)
            except Exception:
                pass
            return
        raise
    try:
        # Автоматично відкрити консоль у браузері (можна вимкнути: AUTO_OPEN_BROWSER=0)
        if (config.ENV.get("AUTO_OPEN_BROWSER", "1") or "1") != "0":
            threading.Timer(1.2, lambda: webbrowser.open(url)).start()
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nЗупинено.")
        httpd.server_close()


if __name__ == "__main__":
    main()
