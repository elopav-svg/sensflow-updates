# -*- coding: utf-8 -*-
"""protocol_report.py — ЗВІТ ПО ЗАГАЛЬНОМУ ПРОТОКОЛУ (зміна 169, 13.08.2026).

⭐ ЖУРНАЛ, ЯКОГО НІХТО НЕ ЧИТАЄ, — НУЛЬ. Тому звіт входить у той самий крок, що й
сам протокол, а не «колись потім». Він відповідає рівно на ті чотири питання, які
Андрій назвав приводом усього хребта:

    1. ЗВІДКИ БЕРЕТЬСЯ РОБОТА   — людина / телеграм / пошта / розклад
    2. ПО КОМУ ВОНА ЙДЕ         — скільки дій по кожному контрагенту і чим скінчились
    3. ДЕ ВОНА ГАЛЬМУЄ          — відмови й поломки з причинами СЛОВАМИ
    4. СКІЛЬКИ КОШТУЄ           — гроші поруч із роботою, а не окремим кошиком

⚠ ЧЕСНІ МЕЖІ (кажу тут, щоб не читалось як повна каса):
  • протокол починається з дня включення — старі журнали в нього не переносились;
  • у рядок ціни потрапляє робота, привʼязана до прогону, задачі чи контрагента;
    повний рахунок грошей за добу веде `costs` (`Run selfcheck` → день/сесія);
  • екран у консолі — наступний крок, не цей.

Запуск: python3 protocol_report.py [--days 7] [--feed 20] [--file]
"""
import sys
from collections import OrderedDict
from datetime import datetime, timedelta
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import clock
import config
import entity
import protocol

LINE = "=" * 66


def _since(days: int) -> str:
    try:
        base = datetime.fromisoformat(clock.now())
    except Exception:
        base = datetime.now()
    return (base - timedelta(days=max(1, days))).isoformat(timespec="seconds")


def _title(ref: str) -> str:
    try:
        return entity.title(ref)
    except Exception:
        return ref


# ⭐⭐⭐ ЧОМУ ПІДРОЗДІЛ НЕ ЛЕЖИТЬ У ПРОТОКОЛІ (зміна 173, 14.08.2026).
# Андрій 14.08: «або фіксувати в протоколі всі поля кожної задачі (що не є
# ефективним та правильним), або навчити оркестратора читати кожну задачу».
# Він правий, і третього шляху шукати не треба — треба РОЗДІЛИТИ ШАРИ:
#   1) ПРОТОКОЛ  — кістяк ФАКТУ І ЧАСУ: хто · над ким · коли · чим скінчилось ·
#      звідки · скільки коштувало. Тільки ІДЕНТИЧНІСТЬ, жодних копій полів.
#   2) ДОВІДНИКИ — змінні ознаки (підрозділ, посада, керівник) приєднуються
#      САМЕ ТУТ, при читанні. Якби відділ лягав копією в рядок, переведення
#      людини змусило б увесь торішній журнал брехати заднім числом.
#   3) ЗМІСТ     — «задачі про постачальників», «про нестачі в магазинах» —
#      судження, яке візьме лише мозок. Але йому не треба читати тисячі задач:
#      протокол за період звітності звужує вибірку до десятків, і платити
#      доведеться саме за них. ⚠ Цей шар ЩЕ НЕ ЗБУДОВАНО — і поки задач мало,
#      будувати його рано. Тут він названий, щоб наступний не поліз копіювати
#      поля задач у журнал «бо аналітики бракує».
def _people():
    """Довідник людей: `person:emp-…` → (імʼя, підрозділ). Немає — не падаємо."""
    out = {}
    try:
        import taskdesk_people as people
        for e in people.employees():
            ref = entity.ref(entity.KIND_PERSON, e.get("id"))
            out[ref] = (_s(e.get("full_name")) or e.get("id"),
                        _s(e.get("unit_name")))
    except Exception:
        pass
    return out


def _s(v) -> str:
    return (v or "").strip() if isinstance(v, str) else ("" if v is None else str(v))


def _person_refs(row: dict) -> list:
    out = []
    for r in list(row.get("about") or []):
        if isinstance(r, str) and r.startswith(entity.KIND_PERSON + ":"):
            out.append(r)
    return out


def _party_refs(row: dict) -> list:
    out = []
    for r in [row.get("subject")] + list(row.get("about") or []):
        if isinstance(r, str) and r.startswith(entity.KIND_PARTY + ":"):
            out.append(r)
    return out


def build(days: int = 7, feed_n: int = 20) -> str:
    since = _since(days)
    rows = protocol.read(since=since)
    L = []
    add = L.append

    add(LINE)
    add("  ПРОТОКОЛ ПЛАТФОРМИ — звіт за останні %d дн." % days)
    add("  станом на %s" % clock.now().replace("T", " "))
    add(LINE)

    if not rows:
        add("")
        add("  За цей період у протоколі ЖОДНОГО рядка.")
        add("  Це не поломка: протокол починається з дня включення (13.08.2026),")
        add("  і поки платформа не працювала — писати нема чого.")
        add("")
        add("  Файл журналу: %s" % protocol._PATH)
        return "\n".join(L)

    add("")
    add("  Усього дій: %d   ·   з них із ціною: %d   ·   разом $%.4f"
        % (len(rows),
           sum(1 for r in rows if float(r.get("cost_usd") or 0) > 0),
           sum(float(r.get("cost_usd") or 0) for r in rows)))

    # ── 1. Звідки береться робота ────────────────────────────────────────────
    add("")
    add("-- 1. ЗВІДКИ БЕРЕТЬСЯ РОБОТА " + "-" * 37)
    src = OrderedDict((s, 0) for s in protocol.SOURCES)
    raw_examples = {}
    for r in rows:
        s = r.get("source") or ""
        if not s:
            continue
        src[s] = src.get(s, 0) + 1
        if r.get("source_raw"):
            raw_examples.setdefault(s, set()).add(r["source_raw"])
    named = [(s, n) for s, n in src.items() if n]
    if not named:
        add("   Джерело не назвав ЖОДЕН рядок — це прогалина, а не «нуль роботи».")
    for s, n in sorted(named, key=lambda x: -x[1]):
        tail = ""
        if raw_examples.get(s):
            tail = "   (%s)" % ", ".join(sorted(raw_examples[s])[:3])
        add("   %-22s %5d%s" % (protocol.SOURCE_NAMES.get(s, s), n, tail))
    no_src = sum(1 for r in rows if not r.get("source"))
    if no_src:
        add("   %-22s %5d   ← джерела не названо" % ("(не вказано)", no_src))

    # ── 2. По кому йде робота ────────────────────────────────────────────────
    add("")
    add("-- 2. ПО КОМУ ЙДЕ РОБОТА " + "-" * 41)
    by_party = OrderedDict()
    for r in rows:
        for p in set(_party_refs(r)):
            d = by_party.setdefault(p, {"дій": 0, "usd": 0.0, "проблем": 0})
            d["дій"] += 1
            d["usd"] += float(r.get("cost_usd") or 0)
            if r.get("outcome") != protocol.OUT_OK:
                d["проблем"] += 1
    if not by_party:
        add("   Жодна дія не привʼязана до контрагента.")
        add("   Найчастіша причина — картка ще не має номера в довіднику")
        add("   (кнопка «У базу» / `crm.ensure_parties()`).")
    for p, d in sorted(by_party.items(), key=lambda x: -x[1]["дій"]):
        add("   %-28s дій: %-4d проблем: %-3d $%.4f"
            % (_title(p)[:28], d["дій"], d["проблем"], d["usd"]))

    # ── 3. По людях: постановники й виконавці ────────────────────────────────
    # ⭐ ЗАРАДИ ЧОГО ЦЕ ЗРОБЛЕНО (слово Андрія 14.08.2026): «власник захоче
    # визначити, наскільки його топи впливають на операційний процес… якщо
    # керівник не ставить задачі, а керує тільки голосом, не фіксуючи
    # розпорядження, то й виконавська дисципліна не піддається виміру».
    # ⛒ Рахуємо ЛИШЕ те, що записано. Задачі, поставлені голосом, сюди не
    # потраплять ніколи — і це не дефект звіту, а рівно його суть.
    people = _people()

    def _name(ref):
        nm, unit = people.get(ref, ("", ""))
        nm = nm or _title(ref)
        return "%s (%s)" % (nm, unit) if unit else nm

    setters, doers = OrderedDict(), OrderedDict()
    for r in rows:
        act = r.get("action")
        who = _s(r.get("actor"))
        outc = _s(r.get("outcome")).partition(":")[0] or protocol.OUT_OK
        if act == protocol.A_TASK_CREATED and who:
            d = setters.setdefault(who, {"поставив": 0, "кому": set()})
            d["поставив"] += 1
            for pr in _person_refs(r):
                d["кому"].add(pr)
        if act in (protocol.A_TASK_CREATED, protocol.A_TASK_DONE,
                   protocol.A_TASK_OVERDUE, protocol.A_TASK_CHANGED):
            for pr in _person_refs(r):
                d = doers.setdefault(pr, {"дано": 0, "вчасно": 0, "пізно": 0,
                                          "прострочено": 0, "відмов": 0})
                if act == protocol.A_TASK_CREATED:
                    d["дано"] += 1
                elif act == protocol.A_TASK_DONE:
                    d["пізно" if outc == protocol.OUT_LATE else "вчасно"] += 1
                elif act == protocol.A_TASK_OVERDUE:
                    d["прострочено"] += 1
                elif outc == protocol.OUT_REFUSED:
                    d["відмов"] += 1

    add("")
    add("-- 3. ПО ЛЮДЯХ " + "-" * 51)
    add("   ХТО СТАВИТЬ ЗАДАЧІ (вплив керівника на операційний процес):")
    if not setters:
        add("      За період ЖОДНОЇ поставленої задачі.")
        add("      Це не «нічого не робили» — це «нічого не зафіксовано».")
    for ref, d in sorted(setters.items(), key=lambda x: -x[1]["поставив"]):
        add("      %-40s поставив: %-4d людям: %d"
            % (_name(ref)[:40], d["поставив"], len(d["кому"])))
    # 🩸 МЕЖУ ІСТОРІЇ НАЗИВАЄМО ВГОЛОС. Рядки, записані ДО 14.08.2026, виконавця
    # не називали взагалі — його тоді просто не писали. Якщо про це змовчати,
    # «поставив: 3 · людям: 1» читається як робота одного виконавця, і
    # дисципліна виглядає меншою, ніж була. Мовчазна прогалина в журналі —
    # брехня на користь платформи.
    nameless = sum(1 for r in rows
                   if r.get("action") == protocol.A_TASK_CREATED
                   and not _person_refs(r))
    if nameless:
        add("      ⚠ %d з них не назвали виконавця (записи до 14.08.2026) —"
            % nameless)
        add("        у дисципліну нижче вони НЕ входять.")

    add("")
    add("   КОМУ ВОНИ ДІСТАЮТЬСЯ (виконавська дисципліна):")
    if not doers:
        add("      Жодна задача не назвала виконавця.")
    for ref, d in sorted(doers.items(), key=lambda x: -x[1]["дано"]):
        closed = d["вчасно"] + d["пізно"]
        pct = ("%d%%" % round(100.0 * d["вчасно"] / closed)) if closed else "—"
        add("      %-40s дано: %-4d закрито: %-4d вчасно: %-5s"
            % (_name(ref)[:40], d["дано"], closed, pct))
        if d["прострочено"] or d["відмов"] or d["пізно"]:
            add("         %s"
                % " · ".join(filter(None, [
                    ("із запізненням: %d" % d["пізно"]) if d["пізно"] else "",
                    ("строк минув: %d" % d["прострочено"]) if d["прострочено"] else "",
                    ("відмов: %d" % d["відмов"]) if d["відмов"] else ""])))
    add("   ⚠ Відсоток рахується від ЗАКРИТИХ задач періоду. Задачі без строку")
    add("     теж рахуються вчасними — строку в них порушувати нічого.")

    # ── 4. Де гальмує ────────────────────────────────────────────────────────
    add("")
    add("-- 4. ДЕ ГАЛЬМУЄ (відмови й поломки, причина словами) " + "-" * 12)
    bad = [r for r in rows
           if _s(r.get("outcome")).partition(":")[0] not in (protocol.OUT_OK,
                                                             protocol.OUT_LATE)]
    if not bad:
        add("   Жодної відмови й поломки за період.")
    for r in bad[-25:]:
        add("   %s  %-16s %s"
            % (str(r.get("at", ""))[5:16].replace("T", " "),
               protocol.OUTCOME_NAMES.get(r.get("outcome"), r.get("outcome")),
               _title(r.get("subject", ""))[:26]))
        reason = (r.get("reason") or "").strip()
        if reason:
            add("        причина: %s" % reason[:150])
    if len(bad) > 25:
        add("   ... і ще %d раніше (показано останні 25)." % (len(bad) - 25))

    # ── 5. Скільки коштує ────────────────────────────────────────────────────
    add("")
    add("-- 5. СКІЛЬКИ КОШТУЄ " + "-" * 45)
    money = [r for r in rows if float(r.get("cost_usd") or 0) > 0]
    if not money:
        add("   Платної роботи за період не було.")
    else:
        add("   Кроків із витратами: %d   ·   разом $%.4f"
            % (len(money), sum(float(r["cost_usd"]) for r in money)))
        add("   Найдорожчі кроки:")
        for r in sorted(money, key=lambda x: -float(x["cost_usd"]))[:10]:
            add("     $%-9.4f %s  %s"
                % (float(r["cost_usd"]), str(r.get("at", ""))[5:16].replace("T", " "),
                   _title(r.get("subject", ""))[:30]))
    add("   ⚠ Це ціна роботи, привʼязаної до прогону/задачі/контрагента.")
    add("     Повний добовий рахунок веде costs.py, не протокол.")

    # ── 6. Стрічка подій ─────────────────────────────────────────────────────
    # 🩸 КОРІНЬ (14.08.2026): Андрій написав боту, задача створилась, рядок ліг
    # у журнал із джерелом «телеграм» — і він чесно сказав «в протоколі не
    # побачив». Бо звіт показував самі ЛІЧИЛЬНИКИ: подію можна було побачити
    # ЛИШЕ якщо вона ПОЛАМАЛАСЬ. Журнал, у якому не видно вдалих дій, — це не
    # журнал, а зведення аварій. ⛒ Екран протоколу він зняв (13.08), тому цей
    # звіт — ЄДИНІ двері, і вони мусять показувати сам журнал.
    add("")
    add("-- 6. ОСТАННІ ДІЇ (сам журнал, рядок за рядком) " + "-" * 18)
    feed = rows[-int(feed_n):] if feed_n else []
    if not feed:
        add("   Показ стрічки вимкнено (--feed 0).")
    for r in feed:
        outc = _s(r.get("outcome")).partition(":")[0] or protocol.OUT_OK
        mark = " " if outc == protocol.OUT_OK else "!"
        who = _s(r.get("actor"))
        add("  %s %s  %-26s %s"
            % (mark, str(r.get("at", ""))[5:16].replace("T", " "),
               protocol.ACTIONS.get(r.get("action"), r.get("action"))[:26],
               _title(_s(r.get("subject")))[:30]))
        tail = " · ".join(filter(None, [
            ("хто: %s" % _name(who)) if who else "хто: (машина)",
            ("кому: %s" % ", ".join(_name(x) for x in _person_refs(r)))
            if _person_refs(r) else "",
            ("звідки: %s" % protocol.SOURCE_NAMES.get(_s(r.get("source")),
                                                      _s(r.get("source"))))
            if _s(r.get("source")) else "",
            ("підсумок: %s" % protocol.OUTCOME_NAMES.get(outc, outc))
            if outc != protocol.OUT_OK else ""]))
        add("      %s" % tail)
        note = _s(r.get("note"))
        if note:
            add("      «%s»" % note[:90])
    if feed_n and len(rows) > len(feed):
        add("   ... і ще %d рядків раніше (показано останні %d, --feed N змінює)."
            % (len(rows) - len(feed), len(feed)))

    # ── 7. Що протокол ВІДХИЛИВ ──────────────────────────────────────────────
    fails = protocol.failures(30)
    add("")
    add("-- 7. ВІДХИЛЕНІ РЯДКИ (мовчазних втрат немає) " + "-" * 20)
    if not fails:
        add("   Жодного відхиленого рядка.")
    else:
        add("   ⚠ %d рядків не потрапили в протокол. Це не «дрібниця»: журнал із"
            % len(fails))
        add("     прогалиною бреше на користь платформи. Причини:")
        seen = []
        for f in fails:
            why = (f.get("reason") or "")[:110]
            if why not in seen:
                seen.append(why)
        for why in seen[:8]:
            add("       · %s" % why)

    add("")
    add(LINE)
    add("  Файл журналу:  %s" % protocol._PATH)
    add("  Файл невдач:   %s" % protocol._FAIL_PATH)
    add(LINE)
    return "\n".join(L)


def main(argv) -> int:
    days = 7
    feed_n = 20
    to_file = False
    for i, a in enumerate(argv):
        if a == "--days" and i + 1 < len(argv):
            try:
                days = int(argv[i + 1])
            except Exception:
                pass
        if a == "--feed" and i + 1 < len(argv):
            try:
                feed_n = max(0, int(argv[i + 1]))
            except Exception:
                pass
        if a == "--file":
            to_file = True
    text = build(days, feed_n)
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    print(text)
    if to_file:
        out = config.STATE_DIR / "state" / "protocol_report.txt"
        try:
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(text, encoding="utf-8")
            print("\nЗвіт збережено: %s" % out)
        except Exception as e:
            print("\nЗвіт не збережено: %s" % e)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
