# -*- coding: utf-8 -*-
"""source_intake.py — ПРИЙОМ ДЖЕРЕЛА: людина вказала — платформа пішла і взяла.

⭐⭐⭐ ЖИВИЙ ВИПАДОК 04.08.2026. Клієнт надіслав посилання на картку закупівлі й
попросив підстави для скарги. Платформа не зробила НІЧОГО: посилання для неї
було просто адресою, а робота, яка вміє взяти картку і документи з Прозорро,
чекала, поки її покличуть на імʼя з номером у параметрі. Андрій: «чому
оркестратор не пройшов по посиланню, не витягнув документи і не організував
юридичний аналіз».

ЗВІДКИ ЦЕЙ КРОК СТОЇТЬ ПЕРЕД МОЗКОМ, А НЕ В ПРОМПТІ.
    Прохання до моделі «якщо бачиш номер — поклич роботу» — це прохання, а не
    ворота: воно провалюється рівно тоді, коли модель поспішає. Тому матеріал
    береться ДЕТЕРМІНОВАНО, до того як мозок почав обирати систему. Мозок
    отримує задачу вже З ДОКУМЕНТАМИ на руках і думає про суть, а не про те,
    яку роботу викликати першою.

ЩО САМЕ РОБИТЬ.
    Знаходить у задачі номер закупівлі (у тексті або всередині посилання на
    БУДЬ-ЯКИЙ майданчик — назв майданчиків ми свідомо не вчимо), іде до
    ПЕРШОДЖЕРЕЛА (Прозорро) і кладе картку та документи замовника в матеріали
    задачі. Прогін безкоштовний: модель тут не питається жодного разу.

ЧОГО НЕ РОБИТЬ.
    Не тлумачить документи, не робить висновків, не обирає систему. Не мовчить
    при невдачі: якщо джерело не відповіло — так і пише в матеріалах, щоб
    система не вирішила, ніби документів просто не існує.
"""
import tender_ref

MAX_FILES = 12
# ⭐⭐⭐ 10.08.2026, зміна 143. СВОЄЇ СТЕЛІ ТУТ БІЛЬШЕ НЕМАЄ.
# Раніше тут стояло `MAX_CHARS = 60000`, і `collect()` різав зібраний
# матеріал голим `out[:MAX_CHARS]`. Живий прогін показав ціну: оголошення
# (34 768 знаків) плюс проєкт договору зʼїдали стелю, і Додаток №2 із
# пʼятьма обовʼязковими документами зникав МОВЧКИ. Бюджет і чесний виріз
# тепер тримає ОДИН писар — `tender_docs.material_blocks`.

HEADER = "## ДЖЕРЕЛО, ВЗЯТЕ ПЛАТФОРМОЮ ЗА ВКАЗІВКОЮ ЛЮДИНИ"

# ⭐⭐⭐ 17.08.2026, зміна 194. НЕПРОЧИТАНИЙ ФАЙЛ — ЦЕ ФАКТ, А НЕ ПРОХАННЯ.
# 🩸 Платформа ЗНАЛА, що не прочитала `Тендерна документація_з 01_07.doc`:
# `read_docs` віддає `skipped` і `complete=False`, і ми чесно писали про це в
# матеріалі. Але далі цей факт жив ЛИШЕ ТЕКСТОМ ДЛЯ МОДЕЛІ — «не видавай перелік
# вимог за вичерпний». Ворота пакета його не бачили, і перший рядок документа
# все одно обіцяв «складено за переліком обовʼязкових документів замовника».
# 17.08 нас урятувало те, що модель виявилась сумлінною і сама написала про
# прогалину. Обіцянка, яку тримає сумлінність моделі, — це не обіцянка.
# ⛒ Тому поряд із людським текстом кладемо МІТКУ ДЛЯ КОДУ. Писар і читач мітки —
# ОДИН модуль (цей), щоб форма не розійшлась між двома руками.
_GAP_MARK = "<!-- SF-НЕ-ПРОЧИТАНО: "
_GAP_END = " -->"


def gap_line(what: str) -> str:
    """Машинна мітка про непрочитаний файл — один писар."""
    return _GAP_MARK + str(what or "").replace("\n", " ").replace("-->", "→") + _GAP_END


def gaps_in(material: str) -> list:
    """Непрочитані файли з матеріалу — один читач. -> [рядок опису]."""
    out, text = [], str(material or "")
    at = text.find(_GAP_MARK)
    while at >= 0:
        end = text.find(_GAP_END, at + len(_GAP_MARK))
        if end < 0:
            break
        got = text[at + len(_GAP_MARK):end].strip()
        if got and got not in out:
            out.append(got)
        at = text.find(_GAP_MARK, end)
    return out


def refs_in(message, files_context="") -> list:
    """Номери закупівель, на які вказала людина. Порядок збережено."""
    return tender_ref.find_all("%s\n%s" % (message or "", files_context or ""))


def fetch_tender(tid: str, max_files: int = MAX_FILES, budget: int = 0) -> dict:
    """Картка + документи замовника з Прозорро. -> {ok, tender_id, text, note}."""
    tid = tender_ref.normalize(tid)
    if not tid:
        return {"ok": False, "tender_id": "", "text": "", "note": "не схоже на номер закупівлі"}
    try:
        import tender_docs
    except Exception as e:
        return {"ok": False, "tender_id": tid, "text": "",
                "note": "модуль читання документації недоступний (%s)" % type(e).__name__}
    # ⭐ ЗУПИНКА НАЗИВАЄ СВОЮ ПРИЧИНУ. Брак писаря матеріалу — окремий діагноз,
    # а не «модуль недоступний»: інакше шукали б збій там, де його немає.
    if not hasattr(tender_docs, "material_blocks"):
        return {"ok": False, "tender_id": tid, "text": "",
                "note": "у складнику читання документації немає писаря матеріалу "
                        "(tender_docs.material_blocks) — це наш збій, а не брак документів"}
    budget = int(budget or 0) or getattr(tender_docs, "MATERIAL_BUDGET", 120000)
    try:
        res = tender_docs.read_docs(tid, max_files=max_files)
    except Exception as e:
        return {"ok": False, "tender_id": tid, "text": "",
                "note": "джерело не відповіло (%s: %s)" % (type(e).__name__, e)}
    if not isinstance(res, dict) or not res.get("ok"):
        note = (res or {}).get("reason") or "джерело не віддало картку"
        return {"ok": False, "tender_id": tid, "text": "", "note": str(note)}

    # ОДИН ПИСАР МАТЕРІАЛУ: бюджет і виріз — у tender_docs.material_blocks.
    _mat, _cut_notes = tender_docs.material_blocks(res.get("files") or [], budget)
    skipped = res.get("skipped") or []
    gaps = []
    for sk in skipped:
        if isinstance(sk, dict):
            gaps.append("%s — %s" % (sk.get("title") or "документ",
                                     sk.get("why") or "причина невідома"))
    signs = [str((sg or {}).get("title") or "підпис")
             for sg in (res.get("signatures") or []) if isinstance(sg, dict)]
    return {"ok": True, "tender_id": tid, "uuid": res.get("uuid") or "",
            "text": _mat, "files": len(res.get("files") or []),
            "skipped": len(skipped), "gaps": gaps + list(_cut_notes),
            "signatures": signs,
            "complete": bool(res.get("complete", True)) and not _cut_notes, "note": ""}


def collect(message, files_context="", max_refs: int = 2) -> str:
    """Матеріал для задачі або "" якщо вказівок на джерело немає.

    Невдача НЕ мовчить: вона потрапляє в матеріал окремим рядком, щоб система
    бачила межу свого знання, а не вважала, що документів не існує.
    """
    refs = refs_in(message, files_context)[:max_refs]
    if not refs:
        return ""
    blocks = []
    # Бюджет ділиться між закупівлями, на які показала людина, — щоб друга не
    # зʼїла першу. Стелю тримає ОДИН писар (tender_docs), своєї тут немає.
    try:
        import tender_docs as _td
        _budget = _td.MATERIAL_BUDGET // max(1, len(refs))
    except Exception:
        _budget = 0
    for tid in refs:
        got = fetch_tender(tid, budget=_budget)
        if got.get("ok"):
            head = ("Закупівля %s — картка і документація замовника, взяті з Прозорро "
                    "(першоджерело) під час цього запиту. Файлів прочитано: %d."
                    % (got["tender_id"], got.get("files", 0)))
            # ⭐ ЧОГО САМЕ МИ НЕ БАЧИЛИ — НАЗВАТИ ПОІМЕННО.
            # Для правового висновку «прочитано 2 з 3» без назви третього — це
            # прихована діра: юрист не знає, про що мовчить, і клієнт теж.
            if not got.get("complete", True) or got.get("skipped"):
                _gaps = list(got.get("gaps") or []) or ["(назви невідомі)"]
                head += ("\n\nУВАГА, ЦЕ НЕ ВСЯ ДОКУМЕНТАЦІЯ. Не прочитано файлів: %d. "
                         "Про їхній зміст висновків робити НЕ МОЖНА, і в результаті це "
                         "треба сказати людині прямо:\n%s"
                         % (got.get("skipped", 0),
                            "\n".join("  • " + g for g in _gaps)))
                # ⛒ І ТОЙ САМИЙ ФАКТ — МІТКОЮ ДЛЯ КОДУ, а не лише прозою для мозку.
                head += "\n" + "\n".join(gap_line(g) for g in _gaps)
            body = got.get("text") or "(перелік файлів порожній: замовник не додав документів)"
            blocks.append("%s\n\n%s" % (head, body))
        else:
            blocks.append("Закупівля %s: документи взяти НЕ ВДАЛОСЯ — %s. "
                          "Це межа знання, а не відсутність документів: висновків про "
                          "їх зміст робити не можна.\n%s"
                          % (tid, got.get("note") or "причина невідома",
                             gap_line("уся документація закупівлі %s — %s"
                                      % (tid, got.get("note") or "джерело не відповіло"))))
    # ⛔ ГОЛОГО ЗРІЗУ ТУТ БІЛЬШЕ НЕМАЄ. Бюджет уже витриманий вище, а кожен виріз
    # назвав себе — і в тексті, і в застереженнях.
    return "%s\n\n%s" % (HEADER, "\n\n---\n\n".join(blocks))
