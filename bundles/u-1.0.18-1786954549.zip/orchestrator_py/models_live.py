# -*- coding: utf-8 -*-
"""models_live.py — ЯКI МОДЕЛI Є В ПРОВАЙДЕРА НАСПРАВДI (один писар).

⭐⭐⭐ КОРIНЬ 10.08.2026 (змiна 148). СЛОВО АНДРIЯ: «зашита назва моделi — це
закладена мiна». 10.08 вона вибухнула: Google зняв `gemini-2.5-flash` для НОВИХ
ключiв. У власника ключ старий — усе працює; у клiєнта ключ новий — на КОЖНОМУ
кроцi 404. З машини власника дефекту не видно взагалi.

Змiна 146 полiкувала НАСЛIДОК: знята модель вибуває з драбини пiсля першої
помилки. Але це лiкування ПIСЛЯ факту — клiєнт уже побачив помилку.
Тут лiкуємо ПРИЧИНУ: перелiк моделей називає ПРОВАЙДЕР, а не наш код.

ТРИ ПРАВИЛА, НА ЯКИХ ЦЕ СТОЇТЬ.
  1. ХТО НАЗИВАЄ. Iм'я моделi не можна вгадати з голови: «claude-opus-5» чи
     «claude-opus-5-20260501» — рiзнi рядки, i хибний дає помилку посеред
     роботи клiєнта. Називає провайдер, безкоштовним викликом (токени не
     витрачаються, бо модель не працює).
  2. ЩО ВИБИРАЄМО. Не iм'я, а РОЛЬ: дешевий виконавець / надiйний / мозок.
     Ранг дає РОДИНА (haiku < sonnet < opus; flash-lite < flash < pro), а
     свiжiсть — числа у назвi. Тому модель, якої на день написання цього коду
     ЩЕ НЕ IСНУЄ, буде обрана правильно, щойно провайдер її вiддасть.
  3. ЯК ПАДАЄМО. Не спитали (немає ключа, мережi, квоти) — працюємо як ранiше,
     на запасних пiдказках `config.MODEL_SUGGESTIONS`. Тут fail-open свiдомий:
     краще стара драбина, нiж жодної. А ось «знята модель» — fail-closed:
     що позначене знятим, не береться нiколи.

⚠ ГРОШI Й ЧАС. Вiдповiдь провайдера кешується на диску (`models_live.json`) на
добу, тож у мережу ходимо щонайбiльше раз на день на провайдера, з коротким
таймаутом. Гарячий шлях кроку в мережу за цим не ходить.

⚠ ЧЕСНА МЕЖА. Порожнiй список НIКОЛИ не тлумачиться як «у провайдера нiчого
немає» — лише як «ми не спитали». Саме тому порожнеча веде до запасних пiдказок,
а не до вимкнення провайдера.
"""

import json
import re
import threading
import time
import urllib.error
import urllib.request
from pathlib import Path

import config

TTL_SECONDS = 24 * 3600
TIMEOUT = 8

_LOCK = threading.RLock()
_MEM = {}                     # памʼять процесу: {провайдер: (час, [моделi])}


def _store() -> Path:
    """Кеш живого перелiку — у ТЕЦI СТАНУ, а не в бойовiй: чек не смiє смiтити
    туди, де живе продукт (`SENSFLOW_STATE_DIR`)."""
    return Path(getattr(config, "STATE_DIR", config.ENGINE_DIR)) / "models_live.json"


# ── ЩО ПИТАЄМО В ПРОВАЙДЕРА ───────────────────────────────────────────────
def _get_json(url: str, headers: dict):
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
            return json.loads(resp.read().decode("utf-8")), None
    except urllib.error.HTTPError as e:
        return None, "HTTP %s" % e.code
    except Exception as e:                               # noqa: BLE001
        return None, "%s" % type(e).__name__


def _ask_anthropic():
    if not config.ANTHROPIC_API_KEY:
        return None, "немає ключа"
    d, err = _get_json("https://api.anthropic.com/v1/models?limit=100",
                       {"x-api-key": config.ANTHROPIC_API_KEY,
                        "anthropic-version": "2023-06-01"})
    if err:
        return None, err
    return [m.get("id", "") for m in (d.get("data") or []) if m.get("id")], None


def _ask_openai():
    if not config.OPENAI_API_KEY:
        return None, "немає ключа"
    d, err = _get_json("https://api.openai.com/v1/models",
                       {"Authorization": "Bearer %s" % config.OPENAI_API_KEY})
    if err:
        return None, err
    return [m.get("id", "") for m in (d.get("data") or []) if m.get("id")], None


def _ask_gemini():
    if not config.GEMINI_API_KEY:
        return None, "немає ключа"
    d, err = _get_json(
        "https://generativelanguage.googleapis.com/v1beta/models?key=%s&pageSize=200"
        % config.GEMINI_API_KEY, {})
    if err:
        return None, err
    out = []
    for m in (d.get("models") or []):
        name = (m.get("name") or "").split("/")[-1]
        methods = m.get("supportedGenerationMethods") or []
        if name and ("generateContent" in methods or not methods):
            out.append(name)
    return out, None


ASKERS = {"anthropic": _ask_anthropic, "openai": _ask_openai, "gemini": _ask_gemini}


# ── КЕШ НА ДИСКУ ──────────────────────────────────────────────────────────
def _read_cache() -> dict:
    with _LOCK:
        try:
            d = json.loads(_store().read_text(encoding="utf-8"))
            return d if isinstance(d, dict) else {}
        except Exception:                                # noqa: BLE001
            return {}


def _write_cache(prov: str, models: list):
    with _LOCK:
        d = _read_cache()
        d[prov] = {"at": time.time(), "models": list(models)}
        try:
            _store().parent.mkdir(parents=True, exist_ok=True)
            _store().write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
        except Exception:                                # noqa: BLE001
            pass          # не змогли зберегти — наступного разу просто спитаємо знову


def forget_cache():
    """Лише для проб і для кнопки «перепитати провайдера»."""
    with _LOCK:
        _MEM.clear()
        try:
            _store().unlink()
        except Exception:                                # noqa: BLE001
            pass


def available(provider: str, refresh: bool = False) -> list:
    """Живий перелiк моделей провайдера. ПОРОЖНЬО = «не спитали», не «немає»."""
    prov = (provider or "").strip().lower()
    if prov not in ASKERS:
        return []
    now = time.time()
    if not refresh:
        hit = _MEM.get(prov)
        if hit and now - hit[0] < TTL_SECONDS:
            return list(hit[1])
        disk = _read_cache().get(prov) or {}
        try:
            if now - float(disk.get("at", 0)) < TTL_SECONDS and disk.get("models"):
                _MEM[prov] = (float(disk["at"]), list(disk["models"]))
                return list(disk["models"])
        except Exception:                                # noqa: BLE001
            pass
    models, err = ASKERS[prov]()
    if err or not models:
        return []                                        # «не спитали» — не «немає»
    _MEM[prov] = (now, list(models))
    _write_cache(prov, models)
    return list(models)


# ── РАНГ I СВIЖIСТЬ: ОЗНАКИ, А НЕ IМЕНА ───────────────────────────────────
# Ранг 1 — дешевий/швидкий, 2 — робочий, 3 — найсильнiший. Тут навмисно НЕМАЄ
# жодного повного iменi моделi: лише ознаки РОДИНИ, якi провайдери тримають
# роками, тодi як версiї змiнюються щомiсяця.
# ⭐⭐⭐ 11.08.2026. `fable` додано за фактом ВІД ВЛАСНИКА: це найпотужнiша й
# найдорожча модель Anthropic, дорожча за Opus. Доти вона мовчки падала в
# `_DEFAULT_RANK = 2` — i платформа пiдписувала найдорожчу модель словами
# «баланс: розумна i помiтно дешевша». Брехня про грошi, показана клiєнтовi.
_RANK_HINTS = {
    "anthropic": ((("haiku",), 1), (("sonnet",), 2), (("opus", "fable"), 3)),
    "gemini":    ((("flash-lite", "flash-8b", "-lite"), 1), (("flash",), 2),
                  (("pro", "ultra"), 3)),
    "openai":    ((("mini", "nano"), 1), (("-pro", "reasoning"), 3)),
    "moonshot":  ((("highspeed", "turbo", "flash"), 1), (("code",), 2)),
}
_DEFAULT_RANK = 2

# Чернетки провайдера: зникають без попередження, клiєнту такого не даємо.
_DRAFT = ("preview", "-exp", "experimental", "-latest-preview", "beta")
# Не текстовi моделi: вбудування, мова, зображення, вiдео, аудiо.
_NOT_CHAT = ("embed", "embedding", "tts", "whisper", "dall-e", "image", "imagen",
             "veo", "audio", "vision-only", "moderation", "rerank", "aqa",
             "transcribe", "realtime", "search-preview", "computer-use")

_NUM = re.compile(r"\d+(?:\.\d+)?")


def version_of(name: str) -> tuple:
    """Свiжiсть моделi за числами в назвi. Бiльший кортеж — новiша модель."""
    return tuple(float(x) for x in _NUM.findall(str(name or "")))


def known_rank(name: str, provider: str = ""):
    """Ранг, ЯКЩО МИ СПРАВДI ЗНАЄМО ЦЮ РОДИНУ. Iнакше None.

    ⭐⭐⭐ 11.08.2026, знайшов Андрiй. `rank_of` вiддавав `_DEFAULT_RANK = 2` i
    для родин, про якi не знає нiчого, — а екран перетворював це число на
    ЗАЯВУ «баланс: розумна i помiтно дешевша». Так найдорожча модель Anthropic
    отримала пiдпис «дешевша».
    🔥 КЛАС: **мовчазна стала, яка робить обiцянку про грошi.** Незнання не смiє
    вдягатись у впевнене твердження. Для ПОРЯДКУ стала годиться (треба ж кудись
    поставити), для ЗАЯВИ людинi — нi. Тому писарiв двоє й вони рiзнi."""
    n = str(name or "").lower()
    prov = (provider or config.provider_for_model(name) or "").lower()
    for words, rank in _RANK_HINTS.get(prov, ()):
        for w in words:
            if w in n:
                return rank
    return None


def rank_of(name: str, provider: str = "") -> int:
    """Ранг моделi за РОДИНОЮ (1 дешева / 2 робоча / 3 найсильнiша).
    Не знаємо родини — беремо середнє, але ЛИШЕ для порядку в списку;
    що казати людинi, вирiшує `known_rank`."""
    r = known_rank(name, provider)
    return _DEFAULT_RANK if r is None else r


def is_usable(name: str) -> bool:
    """Чи можна взагалi пропонувати цю модель клiєнту."""
    n = str(name or "").lower()
    if not n:
        return False
    if any(w in n for w in _DRAFT) or any(w in n for w in _NOT_CHAT):
        return False
    try:
        import llm as _llm
        if _llm.model_is_gone(name):                     # fail-closed: знята — нiколи
            return False
    except Exception:                                    # noqa: BLE001
        pass
    return True


_ROLE_RANK = {"cheap": 1, "worker": 1, "reliable": 2, "brain": 3}


# ── ПЕРЕЛIК ДЛЯ ЕКРАНА: ОДИН ПИСАР ────────────────────────────────────────
# ⭐⭐⭐ 11.08.2026 (змiна 149). Знайшов АНДРIЙ, дивлячись на власний екран: у
# вiкнi вибору моделi мозку не було `claude-opus-5`, хоча ключ його бачить.
# Драбина знала, бо питала провайдера; ЕКРАН читав `config.MODEL_SUGGESTIONS` —
# рядок, вписаний рукою. **Два писарi однiєї правди, i клiєнту показувався той,
# що застряг у минулому.** Тепер перелiк для екрана — тут, поруч iз тим, хто
# питає провайдера. `config.MODEL_SUGGESTIONS` лишається ЗАПАСНИМ (fail-open:
# немає ключа чи мережi — працюємо як ранiше, а не показуємо порожнечу).
SUGGEST_LIMIT = 12


def suggestions(providers=None) -> dict:
    """{провайдер: [моделi]} для вiкна вибору. Живий перелiк провайдера,
    впорядкований ВIД НАЙСИЛЬНIШОЇ РОДИНИ ДО НАЙДЕШЕВШОЇ, всерединi родини —
    вiд найсвiжiшої. Чернетки й не-текстовi моделi вiдсiяно тим самим суддею,
    що й для драбини (`is_usable`).

    ⚠ Мережу тут НЕ смикаємо зайвий раз: `available()` бере кеш (доба), а грiє
    його старт сервера. Екран опитує стан часто — платити за це не можна."""
    out = {}
    provs = list(providers or config.MODEL_SUGGESTIONS.keys())
    for prov in provs:
        live = [m for m in (available(prov) or []) if is_usable(m)]
        if live:
            # Порядок: родина -> НЕ вiдкинуте власником -> свiжiсть.
            # Вiдкинуту (напр. `fable`) лишаємо ВИДИМОЮ i чесно пiдписаною, але
            # не першою: перший рядок списку — те, куди зiсковзує рука.
            live = sorted(set(live),
                          key=lambda m: (rank_of(m, prov),
                                         0 if config.is_avoided(m) else 1,
                                         version_of(m), -len(m)),
                          reverse=True)
            out[prov] = live[:SUGGEST_LIMIT]
            continue
        # FAIL-OPEN: не спитали — вiддаємо запаснi пiдказки, як було до 11.08.
        out[prov] = [m for m in (config.MODEL_SUGGESTIONS.get(prov) or []) if is_usable(m)]
    return out


def ranks_for(sug: dict) -> dict:
    """{модель: ранг} для КОЖНОЇ запропонованої моделi. Екран малює пiдказку
    («найсильнiша / баланс / найдешевша») за РАНГОМ, а не за iменем: iнакше
    нова модель провайдера лишається без опису — саме так i було до 11.08."""
    out = {}
    for prov, models in (sug or {}).items():
        for m in models or []:
            r = known_rank(m, prov)
            out[m] = 0 if r is None else r   # 0 = «родини не знаємо, ціни не обіцяємо»
    return out


def pick(role: str, provider: str) -> str:
    """Модель провайдера пiд РОЛЬ. Порожньо — не змогли обрати нiчого.

    Порядок пошуку: точний ранг ролi -> сусiднi ранги (для дешевої вгору, для
    мозку вниз) -> запаснi пiдказки `config.MODEL_SUGGESTIONS`.
    """
    prov = (provider or "").strip().lower()
    want = _ROLE_RANK.get((role or "").strip().lower(), 2)
    live = [m for m in available(prov) if is_usable(m) and not config.is_avoided(m)]
    if live:
        order = sorted(range(1, 4), key=lambda r: (abs(r - want), -(r - want) if want == 3 else (r - want)))
        for r in order:
            same = [m for m in live if rank_of(m, prov) == r]
            if same:
                return sorted(same, key=lambda m: (version_of(m), len(m)), reverse=True)[0]
    # FAIL-OPEN: живого списку немає — працюємо як ранiше, на запасних пiдказках.
    fallback = [m for m in (config.MODEL_SUGGESTIONS.get(prov) or [])
                if is_usable(m) and not config.is_avoided(m)]
    if not fallback:
        return ""
    same = [m for m in fallback if rank_of(m, prov) == want]
    return (same or fallback)[0]
