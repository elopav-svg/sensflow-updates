"""
engine.py — тонкий шар над агентним оркестратором.

Уся логіка рішень тепер у agent.py (LLM на tool-calling). Тут лише точка входу
для сервера й виклик для планувальника. Жодних статус-switch чи pending —
підтвердження й уточнення веде сама модель у діалозі.
"""

import agent
import costs


def handle_message(actor, message: str, history=None, files_context: str = "",
                   pending=None, confirm=None, emit=None, should_cancel=None,
                   project_context: str = "", egress_allowed: bool = False,
                   understanding_client=None, can_ask: bool = False) -> dict:
    """Головна точка входу для чату.
    pending/confirm — відповідь людини на КАРТКУ РОЗУМІННЯ (11.08.2026, зміна 152).
    ⚠ Раніше ці два поля тут МОВЧКИ ГУБИЛИСЬ («більше не потрібні»), і канал не
    мав як донести рішення людини до воріт. Тепер вони доїжджають до мозку.
    understanding_client — поправка людини, що живе весь чат.
    can_ask — чи вміє канал показати картку з кнопками.
    should_cancel — callable() -> bool для кооперативного переривання («Стоп»).
    project_context — спільний контекст проєкту, якщо чат належить проєкту.
    egress_allowed — користувач явно дозволив разовий вихід назовні (режим
    максимального збереження): пропускаємо картку згоди й виконуємо дозволену дію.
    actor — ХТО ДІЄ (крок 1.5). Обовʼязковий: канал, який не назве людину, не
    отримає роботи. Відповідь на це питання дає ОДИН писар —
    `taskdesk_identity.resolve_actor`, а не кожен канал сам."""
    with costs.run_scope("chat", costs.KIND_CHAT) as scope:
        res = agent.run(actor, message, history=history or [], files_context=files_context or "",
                        emit=emit, should_cancel=should_cancel,
                        project_context=project_context or "",
                        egress_allowed=bool(egress_allowed),
                        pending=pending, confirm=confirm,
                        understanding_client=understanding_client, can_ask=bool(can_ask))
    # Вартість цього прогону (оцінка) + накопичена сесія — для показу в консолі.
    try:
        run_cost = scope.result
        sess = costs.session()
        res["cost"] = {"run_usd": round(run_cost["usd"], 4), "run_calls": run_cost["calls"],
                       "session_usd": round(sess["usd"], 4), "session_calls": sess["calls"]}
    except Exception:
        pass
    return res


def automation_runner(task: str, target_system_id, owner_account_id) -> dict:
    """Викликається планувальником: агент сам визначає й виконує задачу.

    ⭐⭐⭐ 29.07.2026. ТУТ ЖИЛА ДІРКА В ГРОШАХ. Ця функція кликала `agent.run`
    напряму, без лічильника — а отже без стелі: `spent_usd()` завжди повертав 0,
    і ні мʼяка пауза, ні аварійна межа спрацювати не могли. Клієнт міг створити
    автоматизацію й платити без обмеження. Корінь був не в забутому рядку, а в
    тому, що лічильник заводив ВИКЛИКАЧ; тепер пара «відкрив–закрив» — одна річ
    (`costs.run_scope`), а канал без лічильника ловить вартовий у `llm`.

    Прогін позначено як БЕЗПІЛОТНИЙ (`KIND_AUTOMATION`) — лише його гроші йдуть у
    добовий рахунок. Питання людини в чаті денною межею не блокуються ніколи."""
    # ⭐⭐⭐ ВОРОТА 3 «ВІД КОГО ЙДЕ РОЗКЛАД» (крок 1.5, 06.08.2026).
    # Безпілотна задача виконується від ВЛАСНИКА ЗАДАЧІ, а не «від платформи».
    import taskdesk_identity as _tdid
    actor, _note = _tdid.actor_for_automation(owner_account_id)
    if actor is None:
        return {"status": "honest_stop",
                "summary": ("Задачу не виконано: %s. Відкрийте задачу й призначте "
                            "власника — платформа не працює від нікого." % _note),
                "final_markdown": ""}
    if _note:
        try:
            import llm as _llm
            _llm._log("[scheduler] %s" % _note)
        except Exception:
            pass

    hint = task
    if target_system_id:
        hint = f"{task}\n\n(Виконай це через систему «{target_system_id}».)"
    # Денна межа питається ДО прогону: якщо вона вже вибрана, безпілотну задачу
    # не варто навіть починати — це був би платний крок заради відмови.
    if costs.over_day_cap():
        d = costs.day_report()
        return {"status": "stopped_budget",
                "summary": ("**Автоматизації зупинено за денною межею вартості.** "
                            "За добу витрачено $%.2f при межі $%.2f. Це не поломка — "
                            "це запобіжник ваших грошей. Завтра задача запрацює знову; "
                            "підняти межу можна рядком MAX_DAY_USD у файлі .env.local."
                            % (d.get("usd", 0.0), d.get("cap", 0.0))),
                "client_safe": True}
    with costs.run_scope("automation", costs.KIND_AUTOMATION) as scope:
        try:
            res = agent.run(actor, hint, history=[], files_context="", emit=None)
        except Exception as exc:
            # ⭐ ОБРИВ ЧЕСНИЙ (рішення Андрія 29.07.2026): віддаємо те, що встигло
            # зібратись, називаємо причину людськими словами й лишаємо повний слід
            # у журналі. Текст пише ОДИН писар — `failure`, з печаткою client_safe;
            # сирий виняток клієнту не виходить ніколи.
            import failure
            stopped = failure.is_budget(exc)
            return {"status": "stopped_budget" if stopped else "failed",
                    "summary": failure.client_text(exc, "automation")[:400],
                    "client_safe": True,
                    "spent_usd": round(costs.current_run().get("usd", 0.0), 4)}
    return {"status": "completed", "summary": (res.get("reply") or "")[:400],
            "client_safe": True,
            "spent_usd": round(scope.result.get("usd", 0.0), 4)}
