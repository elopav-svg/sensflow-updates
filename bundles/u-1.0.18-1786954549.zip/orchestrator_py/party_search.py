# -*- coding: utf-8 -*-
"""party_search.py — ОДИН ПИСАР ПОШУКУ ПО КЛІЄНТСЬКІЙ БАЗІ (крок D2, 16.08.2026).

⭐⭐⭐ КОРІНЬ (слово Андрія 15.08.2026): «На сторінці "Клієнти" відсутній пошук —
коли їх буде 3 тисячі, як знайти потрібного?»

На трьох тисячах ламається не краса, а сама робота: **знайти → відібрати →
зробити щось із відібраним**. Цей файл робить ПЕРШЕ і лише перше.

ЩО ЦЕЙ ФАЙЛ РОБИТЬ:
  • шукає контрагента за НАЗВОЮ, ЄДРПОУ, ПОШТОЮ, ТЕЛЕФОНОМ, НОМЕРОМ УГОДИ
    і за власним номером картки (`p0020`) — це вибір Андрія 15.08 плюс наш
    власний номер, який видно на кожній плитці;
  • віддає результат СТОРІНКАМИ і КАЖЕ, скільки знайшов усього;
  • складає рядок списку: назва · відповідальний · роль · дата останнього
    контакту (стовпці — вибір Андрія; контактів і числа угод він НЕ взяв).

ЧОГО ЦЕЙ ФАЙЛ НЕ РОБИТЬ І ЧОМУ:
  🩸 **НЕ ЗНАЄ ФАКТІВ ПРО КЛІЄНТА.** Хто веде клієнта — питаємо `parties`
     (крок D1). Коли був останній контакт — теж `parties`. Другий писар тих
     самих фактів розійшовся б із карткою назавтра: у памʼяті платформи це
     найдорожчий клас дефектів («два писарі однієї правди»).
  🩸 **НЕ ШУКАЄ В БРАУЗЕРІ.** Пошук у розмітці бачив би лише те, що вже
     завантажено, — тобто на трьох тисячах брехав би тихо.
  🩸 **НЕ ОБРІЗАЄ МОВЧКИ.** `found` — це скільки збіглося ВСЬОГО, а не скільки
     влізло в сторінку. Мовчазне обрізання списку стоїть у переліку «що вбиває
     продукт», і сторінки без чесного числа були б рівно ним.

ЗАКРИТИЙ СЛОВНИК ФІЛЬТРІВ. До сьогодні правило «вкладка *Усі* ховає контактних
осіб» жило В РОЗМІТЦІ. Сервер про нього не знав — і на сторінках це дало б два
різні переліки з однієї бази. Тепер словник тут, а екран лише називає слово.
Невідоме слово — ВІДМОВА словами, а не тиха підстановка сусіднього.

Запуск чека: python3 party_search_test.py
"""

import math
import re

import deals
import parties

# ── Скільки малюємо за раз ───────────────────────────────────────────────────
# ⚠ Три тисячі карток не малюються разом. 50 — стільки, скільки людина реально
# переглядає очима; стеля стоїть, щоб «per=100000» не обійшло сторінки з адреси.
PER_DEFAULT = 50
PER_MAX = 200

# ── Закритий словник фільтрів (переїхав із розмітки) ─────────────────────────
F_ALL = "all"              # усі, КРІМ контактних осіб — так було до 16.08
F_CONTACT = "contact"      # лише контактні особи
F_SUPPLIER = "supplier"    # лише постачальники
F_PERSON = "person"        # лише фізичні особи
F_COMPANY = "company"      # лише компанії
FILTERS = (F_ALL, F_CONTACT, F_SUPPLIER, F_PERSON, F_COMPANY)
FILTER_NAMES = {F_ALL: "Усі", F_CONTACT: "Контактні особи",
                F_SUPPLIER: "Постачальники", F_PERSON: "Фізичні особи",
                F_COMPANY: "Компанії"}

# ── Стан картки: у роботі чи в архіві (крок D3, 16.08.2026) ──────────────────
# ⛒ ЦЕ ОКРЕМЕ ПИТАННЯ ВІД ФІЛЬТРА, а не ще одне слово в тому ж словнику. Фільтр
# відповідає «ХТО це» (компанія, постачальник, контактна особа), стан — «ЧИ
# працюємо ми з ним зараз». Злити їх в один список означало б, що «Архів» і
# «Постачальники» не ставляться разом, — а саме так виглядає жива робота:
# «покажи архівних постачальників».
# ⚠ ТИПОВО — ЛИШЕ ЖИВІ. Архів, який лишається в переліку, не архів.
ST_LIVE = "live"
ST_ARCHIVED = "archived"
STATES = (ST_LIVE, ST_ARCHIVED)
STATE_NAMES = {ST_LIVE: "У роботі", ST_ARCHIVED: "Архів"}

# ── Чим саме збіглося (щоб екран міг сказати це людині) ──────────────────────
M_ALL = ""                 # запиту не було — показуємо всю базу
M_ID = "id"
M_NAME = "name"
M_EMAIL = "email"
M_PHONE = "phone"
M_EDRPOU = "edrpou"
M_DEAL = "deal"
MATCH_NAMES = {M_ID: "номер картки", M_NAME: "назва", M_EMAIL: "пошта",
               M_PHONE: "телефон", M_EDRPOU: "ЄДРПОУ", M_DEAL: "номер угоди"}

# ── Закритий словник стовпців сортування (зміна 187, 16.08.2026) ─────────────
# ⛒ Сортуємо РІВНО за тими стовпцями, які людина бачить. Стовпця, якого немає на
# екрані, не буває і в словнику: «сортуй за тим, чого не видно» — це вгадування.
S_DEFAULT = ""          # як база наповнювалась: свіжіші згори (так було до 187)
S_NAME = "name"
S_MANAGER = "manager"
S_ROLE = "role"
S_CONTACT = "contact"
SORTS = (S_DEFAULT, S_NAME, S_MANAGER, S_ROLE, S_CONTACT)
SORT_NAMES = {S_DEFAULT: "за появою в базі", S_NAME: "назва",
              S_MANAGER: "відповідальний", S_ROLE: "роль",
              S_CONTACT: "останній контакт"}
# ⭐ У кожного стовпця свій ПРИРОДНИЙ напрям: назву читають з початку абетки,
# а «останній контакт» — від найсвіжішого. Дефолт, який цього не знає, змушує
# людину другим кліком виправляти платформу.
SORT_DEFAULT_DIR = {S_NAME: "asc", S_MANAGER: "asc", S_ROLE: "asc",
                    S_CONTACT: "desc", S_DEFAULT: "desc"}
DIRS = ("asc", "desc")

# 🩸 УКРАЇНСЬКА АБЕТКА, А НЕ ПОРЯДОК КОДІВ. У таблиці Unicode «і», «ї», «є», «ґ»
# стоять ОКРЕМО від решти кирилиці — при звичайному сортуванні «Іванов» поїхав
# би після «Яковенко». Для українського продукту це не дрібниця, а поламаний
# список. Тому порядок букв ми називаємо самі.
UK_ALPHABET = "абвгґдеєжзиіїйклмнопрстуфхцчшщьюя"
_UK_RANK = {ch: i for i, ch in enumerate(UK_ALPHABET)}
_APOSTROPHES = "\u02bc\u2019'`"


def uk_key(value):
    """Ключ сортування українською абеткою. Не буква — після букв, у своєму
    порядку; апостроф і пробіли не рвуть слово навпіл."""
    out = []
    for ch in _s(value).casefold():
        if ch in _APOSTROPHES:
            continue
        r = _UK_RANK.get(ch)
        out.append((0, r) if r is not None else (1, ord(ch)))
    return out


# Номер угоди людина пише як завгодно: «d0014», «D14», «d 14».
DEAL_Q = re.compile(r"^d\s*0*(\d{1,4})$", re.I)
# Номер картки контрагента — так само.
PARTY_Q = re.compile(r"^p\s*0*(\d{1,4})$", re.I)


class SearchError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _digits(v) -> str:
    return re.sub(r"\D", "", _s(v))


def check_filter(value) -> str:
    """Слово фільтра з закритого словника. Порожньо = «Усі»."""
    f = _s(value) or F_ALL
    if f not in FILTERS:
        raise SearchError("Невідомий фільтр «%s». Відомі: %s."
                          % (f, ", ".join(FILTERS)))
    return f


def check_state(value) -> str:
    """Стан із закритого словника. Порожньо = «у роботі»."""
    st = _s(value) or ST_LIVE
    if st not in STATES:
        raise SearchError("Невідомий стан «%s». Відомі: %s."
                          % (st, ", ".join(STATES)))
    return st


def check_manager(value) -> str:
    """Номер працівника для фільтра «клієнти менеджера X». Порожньо = без фільтра.

    ⛔ НЕВІДОМИЙ ПРАЦІВНИК — ВІДМОВА СЛОВАМИ, А НЕ ПОРОЖНІЙ СПИСОК. Порожній
    перелік на друкарську помилку в номері виглядає як «у цього менеджера
    клієнтів немає» — і саме під таким висновком клієнти звільненого лишились
    би нічиїми, хоча вони є.
    ⚠ ЗВІЛЬНЕНИЙ ТУТ ДОПУСКАЄТЬСЯ: знайти його клієнтів — це й є той сценарій,
    заради якого фільтр писався. Заборона стоїть на ПРИЗНАЧЕННІ, не на пошуку."""
    emp = _s(value)
    if not emp:
        return ""
    known = {o["id"] for o in parties.manager_options(include_dismissed=True)}
    if emp not in known:
        raise SearchError(
            "Працівника «%s» немає в оргструктурі — чиїх клієнтів шукати, "
            "невідомо." % emp)
    return emp


def check_per(value) -> int:
    """Скільки рядків на сторінку. Сміття — відмова, а не мовчазний дефолт."""
    v = _s(value)
    if not v:
        return PER_DEFAULT
    try:
        n = int(v)
    except Exception:
        raise SearchError("«%s» — це не число рядків на сторінку." % v)
    if n < 1:
        raise SearchError("Рядків на сторінку не може бути менше одного.")
    if n > PER_MAX:
        raise SearchError("Забагато рядків на сторінку: %d. Стеля — %d."
                          % (n, PER_MAX))
    return n


def check_page(value) -> int:
    v = _s(value)
    if not v:
        return 1
    try:
        n = int(v)
    except Exception:
        raise SearchError("«%s» — це не номер сторінки." % v)
    if n < 1:
        raise SearchError("Номер сторінки починається з одиниці.")
    return n


def check_sort(value) -> str:
    """Стовпець сортування з закритого словника. Невідомий — відмова словами."""
    s = _s(value)
    if s not in SORTS:
        raise SearchError("Невідомий стовпець сортування «%s». Відомі: %s."
                          % (s, ", ".join(x or "«за появою»" for x in SORTS)))
    return s


def check_dir(value, sort: str = "") -> str:
    """Напрям сортування. Порожньо — природний напрям цього стовпця."""
    d = _s(value).lower()
    if not d:
        return SORT_DEFAULT_DIR.get(sort, "asc")
    if d not in DIRS:
        raise SearchError("Невідомий напрям «%s». Відомі: %s."
                          % (d, ", ".join(DIRS)))
    return d


def _sort_hits(hits, sort: str, direction: str, mgrs: dict, lasts: dict):
    """Порядок рядків ДО сторінок.

    🩸 ПОРОЖНЄ — ЗАВЖДИ В КІНЦІ, В ОБОХ НАПРЯМАХ. «Немає відповідального» і
    «ще не спілкувались» — це не «найменше значення», а ВІДСУТНІСТЬ. Якби
    порожні спливали вгору при зворотному порядку, перше, що бачив би менеджер
    у списку, — двадцять прочерків; сама робота (хто охолов, хто нічий)
    опинилась би на другій сторінці."""
    if not sort:
        # Як було до 187: свіжіші згори (`parties.all_parties` уже так віддає).
        return list(hits) if direction == "desc" else list(reversed(list(hits)))
    rev = (direction == "desc")

    def key(item):
        p, _m = item
        pid = _s(p.get("id"))
        if sort == S_NAME:
            v = uk_key(_s(p.get("name")) or pid)
        elif sort == S_MANAGER:
            v = uk_key(_s((mgrs.get(pid) or {}).get("name")))
        elif sort == S_ROLE:
            names = [parties.ROLE_NAMES.get(r, r) for r in (p.get("roles") or [])]
            v = uk_key(", ".join(sorted(names)))
        else:
            d = _s((lasts.get(pid) or {}).get("date"))
            v = [(0, ord(c)) for c in d]
        empty = 1 if not v else 0
        # ⛒ Перший ключ (порожність) НЕ обертається — тому прочерки лишаються
        # внизу і при «згори вниз», і при «знизу вгору».
        return (empty, v)

    body = sorted(hits, key=lambda it: key(it)[1], reverse=rev)
    return ([it for it in body if not key(it)[0]]
            + [it for it in body if key(it)[0]])


def _passes_filter(p: dict, f: str) -> bool:
    roles = list(p.get("roles") or [])
    kind = _s(p.get("kind"))
    if f == F_ALL:
        # ⭐ КРОК B5: людей у базі більше, ніж клієнтів. За замовчуванням перелік
        # показує те саме, що й до 15.08, а контактні особи — окремою вкладкою.
        return parties.ROLE_CONTACT not in roles
    if f == F_CONTACT:
        return parties.ROLE_CONTACT in roles
    if f == F_SUPPLIER:
        return parties.ROLE_SUPPLIER in roles
    if f in (F_PERSON, F_COMPANY):
        return kind == f
    return True


def _deal_parties(q: str) -> set:
    """Номери контрагентів, яких тримає ця угода: клієнт і контактні особи.

    ⛒ Питаємо реєстр угод, а не збираємо звʼязки самі: `deals` — писар угод."""
    m = DEAL_Q.match(q)
    if not m:
        return set()
    did = "d%04d" % int(m.group(1))
    try:
        if not deals.exists(did):
            return set()
    except Exception:
        return set()
    out = set()
    try:
        client = _s(deals.client_of(did))
        if client:
            out.add(client)
        for row in deals.people_of(did):
            pid = _s(row.get("party_id"))
            if pid:
                out.add(pid)
    except Exception:
        return out
    return out


def _match_of(p: dict, q: str, qd: str, deal_pids: set) -> str:
    """Чим саме збігся цей контрагент («» — не збігся зовсім)."""
    if not q:
        return M_ALL
    pid = _s(p.get("id"))
    if pid and pid in deal_pids:
        return M_DEAL
    low = pid.lower()
    pm = PARTY_Q.match(q)
    if low == q or (pm and low == ("p%04d" % int(pm.group(1)))):
        return M_ID
    prof = dict(p.get("profile") or {})
    if q in _s(p.get("name")).casefold() or q in _s(prof.get("org")).casefold():
        return M_NAME
    h = dict(p.get("handles") or {})

    def _vals(kind):
        v = h.get(kind) or []
        return v if isinstance(v, list) else [v]

    # 🩸🩸🩸 ШУКАТИ ТРЕБА ТАМ, ДЕ ФАКТ СПРАВДІ ЛЕЖИТЬ, А НЕ ДЕ ЗРУЧНО.
    # Перевірено на живій базі Андрія 16.08.2026: пошта й телефон живуть у ДВОХ
    # місцях — у «ручках» довідника І в профілі картки (`profile.phone`,
    # `profile.email`), причому в профілі вони ЗАПИСАНІ ЯК ЗАВГОДНО
    # («+7 903 901 0169»). Пошук лише по ручках мовчки не знайшов би половину
    # бази — і це виглядало б як «пошук не працює», а не як «дані в іншому полі».
    # ⛒ КОНТАКТНІ ОСОБИ ТУТ НЕ ЗГАДАНІ СВІДОМО: від кроку B5 у кожної своя
    # картка, і в переліку вони знаходяться ЯК ВЛАСНИЙ РЯДОК. Дублювати їхні
    # адреси в рядку компанії означало б завести другого писаря тієї ж правди.
    mails = list(_vals(parties.H_EMAIL)) + [prof.get("email")]
    phones = list(_vals(parties.H_PHONE)) + [prof.get("phone")]

    for e in mails:
        if q and q in _s(e).lower():
            return M_EMAIL
    # ⚠ ЦИФРИ ШУКАЄМО ЛИШЕ ВІД ТРЬОХ ЗНАКІВ. «6» стоїть і в ЄДРПОУ, і в кожному
    # телефоні — така «знахідка» виглядає як поломка пошуку, а не як відповідь.
    if len(qd) >= 3:
        for e in _vals(parties.H_EDRPOU):
            if qd in _digits(e):
                return M_EDRPOU
        # ⛒ І запит, і збережене — ЛИШЕ ЦИФРАМИ. Інакше «0676340643» не знайшло б
        # «+380 (67) 634-06-43», хоча це один і той самий телефон.
        for e in phones:
            if _digits(e) and qd in _digits(e):
                return M_PHONE
    return ""


def _row(p: dict, match: str, mgr: dict, last: dict, customer: str) -> dict:
    """Рядок для екрана. Стовпці — вибір Андрія 15.08.2026:
    назва · відповідальний · роль · дата останнього контакту."""
    roles = list(p.get("roles") or [])
    kind = _s(p.get("kind"))
    return {
        "id": _s(p.get("id")),
        "name": _s(p.get("name")),
        "kind": kind,
        "kind_name": parties.KIND_NAMES.get(kind, kind),
        "roles": roles,
        "role_names": [parties.ROLE_NAMES.get(r, r) for r in roles],
        "handles": dict(p.get("handles") or {}),
        "manager": mgr or None,
        "last_contact": last or {"date": "", "type": "", "name": ""},
        "customer": customer,
        "match": match,
        "match_name": MATCH_NAMES.get(match, ""),
    }


def criteria(query: str = "", filter: str = F_ALL, sort: str = S_DEFAULT,
             dir: str = "", state: str = ST_LIVE, manager: str = "") -> dict:
    """Перевірені умови відбору — ОДНЕ місце, де слова людини стають правилом.

    ⭐⭐⭐ КРОК D3. «Вибрати все за фільтром» означає, що ГРУПОВА ДІЯ і ПЕРЕЛІК
    на екрані мусять відбирати ОДНАКОВО. Якби писар дії мав власне читання
    умов (хоч на одну галочку інше), людина бачила б 743 картки, а міняла —
    інші 743. Тому умови перевіряються тут і далі їдуть цілим шматком."""
    srt = check_sort(sort)
    return {"query": _s(query), "filter": check_filter(filter),
            "sort": srt, "dir": check_dir(dir, srt),
            "state": check_state(state), "manager": check_manager(manager)}


def describe(crit: dict) -> str:
    """Умови відбору ЛЮДСЬКИМИ СЛОВАМИ — рівно те, що екран покаже перед дією.

    ⛒ Людина мусить прочитати, ЩО саме зараз зміниться, а не довіряти числу."""
    c = dict(crit or {})
    out = [STATE_NAMES.get(c.get("state"), c.get("state") or ST_LIVE),
           FILTER_NAMES.get(c.get("filter"), c.get("filter") or F_ALL)]
    if _s(c.get("manager")):
        names = {o["id"]: o["name"]
                 for o in parties.manager_options(include_dismissed=True)}
        out.append("веде: %s" % names.get(_s(c["manager"]), _s(c["manager"])))
    if _s(c.get("query")):
        out.append("пошук: «%s»" % _s(c["query"]))
    return " · ".join(out)


def _hits(crit: dict) -> list:
    """Усе, що збіглося, у видимому порядку. ОДИН відбирач на весь крок D3."""
    f = crit["filter"]
    q = _s(crit.get("query")).casefold()
    qd = _digits(q)
    srt, direction = crit["sort"], crit["dir"]
    state, mgr_want = crit["state"], _s(crit.get("manager"))
    deal_pids = _deal_parties(q) if q else set()

    # ⚠ ГУРТОМ, А НЕ ПО КАРТЦІ. Фільтр «клієнти менеджера X» питає звʼязок у
    # КОЖНОЇ картки бази — на трьох тисячах це три тисячі читань реєстру.
    all_mgrs = parties.managers() if (mgr_want or srt == S_MANAGER) else {}
    all_lasts = parties.last_contacts() if srt == S_CONTACT else {}

    hits = []
    for p in parties.all_parties(archived=(state == ST_ARCHIVED)):
        if not _passes_filter(p, f):
            continue
        # ⛒ «ЧИЙ КЛІЄНТ» РАХУЄТЬСЯ РІВНО ПО ЗВʼЯЗКУ `REL_MANAGED_BY`, а не по
        # тому, чиї в нього угоди: угоду міг завести хто завгодно, а веде
        # клієнта рівно одна людина (правило D1).
        if mgr_want and _s((all_mgrs.get(_s(p.get("id"))) or {}).get("id")) != mgr_want:
            continue
        m = _match_of(p, q, qd, deal_pids)
        if q and not m:
            continue
        hits.append((p, m))
    return _sort_hits(hits, srt, direction, all_mgrs, all_lasts)


def matched_ids(crit: dict) -> list:
    """Номери ВСЬОГО, що збіглося, — для «вибрати все за фільтром».

    ⛒ Не «те, що на сторінці», а ВСЕ. І бере це той самий `_hits`, яким
    намальовано перелік, — інакше число на екрані й число в дії розійшлись би."""
    return [_s(p.get("id")) for p, _m in _hits(crit)]


def search(query: str = "", filter: str = F_ALL, page=1, per=None,
           sort: str = S_DEFAULT, dir: str = "", state: str = ST_LIVE,
           manager: str = "") -> dict:
    """Знайти → упорядкувати → показати сторінкою → чесно сказати, скільки всього.

    ⭐ РЯДКИ СКЛАДАЄМО ЛИШЕ ДЛЯ ВИДИМОЇ СТОРІНКИ: відповідального й дату
    останнього контакту питаємо в `parties` ОДНИМ читанням на сторінку, а не
    по разу на кожну з трьох тисяч карток.
    ⛒ АЛЕ СОРТУЄМО ЗАВЖДИ ВСЕ ЗНАЙДЕНЕ, А НЕ СТОРІНКУ: «упорядкувати те, що
    вже відрізали» — це впорядкований шматок і брехня про решту."""
    per = check_per(per)
    page = check_page(page)
    crit = criteria(query=query, filter=filter, sort=sort, dir=dir,
                    state=state, manager=manager)
    f, srt, direction = crit["filter"], crit["sort"], crit["dir"]
    hits = _hits(crit)

    found = len(hits)
    pages = max(1, int(math.ceil(found / float(per))) if found else 1)
    # ⚠ Сторінку за межею не мовчимо, а ПРИТИСКАЄМО і кажемо про це вголос.
    clamped = page > pages
    if clamped:
        page = pages
    start = (page - 1) * per
    window = hits[start:start + per]
    ids = [_s(p.get("id")) for p, _m in window]

    mgrs = parties.managers(ids)
    lasts = parties.last_contacts(ids)
    cards = _cards_of(ids)
    rows = [_row(p, m, mgrs.get(_s(p.get("id"))), lasts.get(_s(p.get("id"))),
                 cards.get(_s(p.get("id")), ""))
            for p, m in window]

    return {"query": _s(query), "filter": f, "filter_name": FILTER_NAMES.get(f, f),
            "found": found, "page": page, "pages": pages, "per": per,
            "clamped": clamped, "shown": len(rows), "rows": rows,
            "sort": srt, "sort_name": SORT_NAMES.get(srt, srt), "dir": direction,
            "sorts": dict(SORT_NAMES),
            # ⭐ D3: стан, фільтр менеджера і перелік людей — щоб екран не
            # тримав власного списку працівників (він розійшовся б на першому
            # ж звільненні) і міг назвати умови відбору словами.
            "state": crit["state"], "state_name": STATE_NAMES.get(crit["state"], ""),
            "manager": crit["manager"],
            "manager_options": parties.manager_options(include_dismissed=True),
            "criteria": crit, "criteria_name": describe(crit),
            "counts": parties.count(archived=(crit["state"] == ST_ARCHIVED))}


def _cards_of(ids) -> dict:
    """Імена карток CRM для видимої сторінки («» — картки ще немає).

    ⚠ Загорнуто: зламана картка CRM не сміє повалити пошук по базі."""
    out = {}
    try:
        import crm
    except Exception:
        return out
    for pid in ids:
        try:
            out[pid] = _s(crm.card_of_party(pid))
        except Exception:
            out[pid] = ""
    return out
