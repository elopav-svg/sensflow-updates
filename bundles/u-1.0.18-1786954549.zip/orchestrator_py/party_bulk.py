# -*- coding: utf-8 -*-
"""party_bulk.py — ОДИН ПИСАР ГРУПОВИХ ДІЙ НАД КЛІЄНТСЬКОЮ БАЗОЮ (крок D3,
16.08.2026).

⭐⭐⭐ КОРІНЬ (слово Андрія 15.08.2026): «коли їх буде 3 тисячі…». D2 навчив
ЗНАЙТИ. D3 відповідає на друге питання тієї самої роботи: **зробити щось із
відібраним, не перебираючи по одному**. Головний живий сценарій, який Андрій
назвав сам: менеджер звільнився — його клієнтів треба передати іншому.

ЩО ЦЕЙ ФАЙЛ РОБИТЬ:
  • перетворює вибір людини («ось ці галочки» або «все за фільтром») на
    ПЕРЕЛІК номерів — рівно той самий відбір, яким намальовано екран;
  • показує ПЕРЕЛІК ІЗ ЧИСЛОМ **до** дії;
  • виконує рівно ДВІ дії: **архівувати / повернути з архіву** і
    **перезакріпити відповідального**;
  • віддає ЧЕСНИЙ підсумок: що вдалось, а що ні — ПОІМЕННО.

🩸🩸🩸 ЧОМУ ПИСАР ОДИН. У зміні 188 ми вже лікували цю саму хворобу: народження
угоди мало ДВА шляхи, і другий тихо не знав правил першого. Дві групові дії,
кожна зі своїм читанням умов, своїм переліком і своїм записом у протокол,
розійшлися б на першій же новій дії — а ціна розходження тут не «негарно», а
«сімсот карток змінились не так, як людина бачила на екрані».

⛒ ЩО ЦЕЙ ФАЙЛ НЕ РОБИТЬ І ЧОМУ:
  🩸 **НЕ ВІДБИРАЄ САМ.** Кого взяли — рахує `party_search._hits`, той самий,
     що малює перелік. Другий відбирач = друга правда про те саме.
  🩸 **НЕ ЗМІНЮЄ КАРТКУ САМ.** Архів кладе `parties.set_archived`,
     відповідального — `parties.set_manager`. Обидва вже вміють головне:
     писати рядок у протокол і **не віддавати клієнта звільненому**.
  🩸 **НЕ ВИДАЛЯЄ.** Групового видалення тут немає свідомо (слово Андрія
     16.08): незворотна дія над трьома тисячами записів — не зручність.
  🩸 **НЕ МОВЧИТЬ ПРО ЧАСТКОВИЙ УСПІХ.** Якщо 5 із 700 не лягли, вони
     називаються поіменно. «Готово» при пʼятьох мовчазних відмовах — це те
     саме «зелена брехня», через яку вже двічі страждав клієнт.

Запуск чека: python3 party_bulk_test.py
"""

import parties
import party_search as ps

# ── Закритий словник дій ─────────────────────────────────────────────────────
# ⛒ Дієслово, якого немає в словнику, не виконується — воно ВІДМОВЛЯЄТЬСЯ
# словами. Мовчазна підстановка сусідньої дії над сімомастами картками — це
# найдорожча помилка, яку тільки може зробити цей файл.
A_ARCHIVE = "archive"          # прибрати в архів
A_UNARCHIVE = "unarchive"      # повернути з архіву
A_MANAGER = "manager"          # перезакріпити відповідального
ACTIONS = (A_ARCHIVE, A_UNARCHIVE, A_MANAGER)
ACTION_NAMES = {A_ARCHIVE: "Прибрати в архів",
                A_UNARCHIVE: "Повернути з архіву",
                A_MANAGER: "Перезакріпити відповідального"}

# ── Звідки взявся вибір ──────────────────────────────────────────────────────
# 🩸🩸🩸 «ВСЕ ВИДИМЕ» І «ВСЕ ЗНАЙДЕНЕ» — РІЗНІ ЧИСЛА, І ПЛУТАНИНА ТУТ КОШТУЄ
# ДАНИХ (слово Андрія 16.08). На сторінці 50 карток, а за фільтром — 743.
# Тому джерело вибору назване ВГОЛОС, а не вгадується з того, чи приїхав
# перелік номерів.
SC_IDS = "ids"                 # рівно ці картки, галочками
SC_FILTER = "filter"           # усе, що збіглося з умовами відбору
SCOPES = (SC_IDS, SC_FILTER)
SCOPE_NAMES = {SC_IDS: "вибрані картки", SC_FILTER: "усе за фільтром"}

# ⚠ Скільки імен показуємо в переліку ДО дії. Число завжди чесне й повне;
# іменами показуємо стільки, скільки людина реально прочитає очима.
PREVIEW_NAMES = 20


class BulkError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def check_action(value) -> str:
    a = _s(value)
    if a not in ACTIONS:
        raise BulkError("Невідома групова дія «%s». Відомі: %s."
                        % (a or "«»", ", ".join(ACTIONS)))
    return a


def check_scope(value) -> str:
    s = _s(value)
    if s not in SCOPES:
        raise BulkError("Невідоме джерело вибору «%s». Відомі: %s."
                        % (s or "«»", ", ".join(SCOPES)))
    return s


def resolve(scope, ids=(), crit=None) -> list:
    """Кого саме зачепить дія — ПЕРЕЛІК НОМЕРІВ у видимому порядку.

    ⛒ ПРИ «ВСЕ ЗА ФІЛЬТРОМ» НОМЕРИ РАХУЄ СЕРВЕР ЗАНОВО, а не браузер.
    Перелік із трьох тисяч номерів, надісланий сторінкою, застаріває в мить
    відправки: доки людина читала екран, хтось міг завести нову картку.
    ⛒ ПРИ «ГАЛОЧКАМИ» БЕРЕМО РІВНО НАЗВАНЕ — і мовчки нікого не додаємо.
    ⚠ Порожній вибір — ВІДМОВА: «зроби це ні з ким» не буває наміром."""
    sc = check_scope(scope)
    if sc == SC_FILTER:
        got = ps.matched_ids(crit or ps.criteria())
    else:
        seen, got = set(), []
        for x in (ids or ()):
            pid = _s(x)
            # ⚠ Дубль у переліку — не привід зробити двічі.
            if pid and pid not in seen:
                seen.add(pid)
                got.append(pid)
        unknown = [p for p in got if not parties.exists(p)]
        if unknown:
            # ⛔ Незнайомий номер не пропускаємо мовчки: «зробили 698 із 700»
            # без причини — це та сама тиха відмова.
            raise BulkError("У виборі є картки, яких немає в базі: %s."
                            % ", ".join(unknown[:10]))
    if not got:
        raise BulkError("Нікого не вибрано — робити нема над ким.")
    return got


def _row(pid: str, mgrs: dict) -> dict:
    """Рядок переліку «що саме зміниться»."""
    p = parties.get(pid)
    mg = mgrs.get(pid) or None
    return {"id": pid, "name": _s(p.get("name")) or pid,
            "archived": parties.is_archived(p),
            "manager": mg, "manager_name": _s((mg or {}).get("name"))}


def preview(action, scope, ids=(), crit=None, employee: str = "") -> dict:
    """ЩО САМЕ ЗМІНИТЬСЯ — до того, як щось змінилось.

    🩸🩸🩸 МОВЧАЗНА ДІЯ НАД 3000 ЗАПИСІВ — НЕЗВОРОТНА ШКОДА. Тому людина
    спершу читає: скільки, за яким відбором і кого саме (перші імена).
    ⚠ Число `count` — ПОВНЕ; імен показуємо стільки, скільки читають очима,
    і прямо кажемо, скільки лишилось за межею переліку."""
    act = check_action(action)
    sc = check_scope(scope)
    # 🩸 ВІДМОВА МУСИТЬ ПРИЙТИ ДО ПЕРЕЛІКУ, А НЕ ПІСЛЯ НЬОГО (знайдено читанням
    # коду). Інакше людина читає «Перезакріпити: 743 картки», тисне «Так,
    # зробити» — і аж тоді дізнається, що не обрала працівника. Питання про
    # те, кому передаємо, ставиться в ОБОХ кроках тим самим писарем.
    if act == A_MANAGER:
        _check_employee(employee)
    got = resolve(sc, ids, crit)
    mgrs = parties.managers(got)
    rows = [_row(p, mgrs) for p in got[:PREVIEW_NAMES]]
    out = {"action": act, "action_name": ACTION_NAMES[act],
           "scope": sc, "scope_name": SCOPE_NAMES[sc],
           "count": len(got), "shown": len(rows), "rows": rows,
           "rest": max(0, len(got) - len(rows)),
           "criteria_name": ps.describe(crit) if sc == SC_FILTER else ""}
    if act == A_MANAGER:
        out["employee"] = _s(employee)
        out["employee_name"] = _employee_name(_s(employee))
    return out


def _employee_name(emp: str) -> str:
    if not _s(emp):
        return ""
    for o in parties.manager_options(include_dismissed=True):
        if o["id"] == _s(emp):
            return o["name"]
    return _s(emp)


def _check_employee(emp: str) -> str:
    """Кому передаємо клієнтів.

    ⛔ ПОРОЖНЬО ТУТ НЕ ОЗНАЧАЄ «ЗНЯТИ ВСІМ». Одна забута галочка в списку
    людей знеосіблювала б сімсот клієнтів мовчки — а це рівно та шкода,
    заради недопущення якої писався весь напрям D.
    ⛔ І ЗВІЛЬНЕНОМУ КЛІЄНТА НЕ ВІДДАЄМО — правило D1 діє і на групі. Але
    відмову ставимо ТУТ, ДО першого запису: інакше перша ж картка впала б,
    а людина прочитала б «не вдалось 700 із 700» замість причини."""
    e = _s(emp)
    if not e:
        raise BulkError("Не обрано, кому передати клієнтів. Сама я не вибираю: "
                        "порожній вибір знеосібнив би всіх одразу.")
    for o in parties.manager_options(include_dismissed=False):
        if o["id"] == e:
            return e
    who = _employee_name(e)
    for o in parties.manager_options(include_dismissed=True):
        if o["id"] == e:
            raise BulkError("%s звільнений — вести клієнтів може лише чинний "
                            "працівник." % who)
    raise BulkError("Працівника «%s» немає в оргструктурі — передавати клієнтів "
                    "нема кому." % e)


def apply(action, scope, ids=(), crit=None, employee: str = "", by: str = "") -> dict:
    """Зробити — і чесно сказати, що вийшло, а що ні.

    ⛒ ЧАСТКОВИЙ УСПІХ — ЦЕ ВІДПОВІДЬ, А НЕ МОВЧАННЯ. Одна картка, яка не
    лягла, не має права зупинити решту 699 — але й зникнути з підсумку не
    має права теж: вона називається поіменно з причиною.
    ⛒ СЛІД У ПРОТОКОЛІ НА КОЖЕН ЗАПИС дає не цей файл, а писарі довідника
    (`set_archived`, `set_manager`) — там, де вже стоїть закон «хто зберігає,
    той і звітує». Власний рядок «змінено 743 картки» був би другим писарем
    журналу і не відповів би на питання «а чому саме цей клієнт в архіві?»."""
    act = check_action(action)
    sc = check_scope(scope)
    emp = _check_employee(employee) if act == A_MANAGER else ""
    got = resolve(sc, ids, crit)

    done, failed = [], []
    for pid in got:
        name = ""
        try:
            name = parties.title(pid) or pid
            if act == A_ARCHIVE:
                parties.set_archived(pid, True)
            elif act == A_UNARCHIVE:
                parties.set_archived(pid, False)
            else:
                parties.set_manager(pid, emp, by=by)
            done.append({"id": pid, "name": name})
        except Exception as ex:
            failed.append({"id": pid, "name": name or pid, "why": str(ex)})
    return {"action": act, "action_name": ACTION_NAMES[act],
            "scope": sc, "scope_name": SCOPE_NAMES[sc],
            "asked": len(got), "done": len(done), "failed": len(failed),
            "done_rows": done, "failed_rows": failed,
            "employee": emp, "employee_name": _employee_name(emp)}
