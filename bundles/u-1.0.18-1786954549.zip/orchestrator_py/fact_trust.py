# -*- coding: utf-8 -*-
"""fact_trust.py — ОДИН ПИСАР ПРО ТЕ, ЧИ ФАКТ СПРАВДІ ЗДОБУТИЙ З ДЖЕРЕЛА.

⭐⭐⭐ КОРІНЬ 10.08.2026. Запобіжник брехні існував — але накривав РІВНО ОДИН клас
    факту: номер закупівлі Прозорро (`source_trust` + `tender_ref`, одна регулярка).
    Живий прогін 09.08.2026 показав ціну цієї вузькості: на запит про заклади
    харчування система віддала таблицю з НАЗВАМИ кафе, АДРЕСАМИ й ГОДИНАМИ РОБОТИ,
    жодного джерела при цьому не відкривши. Ворота посилань не спрацювали, бо
    глибоких URL у тексті не було — лишився корінь домену, а його не судять.
    Тобто вигадка доїхала до людини у вигляді впорядкованої таблиці.

    ⛔ КЛАС: **факт, який міг зʼявитись ЛИШЕ з джерела, поданий тоді, коли джерел
    не було жодного.** Це не «неперевірено» — це вигадка, і вона мусить зупиняти
    роботу так само, як зупиняє вигадане посилання.

ЯК МИ ЦЕ СУДИМО (детерміновано, без вгадування намірів):
  • Клас факту впізнається за ФОРМОЮ — так само, як номер тендера впізнається
    регуляркою. Години роботи «08:00–22:00», телефон, e-mail, адреса з «вул./
    просп./шосе», посилання, номер закупівлі. Форма — не здогад про смисл.
  • КОРПУС — це те, що платформа СПРАВДІ прочитала: текст відкритих сторінок,
    документи, які дала людина, власна база знань, і сам текст задачі (якщо
    людина сама назвала адресу, це не «факт із джерела», а її ж слова).
  • Вердикт ТРИСТАННИЙ: `confirmed` (є в корпусі або в реєстрі підтверджень),
    `unverified` (корпус є, але цього факту в ньому не видно) і `invented`
    (корпусу НЕМАЄ ВЗАГАЛІ, а факти подано). Тільки третє зупиняє роботу.

⚠ ЧОГО МИ СВІДОМО НЕ РОБИМО (щоб не зламати живу роботу):
  • не судимо ПОХІДНЕ (пораховані суми фінмоделі, кілометраж) — це не здобуте
    з джерела, а обчислене;
  • не судимо власні реквізити учасника і власну базу знань — вони в корпусі;
  • не зупиняємо роботу, зібрану з ДОКУМЕНТІВ ЛЮДИНИ (`files_context`) — саме так
    працює тендерайтер, і наївне «немає в sources → вигадка» вбило б його;
  • «джерело недоступне» ≠ «джерело вигадане»: недоступність судить `verifier`.
"""

import re

# ── КЛАСИ ФАКТІВ, ЯКІ НЕ МОЖУТЬ ЗʼЯВИТИСЬ «З ГОЛОВИ» ────────────────────────
# Кожен клас — ФОРМА, а не перелік слів. Новий клас додається сюди, і його
# одразу бачать усі, хто питає цей модуль (один писар).
_HOURS = re.compile(r"\b([01]?\d|2[0-3]):[0-5]\d\s*[–\-—]\s*([01]?\d|2[0-3]):[0-5]\d\b")
_PHONE = re.compile(r"(?:\+38|\b0)\s*\(?\d{2,3}\)?[\s\-]?\d{3}[\s\-]?\d{2}[\s\-]?\d{2}\b")
_EMAIL = re.compile(r"\b[\w.+-]+@[\w-]+\.[A-Za-z]{2,}\b")
_ADDRESS = re.compile(
    r"(?:вул\.|вулиця|просп\.|проспект|бул\.|бульвар|пров\.|провулок|"
    r"шосе|наб\.|площа|пл\.)\s*[^,;|\n]{2,60}?\s*,?\s*\d+[А-Яа-яA-Za-z]?\b",
    re.IGNORECASE)
import netfetch as _nf
_URL = _nf.URL_RE              # межа адреси — ОДИН писар (netfetch), 10.08.2026

KINDS = ("hours", "phone", "email", "address", "url", "tender")

_EXTRACT = {
    "hours": lambda t: [m.group(0) for m in _HOURS.finditer(t)],
    "phone": lambda t: [m.group(0) for m in _PHONE.finditer(t)],
    "email": lambda t: [m.group(0) for m in _EMAIL.finditer(t)],
    "address": lambda t: [m.group(0) for m in _ADDRESS.finditer(t)],
    "url": lambda t: [m.group(0) for m in _URL.finditer(t)],
}


def _tenders(text):
    try:
        import tender_ref
        return list(tender_ref.find_all(text or ""))
    except Exception:
        return []


_EXTRACT["tender"] = _tenders


def normalize(kind, value) -> str:
    """Нормалізація ПІД КЛАС, а не під написання.

    ⭐ Урок `source_trust`: печатка на дослівний рядок нічого не варта — той самий
    факт у джерелі й у відповіді написаний по-різному (пробіли, тире, регістр).
    Порівнюємо СУТЬ: цифри телефона, години як числа, адресу без розділових."""
    s = str(value or "")
    if kind == "phone":
        d = "".join(ch for ch in s if ch.isdigit())
        return d[-9:] if len(d) >= 9 else d
    if kind == "hours":
        # ⚠ «08:00 – 22:00» і «8:00-22:00» — ОДИН факт. Порівнювати сирі цифри
        # означало б вважати їх різними (нуль на початку), тобто повторити рівно
        # ту помилку «печатка на дослівний рядок», через яку реєстр був марним.
        m = _HOURS.search(s)
        if m:
            _t = re.findall(r"([01]?\d|2[0-3]):([0-5]\d)", s)
            return "".join("%02d%s" % (int(h), mi) for h, mi in _t[:2])
        _t = re.findall(r"([01]?\d|2[0-3]):([0-5]\d)", s)
        return "".join("%02d%s" % (int(h), mi) for h, mi in _t[:2])
    if kind == "url":
        return s.rstrip("/.,);:*").lower()
    if kind == "tender":
        try:
            import tender_ref
            return (tender_ref.normalize(s) or s).upper()
        except Exception:
            return s.upper()
    if kind == "email":
        return s.lower()
    # адреса й назви: лише літери й цифри, без розділових і регістру
    return "".join(ch.lower() for ch in s if ch.isalnum())


def find_claims(text: str) -> dict:
    """Факти-претензії у видачі: {клас: [значення, …]} (без повторів)."""
    out = {}
    t = text or ""
    for kind in KINDS:
        vals, seen = [], set()
        for v in _EXTRACT[kind](t):
            n = normalize(kind, v)
            if not n or n in seen:
                continue
            seen.add(n)
            vals.append(v)
        if vals:
            out[kind] = vals
    return out


def _corpus_text(parts) -> str:
    return "\n".join(str(p or "") for p in (parts or []))


def _supported(kind, value, corpus_norm: str, corpus_facts=None) -> bool:
    n = normalize(kind, value)
    if not n:
        return True
    # ⭐ 10.08.2026. ДВІ ОПОРИ, І ПЕРША — ГОЛОВНА: витягуємо з КОРПУСУ факти ТОГО
    # САМОГО класу тим самим екстрактором і порівнюємо НОРМАЛІЗОВАНО. Порівнювати
    # нормалізований факт із «сирим» корпусом — це наступити на ту саму міну:
    # номер тендера з дефісами ніколи не знайдеться в тексті без розділових.
    if corpus_facts and n in corpus_facts:
        return True
    if n and n in corpus_norm:
        return True
    # реєстр підтверджень: те, що вже здобув спеціалізований завантажувач
    try:
        import source_trust
        if source_trust.is_confirmed(value, kind=kind):
            return True
    except Exception:
        pass
    return False


def verdict(text: str, corpus_parts, opened_sources: int = 0) -> dict:
    """ТРИСТАННИЙ вердикт про факти видачі.

    corpus_parts — усе, що платформа СПРАВДІ мала перед очима: текст відкритих
    сторінок, документи людини, власна база знань, текст задачі.
    opened_sources — скільки сторінок реально відкрито в цьому прогоні.

    Повертає {"claims": {...}, "unverified": {...}, "invented": bool, "reason": str}.
    `invented` — корпусу немає ЗОВСІМ, а факти класу «лише з джерела» подано.
    """
    claims = find_claims(text)
    corpus = _corpus_text(corpus_parts)
    # корпус нормалізуємо ОДИН раз під кожен клас: числа окремо, літери окремо
    corpus_digits = "".join(ch for ch in corpus if ch.isdigit())
    corpus_alnum = "".join(ch.lower() for ch in corpus if ch.isalnum())
    corpus_low = corpus.lower()
    unverified = {}
    for kind, vals in claims.items():
        bad = []
        # факти ТОГО САМОГО класу, які справді є в прочитаному
        try:
            corpus_facts = {normalize(kind, x) for x in _EXTRACT[kind](corpus)}
            corpus_facts.discard("")
        except Exception:
            corpus_facts = set()
        for v in vals:
            cn = (corpus_digits if kind in ("phone", "hours")
                  else corpus_low if kind in ("url", "email")
                  else corpus_alnum)
            if not _supported(kind, v, cn, corpus_facts):
                bad.append(v)
        if bad:
            unverified[kind] = bad
    has_corpus = bool(corpus.strip())
    invented = bool(claims) and (not has_corpus) and opened_sources <= 0
    reason = ""
    if invented:
        _what = ", ".join("%s (%d)" % (k, len(v)) for k, v in sorted(claims.items()))
        reason = ("у відповіді є факти, які могли зʼявитись лише з джерела — %s — "
                  "а платформа в цьому прогоні не відкрила ЖОДНОГО джерела і не мала "
                  "ні документів, ні власної бази знань" % _what)
    return {"claims": claims, "unverified": unverified,
            "invented": invented, "reason": reason}


def honest_note(unverified: dict) -> str:
    """Чесна позначка ПЛАТФОРМИ (не прохання до моделі написати її сама)."""
    if not unverified:
        return ""
    names = {"hours": "години роботи", "phone": "телефони", "email": "адреси е-пошти",
             "address": "адреси", "url": "посилання", "tender": "номери закупівель"}
    parts = ["%s: %d" % (names.get(k, k), len(v)) for k, v in sorted(unverified.items())]
    return ("> ⚠ **Не підтверджено джерелом** — " + "; ".join(parts)
            + ". Ці дані є у відповіді, але платформа НЕ побачила їх у прочитаних "
              "сторінках і документах. Перед використанням звірте їх самі.")
