"""domains.py — ОДИН ПИСАР ДОВІДНИКА ГАЛУЗЕЙ І ЮРИСДИКЦІЙ (11.08.2026, зміна 150).

НАВІЩО ЦЕЙ МОДУЛЬ ІСНУЄ.
Платформа перестає ВГАДУВАТИ сенс запиту за переліками слів і починає його
ОГОЛОШУВАТИ. Мозок називає галузь і юрисдикцію — але не з голови, а зі списку,
який лежить ТУТ, у даних. Далі довідник каже, ЯКІ ворота вмикаються, а ворота
виконує КОД.

    СЕНС ДАЄ МОЗОК, НАСЛІДОК НЕСЕ КОД.

Чому довідник — файл, а не код: слова Андрія 11.08.2026 — «ми ніколи не
передбачимо всіх пасток у словах». Нова галузь має додаватись рядком у файл, без
правки коду й без нового релізу.

ЧОГО ЦЕЙ МОДУЛЬ НЕ РОБИТЬ. Не судить текст людини, не шукає слів, не ходить у
мережу, не вирішує, що робити з воротами. Він лише ЧИТАЄ довідник і чесно каже,
коли довідника немає.

ЗАПОБІЖНИК. Зіпсований або відсутній файл НЕ валить платформу і НЕ вигадує
галузей: `available()` стає False, усі ворота вимкнені, і кожен споживач мусить
сказати про це вголос (картка розуміння й журнал).
"""

import json
import os

# Тека даних — та сама, де живуть інші бази знань продукту.
PACK_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "knowledge_packs", "domains", "domains.json")

# ⛔ ЗАКРИТИЙ ПЕРЕЛІК ВОРІТ. Довідник — це дані, але назвати можна лише ті ворота,
# які в коді СПРАВДІ існують. Інакше друкарська помилка в json тихо вимикає
# запобіжник, і довідник сам стає новою релейною шафою.
KNOWN_GATES = (
    "tender_deadlines",     # строк у днях без встановленої процедури не виходить як факт
    "verified_norms_only",  # до клієнта йдуть ЛИШЕ звірені з першоджерелом норми
    "live_law",             # звірка норм у живому офіційному джерелі — інваріант ролі
)

# Тверда очевидність: що саме в тексті б'є оголошену галузь.
KNOWN_EVIDENCE = ("tender_id",)

_STAKES = ("high", "normal")

_CACHE = None


class _Book(dict):
    """Прочитаний довідник. Порожній — це нормальний стан, а не виняток."""


def _log(msg):
    try:
        import llm
        llm._log("[domains] %s" % msg)
    except Exception:
        pass


def _empty(problem):
    return _Book({"available": False, "problem": problem,
                  "domains": {}, "order": [], "jurisdictions": {}, "jur_order": []})


def load(path=None, force=False):
    """Читає довідник. Кешує, бо його смикають на кожен запуск системи.

    Повертає структуру, з якою безпечно працювати навіть коли файла немає."""
    global _CACHE
    if _CACHE is not None and not force and path is None:
        return _CACHE
    p = path or PACK_PATH
    try:
        with open(p, "r", encoding="utf-8") as fh:
            raw = json.load(fh)
    except Exception as e:
        book = _empty("довідник галузей недоступний: %s" % e)
        _log(book["problem"])
        if path is None:
            _CACHE = book
        return book

    domains, order = {}, []
    for rec in (raw.get("domains") or []):
        did = str((rec or {}).get("id") or "").strip()
        name = str((rec or {}).get("name") or "").strip()
        if not did or not name or did in domains:
            continue
        gates = tuple(g for g in ((rec.get("gates") or []))
                      if isinstance(g, str) and g in KNOWN_GATES)
        stakes = rec.get("stakes") if rec.get("stakes") in _STAKES else "normal"
        ev = rec.get("evidence") if rec.get("evidence") in KNOWN_EVIDENCE else None
        cats = tuple(str(c).strip().lower() for c in (rec.get("categories") or [])
                     if str(c).strip())
        domains[did] = {"id": did, "name": name, "gates": gates,
                        "stakes": stakes, "evidence": ev, "categories": cats}
        order.append(did)

    jur, jorder = {}, []
    for rec in (raw.get("jurisdictions") or []):
        jid = str((rec or {}).get("id") or "").strip().upper()
        name = str((rec or {}).get("name") or "").strip()
        if not jid or not name or jid in jur:
            continue
        jur[jid] = {"id": jid, "name": name,
                    "portal": str(rec.get("portal") or "").strip()}
        jorder.append(jid)

    if not domains or not jur:
        book = _empty("довідник галузей порожній або зіпсований: %s" % p)
        _log(book["problem"])
        if path is None:
            _CACHE = book
        return book

    book = _Book({"available": True, "problem": "", "domains": domains,
                  "order": order, "jurisdictions": jur, "jur_order": jorder})
    if path is None:
        _CACHE = book
    return book


def reload():
    """Перечитати з диска (для чеків і для правки довідника на ходу)."""
    return load(force=True)


# ---------------------------------------------------------------------------
# ГАЛУЗІ
# ---------------------------------------------------------------------------
def available() -> bool:
    return bool(load().get("available"))


def problem() -> str:
    return load().get("problem") or ""


def domain_ids() -> list:
    """Перелік для `enum` у декларації мозку і для списку в картці клієнта."""
    return list(load().get("order") or [])


def get(domain_id):
    return (load().get("domains") or {}).get(str(domain_id or "").strip())


def is_known(domain_id) -> bool:
    return get(domain_id) is not None


def name_of(domain_id, default="галузь не встановлено") -> str:
    rec = get(domain_id)
    return rec["name"] if rec else default


def gates_of(domain_id) -> tuple:
    rec = get(domain_id)
    return rec["gates"] if rec else ()


def has_gate(domain_id, gate) -> bool:
    """⭐ ГОЛОВНА ФУНКЦІЯ МОДУЛЯ. Ворота вмикає ГАЛУЗЬ, а не слово в тексті.

    Невідома галузь або зіпсований довідник — ворота НЕ вмикаються. Це свідомо:
    доменні ворота, які спрацювали не в своїй галузі, — це і є той дефект, який
    ми лікуємо (юрист відповів водієві про тендери, 11.08.2026)."""
    return gate in gates_of(domain_id)


def stakes_of(domain_id):
    """'high' | 'normal' | None (галузь невідома — вирішує категорія системи)."""
    rec = get(domain_id)
    return rec["stakes"] if rec else None


def evidence_of(domain_id):
    rec = get(domain_id)
    return rec["evidence"] if rec else None


def domain_with_evidence(kind) -> str:
    """Яка галузь має цю тверду очевидність. Потрібно, щоб код міг сказати
    «у тексті є номер UA-… → ведемо як закупівлю» не знаючи назв напам'ять."""
    for did in domain_ids():
        if evidence_of(did) == kind:
            return did
    return ""


def domain_for_category(category) -> str:
    """ЗАПАСНА галузь за НАШОЮ ВЛАСНОЮ міткою категорії системи.

    ⭐ Навіщо. Оголошення галузі може не приїхати: стара автоматизація не знає
    нових полів, провайдер віддав виклик без них. Тоді доменні ворота мовчали б
    там, де вони СПРАВДІ потрібні — наприклад, тендерні строки в тендерній
    системі. Паспорт системи — це НАШ артефакт, а не текст людини, тому читати
    його законно: слово тут І Є сенсом.
    ⚠ Це саме ЗАПАСНИЙ шлях. Оголошення мозку і поправка клієнта сильніші."""
    c = str(category or "").strip().lower()
    if not c:
        return ""
    for did in domain_ids():
        if c in (get(did) or {}).get("categories", ()):
            return did
    return ""


def choices() -> list:
    """[(id, назва)] для картки розуміння. Порядок — як у файлі."""
    return [(d, name_of(d)) for d in domain_ids()]


# ---------------------------------------------------------------------------
# ЮРИСДИКЦІЇ
# ---------------------------------------------------------------------------
def jurisdiction_ids() -> list:
    return list(load().get("jur_order") or [])


def jur(jid):
    return (load().get("jurisdictions") or {}).get(str(jid or "").strip().upper())


def jurisdiction_is_known(jid) -> bool:
    return jur(jid) is not None


def jurisdiction_name(jid, default="") -> str:
    rec = jur(jid)
    return rec["name"] if rec else (default or str(jid or ""))


def portal_of(jid) -> str:
    """Офіційне джерело норм цієї країни. Раніше жило сталою в `executor` —
    тобто ДАНІ лежали в коді, і нова країна вимагала правки коду."""
    rec = jur(jid)
    return rec["portal"] if rec else ""


def jurisdiction_choices() -> list:
    return [(j, jurisdiction_name(j)) for j in jurisdiction_ids()]
