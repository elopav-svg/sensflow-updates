# -*- coding: utf-8 -*-
"""links.py — ОДИН РЕЄСТР ЗВʼЯЗКІВ НА ВСІ ШАРИ ПЛАТФОРМИ (крок B2, 14.08.2026).

⭐⭐⭐ КОРІНЬ. До сьогодні звʼязок був ПОЛЕМ УСЕРЕДИНІ ЗАДАЧІ (`links` у файлі
задачі). Правила жили окремо (`taskdesk_links`) і були зроблені добре — але сам
ФАКТ звʼязку лежав у ВЕРХНЬОМУ шарі. З цього виходили три біди, і жодна не
лікується латкою:

  1. **ЗВОРОТНИЙ БІК — ПЕРЕБІР УСІХ ЗАДАЧ.** Щоб відповісти «хто вказує на мене»,
     доводилось прочитати ВСІ файли задач. На дванадцяти це непомітно; на
     платформі — ні.
  2. **БАЗОВИЙ ШАР ЗАЛЕЖАВ ВІД ВЕРХНІХ.** Щоб картка контакту показала «що з ним
     повʼязано», вона мусила б знати про задачі, угоди й заявки й опитати кожен
     шар окремо. Це перевернута архітектура: контакт живе роками й переживає всі
     верхні шари.
  3. **ЗВʼЯЗОК УМІЛА ЗАВОДИТИ ЛИШЕ ЗАДАЧА.** Угода ↔ контакт, заявка ↔ договір —
     таким звʼязкам не було де лежати. Кожен новий шар довелось би вчити писати
     своє власне поле, і за рік їх стало б стільки ж, скільки шарів.

⛒ ЦЕ ТОЙ САМИЙ КЛАС, ЩО Й У B1: **факт про звʼязок двох сутностей не є власністю
жодної з них.** Тому він переїжджає у власний реєстр — так само, як історія
спілкування переїхала з картки-угоди на контакт.

СІМ РІШЕНЬ, ЗА ЯКІ ВІДПОВІДАЮ (проєкт B2, розділ B2.2):

 1. **ЗВʼЯЗОК — СТАН, А НЕ ПОДІЯ.** Реєстр — це `json`-стан з атомарним записом
    (як `parties.json`), а не журнал. «Яка задача блокує цю ЗАРАЗ» із журналу
    довелось би відтворювати. У протокол іде САМА ДІЯ звʼязування.
 2. **ЗАПИС ЛЕЖИТЬ РІВНО ОДИН РАЗ.** Зворотний бік не дублюється — він РАХУЄТЬСЯ,
    але тепер не перебором чужих файлів, а прямим запитом до реєстру за `to`.
 3. **ПРАВИЛА ЖИВУТЬ ТУТ.** Словник видів, «лише між задачами», «один батько»,
    перевірка кільця — це правила ЗВʼЯЗКУ, а не задачі. `taskdesk_links` лишається
    тонким викликом і писарем ФОРМУЛЮВАНЬ для екрана (прецедент: `agent._refusal_log`
    → `audit.log_refusal`).
 4. **ЧИТАННЯ СУМІСНЕ.** Назовні звʼязок віддається в ТІЙ САМІЙ формі
    (`{ref, rel, at, by}`), що й лежала у файлі задачі. Екран не переписується —
    той самий прийом, що врятував нас у B1.
 5. **НОВЕ ДІЄСЛОВО В ПРОТОКОЛІ** — `link.created` / `link.removed`: звʼязок тепер
    буває не лише в задачі. Старі рядки `task.linked` / `task.unlinked` лишаються
    у словнику НАЗАВЖДИ і читаються звітом — журнал append-only не переписують.
 6. **ВИДАЛЕНА СУТНІСТЬ НЕ ЛИШАЄ ЖИВИХ ЗВʼЯЗКІВ** (`forget`). Дані не зникають:
    подія лишається в журналі назавжди. Живий звʼязок у нікуди — гірше за його
    відсутність.
 7. **ПРАВО НЕ РОЗШИРЮЄТЬСЯ.** Реєстр прав не вигадує: він приймає `by` від того,
    хто його покликав, і НЕ є другим входом повз ворота задачі.

⛔ ЧОГО ЦЕЙ ФАЙЛ НЕ РОБИТЬ. Він не знає ні про диск задач, ні про диск контактів —
хто така сутність, питає `entity`. Другого довідника не заводимо: саме на ДВОХ
ПИСАРЯХ ОДНІЄЇ ПРАВДИ ми горіли найчастіше.

Файл: `state/links.json` (тека живого стану — клієнту не їде, його власний не
затирає). Шлях лежить у змінній модуля: чек підміняє її й не сміє писати в бойову
теку — той самий прийом, що з `audit._PATH`, `parties.PARTIES_JSON`, `protocol._PATH`.
"""

import json
import re

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import entity                     # спільне імʼя сутності на всю платформу
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій (хребет)

_DIR = config.STATE_DIR / "state"
LINKS_JSON = _DIR / "links.json"

# Наш власний номер задачі. Голий «T-000006» — не здогадка про форму, а НАШ
# формат: і людина на екрані, і старе поле `links` писали саме так.
TASK_NUM = re.compile(r"^T-\d{6}$")

MAX_WALK = 500                    # межа обходу: зіпсований реєстр не сміє повісити сервер


class LinkError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


# ── ЗАКРИТИЙ СЛОВНИК ВИДІВ ЗВʼЯЗКУ ───────────────────────────────────────────
# Новий вид заводиться ТУТ, свідомо. Вид, якого немає в словнику, не можна ні
# оголосити, ні заборонити — і тоді замість нього мовчки підставляється сусідній
# (урок зміни 162). Три питання, на які відповідає звʼязок: «частина чого це?»,
# «хто на кого чекає?», «кого/чого це стосується?».
REL_SUBTASK_OF = "subtask_of"   # ця сутність — ЧАСТИНА тієї
REL_BLOCKS = "blocks"           # ця ТРИМАЄ ту: доки не зроблена — та чекає
REL_ABOUT = "about"             # ця СТОСУЄТЬСЯ тієї (клієнт, прогін, система)
# ⭐⭐⭐ КРОК B5 (15.08.2026): людина ПРАЦЮЄ В компанії. Четверте питання, на яке
# відповідає звʼязок: «де ця людина працює / хто в цій компанії наша людина».
# Заводиться ТУТ, а не в довіднику: контактна особа перестала бути полем картки
# і стала таким самим контрагентом, тому звʼязувати їх мусить спільний реєстр.
REL_WORKS_AT = "works_at"       # ця ЛЮДИНА працює в тій КОМПАНІЇ

# ⭐⭐⭐ КРОК C1 (15.08.2026): угода стала сутністю — і в неї зʼявились два власні
# питання, на які «стосується» відповісти НЕ МОЖЕ. «Хто клієнт цієї угоди» —
# це не «стосується»: клієнт рівно один, і без нього угоди не буває. «Хто в цій
# угоді контактна особа» — теж окреме питання: директор і бухгалтер в одній
# угоді — нормальна робота, а не виняток (правка проєкту за зразком, C3 v2).
REL_DEAL_WITH = "deal_with"     # ця УГОДА — з тією КОМПАНІЄЮ (рівно одна)
REL_DEAL_PERSON = "deal_person" # у цій УГОДІ бере участь ця ЛЮДИНА (скільки треба)

# ⭐⭐⭐ КРОК D1 (15.08.2026): ХТО ВЕДЕ ЦЬОГО КЛІЄНТА. Слово Андрія:
# «фільтр, який дозволить відібрати клієнтів по конкретному менеджеру та
# перезакріпити відповідального у випадку звільнення менеджера». Поки
# «хто веде» — це ПІДПИС РЯДКОМ у картці, і фільтр, і масове
# перезакріплення — це пошук-заміна по імені, і ПЕРШИЙ Ж ТЕЗКА все
# ламає. Тому відповідальний живе тут — у спільному реєстрі звʼязків.
REL_MANAGED_BY = "managed_by"   # цього КОНТРАГЕНТА веде та ЛЮДИНА (рівно одна)

RELS = (REL_SUBTASK_OF, REL_BLOCKS, REL_ABOUT, REL_WORKS_AT,
        REL_DEAL_WITH, REL_DEAL_PERSON, REL_MANAGED_BY)

# Людські назви видів. Живуть у СЛОВНИКУ, а не в екрані: відмова реєстру мусить
# називати вид тими самими словами, що й картка, інакше людина побачить дві різні
# назви одного звʼязку.
REL_NAMES = {
    REL_SUBTASK_OF: "підзадача",
    REL_BLOCKS: "блокує",
    REL_ABOUT: "стосується",
    REL_WORKS_AT: "працює в",
    REL_DEAL_WITH: "угода з",
    REL_DEAL_PERSON: "контактна особа угоди",
    REL_MANAGED_BY: "веде",
}

# Підзадача і блокування бувають ЛИШЕ між задачами: «підзадача контрагента» —
# речення без змісту. «Стосується» — навпаки, дивиться на будь-яку сутність.
TASK_ONLY = (REL_SUBTASK_OF, REL_BLOCKS)

# Скільки батьків може мати задача. Один. Дерево з двома батьками — не дерево,
# і жоден звіт «що входить у цю роботу» на ньому не сходиться.
ONE_PARENT = (REL_SUBTASK_OF,)

# «Працює в» буває лише між контрагентами: «задача працює в задачі» — беззмістовно.
# ⚠ А ось ТИП контрагента (людина / компанія) тут НЕ перевіряється, і це свідомо:
# 15.08.2026 на диску 21 картка з 22 не має типу взагалі. Жорстка перевірка
# «лише фізособа → лише компанія» заблокувала б переїзд живих даних і змусила б
# код ВГАДУВАТИ тип за назвою. Вгадувати — не наша робота (урок 162).
PARTY_ONLY = (REL_WORKS_AT,)

# ⭐ КРОК C1: обидва види угоди ведуть ВІД УГОДИ ДО КОНТРАГЕНТА і тільки так.
# «Угода з задачею» або «контактна особа прогону» — речення без змісту, а мовчки
# прийнятий такий рядок зробив би картку угоди нечитабельною.
DEAL_TO_PARTY = (REL_DEAL_WITH, REL_DEAL_PERSON)

# ⭐ D1: «веде» — єдиний вид, який йде ВІД контрагента ДО ЛЮДИНИ
# платформи (`person:<працівник>`). Саме тому його не можна було
# сховати в `PARTY_ONLY` (там обидва боки — контрагенти): відповідальний
# — не контрагент, а НАША людина, і плутати це значило б дозволити
# «клієнта веде інший клієнт».
PARTY_TO_PERSON = (REL_MANAGED_BY,)

# Скільки компаній-клієнтів може мати угода. Одна. Угода з двома клієнтами — це
# дві угоди, і жодна воронка на такій сутності не сходиться (рішення Р2 проєкту C1).
ONE_TARGET = (REL_DEAL_WITH,)

# Скільки відповідальних може бути в клієнта. ОДИН. Двоє — і будь-яке
# «клієнти менеджера Х» починає рахувати одного клієнта двічі, а масове
# перезакріплення перестає бути визначеною дією.
ONE_MANAGER = (REL_MANAGED_BY,)

# ⭐ ПІДПИС НА ЗВʼЯЗКУ (крок B5, рішення Андрія 15.08.2026): посада живе на
# ЗВʼЯЗКУ, а не на картці людини. Доказ із живих даних: Одинцов Ілля — директор
# ТОВ «КАСПЕР УКРАЇНА» І радник міністра одночасно. Посада на картці означала б
# або втрату однієї з двох, або другий дубль людини.
# ⛒ Це КОРОТКИЙ підпис, а не поле для тексту: реєстр звʼязків не стає сховищем
# нотаток. Довше — відмова словами, а не тиха обрізка.
MAX_NOTE = 160


def _s(v) -> str:
    return "" if v is None else str(v).strip()


# ── СЛОВНИК І ПОСИЛАННЯ ──────────────────────────────────────────────────────
def check_rel(rel) -> str:
    """Вид звʼязку зі словника — або відмова з переліком відомих."""
    r = _s(rel)
    if r not in RELS:
        raise LinkError(
            "Невідомий вид звʼязку «%s». Платформа знає лише: %s."
            % (r, ", ".join("%s (%s)" % (x, REL_NAMES[x]) for x in RELS)))
    return r


def check_ref(ref, rel: str) -> str:
    """Нормалізоване посилання потрібного виду — або відмова словами."""
    raw = _s(ref)
    if TASK_NUM.match(raw):
        raw = entity.ref(entity.KIND_TASK, raw)
    try:
        value = entity.norm(raw)
    except Exception as ex:
        raise LinkError("Звʼязок нікуди не веде: %s" % ex)
    if rel in TASK_ONLY and entity.kind_of(value) != entity.KIND_TASK:
        raise LinkError(
            "Звʼязок «%s» буває лише між задачами, а «%s» — це %s."
            % (REL_NAMES[rel], value, entity.KIND_NAMES.get(entity.kind_of(value), "?")))
    if rel in PARTY_ONLY and entity.kind_of(value) != entity.KIND_PARTY:
        raise LinkError(
            "Звʼязок «%s» буває лише між контрагентами, а «%s» — це %s."
            % (REL_NAMES[rel], value, entity.KIND_NAMES.get(entity.kind_of(value), "?")))
    if rel in DEAL_TO_PARTY and entity.kind_of(value) != entity.KIND_PARTY:
        raise LinkError(
            "Звʼязок «%s» веде ДО контрагента, а «%s» — це %s."
            % (REL_NAMES[rel], value, entity.KIND_NAMES.get(entity.kind_of(value), "?")))
    if rel in PARTY_TO_PERSON and entity.kind_of(value) != entity.KIND_PERSON:
        raise LinkError(
            "Звʼязок «%s» веде ДО людини платформи, а «%s» — це %s. "
            "Клієнта веде НАШ працівник, а не запис довідника."
            % (REL_NAMES[rel], value, entity.KIND_NAMES.get(entity.kind_of(value), "?")))
    return value


def check_by(value) -> str:
    """ХТО завів звʼязок — посилання на сутність або ПОРОЖНЬО.

    🩸🩸🩸 КОРІНЬ (знайдено ЖИВИМ прогоном 16.08.2026, зміна 190). Двері
    групових дій поставили сюди ПІДПИС СЛОВАМИ — «менеджер (консоль)». Реєстр
    прийняв його мовчки, бо `by` ніхто не перевіряв на запису. А читач картки
    контрагента цей рядок розбирає як посилання — і картки p0016 та p0017
    перестали ВІДКРИВАТИСЬ узагалі, з відмовою про «вид перед двокрапкою».

    ⛒ СХОВИЩЕ, ЯКЕ ПРИЙМАЄ ТЕ, ЧОГО НЕ ПРОЧИТАЄ ЙОГО ВЛАСНИЙ ЧИТАЧ, — ЦЕ МІНА
    З ВІДКЛАДЕНИМ ПІДРИВОМ: запис проходить зелено, а ламається геть інше
    місце й іншого дня. Тому ворота стоять ТУТ, на записі, а не в читача:
    полагодити одного читача означало б лишити міну для наступного.

    ⚠ Порожньо — законно: дію міг зробити не «хтось із людей платформи»
    (міграція, автоматичний розбір пошти), і вигадувати діяча гірше, ніж
    чесно промовчати."""
    b = _s(value)
    if not b:
        return ""
    if not entity.is_ref(b):
        raise LinkError(
            "«%s» не годиться як той, хто завів звʼязок: тут очікується "
            "ПОСИЛАННЯ на сутність (напр. «person:emp-0d0f191f»), а не підпис "
            "словами. Якщо діяча назвати нема ким — лишайте порожньо." % b)
    return b


def check_note(note, rel: str = "") -> str:
    """Підпис звʼязку (посада) — короткий рядок або порожньо.

    ⚠ Обрізати мовчки не можна: людина побачила б у картці не те, що вписала,
    і жодне слово про це не сказали б."""
    text = _s(note)
    if len(text) > MAX_NOTE:
        raise LinkError(
            "Підпис звʼязку задовгий: %d знаків, а можна щонайбільше %d. "
            "Це підпис (наприклад посада), а не місце для нотатки."
            % (len(text), MAX_NOTE))
    return text


# ── СХОВИЩЕ ──────────────────────────────────────────────────────────────────
def _blank() -> dict:
    return {"seq": 0, "links": []}


def _load() -> dict:
    try:
        d = json.loads(LINKS_JSON.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("seq", 0)
    if not isinstance(d.get("links"), list):
        d["links"] = []
    return d


def _save(d: dict) -> None:
    """Атомарний запис: або старий файл цілий, або новий цілий. Половини не буває."""
    LINKS_JSON.parent.mkdir(parents=True, exist_ok=True)
    tmp = LINKS_JSON.with_name(LINKS_JSON.name + ".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(LINKS_JSON)


def _clean_row(raw) -> dict:
    """Рядок реєстру в канонічній формі — або None, якщо він не читається.

    ⚠ Нечитабельний рядок НЕ ГЛУШИТЬСЯ: він не потрапляє в роботу, але його
    видно в `problems()`. Втрата без жодного слова про неї вбиває продукт."""
    if not isinstance(raw, dict):
        return None
    try:
        rel = check_rel(raw.get("rel"))
        return {
            "id": _s(raw.get("id")),
            "from": entity.norm(raw.get("from")),
            "rel": rel,
            "to": check_ref(raw.get("to"), rel),
            "at": _s(raw.get("at")),
            "by": _s(raw.get("by")),
            "note": check_note(raw.get("note"), rel),
        }
    except Exception:
        return None


def _rows(d: dict) -> tuple:
    """(придатні рядки, скарги на непридатні)."""
    good, bad = [], []
    for raw in (d.get("links") or []):
        row = _clean_row(raw)
        if row is None:
            bad.append(json.dumps(raw, ensure_ascii=False)[:200])
        else:
            good.append(row)
    return good, bad


def problems() -> list:
    """Рядки реєстру, які не прочитались. Мовчати про них не можна."""
    return _rows(_load())[1]


# ── ЗНІМОК: ОДНЕ ЧИТАННЯ НА ВІДПОВІДЬ ────────────────────────────────────────
class Index(object):
    """Реєстр, прочитаний ОДИН раз і розкладений на обидва боки.

    ⭐ Саме цей клас прибирає перебір усіх задач: «хто вказує на мене» — це тепер
    звертання до готового словника, а не читання чужих файлів.

    ⚠ ЗНІМОК НЕ КЕШУЄТЬСЯ МІЖ ВИКЛИКАМИ. Спільний стан у памʼяті процесу вже
    змушував наші чеки брехати: диск міняється, а памʼять показує вчорашнє.
    Хто хоче свіжого — питає `index()` заново; хто хоче дешево — передає знімок
    униз явно."""

    def __init__(self, rows):
        self.rows = list(rows or [])
        self._out, self._inc = {}, {}
        for r in self.rows:
            self._out.setdefault(r["from"], []).append(r)
            self._inc.setdefault(r["to"], []).append(r)

    @staticmethod
    def _view(rows, key: str) -> list:
        """Форма, у якій звʼязок жив у файлі задачі. Екран не переписуємо."""
        return [{"ref": r[key], "rel": r["rel"], "at": r["at"], "by": r["by"],
                 "note": r.get("note", "")}
                for r in rows]

    def out(self, ref) -> list:
        """Куди веде ця сутність."""
        return self._view(self._out.get(_s(ref), []), "to")

    def inc(self, ref) -> list:
        """Хто вказує НА цю сутність."""
        return self._view(self._inc.get(_s(ref), []), "from")

    def refs_out(self, ref, rel: str = "") -> list:
        r = _s(rel)
        return [x["to"] for x in self._out.get(_s(ref), []) if not r or x["rel"] == r]

    def has(self, frm, rel, to) -> bool:
        return any(x["rel"] == _s(rel) and x["to"] == _s(to)
                   for x in self._out.get(_s(frm), []))

    def touching(self, ref) -> list:
        """Усі рядки, де сутність стоїть хоч якимось боком."""
        me = _s(ref)
        return [r for r in self.rows if r["from"] == me or r["to"] == me]


def index() -> Index:
    """Знімок реєстру одним читанням диска."""
    return Index(_rows(_load())[0])


# ── ЧИТАННЯ ──────────────────────────────────────────────────────────────────
def all_links() -> list:
    return index().rows


def outgoing(ref) -> list:
    return index().out(ref)


def incoming(ref) -> list:
    """⭐⭐⭐ ЗВОРОТНИЙ БІК — ОДИН ЗАПИТ ДО РЕЄСТРУ, А НЕ ПЕРЕБІР ЗАДАЧ."""
    return index().inc(ref)


def has(links, ref, rel) -> bool:
    """Чи є такий звʼязок у ГОТОВОМУ переліку (форма картки). Диска не чіпає."""
    r, value = _s(rel), _s(ref)
    return any(l.get("ref") == value and l.get("rel") == r for l in (links or []))


def refs_of(links, rel: str = "") -> list:
    """Куди ведуть звʼязки з ГОТОВОГО переліку (порожній вид — усі)."""
    r = _s(rel)
    return [l.get("ref") for l in (links or []) if not r or l.get("rel") == r]


# ── ЧИ МОЖНА ЗВʼЯЗАТИ ────────────────────────────────────────────────────────
def _reach(idx: Index, start: str, goal: str, rel: str) -> bool:
    """Чи можна дійти від `start` до `goal` тим самим видом звʼязку.

    ⚠ Обхід іде ЛИШЕ по одному виду: «підзадача» і «блокує» — різні дерева, і
    змішувати їх означало б забороняти те, що дозволено."""
    seen, queue, steps = {start}, [start], 0
    while queue:
        steps += 1
        if steps > MAX_WALK:
            raise LinkError("Ланцюг звʼязків надто довгий — схоже, у реєстрі кільце. "
                            "Розірвіть його вручну.")
        cur = queue.pop(0)
        if cur == goal:
            return True
        for nxt in idx.refs_out(cur, rel):
            if nxt not in seen:
                seen.add(nxt)
                queue.append(nxt)
    return False


def check_add(frm, rel, to, idx: Index = None) -> tuple:
    """Звʼязок або народжується чистим, або не народжується зовсім.

    Окремо від `add` навмисно: переїзд даних мусить УМІТИ спитати «чи можна»,
    не записуючи. Повертає (звідки, вид, куди)."""
    try:
        me = entity.norm(frm)
    except Exception as ex:
        raise LinkError("Звʼязок нізвідки не веде: %s" % ex)
    r = check_rel(rel)
    value = check_ref(to, r)
    idx = index() if idx is None else idx

    # ⭐ D1: «веде» теж йде ВІД контрагента — і судимо це ДО того, як
    # питати про існування: звʼязок не тієї форми лишається беззмістовним
    # незалежно від того, чи живі його кінці.
    if r in (PARTY_ONLY + PARTY_TO_PERSON) and entity.kind_of(me) != entity.KIND_PARTY:
        raise LinkError(
            "Звʼязок «%s» веде ВІД контрагента, а «%s» — це %s."
            % (REL_NAMES[r], me, entity.KIND_NAMES.get(entity.kind_of(me), "?")))
    if value == me:
        _me = entity.human(me)
        raise LinkError("%s не звʼязується сама з собою." % (_me[:1].upper() + _me[1:]))
    if idx.has(me, r, value):
        raise LinkError("Такий звʼязок уже є: %s %s."
                        % (REL_NAMES[r], entity.human(value)))
    if not entity.exists(me):
        raise LinkError("%s не існує — звʼязок вів би нізвідки." % entity.human(me))
    if not entity.exists(value):
        raise LinkError("%s не існує — звʼязок вів би в порожнечу." % entity.human(value))
    if r in DEAL_TO_PARTY and entity.kind_of(me) != entity.KIND_DEAL:
        raise LinkError(
            "Звʼязок «%s» веде ВІД угоди, а «%s» — це %s."
            % (REL_NAMES[r], me, entity.KIND_NAMES.get(entity.kind_of(me), "?")))
    if r in ONE_TARGET and idx.refs_out(me, r):
        raise LinkError(
            "В угоди вже є клієнт: %s. Одна угода — одна компанія-клієнт; угода "
            "з двома клієнтами — це дві угоди."
            % entity.human(idx.refs_out(me, r)[0]))
    if r in ONE_MANAGER and idx.refs_out(me, r):
        raise LinkError(
            "Цього клієнта вже веде %s. Відповідальний рівно один — щоб передати "
            "клієнта, спершу зніміть чинного."
            % entity.human(idx.refs_out(me, r)[0]))
    if r in ONE_PARENT and idx.refs_out(me, r):
        raise LinkError(
            "Задача вже є підзадачею: %s. Одна задача — один батько, інакше "
            "жоден звіт «що входить у цю роботу» не сходиться."
            % entity.human(idx.refs_out(me, r)[0]))
    if r in TASK_ONLY and _reach(idx, value, me, r):
        raise LinkError(
            "Кільце: %s уже %s цю задачу (прямо або через інші). Звʼязок, який "
            "замикається сам на себе, робить порядок робіт невизначеним."
            % (entity.human(value), REL_NAMES[r]))
    return me, r, value


# ── ЗАПИС ────────────────────────────────────────────────────────────────────
def _next_id(d: dict) -> str:
    d["seq"] = int(d.get("seq") or 0) + 1
    return "L-%06d" % d["seq"]


def _to_protocol(action: str, row: dict, note: str) -> None:
    """ТОЧКА ВРІЗКИ — РЕЄСТР ЗВʼЯЗКІВ (крок B2).

    ⭐ ДРУГА СУТНІСТЬ ЙДЕ В `about` — саме цим «покажи все про Каспера» починає
    бачити звʼязки. Без неї рядок сказав би «щось звʼязали».
    ⚠ Ніколи не кидає: реєстр уже на диску."""
    try:
        actor = _s(row.get("by"))
        if actor and entity.kind_of(actor) != entity.KIND_PERSON:
            actor = ""          # діячем може бути лише людина або система
        protocol.write(action, row["from"], actor=actor, about=[row["to"]], note=note)
    except Exception:
        pass


def add(frm, rel, to, by: str = "", note: str = "") -> dict:
    """Завести звʼязок. `by` — посилання на ЛЮДИНУ (`person:…`), яку дав викликач.
    `note` — короткий підпис звʼязку (наприклад посада для «працює в»).

    ⛒ ПРАВА ТУТ НЕ ПЕРЕВІРЯЮТЬСЯ І НЕ ВИГАДУЮТЬСЯ: реєстр не є другим входом
    повз ворота задачі. Хто має право правити сутність — той її і звʼязує, і це
    судить власник сутності перед викликом."""
    d = _load()
    good, _bad = _rows(d)
    me, r, value = check_add(frm, rel, to, Index(good))
    signature = check_note(note, r)
    actor = check_by(by)
    row = {"id": _next_id(d), "from": me, "rel": r, "to": value,
           "at": clock.now(), "by": actor, "note": signature}
    good.append(row)
    d["links"] = good
    _save(d)
    _to_protocol(protocol.A_LINK_CREATED, row,
                 "%s %s%s" % (REL_NAMES[r], entity.human(value),
                              (" · %s" % signature) if signature else ""))
    return dict(row)


def remove(frm, rel, to, by: str = "") -> dict:
    """Прибрати звʼязок. ⚠ Прибирається РІВНО той, який назвали: пара «куди» +
    «який». Видалення, яке вгадує форму, — окремий клас біди (урок 10.08)."""
    d = _load()
    good, _bad = _rows(d)
    me = entity.norm(frm)
    r = check_rel(rel)
    value = check_ref(to, r)
    # ⛒ Ті самі ворота, що й на записі: прибирання теж називає діяча ПОСИЛАННЯМ.
    by = check_by(by)
    gone = [x for x in good if x["from"] == me and x["rel"] == r and x["to"] == value]
    if not gone:
        raise LinkError("У %s немає звʼязку «%s %s» — прибирати нічого."
                        % (entity.human(me), REL_NAMES[r], entity.human(value)))
    _drop = {id(x) for x in gone}
    d["links"] = [x for x in good if id(x) not in _drop]
    _save(d)
    row = dict(gone[0])
    row["by"] = _s(by) or row.get("by", "")
    _to_protocol(protocol.A_LINK_REMOVED, row,
                 "%s %s" % (REL_NAMES[r], entity.human(value)))
    return row


def forget(ref, by: str = "") -> int:
    """⭐ ВИДАЛЕНА СУТНІСТЬ НЕ ЛИШАЄ ЖИВИХ ЗВʼЯЗКІВ — з ОБОХ боків.

    Дані від цього не зникають: кожне прибирання лягає в протокол, а журнал
    append-only памʼятає його назавжди. Живий звʼязок у нікуди гірший за його
    відсутність: він показує людині роботу, якої вже немає."""
    me = _s(ref)
    if not me:
        return 0
    d = _load()
    good, _bad = _rows(d)
    gone = [x for x in good if x["from"] == me or x["to"] == me]
    if not gone:
        return 0
    _drop = {id(x) for x in gone}
    d["links"] = [x for x in good if id(x) not in _drop]
    _save(d)
    for row in gone:
        row = dict(row)
        row["by"] = _s(by) or row.get("by", "")
        _to_protocol(protocol.A_LINK_REMOVED, row,
                     "сутність прибрано — звʼязок «%s» більше ні до чого не веде"
                     % REL_NAMES.get(row["rel"], row["rel"]))
    return len(gone)
