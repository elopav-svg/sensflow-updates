# -*- coding: utf-8 -*-
"""relations.py — ЩО ПОВʼЯЗАНО З СУТНІСТЮ І ЩО З НЕЮ ВІДБУВАЛОСЬ (крок B3, 14.08.2026).

⭐⭐⭐ КОРІНЬ. B2 збудував реєстр, який одним запитом каже «що повʼязано з
`party:p0020`». Хребет (169) веде загальний журнал усіх дій. Але картка контакту
не питала НІ ОДНОГО, НІ ДРУГОГО: розділ «Історія взаємин» показував лише
спілкування, яке людина завела руками. Механізм, якого не кличе жоден екран, —
це нуль (урок 07.08).

⛒ ЦЕЙ ФАЙЛ — ЧИТАЧ. Він нічого не пише і не має власного сховища. Другого
писаря правди не зʼявляється: реєстр звʼязків лишається в `links`, журнал — у
`protocol`, спілкування — у `parties`.

⛒ І ВІН ПРО БУДЬ-ЯКУ СУТНІСТЬ, А НЕ ПРО КОНТАКТ. Питання «що з цим повʼязано і
що з ним відбувалось» однакове для контакту, задачі, угоди й заявки. Окремий
читач під кожен шар — це рівно та біда, від якої лікували B2. Тому B4 (перехід
із картки задачі в картку контакту) візьме цей самий файл, не дописуючи логіки.

ДВА ПИТАННЯ РОЗДІЛЕНІ НАВМИСНО (рішення 12.4.2 проєкту хребта):

  • `related()` — **ЩО ІСНУЄ**: живі картки з реєстру звʼязків, обидва боки.
  • `feed()`    — **ЩО СТАЛОСЬ**: стрічка подій.

Подія незмінна назавжди, а картка живе й міняє стадію. Зліпити їх в одну
структуру означало б або переписувати журнал (append-only не переписують), або
показувати мертві картки як події.

🩸 НАЙНЕБЕЗПЕЧНІШЕ МІСЦЕ ЦЬОГО ФАЙЛА — ПОДВОЄННЯ. `parties.add_history()` пише
запис в історію контакту І рядок у протокол; те саме роблять `note_inbound()` і
надіслане оновлення. Наївне злиття двох джерел показало б КОЖЕН запис
спілкування двічі — тобто збрехало б про обсяг роботи з клієнтом удвічі.
Розвʼязка — `ECHO_ACTIONS` нижче.

🩸 І ДРУГЕ: ЧАС ЧИТАЄТЬСЯ З АРТЕФАКТА, А НЕ З ГОЛОВИ. Серед 92 записів історії
Каспера 91 лежить як `2026-08-12T11:16:41`, а один — як `28.07.2026`. Сортування
рядком зробило б цей один запис найновішою подією назавжди («28…» більше за
«2026…» за буквою). Той самий клас, що й проба бекапу зі зміни 161.
"""

import hashlib

import card_layout                 # склад картки — дані, а не верстка (C3)
import entity                   # спільне імʼя сутності й АДРЕСА її екрана
import links                      # реєстр звʼязків на всі шари (B2)
import parties                    # базовий шар: спілкування з контактом (B1)
import pins                       # закріплені події (C3) — окремий реєстр
import protocol                   # загальний журнал усіх дій (хребет, 169)
import taskdesk_links as link_words   # ОДИН писар формулювань звʼязку


# ── ЩО НЕ БЕРЕТЬСЯ З ПРОТОКОЛУ У СТРІЧКУ ─────────────────────────────────────
# ⛒ ТРИ ДІЄСЛОВА-ЛУНИ. Кожне з них народжується РАЗОМ із записом в історію
# контакту (`parties.add_history` / `parties.note_inbound`), тобто його текст
# уже приїхав у стрічку з боку спілкування. Узяти їх ще й тут — показати ту саму
# подію двічі.
# ⚠ ПЕРЕЛІК ЗАКРИТИЙ І ЛЕЖИТЬ В ОДНОМУ МІСЦІ. Нове дієслово-луна доводиться
# дописати сюди свідомо — мовчки воно не підставиться (урок 162).
# ⛔ ДЕДУПЛІКАЦІЯ ЗА ТЕКСТОМ ЗАБОРОНЕНА: збіг тексту — здогадка, а не факт. Дві
# справжні однакові нотатки в один день зникли б, і ми б цього не побачили.
ECHO_ACTIONS = (
    protocol.A_PARTY_HISTORY,     # ← parties.add_history()
    protocol.A_PARTY_INBOUND,     # ← parties.note_inbound()
    protocol.A_PARTY_UPDATE,      # ← crm._hist(..., action=A_PARTY_UPDATE)
)

# Звідки рядок стрічки. Це не прикраса: за спілкуванням стоїть людина, за дією
# платформи — код, і людина на екрані мусить бачити різницю.
SRC_TALK = "talk"
SRC_PLATFORM = "platform"
SRC_NAMES = {SRC_TALK: "спілкування", SRC_PLATFORM: "платформа"}

# Скільки подій віддаємо за раз. `protocol.about_ref` читає ВЕСЬ журнал на кожен
# запит: сьогодні це 48 рядків, за рік — десятки тисяч. Межа є завжди, і вона
# НАЗИВАЄ СЕБЕ (`total` / `shown`): мовчазне обрізання списку стоїть у нашому
# переліку «що вбиває продукт».
FEED_LIMIT = 50

# ⭐ C3 (15.08.2026): скільки подій показуємо ОДНІЄЮ порцією, поки людина не
# натисне «показати ще». Межа лишається, але тепер за нею є кнопка, а не тиша.
FEED_PAGE = 20

# Людські назви типів запису історії. Словник НЕ закритий і нічого не вигадує:
# на диску поруч лежать і наші коди (`build`, `outbound`), і слова, які Андрій
# писав руками («домовленість», «демо»). Незнайомий тип показується як є.
TALK_TYPE_NAMES = {
    "note": "нотатка",
    "comm": "комунікація",
    "stage": "етап",
    "build": "збірка",
    "update": "оновлення",
    "outbound": "надіслано",
    "inbound": "вхідне",
    "contact": "контактна особа",
    "archive": "архів",
    "restore": "повернуто з архіву",
    "action_done": "дію виконано",
}

# Дата, яку не вдалось прочитати, НЕ мовчить і НЕ стає найновішою.
UNREADABLE_DATE = "дата запису не читається"


def _s(v) -> str:
    return "" if v is None else str(v).strip()


# ── ТОТОЖНІСТЬ ПОДІЇ (крок C3, 15.08.2026) ───────────────────────────────────
def event_key(row: dict) -> str:
    """⭐⭐⭐ ОДИН ПИСАР ТОТОЖНОСТІ ПОДІЇ на всю платформу.

    Закріплення (`pins`) мусить памʼятати, ЯКУ подію людина підняла вгору. А в
    події немає власного номера: ні рядок протоколу, ні запис історії контакту
    його ніколи не мали. Дописати номер заднім числом неможливо — журнал
    append-only не переписують.

    ⛒ ТОМУ ТОТОЖНІСТЬ РАХУЄТЬСЯ З НЕЗМІННОГО ВМІСТУ САМОЇ ПОДІЇ: звідки вона,
    коли сталась, якого типу і що в ній написано. Рядок журналу не міняється
    ніколи — отже, і ключ у нього назавжди той самий. Це не здогадка про форму,
    а відбиток по чотирьох полях, які вже лежать на диску.

    ⚠ ЧЕСНА МЕЖА, ЯКУ КАЖУ ДО РОБОТИ: дві події, у яких збігаються ВСІ ЧОТИРИ
    поля (та сама секунда, те саме джерело, той самий тип, той самий текст), у
    самих даних нерозрізненні — закріплення підніме обидві. Вигадати їм різні
    ключі означало б покластись на порядок рядків у файлі, а він змінюється.

    ⛔ НОМЕР РЯДКА ЯК КЛЮЧ — ЗАБОРОНЕНО: видалили один запис історії — і всі
    закріплення нижче мовчки поїхали на сусідні події."""
    raw = "|".join([
        _s(row.get("source")),
        _s(row.get("at")),
        _s(row.get("kind")),
        _s(row.get("text")),
    ])
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:16]


# ── ЧАС ──────────────────────────────────────────────────────────────────────
def _at(raw) -> str:
    """Одне порівнюване значення часу з ОБОХ форм, які реально лежать на диску.

    Повертає `YYYY-MM-DDTHH:MM:SS` або `""`, якщо форма незнайома. Порожнє — це
    відповідь, а не нуль: рядок із нечитабельною датою піде в кінець стрічки з
    видимою позначкою, а не тихо вгору.

    ⛔ ВГАДУВАННЯ ТУТ НЕМАЄ. Знаємо рівно дві форми, бо рівно дві лежать у
    даних; третя мусить прийти сюди свідомо, а не бути «здогадана» регуляркою."""
    v = _s(raw)
    if not v:
        return ""
    # 2026-08-12T11:16:41 (і 2026-08-12 11:16:41, і сама дата)
    if len(v) >= 10 and v[4] == "-" and v[7] == "-":
        head, sep, tail = v.partition("T")
        if not sep:
            head, sep, tail = v.partition(" ")
        if len(head) == 10 and head[:4].isdigit():
            return head + "T" + ((tail + "00:00:00")[:8] if tail else "00:00:00")
        return ""
    # 28.07.2026 — так писалось до переїзду B1
    if len(v) == 10 and v[2] == "." and v[5] == ".":
        d, m, y = v[:2], v[3:5], v[6:]
        if d.isdigit() and m.isdigit() and y.isdigit():
            return "%s-%s-%sT00:00:00" % (y, m, d)
    return ""


def _sort_key(row: dict) -> str:
    """Свіжіші — вгорі; нечитабельна дата — в КІНЕЦЬ, а не на вершину.

    ⚠ Окремої «ознаки нечитабельності» тут НЕМАЄ навмисно: порожній рядок
    менший за будь-яку дату, тому при сортуванні «свіжіші вгорі» він і так
    опиняється в кінці. Другий захист поверх цього виглядав би несучим, а
    насправді нічого б не тримав — і мутація це показала (зелена мутація 9)."""
    return _s(row.get("at_key"))


# ── ЩО ІСНУЄ ─────────────────────────────────────────────────────────────────
def _decorate(rows, back: bool) -> list:
    out = []
    for row in link_words.decorate(rows, back=back):
        # ⛒ АДРЕСУ Й ЖИТТЯ СУТНОСТІ РАХУЄ ПИСАР ФОРМУЛЮВАНЬ (крок B4). Тут я
        # це робив сам — і поки картка задачі складала адресу по-своєму, у нас
        # було ДВА писарі одного факту. Другого більше немає.
        ref = _s(row.get("ref"))
        kind = _s(row.get("kind"))
        alive = bool(row.get("alive"))
        by = _s(row.get("by"))
        out.append({
            "ref": ref,
            "kind": kind,
            "kind_name": entity.KIND_NAMES.get(kind, ""),
            "ident": entity.ident_of(ref) if entity.is_ref(ref) else ref,
            "title": _s(row.get("title")),
            "rel": _s(row.get("rel")),
            "rel_name": _s(row.get("rel_name")),
            "phrase": _s(row.get("phrase")),
            # ⭐ Крок B5: підпис звʼязку (посада на «працює в», «посередник у
            # переписці» на «стосується»). Він живе на ЗВʼЯЗКУ — тому їде скрізь,
            # де показують звʼязок, а не лише в переліку осіб.
            "note": _s(row.get("note")),
            "side": "in" if back else "out",
            "at": _s(row.get("at")),
            "by": by,
            "by_name": entity.title(by) if by else "",
            "alive": alive,
            "href": _s(row.get("href")),
        })
    return out


def related(ref, idx=None) -> list:
    """ЩО ІСНУЄ: живі картки, повʼязані з цією сутністю, обидва боки.

    ⭐ ОДНЕ ЧИТАННЯ ДИСКА НА ВІДПОВІДЬ (`links.index()`), а не перебір чужих
    файлів. Саме це B2 і купив."""
    me = entity.norm(ref)
    ix = idx or links.index()
    rows = _decorate(ix.out(me), False) + _decorate(ix.inc(me), True)
    rows.sort(key=lambda r: (_at(r.get("at")) or ""), reverse=True)
    return rows


# ── ЩО СТАЛОСЬ ───────────────────────────────────────────────────────────────
def _talk_rows(me: str) -> list:
    """Спілкування з контактом. Для інших видів сутності його не буває — і це
    не порожнеча через помилку, а чесна відповідь: історію спілкування веде
    базовий шар, а не задача."""
    # ⚠ ЦЕ ПАРКАН, А НЕ ЄДИНА ОПОРА: `parties.history` на чужому номері й так
    # віддає порожньо, тому зняття цієї перевірки сьогодні НЕ видно жодним
    # чеком (зелена мутація 7 — неточна, а не діра). Лишаю свідомо: коли
    # зʼявиться шар угоди зі своїм довідником, саме ця межа не дасть читати
    # історію контакту за номером угоди.
    if entity.kind_of(me) != entity.KIND_PARTY:
        return []
    pid = entity.ident_of(me)
    out = []
    for h in parties.history(pid):
        kind = _s(h.get("type"))
        note = _s(h.get("note"))
        at_raw = _s(h.get("date"))
        at_key = _at(at_raw)
        out.append({
            "at": at_raw,
            "at_key": at_key,
            "source": SRC_TALK,
            "source_name": SRC_NAMES[SRC_TALK],
            "kind": kind,
            "kind_name": TALK_TYPE_NAMES.get(kind, kind),
            "text": note,
            "ref": "",
            "href": "",
            "outcome": "",
            "cost_usd": 0.0,
            "warn": "" if at_key else UNREADABLE_DATE,
        })
    return out


def _proto_ref(row: dict, me: str) -> str:
    """Про яку ІНШУ сутність цей рядок — щоб з нього був один клік.

    Береться перше посилання, у якого взагалі є екран. Немає такого — порожньо,
    і рядок лишається текстом."""
    for value in [row.get("subject")] + list(row.get("about") or []):
        v = _s(value)
        if not v or v == me:
            continue
        if entity.screen(v):
            return v
    return ""


def _proto_rows(me: str) -> list:
    out = []
    for r in protocol.about_ref(me):
        action = _s(r.get("action"))
        if action in ECHO_ACTIONS:
            continue                      # ⛒ луна історії — вона вже у стрічці
        at_raw = _s(r.get("at"))
        at_key = _at(at_raw)
        ref = _proto_ref(r, me)
        outcome = _s(r.get("outcome"))
        note = _s(r.get("note"))
        reason = _s(r.get("reason"))
        # 🩸 НАЗВА ДІЇ ЖИВЕ В ОДНОМУ ПОЛІ, А НЕ В ДВОХ. Спершу я клав її і в
        # `kind_name`, і на початок тексту — і на екрані вийшло «сутності
        # звʼязано · сутності звʼязано: стосується…». Побачив ЛИШЕ прочитавши
        # готовий рядок очима, бо жоден чек про красу не питає.
        text = note
        if reason:
            text = (text + " — " + reason) if text else reason
        who = _s(r.get("actor"))
        out.append({
            "at": at_raw,
            "at_key": at_key,
            "source": SRC_PLATFORM,
            "source_name": SRC_NAMES[SRC_PLATFORM],
            "kind": action,
            "kind_name": protocol.ACTIONS.get(action, action),
            "text": text,
            "ref": ref,
            "href": entity.screen(ref) if ref else "",
            "ref_title": entity.title(ref) if ref else "",
            "outcome": outcome,
            "outcome_name": protocol.OUTCOME_NAMES.get(outcome, outcome),
            "by": who,
            "by_name": entity.title(who) if who else "",
            "cost_usd": float(r.get("cost_usd") or 0.0),
            "warn": "" if at_key else UNREADABLE_DATE,
        })
    return out


def _int(v, default: int) -> int:
    try:
        return int(v)
    except Exception:
        return default


def _vocab(rows: list, field: str, name_field: str) -> list:
    """Що взагалі є у стрічці цієї сутності — щоб фільтр пропонував лише реальне.

    ⛒ ФІЛЬТР ЛИШЕ ЗВУЖУЄ (той самий закон, що на дошці задач). Пункт, якого в
    даних немає, у переліку не зʼявляється: вибір, який завжди дає порожньо, —
    це обіцянка, якої платформа не виконує."""
    order, seen = [], {}
    for r in rows:
        key = _s(r.get(field))
        if not key:
            continue
        if key not in seen:
            seen[key] = {"id": key, "name": _s(r.get(name_field)) or key, "n": 0}
            order.append(key)
        seen[key]["n"] += 1
    return [seen[k] for k in order]


def feed(ref, limit: int = FEED_LIMIT, offset: int = 0, source: str = "",
         kind: str = "", about: str = "", since: str = "", until: str = "") -> dict:
    """ЩО СТАЛОСЬ: спілкування + дії платформи, злиті за часом.

    ⛒ МЕЖА НАЗИВАЄ СЕБЕ. `total` — скільки подій усього, `matched` — скільки
    лишив фільтр, `shown` — скільки віддано зараз, `cut` — скільки ще за кнопкою.

    ⭐ C3: три ліки від простині, і всі три — тут, а не на екрані. Екран лише
    показує те, що порахував цей файл: інакше два екрани (консоль і майбутній
    телеграм) порахували б «показано N із M» по-різному.

      • ЗАКРІПЛЕНІ (`pinned`) — рахуються з УСІХ подій, до фільтра й до сторінки;
      • ФІЛЬТР — за джерелом, типом, повʼязаною сутністю і датами;
      • СТОРІНКА — `offset` + `limit`, решта лишається за «показати ще».

    🩸 ЗАКРІПЛЕНА ПОДІЯ НЕ ПОКАЗУЄТЬСЯ ДВІЧІ. Вона піднімається вгору й зі
    звичайної стрічки прибирається: та сама подія у двох місцях одного екрана —
    це рівно те подвоєння, від якого лікував B3, тільки іншим боком."""
    me = entity.norm(ref)
    rows = _talk_rows(me) + _proto_rows(me)
    rows.sort(key=_sort_key, reverse=True)
    # ⛒ Ключ проставляє ОДНЕ місце — інакше закріплення й стрічка порахували б
    # тотожність події по-різному.
    for r in rows:
        r["key"] = event_key(r)

    total = len(rows)
    sources = _vocab(rows, "source", "source_name")
    kinds = _vocab(rows, "kind", "kind_name")
    # ⛒ «ПРО КОГО» БЕРЕТЬСЯ ЗІ СТРІЧКИ, А НЕ З ПЕРЕЛІКУ ЗВʼЯЗКІВ. Це різні
    # множини: у стрічці згадується й те, з чим картка не звʼязана (прогін,
    # система), а звʼязана сутність може не мати жодної події. Взявши перелік
    # звʼязків, ми пропонували б вибір, який дає порожньо, — і людина вирішила б,
    # що дані загубились.
    refs = _vocab(rows, "ref", "ref_title")

    # ── Закріплені: до фільтра й до сторінки ─────────────────────────────────
    pin_keys = pins.keys(me)
    by_key = {}
    for r in rows:
        by_key.setdefault(r["key"], r)
    pinned = [by_key[k] for k in pin_keys if k in by_key]
    # ⛒ Закріплення, під яке події вже не знайшлось, НЕ зникає мовчки: запис
    # історії могли прибрати руками, і людина мусить бачити, що її позначка
    # осиротіла, а не гадати, куди поділась подія.
    pin_lost = len([k for k in pin_keys if k not in by_key])
    pinned_set = set(k for k in pin_keys if k in by_key)

    # ── Фільтр ───────────────────────────────────────────────────────────────
    f_source, f_kind = _s(source), _s(kind)
    f_about = entity.norm(about) if _s(about) else ""
    f_since, f_until = _s(since), _s(until)
    undated_hidden = 0
    kept = []
    for r in rows:
        if r["key"] in pinned_set:
            continue                       # закріплене показуємо окремо, і лише раз
        if f_source and _s(r.get("source")) != f_source:
            continue
        if f_kind and _s(r.get("kind")) != f_kind:
            continue
        if f_about and _s(r.get("ref")) != f_about:
            continue
        if f_since or f_until:
            at = _s(r.get("at_key"))
            if not at:
                # ⛒ Подія з нечитабельною датою під фільтр дат не підпадає — і ми
                # кажемо, скільки таких сховалось. Тихо викинути її означало б
                # приховати саме те, що вже раз нас підвело (урок B3 про «28.07»).
                undated_hidden += 1
                continue
            if f_since and at[:len(f_since)] < f_since:
                continue
            if f_until and at[:10] > f_until[:10]:
                continue
        kept.append(r)

    matched = len(kept)
    off = max(0, _int(offset, 0))
    n = _int(limit, FEED_LIMIT)
    page = kept[off:] if n <= 0 else kept[off:off + n]
    return {
        "rows": page,
        "total": total,
        "matched": matched,
        "shown": len(page),
        "offset": off,
        "cut": max(0, matched - off - len(page)),
        "has_more": (off + len(page)) < matched,
        "pinned": pinned,
        "pin_count": len(pinned),
        "pin_limit": pins.LIMIT,
        "pin_lost": pin_lost,
        "undated_hidden": undated_hidden,
        "filter": {"source": f_source, "kind": f_kind, "about": f_about,
                   "since": f_since, "until": f_until},
        "filtered": bool(f_source or f_kind or f_about or f_since or f_until),
        "sources": sources,
        "kinds": kinds,
        "refs": refs,
        # Чесна межа, яку розділ каже вголос: журнал платформи почався пізніше
        # за спілкування, і старіші дії в нього не переносились.
        "protocol_since": _s(_first_protocol_at()),
    }


def _first_protocol_at() -> str:
    """З якого дня взагалі існує журнал платформи.

    ⚠ `protocol.read(limit=N)` віддає ОСТАННІ N рядків — тому тут межі немає:
    потрібен саме ПЕРШИЙ рядок. Узяти `limit=1` означало б показати найновішу
    дату як «журнал ведеться з…», тобто збрехати рівно навпаки."""
    rows = protocol.read()
    return _s(rows[0].get("at")) if rows else ""


# ── УСЕ РАЗОМ ────────────────────────────────────────────────────────────────
def card(ref, limit: int = FEED_LIMIT, **flt) -> dict:
    """Розділ «Історія взаємовідносин» одним читанням: дві частини, не змішані.

    ⭐ C3: сюди ж їде СКЛАД картки (`card_layout`). Екран не складає його сам —
    інакше консоль і майбутній телеграм показали б різні картки однієї сутності.

    ⛒ СКЛАДУ НЕМАЄ — КАЖЕМО СЛОВАМИ, А НЕ ВІДДАЄМО ПОРОЖНЄ. Порожній склад
    виглядав би на екрані як «даних немає», і людина повірила б."""
    me = entity.norm(ref)
    kind = entity.kind_of(me)
    out = {
        "ref": me,
        "kind": kind,
        "title": entity.title(me),
        "href": entity.screen(me),
        "related": related(me),
        "feed": feed(me, limit, **flt),
    }
    try:
        out["layout"] = card_layout.view(kind)
    except card_layout.CardLayoutError as ex:
        out["layout"] = None
        out["layout_error"] = str(ex)
    return out
