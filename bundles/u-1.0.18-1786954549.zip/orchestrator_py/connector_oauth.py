# -*- coding: utf-8 -*-
"""ДВЕРІ ДО ЧУЖОГО СЕРВІСУ (OAuth) — ОДИН ПИСАР.

⭐⭐⭐ 12.08.2026 (зміна 163). Крок 2 конекторів.

Зміна 162 навчила платформу ЧЕСНО КАЗАТИ, що входу немає
(`registry.REQUIRABLE_INPUTS`). Цей модуль дає САМ ВХІД: спосіб отримати
згоду людини на її ж пошту/календар і зберегти токен так, щоб його побачили
ворота, які вже стоять.

⛒ ЧОМУ ОДИН ПИСАР. Правда про двері складається з чотирьох речей, і кожна
вміє розійтися зі своїм близнюком:
  • ФОРМА АДРЕСИ ПОВЕРНЕННЯ — її будує і кнопка «Підключити», і обробник
    повернення. Різні рядки = `redirect_uri_mismatch` (клас «два писарі
    однієї правди»).
  • ШЛЯХ ФАЙЛА ТОКЕНА — сюди ПИШЕ цей модуль, а ЧИТАЄ `registry`
    (`connector_ready` → ворота збірки, запуску і самомодель). Писар шляху
    тут один: `token_path()`.
  • ПРАВА (scopes) — що саме дозволила людина.
  • МЕЖА ПРОВАЙДЕРА — те, чого ми не можемо змінити (див. `caveat`).

⛒ НОВИЙ КОНЕКТОР = НОВИЙ РЯДОК У `DOORS`, і більше нічого правити не треба:
ендпоінти сервера і картка в консолі загальні, по `id`.

Жодних зовнішніх залежностей.
"""

import json
import secrets
import time
import urllib.parse
import urllib.request

import config
import features


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЦЕ ПЛАТНИЙ РІВЕНЬ (слово Андрія 12.08.2026)
# ---------------------------------------------------------------------------
# «Конектори — частина Task Desk і окремий рівень автоматизації, і тому поїде до
# клієнта виключно за гроші. Робимо на моїй машині, на клієнтів не поширюємо.»
#
# ⛒ ВИМКНЕНА РІЧ НЕ МУСИТЬ СВІТИТИСЬ У КЛІЄНТА НАВІТЬ КАРТКОЮ. Побачити двері,
# яких у тебе немає, — це та сама обіцянка відсутнього, від якої лікувалась
# зміна 162, і водночас безкоштовний показ платного.
# ⛒ Вимикач НЕ свій: той самий один писар, що тримає Task Desk
# (`features.enabled`), і за замовчуванням ВИМКНЕНО скрізь, включно з еталоном.
WORK_ID = "connectors_oauth"


def enabled() -> bool:
    """ЄДИНА відповідь «чи цей рівень куплено/увімкнено»."""
    return features.enabled(WORK_ID)


# ---------------------------------------------------------------------------
# ПРОВАЙДЕРИ — чиї це двері й де вони стоять
# ---------------------------------------------------------------------------
PROVIDERS = {
    "google": {
        "name": "Google",
        "auth_endpoint": "https://accounts.google.com/o/oauth2/v2/auth",
        "token_endpoint": "https://oauth2.googleapis.com/token",
        "client_id_key": "GOOGLE_OAUTH_CLIENT_ID",
        "client_secret_key": "GOOGLE_OAUTH_CLIENT_SECRET",
        # Що зробити людині, якщо ключів немає. Пишемо ДІЮ, а не назву біди.
        "setup": ("У Google Cloud створіть OAuth-клієнт типу «Desktop app», "
                  "увімкніть потрібні API і впишіть GOOGLE_OAUTH_CLIENT_ID та "
                  "GOOGLE_OAUTH_CLIENT_SECRET у файл .env.local у корені платформи."),
        # 🩸 МЕЖА, ПРО ЯКУ ПЛАТФОРМА МУСИТЬ СКАЗАТИ САМА, а не показати через
        # тиждень порожньою скринькою. Джерело — документація Google
        # (developers.google.com/identity/protocols/oauth2, розділ про строк
        # життя): застосунок зі статусом «Testing» і зовнішнім типом
        # користувача отримує refresh-токен, який живе 7 днів. Також згода
        # злітає, коли людина міняє пароль Google (для прав Gmail).
        "caveat": ("Поки застосунок у Google має статус «Testing», згода живе 7 днів — "
                   "після цього підключення треба буде повторити. Згода також злітає, "
                   "якщо змінити пароль Google."),
    },
}


# ---------------------------------------------------------------------------
# ДВЕРІ — який конектор які права просить
# ---------------------------------------------------------------------------
# ⛒ Права просимо НАЙВУЖЧІ, які покривають обіцянку. «Прочитати листи» — це
# `gmail.readonly`: платформа не може ні надіслати, ні видалити нічого.
DOORS = {
    "google_mail": {
        "provider": "google",
        "scopes": ["https://www.googleapis.com/auth/gmail.readonly"],
        "grants": "читати ваші листи (надсилати чи видаляти платформа не зможе)",
    },
    "google_calendar": {
        "provider": "google",
        "scopes": ["https://www.googleapis.com/auth/calendar.events"],
        "grants": "бачити і створювати події у вашому календарі",
    },
}


# ---------------------------------------------------------------------------
# Шляхи на диску (ОДИН писар)
# ---------------------------------------------------------------------------
def token_path(connector_id: str):
    """Де лежить токен конектора. ⭐ Той самий шлях ЧИТАЄ `registry`."""
    return config.CONNECTORS_DIR / ("%s.token.json" % connector_id)


def _state_path(connector_id: str):
    return config.CONNECTORS_DIR / ("%s.oauth_state.json" % connector_id)


def _read_json(path, default=None):
    try:
        raw = path.read_text(encoding="utf-8-sig")
        return json.loads(raw)
    except Exception:
        return default


def _write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Стан дверей
# ---------------------------------------------------------------------------
def has_door(connector_id: str) -> bool:
    """Чи вміє платформа взагалі відмикати цей конектор."""
    return str(connector_id or "") in DOORS


def _provider(connector_id: str):
    door = DOORS.get(str(connector_id or ""))
    if not door:
        return None, None
    return door, PROVIDERS.get(door["provider"])


def credentials(connector_id: str):
    """(client_id, client_secret) з .env.local. Порожньо = дверей ще нема чим відмикати."""
    door, prov = _provider(connector_id)
    if not prov:
        return "", ""
    cid = str(config.ENV.get(prov["client_id_key"], "") or "").strip()
    sec = str(config.ENV.get(prov["client_secret_key"], "") or "").strip()
    return cid, sec


def configured(connector_id: str) -> bool:
    cid, sec = credentials(connector_id)
    return bool(cid and sec)


def redirect_uri(connector_id: str) -> str:
    """⭐ ОДИН ПИСАР ФОРМИ АДРЕСИ ПОВЕРНЕННЯ.

    Її мусять однаково знати троє: кнопка (тут), обробник повернення в сервері
    і сам Google. Порт беремо з `config.PORT`, а не з голови: у клієнта він
    може бути інший. Саме тому OAuth-клієнт узятий типу «Desktop» — Google для
    адреси 127.0.0.1 НЕ звіряє порт (перевірено живим 12.08.2026).
    """
    return "http://127.0.0.1:%d/api/connectors/%s/oauth/callback" % (
        int(config.PORT), connector_id)


def caveat(connector_id: str) -> str:
    _door, prov = _provider(connector_id)
    return (prov or {}).get("caveat", "")


def grants(connector_id: str) -> str:
    door, _prov = _provider(connector_id)
    return (door or {}).get("grants", "")


def setup_hint(connector_id: str) -> str:
    _door, prov = _provider(connector_id)
    return (prov or {}).get("setup", "")


def connected_at(connector_id: str) -> str:
    return str((_read_json(token_path(connector_id), {}) or {}).get("connected_at") or "")


# ---------------------------------------------------------------------------
# КРОК 1: почати
# ---------------------------------------------------------------------------
def start(connector_id: str):
    """→ (адреса згоди, помилка). Помилка — ТЕКСТ ЛЮДИНІ, не код."""
    if not enabled():
        return "", "Цей рівень автоматизації у вашій збірці не підключено."
    door, prov = _provider(connector_id)
    if not door:
        return "", "Платформа не вміє підключати «%s»." % connector_id
    client_id, client_secret = credentials(connector_id)
    if not (client_id and client_secret):
        return "", ("Підключення не налаштоване. %s" % prov["setup"])

    state = secrets.token_hex(24)
    _write_json(_state_path(connector_id),
                {"state": state, "created_at": _now(), "connector_id": connector_id})

    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri(connector_id),
        "response_type": "code",
        "scope": " ".join(door["scopes"]),
        # ⛒ offline + consent: без них Google не дасть refresh-токена, і зв'язок
        # помре через годину — тихо, вже після того, як ми сказали «підключено».
        "access_type": "offline",
        "prompt": "consent",
        "include_granted_scopes": "true",
        "state": state,
    }
    return (prov["auth_endpoint"] + "?" + urllib.parse.urlencode(params)), ""


# ---------------------------------------------------------------------------
# КРОК 2: завершити
# ---------------------------------------------------------------------------
def finish(connector_id: str, code: str, state: str, error: str = ""):
    """→ (ok, текст людині). Пише токен рівно туди, куди дивляться ворота."""
    if not enabled():
        return False, "Цей рівень автоматизації у вашій збірці не підключено."
    door, prov = _provider(connector_id)
    if not door:
        return False, "Платформа не вміє підключати «%s»." % connector_id
    if error:
        return False, "Авторизацію не завершено: %s." % error

    stored = _read_json(_state_path(connector_id), None) or {}
    if not code or not state or stored.get("state") != state:
        # ⛒ Не «щось пішло не так»: називаємо ПРИЧИНУ і що робити.
        return False, ("Позначку безпеки (state) не впізнано — можливо, вікно згоди "
                       "провисіло надто довго або відкривалось двічі. Натисніть "
                       "«Підключити» ще раз.")
    # Позначка одноразова: другий раз тим самим кодом уже не зайти.
    try:
        _state_path(connector_id).unlink()
    except Exception:
        pass

    client_id, client_secret = credentials(connector_id)
    ok, payload = _post_form(prov["token_endpoint"], {
        "code": code,
        "client_id": client_id,
        "client_secret": client_secret,
        "redirect_uri": redirect_uri(connector_id),
        "grant_type": "authorization_code",
    })
    if not ok:
        return False, payload
    if not payload.get("access_token"):
        return False, "Сервіс не повернув ключа доступу — підключення не відбулось."
    if not payload.get("refresh_token"):
        # ⛒ Без refresh-токена «підключено» протримається годину і тихо помре.
        # Краще чесна відмова зараз, ніж мовчазна поломка завтра.
        return False, ("Сервіс не повернув ключа для продовження доступу. "
                       "Відкрийте myaccount.google.com/permissions, приберіть доступ "
                       "застосунку і натисніть «Підключити» ще раз.")
    _save_token(connector_id, payload)
    return True, ""


def _save_token(connector_id: str, payload: dict, keep_refresh: str = ""):
    data = dict(payload or {})
    if keep_refresh and not data.get("refresh_token"):
        # Google віддає refresh-токен ЛИШЕ першого разу — при оновленні його
        # треба донести самим, інакше наступне оновлення нічим буде робити.
        data["refresh_token"] = keep_refresh
    try:
        data["expires_at"] = int(time.time()) + int(data.get("expires_in") or 0)
    except Exception:
        data["expires_at"] = 0
    data["connector_id"] = connector_id
    data["connected_at"] = _now()
    _write_json(token_path(connector_id), data)
    return data


# ---------------------------------------------------------------------------
# КРОК 3: живий ключ для інструментів
# ---------------------------------------------------------------------------
def access_token(connector_id: str):
    """→ (ключ, помилка). Сам продовжує доступ, коли той протух.

    ⛒ Інструменти НЕ читають файл токена самі: інакше кожен новий інструмент
    мусив би пам'ятати про строк життя — і той, хто забуде, стане дірою.
    """
    door, prov = _provider(connector_id)
    if not door:
        return "", "Платформа не вміє підключати «%s»." % connector_id
    data = _read_json(token_path(connector_id), None)
    if not data or not data.get("access_token"):
        return "", "Конектор не підключено."
    # 60 секунд запасу: ключ, що протухне в польоті, — та сама поломка.
    if int(data.get("expires_at") or 0) > int(time.time()) + 60:
        return str(data["access_token"]), ""

    refresh = str(data.get("refresh_token") or "")
    if not refresh:
        return "", "Доступ протух, а ключа для продовження немає — підключіть конектор заново."
    client_id, client_secret = credentials(connector_id)
    ok, payload = _post_form(prov["token_endpoint"], {
        "refresh_token": refresh,
        "client_id": client_id,
        "client_secret": client_secret,
        "grant_type": "refresh_token",
    })
    if not ok:
        return "", payload
    fresh = _save_token(connector_id, payload, keep_refresh=refresh)
    return str(fresh.get("access_token") or ""), ""


# ---------------------------------------------------------------------------
# Вихід назовні (один прохід, зі слідом)
# ---------------------------------------------------------------------------
def _post_form(url: str, form: dict):
    """→ (ok, дані) або (False, ТЕКСТ ЛЮДИНІ).

    ⛒ Сирий текст помилки сервісу зберігаємо в журналі виходів, а людині
    віддаємо зрозуміле речення (урок 11.08: спершу сирий текст, потім порада).
    """
    body = urllib.parse.urlencode(form).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST", headers={
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
    })
    raw, status = "", 0
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            status = int(getattr(resp, "status", 200) or 200)
            raw = resp.read().decode("utf-8", "replace")
    except Exception as exc:
        raw = getattr(exc, "read", lambda: b"")()
        try:
            raw = raw.decode("utf-8", "replace")
        except Exception:
            raw = ""
        status = int(getattr(exc, "code", 0) or 0)
        _trace(url, status, raw or str(exc))
        return False, _human_error(status, raw, str(exc))
    _trace(url, status, "ok")
    try:
        return True, json.loads(raw)
    except Exception:
        return False, "Сервіс відповів не тим, чого ми чекали — підключення не відбулось."


def _human_error(status: int, raw: str, fallback: str) -> str:
    code = ""
    try:
        code = str((json.loads(raw) or {}).get("error") or "")
    except Exception:
        code = ""
    if code == "invalid_grant":
        return ("Google більше не приймає цю згоду (найчастіше — вона протухла: "
                "у режимі «Testing» згода живе 7 днів). Підключіть конектор заново.")
    if code == "redirect_uri_mismatch":
        return ("Google не впізнав адресу повернення. Перевірте, що OAuth-клієнт "
                "має тип «Desktop app».")
    if code in ("invalid_client", "unauthorized_client"):
        return "Google не впізнав наш застосунок — перевірте ключі в .env.local."
    if status:
        return "Сервіс відмовив (код %d)%s." % (status, (": " + code) if code else "")
    return "Не вдалося звʼязатися з сервісом: %s." % fallback


def _trace(url: str, status: int, note: str):
    try:
        import egress_guard
        egress_guard.log("connector_oauth", {"url": url, "status": status,
                                             "note": (note or "")[:300]})
    except Exception:
        pass


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")
