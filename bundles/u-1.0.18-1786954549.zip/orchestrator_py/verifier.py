"""
verifier.py — quality gate. Перевіряє результат перед видачею користувачу.

Поєднує дешеві детермінthose перевірки (порожнеча, службовий шум, leakage)
з семантичною перевіркою через LLM (чи відповідає результат задачі).
"""

import re
import urllib.request
import urllib.error

import llm
import config
import tools as _toolbox

# ── Перевірка посилань (анти-галюцинація) ─────────────────────────────────
import netfetch as _nf
_URL_RE = _nf.URL_RE           # межа адреси — ОДИН писар (netfetch)
_UA = "Mozilla/5.0 (compatible; AI-Orchestrator-LinkCheck/1.0)"


def _clean_url(u: str) -> str:
    return (u or "").rstrip('.,;:!?»"\'）)】>').strip()


def extract_urls(text: str, limit: int = 12) -> list:
    seen, out = set(), []
    for m in _URL_RE.finditer(text or ""):
        u = _clean_url(m.group(0))
        if u and u not in seen:
            seen.add(u)
            out.append(u)
        if len(out) >= limit:
            break
    return out


def check_url(url: str, timeout: int = 6):
    """Тристанна перевірка: True=жива, False=точно мертва (ЛИШЕ 404/410 — сервер сам
    підтвердив, що сторінки нема), None=невизначено (таймаут/403/блок/DNS-збій — НЕ
    караємо, щоб не таврувати справжні сайти «вигаданими»). Недоступний ≠ вигаданий."""
    def _try(method):
        req = urllib.request.Request(url, method=method, headers={"User-Agent": _UA})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return getattr(r, "status", 200)
    try:
        _try("HEAD")
        return (True, "ok")
    except urllib.error.HTTPError as e:
        if e.code in (404, 410):
            return (False, f"HTTP {e.code}")
        if e.code in (405, 403, 401, 429, 400):  # HEAD не дозволено / блок — пробуємо GET
            try:
                _try("GET")
                return (True, "ok")
            except urllib.error.HTTPError as e2:
                return (False, f"HTTP {e2.code}") if e2.code in (404, 410) else (None, f"HTTP {e2.code}")
            except Exception:
                return (None, "недоступно")
        return (None, f"HTTP {e.code}")
    except urllib.error.URLError as e:
        reason = str(getattr(e, "reason", e)).lower()
        # DNS не розпізнав домен — НЕ вважаємо це доказом фальсифікації. Причиною буває
        # тимчасовий збій мережі/DNS (той самий, що дає таймаути) або артефакт зайвої
        # пунктуації в адресі. Понижуємо до «невідомо» (як таймаут): краще чесне
        # «перевірте вручну», ніж хибне «вигадане» на реальному сайті.
        _ = reason  # (діагностика; на вердикт більше не впливає — усе → None)
        return (None, "недоступно")
    except Exception:
        return (None, "недоступно")


def validate_urls(result: str, known_urls=None, do_network=True) -> dict:
    """Повертає {checked:[{url,status,reason}], dead:[url,...]}.
    status: 'source' (з пошуку) | 'live' | 'dead' | 'unknown'."""
    known = set(known_urls or [])
    checked, dead = [], []
    for u in extract_urls(result):
        if u in known:
            checked.append({"url": u, "status": "source", "reason": "джерело пошуку"})
            continue
        if not do_network:
            checked.append({"url": u, "status": "unknown", "reason": "не перевірено"})
            continue
        ok, reason = check_url(u)
        if ok is True:
            checked.append({"url": u, "status": "live", "reason": reason})
        elif ok is False:
            checked.append({"url": u, "status": "dead", "reason": reason})
            dead.append(u)
        else:
            checked.append({"url": u, "status": "unknown", "reason": reason})
    return {"checked": checked, "dead": dead}


def neutralize_dead_urls(md: str, dead_urls) -> str:
    """Прибирає вигадані/мертві посилання з тексту, лишаючи видиму позначку."""
    out = md or ""
    for u in (dead_urls or []):
        # markdown-лінк [текст](u) -> текст (посилання не підтверджено)
        out = re.sub(r'\[([^\]]+)\]\(\s*' + re.escape(u) + r'[^\)]*\)',
                     r'\1 (посилання не підтверджено — вилучено)', out)
        # голий URL
        out = out.replace(u, "(посилання не підтверджено — вилучено)")
    return out


SERVICE_NOISE = [
    "TASK_FOR_CODEX",
    "task_package.json",
    "[Content_Types].xml",
    "PK",
    "system prompt",
    "AgentSearchData_task",
]


# Mojibake (кракозябри) — наслідок misdecode UTF-8↔cp1251/latin1. Маркери мають бути
# ОДНОЗНАЧНІ: латиниця Ð/Ñ/Ã серед кирилиці не трапляється, «вЂ» — типовий бите-код
# лапок/тире. НЕ вживаємо кирилично-кириличні біграми (напр. «РІ») — вони живуть у
# нормальних великих словах (СТОРІН, СПОРІВ, ВИРІШЕННЯ) і дають ХИБНУ тривогу на
# будь-якому договорі. Караємо лише за КЛАСТЕР (>=2 збіги): реальні кракозябри йдуть
# купою, а не поодиноким збігом.
_MOJIBAKE_MARKERS = ("Ð", "Ñ", "Ã", "вЂ")


def _cheap_checks(task: str, result: str) -> list:
    checks = []
    text = result or ""
    _empty = len(text.strip()) < 20
    checks.append({"label": "Результат не порожній", "ok": not _empty,
                   "reason": ("порожній або надто короткий результат" if _empty else "")})
    noise = next((m for m in SERVICE_NOISE if m in text), None)
    checks.append({"label": "Немає службового шуму / leakage", "ok": noise is None,
                   "reason": (f"службовий маркер «{noise}»" if noise else "")})
    _mj = sum(text.count(m) for m in _MOJIBAKE_MARKERS)
    checks.append({"label": "Немає mojibake-маркерів (кракозябр)", "ok": _mj < 2,
                   "reason": (f"{_mj} маркерів поламаного кодування" if _mj >= 2 else "")})
    return checks


def verify_numbers(task: str, result: str) -> dict:
    """ВЕРИФІКАТОР-БУХГАЛТЕР: незалежно перераховує ключові числа результату через
    ізольований калькулятор (tools.run_python) і порівнює з наведеними (толеранс 1%).
    Повертає {status: 'pass'|'fail'|'skip', note}. 'skip' — чесно «не зміг перевірити»
    (не караємо), 'fail' — числа не сходяться (караємо verified:False)."""
    if not config.provider_ready():
        return {"status": "skip", "note": ""}
    # Інструкція бухгалтеру. Підсилена проти «голих» невизначених імен (корінь бага
    # REPORTED_TOTAL_TIME 14.07): змінні оголошувати, числа з результату — ЛІТЕРАЛАМИ.
    instr = (
        "Ти — бухгалтер-ревізор. Тобі дано ЗАДАЧУ і РЕЗУЛЬТАТ з числами. Напиши "
        "Python-код, який НЕЗАЛЕЖНО перераховує з вхідних даних задачі 1–6 КЛЮЧОВИХ "
        "чисел результату (підсумки, платежі, відсотки, частки — не кожну клітинку), "
        "порівнює їх із числами з результату (впиши їх у код КОНСТАНТАМИ-ЛІТЕРАЛАМИ) з "
        "толерансом 1% і друкує по рядку на перевірку строго у форматі:\n"
        "CHECK <назва>: expected=<перераховане> reported=<з результату> -> OK|FAIL\n"
        "Останнім рядком надрукуй VERDICT: PASS (усі OK) або VERDICT: FAIL (є хоч один "
        "FAIL). Дозволені лише стандартні модулі математики (math, decimal, statistics). "
        "ВАЖЛИВО: оголоси КОЖНУ змінну, яку використовуєш; НЕ посилайся на невизначені "
        "імена/плейсхолдери; усі числа з результату став ЛІТЕРАЛАМИ (напр. 674.5, а не "
        "REPORTED_TOTAL). Код має виконуватись без помилок. "
        "Якщо в результаті НЕМАЄ чисел, які можна перерахувати з умови (немає вхідних "
        "даних або числа — з зовнішніх джерел, а не з обчислень), надрукуй лише "
        "VERDICT: SKIP. Поверни ЛИШЕ Python-код, без пояснень і без ```-огорож.")
    ctx = f"## ЗАДАЧА\n{(task or '')[:3000]}\n\n## РЕЗУЛЬТАТ\n{(result or '')[:6000]}"

    # Початкова спроба + ОДИН саморемонт: якщо згенерований код упав на виконанні,
    # віддаємо моделі її ж код і ТЕКСТ ПОМИЛКИ й просимо виправити. Так перерахунок
    # реально відбувається, а не «пропускається». Технічний збій НЕ показуємо в банер
    # (сирий трейсбек не для клієнта) — тихий skip; РЕАЛЬНІ розбіжності чисел (fail) далі
    # показуємо як завжди. Другий виклик витрачається ЛИШЕ коли перша спроба впала.
    code, run_err, r = "", "", {}
    for attempt in range(2):
        if attempt == 0:
            user = ctx
        else:
            user = (ctx + f"\n\n## ТВІЙ ПОПЕРЕДНІЙ КОД (він УПАВ на виконанні)\n{code[:2000]}"
                    f"\n\n## ПОМИЛКА ВИКОНАННЯ\n{run_err[:500]}\n\n"
                    "Виправ код так, щоб він виконувався без помилок: оголоси кожну змінну, "
                    "числа впиши літералами, прибери будь-які невизначені імена.")
        try:
            gen = llm.complete(instr, user, temperature=0.0,
                               model=config.worker_model(), max_tokens=1500)
        except (llm.LLMError, llm.LLMNotConfigured):
            return {"status": "skip", "note": ""}   # наша межа, не провина звіту — тихо
        code = (gen or "").strip()
        if code.startswith("```"):
            code = re.sub(r"^```[a-zA-Z]*\r?\n|\r?\n?```$", "", code)
        r = _toolbox.run_python(code)
        if r.get("ok"):
            break
        run_err = (r.get("note") or "")
    else:
        # Обидві спроби впали на виконанні — тихий пропуск БЕЗ сирого трейсбека в банер.
        return {"status": "skip", "note": ""}
    out = r.get("stdout", "")
    if "VERDICT: FAIL" in out:
        fails = [l.strip() for l in out.splitlines()
                 if l.strip().startswith("CHECK") and "FAIL" in l]
        return {"status": "fail",
                "note": "розбіжність чисел (бухгалтер): " + "; ".join(fails[:3])}
    if "VERDICT: PASS" in out:
        return {"status": "pass", "note": ""}
    return {"status": "skip", "note": ""}


# ── ВОРОТА ПРИЙМАННЯ: санітар + детектор виродженого виводу ───────────────────
# Дешеві, ДЕТЕРМІНОВАНІ перевірки структурної осудності — щоб система ніколи не
# видавала «брак під виглядом готового» (напр. документ, у якому 99% пробілів через
# зациклення слабкої моделі на fallback). Спільні для складальника (executor) і межі
# видачі (agent). Не залежать від LLM.
def sanitize_output(text: str) -> str:
    """Прибирає ДЕГЕНЕРАТИВНІ пробіли (аномальні цикли моделі), не чіпаючи звичайний
    текст: схлопує суцільні горизонтальні пробіли завдовжки >=12 в один, обрізає хвости
    рядків, стягує 3+ порожні рядки до 2."""
    if not text:
        return text or ""
    t = str(text).replace("\r\n", "\n").replace("\r", "\n")
    t = re.sub(r"[^\S\n]{12,}", " ", t)   # аномальні пробільні цикли (гориз. пробіли будь-якого виду)
    t = re.sub(r"[^\S\n]+\n", "\n", t)    # хвости рядків
    t = re.sub(r"\n{3,}", "\n\n", t)      # зайві порожні рядки
    return t.strip()


def degeneracy_check(text: str, work_len: int = 0) -> dict:
    """Детермінований детектор виродженого виводу. {ok, reason}. ok=False => результат
    НЕ можна віддавати як готовий (порожнеча / пробільний цикл / мізерність проти роботи).
    work_len — обсяг сировини етапів конвеєра."""
    t = text or ""
    real = re.sub(r"\s+", "", t)
    if len(real) < 40:
        return {"ok": False, "reason": "майже порожній результат"}
    if len(t) >= 800 and (len(real) / len(t)) < 0.35:
        return {"ok": False, "reason": "аномально багато пробілів (вироджений вивід)"}
    if re.search(r"\s{300,}", t):
        return {"ok": False, "reason": "суцільний пробільний блок"}
    if work_len >= 1500 and len(real) < max(300, int(work_len * 0.02)):
        return {"ok": False, "reason": "результат мізерний проти виконаної роботи"}
    return {"ok": True, "reason": ""}


# ── БУХГАЛТЕР ФОРМУЛ (файловий, детермінований, без LLM) ─────────────────────
# Ловить клас «правдоподібний .xlsx з фейковими числами» (кредитний кейс 10.07
# ~22:10: формула множила ставку на ТЕКСТОВИЙ напис; цикл в останньому платежі;
# SUM повз дані; сирі {name}-заглушки). Працює на ГОТОВОМУ файлі — страхує будь-який
# шлях створення, не лише рендерер моделі.
_XLSX_REF_RE = re.compile(
    r"(?:(?:'([^']{1,31})'|([A-Za-zЀ-ӿ_][\wЀ-ӿ.]{0,30}))!)?"
    r"(?<![A-Za-z0-9_])\$?([A-Z]{1,3})\$?(\d{1,7})"
    r"(?::\$?([A-Z]{1,3})\$?(\d{1,7}))?(?![\w(])", re.U)
_XLSX_PLACEHOLDER_RE = re.compile(r"\{(?:P\d+|row|prev|first|last|i|name|value)(?:[+-]\d+)?(?::[^}]*)?\}")
_XLSX_NUMLIKE_RE = re.compile(r"^\s*-?[\d\s]+(?:[.,]\d+)?\s*%?\s*$")


def _xlsx_is_texty(v) -> bool:
    """Значення клітинки — «мертвий» для арифметики текст (не число/дата/формула)."""
    import datetime as _dt
    if v is None or isinstance(v, (int, float, _dt.date, _dt.datetime, bool)):
        return False
    s = str(v).strip()
    return bool(s) and not s.startswith("=") and not _XLSX_NUMLIKE_RE.match(s)


def _xlsx_formula_audit(wb) -> list:
    """Аудит формул книги: (а) сирі плейсхолдери; (б) арифметика по ТЕКСТУ;
    (в) діапазони з текстовими клітинками всередині; (г) циклічні посилання.
    Помилки поіменно, ЗБАЛАНСОВАНО за класами (щоб 10 однакових заглушок не
    витіснили зі звіту зсув посилань чи цикл — урок першого прогону тесту)."""
    from openpyxl.utils import column_index_from_string, get_column_letter
    ph_errs, ref_errs, cyc_errs, deps = [], [], [], {}
    sheets = {ws.title: ws for ws in wb.worksheets}
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if not isinstance(v, str):
                    continue
                if _XLSX_PLACEHOLDER_RE.search(v):
                    ph_errs.append(f"{ws.title}!{cell.coordinate}: сирий плейсхолдер "
                                   f"«{_XLSX_PLACEHOLDER_RE.search(v).group(0)}»")
                    continue
                if not v.startswith("="):
                    continue
                node = (ws.title, cell.coordinate)
                deps.setdefault(node, set())
                for m in _XLSX_REF_RE.finditer(v):
                    target = (m.group(1) or m.group(2) or ws.title).strip()
                    tws = sheets.get(target)
                    if tws is None:
                        continue  # неіснуючий лист ловить перевірка вище
                    c1 = column_index_from_string(m.group(3)); r1 = int(m.group(4))
                    if m.group(5):  # діапазон: текст усередині = агрегат по сміттю
                        c2 = column_index_from_string(m.group(5)); r2 = int(m.group(6))
                        cells_n = (abs(r2 - r1) + 1) * (abs(c2 - c1) + 1)
                        if cells_n <= 4000:
                            for rr in range(min(r1, r2), max(r1, r2) + 1):
                                for cc in range(min(c1, c2), max(c1, c2) + 1):
                                    tv = tws.cell(rr, cc).value
                                    if _xlsx_is_texty(tv):
                                        ref_errs.append(
                                            f"{ws.title}!{cell.coordinate}: діапазон "
                                            f"{m.group(0).lstrip('=')} містить ТЕКСТ у "
                                            f"{target}!{get_column_letter(cc)}{rr} "
                                            f"(«{str(tv)[:40]}») — захоплені службові рядки")
                                        break
                                    if isinstance(tv, str) and tv.startswith("="):
                                        deps[node].add((target, f"{get_column_letter(cc)}{rr}"))
                                else:
                                    continue
                                break
                    else:
                        tv = tws.cell(r1, c1).value
                        if _xlsx_is_texty(tv):
                            ref_errs.append(f"{ws.title}!{cell.coordinate}: формула працює з "
                                            f"ТЕКСТОМ {target}!{m.group(3)}{r1} («{str(tv)[:40]}») — "
                                            "посилання зсунуте на службовий рядок")
                        deps[node].add((target, f"{m.group(3)}{m.group(4)}"))
    # (г) цикли — ітеративний трикольоровий DFS
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {}
    for start in deps:
        if color.get(start, WHITE) != WHITE:
            continue
        stack = [(start, iter(deps.get(start, ())))]
        color[start] = GRAY
        while stack:
            node, it = stack[-1]
            adv = False
            for nxt in it:
                nxt = (nxt[0], (nxt[1] or "").replace("$", "").upper())
                if nxt not in deps:
                    continue
                st = color.get(nxt, WHITE)
                if st == GRAY:
                    cyc_errs.append(f"циклічне посилання: {node[0]}!{node[1]} ⇄ {nxt[0]}!{nxt[1]}")
                elif st == WHITE:
                    color[nxt] = GRAY
                    stack.append((nxt, iter(deps.get(nxt, ()))))
                    adv = True
                    break
            if not adv:
                color[node] = BLACK
                stack.pop()
    if len(ph_errs) > 3:
        ph_errs = ph_errs[:2] + [f"…і ще {len(ph_errs) - 2} сирих плейсхолдерів"]
    return (ph_errs + ref_errs[:5] + cyc_errs[:3])[:10]


def xlsx_integrity(path) -> dict:
    """ВОРОТА ГОТОВОГО ФАЙЛА: відкриває вже зібраний .xlsx і перевіряє, що
    (а) формули не посилаються на неіснуючі аркуші (інакше Excel покаже #REF! —
    «пустий» файл, як кредитний кейс 10.07), (б) книга не порожня, (в) БУХГАЛТЕР
    ФОРМУЛ: без сирих плейсхолдерів, без арифметики по тексту, без агрегатів по
    службових рядках, без циклів. {ok, note}. Це страховка ПОВЕРХ воріт рендерера —
    verified:True на битому файлі неможливий."""
    try:
        import openpyxl
    except Exception:
        return {"ok": True, "note": "openpyxl недоступний — перевірку пропущено"}
    try:
        wb = openpyxl.load_workbook(str(path))
    except Exception as e:
        return {"ok": False, "note": f"файл не відкривається: {e}"}
    names = set(wb.sheetnames)
    ref_re = re.compile(r"(?:'([^']{1,31})'|(?<![\w#])([\w]{1,31}))!", re.U)
    missing, filled = set(), 0
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if v is None or v == "":
                    continue
                filled += 1
                if isinstance(v, str) and v.startswith("="):
                    for m in ref_re.finditer(v):
                        ref = (m.group(1) or m.group(2) or "").strip()
                        if ref and ref not in names:
                            missing.add(ref)
    if missing:
        return {"ok": False, "note": "формули посилаються на неіснуючі аркуші: "
                                     + ", ".join(sorted(missing))}
    if filled < 3:
        return {"ok": False, "note": "книга майже порожня"}
    audit = _xlsx_formula_audit(wb)
    if audit:
        return {"ok": False, "note": "бухгалтер формул: " + "; ".join(audit[:4])}
    return {"ok": True, "note": ""}


def verify(task: str, result: str, criteria=None, sources=None, check_links=True,
           scope_note: str = "",
           numeric=False) -> dict:
    """Повертає {ok, checks:[{label, ok}], note, dead_urls, link_report}.
    sources — джерела з веб-пошуку (їхні URL вважаються справжніми).
    numeric=True — числова/фінансова задача: бухгалтер незалежно перераховує
    ключові числа; розбіжність понад 1% -> verified:False."""
    checks = _cheap_checks(task, result)
    cheap_ok = all(c["ok"] for c in checks)

    # Перевірка посилань: караємо ЛИШЕ сервер-підтверджені 404/410 (сторінки точно нема).
    # Недоступні/DNS-збій — не фальсифікація, лише мʼяко позначаємо (недоступний ≠ вигаданий).
    known = [s.get("url") for s in (sources or []) if isinstance(s, dict) and s.get("url")]
    link_report, dead_urls = [], []
    if check_links:
        lr = validate_urls(result, known_urls=known, do_network=config.provider_ready())
        link_report, dead_urls = lr["checked"], lr["dead"]
        if link_report:
            checks.append({"label": "Усі посилання справжні (перевірено)", "ok": not dead_urls})

    semantic_ok = True
    # ⭐⭐⭐ 30.07.2026. «ЧИ ВИКОНАНО ПЕРЕВІРКУ» І «ЧИ ВОНА ПРОЙДЕНА» — РІЗНІ РЕЧІ.
    # Доти їх не розрізняли: `semantic_ok` стояло True за замовчуванням, і збій
    # моделі-контролера читався як «результат чистий». Перевірено живцем 30.07:
    # провайдер не відповів -> ok=True, not_a_result=False, тобто платформа
    # оголосила НЕПЕРЕВІРЕНИЙ результат перевіреним.
    # ⛔ КОНТРОЛЬ, ЯКИЙ ПРИ ЗБОЇ КАЖЕ «ЧИСТО», — ЦЕ ВІДСУТНІЙ КОНТРОЛЬ.
    semantic_checked = False
    note = ""
    # Якщо провалився ДЕШЕВИЙ структурний чек — банер МУСИТЬ назвати причину (інакше
    # користувач бачить голе «не пройшов повну перевірку» без пояснення — дефект 11.07).
    if not cheap_ok:
        _failed = [c for c in checks if not c.get("ok")]
        note = "структурна перевірка не пройдена: " + "; ".join(
            (c.get("reason") or c.get("label", "")) for c in _failed)
    if cheap_ok and config.provider_ready():
        crit_block = ""
        if criteria:
            # ⭐⭐⭐ 10.08.2026. «РЕЛЕЙНА ШАФА» В ВОРОТАХ ЯКОСТІ.
            # Критерії успіху — це чек-лист ПОВНОЇ послуги системи, а не перелік
            # того, що замовила людина. Живий випадок 09.08: попросили таблицю
            # кафе на відтинку траси; система віддала саме таблицю — і ворота
            # оголосили результат непідтвердженим, бо в ньому «немає трьох
            # рейтингів і орієнтовного бюджету». Тобто людина отримала рівно те,
            # що просила, і побачила банер «не пройшло перевірку».
            # ЛІКУЄМО В ОДНОМУ МІСЦІ НА ВСІ СИСТЕМИ: критерій, якого ЗАДАЧА не
            # замовляла, — це «не застосовно», а не «провалено». Критерій, який
            # задача замовляла, судиться так само суворо, як і був. Це не
            # послаблення воріт: жоден із жорстких кодових замків (тендерайтер,
            # правові норми, бухгалтер, посилання) через критерії не працює.
            crit_block = ("\n\n## КРИТЕРІЇ УСПІХУ СИСТЕМИ (перевір кожен)\n"
                          + "\n".join(f"- {c}" for c in criteria)
                          + "\n\n⚠ ОБСЯГ ЗАМОВЛЕННЯ. Перелік вище — чек-лист ПОВНОЇ "
                            "послуги системи, а не того, що замовила людина. Суди лише "
                            "ті критерії, які ЗАДАЧА справді замовила. Критерій про "
                            "роботу, якої в задачі не просили (інший розділ, інший "
                            "формат, додаткова аналітика, побудова маршруту, коли просили "
                            "лише перелік обʼєктів), — це «не застосовно», і він НЕ "
                            "робить результат неповним. Конкретний запит — конкретна "
                            "відповідь: якщо людина попросила таблицю з трьома "
                            "колонками і отримала її, результат ПОВНИЙ.")
        # ⭐⭐⭐ 10.08.2026, зміна 145. МЕЖА ПОВНОВАЖЕНЬ ПЛАТФОРМИ.
        # Критерії кажуть, ЧОГО чекати; межа каже, чого платформа НЕ СМІЄ
        # робити. Без неї суддя вимагав заповнених бланків замовника — тобто
        # вигаданих цін — і завалював будь-який результат.
        if scope_note:
            crit_block += "\n\n" + str(scope_note)
        # Контролеру даємо ПОЧАТОК + КІНЕЦЬ звіту, а не лише перші символи: інакше на
        # довгому звіті модель бачить штучний обрив на межі вікна і хибно каже
        # «неповний / обірваний» (корінь фальшивого банера 13.07). Кінець показує,
        # чи звіт справді ЗАВЕРШУЄТЬСЯ (висновок/перелік прогалин).
        if len(result) <= 7000:
            _res_view = result
        else:
            _res_view = (result[:4500]
                         + "\n\n[…СЕРЕДИНУ ЗВІТУ СКОРОЧЕНО ДЛЯ ПЕРЕВІРКИ — це не обрив…]\n\n"
                         + result[-2500:])
        try:
            verdict = llm.judge_json(
                "Ти контролер якості. Оціни, чи відповідає РЕЗУЛЬТАТ поставленій ЗАДАЧІ "
                "та критеріям успіху системи: чи повний, чи по суті, чи не є відмовкою або "
                "заглушкою.\n"
                "Важливо — не плутай чесність із незавершеністю:\n"
                "• Шаблон для заповнення (дашборд «план-факт» із порожніми клітинками, проєкт "
                "документа з пропусками «____», поля для підпису) — НЕ заглушка й НЕ неповнота "
                "ЛИШЕ тоді, коли шаблон і просили в ЗАДАЧІ. Якщо ж задача просила ЗРОБИТИ роботу "
                "(знайти, порахувати, перевірити, скласти список), а результат — це кістяк "
                "таблиці, перелік потрібних вхідних даних або прохання «надішліть параметри, і я "
                "тоді зроблю», то роботу НЕ виконано: став answers_task=false, is_placeholder=true. "
                "⭐ 30.07.2026: саме такий документ платформа вже віддавала клієнту як результат.\n"
                "• Якщо числа/факти ЯВНО позначені як припущення (теги [ПРИПУЩЕННЯ], "
                "«орієнтовно», «гіпотеза»), а прогалини в даних чесно перелічені — це ОЗНАКА ЯКОСТІ "
                "(розділення фактів і припущень), а НЕ незавершеність. Не знижуй за це complete і "
                "не став is_placeholder.\n"
                "• is_placeholder=true став ЛИШЕ коли результат є справжньою відмовкою або "
                "болванкою (напр. «тут буде аналіз», «зробіть це самі», порожній кістяк без змісту).\n"
                "• Для довгих звітів РЕЗУЛЬТАТ показано як ПОЧАТОК + КІНЕЦЬ із явною поміткою "
                "«[…середину скорочено…]» — це НОРМА перевірки, а НЕ обрив. Повноту (complete) суди "
                "за тим, чи КІНЕЦЬ виглядає завершеним (є підсумок/висновок/перелік прогалин), а не "
                "за наявністю помітки про скорочення середини.\n"
                'Поверни JSON: {"answers_task": true|false, "complete": true|false, '
                '"is_placeholder": true|false, "note": "коротко"}.',
                f"## ЗАДАЧА\n{task}{crit_block}\n\n## РЕЗУЛЬТАТ\n{_res_view}",
                temperature=0.0,
                model=config.worker_model(),
            )
            semantic_ok = bool(verdict.get("answers_task")) and not verdict.get("is_placeholder")
            note = verdict.get("note", "")
            checks.append({"label": "Відповідає задачі (семантично)", "ok": bool(verdict.get("answers_task"))})
            checks.append({"label": "Не є заглушкою", "ok": not verdict.get("is_placeholder")})
            checks.append({"label": "Повний результат", "ok": bool(verdict.get("complete"))})
            semantic_checked = True
        except llm.LLMError:
            note = ("Перевірку змісту НЕ виконано (контролер не відповів) — "
                    "результат не можна вважати перевіреним.")
            checks.append({"label": "Перевірку змісту виконано", "ok": False,
                           "reason": "контролер якості не відповів"})

    # Бухгалтер: незалежний перерахунок ключових чисел (лише числові задачі).
    numbers_ok = True
    if numeric and cheap_ok:
        acc = verify_numbers(task, result)
        if acc["status"] == "pass":
            checks.append({"label": "Числа перераховано незалежно (бухгалтер)", "ok": True})
        elif acc["status"] == "fail":
            checks.append({"label": "Числа перераховано незалежно (бухгалтер)", "ok": False})
            numbers_ok = False
            note = (note + " " if note else "") + "⚠ " + acc["note"]
        elif acc.get("note"):
            note = (note + " " if note else "") + f"(перерахунок пропущено: {acc['note']})"

    if dead_urls:
        bad = ", ".join(dead_urls[:3])
        note = (note + " " if note else "") + f"⚠ Не вдалося підтвердити посилання (перевірте вручну): {bad}."
    links_ok = not dead_urls
    # ⭐⭐⭐ 30.07.2026 (закон оркестратора, Андрій). Один спільний `ok` змішував дві
    # РІЗНІ за наслідками речі: «це не результат» (робота не зроблена: не відповідає
    # задачі або болванка) і «це результат, але з застереженням» (частину посилань не
    # підтверджено, число не звірене). Через це здача результату не могла їх
    # розрізнити — і клеїла наліпку на обидва випадки. Тепер вердикт «роботи немає»
    # виїжджає окремим полем, і здача мусить на нього СПИНИТИСЬ, а не попередити.
    # `ok` — зелене світло. Немає ВИКОНАНОЇ перевірки змісту — зеленого світла НЕМАЄ.
    # `not_a_result` — ВИРОК «роботи не зроблено»; його ставить лише ВИКОНАНА
    # перевірка: ми не знаємо, що результат поганий — ми знаємо, що НЕ ПЕРЕВІРИЛИ.
    # Тому тут застереження клієнту, а не зупинка: інакше збій провайдера глушив би платформу.
    return {"ok": (cheap_ok and semantic_ok and links_ok and numbers_ok
                   and (semantic_checked or not config.provider_ready())),
            "not_a_result": semantic_checked and not semantic_ok,
            "semantic_checked": semantic_checked,
            "checks": checks,
            "note": note, "dead_urls": dead_urls, "link_report": link_report}
