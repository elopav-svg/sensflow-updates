# -*- coding: utf-8 -*-
"""
tender_docs.py — ПРОЧИТАТИ ТЕНДЕРНУ ДОКУМЕНТАЦІЮ ЗАМОВНИКА, 30.07.2026.

НАВІЩО (живий випадок 30.07.2026). Оркестратор пообіцяв клієнту: «відкриємо
тендер UA-2026-07-25-000428-a, витягнемо вимоги з тендерної документації
замовника і складемо перелік документів під нього». Клієнт погодився. А вміння
читати файли документації в платформі НЕ БУЛО — і документ чесно написав
«мені не було передано вміст тендерної документації». Обіцянка вже прозвучала.
Тому тут не новий шар, а СКЛЕЙКА того, що вже є:

    номер UA-…  ->  tender_legal.load_card  (свій резолвер писати заборонено)
    картка      ->  tender_source_ua.documents  (перелік файлів)
    файл        ->  netfetch.get_bytes          (ЄДИНЕ вікно назовні, ворота егресу)
    текст       ->  filetext.extract_text       (pdf/docx/xlsx/csv, стеля MAX_CHARS)

ГОЛОВНЕ ПРАВИЛО — FAIL-CLOSED. Не дістали номер, картку чи перелік файлів ->
ok=False і ПРИЧИНА СЛОВАМИ. Порожній перелік — це НЕ помилка: замовник міг
нічого не оприлюднити, і сказати про це чесно важливіше, ніж вдати, що шукали
погано. Формат, який ми не читаємо (скан-картинка, архів), НЕ вигадуємо —
він іде в `skipped` з причиною, а `complete` стає False.

Нічого не кешуємо і нічого не пишемо на диск: документація тендера змінюється
(замовник викладає нові версії), і вчорашня копія — це тихо застаріла правда.
"""

# ⭐ 04.08.2026. КОНТЕЙНЕРИ ЕЛЕКТРОННОГО ПІДПИСУ — НЕ ДОКУМЕНТИ.
# Замовник кладе їх поруч із документацією (`sign.p7s` і подібні). Читати в них
# нічого: підпис засвідчує файл, а не описує вимоги. Якщо рахувати їх «непрочитаними»,
# кожен правовий висновок нестиме фальшиве «це не вся документація».
_SIGNATURE_EXT = {".p7s", ".p7b", ".p7m", ".sig", ".asics", ".asice", ".cer", ".crt", ".pkcs7"}

MAX_FILES_DEFAULT = 6          # стеля файлів за один прогін (контекст не гумовий)
# ⭐ 10.08.2026. Стеля ВСЬОГО матеріалу тендера на один прогін, у знаках.
# Ділиться порівну між прочитаними документами (`_allot`).
# ⭐⭐⭐ 17.08.2026, зміна 194, СЛОВО АНДРІЯ: 120 000 -> 300 000. 🩸 Живий прогін
# показав ціну старої стелі: тендерна документація Кривого Рогу — один файл на
# 367 КБ, перелік документів учасника лежить у Додатку 3 ближче до кінця, і при
# бюджеті 120 000 на ЧОТИРИ файли до пакета доїжджало 3 позиції замість ~30.
# Ціна рішення — приблизно вдвічі дорожчий прогін тендера. Слово Андрія 12.08:
# «економія на тендерній системі може вистрелити втратами під час торгів;
# головне, щоб документи були повні і релевантні».
MATERIAL_BUDGET = 300000
_UA = "AI-Orchestrator/1.0 (SensFlow tender docs)"
_TIMEOUT = 60                  # файли важчі за json — час більший, ніж у картки

# Формати, які ми ВМІЄМО перетворити на текст (дивись filetext.extract_text).
# Список ДОЗВОЛЕНИХ, а не заборонених, свідомо: це fail-closed. Невідоме
# розширення краще чесно пропустити, ніж завантажити мегабайти і віддати сміття.
# ⭐⭐⭐ 17.08.2026, зміна 194. `.doc` СЮДИ ДОДАНО. 🩸 Живий прогін показав, що цілі
# тендери публікуються старим Word 97-2003 (сигнатура d0cf11e0 — перевірено на
# справжніх файлах), і платформа не бачила переліку обовʼязкових документів
# ВЗАГАЛІ: `обсяг в оголошенні=0`. Розбір власний — `filetext._from_doc`; не
# впорався — віддає «[.doc не розібрано: …]», і нижче цей рядок стає ЧЕСНИМ
# `skipped`, а не мовчазним провалом.
# ⚠ `.xls` (старий Excel) досі НЕ читаємо — не обіцяємо того, чого не вміємо.
_READABLE_EXT = {
    ".pdf", ".docx", ".doc", ".xlsx", ".xlsm", ".csv", ".tsv",
    ".txt", ".md", ".json", ".xml", ".html", ".yaml", ".yml", ".log",
}

# Тип із поля `format` (mime) -> розширення. Потрібно, коли в назві файлу
# розширення немає взагалі — таке в Прозорро трапляється.
_MIME_EXT = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "application/vnd.ms-excel": ".xls",
    "application/msword": ".doc",
    "text/plain": ".txt",
    "text/csv": ".csv",
    "text/html": ".html",
    "application/json": ".json",
    "application/xml": ".xml",
    "text/xml": ".xml",
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/tiff": ".tif",
    "application/zip": ".zip",
}


def _ext_of(title, fmt):
    """Розширення файлу: спершу з назви, потім із mime-типу. '' — не визначили."""
    name = (title or "").strip()
    if "." in name:
        ext = "." + name.rsplit(".", 1)[-1].lower()
        if len(ext) <= 6:                    # «.pdf» так, «.документація» ні
            return ext
    return _MIME_EXT.get((fmt or "").strip().lower(), "")


def _stamp(doc):
    """Момент життя документа для порівняння версій. Дати в Прозорро — ISO,
    тому звичайне порівняння рядків працює як порівняння часу."""
    d = doc or {}
    return (d.get("datePublished") or d.get("dateModified") or "")


def _latest_only(docs):
    """Лишити ЛИШЕ останні версії документів. -> (список, скільки прибрано).

    ЯК ВЕРСІЇ ВІДРІЗНЯЮТЬСЯ. У Прозорро документ версіонується: нова редакція
    приходить ОКРЕМИМ записом із тим самим `id` і свіжішою `datePublished`.
    Певності, що так буде завжди (і що субресурс не віддасть кожну версію під
    своїм `id`), у нас НЕМАЄ — живою розвідкою це не перевірено. Тому робимо
    два проходи, як велить обережність:
      1) за `id` — беремо найсвіжіший запис у кожній групі;
      2) за `title` — те саме ще раз, бо ЯКЩО версії мають різні `id`, їх
         усе одно тримає купи однакова назва.
    Ціна другого проходу: два РІЗНІ документи з ОДНАКОВОЮ назвою зіллються в
    один. У Прозорро однакова назва майже завжди й означає версії того самого
    файлу, а показати стару редакцію вимог як чинну — дорожче за цю втрату.
    Скільки записів прибрано — повертаємо числом, щоб звуження було ВИДИМЕ.
    """
    def _fold(items, key_of):
        best, order = {}, []
        for d in items:
            key = key_of(d)
            if key not in best:
                best[key] = d
                order.append(key)
            elif _stamp(d) >= _stamp(best[key]):
                best[key] = d
        return [best[k] for k in order]

    src = [d for d in (docs or []) if isinstance(d, dict)]
    by_id = _fold(src, lambda d: (d.get("id") or "").strip()
                  or "назва:" + (d.get("title") or "").strip().lower())
    by_title = _fold(by_id, lambda d: (d.get("title") or "").strip().lower()
                     or "ід:" + (d.get("id") or "").strip())
    return by_title, len(src) - len(by_title)


def _is_placeholder(text):
    """filetext на нечитабельному файлі віддає не текст, а помітку в дужках
    («[pdf без текстового шару…]», «[формат .x не підтримується…]»). Прийняти
    її за вміст документа означало б показати клієнту порожнечу як вимоги."""
    t = (text or "").strip()
    return bool(t) and t.startswith("[") and t.endswith("]") and "\n" not in t


def _fail(tender_id, reason, uuid=""):
    """Один вигляд чесного стопу — щоб причина ніде не загубилась."""
    return {"ok": False, "tender_id": (tender_id or "").strip(), "uuid": uuid,
            "files": [], "skipped": [], "reason": reason, "complete": False}


def read_docs(tender_id, max_files=MAX_FILES_DEFAULT):
    """Номер тендера UA-… -> тексти файлів тендерної документації замовника.

    -> {ok, tender_id, uuid, files, skipped, reason, complete}
       files    — [{title, format, url, chars, text}] у порядку джерела;
       skipped  — [{title, why}]: формат не читаємо / файл не взявся / ліміт;
       complete — False, якщо хоч щось у skipped (ми бачили НЕ ВСЕ).

    Мережа — тільки через netfetch (ворота егресу). Кешу і запису на диск немає.
    """
    tid = (tender_id or "").strip()
    if not tid:
        return _fail(tid, "не сказано, який тендер читати: потрібен номер UA-…")
    try:
        max_files = max(1, int(max_files))
    except (TypeError, ValueError):
        max_files = MAX_FILES_DEFAULT

    # Імпорти всередині функції: реєстр робіт тримає модулі лінивими, а
    # tender_legal/джерело не мають знати одне про одного через кільце імпортів.
    try:
        import netfetch
        import filetext
        import tender_legal
        import tender_source_ua as src
    except Exception as e:
        return _fail(tid, "не завантажились складники читання документації (%s: %s)"
                          % (type(e).__name__, e))

    # Номер -> картка. Свого резолвера НЕ пишемо: load_card уже ходить
    # tender_source_ua.index_uuid (міст) і .resolve (пошук у джерелі).
    try:
        card = tender_legal.load_card(tid)
    except Exception as e:
        return _fail(tid, "джерело тендерів не відповіло (%s: %s)" % (type(e).__name__, e))
    if not isinstance(card, dict) or not card:
        return _fail(tid, "не вдалося дістати картку тендера %s: джерело не знає цього "
                          "номера або зараз недоступне. Перевірте номер або спробуйте "
                          "пізніше — вигадувати вміст документації я не буду" % tid)

    uuid = str(card.get("id") or "").strip()

    # Перелік файлів: основний шлях — прямо з картки (вона повна), запасний —
    # субресурс /documents (його вмикає сам tender_source_ua.documents).
    try:
        raw_docs = src.documents(uuid, card=card)
    except Exception as e:
        return _fail(tid, "перелік файлів документації не прочитався (%s: %s)"
                          % (type(e).__name__, e), uuid=uuid)
    if not isinstance(raw_docs, list):
        return _fail(tid, "джерело віддало перелік файлів у незрозумілому вигляді", uuid=uuid)

    if not raw_docs:
        # Порожньо — це ВІДПОВІДЬ, а не помилка. Замовник міг нічого не додати.
        return {"ok": True, "tender_id": tid, "uuid": uuid, "files": [], "skipped": [],
                "reason": "документів не додано", "complete": True}

    fresh, dropped_versions = _latest_only(raw_docs)

    files, skipped, signatures = [], [], []
    for d in fresh:
        title = (d.get("title") or "").strip() or "без назви"
        url = (d.get("url") or "").strip()
        fmt = (d.get("format") or "").strip()
        if len(files) >= max_files:
            skipped.append({"title": title,
                            "why": "ліміт: за один раз читаємо не більше %d файлів" % max_files})
            continue
        if not url:
            skipped.append({"title": title, "why": "у записі немає посилання на файл"})
            continue
        ext = _ext_of(title, fmt)
        if ext in _SIGNATURE_EXT:
            # ⭐ 04.08.2026 (живий прогін на UA-2026-08-04-003201-A). НЕ ВСЯКИЙ
            # ФАЙЛ У КАРТЦІ — ДОКУМЕНТ. Замовник докладає до документації
            # контейнер електронного підпису (`sign.p7s`). Змісту в ньому немає:
            # він засвідчує підпис, а не описує вимоги. Раніше він падав у
            # «пропущено», і кожен правовий висновок ніс застереження «це не вся
            # документація» — тобто клієнт платив сумнівом за файл, у якому
            # нічого читати. Тепер підпис відомий як підпис і дірою не рахується.
            signatures.append({"title": title, "format": fmt or ext, "url": url})
            continue
        if ext not in _READABLE_EXT:
            # Скани-картинки, архіви, старі .doc/.xls. Вигадувати їхній вміст
            # заборонено: краще чесно назвати файл, який ми не прочитали.
            skipped.append({"title": title,
                            "why": "формат %s ми читати не вміємо (скан-картинка, архів "
                                   "або старий формат) — вміст не вигадуємо"
                                   % (ext or fmt or "невідомий")})
            continue
        try:
            raw = netfetch.get_bytes(url, ua=_UA, timeout=_TIMEOUT)
        except Exception as e:
            skipped.append({"title": title,
                            "why": "файл не завантажився (%s: %s)" % (type(e).__name__, e)})
            continue
        # filetext дивиться на розширення В НАЗВІ — якщо його там немає,
        # підставляємо те, що дало поле format, інакше pdf піде «як текст».
        name = title if "." in title else (title + ext)
        try:
            # ⭐⭐⭐ 17.08.2026. СТЕЛЮ НАЗИВАЄ СПОЖИВАЧ. 🩸 Живий прогін після
            # лікування `.doc`: тендерна документація Кривого Рогу обрізалась
            # ВЛАСНОЮ стелею `filetext` (40 000 знаків), перелік документів
            # учасника лежав далі — і в пакет доїхало 3 позиції замість ~30.
            # Про цей виріз не знав ніхто: єдиний писар бюджету (нижче,
            # `material_blocks`) уміє СКАЗАТИ про обрізання, а тихий виріз
            # поверхом нижче забирав у нього цю можливість.
            # ⛒ Тут стеля ОДНА — бюджет матеріалу; ділить і називає його
            # `material_blocks`, і другого різника більше немає.
            text = filetext.extract_text(name, raw, cap=MATERIAL_BUDGET) or ""
        except Exception as e:
            skipped.append({"title": title,
                            "why": "текст із файлу не витягся (%s: %s)" % (type(e).__name__, e)})
            continue
        if not text.strip():
            skipped.append({"title": title, "why": "файл порожній — тексту в ньому немає"})
            continue
        if _is_placeholder(text):
            skipped.append({"title": title, "why": text.strip().strip("[]")})
            continue
        files.append({"title": title, "format": fmt or ext, "url": url,
                      "chars": len(text), "text": text})

    bits = ["прочитано файлів: %d" % len(files)]
    if dropped_versions:
        bits.append("старих версій документів прибрано: %d" % dropped_versions)
    if signatures:
        bits.append("файлів електронного підпису (без змісту): %d" % len(signatures))
    if skipped:
        bits.append("пропущено файлів: %d (кожен із причиною)" % len(skipped))
    if not files and skipped:
        bits.append("тексту вимог у мене НЕМАЄ — жоден файл не прочитався")
    return {"ok": True, "tender_id": tid, "uuid": uuid, "files": files,
            "skipped": skipped, "signatures": signatures,
            "reason": "; ".join(bits), "complete": not skipped}

# ═══════════════ ОДИН ПИСАР МАТЕРІАЛУ ТЕНДЕРА (10.08.2026, зміна 143) ═══════
# ⭐⭐⭐ КОРІНЬ, ЗНАЙДЕНИЙ ЖИВИМ ПРОГОНОМ ЗА ГРОШІ. Пакет зібрався на 15 позицій —
# рівно перелік ОГОЛОШЕННЯ. Пʼять вимог ДОДАТКА №2 (паспорт якості, протокол
# випробувань, Програма і методики, ТУ, фото) не доїхали ЗОВСІМ, і про це не
# було сказано ані слова. Без протоколу випробувань і ТУ пропозицію знімають.
#
# Писарів матеріалу було ДВА, і вони поводились по-різному:
#   • `read_docs_job` ділив бюджет ПОРІВНУ і різав видимим `fit_context`;
#   • `source_intake.collect` — шлях, яким документи РЕАЛЬНО потрапляють у
#     роботу, — склеював усе підряд і робив `out[:MAX_CHARS]`. Голий зріз хвоста.
#     Оголошення (34 768) плюс проєкт договору зʼїдали стелю, і технічний
#     додаток просто не існував — ні для агента, ні для коду.
#
# ⛒ ЛІКУЄМО ОДНИМ ПИСАРЕМ І ЧЕСНИМ ДІЛЕННЯМ. Бюджет ділиться НЕ порівну, а ЗА
# ПОТРЕБОЮ: хто менший за свою частку — бере скільки треба, надлишок іде
# більшим. Малий технічний додаток більше не може зникнути через товстий
# договір. Усе, що врізано або не вмістилось, НАЗВАНО поіменно.
_MIN_DOC_CHARS = 3000          # менше цього документ уже не документ, а обрубок


def _allot(sizes, budget: int) -> dict:
    """Скільки знаків дістанеться кожному документу (за потребою, не порівну).

    -> {індекс: квота}. Індекси, яких немає у відповіді, у бюджет не вмістились.
    """
    keep = list(range(len(sizes)))
    budget = max(0, int(budget))
    # Кому не дістається навіть мінімуму — той не їде, і про це скаже той, хто
    # кличе. Прибираємо З КІНЦЯ порядку джерела: у Прозорро оголошення йде
    # першим, і саме воно найпотрібніше.
    while len(keep) > 1 and budget // len(keep) < _MIN_DOC_CHARS:
        keep.pop()
    rest, left, quota = set(keep), budget, {}
    while rest:
        share = left // len(rest)
        small = [i for i in rest if sizes[i] <= share]
        if not small:
            for i in rest:
                quota[i] = share
            break
        for i in small:
            quota[i] = sizes[i]
            left -= sizes[i]
        rest -= set(small)
    return quota


def material_blocks(files, budget: int = MATERIAL_BUDGET):
    """Тексти документів замовника -> (матеріал, застереження).

    ЄДИНИЙ складач матеріалу тендера: ним користуються і робота `read_docs_job`,
    і прийом джерела `source_intake`. Двох писарів однієї правди не заводимо.
    Мовчазного обрізання тут немає на жодному шарі: виріз лишає позначку В
    ТЕКСТІ (`executor.fit_context`), а документ, який не вмістився зовсім,
    названо поіменно в застереженнях.
    """
    import executor                 # пізній імпорт: tender_docs гріється раніше
    items = [f for f in (files or []) if isinstance(f, dict) and str(f.get("text") or "").strip()]
    if not items:
        return "", []
    sizes = [len(str(f.get("text") or "")) for f in items]
    quota = _allot(sizes, budget)
    lines, notes = [], []
    for i, f in enumerate(items):
        title = str(f.get("title") or "без назви")
        text = str(f.get("text") or "")
        if i not in quota:
            notes.append("«%s» — НЕ ВМІСТИВСЯ у бюджет матеріалу (%d знаків). "
                         "Про його вміст висновків робити НЕ МОЖНА." % (title, len(text)))
            continue
        body = executor.fit_context(text, quota[i], "документа «%s»" % title)
        if len(body) < len(text):
            notes.append("«%s» — показано %d знаків із %d (середину вирізано, "
                         "позначка стоїть у тексті)." % (title, len(body), len(text)))
        lines.append("\n=== ДОКУМЕНТ: %s (%d символів) ===\n%s" % (title, len(text), body))
    return "\n".join(lines), notes




def read_docs_job(tender_id="", max_files=MAX_FILES_DEFAULT, **_ignored):
    """Вхід для реєстру тихих задач (data_jobs) -> {status, summary}.

    Номер тендера приїздить ЧЕРЕЗ kwargs: `data_jobs.run(job, **kwargs)` уже
    передає їх сюди. Планувальник кличе run(job) БЕЗ аргументів — тому в
    tender_id стоїть порожній усталений, і робота тоді чесно каже, чого бракує,
    а не мовчить і не вигадує номер. Зайві kwargs ковтаємо (**_ignored), щоб
    новий виклик звідкись іще не завалив прогін.
    """
    tid = (tender_id or "").strip()
    if not tid:
        return {"status": "failed",
                "summary": "не сказано, ЯКИЙ тендер читати. Потрібен номер UA-…: "
                           "виклич цю роботу з tender_id=\"UA-РРРР-ММ-ДД-NNNNNN-a\". "
                           "Сама я номер не вигадую."}
    res = read_docs(tid, max_files=max_files)
    if not res.get("ok"):
        return {"status": "failed", "summary": "%s — %s" % (tid, res.get("reason") or "причина невідома")}

    files, skipped = res.get("files") or [], res.get("skipped") or []
    lines = ["Тендер %s — тендерна документація замовника (%s)." % (tid, res.get("reason") or "")]
    if not files and not skipped:
        lines.append("Замовник не оприлюднив жодного файлу документації. "
                     "Вимог узяти нізвідки — так і скажи людині.")
    # ⚠ ТЕКСТ ІДЕ ЦІЛКОМ, ПОКИ ВМІЩАЄТЬСЯ. Саме через його брак документ
    # 30.07.2026 написав «мені не було передано вміст тендерної документації».
    # ⭐ 10.08.2026. СТЕЛЮ НА ФАЙЛ підняли з 20 000 до 40 000 знаків (справжнє
    # оголошення замовника — 34 743). Щоб це не перетворилось на подвоєння
    # вартості прогону, ЗАГАЛЬНИЙ обсяг матеріалу тримає СПОЖИВАЧ — тут:
    # MATERIAL_BUDGET ділиться порівну між прочитаними документами. Найгірший
    # випадок лишився тим самим, що й був (6 файлів x 20 000), але коли файлів
    # менше, кожен доїжджає повніше. Ріже один писар — executor.fit_context:
    # він лишає ПОЧАТОК і КІНЕЦЬ і ставить видиму позначку про виріз.
    # Мовчазного урізання немає на жодному з двох шарів.
    _mat, _notes = material_blocks(files, MATERIAL_BUDGET)
    if _mat:
        lines.append(_mat)
    for _n in _notes:
        lines.append("• " + _n)
    for s in skipped:
        lines.append("• НЕ прочитано: %s — %s" % (s.get("title"), s.get("why")))
    if not res.get("complete"):
        lines.append("Це НЕ повна картина: частину файлів прочитати не вдалося — "
                     "не видавай перелік вимог за вичерпний, назви пропущені файли.")
    return {"status": "completed", "summary": "\n".join(lines)}
