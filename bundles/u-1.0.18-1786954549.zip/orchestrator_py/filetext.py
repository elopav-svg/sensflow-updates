"""
filetext.py — витяг тексту з прикріплених файлів (для подачі агентам як вхід).

Працює з сирими байтами (файли приходять у чат як base64). Опційні бібліотеки
(python-docx, openpyxl, pypdf) визначаються під час виконання — без них формати
docx/xlsx/pdf просто позначаються як недоступні, рушій не падає.
"""

import io
import csv
import re
import struct

# ⭐ 10.08.2026. СТЕЛЯ НА ФАЙЛ. Була 20 000 — і справжнє оголошення замовника
# (34 743 знаки, тендер UA-2026-08-05-000303-a) не вміщалось у неї ЦІЛКОМ.
# Стеля мусить вміщати типовий документ замовника, інакше вона ріже не «хвіст
# зайвого», а сам зміст. Загальний обсяг матеріалу тримає СПОЖИВАЧ (executor
# .fit_context для доданих файлів, tender_docs.read_docs_job для документації
# тендера) — саме там про нього знають.
MAX_CHARS = 40000


# ⭐⭐⭐ 17.08.2026, зміна 194 (знайдено ЖИВИМ ПРОГОНОМ ПІСЛЯ лікування .doc).
# СТЕЛЮ НАЗИВАЄ СПОЖИВАЧ, А НЕ ЦЕЙ МОДУЛЬ. 🩸 Щойно платформа навчилась читати
# `.doc`, вона прочитала тендерну документацію Кривого Рогу — і обрізала її ТУТ
# на 40 000 знаків. Повний перелік документів учасника лежав далі, у Додатку 3, і
# в пакет доїхало 3 позиції з ~30. Обрізання лишало позначку в тексті, але для
# КОДУ воно було невидиме: `tender_docs.material_blocks` — єдиний писар бюджету,
# який уміє СКАЗАТИ про виріз, — про цей другий, тихий виріз не знав нічого.
# ⛒ ДВОХ ПИСАРІВ СТЕЛІ НЕ БУВАЄ. Хто знає свій бюджет, той його і називає.
def _cap(text: str, limit: int = None) -> str:
    limit = int(limit or MAX_CHARS)
    if text and len(text) > limit:
        return text[:limit] + f"\n\n…[обрізано, показано перші {limit} символів]"
    return text or ""


def was_capped(text: str) -> bool:
    """Чи цей текст обрізала стеля — ОДИН читач власної позначки."""
    return "…[обрізано, показано перші " in (text or "")


def _ext(name: str) -> str:
    return ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""


def _decode(raw: bytes) -> str:
    for enc in ("utf-8-sig", "utf-8", "cp1251", "latin-1"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", errors="replace")


def _docx_blocks(parent):
    """Абзаци й таблиці В ПОРЯДКУ ДОКУМЕНТА, з будь-якої глибини вкладеності.

    python-docx дає `d.paragraphs` і `d.tables` ДВОМА окремими плоскими списками
    верхнього рівня. Через це текст у таблиці всередині таблиці не існував ані в
    першому, ані в другому. Обхід іде по САМОМУ дереву документа, тому порядок
    зберігається, а вкладеність не має значення.
    """
    from docx.document import Document as _Doc
    from docx.oxml.ns import qn
    from docx.table import Table, _Cell
    from docx.text.paragraph import Paragraph

    if isinstance(parent, _Doc):
        el = parent.element.body
    elif isinstance(parent, _Cell):
        el = parent._tc
    else:
        return
    for child in el.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, parent)
        elif child.tag == qn("w:tbl"):
            yield Table(child, parent)


def _docx_render(parent, depth=0):
    """Текст гілки дерева. Рядок таблиці лишається одним рядком (`a | b | c`),
    щоб нумеровані переліки в клітинці не злиплись — на них спирається розбір
    вимог тендера."""
    from docx.table import Table
    out = []
    if depth > 12:            # запобіжник від хворого документа, не межа змісту
        return out
    for block in _docx_blocks(parent):
        if isinstance(block, Table):
            for row in block.rows:
                cells, seen = [], set()
                try:
                    row_cells = row.cells
                except Exception:
                    continue
                for cell in row_cells:
                    key = id(cell._tc)
                    if key in seen:      # обʼєднана клітинка: той самий вміст
                        continue
                    seen.add(key)
                    cells.append("\n".join(_docx_render(cell, depth + 1)).strip())
                if any(cells):
                    out.append(" | ".join(cells))
        else:
            t = (block.text or "").strip()
            if t:
                out.append(t)
    return out


def _docx_xml_paragraphs(raw: bytes):
    """ПРАВДА ПРО ДОКУМЕНТ, здобута НЕ обходом дерева: усі абзаци word/document.xml.

    Незалежна опора. Ворота, які звіряють результат із власним недоліком, — не
    ворота: якщо обхід дерева чогось не побачив (напис у текстовому полі, поле
    форми, вміст `w:sdt`), помітити це можна лише зовнішнім джерелом.
    """
    import zipfile
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            xml = z.read("word/document.xml").decode("utf-8", "replace")
    except Exception:
        return []
    out = []
    for m in re.finditer(r"<w:p[ >].*?</w:p>", xml, re.S):
        t = "".join(re.findall(r"<w:t[^>]*>([^<]*)</w:t>", m.group(0))).strip()
        if t:
            out.append(t)
    return out


def _from_docx(raw: bytes) -> str:
    """⭐⭐⭐ 10.08.2026. ВИТЯГ, ЯКИЙ НЕ ГУБИТЬ ТЕКСТ МОВЧКИ.

    Що було. Читались абзаци верхнього рівня плюс таблиці верхнього рівня, а
    `cell.text` віддає лише абзаци, що лежать у клітинці НАПРЯМУ. Справжнє
    оголошення замовника — одна велика таблиця, а всередині неї ВКЛАДЕНА ще
    одна: із 34 743 знаків до систем доїжджало 6 395, тобто 81 відсоток зникав,
    і платформа про це НЕ КАЗАЛА НІЧОГО. Тихе обрізання гірше за відмову: людина
    отримує впевнений висновок, зроблений із пʼятої частини документа.

    Що тепер. Два незалежні шари:
      1. ОБХІД ДЕРЕВА — абзаци й таблиці будь-якої вкладеності, у порядку
         документа (`_docx_render`).
      2. ЗАПОБІЖНИК — звірка з word/document.xml (`_docx_xml_paragraphs`). Усе,
         чого обхід не побачив, доїжджає окремим ПОЗНАЧЕНИМ блоком. Тому навіть
         невідомий сьогодні різновид .docx не зможе загубити текст непомітно.
    """
    try:
        import docx
    except Exception:
        return "[docx не розпізнано: встановіть python-docx]"
    try:
        d = docx.Document(io.BytesIO(raw))
        parts = _docx_render(d)
    except Exception as e:
        return f"[помилка читання docx: {e}]"

    text = "\n".join(parts)
    seen_lines = {ln.strip() for ln in text.split("\n")}
    extra = []
    for para in _docx_xml_paragraphs(raw):
        if para in seen_lines or para in text:
            continue
        extra.append(para)
    if extra:
        text += ("\n\n[ДОДАТКОВО ЗНАЙДЕНО В ДОКУМЕНТІ %d рядків тексту поза основною "
                 "структурою (напис, поле, вкладення). Наведено як є, порядок може "
                 "відрізнятись:]\n" % len(extra)) + "\n".join(extra)
    return text


def _from_xlsx(raw: bytes) -> str:
    try:
        import openpyxl
    except Exception:
        return "[xlsx не розпізнано: встановіть openpyxl]"
    try:
        wb = openpyxl.load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        out = []
        for ws in wb.worksheets:
            out.append(f"# Аркуш: {ws.title}")
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i > 500:
                    out.append("…[обрізано рядки]")
                    break
                vals = ["" if c is None else str(c) for c in row]
                if any(v.strip() for v in vals):
                    out.append(" | ".join(vals))
        return "\n".join(out)
    except Exception as e:
        return f"[помилка читання xlsx: {e}]"


def _from_pdf(raw: bytes) -> str:
    try:
        import pypdf
    except Exception:
        try:
            import PyPDF2 as pypdf  # запасний варіант
        except Exception:
            return "[pdf не розпізнано: встановіть pypdf]"
    try:
        reader = pypdf.PdfReader(io.BytesIO(raw))
        pages = []
        for i, page in enumerate(reader.pages):
            if i > 80:
                pages.append("…[обрізано сторінки]")
                break
            try:
                pages.append(page.extract_text() or "")
            except Exception:
                pages.append("")
        text = "\n".join(pages).strip()
        return text or "[pdf без текстового шару — можливо, скан без OCR]"
    except Exception as e:
        return f"[помилка читання pdf: {e}]"


def _from_csv(raw: bytes) -> str:
    text = _decode(raw)
    try:
        rows = list(csv.reader(io.StringIO(text)))
        return "\n".join(" | ".join(r) for r in rows[:600])
    except Exception:
        return text


# ═══════ СТАРИЙ WORD (.doc) — 17.08.2026, зміна 194 ═════════════════════════
# 🩸 ЖИВИЙ ПРОГІН 17.08: уся тендерна документація закупівлі Кривого Рогу
# опублікована файлами `.doc`, платформа їх не читала — і переліку обовʼязкових
# документів не побачила ЖОДНОГО. Клієнт отримав вільний пакет замість пакета
# за переліком замовника. Перевірено сигнатуру справжніх файлів: `d0 cf 11 e0` —
# це не перейменований RTF, а двійковий Word 97-2003 (OLE2).
#
# ⛒ ЧОМУ СВІЙ РОЗБІР, А НЕ БІБЛІОТЕКА. Уміння, яке є лише там, де хтось доставив
# пакет, — це не вміння продукту: у Каспера в збірці стоїть те, що ми привезли.
# Тут немає жодного імпорту поза стандартною бібліотекою.
# ⛒ І НЕ ВІДДАЄМО СМІТТЯ ЗА ТЕКСТ: якщо розбір не впорався, кажемо це прямо —
# і цей факт тепер доїжджає до воріт пакета (`source_intake` -> `check_pack`).
_OLE_SIG = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
_OLE_FREE, _OLE_END = 0xFFFFFFFF, 0xFFFFFFFE


class _Ole:
    """Мінімальний читач OLE2 (Compound File): рівно те, що треба для .doc."""

    def __init__(self, raw: bytes):
        if len(raw) < 512 or raw[:8] != _OLE_SIG:
            raise ValueError("не OLE2")
        self.raw = raw
        self.ssz = 1 << struct.unpack_from("<H", raw, 0x1E)[0]
        self.msz = 1 << struct.unpack_from("<H", raw, 0x20)[0]
        if self.ssz < 128 or self.msz < 16:
            raise ValueError("неправдоподібний розмір сектора")
        n_fat = struct.unpack_from("<I", raw, 0x2C)[0]
        self.dir0 = struct.unpack_from("<I", raw, 0x30)[0]
        self.cutoff = struct.unpack_from("<I", raw, 0x38)[0]
        mini0 = struct.unpack_from("<I", raw, 0x3C)[0]
        n_mini = struct.unpack_from("<I", raw, 0x40)[0]
        dif0 = struct.unpack_from("<I", raw, 0x44)[0]
        n_dif = struct.unpack_from("<I", raw, 0x48)[0]

        difat = list(struct.unpack_from("<109I", raw, 0x4C))
        sec, guard = dif0, 0
        while sec not in (_OLE_END, _OLE_FREE) and guard < n_dif + 64:
            blk = self._sector(sec)
            if len(blk) < self.ssz:
                break
            difat += list(struct.unpack_from("<%dI" % (self.ssz // 4 - 1), blk, 0))
            sec = struct.unpack_from("<I", blk, self.ssz - 4)[0]
            guard += 1

        self.fat = []
        for s in difat[:n_fat]:
            if s in (_OLE_FREE, _OLE_END):
                continue
            blk = self._sector(s)
            if len(blk) < self.ssz:
                break
            self.fat += list(struct.unpack_from("<%dI" % (self.ssz // 4), blk, 0))

        self.minifat = []
        sec, guard = mini0, 0
        while sec not in (_OLE_END, _OLE_FREE) and guard < n_mini + 64:
            blk = self._sector(sec)
            if len(blk) < self.ssz:
                break
            self.minifat += list(struct.unpack_from("<%dI" % (self.ssz // 4), blk, 0))
            sec = self.fat[sec] if sec < len(self.fat) else _OLE_END
            guard += 1

        self.entries = self._dir()
        self.mini_stream = b""
        root = self.entries[0] if self.entries else None
        if root and root["size"]:
            self.mini_stream = self._chain(root["start"], root["size"], mini=False)

    def _sector(self, i: int) -> bytes:
        off = 512 + int(i) * self.ssz
        return self.raw[off:off + self.ssz]

    def _chain(self, start: int, size: int, mini: bool) -> bytes:
        out, sec, guard = [], int(start), 0
        cap = (len(self.raw) // max(1, self.ssz)) + len(self.minifat) + 16
        while sec not in (_OLE_END, _OLE_FREE) and guard < cap:
            if mini:
                off = sec * self.msz
                out.append(self.mini_stream[off:off + self.msz])
                sec = self.minifat[sec] if sec < len(self.minifat) else _OLE_END
            else:
                out.append(self._sector(sec))
                sec = self.fat[sec] if sec < len(self.fat) else _OLE_END
            guard += 1
        return b"".join(out)[:size]

    def _dir(self) -> list:
        blob = self._chain(self.dir0, 1 << 30, mini=False)
        out = []
        for off in range(0, max(0, len(blob) - 127), 128):
            nlen = struct.unpack_from("<H", blob, off + 0x40)[0]
            if not (2 <= nlen <= 64):
                continue
            out.append({"name": blob[off:off + nlen - 2].decode("utf-16-le", "ignore"),
                        "type": blob[off + 0x42],
                        "start": struct.unpack_from("<I", blob, off + 0x74)[0],
                        "size": struct.unpack_from("<Q", blob, off + 0x78)[0]})
        return out

    def stream(self, name: str) -> bytes:
        for e in self.entries:
            if e["name"] == name and e["type"] == 2:
                return self._chain(e["start"], e["size"], mini=e["size"] < self.cutoff)
        return b""


def _doc_pieces(doc: bytes, tbl: bytes) -> str:
    """Текст за ТАБЛИЦЕЮ ШМАТКІВ (piece table) — рідний спосіб Word 97+.

    Кожен шматок або стиснутий (по байту на знак, cp1251 для української), або
    UTF-16. Вгадувати кодування не треба: про це каже прапорець у самому шматку.
    """
    fc_clx, lcb_clx = struct.unpack_from("<II", doc, 0x01A2)
    clx = tbl[fc_clx:fc_clx + lcb_clx]
    i = 0
    while i < len(clx) and clx[i] == 0x01:                    # Prc — пропускаємо
        i += 1 + 2 + struct.unpack_from("<H", clx, i + 1)[0]
    if i >= len(clx) or clx[i] != 0x02:
        raise ValueError("у таблиці немає переліку шматків")
    lcb = struct.unpack_from("<I", clx, i + 1)[0]
    pcdt = clx[i + 5:i + 5 + lcb]
    n = (len(pcdt) - 4) // 12
    if n <= 0:
        raise ValueError("порожній перелік шматків")
    cps = list(struct.unpack_from("<%dI" % (n + 1), pcdt, 0))
    out = []
    for k in range(n):
        at = 4 * (n + 1) + k * 8
        fc = struct.unpack_from("<I", pcdt, at + 2)[0]
        chars = cps[k + 1] - cps[k]
        if chars <= 0:
            continue
        if fc & 0x40000000:
            start = (fc & ~0x40000000) // 2
            out.append(doc[start:start + chars].decode("cp1251", "replace"))
        else:
            out.append(doc[fc:fc + chars * 2].decode("utf-16-le", "replace"))
    return "".join(out)


def _doc_clean(text: str) -> str:
    """Знаки Word -> звичайний текст. ТАБЛИЦЯ ЛИШАЄТЬСЯ ТАБЛИЦЕЮ.

    ⛒ У двійковому Word кінець комірки — \\x07, а кінець РЯДКА — другий \\x07
    одразу за ним. Не розібрати цього означає розсипати таблицю на абзаци — і
    «| Антитепловізорні пончо | шт | 125 |» поїде далі як окрема вимога.
    Віддаємо тим самим виглядом, що й `.docx`, щоб запобіжники платформи
    впізнавали рядок таблиці однаково на обох шляхах.
    """
    text = re.sub(r"\x13[^\x14\x15]*\x14", "", text)          # код поля — геть
    text = text.replace("\x0b", "\n").replace("\x0c", "\n")
    text = text.replace("\x1e", "-").replace("\x1f", "").replace("\xa0", " ")
    lines, cells, cur = [], [], []
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == "\r":
            if cells:
                cells.append("".join(cur).strip())
                lines.append("| " + " | ".join(cells) + " |")
                cells = []
            else:
                lines.append("".join(cur))
            cur = []
            i += 1
            continue
        if ch == "\x07":
            cells.append("".join(cur).strip())
            cur = []
            if i + 1 < len(text) and text[i + 1] == "\x07":
                lines.append("| " + " | ".join(cells) + " |")
                cells = []
                i += 2
                continue
            i += 1
            continue
        cur.append(ch)
        i += 1
    if cur or cells:
        cells.append("".join(cur).strip())
        lines.append(("| " + " | ".join(cells) + " |") if len(cells) > 1 else cells[0])
    out = re.sub(r"[\x00-\x08\x0e-\x1f]", "", "\n".join(lines))
    out = re.sub(r"[ \t]+", " ", out)
    return re.sub(r"\n{3,}", "\n\n", out).strip()


def _looks_like_text(s: str) -> bool:
    """⛒ ПРОБА НА СМІТТЯ. Розбір, який віддав кашу, гірший за чесне «не прочитав»:
    каша поїде в пакет клієнта як вимоги замовника."""
    t = (s or "").strip()
    if len(t) < 40:
        return False
    good = sum(1 for ch in t if ch.isalnum() or ch.isspace() or ch in ".,:;!?()«»\"'-—–/|№%")
    return good / len(t) >= 0.90


def _from_doc(raw: bytes) -> str:
    """Старий Word (.doc). Не впорались — кажемо це, а не вгадуємо."""
    try:
        ole = _Ole(raw)
        doc = ole.stream("WordDocument")
        if not doc or len(doc) < 0x01A6:
            raise ValueError("немає потоку WordDocument")
        if struct.unpack_from("<H", doc, 0)[0] not in (0xA5EC, 0xA5DC):
            raise ValueError("це OLE2, але не документ Word")
        flags = struct.unpack_from("<H", doc, 0x0A)[0]
        tbl = ole.stream("1Table" if (flags >> 9) & 1 else "0Table")
        if not tbl:
            raise ValueError("немає таблиці документа")
        text = _doc_clean(_doc_pieces(doc, tbl))
    except Exception as e:
        return ("[.doc не розібрано: %s — відкрийте файл самі й перевірте його зміст]"
                % (str(e)[:80] or type(e).__name__))
    if not _looks_like_text(text):
        return "[.doc не розібрано: текст не впізнано — відкрийте файл самі]"
    return text


def extract_text(name: str, raw: bytes, cap: int = None) -> str:
    """Текст із файлу. `cap` — СТЕЛЯ СПОЖИВАЧА: хто знає свій бюджет, той його й
    називає. Без неї діє власна стеля модуля (для файлів, доданих у чат)."""
    ext = _ext(name)
    if ext == ".docx":
        return _cap(_from_docx(raw), cap)
    if ext == ".doc":
        return _cap(_from_doc(raw), cap)
    if ext in (".xlsx", ".xlsm"):
        return _cap(_from_xlsx(raw), cap)
    if ext == ".pdf":
        return _cap(_from_pdf(raw), cap)
    if ext in (".csv", ".tsv"):
        return _cap(_from_csv(raw), cap)
    if ext in (".txt", ".md", ".json", ".log", ".yaml", ".yml", ".html", ".xml"):
        return _cap(_decode(raw), cap)
    # ⭐⭐⭐ 17.08.2026, зміна 194. ДВІЙКОВИЙ ФАЙЛ НЕ СМІЄ ПРОЙТИ ЗА ТЕКСТ.
    # 🩸 Знайдено ПРОБОЮ на справжньому `.xls`: він падав сюди, latin-1 декодував
    # кожен байт у «друкований» знак, частка проходила поріг 0.85 — і 5 632 знаки
    # каші їхали далі як ВМІСТ ДОКУМЕНТА ЗАМОВНИКА. Помітка «не підтримується»
    # чесна і зупиняє роботу; каша — ні, вона вдає зміст.
    # ⛒ Спершу дивимось на ПІДПИС файлу, потім на частку осмислених знаків.
    _bin = {b"\xd0\xcf\x11\xe0": "старий формат Microsoft Office (OLE2)",
            b"PK\x03\x04": "архів ZIP (можливо, docx/xlsx із чужим розширенням)",
            b"%PDF": "PDF", b"\x89PNG": "зображення PNG", b"\xff\xd8\xff": "зображення JPEG",
            b"Rar!": "архів RAR", b"\x1f\x8b": "архів GZIP", b"7z\xbc\xaf": "архів 7z"}
    for sig, human in _bin.items():
        if raw[:len(sig)] == sig:
            return "[%s — текст із цього файлу платформа не витягує]" % human
    text = _decode(raw)
    head = text[:1000]
    good = sum(1 for ch in head if ch.isalnum() or ch.isspace()
               or ch in ".,:;!?()[]{}«»\"'-—–/\\|№%@#$&*+=<>_")
    if text and good / max(1, len(head)) > 0.90:
        return _cap(text, cap)
    return f"[формат {ext or '?'} не підтримується для витягу тексту]"


def build_files_context(files: list) -> tuple:
    """
    files: [{'name': str, 'b64': 'data:...;base64,XXXX' або чистий base64}]
    Повертає (files_context_text, [meta]) де meta = {'name','chars'}.
    """
    import base64
    blocks = []
    meta = []
    for f in files or []:
        name = (f.get("name") or "file").strip()
        b64 = f.get("b64") or ""
        if "," in b64 and b64.strip().startswith("data:"):
            b64 = b64.split(",", 1)[1]
        try:
            raw = base64.b64decode(b64)
        except Exception:
            blocks.append(f"## Файл: {name}\n[не вдалося декодувати вміст]")
            meta.append({"name": name, "chars": 0})
            continue
        text = extract_text(name, raw)
        blocks.append(f"## Файл: {name}\n{text}")
        meta.append({"name": name, "chars": len(text)})
    return ("\n\n".join(blocks), meta)
