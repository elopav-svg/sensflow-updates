# -*- coding: utf-8 -*-
"""
taskdesk_tasks.py — САМА ЗАДАЧА: склад, стадії, стрічка, терміни, видимість.

Етап 2 Task Desk. Рішення, за якими це збудовано, — у памʼяті проєкту
(`project_taskdesk_domain`, `project_taskdesk_design`), узгоджені з Андрієм
02-06.08.2026. Уклад файла той самий, що в `taskdesk_people.py` і `scheduler.py`:
ОДИН НОРМАЛІЗАТОР · ОДИН ЧИТАЧ · ОДИН ПИСАР + слід у `audit[]`.

⭐⭐⭐ ЧОТИРИ РІШЕННЯ, ЯКІ ТУТ ВТІЛЕНІ ЯК ВОРОТА, А НЕ ЯК ПРОХАННЯ:

1. **ОДНА ФУНКЦІЯ ВИДИМОСТІ — `visible_ids()`.** Список, дошка, фільтр, пошук,
   картка і майбутні звіти питають ЇЇ. Видимість, розсипана по екранах, — той
   самий клас, що ворота лише на першому вході.

2. **ТЕРМІН МАЄ ОДНОГО ПИСАРЯ.** На диску лежить лише той термін, який ввела
   ЛЮДИНА. Порожній — ОБЧИСЛЮЄТЬСЯ з пунктів чек-листа при читанні
   (`due_effective`). Пункт із терміном за межею задачі — відмова з причиною.

3. **ЗАВЕРШИТИ БЕЗ РЕЗУЛЬТАТУ НЕ МОЖНА.** Результат — це ВКАЗІВНИК на коментар
   у стрічці (`result_comment_id`), а не копія його тексту: копія була б другим
   писарем однієї правди.

4. **ПРОТЕРМІНУВАННЯ — ОЗНАКА ПОВЕРХ СТАДІЇ, А НЕ СТАДІЯ.** Задача лишається
   там, де вона є, і горить червоним. Обчислюється при читанні, на диск не лягає.

⚠ МОЗОК (LLM) СЮДИ НЕ ХОДИТЬ. Стадії, права, терміни, звʼязки й закриття —
логічні скрипти. Єдиний майбутній міст до мозку — окремий `taskdesk_ai.py`
(рішення 21). Цей файл не імпортує ні `llm`, ні `agent`, ні `executor` — це
перевіряє чек деревом коду.
"""

import json
import re
from pathlib import Path

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import taskdesk_events as events   # НЕРВ: журнал подій і черга ротів
import taskdesk_people as people
import entity                      # спільне імʼя сутності на всю платформу
import protocol                    # ЗАГАЛЬНИЙ журнал усіх дій (хребет, 13.08.2026)
import links                       # ⭐ РЕЄСТР ЗВʼЯЗКІВ — один на всі шари (крок B2)
import taskdesk_links as tlinks    # СЛОВА, якими звʼязок читається людині (172 → B2)

# ⭐ ОДИН ПИСАР ШЛЯХУ: теку стану Task Desk оголошує нерв, тут лише беремо.
DESK_DIR = events.DESK_DIR
TASKS_DIR = DESK_DIR / "tasks"

AUDIT_KEEP = 200

# ---------------------------------------------------------------------------
# СТАДІЇ. Основна лінія + дві збоку. Протермінування стадією НЕ Є.
# ---------------------------------------------------------------------------
STAGE_NEW = "new"
STAGE_WORK = "in_work"
STAGE_REVIEW = "review"
STAGE_DONE = "done"
STAGE_HOLD = "postponed"
STAGE_CANCEL = "cancelled"

STAGES_MAIN = (STAGE_NEW, STAGE_WORK, STAGE_REVIEW, STAGE_DONE)
STAGES_SIDE = (STAGE_HOLD, STAGE_CANCEL)
STAGES_ALL = STAGES_MAIN + STAGES_SIDE
STAGES_CLOSED = (STAGE_DONE, STAGE_CANCEL)

STAGE_NAMES = {
    STAGE_NEW: "Нова",
    STAGE_WORK: "У роботі",
    STAGE_REVIEW: "На перевірці",
    STAGE_DONE: "Завершена",
    STAGE_HOLD: "Відкладена",
    STAGE_CANCEL: "Скасована",
}

# Ролі людини в задачі. Порядок важливий: сильніша роль перемагає слабшу.
ROLE_AUTHOR = "author"          # постановник
ROLE_ASSIGNEE = "assignee"      # виконавець — ОДИН, уся відповідальність на ньому
ROLE_CO = "coassignee"          # співвиконавець — РЕСУРС, доданий постановником
ROLE_WATCHER = "watcher"        # спостерігач — перегляд і коментарі, і все

ROLE_NAMES = {
    ROLE_AUTHOR: "постановник",
    ROLE_ASSIGNEE: "виконавець",
    ROLE_CO: "співвиконавець",
    ROLE_WATCHER: "спостерігач",
}

# ⭐ Рішення 25, вузький варіант: якщо підлеглий у задачі ЛИШЕ спостерігач,
# керівникові вона не показується — інакше через одного спостерігача керівникові
# заїдуть задачі чужих підрозділів. Одна константа = одне місце, де це
# перемикається, якщо Андрій вирішить інакше.
MANAGER_SEES_WATCHER_ONLY = False

# ⭐ ПРОПОЗИЦІЯ МОЗКУ — це ПРОХАННЯ, а не дія. Стан у неї свій, щоб та сама
# порада не спливала щоразу, коли її вже відхилили.
PROPOSAL_DUE = "due"                 # «посунути термін до …»
PROPOSAL_OPEN = "open"
PROPOSAL_ACCEPTED = "accepted"
PROPOSAL_DECLINED = "declined"
AI_ACTOR = "ai"                      # автор запису, який зробив мозок

# Похідні поля: ОБЧИСЛЮЮТЬСЯ при читанні й НІКОЛИ не лежать на диску.
DERIVED = ("broken", "broken_reason", "due_effective", "due_source", "overdue",
           "stage_name", "author_name", "assignee_name", "participant_ids",
           "checklist_done", "checklist_total", "result_text", "days_left",
           "open_proposals", "has_proposal", "links", "links_in")

# ⭐⭐⭐ КРОК B2 (14.08.2026): `links` СТАЛО ПОХІДНИМ І БІЛЬШЕ НЕ ЛЕЖИТЬ У ФАЙЛІ
# ЗАДАЧІ. Факт звʼязку живе в реєстрі `links.py` — бо він не є власністю жодної
# зі сторін. Обидва боки (`links` — куди веду я, `links_in` — хто веде до мене)
# читаються ОДНИМ запитом до реєстру, а не перебором усіх файлів задач.
# ⚠ Задача, у файлі якої ще лежить СТАРЕ поле `links`, оголошується ЗЛАМАНОЮ з
# причиною словами: мовчки прочитати його як правду означало б завести другого
# писаря звʼязків, а мовчки викинути — загубити роботу людини. Лікує це переїзд
# (`migrate_links.py`), і задача сама скаже, що його не робили.


class TaskError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return "" if v is None else str(v).strip()


def _ids(v) -> list:
    out, seen = [], set()
    for x in (v or []):
        x = _s(x)
        if x and x not in seen:
            seen.add(x)
            out.append(x)
    return out


# ---------------------------------------------------------------------------
# ЧАС І ТЕРМІНИ
# ---------------------------------------------------------------------------
DUE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2})?$")


def _norm_due(v) -> str:
    """Термін на диску — машинний рядок `YYYY-MM-DD` або `YYYY-MM-DDTHH:MM`.
    Людині його показує екран у форматі DD.MM.YYYY — перетворення живе там,
    у файлі стану дата лежить в одному вигляді."""
    s = _s(v).replace(" ", "T")
    if not s:
        return ""
    if not DUE_RE.match(s):
        raise TaskError("Термін «%s» не схожий на дату. Приклад: 2026-08-15 17:00" % v)
    return s


def due_from_human(text) -> str:
    """Дата, набрана людиною (DD.MM.YYYY або DD.MM.YYYY HH:MM), -> машинна.
    Порожньо, якщо це не дата.

    ЗІРКА. ОДИН ПИСАР РОЗУМІННЯ ДАТИ. Він знадобився телефону (у телеграмі
    немає нашого календаря), але живе ТУТ, поруч із `_norm_due`: щойно дату
    почне розбирати ще й пошта чи голосовий бот, вони питатимуть це саме
    місце, а не заведуть свій формат.
    """
    v = " ".join(_s(text).replace("/", ".").split())
    m = re.match(r"^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s+(\d{1,2}):(\d{2}))?$", v)
    if not m:
        return ""
    d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    hh, mm = int(m.group(4) or 0), int(m.group(5) or 0)
    from datetime import datetime          # як і решта дат у цьому файлі
    try:
        datetime(y, mo, d, hh, mm)
    except ValueError:
        return ""            # 31.02.2026 — не дата
    # УВАГА, дорого куплено 09.08.2026: тут стояло `except Exception`, і воно
    # проковтнуло NameError від незробленого імпорту. Функція мовчки повертала
    # «це не дата» НА ВСЕ, і жодного сліду не лишалось. Мовчазний except ховає
    # не лише чужу помилку, а й твою власну — тому ловимо РІВНО ValueError.
    out = "%04d-%02d-%02d" % (y, mo, d)
    return out + ("T%02d:%02d" % (hh, mm) if (hh or mm) else "")


def _due_key(s: str) -> str:
    """Порівнюваний вигляд: дата без часу означає кінець того дня."""
    s = _s(s)
    if not s:
        return ""
    return s if "T" in s else s + "T23:59"


# ---------------------------------------------------------------------------
# ОДИН НОРМАЛІЗАТОР
# ---------------------------------------------------------------------------
def _normalize(raw, tid: str) -> dict:
    """Будь-який запис, хоч побитий, виходить звідси з повним набором полів.
    Зламаність — ОЗНАКА, а не окреме життя й не тиша."""
    broken, reason = False, ""
    if not isinstance(raw, dict):
        broken, reason, raw = True, "файл задачі не є записом", {}

    t = {
        "id": _s(raw.get("id")) or tid,
        "title": _s(raw.get("title")),
        "description": _s(raw.get("description")),
        "author_id": _s(raw.get("author_id")),
        "assignee_id": _s(raw.get("assignee_id")),
        "coassignee_ids": _ids(raw.get("coassignee_ids")),
        "watcher_ids": _ids(raw.get("watcher_ids")),
        "stage": _s(raw.get("stage")) or STAGE_NEW,
        "due_at": _s(raw.get("due_at")),
        "checklist": [],
        "feed": [],
        "proposals": [],          # що ПРОПОНУЄ мозок; сам він нічого не змінює
        # ⭐ ФАКТ ПРОТЕРМІНУВАННЯ ЛЕЖИТЬ НА ДИСКУ (зміна 172): `overdue_at` — коли
        # платформа ПОБАЧИЛА перетин строку, `overdue_for` — ЯКИЙ саме строк було
        # перетнуто. Друге потрібне, щоб посунутий термін давав НОВИЙ факт, а не
        # мовчав під старою позначкою.
        "overdue_at": _s(raw.get("overdue_at")),
        "overdue_for": _s(raw.get("overdue_for")),
        "source": _s(raw.get("source")),          # звідки прийшла: crm, telegram, ...
        "source_ref": _s(raw.get("source_ref")),
        "result_comment_id": _s(raw.get("result_comment_id")),
        "refusal_reason": _s(raw.get("refusal_reason")),
        "created_at": _s(raw.get("created_at")),
        "updated_at": _s(raw.get("updated_at")),
        "audit": [a for a in (raw.get("audit") or []) if isinstance(a, dict)][-AUDIT_KEEP:],
    }

    # ⭐ СТАРЕ ПОЛЕ НА ДИСКУ — ЦЕ НЕ ДАНІ, ЦЕ НЕЗАВЕРШЕНИЙ ПЕРЕЇЗД (крок B2).
    # Прочитати його як правду означало б мати ДВОХ писарів звʼязку (файл і
    # реєстр) — рівно те, на чому ми горіли 09-11.08. Промовчати — загубити
    # роботу людини. Тому задача каже про це вголос, а лікує `migrate_links.py`.
    if raw.get("links"):
        broken = True
        reason = reason or ("звʼязки задачі ще не переїхали до реєстру — "
                            "запустіть `migrate_links.py --apply`")

    if t["stage"] not in STAGES_ALL:
        broken, reason = True, "невідома стадія «%s»" % t["stage"]
        t["stage"] = STAGE_NEW
    if not t["title"]:
        broken, reason = True, reason or "у задачі немає назви"

    for i, raw_item in enumerate(raw.get("checklist") or []):
        if not isinstance(raw_item, dict):
            continue
        t["checklist"].append({
            "id": _s(raw_item.get("id")) or ("c%d" % (i + 1)),
            "text": _s(raw_item.get("text")),
            "done": bool(raw_item.get("done")),
            "due_at": _s(raw_item.get("due_at")),
            "assignee_id": _s(raw_item.get("assignee_id")),
        })
    for i, raw_c in enumerate(raw.get("feed") or []):
        if not isinstance(raw_c, dict):
            continue
        t["feed"].append({
            "id": _s(raw_c.get("id")) or ("m%d" % (i + 1)),
            "author_id": _s(raw_c.get("author_id")),
            "text": _s(raw_c.get("text")),
            "at": _s(raw_c.get("at")),
            "kind": _s(raw_c.get("kind")) or "comment",   # comment | event
        })

    # ⭐ ПРОПОЗИЦІЇ МОЗКУ. Лежать поруч із задачею, але НІЧОГО в ній не міняють,
    # доки людина не натисне «Прийняти». Мозок не є писарем терміну.
    for i, raw_p in enumerate(raw.get("proposals") or []):
        if not isinstance(raw_p, dict):
            continue
        t["proposals"].append({
            "id": _s(raw_p.get("id")) or ("p%d" % (i + 1)),
            "kind": _s(raw_p.get("kind")) or PROPOSAL_DUE,
            "date": _norm_due(raw_p.get("date")),
            "why": _s(raw_p.get("why"))[:300],
            "quote": _s(raw_p.get("quote"))[:300],
            "from_comment": _s(raw_p.get("from_comment")),
            "at": _s(raw_p.get("at")),
            "state": _s(raw_p.get("state")) or PROPOSAL_OPEN,
            "decided_by": _s(raw_p.get("decided_by")),
        })

    # Результат мусить вказувати на існуючий коментар — інакше це не вказівник.
    if t["result_comment_id"] and not any(
            c["id"] == t["result_comment_id"] for c in t["feed"]):
        broken = True
        reason = reason or "результат указує на коментар, якого немає"
        t["result_comment_id"] = ""

    t["broken"] = broken
    t["broken_reason"] = reason
    return t


def _derive(t: dict, names: dict, now: str, idx=None) -> dict:
    """Похідне рахуємо ТУТ і ніде більше. На диск воно не лягає ніколи.

    ⭐ КРОК B2: `idx` — ЗНІМОК РЕЄСТРУ ЗВʼЯЗКІВ, прочитаний ОДИН раз тим, хто
    читає багато задач. Без нього кожна задача перечитувала б реєстр із диска.
    Не передали — читаємо самі: правду віддає диск, а не зручність викликача."""
    t = dict(t)
    idx = links.index() if idx is None else idx
    _me = entity.ref(entity.KIND_TASK, t["id"])
    # ⭐⭐⭐ ОБИДВА БОКИ — ОДИН ЗАПИТ ДО РЕЄСТРУ. Раніше зворотний бік був
    # ПЕРЕБОРОМ УСІХ ФАЙЛІВ ЗАДАЧ і рахувався лише в `load_all`; тому картка,
    # відкрита напряму, його не бачила. Тепер він коштує стільки ж, скільки
    # прямий, і брехати про «не рахували» більше нема потреби.
    t["links"] = idx.out(_me)
    t["links_in"] = idx.inc(_me)

    # ⭐ Рішення 22: якщо термін задачі не вводила людина — він дорівнює
    # найпізнішому терміну пункту чек-листа.
    if t["due_at"]:
        t["due_effective"], t["due_source"] = t["due_at"], "людина"
    else:
        item_dues = [c["due_at"] for c in t["checklist"] if c["due_at"]]
        if item_dues:
            t["due_effective"] = max(item_dues, key=_due_key)
            t["due_source"] = "чек-лист"
        else:
            t["due_effective"], t["due_source"] = "", ""

    # ⭐ Рішення 6: протермінування — ОЗНАКА поверх стадії.
    due_k = _due_key(t["due_effective"])
    t["overdue"] = bool(due_k and t["stage"] not in STAGES_CLOSED and due_k < now)
    t["days_left"] = _days_left(due_k, now)

    t["stage_name"] = STAGE_NAMES.get(t["stage"], t["stage"])
    t["author_name"] = names.get(t["author_id"], "")
    t["assignee_name"] = names.get(t["assignee_id"], "")
    t["participant_ids"] = participants(t)
    t["checklist_total"] = len(t["checklist"])
    t["checklist_done"] = len([c for c in t["checklist"] if c["done"]])
    t["open_proposals"] = [p for p in t.get("proposals", [])
                           if p["state"] == PROPOSAL_OPEN]
    t["has_proposal"] = bool(t["open_proposals"])
    t["result_text"] = ""
    if t["result_comment_id"]:
        for c in t["feed"]:
            if c["id"] == t["result_comment_id"]:
                t["result_text"] = c["text"]
                break
    return t


def _days_left(due_key: str, now: str):
    if not due_key:
        return None
    try:
        from datetime import datetime
        a = datetime.strptime(due_key[:16], "%Y-%m-%dT%H:%M")
        b = datetime.strptime(now[:16], "%Y-%m-%dT%H:%M")
        return int((a - b).total_seconds() // 86400)
    except Exception:
        return None


def participants(t: dict) -> list:
    """Усі, хто в задачі. Порядок ролей — від сильнішої до слабшої."""
    out = []
    for x in ([t.get("author_id"), t.get("assignee_id")]
              + list(t.get("coassignee_ids") or [])
              + list(t.get("watcher_ids") or [])):
        x = _s(x)
        if x and x not in out:
            out.append(x)
    return out


def roles_of(t: dict, emp_id: str) -> tuple:
    """⭐⭐⭐ УСІ ролі людини в задачі, від сильнішої до слабшої.

    08.08.2026. Раніше тут була ОДНА роль — і це був глухий кут: той, хто
    поставив задачу САМ СОБІ, ставав «виконавцем» і втрачав права постановника.
    Він не міг ні правити свою задачу, ні прийняти її: здав на перевірку — і
    приймати нікому. Для клієнта, який у системі один, це означало, що ЖОДНА
    його задача не закривається.

    Закон тепер такий самий, як у дорослих системах: **людина має стільки прав,
    скільки дають УСІ її ролі разом**. Одна роль ніколи не відбирає того, що
    дала інша."""
    emp_id = _s(emp_id)
    if not emp_id:
        return ()
    out = []
    if emp_id == _s(t.get("assignee_id")):
        out.append(ROLE_ASSIGNEE)
    if emp_id == _s(t.get("author_id")):
        out.append(ROLE_AUTHOR)
    if emp_id in (t.get("coassignee_ids") or []):
        out.append(ROLE_CO)
    if emp_id in (t.get("watcher_ids") or []):
        out.append(ROLE_WATCHER)
    return tuple(out)


def role_of(t: dict, emp_id: str) -> str:
    """ГОЛОВНА роль — лише щоб показати людині одним словом, хто вона тут.
    Права рахуються НЕ звідси, а з `roles_of()`: див. `may()`."""
    rr = roles_of(t, emp_id)
    return rr[0] if rr else ""


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ
# ---------------------------------------------------------------------------
def _path(tid: str) -> Path:
    if not re.match(r"^T-\d{6}$", _s(tid)):
        raise TaskError("Номер задачі «%s» не схожий на наш (T-000001)." % tid)
    return TASKS_DIR / ("%s.json" % tid)


def load_all(include_closed: bool = True) -> list:
    """ЄДИНЕ місце, де читається диск задач. Далі всі беруть правду звідси."""
    TASKS_DIR.mkdir(parents=True, exist_ok=True)
    now = clock.now()[:16]
    names = {e["id"]: e.get("full_name", "") for e in people.employees(True)}
    idx = links.index()               # реєстр звʼязків читаємо ОДИН раз на весь обхід
    everyone = []
    for p in sorted(TASKS_DIR.glob("T-*.json")):
        tid = p.stem
        try:
            raw = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            raw = {"title": "", "audit": []}
            t = _normalize(raw, tid)
            t["broken"], t["broken_reason"] = True, "файл не прочитався: %s" % e
        else:
            t = _normalize(raw, tid)
        everyone.append(_derive(t, names, now, idx))

    # ⭐⭐⭐ ЗВОРОТНИЙ БІК РАХУЄМО, А НЕ ЗБЕРІГАЄМО — і тепер РЕЄСТРОМ, а не
    # перебором чужих файлів (крок B2). Звʼязок лежить рівно один раз, і обидва
    # боки читаються з одного місця; другого писаря однієї правди не існує.
    # ⚠ Читається ДО відсіву закритих: закрита задача, яка блокує живу, — це
    # саме те, що людині треба побачити.
    out = [t for t in everyone
           if include_closed or t["stage"] not in STAGES_CLOSED]
    out.sort(key=lambda t: t["id"], reverse=True)
    return out


def task(tid: str, incoming: bool = False) -> dict:
    """Одна задача — з обома боками звʼязків.

    ⭐ КРОК B2: параметр `incoming` лишений заради старих викликачів і БІЛЬШЕ
    НІЧОГО НЕ ВМИКАЄ. Раніше зворотний бік коштував перебору всіх файлів задач,
    і тому був окремим — свідомо дорожчим — шляхом. Тепер це один запит до
    реєстру, і ділити читання на «дешеве без зворотного боку» та «дороге зі
    зворотним» стало брехнею про ціну."""
    p = _path(tid)
    if not p.exists():
        raise TaskError("Задачі %s немає." % tid)
    now = clock.now()[:16]
    names = {e["id"]: e.get("full_name", "") for e in people.employees(True)}
    return _derive(_normalize(json.loads(p.read_text(encoding="utf-8")), tid), names, now)


def next_id() -> str:
    """Номер рахуємо з наявних файлів — щоб не заводити ДРУГОГО писаря лічильника."""
    TASKS_DIR.mkdir(parents=True, exist_ok=True)
    top = 0
    for p in TASKS_DIR.glob("T-*.json"):
        try:
            top = max(top, int(p.stem.split("-")[1]))
        except Exception:
            continue
    return "T-%06d" % (top + 1)


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ОДНА ФУНКЦІЯ ВИДИМОСТІ НА ВЕСЬ ПРОДУКТ
# ---------------------------------------------------------------------------
def visible_ids(emp_id: str, tasks: list = None) -> set:
    """Хто що взагалі БАЧИТЬ (це не те саме, що «що можна ЗРОБИТИ»).

    - працівник бачить свої задачі: постановник · виконавець · співвиконавець ·
      спостерігач;
    - керівник додатково бачить усе, що доручено, виконується або створено його
      підлеглими на ВСІХ рівнях униз (ланцюг береться з дерева підрозділів,
      другого списку підлеглих не існує);
    - головний директор — не окремий випадок у коді: він керівник кореневого
      підрозділу, і правило керівника вже дає йому всю компанію.

    Фільтр екрана може лише ЗВУЗИТИ цей набір, ніколи не розширити."""
    emp_id = _s(emp_id)
    tasks = load_all() if tasks is None else tasks
    if not emp_id:
        return set()
    mine = set(people.subordinates_of(emp_id) or [])
    seen = set()
    for t in tasks:
        if role_of(t, emp_id):
            seen.add(t["id"])
            continue
        for sub in mine:
            role = role_of(t, sub)
            if not role:
                continue
            if role == ROLE_WATCHER and not MANAGER_SEES_WATCHER_ONLY:
                continue
            seen.add(t["id"])
            break
    return seen


def visible_tasks(emp_id: str, include_closed: bool = True) -> list:
    tasks = load_all(include_closed=include_closed)
    ok = visible_ids(emp_id, tasks)
    return [t for t in tasks if t["id"] in ok]


# ---------------------------------------------------------------------------
# ОДИН ПИСАР
# ---------------------------------------------------------------------------
def _strip_derived(t: dict) -> dict:
    return {k: v for k, v in t.items() if k not in DERIVED}


def _reason(kind: str, det: dict, t: dict) -> str:
    """ОДИН ПИСАР СЛІДУ. Рядок у `audit` більше не приходить ззовні готовим
    текстом — він НАРОДЖУЄТЬСЯ з події. Тому слід у задачі й повідомлення в чат
    не можуть розійтись: у них одне джерело — вид і деталі."""
    if kind == events.KIND_CREATED:
        return "задачу створено"
    if kind == events.KIND_COMMENT:
        return "коментар"
    if kind == events.KIND_RESULT:
        return "додано результат" if det.get("with_text") else "позначено результат"
    if kind == events.KIND_STAGE:
        st = _s(det.get("stage"))
        return "стадія → %s" % STAGE_NAMES.get(st, st)
    if kind == events.KIND_DELEGATED:
        return "передано виконавцю"
    if kind == events.KIND_REFUSED:
        return "відмова з причиною"
    if kind == events.KIND_UPDATED:
        return "задачу змінено: " + " · ".join(det.get("said") or [])
    if kind == events.KIND_PROPOSAL:
        return "пропозиція терміну %s" % _human(_s(det.get("date")))
    if kind == events.KIND_PROPOSAL_DONE:
        return "пропозицію %s" % ("прийнято" if det.get("accepted") else "відхилено")
    if kind == events.KIND_CHECKLIST:
        return "пункт плану"
    if kind == events.KIND_LINKED:
        return "звʼязок — %s" % tlinks.phrase(det.get("rel"), det.get("ref"))
    if kind == events.KIND_UNLINKED:
        return "звʼязок прибрано — %s" % tlinks.phrase(det.get("rel"), det.get("ref"))
    if kind == events.KIND_OVERDUE:
        return "строк %s минув" % _human(_s(det.get("due")))
    return events.KIND_NAMES.get(kind, kind)


def save(t: dict, actor_id: str, ev) -> dict:
    """Кожна зміна лишає слід І народжує подію. Писар один — тому ні журнал
    задачі, ні сповіщення не розʼїжджаються.

    ⭐⭐⭐ ТРЕТІЙ ПАРАМЕТР — ПОДІЯ, А НЕ ТЕКСТ ПРИЧИНИ. Так «повідомити» перестало
    бути окремим кроком поруч зі збереженням, який можна забути в одному з
    одинадцяти місць: **без події задача просто не збережеться**. Правило в
    промпті — прохання; ворота — це коли інакше не виходить фізично."""
    kind, det = events.parts(ev)
    TASKS_DIR.mkdir(parents=True, exist_ok=True)
    clean = _strip_derived(t)
    p = _path(clean["id"])
    before = {}
    if p.exists():
        try:
            before = json.loads(p.read_text(encoding="utf-8"))
        except Exception as e:
            raise TaskError("Задача %s на диску не читається: %s" % (clean["id"], e))
    clean["updated_at"] = clock.now()
    clean["audit"] = (clean.get("audit") or [])[-AUDIT_KEEP:]
    clean["audit"].append({"at": clock.now(), "who": _s(actor_id),
                           "what": _reason(kind, det, clean)[:300]})
    p.write_text(json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8")
    to = recipients(before, clean, kind, _s(actor_id))
    try:
        events.emit(kind, clean["id"], _s(actor_id), det, to,
                    title=_s(clean.get("title")))
    except Exception as e:
        # Задача вже на диску. Подію НЕ ковтаємо мовчки: лишаємо слід, з якого
        # її можна повторити, і кажемо вголос. Тихий успіх убиває продукт.
        events.lost({"kind": kind, "task_id": clean["id"], "actor_id": _s(actor_id),
                     "details": det, "to": to,
                     "task_title": _s(clean.get("title"))},
                    "не вдалося записати подію: %s" % e)
    _to_protocol(clean, actor_id, kind, det, bool(before))
    return task(clean["id"])


def _lateness(due_iso: str, done_iso: str) -> tuple:
    """(підсумок словами, днів запізнення) для факту закриття задачі.

    ⭐ ЧОМУ ЦЕ ФАКТ, А НЕ РОЗБІР ТЕКСТУ (зміна 173). «Відсоток своєчасного
    виконання» — те, заради чого Андрій просив рейтинг. Якби він рахувався
    пошуком слова в примітці, це був би рівно наш власний заборонений «чек по
    рядку в тексті»: варто комусь переписати формулювання — і відсоток мовчки
    поїде. Тому висновок робиться ТУТ, один раз, з двох дат.

    ⚠ СТРОКУ МОГЛО НЕ БУТИ, і це не «вчасно». Задача-нагадування без терміну
    не має чого порушувати — вигадати їй «вчасно» означало б завищити рейтинг
    того, хто просто не ставить строків."""
    from datetime import datetime          # як і решта дат у цьому файлі
    due, done = _s(due_iso), _s(done_iso)
    if not due:
        return ("строку не було", 0)
    try:
        d1 = datetime.fromisoformat(due[:19] if len(due) >= 19 else due[:10])
        d2 = datetime.fromisoformat(done[:19] if len(done) >= 19 else done[:10])
    except Exception:
        return ("строку не було", 0)
    if d2 <= d1:
        return ("вчасно", 0)
    late = (d2.date() - d1.date()).days
    return ("із запізненням", max(late, 0))


def _to_protocol(clean: dict, actor_id, kind: str, det: dict, existed: bool) -> None:
    """ТОЧКА ВРІЗКИ №2 — ЗАДАЧІ (хребет, 13.08.2026).

    ⛒ НЕРВ (`taskdesk_events`) ЗАЛИШАЄТЬСЯ НЕРВОМ. Він веде чергу доставки й
    курсори ротів — навантажити його ще й платформною аналітикою означало б
    зробити з одного механізму два. Тому він просто ще одне ДЖЕРЕЛО протоколу.

    ⭐ Створення і зміна — РІЗНІ дієслова, бо це різні відповіді на питання «де
    робота застрягає»: народження задачі і рух по ній рахуються окремо. Різницю
    знає рівно це місце (`before` уже прочитано з диска), тому вгадувати не треба.

    ⚠ Ніколи не кидає: задача вже на диску."""
    # ⭐ КРОК B2: ЗВʼЯЗОК ЗВІТУЄ САМ РЕЄСТР (`link.created` / `link.removed`) —
    # бо звʼязок тепер буває не лише в задачі. Написати ще й звідси означало б
    # ДВА рядки протоколу на одну дію, і будь-який підрахунок «скільки звʼязків
    # завели» подвоївся б. Старі рядки `task.linked` / `task.unlinked` лишаються
    # у словнику назавжди і читаються звітом: журнал append-only не переписують.
    if kind in (events.KIND_LINKED, events.KIND_UNLINKED):
        return
    try:
        ref = entity.ref(entity.KIND_TASK, _s(clean.get("id")))
        who = entity.person_of_employee(_s(actor_id))
        # ⚠ МАШИННИЙ ФАКТ НЕ ВІДКРИВАЄ КРОКУ РОБОТИ. Сторож строків обходить сотні
        # задач підряд; якби кожна лишалась у контексті потоку, наступний запис
        # приписався б випадковій сусідці.
        if kind != events.KIND_OVERDUE:
            protocol.bind(task=ref)
            if who:
                protocol.bind(actor=who)
        act = protocol.A_TASK_CHANGED if existed else protocol.A_TASK_CREATED
        outcome = protocol.OUT_OK
        about = []
        source = ""
        note_over = ""

        # ⭐⭐⭐ РЯДОК НАЗИВАЄ ОБИДВІ СТОРОНИ (зміна 173, 14.08.2026).
        # КОРІНЬ. Постановник у протоколі був завжди — це `актор`. А виконавця
        # не було НІДЕ: журнал казав «Петренко поставив задачу» і не казав
        # КОМУ. Через це не збиралась пара «хто → кому», а без неї немає ні
        # рейтингу постановників, ні виконавської дисципліни підрозділу —
        # рівно того, заради чого Андрій просив протокол (14.08.2026).
        # ⛒ ВИКОНАВЦЯ ПИШЕМО ЛИШЕ ТУДИ, ДЕ ПИТАННЯ «КОМУ» МАЄ СЕНС: народження
        # задачі · рух по стадіях (зокрема закриття) · зміна виконавця ·
        # протермінування · відмова. Вішати його на КОЖЕН коментар означало б
        # роздути журнал і зробити «дій по людині» мірою балакучості, а не роботи.
        # ⛒ І ЛИШЕ ІДЕНТИЧНІСТЬ (`person:emp-…`), А НЕ КОПІЯ ПОЛІВ. Підрозділ,
        # посада, керівник живуть у `taskdesk_people` і приєднуються ПРИ
        # ЧИТАННІ звіту. Якби відділ лягав копією в рядок, то переведення
        # людини в інший відділ змусило б увесь торішній журнал брехати.
        _SIDED = (events.KIND_CREATED, events.KIND_STAGE, events.KIND_DELEGATED,
                  events.KIND_OVERDUE, events.KIND_REFUSED)
        if kind in _SIDED:
            _ass = entity.person_of_employee(_s(clean.get("assignee_id")))
            if _ass:
                about = [_ass]

        if kind == events.KIND_REFUSED:
            outcome = "%s: %s" % (protocol.OUT_REFUSED,
                                  _s(det.get("reason")) or "виконавець відмовився")
        elif kind == events.KIND_STAGE and _s(det.get("stage")) == STAGE_DONE:
            # ⭐ ЗАКРИТТЯ — ОКРЕМЕ ДІЄСЛОВО, А ПІДСУМОК — ГОТОВИЙ ВИСНОВОК.
            # Раніше це був звичайний `task.changed` із приміткою «стадія →
            # Виконана»: щоб порахувати відсоток вчасних, звіту довелося б
            # шукати підрядок у тексті. Тепер «вчасно / із запізненням» стоїть
            # у самому рядку, і формулювання можна міняти без шкоди рахунку.
            act = protocol.A_TASK_DONE
            _verdict, _days = _lateness(_s(clean.get("due_at")), clock.now())
            # ⛒ ВЕРДИКТ — У ПІДСУМОК, А НЕ В ТЕКСТ. Примітка лишається для ока
            # людини; рахує звіт САМЕ підсумок (`protocol.OUT_LATE`), тому
            # формулювання можна переписати, не зламавши жодного відсотка.
            if _verdict == "із запізненням":
                outcome = "%s: %s" % (protocol.OUT_LATE,
                                      "строк %s, прострочено на %d дн."
                                      % (_human(_s(clean.get("due_at"))), _days))
            note_over = ("виконано %s" % _verdict
                         + (" на %d дн." % _days if _days else ""))
        elif kind == events.KIND_OVERDUE:
            act = protocol.A_TASK_OVERDUE
            # Протермінування — це межа ЧАСУ, яка обірвала роботу, а не поломка
            # і не відмова: у словнику підсумків це рівно `stopped`.
            outcome = "%s: %s" % (protocol.OUT_STOPPED,
                                  "строк %s минув" % _human(_s(det.get("due"))))
            # ⚠ ДІЯЧА-ЛЮДИНИ ТУТ НЕМАЄ І ВИГАДУВАТИ ЙОГО НЕ МОЖНА. Хто це зробив,
            # каже ДЖЕРЕЛО: сама платформа. Підставити сюди виконавця означало б
            # записати в журнал, ніби він щось зробив, — а він саме що НЕ зробив.
            # ⭐ І ЦЕ НЕ СУПЕРЕЧИТЬ ВИКОНАВЦЮ В `about` (173): «діяч» відповідає
            # на питання ХТО ЗРОБИВ, а «про кого» — НА КОМУ ВИСІЛО. Друге для
            # протермінування якраз і є суттю рядка, і мовчати про це не можна:
            # інакше «де підрозділ гальмує» не порахувати взагалі.
            source = protocol.S_SYSTEM
        # 🩸 І КОНТЕКСТ КРОКУ СЮДИ НЕ ЗАЛІЗЕ. Порожній діяч доповнюється тим, хто
        # діяв на цьому потоці востаннє, — і рядок «строк минув» дістав би імʼя
        # людини, яка саме що НІЧОГО не робила. Той самий клас, що й ціна кроку,
        # приписана останньому прогону (зміна 169).
        protocol.write(act, ref, actor=who, about=about, outcome=outcome,
                       source=source, note=note_over or _reason(kind, det, clean),
                       use_context=(kind != events.KIND_OVERDUE))
    except Exception:
        pass


def _require_worker(emp_id: str, what: str):
    """Виконавцем-людиною може бути ВИКЛЮЧНО активний працівник компанії."""
    emp = people.employee(emp_id)
    if not emp:
        raise TaskError("Працівника для ролі «%s» не знайдено." % what)
    if not people.can_receive_tasks(emp_id):
        raise TaskError("%s не може отримувати задачі: працівник звільнений."
                        % emp.get("full_name", what))
    return emp


def _human(iso: str) -> str:
    """Термін у сліді — очима людини (DD.MM.YYYY), а не як на диску."""
    v = _s(iso)
    if len(v) < 10:
        return v
    out = "%s.%s.%s" % (v[8:10], v[5:7], v[0:4])
    return (out + " " + v[11:16]) if len(v) >= 16 else out


def _who(ids) -> str:
    return ", ".join([people.employee(i).get("full_name", i) for i in (ids or [])])


def _check_checklist_due(due_task: str, checklist: list):
    """Пункт із терміном ЗА МЕЖЕЮ терміну задачі — відмова з причиною."""
    if not due_task:
        return
    limit = _due_key(due_task)
    for c in checklist:
        if c.get("due_at") and _due_key(c["due_at"]) > limit:
            raise TaskError(
                "Пункт «%s» має термін пізніший за термін задачі. "
                "Або перенесіть пункт, або посуньте термін задачі."
                % (c.get("text") or c.get("id")))


def create(actor_id: str, title: str, assignee_id: str = "", due_at: str = "",
           description: str = "", coassignee_ids=None, watcher_ids=None,
           checklist=None, source: str = "", source_ref: str = "") -> dict:
    """Обовʼязкова лише НАЗВА.

    ⭐ Постановник має право записати задачу СОБІ й без терміну — як нагадування.
    Цієї можливості його позбавляти не можна (слова Андрія, 02.08.2026)."""
    title = _s(title)
    if not title:
        raise TaskError("У задачі має бути назва.")
    actor_id = _s(actor_id)
    if not actor_id:
        raise TaskError("Не видно, хто ставить задачу.")
    _require_worker(actor_id, "постановник")

    assignee_id = _s(assignee_id) or actor_id
    _require_worker(assignee_id, "виконавець")

    co = [x for x in _ids(coassignee_ids) if x != assignee_id]
    for x in co:
        _require_worker(x, "співвиконавець")
    watchers = [x for x in _ids(watcher_ids) if x != assignee_id and x not in co]

    items = []
    for i, c in enumerate(checklist or []):
        if not _s((c or {}).get("text")):
            continue
        items.append({"id": "c%d" % (i + 1), "text": _s(c.get("text")),
                      "done": False, "due_at": _norm_due(c.get("due_at")),
                      "assignee_id": _s(c.get("assignee_id"))})
    due_at = _norm_due(due_at)
    _check_checklist_due(due_at, items)

    # ⭐⭐⭐ ДЖЕРЕЛО СТАВИТЬ ТОЙ, ХТО КРОК ВІДКРИВ (зміна 173, 14.08.2026).
    # КОРІНЬ. Поле `source` лежало в КОЖНІЙ задачі з першого дня — і його не
    # писав НІХТО й не читав НІХТО (перевірено по всьому коду 14.08). Рівно та
    # сама історія, що з `links` у зміні 172. Мертве поле гірше за відсутнє:
    # наступний, хто його прочитає, дістане порожньо і чесно вирішить, що
    # задача взялась нізвідки.
    # ⛒ Але писати його РУКАМИ в кожному вході (телеграм, пошта, розклад, CRM)
    # означало б завести стільки писарів, скільки дверей, — і перший же новий
    # вхід тихо забув би. Тому джерело береться з ВІДКРИТОГО КРОКУ: двері вже
    # назвали себе для протоколу (`telegram_bot._open_step`, закон зміни 169),
    # і задача бере ту саму правду з того самого місця. Один писар на всіх.
    # ⚠ ЯВНО ПЕРЕДАНЕ ПЕРЕМАГАЄ: викликач, який ЗНАЄ джерело точніше за крок,
    # не мусить із ним боротись.
    # ⛔ У КАРТЦІ ЦЬОГО НЕ ПОКАЗУЄМО — слово Андрія 14.08: «позначати ворота, через
    # які зайшла задача, не обовʼязково для операційного процесу». Поле живе для
    # аналітики, а не для екрана.
    src = _s(source)
    if not src:
        try:
            src = _s(protocol.context().get("source"))
        except Exception:
            src = ""
    t = _normalize({
        "id": next_id(), "title": title, "description": _s(description),
        "author_id": actor_id, "assignee_id": assignee_id,
        "coassignee_ids": co, "watcher_ids": watchers,
        "stage": STAGE_NEW, "due_at": due_at, "checklist": items,
        "feed": [], "created_at": clock.now(),
        "source": src, "source_ref": _s(source_ref),
    }, next_id())
    return save(t, actor_id, events.event(events.KIND_CREATED))


def comment(tid: str, actor_id: str, text: str, as_result: bool = False,
            is_admin: bool = False) -> dict:
    """Стрічка — це середовище задачі: вказівки, питання й матеріали результату
    живуть в одному місці. Позначка «це результат» ставиться на КОМЕНТАРІ."""
    t = task(tid)
    actor_id = _s(actor_id)
    require(t, actor_id, ACT_COMMENT, is_admin)
    text = _s(text)
    if not text:
        raise TaskError("Порожній коментар не додається.")
    raw = _strip_derived(t)
    cid = "m%d" % (len(raw["feed"]) + 1)
    raw["feed"].append({"id": cid, "author_id": actor_id, "text": text,
                        "at": clock.now(), "kind": "comment"})
    ev = events.event(events.KIND_COMMENT, comment_id=cid, text=text[:300])
    if as_result:
        require(t, actor_id, ACT_RESULT, is_admin)
        raw["result_comment_id"] = cid
        ev = events.event(events.KIND_RESULT, comment_id=cid, text=text[:300],
                          with_text=True)
    return save(raw, actor_id, ev)


def mark_result(tid: str, actor_id: str, comment_id: str,
                is_admin: bool = False) -> dict:
    t = task(tid)
    require(t, actor_id, ACT_RESULT, is_admin)
    if not any(c["id"] == _s(comment_id) for c in t["feed"]):
        raise TaskError("Такого коментаря в задачі немає.")
    raw = _strip_derived(t)
    raw["result_comment_id"] = _s(comment_id)
    return save(raw, actor_id, events.event(events.KIND_RESULT,
                                            comment_id=_s(comment_id)))


# Хто має право перевести задачу в стадію. Постановник веде приймання,
# виконавець і співвиконавці — хід роботи.
STAGE_RIGHTS = {
    STAGE_WORK: (ROLE_ASSIGNEE, ROLE_CO, ROLE_AUTHOR),
    STAGE_REVIEW: (ROLE_ASSIGNEE, ROLE_CO),
    STAGE_DONE: (ROLE_AUTHOR,),
    STAGE_HOLD: (ROLE_AUTHOR,),
    STAGE_CANCEL: (ROLE_AUTHOR,),
    STAGE_NEW: (ROLE_AUTHOR,),
}


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ОДНА ТАБЛИЦЯ ПРАВ НА ВЕСЬ TASK DESK (08.08.2026, вимога Андрія)
#
# Досі кожна дія перевіряла права САМА, всередині себе, а екран малював кнопки
# за власними «якщо». Це ДВА ПИСАРІ ОДНІЄЇ ПРАВДИ: варто розійтись — і людина
# бачить кнопку, яка відмовить, або НЕ бачить дії, на яку має право. Той самий
# клас, що й видимість: її вже сторожить ОДНА функція `visible_ids()`.
#
# Тепер право оголошене рівно тут, а питають його троє: сама дія, відмова
# словами і екран (через `rights()` у відповіді сервера).
#
# ⭐ АДМІНІСТРАТОР — НЕ РОЛЬ У ЗАДАЧІ, А ШАР НАД НЕЮ. Тому він приходить
# окремим прапорцем `is_admin`, а не підмішується до ролей: у задачі його може
# не бути взагалі. І шар цей ВУЗЬКИЙ — рівно те, що назвав Андрій: правити,
# скасувати, змінити виконавця. Позначати результат замість виконавця він не
# може: інакше «доказ виконання» перестав би бути доказом.
# ---------------------------------------------------------------------------
ACT_EDIT = "edit"
ACT_REASSIGN = "reassign"
ACT_CANCEL = "cancel"
ACT_COMMENT = "comment"
ACT_RESULT = "result"
ACT_CHECK = "check"
ACT_REFUSE = "refuse"


def stage_action(stage: str) -> str:
    """Скасування — не «ще одна стадія», а окрема дія: у неї свої права."""
    return ACT_CANCEL if stage == STAGE_CANCEL else "stage:" + _s(stage)


ACTION_ROLES = {
    ACT_EDIT: (ROLE_AUTHOR,),
    ACT_REASSIGN: (ROLE_ASSIGNEE, ROLE_AUTHOR),
    ACT_CANCEL: (ROLE_AUTHOR,),
    ACT_COMMENT: (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_WATCHER),
    ACT_RESULT: (ROLE_ASSIGNEE, ROLE_CO),
    ACT_CHECK: (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    ACT_REFUSE: (ROLE_ASSIGNEE, ROLE_CO),
}
for _st in STAGES_ALL:                       # стадії беруть права зі STAGE_RIGHTS
    ACTION_ROLES.setdefault(stage_action(_st), STAGE_RIGHTS.get(_st, ()))

ACTION_NAMES = {
    ACT_EDIT: "змінювати текст, терміни й склад задачі",
    ACT_REASSIGN: "змінювати виконавця",
    ACT_CANCEL: "скасувати задачу",
    ACT_COMMENT: "коментувати задачу",
    ACT_RESULT: "позначати результат",
    ACT_CHECK: "вести пункти плану",
    ACT_REFUSE: "відмовитись від задачі",
}
for _st in STAGES_ALL:
    ACTION_NAMES.setdefault(stage_action(_st),
                            "переводити задачу в «%s»" % STAGE_NAMES[_st])

# ---------------------------------------------------------------------------
# ⭐⭐⭐ АДМІНІСТРАТОР МОЖЕ ВСЕ (рішення Андрія 09.08.2026 — СКАСОВУЄ його ж
# рішення від 08.08).
#
# 08.08 цей шар був ВУЗЬКИЙ (правити · скасувати · змінити виконавця), і причина
# була така: «позначати результат замість виконавця адміністратор не може,
# інакше доказ виконання перестане бути доказом».
#
# ЩО ЗМІНИЛО РІШЕННЯ. Андрій на живому впіймав глухий кут: він адміністратор і
# власник платформи, але прийняти задачу не міг, бо приймає ПОСТАНОВНИК. Це не
# примха — це цілий КЛАС: пішов у відпустку постановник, звільнився виконавець,
# і задача застрягає назавжди, бо єдина людина з правом недосяжна.
#
# ⭐ ЧОМУ СТАРА ПРИЧИНА НЕ ВТРАЧЕНА. Доказ виконання тримався не на ЗАБОРОНІ, а
# на СЛІДІ: `save()` пише в журнал задачі, ХТО саме зробив дію. Якщо результат
# позначив адміністратор, у журналі стоїть його імʼя, а не виконавцеве. Доказ не
# зник — він ПІДПИСАНИЙ. А `rights()` окремо називає, які дії людина має САМЕ
# як адміністратор, щоб вона тиснула кнопку свідомо.
#
# ⚠ ТОМУ ЦЕЙ ПЕРЕЛІК БІЛЬШЕ НЕ ПИШУТЬ РУКАМИ: він дорівнює ВСІМ оголошеним
# діям. Нова дія отримує адмінське право сама — інакше через місяць знову
# зʼявився б глухий кут у дії, яку забули сюди вписати.
# ---------------------------------------------------------------------------
ADMIN_ACTIONS = tuple(ACTION_NAMES)


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ХТО ПРО ЩО ДІЗНАЄТЬСЯ. Друга таблиця на ТИХ САМИХ ролях, навмисно поруч
# із таблицею прав: «кого повідомити» не сміє розповзтися по екранах і ротах.
#
# Спостерігач не отримує кожен коментар і кожну галочку в плані. Бот, який
# шумить, вимикають — і тоді нерв марний.
# ---------------------------------------------------------------------------
KIND_ROLES = {
    events.KIND_CREATED:       (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_WATCHER),
    events.KIND_COMMENT:       (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    events.KIND_RESULT:        (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_WATCHER),
    events.KIND_STAGE:         (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_WATCHER),
    events.KIND_DELEGATED:     (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_WATCHER),
    events.KIND_REFUSED:       (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_WATCHER),
    events.KIND_UPDATED:       (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_WATCHER),
    events.KIND_PROPOSAL:      (ROLE_AUTHOR, ROLE_ASSIGNEE),
    events.KIND_PROPOSAL_DONE: (ROLE_AUTHOR, ROLE_ASSIGNEE),
    events.KIND_CHECKLIST:     (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    events.KIND_LINKED:        (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    events.KIND_UNLINKED:      (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    # ⭐ ПРО СТРОК, ЩО МИНУВ, ЗНАЄ ТОЙ, КОГО ЗА НЬОГО ПИТАЮТЬ, І ТОЙ, ХТО ЙОГО
    # ПОСТАВИВ. Спостерігача сюди не беремо: сигнал, який приходить усім, швидко
    # перестають читати всі.
    events.KIND_OVERDUE:       (ROLE_ASSIGNEE, ROLE_CO, ROLE_AUTHOR),
}


def recipients(before: dict, after: dict, kind: str, actor_id: str) -> list:
    """ЄДИНА відповідь «кого це стосується». Її питає `save()`, і більше ніхто
    не має права рахувати адресатів сам.

    ⭐ ОБʼЄДНАННЯ учасників ДО і ПІСЛЯ зміни. Інакше людина, яку щойно прибрали
    із задачі, не дізналася б, що її прибрали, а той, кого щойно додали, — що
    він зʼявився.

    ⭐ СОБІ НЕ ПИШЕМО: хто зробив дію, той про неї повідомлення не отримує.
    Мозок (`AI_ACTOR`) людиною не є, тож із його пропозицій не виключається
    ніхто."""
    allowed = KIND_ROLES.get(kind, ())
    actor_id = _s(actor_id)
    out = []
    for emp in participants(after) + participants(before):
        if emp in out or emp == actor_id:
            continue
        rr = tuple(roles_of(after, emp)) + tuple(roles_of(before, emp))
        if any(r in allowed for r in rr):
            out.append(emp)
    return out


def may(t: dict, emp_id: str, action: str, is_admin: bool = False) -> bool:
    """ЄДИНА відповідь «чи можна». Її питають і код дії, і кнопки на екрані.

    ⭐ Ролей у людини може бути кілька — і тоді діє ТА, ЩО ДАЄ БІЛЬШЕ. Питати
    лише «головну» роль означало б відбирати права, які дала інша."""
    if is_admin and action in ADMIN_ACTIONS:
        return True
    allowed = ACTION_ROLES.get(action, ())
    return any(r in allowed for r in roles_of(t, emp_id))


def require(t: dict, emp_id: str, action: str, is_admin: bool = False):
    """Відмова завжди називає ПРИЧИНУ і того, хто б це зміг."""
    if may(t, emp_id, action, is_admin):
        return
    rr = roles_of(t, emp_id)
    who = ACTION_ROLES.get(action, ())
    what = ACTION_NAMES.get(action, action)
    allowed = " або ".join([ROLE_NAMES[r] for r in who]) if who else "ніхто"
    if action in ADMIN_ACTIONS:
        allowed += " або адміністратор"
    if not rr:
        raise TaskError("Ви не учасник цієї задачі, тож %s не можете. Це може %s."
                        % (what, allowed))
    mine = " і ".join([ROLE_NAMES[r] for r in rr])
    raise TaskError("Ви — %s, тож %s не можете. Це може %s."
                    % (mine, what, allowed))


def rights(t: dict, emp_id: str, is_admin: bool = False) -> dict:
    """Що САМЕ може ця людина з цією задачею — для екрана. Кнопка, якої тут
    немає, не малюється: кнопка, що відмовить, бреше не менше за її відсутність.

    ⭐ `by_admin` — дії, які людина має НЕ за своєю роллю в задачі, а лише як
    адміністратор. Влада без цього рядка була б тихою: людина тиснула б
    «Прийняти», не знаючи, що вона щойно зробила це ЗАМІСТЬ постановника, і
    саме її імʼя лишиться в журналі."""
    out = {a: may(t, emp_id, a, is_admin) for a in ACTION_NAMES}
    out["is_admin"] = bool(is_admin)
    out["by_admin"] = {a: (bool(is_admin) and may(t, emp_id, a, True)
                           and not may(t, emp_id, a, False))
                       for a in ACTION_NAMES}
    return out


def set_stage(tid: str, actor_id: str, stage: str, is_admin: bool = False) -> dict:
    """⭐ ВОРОТА: завершити задачу без результату НЕ МОЖНА.

    Це не прапорець-прохання у формі, а умова закриття в коді: інакше «доказ
    виконання» тримається на добрій волі того, хто тисне кнопку."""
    stage = _s(stage)
    if stage not in STAGES_ALL:
        raise TaskError("Невідома стадія «%s». Відомі: %s"
                        % (stage, ", ".join(STAGE_NAMES[s] for s in STAGES_ALL)))
    t = task(tid)
    require(t, actor_id, stage_action(stage), is_admin)
    if stage == STAGE_DONE and not t["result_comment_id"]:
        raise TaskError("Задачу не завершити без результату: виконавець має "
                        "позначити коментар зі зробленим як результат.")
    raw = _strip_derived(t)
    raw["stage"] = stage
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": "Стадія: %s" % STAGE_NAMES[stage],
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_STAGE, stage=stage))


def delegate(tid: str, actor_id: str, new_assignee_id: str,
             is_admin: bool = False) -> dict:
    """⭐ Рішення 10: делегування — ТА САМА задача, змінюється виконавець.
    Один номер, одна стрічка, одна правда. Той, хто делегував, лишається в
    задачі (стає співвиконавцем), щоб не зникнути з картини перед постановником."""
    t = task(tid)
    require(t, actor_id, ACT_REASSIGN, is_admin)
    role = role_of(t, actor_id)
    new_id = _s(new_assignee_id)
    if not new_id or new_id == t["assignee_id"]:
        raise TaskError("Оберіть іншого виконавця.")
    _require_worker(new_id, "виконавець")
    raw = _strip_derived(t)
    old = raw["assignee_id"]
    raw["assignee_id"] = new_id
    if old and old != new_id and role == ROLE_ASSIGNEE and old not in raw["coassignee_ids"]:
        raw["coassignee_ids"].append(old)
    raw["watcher_ids"] = [w for w in raw["watcher_ids"] if w != new_id]
    raw["coassignee_ids"] = [c for c in raw["coassignee_ids"] if c != new_id]
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": "Виконавець: %s" % people.employee(new_id).get("full_name", new_id),
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_DELEGATED,
                                            old_assignee_id=old,
                                            new_assignee_id=new_id))


def refuse(tid: str, actor_id: str, reason: str,
           is_admin: bool = False) -> dict:
    """⭐ Рішення 11-12: прямий підлеглий НЕ МАЄ права відмовитись від задачі
    свого керівника — для нього легальний вихід це КЛАПАН (коментар керівнику,
    чого бракує). Відмова лишається тільки для «чужих» задач і завжди з причиною."""
    t = task(tid)
    require(t, actor_id, ACT_REFUSE, is_admin)
    reason = _s(reason)
    if not reason:
        raise TaskError("Відмова без причини не приймається.")
    if people.is_manager_of(t["author_id"], actor_id):
        raise TaskError(
            "Це задача вашого керівника — від неї не відмовляються. "
            "Напишіть у стрічці, чого вам бракує: керівник змінить термін, "
            "додасть ресурс або передасть задачу іншому.")
    raw = _strip_derived(t)
    raw["refusal_reason"] = reason
    raw["stage"] = STAGE_HOLD
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": "Відмова від задачі. Причина: %s" % reason,
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_REFUSED,
                                            reason=reason[:300]))


def update(tid: str, actor_id: str, is_admin: bool = False, **fields) -> dict:
    """Текст, терміни й склад задачі правлять постановник і адміністратор.
    Виконавець — ні: інакше умову роботи міняв би той, кого за неї питають.
    Хто саме має право — каже ОДНА таблиця вище, не ця функція."""
    t = task(tid)
    require(t, actor_id, ACT_EDIT, is_admin)
    raw = _strip_derived(t)
    if "title" in fields:
        title = _s(fields["title"])
        if not title:
            raise TaskError("Назву не можна прибрати.")
        raw["title"] = title
    if "description" in fields:
        raw["description"] = _s(fields["description"])
    if "due_at" in fields:
        raw["due_at"] = _norm_due(fields["due_at"])
        _check_checklist_due(raw["due_at"], raw["checklist"])
    if "coassignee_ids" in fields:
        co = [x for x in _ids(fields["coassignee_ids"]) if x != raw["assignee_id"]]
        for x in co:
            _require_worker(x, "співвиконавець")
        raw["coassignee_ids"] = co
    if "watcher_ids" in fields:
        raw["watcher_ids"] = [x for x in _ids(fields["watcher_ids"])
                              if x != raw["assignee_id"] and x not in raw["coassignee_ids"]]

    # ⭐⭐ ЗМІНА, ЯКОЇ НЕ ВИДНО ТОМУ, КОГО ВОНА СТОСУЄТЬСЯ, — ТИХА ЗМІНА.
    # Службовий журнал `audit` бачимо ми; ВИКОНАВЕЦЬ дивиться у СТРІЧКУ. Якщо
    # постановник посунув термін, а в стрічці порожньо — людина дізнається про
    # це, коли задача почервоніє. Тому кожна правка називає себе там, де на неї
    # дивляться. (Знайдено живим прогоном 08.08.2026, не чеками.)
    said = []
    if t["title"] != raw["title"]:
        said.append("назва: «%s»" % raw["title"])
    if t["due_at"] != raw["due_at"]:
        said.append("термін: %s" % (_human(raw["due_at"]) if raw["due_at"]
                                    else "прибрано, рахується з плану"))
    if t["description"] != raw["description"]:
        said.append("опис змінено")
    if t["coassignee_ids"] != raw["coassignee_ids"]:
        said.append("співвиконавці: %s" % (_who(raw["coassignee_ids"]) or "нікого"))
    if t["watcher_ids"] != raw["watcher_ids"]:
        said.append("спостерігачі: %s" % (_who(raw["watcher_ids"]) or "нікого"))
    if not said:
        return task(tid)                      # нічого не змінилось — і сліду не треба
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": "Задачу змінено. " + " · ".join(said),
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_UPDATED, said=list(said)))


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЗВʼЯЗКИ ЗАДАЧ (зміна 172 → крок B2, 14.08.2026).
#
# ЩО ТУТ ЛИШИЛОСЬ ПІСЛЯ B2. Сам ФАКТ звʼязку більше не лежить у файлі задачі —
# він у реєстрі `links.py`, спільному для всіх шарів. Тут лишились рівно дві
# речі, і обидві — власність ЗАДАЧІ, а не звʼязку: **ПРАВО** (кому можна) і
# **СЛІД У СТРІЧЦІ** (щоб людина побачила це там, де вона живе).
#
# ПРАВО ТЕ САМЕ, ЩО НА ПРАВКУ ЗАДАЧІ (`ACT_EDIT`): звʼязок міняє УМОВУ роботи —
# що є частиною чого і хто на кого чекає. Виконавцю нових прав не додаємо: у
# нього для цього є стрічка й відмова з причиною. Нова таблиця прав не заводиться.
# ⛒ І РЕЄСТР ЇЇ НЕ ОБХОДИТЬ: він не питає прав і не є другим входом — права
# судить власник сутності ДО виклику, як тут.
#
# ⚠ ПОРЯДОК НАВМИСНИЙ: спершу РЕЄСТР (правда), потім стрічка задачі (розповідь
# про правду). Якщо впаде другий крок, у людини лишиться справжній звʼязок без
# рядка в стрічці — це видно й лікується. Зворотний порядок дав би рядок про
# звʼязок, якого немає, тобто тиху брехню в очі.
# ---------------------------------------------------------------------------
def link(tid: str, actor_id: str, ref, rel: str, is_admin: bool = False) -> dict:
    """Звʼязати задачу з іншою задачею, контрагентом або прогоном."""
    t = task(tid)
    require(t, actor_id, ACT_EDIT, is_admin)
    me = entity.ref(entity.KIND_TASK, t["id"])
    try:
        row = links.add(me, rel, ref, by=entity.person_of_employee(_s(actor_id)))
    except links.LinkError as ex:
        raise TaskError(str(ex))
    value, r = row["to"], row["rel"]
    raw = _strip_derived(t)
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1),
                        "author_id": _s(actor_id),
                        "text": "Звʼязок — %s" % tlinks.phrase(r, value),
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_LINKED, ref=value, rel=r))


def unlink(tid: str, actor_id: str, ref, rel: str, is_admin: bool = False) -> dict:
    """Прибрати звʼязок. ⚠ Прибирається РІВНО той, який назвали: пара «на що» +
    «який». Видалення, яке вгадує форму, — окремий клас біди (урок 10.08)."""
    t = task(tid)
    require(t, actor_id, ACT_EDIT, is_admin)
    me = entity.ref(entity.KIND_TASK, t["id"])
    try:
        row = links.remove(me, rel, ref, by=entity.person_of_employee(_s(actor_id)))
    except links.LinkError as ex:
        raise TaskError(str(ex))
    value, r = row["to"], row["rel"]
    raw = _strip_derived(t)
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1),
                        "author_id": _s(actor_id),
                        "text": "Звʼязок прибрано — %s" % tlinks.phrase(r, value),
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_UNLINKED, ref=value, rel=r))


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ПРОПОЗИЦІЇ МОЗКУ. Мозок сюди НЕ ХОДИТЬ — він живе в `taskdesk_ai.py` і
# лише ПРИНОСИТЬ готову пропозицію. Цей файл її записує, показує й застосовує.
# Термін від того не отримує другого писаря: коли людина тисне «Прийняти»,
# зміну робить ТА САМА `update()` під ТИМИ САМИМИ правами, і в журналі стоїть
# ЛЮДИНА, а не машина.
# ---------------------------------------------------------------------------
def add_proposal(tid: str, kind: str, date: str, why: str, quote: str,
                 from_comment: str = "") -> dict:
    """Записати пораду мозку. Нічого в задачі не змінює."""
    kind = _s(kind)
    if kind != PROPOSAL_DUE:
        raise TaskError("Невідомий вид пропозиції «%s»." % kind)
    date = _norm_due(date)
    if not date:
        raise TaskError("Пропозиція терміну без дати не приймається.")
    t = task(tid)
    raw = _strip_derived(t)
    raw.setdefault("proposals", [])
    # Та сама дата, яку вже пропонували або вже відхилили, вдруге не спливає.
    for p in raw["proposals"]:
        if p.get("kind") == kind and _norm_due(p.get("date")) == date:
            return t
    pid = "p%d" % (len(raw["proposals"]) + 1)
    raw["proposals"].append({
        "id": pid, "kind": kind, "date": date, "why": _s(why)[:300],
        "quote": _s(quote)[:300], "from_comment": _s(from_comment),
        "at": clock.now(), "state": PROPOSAL_OPEN, "decided_by": "",
    })
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": AI_ACTOR,
                        "text": "Пропозиція: посунути термін на %s. %s"
                                % (_human(date), _s(why)),
                        "at": clock.now(), "kind": "event"})
    return save(raw, AI_ACTOR, events.event(events.KIND_PROPOSAL,
                                            proposal_id=pid, date=date,
                                            why=_s(why)[:300]))


def resolve_proposal(tid: str, actor_id: str, proposal_id: str, accept: bool,
                     is_admin: bool = False) -> dict:
    """Прийняти або відхилити пораду. Прийняти може ТІЛЬКИ той, хто й так має
    право правити задачу — інакше мозок став би обхідним шляхом повз права."""
    t = task(tid)
    require(t, actor_id, ACT_EDIT, is_admin)
    pid = _s(proposal_id)
    found = [p for p in t.get("proposals", []) if p["id"] == pid]
    if not found:
        raise TaskError("Такої пропозиції в задачі немає.")
    p = found[0]
    if p["state"] != PROPOSAL_OPEN:
        raise TaskError("Цю пропозицію вже %s."
                        % ("прийнято" if p["state"] == PROPOSAL_ACCEPTED else "відхилено"))
    raw = _strip_derived(t)
    for q in raw["proposals"]:
        if q["id"] == pid:
            q["state"] = PROPOSAL_ACCEPTED if accept else PROPOSAL_DECLINED
            q["decided_by"] = _s(actor_id)
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": ("Пропозицію прийнято: термін %s."
                                 % _human(p["date"])) if accept
                                else "Пропозицію відхилено (термін лишається).",
                        "at": clock.now(), "kind": "event"})
    save(raw, actor_id, events.event(events.KIND_PROPOSAL_DONE, proposal_id=pid,
                                     accepted=bool(accept), date=p["date"]))
    if not accept:
        return task(tid)
    # ⭐ Саму зміну робить ТА САМА update() — щоб термін не отримав другого писаря
    # і щоб спрацювали всі її ворота (пункти плану, слід у стрічці).
    return update(tid, actor_id, is_admin, due_at=p["date"])


def check_item(tid: str, actor_id: str, item_id: str, done: bool,
               is_admin: bool = False) -> dict:
    t = task(tid)
    require(t, actor_id, ACT_CHECK, is_admin)
    raw = _strip_derived(t)
    found = False
    for c in raw["checklist"]:
        if c["id"] == _s(item_id):
            c["done"], found = bool(done), True
    if not found:
        raise TaskError("Такого пункту в задачі немає.")
    return save(raw, actor_id, events.event(events.KIND_CHECKLIST,
                                            item_id=_s(item_id), done=bool(done)))


# ---------------------------------------------------------------------------
# ДОШКА — те, що бачить екран. Фільтр лише ЗВУЖУЄ видимість.
# ---------------------------------------------------------------------------
def board(emp_id: str, scope: str = "all", show_closed: bool = False,
          narrow=None) -> dict:
    """scope: all | mine (я виконавець) | i_set (я поставив) | overdue

    ⭐⭐⭐ `narrow` — це фільтр екрана. Він отримує вже ВИДИМІ задачі й може лише
    ЗМЕНШИТИ їх число. Це не домовленість, а ворота: якщо після нього зʼявився
    хоч один номер, якого не було, робота зупиняється з причиною. Інакше екран
    з фільтром став би другим входом повз `visible_ids()`."""
    tasks = visible_tasks(emp_id, include_closed=True)
    if narrow is not None:
        allowed = {t["id"] for t in tasks}
        tasks = list(narrow(tasks))
        extra = sorted({t["id"] for t in tasks} - allowed)
        if extra:
            raise TaskError("Фільтр не має права додавати задачі, лише звужувати. "
                            "Зайві: %s" % ", ".join(extra[:5]))
    if scope == "mine":
        tasks = [t for t in tasks if t["assignee_id"] == emp_id]
    elif scope == "i_set":
        tasks = [t for t in tasks if t["author_id"] == emp_id]
    elif scope == "overdue":
        tasks = [t for t in tasks if t["overdue"]]
    if not show_closed:
        tasks = [t for t in tasks if t["stage"] not in STAGES_CLOSED or scope == "overdue"]
    cols = []
    for st in STAGES_MAIN + STAGES_SIDE:
        in_st = [t for t in tasks if t["stage"] == st]
        if st in STAGES_SIDE and not in_st:
            continue
        cols.append({"stage": st, "name": STAGE_NAMES[st], "tasks": in_st})
    return {
        "columns": cols,
        "total": len(tasks),
        "overdue": len([t for t in tasks if t["overdue"]]),
        "broken": [t["id"] for t in tasks if t["broken"]],
    }
