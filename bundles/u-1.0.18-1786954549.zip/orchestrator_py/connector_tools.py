# -*- coding: utf-8 -*-
"""ІНСТРУМЕНТИ ЧУЖОГО СЕРВІСУ — ОДИН ПИСАР.

⭐⭐⭐ 12.08.2026 (зміна 164). Крок 3 конекторів.

Зміна 162 навчила платформу ЧЕСНО КАЗАТИ, що входу немає. Зміна 163 дала САМ
ВХІД (`connector_oauth`). Але за дверима було ПОРОЖНЬО: жоден шлях виконання не
вмів прочитати листа. Тобто щойно пошту підключено, ворота 162 роботу
ПРОПУСКАЮТЬ — а виконати її нічим, і агент відповість з памʼяті моделі.
⛒ ЗДАТНІСТЬ, ДО ЯКОЇ НЕ ВЕДЕ ЖОДЕН ІНСТРУМЕНТ, НЕ ІСНУЄ — а обіцяна ворітьми
відсутня здатність гірша за чесну відмову.

⛒ ЧОМУ ОДИН ПИСАР. Правда про роботу в чужому сервісі складається з речей, які
вміють розійтися зі своїми близнюками:
  • ЯКИЙ ВХІД потрібен інструменту (`need` — те саме слово, що в
    `registry.REQUIRABLE_INPUTS`, а не своє);
  • ЗВІДКИ КЛЮЧ — ЛИШЕ `connector_oauth.access_token`, ніхто не читає файл
    токена сам (інакше кожен новий інструмент мусив би памʼятати про строк
    життя ключа, і той, хто забуде, стане дірою);
  • ЧИ КУПЛЕНО РІВЕНЬ — той самий вимикач, що тримає двері
    (`connector_oauth.enabled`);
  • ЩО СКАЗАТИ ЛЮДИНІ, коли сервіс відмовив (текст, а не код помилки).

⛒ НОВИЙ ІНСТРУМЕНТ = НОВИЙ РЯДОК У `TOOLS`, і більше нічого правити не треба:
мозок (`agent`), крок агента системи (`executor`), перелік умінь
(`tools.available_tools`) і самомодель беруть його звідси.

Жодних зовнішніх залежностей.
"""

import json
import time
import urllib.parse
import urllib.request

import connector_oauth


TIMEOUT_S = 30

_GMAIL = "https://gmail.googleapis.com/gmail/v1/users/me"
_CALENDAR = "https://www.googleapis.com/calendar/v3/calendars/primary/events"


# ---------------------------------------------------------------------------
# Реєстр інструментів
# ---------------------------------------------------------------------------
TOOLS = {
    "mail_read": {
        "need": "mail",                 # ⭐ слово з registry.REQUIRABLE_INPUTS
        "connector": "google_mail",
        "name": "Листи Gmail",
        "label": "📧",
        "human": "Читання листів",
        "description": (
            "Прочитати листи з поштової скриньки власника платформи за період. "
            "Повертає відправника, дату, тему і початок тексту кожного листа. "
            "Це САМА скринька, а не веб-пошук: підміни немає. Надіслати чи "
            "видалити лист платформа не може — права лише на читання."),
        "parameters": {"type": "object", "properties": {
            "days": {"type": "integer", "description":
                     "За скільки останніх днів брати листи (1-90; типово 7)."},
            "since": {"type": "string", "description":
                      "(необовʼязково) початок періоду, формат РРРР-ММ-ДД. "
                      "Разом із until перекриває days."},
            "until": {"type": "string", "description":
                      "(необовʼязково) кінець періоду, формат РРРР-ММ-ДД."},
            "query": {"type": "string", "description":
                      "(необовʼязково) додатковий пошук у скриньці мовою Gmail, "
                      "напр. from:ivan@ua.com або subject:договір."},
            "limit": {"type": "integer", "description":
                      "Скільки листів повернути (1-50; типово 20)."},
        }},
    },
    "calendar_create_event": {
        "need": "calendar",
        "connector": "google_calendar",
        "name": "Подія в Google Calendar",
        "label": "📅",
        "human": "Створення події",
        "description": (
            "Створити подію в основному календарі власника платформи. "
            "Час — місцевий час цієї машини."),
        "parameters": {"type": "object", "properties": {
            "title": {"type": "string", "description": "назва події"},
            "start": {"type": "string", "description":
                      "початок: «РРРР-ММ-ДД ГГ:ХХ» (місцевий час)"},
            "end": {"type": "string", "description":
                    "(необовʼязково) кінець у тому ж форматі; немає — береться "
                    "duration_min"},
            "duration_min": {"type": "integer", "description":
                             "(необовʼязково) тривалість у хвилинах, типово 60"},
            "description": {"type": "string", "description": "(необовʼязково) опис"},
            "location": {"type": "string", "description": "(необовʼязково) місце"},
        }, "required": ["title", "start"]},
    },
}


# ---------------------------------------------------------------------------
# Чи можна цим інструментом користуватись
# ---------------------------------------------------------------------------
def _input_ready(need: str) -> bool:
    """Чи є вхід. ⭐ Питаємо ОДНОГО писаря правди про входи, а не диск самі."""
    import registry
    return bool(registry.input_ready(need))


def ready(tool_id: str) -> bool:
    """Інструмент доступний, коли КУПЛЕНО рівень і ПІДКЛЮЧЕНО вхід."""
    spec = TOOLS.get(str(tool_id or ""))
    if not spec:
        return False
    return bool(connector_oauth.enabled()) and _input_ready(spec["need"])


def ready_ids() -> list:
    return [tid for tid in TOOLS if ready(tid)]


def refusal(tool_id: str) -> str:
    """ЧОМУ інструмент недоступний — реченням людині, без коду помилки."""
    spec = TOOLS.get(str(tool_id or ""))
    if not spec:
        return "Платформа не знає інструмента «%s»." % tool_id
    if not connector_oauth.enabled():
        return "Цей рівень автоматизації у вашій збірці не підключено."
    import registry
    ref = registry.input_refusal([spec["need"]])
    return "%s Що зробити: %s." % (ref["reason"], ref["action"])


def catalogue() -> list:
    """Рядки для переліку вмінь і самомоделі (`tools.available_tools`)."""
    return [{"id": tid, "name": spec["name"], "description": spec["description"],
             "available": ready(tid)} for tid, spec in TOOLS.items()]


def specs(names) -> list:
    """Схеми інструментів для моделі. ⛒ Недоступний інструмент у набір НЕ
    потрапляє: інакше модель побачить обіцянку, якої нема чим виконати."""
    out = []
    for tid in (names or []):
        spec = TOOLS.get(str(tid or ""))
        if not spec or not ready(tid):
            continue
        out.append({"name": tid, "description": spec["description"],
                    "parameters": spec["parameters"]})
    return out


def step_tools(role_tools: dict) -> list:
    """Які інструменти чужого сервісу дістаються КРОКУ агента.

    ⛒ Ворота — ПАСПОРТ РОЛІ (явна декларація `needs` від Будівника, зміна 162),
    а не назва агента і не слова задачі. Здогадка за написанням — рівно той
    клас, що зробив «читача пошти» веб-шукачем."""
    t = role_tools if isinstance(role_tools, dict) else {}
    return [tid for tid, spec in TOOLS.items() if t.get(spec["need"]) and ready(tid)]


def brain_specs() -> list:
    """Набір для мозку: усе, що зараз справді доступне."""
    return specs(ready_ids())


def human_label(tool_id: str):
    spec = TOOLS.get(str(tool_id or "")) or {}
    return spec.get("label", "🔌"), spec.get("human", spec.get("name", tool_id))


# ---------------------------------------------------------------------------
# Виконання
# ---------------------------------------------------------------------------
def run(tool_id: str, args: dict) -> dict:
    """→ {ok, text}. `text` — готовий рядок для моделі АБО чесна причина відмови.

    ⛒ Тихого успіху немає: порожній результат теж називає себе словами.

    ⭐ ТОЧКА ВРІЗКИ №4 — ЧУЖІ СЕРВІСИ (хребет, 13.08.2026). Кожен вихід назовні —
    і вдалий, і відмова — лягає в загальний протокол. Саме звідси береться
    відповідь «скільки разів платформа РЕАЛЬНО виходила назовні»: слід виходів
    (`_trace`) бачить лише мережу і живе окремим файлом, а протокол ставить цей
    дотик поруч із задачею, клієнтом і грошима того самого прогону."""
    tid = str(tool_id or "")
    spec = TOOLS.get(tid)
    if not spec:
        return _out(tid, "", {"ok": False,
                              "text": "Платформа не знає інструмента «%s»." % tid})
    conn = str(spec.get("connector") or "")
    if not ready(tid):
        return _out(tid, conn, {"ok": False, "text": refusal(tid)})
    token, err = connector_oauth.access_token(spec["connector"])
    if not token:
        return _out(tid, conn, {"ok": False,
                                "text": err or "Конектор не підключено."})
    impl = _IMPL.get(tid)
    if not impl:
        return _out(tid, conn, {"ok": False,
                                "text": "Інструмент «%s» оголошено, але не реалізовано." % tid})
    try:
        return _out(tid, conn, impl(dict(args or {}), token))
    except Exception as exc:            # noqa — аварія називає себе, не мовчить
        _trace(tid, 0, "exception: %s" % exc)
        return _out(tid, conn, {"ok": False,
                                "text": "Інструмент «%s» зупинився: %s." % (tid, exc)},
                    failed=True)


def _out(tool_id: str, connector: str, res: dict, failed: bool = False) -> dict:
    """Один вихід — один рядок протоколу. Кожен `return` іде через це місце, тому
    забути котрийсь шлях відмови фізично не виходить (урок 162: ворота, які
    стоять на одному шляху з пʼяти, не ворота)."""
    try:
        import entity
        import protocol
        ok = bool((res or {}).get("ok"))
        if ok:
            outcome = protocol.OUT_OK
        else:
            kind = protocol.OUT_FAILED if failed else protocol.OUT_REFUSED
            outcome = "%s: %s" % (kind, (res or {}).get("text") or "без причини")
        subject = entity.ref(entity.KIND_CONNECTOR, connector or "невідомий")
        protocol.write(protocol.A_CONNECTOR_CALL, subject,
                       outcome=outcome, note="інструмент: %s" % (tool_id or "?"))
    except Exception:
        pass
    return res


# ---------------------------------------------------------------------------
# ВИХІД НАЗОВНІ (один прохід, зі слідом)
# ---------------------------------------------------------------------------
def _api(method: str, url: str, token: str, body: dict = None):
    """→ (ok, дані) або (False, ТЕКСТ ЛЮДИНІ). Сирий текст помилки — у журнал
    виходів, людині — зрозуміле речення (урок 11.08)."""
    data = json.dumps(body, ensure_ascii=False).encode("utf-8") if body is not None else None
    headers = {"Authorization": "Bearer %s" % token, "Accept": "application/json"}
    if data is not None:
        headers["Content-Type"] = "application/json; charset=utf-8"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT_S) as resp:
            status = int(getattr(resp, "status", 200) or 200)
            raw = resp.read().decode("utf-8", "replace")
    except Exception as exc:
        raw = getattr(exc, "read", lambda: b"")()
        try:
            raw = raw.decode("utf-8", "replace")
        except Exception:
            raw = ""
        status = int(getattr(exc, "code", 0) or 0)
        _trace(url, status, raw or str(exc))
        return False, _human_error(status, raw, str(exc))
    _trace(url, status, "ok")
    try:
        return True, (json.loads(raw) if raw.strip() else {})
    except Exception:
        return False, "Сервіс відповів не тим, чого ми чекали."


def _human_error(status: int, raw: str, fallback: str) -> str:
    reason = ""
    try:
        err = (json.loads(raw) or {}).get("error") or {}
        if isinstance(err, dict):
            details = (err.get("errors") or [{}])[0]
            reason = str(details.get("reason") or err.get("status") or "")
        else:
            reason = str(err)
    except Exception:
        reason = ""
    if status == 401:
        return ("Google більше не приймає цей доступ (найчастіше згода протухла: "
                "у режимі «Testing» вона живе 7 днів). Підключіть конектор заново "
                "в розділі «Конектори».")
    if status == 403 and "insufficient" in reason.lower():
        return ("Прав на цю дію не вистачає. Підключіть конектор заново — платформа "
                "попросить потрібні права.")
    if status == 403:
        return ("Сервіс відмовив у доступі%s. Найчастіше це вимкнений API у Google "
                "Cloud або обмеження акаунта." % ((": " + reason) if reason else ""))
    if status == 404:
        return "Сервіс не знайшов того, що ми просили (можливо, немає такого календаря)."
    if status in (429, 500, 502, 503, 504):
        return "Сервіс зараз не відповідає (код %d) — спробуйте за кілька хвилин." % status
    if status:
        return "Сервіс відмовив (код %d)%s." % (status, (": " + reason) if reason else "")
    return "Не вдалося звʼязатися з сервісом: %s." % fallback


def _trace(url: str, status: int, note: str):
    try:
        import egress_guard
        egress_guard.log("connector_tools", {"url": str(url)[:200], "status": status,
                                             "note": (note or "")[:300]})
    except Exception:
        pass


# ---------------------------------------------------------------------------
# ПОШТА: прочитати листи за період
# ---------------------------------------------------------------------------
def _clamp(value, low, high, default):
    try:
        n = int(value)
    except Exception:
        return default
    return max(low, min(high, n))


def _date_human(raw: str) -> str:
    """Дата листа у форматі DD.MM.YYYY HH:MM (правило Андрія)."""
    try:
        from email.utils import parsedate_to_datetime
        dt = parsedate_to_datetime(raw)
        try:
            dt = dt.astimezone()
        except Exception:
            pass
        return dt.strftime("%d.%m.%Y %H:%M")
    except Exception:
        return (raw or "").strip()[:25]


def _gmail_query(args: dict):
    """→ (запит Gmail, опис періоду людині)."""
    since = str(args.get("since") or "").strip()
    until = str(args.get("until") or "").strip()
    parts, human = [], ""
    if since or until:
        if since:
            parts.append("after:%s" % since.replace("-", "/"))
        if until:
            parts.append("before:%s" % until.replace("-", "/"))
        human = "період %s — %s" % (since or "початок", until or "сьогодні")
    else:
        days = _clamp(args.get("days"), 1, 90, 7)
        parts.append("newer_than:%dd" % days)
        human = "останні %d дн." % days
    extra = str(args.get("query") or "").strip()
    if extra:
        parts.append(extra)
        human += "; запит: %s" % extra
    return " ".join(parts), human


def _mail_read(args: dict, token: str) -> dict:
    limit = _clamp(args.get("limit"), 1, 50, 20)
    q, human = _gmail_query(args)
    url = "%s/messages?%s" % (_GMAIL, urllib.parse.urlencode(
        {"q": q, "maxResults": limit}))
    ok, data = _api("GET", url, token)
    if not ok:
        return {"ok": False, "text": "Листи не прочитано. %s" % data}
    ids = [m.get("id") for m in (data.get("messages") or []) if m.get("id")][:limit]
    if not ids:
        # ⛒ Порожньо — це ФАКТ, а не мовчання: інакше модель домалює листи.
        return {"ok": True, "count": 0,
                "text": "У скриньці за цей період (%s) листів немає." % human}
    lines, items = [], []
    for mid in ids:
        murl = "%s/messages/%s?%s" % (_GMAIL, mid, urllib.parse.urlencode(
            [("format", "metadata"), ("metadataHeaders", "From"),
             ("metadataHeaders", "Subject"), ("metadataHeaders", "Date")]))
        mok, mdata = _api("GET", murl, token)
        if not mok:
            lines.append("• лист %s прочитати не вдалося: %s" % (mid, mdata))
            continue
        heads = {str(h.get("name", "")).lower(): str(h.get("value", ""))
                 for h in ((mdata.get("payload") or {}).get("headers") or [])}
        item = {"id": mid, "from": heads.get("from", ""),
                "subject": heads.get("subject", "(без теми)"),
                "date": _date_human(heads.get("date", "")),
                "snippet": (mdata.get("snippet") or "").strip()}
        items.append(item)
        lines.append("%d. %s · від %s\n   Тема: %s\n   %s" % (
            len(items), item["date"], item["from"], item["subject"], item["snippet"]))
    text = ("Прочитано зі скриньки Gmail (%s). Листів: %d.\n\n%s" % (
        human, len(items), "\n".join(lines)))
    return {"ok": True, "count": len(items), "items": items, "text": text}


# ---------------------------------------------------------------------------
# КАЛЕНДАР: створити подію
# ---------------------------------------------------------------------------
def _offset() -> str:
    """Місцевий зсув часу цієї машини у вигляді +03:00. ⛒ Міста НЕ вгадуємо:
    у клієнта може бути будь-який часовий пояс."""
    off = -(time.altzone if time.daylight and time.localtime().tm_isdst else time.timezone)
    sign = "+" if off >= 0 else "-"
    off = abs(int(off))
    return "%s%02d:%02d" % (sign, off // 3600, (off % 3600) // 60)


def _moment(raw: str):
    """«РРРР-ММ-ДД ГГ:ХХ» (місцевий) або готовий RFC3339 → (rfc3339, помилка)."""
    s = str(raw or "").strip()
    if not s:
        return "", "не вказано час"
    if "T" in s and (s.endswith("Z") or "+" in s[10:] or "-" in s[11:]):
        return s, ""
    s = s.replace("T", " ")
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%d.%m.%Y %H:%M"):
        try:
            t = time.strptime(s, fmt)
            return time.strftime("%Y-%m-%dT%H:%M:%S", t) + _offset(), ""
        except ValueError:
            continue
    return "", "час «%s» не розпізнано; потрібен формат РРРР-ММ-ДД ГГ:ХХ" % raw


def _calendar_create_event(args: dict, token: str) -> dict:
    title = str(args.get("title") or "").strip()
    if not title:
        return {"ok": False, "text": "Подію не створено: не вказано назву."}
    start, err = _moment(args.get("start"))
    if err:
        return {"ok": False, "text": "Подію не створено: %s." % err}
    end = ""
    if str(args.get("end") or "").strip():
        end, err = _moment(args.get("end"))
        if err:
            return {"ok": False, "text": "Подію не створено: %s." % err}
    if not end:
        minutes = _clamp(args.get("duration_min"), 5, 24 * 60, 60)
        base = time.strptime(start[:19], "%Y-%m-%dT%H:%M:%S")
        end = time.strftime("%Y-%m-%dT%H:%M:%S",
                            time.localtime(time.mktime(base) + minutes * 60)) + _offset()
    body = {"summary": title, "start": {"dateTime": start}, "end": {"dateTime": end}}
    if str(args.get("description") or "").strip():
        body["description"] = str(args["description"]).strip()
    if str(args.get("location") or "").strip():
        body["location"] = str(args["location"]).strip()
    # ⛒ sendUpdates=none свідомо: платформа не розсилає листів людям без прямого
    # прохання — тиха розсилка від нашого імені була б сюрпризом, а не роботою.
    ok, data = _api("POST", _CALENDAR + "?sendUpdates=none", token, body)
    if not ok:
        return {"ok": False, "text": "Подію не створено. %s" % data}
    when = "%s — %s" % (_when_human(start), _when_human(end, time_only=True))
    link = str(data.get("htmlLink") or "")
    return {"ok": True, "event_id": str(data.get("id") or ""), "link": link,
            "text": "Подію створено: «%s», %s.%s" % (
                title, when, (" Посилання: " + link) if link else "")}


def _when_human(rfc: str, time_only: bool = False) -> str:
    try:
        t = time.strptime(str(rfc)[:19], "%Y-%m-%dT%H:%M:%S")
        return time.strftime("%H:%M" if time_only else "%d.%m.%Y %H:%M", t)
    except Exception:
        return str(rfc)


_IMPL = {
    "mail_read": _mail_read,
    "calendar_create_event": _calendar_create_event,
}
