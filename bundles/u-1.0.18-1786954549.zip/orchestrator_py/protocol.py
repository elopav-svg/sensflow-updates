# -*- coding: utf-8 -*-
"""protocol.py — ЗАГАЛЬНИЙ ПРОТОКОЛ УСІХ ДІЙ ПЛАТФОРМИ (зміна 169, 13.08.2026).

⭐⭐⭐ КОРІНЬ. Слово Андрія 12.08.2026: «...і ведеться загальний протокол усіх дій
для аналізу і прийняття стратегічних рішень.»

Досі кожен домен вів СВІЙ журнал у СВОЄМУ форматі й СВОЇМИ іменами:
`runs/_audit.jsonl` (прогони), `taskdesk/events.jsonl` (задачі), історія всередині
картки CRM, слід виходів конекторів. Вони не бʼються не тому, що хтось лінувався, а
тому, що не було спільного способу НАЗВАТИ ту саму річ. Спільне імʼя тепер дає
`entity.py`; цей файл дає спільний ЖУРНАЛ.

ОДИН РЯДОК = ОДНА ДІЯ:
    at        коли (за єдиним писарем часу `clock`)
    actor     хто зробив          person:acc_1 · system:tender_writer
    action    що саме             ЗАКРИТИЙ словник дієслів (див. ACTIONS)
    subject   головна річ         task:128
    about     кого ще стосується  [party:p0004, run:run-2026-08-12T10-40-39]
    outcome   чим скінчилось      ok · refused · failed · stopped
    reason    причина СЛОВАМИ     «немає доступу до пошти»
    cost_usd  скільки коштувало   0.049
    source    звідки прийшла робота  human.console · telegram · mail · schedule

⭐ КЛЮЧОВЕ АРХІТЕКТУРНЕ РІШЕННЯ: **ЗВʼЯЗОК МІЖ СУТНОСТЯМИ ЖИВЕ ТУТ, А НЕ
КОПІЮЄТЬСЯ В КОЖЕН ФАЙЛ.** Не «допишемо клієнта в задачу, задачу в прогін, прогін у
картку» — це три копії однієї правди, які розійдуться за тиждень. Один рядок каже:
ця дія стосується цієї задачі, цього контрагента і цього прогону. «Покажи все про
Каспера» — прохід журналом, а не збирання по трьох файлах.

⚠ ПРОТОКОЛ НЕ МАЄ ПРАВА ЗАВАЛИТИ РОБОТУ. `write()` НІКОЛИ не кидає — як і `audit`.
Але тиха згода теж заборонена: відхилений рядок голосно лягає у ВЛАСНИЙ файл невдач
(`protocol_failures.jsonl`) і повертає False. Мовчазна втрата рядка зробила б журнал
брехуном, а брехливий журнал гірший за відсутній.

⚠ СЕКРЕТИ В ЖУРНАЛ НЕ ПОТРАПЛЯЮТЬ. Прибирання секретів стало ОДНИМ ПИСАРЕМ саме тут
(до 13.08 воно жило всередині `audit._scrub`), і `audit` тепер кличе його — щоб не
було двох різних «чистильників», які розійдуться.

⚠ ЧОМУ ЗВИЧАЙНИЙ ФАЙЛ, А НЕ БАЗА. Обсяг — сотні-тисячі рядків на місяць. SQLite дав
би новий тип сховища, блокування, міграції й окремий бекап — ціна є, виграшу немає.

Файл: `state/protocol.jsonl` (тека `state` уже в переліку живого стану
`state_files.STATE_DIRS`, тобто клієнту не їде і його власний не затирає).
Шлях лежить у змінній модуля — чек підміняє її й не сміє писати в бойову теку
(той самий прийом, що з `audit._PATH` і `parties.PARTIES_JSON`).
"""

import json
import threading

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import entity

# ⚠ Тека саме `config.STATE_DIR / "state"` — так само, як добовий рахунок грошей
# (`costs._day_path`). Це та сама тека живого стану, яку `state_files.STATE_DIRS`
# уже тримає осторонь від клієнтської збірки й від бандла оновлень.
_DIR = config.STATE_DIR / "state"
_PATH = _DIR / "protocol.jsonl"
_FAIL_PATH = _DIR / "protocol_failures.jsonl"


# ── ЗАКРИТИЙ СЛОВНИК ДІЄСЛІВ ─────────────────────────────────────────────────
# Урок зміни 162: вміння, якого немає в словнику, не можна ні оголосити, ні
# заборонити — і тоді замість нього мовчки підставляється сусіднє. Нове дієслово
# заводиться ТУТ, свідомо, а не зʼявляється саме з чергового виклику.
A_RUN_FINISHED = "run.finished"
A_RUN_EVENT = "run.event"
A_RUN_REFUSED = "run.refused"
A_TASK_CREATED = "task.created"
A_TASK_CHANGED = "task.changed"
# ⭐ ЗВʼЯЗОК І ПРОТЕРМІНУВАННЯ — ОКРЕМІ ДІЄСЛОВА (зміна 172). Обидва
# відповідають на різні питання звіту: «що з чим повʼязано» і «де робота
# стоїть». Заганяти їх у `task.changed` означало б втратити рівно ту
# аналітику, заради якої протокол і будувався.
A_TASK_LINKED = "task.linked"
A_TASK_UNLINKED = "task.unlinked"
A_TASK_OVERDUE = "task.overdue"
# ⭐ ЗАКРИТТЯ — ОКРЕМЕ ДІЄСЛОВО (зміна 173, 14.08.2026). Слово Андрія: рейтинг
# підрозділу тримається на «відсотку своєчасного виконання». Стадія «Виконана»
# і досі приїжджала як `task.changed` із приміткою ТЕКСТОМ — рахувати відсоток
# по підрядку в примітці означало б порушити власний закон «чек по рядку в
# тексті фальшивий». Тому «вчасно / із запізненням» стає ФАКТОМ рядка.
A_TASK_DONE = "task.done"
A_PARTY_CREATED = "party.created"
A_PARTY_CHANGED = "party.changed"
A_PARTY_DELETED = "party.deleted"
A_PARTY_INBOUND = "party.inbound"
A_PARTY_HISTORY = "party.history"
A_PARTY_UPDATE = "party.update_sent"
A_CONNECTOR_CALL = "connector.call"
A_MONEY_SPENT = "money.spent"
# ⭐⭐⭐ ЗВʼЯЗОК — СВОЄ ДІЄСЛОВО (крок B2, 14.08.2026). Досі звʼязок умів заводити
# лише Task Desk, і дієслово так і звалось — `task.linked`. Тепер факт звʼязку
# живе у власному реєстрі (`links.py`) і буває між БУДЬ-ЯКИМИ сутностями: угода
# ↔ контакт, заявка ↔ договір. Писати про них «задачу звʼязано» означало б
# збрехати у звіті про те, що саме сталось.
# ⛒ СТАРІ ДІЄСЛОВА ЛИШАЮТЬСЯ У СЛОВНИКУ НАЗАВЖДИ. Журнал append-only не
# переписують: рядки від 13-14.08 мусять читатись і за рік.
A_LINK_CREATED = "link.created"
A_LINK_REMOVED = "link.removed"
# ⭐⭐⭐ УГОДА — СВОЇ ДІЄСЛОВА (крок C1, 15.08.2026). Досі рух угоди взагалі
# не потрапляв у журнал: угода не була сутністю, і стадія мінялась усередині
# картки клієнта мовчки. СТАДІЯ — ОКРЕМЕ ДІЄСЛОВО від звичайної зміни:
# саме на ній тримається весь аналіз воронки, а шукати зміну стадії підрядком
# у примітці означало б порушити власний закон «чек по рядку в тексті фальшивий».
A_DEAL_CREATED = "deal.created"
A_DEAL_CHANGED = "deal.changed"
A_DEAL_STAGE = "deal.stage"
A_DEAL_DELETED = "deal.deleted"
# ⭐⭐⭐ ЛИСТУВАННЯ З АДРЕСОЮ УГОДИ (крок C2, 15.08.2026). «Сформовано» і
# «надіслано» — РІЗНІ факти: пошту шле поштова програма людини, тому чужого
# факту на себе не беремо. А «чекає на рознесення» — теж окремий факт: це
# обіцянка людині, що лист не загубився, поки адреси в ньому немає.
A_DEAL_MAIL_OUT = "deal.mail_out"
A_DEAL_MAIL_IN = "deal.mail_in"
A_DEAL_MAIL_PARKED = "deal.mail_parked"

ACTIONS = {
    A_RUN_FINISHED: "прогін завершився",
    A_RUN_EVENT: "подія прогону",
    A_RUN_REFUSED: "робота не відбулась",
    A_TASK_CREATED: "задачу створено",
    A_TASK_CHANGED: "задачу змінено",
    A_TASK_LINKED: "задачу звʼязано",
    A_TASK_UNLINKED: "звʼязок задачі прибрано",
    A_TASK_OVERDUE: "строк задачі минув",
    A_TASK_DONE: "задачу виконано",
    A_PARTY_CREATED: "контрагента заведено",
    A_PARTY_CHANGED: "картку контрагента змінено",
    A_PARTY_DELETED: "контрагента прибрано з довідника",
    A_PARTY_INBOUND: "вхідне від контрагента",
    A_PARTY_HISTORY: "запис в історію контрагента",
    A_PARTY_UPDATE: "контрагенту направлено оновлення",
    A_CONNECTOR_CALL: "звернення до чужого сервісу",
    A_MONEY_SPENT: "витрачено грошей",
    A_LINK_CREATED: "сутності звʼязано",
    A_LINK_REMOVED: "звʼязок прибрано",
    A_DEAL_CREATED: "угоду заведено",
    A_DEAL_CHANGED: "угоду змінено",
    A_DEAL_STAGE: "стадію угоди змінено",
    A_DEAL_DELETED: "угоду прибрано",
    A_DEAL_MAIL_OUT: "лист із угоди сформовано",
    A_DEAL_MAIL_IN: "вхідне лягло в угоду",
    A_DEAL_MAIL_PARKED: "вхідне чекає на рознесення",
}

# ── Чим скінчилось ───────────────────────────────────────────────────────────
OUT_OK = "ok"
OUT_REFUSED = "refused"          # платформа свідомо не стала робити (ворота, брак даних)
OUT_FAILED = "failed"            # спробувала і зламалась
OUT_STOPPED = "stopped"          # обірвано межею (гроші, час, людина натиснула «Стоп»)
# ⭐ «ІЗ ЗАПІЗНЕННЯМ» — ОКРЕМИЙ ПІДСУМОК (зміна 173, 14.08.2026). Робота
# ВІДБУЛАСЬ, тому це не `stopped` і не `failed`; але зарахувати її в `ok`
# означало б завищити виконавську дисципліну — а «відсоток своєчасного
# виконання» Андрій назвав головною мірою підрозділу.
# ⛒ І ЖИВЕ ВОНО САМЕ ТУТ, У ЗАКРИТОМУ СЛОВНИКУ, А НЕ СЛОВАМИ В ПРИМІТЦІ:
# відсоток, порахований пошуком підрядка в тексті, поїде від першого ж
# переписаного формулювання. Це наш власний закон «чек по рядку — фальшивий».
OUT_LATE = "late"
OUTCOMES = (OUT_OK, OUT_REFUSED, OUT_FAILED, OUT_STOPPED, OUT_LATE)
OUTCOME_NAMES = {OUT_OK: "виконано", OUT_REFUSED: "відмова",
                 OUT_FAILED: "поломка", OUT_STOPPED: "обірвано",
                 OUT_LATE: "виконано із запізненням"}

# ── Звідки прийшла робота ────────────────────────────────────────────────────
# Словник закритий заради звіту («звідки береться робота» — питання №1 Андрія).
# Але СИРИЙ канал не губиться: незнайомий лягає як `other` + `source_raw`.
# Це не тиха підстановка: обидва значення видно в тому самому рядку.
S_CONSOLE = "human.console"
S_TELEGRAM = "telegram"
S_MAIL = "mail"
S_SCHEDULE = "schedule"
S_SYSTEM = "system"
S_OTHER = "other"
SOURCES = (S_CONSOLE, S_TELEGRAM, S_MAIL, S_SCHEDULE, S_SYSTEM, S_OTHER)
SOURCE_NAMES = {S_CONSOLE: "людина в консолі", S_TELEGRAM: "телеграм",
                S_MAIL: "пошта", S_SCHEDULE: "розклад",
                S_SYSTEM: "сама платформа", S_OTHER: "інше"}

_SOURCE_MAP = {
    "chat": S_CONSOLE, "console": S_CONSOLE, "human": S_CONSOLE,
    "human.console": S_CONSOLE, "ui": S_CONSOLE, "web": S_CONSOLE,
    "telegram": S_TELEGRAM, "tg": S_TELEGRAM,
    "mail": S_MAIL, "email": S_MAIL, "gmail": S_MAIL,
    "schedule": S_SCHEDULE, "scheduler": S_SCHEDULE, "automation": S_SCHEDULE,
    "system": S_SYSTEM, "platform": S_SYSTEM,
}

MAX_REASON = 300                  # причина словами, а не текст результату


class ProtocolError(Exception):
    """Відмова з причиною словами. Ловиться всередині `write` — назовні не летить."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ── ОДИН ПИСАР ПРИБИРАННЯ СЕКРЕТІВ ───────────────────────────────────────────
# ⭐ 13.08.2026. Правило жило всередині `audit._scrub`. Поки писар один — усе
# гаразд; але поява ДРУГОГО журналу (цього) означала б і другий чистильник, а два
# чистильники розходяться — і одного дня ключ виїде тим, що новіший. Тому правда
# переїхала сюди, а `audit._scrub` став тонким викликом.
SECRET_HINTS = ("sk-", "api_key", "apikey", "token=", "bearer ", "aiza", "ghp_",
                "secret_", "client_secret", "refresh_token", "password=")

SECRET_MASK = "[приховано: можливий секрет у тексті]"


def scrub(text, limit: int = 160) -> str:
    """Обрізати до безпечної довжини і прибрати рядок, схожий на ключ.

    Обрізаємо ДО перевірки — рівно як робив `audit._scrub`, щоб поведінка журналу
    прогонів не змінилась ні на знак."""
    t = _s(text)[:limit] if limit else _s(text)
    low = t.lower()
    if any(h in low for h in SECRET_HINTS):
        return SECRET_MASK
    return t


# ── КОНТЕКСТ ПОТОЧНОЇ РОБОТИ ─────────────────────────────────────────────────
# ⭐ НАВІЩО. Гроші рахує `costs`, який не знає ні клієнта, ні задачі; задачу знає
# Task Desk, який не знає ціни. Якби кожен домен ДОПИСУВАВ чуже поле собі у файл —
# це були б ті самі три копії однієї правди, від яких ми тікали. Тому домени
# лишаються при своєму, а спільне «над чим ми зараз працюємо» живе тут, у памʼяті
# потоку, і доклеюється до рядка протоколу в момент запису.
# ⚠ Це НЕ сховище: у файл контекст не лягає, між потоками не ділиться і гине
# разом із прогоном (`clear()` кличе `costs.end_run`).
_local = threading.local()

CONTEXT_KEYS = ("actor", "source", "party", "task", "run")


def context() -> dict:
    return dict(getattr(_local, "ctx", None) or {})


def bind(**kw) -> dict:
    """Додати до контексту те, що щойно стало відомим. Невідомий ключ — ігнор.

    ⚠ ПРОГІН НЕ ЗАТИРАЄ ПОПЕРЕДНІЙ. Один крок роботи людини легко запускає дві-три
    системи. Якби кожна нова затирала попередню, ціна кроку мовчки приписалась би
    ОСТАННЬОМУ прогону — тобто журнал показав би дорогим той, що майже нічого не
    робив. Тому головним лишається ПЕРШИЙ, а всі решта памʼятаються поруч."""
    ctx = context()
    for k, v in kw.items():
        if k not in CONTEXT_KEYS:
            continue
        v = _s(v)
        if not v:
            continue
        if k == "run":
            seen = list(ctx.get("_runs") or [])
            if v not in seen:
                seen.append(v)
            ctx["_runs"] = seen
            ctx.setdefault("run", v)
            continue
        ctx[k] = v
    _local.ctx = ctx
    return dict(ctx)


def runs_seen() -> list:
    """Усі прогони цього кроку роботи (у порядку появи)."""
    return list(context().get("_runs") or [])


def clear() -> None:
    """Кінець прогону. Інакше «поточна задача» протекла б у наступний прогін і
    журнал почав би приписувати роботу не тому клієнту."""
    _local.ctx = {}


# ── Перевірка рядка ──────────────────────────────────────────────────────────
def norm_source(raw) -> tuple:
    """(канонічне джерело, сирий рядок якщо він не з словника)."""
    r = _s(raw)
    if not r:
        return "", ""
    low = r.lower()
    if low in SOURCES:
        return low, ""
    if low in _SOURCE_MAP:
        return _SOURCE_MAP[low], ""
    head = low.split("/")[0].split(":")[0].split("-")[0].strip()
    if head in _SOURCE_MAP:
        return _SOURCE_MAP[head], r
    return S_OTHER, r


def split_outcome(value) -> tuple:
    """«refused: немає доступу до пошти» → ("refused", "немає доступу до пошти")."""
    v = _s(value) or OUT_OK
    kind, _sep, reason = v.partition(":")
    kind = _s(kind).lower()
    if kind not in OUTCOMES:
        raise ProtocolError(
            "Невідомий підсумок «%s». Платформа знає лише: %s. Новий підсумок "
            "заводиться у словнику `protocol.OUTCOMES`, інакше звіт мовчки "
            "порахує поломку успіхом." % (kind, ", ".join(OUTCOMES)))
    return kind, scrub(reason, MAX_REASON)


def validate(action: str, subject, actor="", about=None, outcome=OUT_OK,
             cost_usd=0.0, source="", note="") -> dict:
    """Зібрати чистий рядок або ВІДМОВИТИ з причиною словами.

    Окрема від `write` навмисно: `write` не сміє кидати (журнал не валить роботу),
    а чек мусить БАЧИТИ причину відмови, а не порожній False."""
    act = _s(action)
    if act not in ACTIONS:
        raise ProtocolError(
            "Невідома дія «%s». Платформа знає лише: %s. Нове дієслово заводиться "
            "у словнику `protocol.ACTIONS` свідомо — інакше воно мовчки підміниться "
            "сусіднім, і звіт покаже не те, що сталось." % (act, ", ".join(sorted(ACTIONS))))

    subj = entity.norm(subject)            # невідомий вид сутності — відмова

    seen = []
    for r in (about or []):
        n = entity.norm(r)
        if n != subj and n not in seen:
            seen.append(n)

    act_ref = _s(actor)
    if act_ref:
        k, _i = entity.parse(act_ref)
        if k not in (entity.KIND_PERSON, entity.KIND_SYSTEM):
            raise ProtocolError(
                "Діяч може бути лише людиною або системою, а не %s («%s»). "
                "Контрагент нічого не робить у платформі — він той, ПРО кого дія."
                % (entity.KIND_NAMES[k], act_ref))
        act_ref = entity.norm(act_ref)

    out_kind, reason = split_outcome(outcome)

    try:
        usd = round(float(cost_usd or 0.0), 6)
    except Exception:
        raise ProtocolError("Ціна «%s» не є числом: журнал грошей не вгадує." % cost_usd)
    if usd < 0:
        raise ProtocolError("Відʼємна ціна %s у журналі неможлива." % usd)

    src, src_raw = norm_source(source)

    rec = {
        "at": clock.now(),
        "action": act,
        "actor": act_ref,
        "subject": subj,
        "about": seen,
        "outcome": out_kind,
        "reason": reason,
        "cost_usd": usd,
        "source": src,
    }
    if src_raw:
        rec["source_raw"] = scrub(src_raw, 80)
    n = scrub(note, MAX_REASON)
    if n:
        rec["note"] = n
    return rec


# ── Запис ────────────────────────────────────────────────────────────────────
def _append(path, rec) -> bool:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return True
    except Exception:
        return False


def _fail(reason: str, raw: dict) -> None:
    """Відхилений рядок не зникає мовчки — він лягає у власний файл невдач.

    Саме тому `write` може не кидати і все одно не бути тихим."""
    _append(_FAIL_PATH, {"at": _now_safe(), "reason": _s(reason)[:400],
                         "raw": {k: _s(v)[:200] for k, v in (raw or {}).items()}})


def _now_safe() -> str:
    try:
        return clock.now()
    except Exception:
        return ""


def write(action: str, subject, actor="", about=None, outcome=OUT_OK,
          cost_usd=0.0, source="", note="", use_context: bool = True) -> bool:
    """Записати дію. НІКОЛИ не кидає — але й ніколи не мовчить про відмову.

    Порожні поля доповнюються КОНТЕКСТОМ поточного прогону (див. вище): хто діє,
    звідки прийшла робота, який контрагент/задача/прогін зараз в роботі."""
    ctx = context() if use_context else {}
    try:
        a = list(about or [])
        if use_context:
            for key in ("party", "task", "run"):
                v = _s(ctx.get(key))
                if v and v not in a:
                    a.append(v)
        rec = validate(action, subject,
                       actor=_s(actor) or _s(ctx.get("actor")),
                       about=a, outcome=outcome, cost_usd=cost_usd,
                       source=_s(source) or _s(ctx.get("source")), note=note)
    except Exception as exc:
        _fail(str(exc), {"action": action, "subject": subject, "actor": actor,
                         "about": about, "outcome": outcome, "source": source})
        return False
    if not _append(_PATH, rec):
        # Диск не пише — робота все одно йде далі. Але слід невдачі теж пробуємо
        # покласти: якщо не вийде і це, ми хоча б не зламали роботу людини.
        _fail("не вдалося дописати у файл протоколу", {"action": action,
                                                       "subject": rec.get("subject")})
        return False
    return True


# ── Читання ──────────────────────────────────────────────────────────────────
def _read_lines(path=None) -> list:
    p = path or _PATH
    try:
        raw = p.read_text(encoding="utf-8").splitlines()
    except Exception:
        return []
    out = []
    for ln in raw:
        ln = ln.strip()
        if not ln:
            continue
        try:
            v = json.loads(ln)
        except Exception:
            continue                       # побитий рядок не валить читання решти
        if isinstance(v, dict):
            out.append(v)
    return out


def read(limit: int = 0, action: str = "", since: str = "") -> list:
    """Рядки журналу, свіжіші — в кінці. limit=0 — усе."""
    rows = _read_lines()
    if action:
        rows = [r for r in rows if _s(r.get("action")) == _s(action)]
    if since:
        rows = [r for r in rows if _s(r.get("at")) >= _s(since)]
    return rows[-limit:] if limit else rows


def about_ref(value, limit: int = 0) -> list:
    """⭐ ЗВʼЯЗОК ЧИТАЄТЬСЯ НАЗАД. «Покажи все про Каспера» — це один прохід тут.

    Знаходить рядки, де сутність є або головною річчю, або згадана серед тих,
    кого дія стосується."""
    ref = entity.norm(value)
    rows = [r for r in _read_lines()
            if _s(r.get("subject")) == ref or ref in (r.get("about") or [])]
    return rows[-limit:] if limit else rows


def failures(limit: int = 50) -> list:
    return _read_lines(_FAIL_PATH)[-limit:] if limit else _read_lines(_FAIL_PATH)
