/* ui/crm_core.js -- ОДИН ПИСАР ЕКРАНА CRM (зміна 436, 02.09.2026).
   ⭐⭐⭐ Рішення Андрія: паритет робимо СПІЛЬНИМ ФАЙЛОМ. Доти екран жив
   усередині ui/index.html, і клієнтові його можна було дати лише ДРУГОЮ
   редакцією -- а два писарі однієї правди розходяться за тиждень.
   Тепер писар один, а місць підключення двоє: консоль і сторінка /crm.
   ⛒ CRM_KITCHEN каже, чи малювати НАШІ, кухонні розділи (ліцензія, набір
   систем, черга вхідних). Ставить його той, хто монтує екран. */
var CRM_KITCHEN = true;
/* ⛒⛒⛒ 444: ДЕ ВИСИТЬ ЕКРАН -- ТУДИ Й ВЕДУТЬ ЙОГО ПОСИЛАННЯ. Платформа дає
   адресу своєї консолі (`/?deal=d0001`); на сторінці /crm вона веде в нікуди.
   Один писар адреси лишається на сервері, а екран лише переносить її на ту
   точку, де його змонтували. `''` -- консоль, `'/crm'` -- окрема сторінка. */
var CRM_BASE = '';
function crmHref(h){
  var s = String(h == null ? '' : h);
  if(!s || !CRM_BASE) return s;
  return s.slice(0, 2) === '/?' ? (CRM_BASE + s.slice(1)) : s;
}
/* ⛒ 444: РОЗБІР АДРЕСИ теж спільний. Доти він жив лише внизу консолі, і
   сторінка /crm не вміла відкрити картку за пересланим посиланням. */
async function crmRouteAddress(){
  try{
    var q = new URLSearchParams(location.search);
    var did = q.get('deal');
    if(did){ crmView('board'); await loadBoard(); await openCrmDeal(did); return true; }
    var pid = q.get('party');
    if(!pid) return false;
    crmView('base'); await loadBase(); await crmOpenParty(pid); return true;
  }catch(e){ return false; }
}
/* ⛒⛒⛒ 440: РОЗМІТКА ЛЕЖИТЬ ДОСЛІВНО. В екранованому JS-рядку її не
   бачить ані grep, ані сторож, ані око -- і чек «на воронці є САМА
   КНОПКА» падав через зникнення її ВИГЛЯДУ, а не самої кнопки. */
var CRM_BODY_HTML = `      <div id="crmView" style="display:flex;gap:8px;margin-bottom:12px">
        <button id="crmViewDash" class="crmtab" onclick="crmView('dashboard')">▣ Дашборд</button>
        <button id="crmViewBoard" class="crmtab on" onclick="crmView('board')">▤ Канбан-воронка</button>
        <button id="crmViewTiles" class="crmtab" onclick="crmView('tiles')">▦ Плитка</button>
        <button id="crmViewBase" class="crmtab" onclick="crmView('base')" aria-label="Клієнтська база: довідник контрагентів">▥ Клієнти <span id="crmBaseCnt"></span></button>
        <button id="crmMakeBtn" class="crmtab on" style="margin-left:auto" onclick="crmMakeOpen('')" title="Завести нову угоду: спершу клієнт, потім назва">+ Створити угоду</button>
      </div>
      <div id="crmTabs" style="display:flex;gap:8px;margin-bottom:14px">
        <button id="crmTabActive" class="crmtab on" onclick="crmTab('active')">Активні <span id="crmCntActive">0</span></button>
        <button id="crmTabArch" class="crmtab" onclick="crmTab('archived')">Архів <span id="crmCntArch">0</span></button>
      </div>
      <div id="crmMsg" role="status" aria-live="polite" style="font-size:12px;color:var(--muted);min-height:14px;margin-bottom:8px"></div>
      <div id="crmGrid" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:10px"></div>
      <div id="crmBoardWrap" style="display:none;position:relative">
        <div class="crmfold">
          <label><input type="checkbox" id="crmShowEmpty" onchange="crmFoldApply()"> показати порожні стадії</label>
          <span id="crmFoldWhy"></span>
        </div>
        <button id="crmNavL" class="crmnav" onclick="crmScroll(-1)" aria-label="Гортати ліворуч">‹</button>
        <div id="crmBoard" style="display:flex;gap:10px;overflow-x:auto;padding-bottom:8px;scroll-behavior:smooth" onscroll="crmUpdateNav()"></div>
        <button id="crmNavR" class="crmnav" onclick="crmScroll(1)" aria-label="Гортати праворуч">›</button>
      </div>
      <div id="crmDash" style="display:none"></div>
      <div id="crmBase" style="display:none"></div>
      <div id="crmDetail" style="display:none"></div>
`;
var CRM_FLOAT_HTML = `<div id="crmDrawer">
  <div class="crmdh" id="crmDrawerHead"></div>
  <div class="crmdbody" id="crmDrawerBody"></div>
</div>
<!-- ⭐⭐⭐ ЗМІНА 188 (16.08.2026). Два вікна, обидва НАД шухлядою картки
     (z-index шухляди — 80), бо «+ Завести угоду» тиснуть саме з неї. -->
<div class="overlay" id="crmPickOverlay" style="z-index:120" onclick="if(event.target===this)crmPickClose()">
  <div class="modal" style="width:min(620px,100%)">
    <div class="modal-head">
      <div><h2 id="crmPickTitle">Оберіть контрагента</h2>
      <div class="modal-sub" id="crmPickHint"></div></div>
      <button class="modal-x" onclick="crmPickClose()" title="Закрити">✕</button>
    </div>
    <div class="modal-body" id="crmPickBody"></div>
  </div>
</div>
<div class="overlay" id="crmMakeOverlay" style="z-index:110" onclick="if(event.target===this)crmMakeClose()">
  <div class="modal" style="width:min(560px,100%)">
    <div class="modal-head">
      <div><h2>Нова угода</h2>
      <div class="modal-sub">Продаж живе в УГОДІ: клієнт і назва — і воронка рахує саме її.</div></div>
      <button class="modal-x" onclick="crmMakeClose()" title="Закрити">✕</button>
    </div>
    <div class="modal-body" id="crmMakeBody"></div>
  </div>
</div>
`;
var crmState={view:'tiles',tab:'active',filter:{field:'',value:''},data:{active:[],archived:[],counts:{active:0,archived:0}},board:null,channels:null};
var CRM_STAGE_COL={'Новий клієнт':'var(--stg-new-h)','Перемовини':'var(--stg-talks-h)','Пілотне випробування':'var(--stg-pilot-h)','Укладення угоди':'var(--stg-deal-h)','Чекаємо оплати':'var(--stg-pay-h)','Активні клієнти':'var(--stg-active-h)','Неактивні клієнти':'var(--stg-off-h)','Архів':'var(--stg-arch-h)'};
var CRM_STAGE_BG={'Новий клієнт':'var(--stg-new-b)','Перемовини':'var(--stg-talks-b)','Пілотне випробування':'var(--stg-pilot-b)','Укладення угоди':'var(--stg-deal-b)','Чекаємо оплати':'var(--stg-pay-b)','Активні клієнти':'var(--stg-active-b)','Неактивні клієнти':'var(--stg-off-b)','Архів':'var(--stg-arch-b)'};
var crmEdit={};
/* ⛒⛒⛒ 436: ЕКРАН -- ЦЕ ТІЛО І ЧОХОЛ. Тіло спільне, чохол у кожного свій:
   у консолі це модальне вікно, на сторінці /crm -- сама сторінка. Тому тут
   живе ВІДКРИТТЯ ЕКРАНА, а показ чохла лишається тому, чий чохол. */
function crmMount(hostId, opts){
  var host = document.getElementById(hostId);
  if(!host) return false;
  CRM_KITCHEN = !(opts && opts.kitchen === false);
  CRM_BASE = (opts && opts.base) ? String(opts.base) : '';
  if(host.getAttribute('data-crm-mounted') !== '1'){
    host.innerHTML = CRM_BODY_HTML;
    host.setAttribute('data-crm-mounted','1');
  }
  /* ⛒ 443: КУХОННІ ВХОДИ ХОВАЄ ТОЙ, ХТО МОНТУЄ. «Плитка» в консолі -- це
     картки ЛІЦЕНЗІЙ (двері /api/crm/list), а не плитка угод; вкладки
     «Активні/Архів» належать тому самому переліку. Клієнтові вони не належать. */
  if(!CRM_KITCHEN){
    var tl = host.querySelector('#crmViewTiles'); if(tl) tl.style.display='none';
    var tb = host.querySelector('#crmTabs'); if(tb) tb.style.display='none';
  }
  if(!document.getElementById('crmDrawer')){
    var w = document.createElement('div');
    w.id = 'crmFloat';
    w.innerHTML = CRM_FLOAT_HTML;
    document.body.appendChild(w);
  }
  return true;
}
function crmOpen(){
  var d = document.getElementById('crmDrawer'); if(d) d.classList.remove('open');
  crmState.view='board'; crmState.tab='active';
  var m = document.getElementById('crmModal'); if(m) m.style.width='';
  crmViewUI(); crmSetTabUI(); crmShowBoard(); loadBoard();
}
function crmClose(){
  var d = document.getElementById('crmDrawer'); if(d) d.classList.remove('open');
  crmAddr('');
}

function crmSetTabUI(){ document.getElementById('crmTabActive').classList.toggle('on',crmState.tab==='active'); document.getElementById('crmTabArch').classList.toggle('on',crmState.tab==='archived'); }
function crmViewUI(){ document.getElementById('crmViewBase').classList.toggle('on',crmState.view==='base'); document.getElementById('crmViewTiles').classList.toggle('on',crmState.view==='tiles'); document.getElementById('crmViewBoard').classList.toggle('on',crmState.view==='board'); document.getElementById('crmViewDash').classList.toggle('on',crmState.view==='dashboard'); document.getElementById('crmView').style.display='flex'; }
function crmTab(t){ crmState.tab=t; crmSetTabUI(); crmShowList(); crmRender(); }
function crmShowList(){ var _b=document.getElementById('crmBase'); if(_b) _b.style.display='none'; document.getElementById('crmView').style.display='flex'; document.getElementById('crmTabs').style.display='flex'; document.getElementById('crmGrid').style.display='grid'; document.getElementById('crmBoardWrap').style.display='none'; document.getElementById('crmDash').style.display='none'; document.getElementById('crmDetail').style.display='none'; document.getElementById('crmMsg').textContent=''; }
function crmShowBoard(){ var _b=document.getElementById('crmBase'); if(_b) _b.style.display='none'; document.getElementById('crmView').style.display='flex'; document.getElementById('crmTabs').style.display='none'; document.getElementById('crmGrid').style.display='none'; document.getElementById('crmBoardWrap').style.display='block'; document.getElementById('crmDash').style.display='none'; document.getElementById('crmDetail').style.display='none'; document.getElementById('crmMsg').textContent='Перетягни картку між стадіями, щоб змінити статус.'; }
function crmShowDash(){ var _b=document.getElementById('crmBase'); if(_b) _b.style.display='none'; document.getElementById('crmView').style.display='flex'; document.getElementById('crmTabs').style.display='none'; document.getElementById('crmGrid').style.display='none'; document.getElementById('crmBoardWrap').style.display='none'; document.getElementById('crmDash').style.display='block'; document.getElementById('crmDetail').style.display='none'; document.getElementById('crmMsg').textContent=''; }
function crmShowBase(){ document.getElementById('crmView').style.display='flex'; document.getElementById('crmTabs').style.display='none'; document.getElementById('crmGrid').style.display='none'; document.getElementById('crmBoardWrap').style.display='none'; document.getElementById('crmDash').style.display='none'; document.getElementById('crmDetail').style.display='none'; document.getElementById('crmBase').style.display='block'; document.getElementById('crmMsg').textContent=''; }

/* ── КЛІЄНТСЬКА БАЗА (зміна 167, 12.08.2026) ─────────────────────────────────
   Довідник контрагентів + черга «Не оброблені». Контрагент потрапляє в базу
   ЛИШЕ кнопкою людини: код більше не заводить картку з невідомого листа. */
var crmBaseState={filter:'all',inbox:[],parties:[],counts:{},kinds:{},roles:{},q:'',page:1,per:50,mode:'tiles',search:null,qFocus:false,seq:0,sort:'',dir:'',
  /* ⭐⭐⭐ D3 (16.08.2026): стан картки, фільтр «клієнти менеджера X» і ВИБІР.
     🩸 `sel` — рівно ті номери, які людина відзначила галочками; `selAll` —
     ЗОВСІМ ІНШЕ: «усе, що збіглося з фільтром», навіть те, чого на цій
     сторінці не видно. Тримати їх одним полем означало б плутати 50 і 743 —
     а плутанина тут коштує даних. */
  state:'live',manager:'',sel:{},selAll:false};
/* ⛒ Панель групової дії живе ОКРЕМИМ станом і має ВЛАСНИЙ лічильник питань:
   спільний зробив би її залежною від перемальовування переліку (урок 188). */
var crmBulk={seq:0,busy:false,plan:null,result:null,msg:'',bad:false,action:'',employee:''};
async function loadBase(){
  var el=document.getElementById('crmBase');
  el.innerHTML='<div style="color:var(--muted);font-size:12.5px;padding:8px 0">Читаю клієнтську базу…</div>';
  try{
    /* ⭐ D2 (16.08.2026): ЩО ПОКАЗУВАТИ — ВИРІШУЄ СЕРВЕР. Четверті двері
       (`party_search`) віддають рядки сторінкою, а `/api/crm/parties` лишається
       для переліків вибору («привʼязати до наявного») і для лічильників. */
    var my=crmBaseAsk();
    /* ⛒ 443: черга «Не оброблені» -- НАША кухня (двері /api/crm/inbox).
       Без кухні її не питаємо взагалі: інакше клієнт дістав би 403 і порожній
       екран замість своєї бази. */
    var r=await Promise.all([fetch('/api/crm/inbox'),fetch('/api/crm/parties'),fetch('/api/crm/spread'),fetch(crmSearchUrl())]);
    var di=await r[0].json(), dp=await r[1].json(), ds=await r[2].json(), dq=await r[3].json();
    if(crmBaseStale(my)) return;   /* поки читали — спитали інше */
    crmBaseState.search=(dq&&!dq.error)?dq:{rows:[],found:0,page:1,pages:1,error:(dq||{}).error||''};
    crmBaseState.inbox=di.inbox||[]; crmBaseState.parties=dp.parties||[];
    /* ⛒ Черга перечиталась — номери рядків уже інші, тому раніше обране
       скидаємо: інакше звернення привʼязалось би до ЧУЖОГО контрагента. */
    crmBaseState.attach={};
    /* ⭐ C2: друга черга — листи ВІДОМИХ контактів без адреси угоди. */
    crmBaseState.spread=ds.items||[];
    /* ⭐ 618: хто зараз дивиться — каже СЕРВЕР. Екран сам цього не знає
       і не вгадує: кнопка «це мій лист» мусить бути саме одним кліком. */
    crmBaseState.me=ds.me||'';
    /* ⛒ ЛІЧИЛЬНИКИ БЕРЕМО В ТОГО, ХТО ЗНАЄ ПРО СТАН (D3). `/api/crm/parties`
       рахує всю базу гуртом і не знає, чи ми зараз дивимось архів, — його
       числа під вкладками «У роботі / Архів» брехали б. */
    crmBaseState.counts=(dq&&!dq.error&&dq.counts)?dq.counts:(dp.counts||{});
    crmBaseState.kinds=dp.kinds||{}; crmBaseState.roles=dp.roles||{};
    renderBase();
  }catch(e){
    el.innerHTML='<div style="color:var(--bad);font-size:12.5px;padding:8px 0">Не вдалося прочитати базу: '+crmEsc(e.message||e)+'</div>';
  }
}
/* ── ⭐⭐⭐ ПОШУК ПО БАЗІ (крок D2, 16.08.2026) ────────────────────────────────
   Слово Андрія 15.08: «коли їх буде 3 тисячі, як знайти потрібного?»
   ⛒ ЕКРАН НІЧОГО НЕ ВІДБИРАЄ САМ. Раніше вкладки «Усі / Контактні особи /
   Постачальники» різали масив ТУТ — на сторінках це дало б два різні переліки
   з однієї бази (екран бачить лише завантажене, сервер — усе). Тепер слово
   фільтра їде в двері, а відповідь приходить готовою сторінкою. */
function crmSearchUrl(){
  var st=crmBaseState;
  return '/api/crm/party_search?q='+encodeURIComponent(st.q||'')
    +'&filter='+encodeURIComponent(st.filter||'all')
    +'&page='+(st.page||1)+'&per='+(st.per||50)
    +'&sort='+encodeURIComponent(st.sort||'')+'&dir='+encodeURIComponent(st.dir||'')
    /* ⭐ D3: стан і фільтр менеджера їдуть у ті самі двері. */
    +'&state='+encodeURIComponent(st.state||'live')
    +'&manager='+encodeURIComponent(st.manager||'');
}
/* ⛒ УМОВИ ВІДБОРУ ОДНИМ ШМАТКОМ. Групова дія «все за фільтром» надсилає
   рівно ті самі слова, якими намальовано перелік, — інакше людина бачила б
   одне число, а міняла інші картки. */
function crmBaseCriteria(){
  var st=crmBaseState;
  return {query:st.q||'',filter:st.filter||'all',sort:st.sort||'',dir:st.dir||'',
          state:st.state||'live',manager:st.manager||''};
}
/* 🩸🩸🩸 ВІДПОВІДЬ НА СТАРЕ ПИТАННЯ НЕ СМІЄ ПЕРЕБИТИ НОВЕ (знайдено ЖИВИМ
   прогоном 16.08.2026). Два запити можуть їхати одночасно — людина набирає
   «ка», потім «каспер»; або закрилась картка (а це теж перечитує розділ) і
   тут-таки натиснуто «Далі». Хто приїхав ОСТАННІМ, той і малювався — і екран
   показував відповідь, якої вже ніхто не питав. Тому в кожного питання свій
   НОМЕР, і чужа відповідь тихо викидається. */
function crmBaseAsk(){ crmBaseState.seq=(crmBaseState.seq||0)+1; return crmBaseState.seq; }
function crmBaseStale(my){ return my!==crmBaseState.seq; }
async function loadBaseRows(){
  var my=crmBaseAsk();
  try{
    var d=await fetch(crmSearchUrl()).then(function(r){return r.json();});
    if(crmBaseStale(my)) return;
    /* ⛒ Відмова сервера їде СЛОВАМИ на екран, а не гине в консолі. */
    if(d.error){ crmBaseState.search={rows:[],found:0,page:1,pages:1,error:d.error}; renderBase(); return; }
    crmBaseState.search=d; crmBaseState.page=d.page||1;
    if(d.counts) crmBaseState.counts=d.counts;
    renderBase();
  }catch(e){ if(crmBaseStale(my)) return; crmBaseMsg('Не вдалося знайти: '+(e.message||e),true); }
}
/* 🩸🩸🩸 ЗМІНИЛИ УМОВИ ВІДБОРУ — ВИБІР СКИДАЄМО. «Вибрано все за фільтром»
   означає РІВНО той фільтр, який людина бачила, коли тиснула. Якби вибір
   пережив зміну вкладки, «архівувати все» тихо поїхало б по іншій громаді —
   і це та шкода, яку вже не відкотити. Порядок (сортування) громади не
   міняє, тому його тут свідомо немає. */
function crmSelReset(){
  crmBaseState.sel={}; crmBaseState.selAll=false;
  crmBulk.plan=null; crmBulk.result=null; crmBulk.msg=''; crmBulk.bad=false; crmBulk.action='';
}
function crmSelCount(){
  if(crmBaseState.selAll) return ((crmBaseState.search||{}).found)||0;
  return Object.keys(crmBaseState.sel||{}).length;
}
function crmSelIds(){ return Object.keys(crmBaseState.sel||{}); }
function crmSelOn(pid){ return crmBaseState.selAll || !!(crmBaseState.sel||{})[pid]; }
function crmSelToggle(pid){
  /* ⛔ Поки вибрано ВСЕ за фільтром, окрема галочка не знімається: «усе, крім
     цих трьох» на трьох тисячах — це вже не вибір, а тихий сюрприз. Дорога
     назад одна й названа вголос: «Зняти вибір». */
  if(crmBaseState.selAll) return;
  var s=crmBaseState.sel||{};
  if(s[pid]) delete s[pid]; else s[pid]=true;
  crmBaseState.sel=s; crmBulk.plan=null; crmBulk.result=null; renderBase();
}
function crmSelPage(on){
  if(crmBaseState.selAll) return;
  var rows=((crmBaseState.search||{}).rows)||[], s=crmBaseState.sel||{};
  for(var i=0;i<rows.length;i++){ if(on) s[rows[i].id]=true; else delete s[rows[i].id]; }
  crmBaseState.sel=s; crmBulk.plan=null; crmBulk.result=null; renderBase();
}
function crmSelAllFilter(){
  crmBaseState.selAll=true; crmBaseState.sel={};
  crmBulk.plan=null; crmBulk.result=null; renderBase();
}
function crmSelClear(){ crmSelReset(); renderBase(); }
function crmBaseTab(s){
  if((crmBaseState.state||'live')===s) return;
  crmBaseState.state=s; crmBaseState.page=1; crmBaseState.qFocus=false;
  crmSelReset(); loadBaseRows();
}
function crmBaseManager(v){
  crmBaseState.manager=v||''; crmBaseState.page=1; crmBaseState.qFocus=false;
  crmSelReset(); loadBaseRows();
}
function crmBaseFilter(f){ crmBaseState.filter=f; crmBaseState.page=1; crmBaseState.qFocus=false; crmSelReset(); loadBaseRows(); }
function crmBaseMode(m){ crmBaseState.mode=(m==='list'?'list':'tiles'); crmBaseState.qFocus=false; renderBase(); }
function crmBasePage(n){
  var s=crmBaseState.search||{}, p=Math.max(1,Math.min(n,s.pages||1));
  if(p===(crmBaseState.page||1)) return;
  crmBaseState.page=p; crmBaseState.qFocus=false; loadBaseRows();
}
function crmBaseFind(){
  crmBaseState.q=(crmVal('crmBaseQ')||'').trim();
  crmBaseState.page=1; crmBaseState.qFocus=true; crmSelReset(); loadBaseRows();
}
function crmBaseClear(){ crmBaseState.q=''; crmBaseState.page=1; crmBaseState.qFocus=true; crmSelReset(); loadBaseRows(); }
/* ⭐ СОРТУВАННЯ (зміна 187, слово Андрія 16.08). Клік по заголовку — той самий
   стовпець удруге перевертає порядок. ⛒ Сортує СЕРВЕР: у браузері лежить лише
   одна сторінка, і «впорядкувати видиме» на трьох тисячах — це впорядкований
   шматок, а не список. Тому екран лише КАЖЕ, за чим сортувати. */
function crmBaseSort(col){
  /* 🩸 ПЕРЕВЕРТАЄМО ТЕ, ЩО СПРАВДІ ПРИЇХАЛО, А НЕ СВОЮ ЗДОГАДКУ (знайдено
     ЖИВИМ 16.08.2026). Екран просить «природний напрям» порожнім рядком, а
     який він насправді — вирішує СЕРВЕР. Поки другий клік рахувався від
     порожнього рядка, він щоразу давав те саме «за зростанням», і стовпець
     не перевертався ЖОДНОГО разу. Джерело правди про напрям — відповідь. */
  var st=crmBaseState, got=st.search||{};
  if((got.sort||'')===col){ st.dir=((got.dir||'asc')==='asc')?'desc':'asc'; }
  else { st.sort=col; st.dir=''; }   /* '' = природний напрям стовпця */
  st.page=1; st.qFocus=false; loadBaseRows();
}
async function crmSpreadPost(path,body,okMsg){
  try{
    var r=await fetch('/api/crm/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    var d=await r.json();
    if(!r.ok||d.error){ crmBaseMsg(d.error||'Не вдалося',true); return null; }
    crmBaseState.spread=d.spread||[];
    if(d.me!==undefined) crmBaseState.me=d.me||'';
    renderBase();
    crmBaseMsg(okMsg);
    return d;
  }catch(e){ crmBaseMsg('Не вдалося: '+(e.message||e),true); return null; }
}
async function crmSpreadAssign(i){
  var it=(crmBaseState.spread||[])[i]; if(!it) return;
  var did=crmVal('sp_deal_'+i);
  /* ⛔ Порожній вибір — це НЕ «постав куди-небудь». */
  if(!did){ crmBaseMsg('Не обрано угоду. Сама я не вибираю — саме заради цього черга й існує.',true); return; }
  await crmSpreadPost('spread_assign',{item:it.id,deal:did},'Лист рознесено в угоду '+did+'.');
}
/* ⭐⭐⭐ 618: «ЧИЙ ЦЕ ЛИСТ» — один клік. Він не прилипає до рядка, а
   ставить ВІДПОВІДАЛЬНОГО КОНТРАГЕНТА — тобто навчає зв’язок на майбутнє.
   ⛒ Відмову (передати клієнта може керівник) каже СЕРВЕР словами — екран
   свого другого правила про права не заводить. */
async function crmSpreadOwner(i,emp){
  var it=(crmBaseState.spread||[])[i]; if(!it) return;
  if(!emp){ crmBaseMsg('Не обрано людину.',true); return; }
  await crmSpreadPost('spread_owner',{item:it.id,owner:emp},
                      'Запам’ятала: цей контрагент тепер за ним. Наступний лист уже не спитає.');
}
async function crmSpreadDrop(i){
  var it=(crmBaseState.spread||[])[i]; if(!it) return;
  await crmSpreadPost('spread_drop',{item:it.id,why:'рішення людини в черзі'},'Прибрано з черги без угоди.');
}
function crmBaseMsg(text,bad){
  var m=document.getElementById('crmBaseMsg'); if(!m) return;
  m.textContent=text||''; m.style.color=bad?'var(--bad)':'var(--muted)';
}
/* ══════════════════════════════════════════════════════════════════════════
   ⭐⭐⭐ ГРУПОВІ ДІЇ НАД БАЗОЮ (крок D3, 16.08.2026)
   Слово Андрія: «вибрати все за фільтром» — це НЕ «все видиме на сторінці».
   На сторінці 50, за фільтром 743, і плутанина тут коштує ДАНИХ.
   ⛒ Тому екран нічого не рахує сам: скільки саме зачепить дія, каже СЕРВЕР
   переліком (`bulk_preview`) — і людина читає його ДО того, як щось сталось.
   ══════════════════════════════════════════════════════════════════════════ */
/* ⛒ УКРАЇНСЬКА МНОЖИНА, А НЕ «1 картка / решта карток». «3 карток» у тексті,
   який людина читає ПЕРЕД незворотною дією, виглядає як машинний переклад —
   і підриває довіру рівно там, де вона потрібна найбільше. */
function crmCards(n){
  n=Math.abs(Number(n)||0);
  var t=n%10, h=n%100;
  if(t===1&&h!==11) return 'картка';
  if(t>=2&&t<=4&&(h<12||h>14)) return 'картки';
  return 'карток';
}
function crmBulkAsk(){ crmBulk.seq=(crmBulk.seq||0)+1; return crmBulk.seq; }
function crmBulkStale(my){ return my!==crmBulk.seq; }
function crmBulkMsg(t,bad){ crmBulk.msg=t||''; crmBulk.bad=!!bad; renderBase(); }
function crmBulkCancel(){ crmBulk.plan=null; crmBulk.msg=''; crmBulk.bad=false; renderBase(); }
function crmBulkPost(path,body){
  return fetch('/api/crm/'+path,{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify(body)}).then(function(r){
      return r.json().then(function(d){ return {ok:r.ok,d:d}; });
    });
}
function crmBulkBody(action){
  var st=crmBaseState;
  return {action:action,
          scope:st.selAll?'filter':'ids',
          ids:st.selAll?[]:crmSelIds(),
          criteria:crmBaseCriteria(),
          employee:crmBulk.employee||''};
}
/* ⭐ КРОК ПЕРШИЙ: ПЕРЕЛІК ІЗ ЧИСЛОМ. Ніякої дії тут ще не відбувається. */
async function crmBulkPlan(action){
  crmBulk.action=action;
  if(action==='manager'){
    /* ⛒ Кому передаємо — читаємо ДО запиту: порожній вибір знеосібнив би всіх. */
    crmBulk.employee=(crmVal('crmBulkEmp')||'').trim();
  }
  var my=crmBulkAsk(); crmBulk.busy=true; crmBulk.result=null; crmBulk.msg=''; crmBulk.bad=false;
  renderBase();
  try{
    var r=await crmBulkPost('bulk_preview',crmBulkBody(action));
    if(crmBulkStale(my)) return;
    crmBulk.busy=false;
    /* ⛒ ВІДМОВА ЛЯГАЄ ТУДИ, КУДИ ЛЮДИНА ДИВИТЬСЯ — у саму панель дії. */
    if(!r.ok||r.d.error){ crmBulk.plan=null; crmBulkMsg(r.d.error||'Не вдалося скласти перелік',true); return; }
    crmBulk.plan=r.d; renderBase();
  }catch(e){
    if(crmBulkStale(my)) return;
    crmBulk.busy=false; crmBulk.plan=null; crmBulkMsg('Не вдалося скласти перелік: '+(e.message||e),true);
  }
}
/* ⭐ КРОК ДРУГИЙ: ЗРОБИТИ. Тільки після прочитаного переліку. */
async function crmBulkGo(){
  var plan=crmBulk.plan; if(!plan) return;
  var my=crmBulkAsk(); crmBulk.busy=true; renderBase();
  try{
    var r=await crmBulkPost('bulk_apply',crmBulkBody(plan.action));
    if(crmBulkStale(my)) return;
    crmBulk.busy=false; crmBulk.plan=null;
    if(!r.ok||r.d.error){ crmBulkMsg(r.d.error||'Не вдалося виконати',true); return; }
    /* ⛒ ПІДСУМОК ПЕРЕЖИВАЄ СКИДАННЯ ВИБОРУ. Спершу знімаємо вибір (картки вже
       змінились — тримати на них галочки означало б показувати вчорашній
       намір), і аж ПОТІМ кладемо підсумок: інакше людина не побачила б, що
       саме сталось, і чи всі картки лягли. */
    crmSelReset();
    crmBulk.result=r.d;
    loadBaseRows();
  }catch(e){
    if(crmBulkStale(my)) return;
    crmBulk.busy=false; crmBulk.plan=null; crmBulkMsg('Не вдалося виконати: '+(e.message||e),true);
  }
}
function crmBulkEmpOpts(){
  var opts='<option value="">— оберіть працівника —</option>';
  /* ⛒ ПЕРЕЛІК ЛЮДЕЙ ПРИЇЖДЖАЄ З СЕРВЕРА. Власний список у браузері розійшовся
     б із оргструктурою на першому ж звільненні.
     ⛔ І ЗВІЛЬНЕНОГО ТУТ НЕМАЄ: віддати йому клієнтів не можна (правило D1). */
  var list=((crmBaseState.search||{}).manager_options)||[];
  for(var i=0;i<list.length;i++){
    if(list[i].dismissed) continue;
    opts+='<option value="'+crmEsc(list[i].id)+'"'+((crmBulk.employee===list[i].id)?' selected':'')+'>'+crmEsc(list[i].name)+'</option>';
  }
  return opts;
}
/* Панель вибору: скільки вибрано, за яким відбором і що з цим можна зробити. */
function crmBulkBarHtml(){
  var st=crmBaseState, n=crmSelCount();
  var sr=st.search||{}, found=sr.found||0, rows=sr.rows||[];
  var h=[];
  /* ⭐ «ВСЕ ЗА ФІЛЬТРОМ» ПРОПОНУЄМО ЛИШЕ ТОДІ, КОЛИ ЗА ФІЛЬТРОМ БІЛЬШЕ, НІЖ
     НА СТОРІНЦІ, — інакше це те саме число під двома різними словами. */
  if(!n) return '';
  h.push('<div id="crmBulkBar" style="border:1px solid var(--accent);border-radius:10px;padding:10px 12px;margin:0 0 10px;background:var(--panel2)">');
  h.push('<div style="font-size:12.5px;margin-bottom:8px">'
    +(st.selAll
      ? ('Вибрано <b>усе за фільтром: '+found+'</b> <span style="color:var(--muted)">('+crmEsc(sr.criteria_name||'')+')</span>')
      : ('Вибрано <b>'+n+'</b> <span style="color:var(--muted)">'
         +(found>rows.length?('на цій сторінці; за фільтром знайдено '+found):('із '+found))+'</span>'))
    +'</div>');
  h.push('<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">');
  if(!st.selAll && found>n){
    h.push('<button class="crmtab" onclick="crmSelAllFilter()">Вибрати все за фільтром ('+found+')</button>');
  }
  if((st.state||'live')==='archived'){
    h.push('<button class="crmtab on" onclick="crmBulkPlan(\'unarchive\')">Повернути з архіву</button>');
  } else {
    h.push('<button class="crmtab on" onclick="crmBulkPlan(\'archive\')">Прибрати в архів</button>');
  }
  h.push('<span style="display:inline-block;width:1px;height:22px;background:var(--line)"></span>');
  /* 🩸 ВИБІР ПРАЦІВНИКА МУСИТЬ ПЕРЕЖИВАТИ ПЕРЕМАЛЬОВУВАННЯ (знайдено ЧИТАННЯМ
     КОДУ, а не чеком). Панель малюється цілим шматком розмітки, тому кожна
     наступна галочка народжувала список заново — і щойно обраний працівник
     мовчки скидався на «— оберіть —». Людина цього не бачить: вона вже
     вибрала. Тому запамʼятовуємо вибір ОДРАЗУ, а не в мить натискання. */
  h.push('<select id="crmBulkEmp" onchange="crmBulk.employee=this.value" style="padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--txt);font-size:12.5px;max-width:240px">'+crmBulkEmpOpts()+'</select>');
  h.push('<button class="crmtab" onclick="crmBulkPlan(\'manager\')">Перезакріпити відповідального</button>');
  h.push('<button class="crmtab" style="margin-left:auto" onclick="crmSelClear()">Зняти вибір</button>');
  h.push('</div>');
  if(crmBulk.msg){
    h.push('<div style="font-size:12px;margin-top:8px;color:'+(crmBulk.bad?'var(--bad)':'var(--muted)')+'">'+crmEsc(crmBulk.msg)+'</div>');
  }
  if(crmBulk.busy) h.push('<div style="font-size:12px;color:var(--muted);margin-top:8px">Рахую…</div>');
  h.push(crmBulkPlanHtml());
  h.push('</div>');
  return h.join('');
}
/* 🩸🩸🩸 ПЕРЕЛІК ІЗ ЧИСЛОМ **ДО** ДІЇ. Мовчазна дія над сотнями записів —
   незворотна шкода, тому людина спершу читає, ЩО саме зміниться. */
function crmBulkPlanHtml(){
  var p=crmBulk.plan; if(!p) return '';
  var h=['<div style="border-top:1px dashed var(--line);margin-top:10px;padding-top:10px">'];
  h.push('<div style="font-size:12.5px;font-weight:700;margin-bottom:6px">'+crmEsc(p.action_name)
    +': <span style="color:var(--accent)">'+p.count+'</span> '
    +crmCards(p.count)
    +(p.employee_name?(' → '+crmEsc(p.employee_name)):'')+'</div>');
  if(p.criteria_name){
    h.push('<div style="font-size:11.5px;color:var(--muted);margin-bottom:6px">за відбором: '+crmEsc(p.criteria_name)+'</div>');
  }
  var rows=p.rows||[], names=[];
  for(var i=0;i<rows.length;i++){
    names.push('<div style="font-size:12px;padding:2px 0">'+crmEsc(rows[i].name)
      +' <span style="color:var(--muted)">'+crmEsc(rows[i].id)
      +(rows[i].manager_name?(' · веде: '+crmEsc(rows[i].manager_name)):' · нікого не веде')+'</span></div>');
  }
  h.push('<div style="max-height:190px;overflow:auto;border:1px solid var(--line);border-radius:8px;padding:8px;background:var(--panel)">'+names.join('')+'</div>');
  /* ⛒ ЧЕСНА МЕЖА ПЕРЕЛІКУ: число повне, імен показуємо стільки, скільки
     читають очима, — і прямо кажемо, скільки лишилось поза переліком. */
  if(p.rest>0){
    h.push('<div style="font-size:11.5px;color:var(--muted);margin-top:6px">…і ще '+p.rest+'. Число вище — повне; тут показано перші '+p.shown+' імен.</div>');
  }
  h.push('<div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">'
    +'<button class="crmtab on" onclick="crmBulkGo()">Так, зробити</button>'
    +'<button class="crmtab" onclick="crmBulkCancel()">Скасувати</button></div>');
  h.push('</div>');
  return h.join('');
}
/* ⛒ ЧАСТКОВИЙ УСПІХ — ЦЕ ВІДПОВІДЬ, А НЕ МОВЧАННЯ: хто не ліг — поіменно. */
function crmBulkResultHtml(){
  var r=crmBulk.result; if(!r) return '';
  var bad=(r.failed||0)>0;
  var h=['<div style="border:1px solid '+(bad?'var(--warn)':'var(--line)')+';border-radius:10px;padding:10px 12px;margin:0 0 10px;background:var(--panel2)">'];
  h.push('<div style="font-size:12.5px;font-weight:700">'+crmEsc(r.action_name)+': зроблено '+r.done+' із '+r.asked
    +(r.employee_name?(' → '+crmEsc(r.employee_name)):'')+'</div>');
  var fr=r.failed_rows||[];
  for(var i=0;i<fr.length;i++){
    h.push('<div style="font-size:12px;color:var(--warn);margin-top:4px">'+crmEsc(fr[i].name)
      +' <span style="color:var(--muted)">'+crmEsc(fr[i].id)+'</span> — '+crmEsc(fr[i].why)+'</div>');
  }
  h.push('<div style="margin-top:8px"><button class="crmtab" onclick="crmBulkForget()">Зрозуміло</button></div>');
  h.push('</div>');
  return h.join('');
}
function crmBulkForget(){ crmBulk.result=null; renderBase(); }
function renderBase(){
  var st=crmBaseState, h=[];
  var kindName={'':'не вказано','person':'фізична особа','company':'компанія'};
  var roleName={'client':'клієнт','supplier':'постачальник','partner':'партнер','contact':'контактна особа'};
  h.push('<div id="crmBaseMsg" role="status" aria-live="polite" style="font-size:12px;color:var(--muted);min-height:14px;margin-bottom:8px"></div>');

  /* Черга «Не оброблені» -- 450: це ЛІДИ, і вони належать клієнту так само,
     як і нам. Ховати її від нього було моєю помилкою. */
  h.push('<div style="font-weight:700;font-size:13px;margin:2px 0 8px">Не оброблені <span style="color:var(--muted);font-weight:600">'+st.inbox.length+'</span></div>');
  if(!st.inbox.length){
    h.push('<div style="color:var(--muted);font-size:12.5px;border:1px dashed var(--line);border-radius:10px;padding:12px;margin-bottom:16px">Порожньо. Сюди потрапляють листи й повідомлення від тих, кого база ще не знає — щоб жоден новий контакт не загубився.</div>');
  } else {
    for(var i=0;i<st.inbox.length;i++){
      var it=st.inbox[i];
      var chan=(it.channel==='email')?'Пошта':'Телеграм';
      var _at=(st.attach||{})[i]||null;
      h.push('<div style="border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin-bottom:8px;background:var(--panel2)">'
        +'<div style="display:flex;gap:8px;align-items:baseline;flex-wrap:wrap">'
        +'<span style="font-size:11px;color:var(--muted)">'+chan+'</span>'
        +'<b style="font-size:13px">'+crmEsc(it.identity)+'</b>'
        +(it.name?'<span style="font-size:12px;color:var(--muted)">'+crmEsc(it.name)+'</span>':'')
        +(it.count>1?'<span style="font-size:11px;color:var(--muted)">звернень: '+it.count+'</span>':'')
        +'</div>'
        +(it.first_seen?'<div style="font-size:11px;color:var(--muted);margin-top:2px">перше звернення '+crmDateTime(it.first_seen)+' · останнє '+crmDateTime(it.last_seen)+'</div>':'')
        +(it.preview?'<div style="font-size:12px;color:var(--muted);margin:4px 0 2px;white-space:pre-wrap;word-break:break-word">'+crmEsc(it.preview)+'</div>':'<div style="height:6px"></div>')
        /* ⛒ ЧЕСНА МЕЖА, А НЕ ТИХА ОБІЦЯНКА. Черга зберігає лише перші 200 знаків
           звернення — повного тексту в платформі НЕМАЄ, і вдавати, що він
           відкриється, гірше за прямо сказану межу. */
        +(it.preview&&String(it.preview).length>=195?'<div style="font-size:11px;color:var(--muted);margin:0 0 8px">⚠ Це початок звернення: платформа зберегла перші 200 знаків. Повний текст — у самому телеграмі чи пошті.</div>':'<div style="height:6px"></div>')
        +'<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">'
        +'<label style="font-size:11px;color:var(--muted)">Назва<br><input id="pb_name_'+i+'" type="text" value="'+crmEsc(it.name||it.identity)+'" style="min-width:190px;padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--txt)"></label>'
        +'<label style="font-size:11px;color:var(--muted)">Тип<br><select id="pb_kind_'+i+'" style="padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--txt)"><option value="">не вказано</option><option value="person">фізична особа</option><option value="company">компанія</option></select></label>'
        +'<label style="font-size:11px;color:var(--muted)">Роль<br><select id="pb_role_'+i+'" style="padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--txt)"><option value="client">клієнт</option><option value="supplier">постачальник</option><option value="partner">партнер</option></select></label>'
        +'<button class="crmtab on" style="min-height:32px" onclick="crmPromote('+i+')">У базу</button>'
        +'<button class="crmtab" style="min-height:32px" onclick="crmInboxDrop('+i+')" aria-label="Прибрати це вхідне з черги">Прибрати</button>'
        +'</div>'
        /* ⭐ ДРУГИЙ ШЛЯХ, БЕЗ ЯКОГО ПЕРШИЙ ШКОДИТЬ. Той самий Борис пише і з пошти,
           і з телеграму. Коли в базі він УЖЕ Є, кнопка «У базу» заводить ДУБЛЬ
           руками — тобто псує саме той актив, заради якого писався довідник. */
        +'<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:8px;padding-top:8px;border-top:1px dashed var(--line)">'
        +'<span style="font-size:11px;color:var(--muted)">Це вже відомий контрагент?</span>'
        /* ⭐ ЗМІНА 188: був `select` НА ВСЮ БАЗУ — на трьох тисячах це рівно
           та сама поламана робота, від якої лікував D2. Тепер той самий
           вибирач із пошуком на сервері. */
        +'<span style="font-size:12px">'+(_at?('обрано: <b>'+crmEsc(_at.name)+'</b> <span style="color:var(--muted)">('+crmEsc(_at.id)+')</span>'):'<span style="color:var(--muted)">контрагента не обрано</span>')+'</span>'
        +'<button class="crmtab" style="min-height:32px" onclick="crmAttachPick('+i+')">'+(_at?'Обрати іншого':'Обрати контрагента')+'</button>'
        +'<button class="crmtab" style="min-height:32px" onclick="crmInboxAttach('+i+')">Привʼязати до наявного</button>'
        +'</div></div>');
    }
    h.push('<div style="height:10px"></div>');
  }

  /* ⭐⭐⭐ ЧЕРГА «РОЗНЕСТИ» (крок C2). Сестра «Не оброблених», але про інше:
     контакт ВІДОМИЙ, а от у яку з його угод лягає лист — невідомо. Платформа
     тут свідомо НЕ вгадує: «покладу в найсвіжішу» помиляється тихо, і помилку
     видно вже після відповіді клієнту. */
  var sp=st.spread||[];
  h.push('<div style="font-weight:700;font-size:13px;margin:2px 0 8px">Рознести <span style="color:var(--muted);font-weight:600">'+sp.length+'</span></div>');
  if(!sp.length){
    h.push('<div style="color:var(--muted);font-size:12.5px;border:1px dashed var(--line);border-radius:10px;padding:12px;margin-bottom:16px">Порожньо. Сюди лягають листи від тих, кого база вже знає, але без адреси угоди в темі — щоб жоден не потрапив у чужу угоду навмання.</div>');
  } else {
    for(var q=0;q<sp.length;q++){
      var sr=sp[q], ch=(sr.channel==='email')?'Пошта':'Телеграм';
      var opts='<option value="">— оберіть угоду —</option>';
      for(var w=0;w<(sr.choices||[]).length;w++){
        var cc=sr.choices[w];
        opts+='<option value="'+crmEsc(cc.id)+'">'+crmEsc(cc.id)+' · '+crmEsc(cc.name)+(cc.stage?(' · '+crmEsc(cc.stage)):'')+'</option>';
      }
      h.push('<div style="border:1px solid var(--line);border-radius:10px;padding:10px 12px;margin-bottom:8px;background:var(--panel2)">'
        +'<div style="display:flex;gap:8px;align-items:baseline;flex-wrap:wrap">'
        +'<span style="font-size:11px;color:var(--muted)">'+ch+'</span>'
        +'<b style="font-size:13px">'+crmEsc(sr.party_name||sr.party)+'</b>'
        +(sr.count>1?'<span style="font-size:11px;color:var(--muted)">листів: '+sr.count+'</span>':'')
        +'<span style="font-size:11px;color:var(--muted)">'+crmDateTime(sr.last_seen)+'</span>'
        +'</div>'
        +(sr.subject?'<div style="font-size:12.5px;margin:4px 0 2px;word-break:break-word">'+crmEsc(sr.subject)+'</div>':'')
        +(sr.preview?'<div style="font-size:12px;color:var(--muted);margin:2px 0;white-space:pre-wrap;word-break:break-word">'+crmEsc(sr.preview)+'</div>':'')
        +'<div style="font-size:11.5px;color:var(--warn);margin:4px 0 8px">Чому чекає: '+crmEsc(sr.reason||'адреси угоди в темі немає')+'</div>'
        /* ⭐⭐⭐ 618: ЧИЙ ЦЕ ЛИСТ. Одне рядком: або ім’я й ЗВІДКИ воно
           відоме, або чесне «нічий» із кнопкою. Порожнє поле тут було б
           гірше за відмову: людина не знала б, чекати йй чи діяти. */
        +(sr.owner
            ? '<div style="font-size:11.5px;color:var(--muted);margin:2px 0 8px">Чий це лист: <b style="color:var(--txt)">'+crmEsc(sr.owner_name||sr.owner)+'</b> — '+crmEsc(sr.owner_why||'')+'</div>'
            : '<div style="font-size:11.5px;color:var(--warn);margin:2px 0 8px">Чий це лист: <b>нічий</b> — '+crmEsc(sr.owner_why||'')+'</div>')
        +'<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">'
        +'<select id="sp_deal_'+q+'" style="padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--txt);max-width:320px">'+opts+'</select>'
        +'<button class="crmtab on" style="min-height:32px" onclick="crmSpreadAssign('+q+')">Рознести</button>'
        +'<button class="crmtab" style="min-height:32px" onclick="crmSpreadDrop('+q+')">Не про угоди</button>'
        /* ⭐ 618: кнопки «чий» стоять ТІЛЬКИ там, де питання справді відкрите
           (`owner_ask`). Там, де платформа вже знає власника, кнопка була б
           запрошенням переписати чужого клієнта між іншим. */
        +((sr.owner_ask&&crmBaseState.me)
            ? '<button class="crmtab" style="min-height:32px" onclick="crmSpreadOwner('+q+',\''+crmEsc(crmBaseState.me)+'\')">Це мій лист</button>' : '')
        +((sr.owner_candidates||[]).map(function(cid,ci){
            return '<button class="crmtab" style="min-height:32px" onclick="crmSpreadOwner('+q+',\''+crmEsc(cid)+'\')">Це лист '+crmEsc((sr.owner_candidate_names||[])[ci]||cid)+'</button>';
          }).join(''))
        +'</div></div>');
    }
    h.push('<div style="height:10px"></div>');
  }

  /* Сама база */
  var c=st.counts||{};
  h.push('<div style="font-weight:700;font-size:13px;margin:6px 0 8px">Клієнтська база <span style="color:var(--muted);font-weight:600">'+(c.all||0)+'</span></div>');
  /* ⭐ КРОК B5: людей у базі стало більше, ніж клієнтів. За замовчуванням
     перелік показує те саме, що й до 15.08, а контактні особи — окремою вкладкою
     (рішення Андрія 15.08). */
  /* ⭐ D3: СТАН — окреме питання від фільтра. «Хто це» (компанія, постачальник)
     і «чи працюємо ми з ним зараз» — різні речі, тому й перемикачі різні:
     інакше «архівні постачальники» не поставились би разом. */
  h.push('<div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap;align-items:center">'
    +'<button class="crmtab'+((st.state||'live')==='live'?' on':'')+'" onclick="crmBaseTab(\'live\')">У роботі <span style="color:var(--muted)">'+(c.live||0)+'</span></button>'
    +'<button class="crmtab'+((st.state||'live')==='archived'?' on':'')+'" onclick="crmBaseTab(\'archived\')">Архів <span style="color:var(--muted)">'+(c.archived||0)+'</span></button>'
    +'</div>');
  var fl=[['all','Усі',(c.all||0)-(c.contact||0)],['contact','Контактні особи',c.contact||0],['person','Фізичні особи',0],['company','Компанії',0],['supplier','Постачальники',c.supplier||0]];
  h.push('<div style="display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap;align-items:center">');
  for(var f=0;f<fl.length;f++){
    h.push('<button class="crmtab'+(st.filter===fl[f][0]?' on':'')+'" onclick="crmBaseFilter(\''+fl[f][0]+'\')">'+fl[f][1]+'</button>');
  }
  /* ⭐ D3: «КЛІЄНТИ МЕНЕДЖЕРА X» (слово Андрія 16.08). Рахується РІВНО по
     звʼязку «хто веде» (правило D1), а не по тому, чиї в клієнта угоди.
     ⛒ ЗВІЛЬНЕНІ ТУТ Є — і це головний сценарій напряму: людина пішла, і треба
     знайти всіх її клієнтів, щоб передати іншому. */
  var mo=((st.search||{}).manager_options)||[];
  if(mo.length){
    var mopts='<option value="">хто веде: усі</option>';
    for(var mi=0;mi<mo.length;mi++){
      mopts+='<option value="'+crmEsc(mo[mi].id)+'"'+((st.manager===mo[mi].id)?' selected':'')+'>'
        +crmEsc(mo[mi].name)+(mo[mi].dismissed?' (звільнений)':'')+'</option>';
    }
    h.push('<select id="crmBaseMgr" aria-label="Показати клієнтів обраного менеджера" onchange="crmBaseManager(this.value)"'
      +' style="padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--txt);font-size:12.5px;max-width:220px">'+mopts+'</select>');
  }
  /* ⭐ Клієнт народжується не лише з листа: на зустрічі, у телефонній розмові.
     Контакт, який не має як потрапити в базу, живе в чиїйсь голові, а не в активі. */
  h.push('<button class="crmtab on" style="margin-left:auto" onclick="crmPartyNewForm()">+ Додати контрагента</button>');
  h.push('</div>');
  h.push('<div id="crmPartyNew" style="display:none;border:1px solid var(--line);border-radius:10px;padding:12px;margin-bottom:12px;background:var(--panel2)"></div>');
  /* ⭐ ПОШУК І ПОДАННЯ (крок D2). Поле шукає на СЕРВЕРІ — по назві, ЄДРПОУ,
     пошті, телефону, номеру угоди і номеру картки. */
  h.push('<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px">'
    +'<input id="crmBaseQ" type="search" placeholder="Назва, ЄДРПОУ, пошта, телефон, номер угоди (d0014) або картки (p0020)" aria-label="Пошук по клієнтській базі"'
    +' onkeydown="if(event.key===\'Enter\'){event.preventDefault();crmBaseFind();}"'
    +' style="flex:1;min-width:240px;padding:8px 10px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--txt);font-size:13px">'
    +'<button class="crmtab on" onclick="crmBaseFind()">Знайти</button>'
    +(st.q?'<button class="crmtab" onclick="crmBaseClear()">Очистити</button>':'')
    +'<span style="display:inline-block;width:1px;height:22px;background:var(--line)"></span>'
    +'<button class="crmtab'+(st.mode==='list'?'':' on')+'" onclick="crmBaseMode(\'tiles\')" aria-label="Показати плиткою">▦ Плитка</button>'
    +'<button class="crmtab'+(st.mode==='list'?' on':'')+'" onclick="crmBaseMode(\'list\')" aria-label="Показати списком">▤ Список</button>'
    +'</div>');

  /* ⭐ D3: підсумок минулої групової дії і панель поточного вибору стоять НАД
     переліком — там, куди людина дивиться, коли тисне галочки. */
  h.push(crmBulkResultHtml());
  h.push(crmBulkBarHtml());

  var sr=st.search;
  if(!sr){
    h.push('<div style="color:var(--muted);font-size:12.5px;padding:8px 0">Читаю базу…</div>');
  } else if(sr.error){
    /* ⛒ НАША КУХНЯ НЕ ЇДЕ В ТЕКСТ ЛЮДИНИ. Голе «not_found» — це слово коду;
       людині потрібне слово про те, що робити. Решта відмов приходить із
       сервера вже людською мовою («Невідомий фільтр «…»»). */
    h.push('<div style="color:var(--bad);font-size:12.5px;border:1px solid var(--line);border-radius:10px;padding:12px">'
      +(sr.error==='not_found'
        ? 'Пошук недоступний: сторінка новіша за програму. Онови сторінку (Ctrl+F5), а якщо не допомогло — перезапусти SensFlow.'
        : crmEsc(sr.error))+'</div>');
  } else {
    var rows=sr.rows||[], found=sr.found||0, page=sr.page||1, pages=sr.pages||1;
    /* 🩸 МОВЧАЗНЕ ОБРІЗАННЯ СПИСКУ — У ПЕРЕЛІКУ «ЩО ВБИВАЄ ПРОДУКТ». Тому
       платформа щоразу КАЖЕ, скільки знайшла всього і скільки показує зараз. */
    h.push('<div style="font-size:12px;color:var(--muted);margin-bottom:8px">'
      +(st.q?('Знайдено <b style="color:var(--txt)">'+found+'</b> за запитом «'+crmEsc(st.q)+'»')
            :('У базі <b style="color:var(--txt)">'+found+'</b>'))
      +(pages>1?(' · показано '+rows.length+' (сторінка '+page+' з '+pages+')'):'')
      +'</div>');
    if(!rows.length){
      h.push(st.q
        ? '<div style="color:var(--muted);font-size:12.5px;border:1px dashed var(--line);border-radius:10px;padding:12px">Нічого не знайшлось. Шукаю за назвою, ЄДРПОУ, поштою, телефоном, номером угоди (d0014) і номером картки (p0020) — цифри від трьох знаків.</div>'
        : '<div style="color:var(--muted);font-size:12.5px;border:1px dashed var(--line);border-radius:10px;padding:12px">Тут поки порожньо. Контрагенти зʼявляються звідси: з черги «Не оброблені» кнопкою «У базу» або з наявних карток Сервіс-центру.</div>');
    } else if(st.mode==='list'){
      h.push(crmBaseListHtml(rows));
    } else {
      h.push('<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:10px">');
      for(var j=0;j<rows.length;j++){
        var pr=rows[j], hs=pr.handles||{};
        var mails=(hs.email||[]).join(', '), tg=(hs.telegram_user||[]).concat(hs.telegram_id||[]).join(', ');
        var rls=(pr.role_names||[]).join(', ');
        var mg=pr.manager||null;
        h.push('<div class="crmpartycard" role="button" tabindex="0" title="Відкрити картку контрагента"'
          +' onclick="crmOpenParty(\''+crmJsq(pr.id)+'\')"'
          +' onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();crmOpenParty(\''+crmJsq(pr.id)+'\');}"'
          +' style="border:1px solid var(--line);border-radius:10px;padding:10px 12px;background:var(--panel2);cursor:pointer">'
          /* ⛒ D3: вибір мусить бути ОДНАКОВО доступним у плитці й у списку —
             інакше «галочки працюють, але не тут» читається як поломка. */
          +'<div style="display:flex;gap:8px;align-items:center">'
          +'<input type="checkbox" aria-label="Вибрати «'+crmEsc(pr.name)+'»"'
          +(crmSelOn(pr.id)?' checked':'')+(st.selAll?' disabled':'')
          +' onclick="event.stopPropagation();crmSelToggle(\''+crmJsq(pr.id)+'\')" style="cursor:pointer">'
          +'<div style="font-size:11px;color:var(--muted)">'+crmEsc(pr.id)+' · '+crmEsc(pr.kind_name||'')+'</div>'
          +'</div>'
          +'<div style="font-weight:700;font-size:13px;margin:2px 0 4px">'+crmEsc(pr.name)+'</div>'
          +'<div style="font-size:12px;color:var(--muted)">'+crmEsc(rls)+'</div>'
          +(mg?'<div style="font-size:12px;margin-top:4px">веде: '+crmEsc(mg.name||mg.id)+(mg.dismissed?' <span style="color:var(--warn)">(звільнений)</span>':'')+'</div>':'')
          +(mails?'<div style="font-size:12px;margin-top:4px">'+crmEsc(mails)+'</div>':'')
          +(tg?'<div style="font-size:12px;color:var(--muted)">телеграм: '+crmEsc(tg)+'</div>':'')
          +(CRM_KITCHEN?(pr.customer?'<div style="font-size:11.5px;color:var(--muted);margin-top:6px">картка: '+crmEsc(pr.customer)+'</div>':'<div style="font-size:11.5px;color:var(--muted);margin-top:6px">картки ще немає</div>'):'')
          +'</div>');
      }
      h.push('</div>');
    }
    h.push(crmBasePagerHtml(sr));
  }
  document.getElementById('crmBase').innerHTML=h.join('');
  /* ⛒ ПОЛЕ ПОШУКУ ПЕРЕЖИВАЄ ПЕРЕМАЛЬОВУВАННЯ. Розділ малюється цілим шматком
     розмітки, тому після кожного пошуку поле народжується заново — і без цих
     трьох рядків курсор із нього тікав би на кожній букві. */
  var qi=document.getElementById('crmBaseQ');
  if(qi){
    qi.value=st.q||'';
    if(st.qFocus){ try{ qi.focus(); qi.setSelectionRange(qi.value.length,qi.value.length); }catch(e){} }
  }
  var b=document.getElementById('crmBaseCnt'); if(b) b.textContent=(c.all||0)?String(c.all):'';
}
/* ⭐ СПИСОК (крок D2). Стовпці — вибір Андрія 15.08.2026: назва ·
   відповідальний · роль · дата останнього контакту. Контактів і числа угод він
   НЕ взяв — не додаємо «про запас». */
function crmBaseListHtml(rows){
  var th='text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);font-size:11.5px;color:var(--muted);font-weight:600';
  var td='padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top';
  var sr=crmBaseState.search||{}, sc=sr.sort||'', sd=sr.dir||'';
  /* ⛒ Стрілка стоїть ЛИШЕ на тому стовпці, за яким справді відсортовано, і
     показує напрям, який ПРИЇХАВ ІЗ СЕРВЕРА, а не той, що ми загадали. */
  function hcell(col,label,extra){
    var on=(sc===col), mark=on?(sd==='asc'?' ▲':' ▼'):'';
    return '<th style="'+th+(on?';color:var(--accent)':'')+'">'
      +'<span role="button" tabindex="0" style="cursor:pointer;user-select:none"'
      +' aria-label="Сортувати за: '+label+'"'
      +' onclick="crmBaseSort(\''+col+'\')"'
      +' onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();crmBaseSort(\''+col+'\');}"'
      +(extra||'')+'>'+label+mark+'</span></th>';
  }
  /* ⭐ D3: ГАЛОЧКА В ЗАГОЛОВКУ БЕРЕ РІВНО ЦЮ СТОРІНКУ — і так і підписана.
     «Вибрати все за фільтром» — окрема кнопка з окремим числом, бо це інша
     дія над іншою кількістю карток. */
  var pageOn=rows.length>0;
  for(var z=0;z<rows.length;z++){ if(!crmSelOn(rows[z].id)) pageOn=false; }
  var h=['<div style="overflow-x:auto;border:1px solid var(--line);border-radius:10px">'
    +'<table style="width:100%;border-collapse:collapse;font-size:12.5px">'
    +'<thead><tr style="background:var(--panel2)">'
    +'<th style="'+th+';width:34px">'
      +'<input type="checkbox" aria-label="Вибрати всі картки на цій сторінці"'
      +(pageOn?' checked':'')+(crmBaseState.selAll?' disabled':'')
      +' onclick="crmSelPage(this.checked)" style="cursor:pointer">'
      +'</th>'
    +hcell('name','Назва')
    +hcell('manager','Відповідальний')
    +hcell('role','Роль')
    +hcell('contact','Останній контакт',' title="Останнє спілкування: вхідне, вихідне, дзвінок або запис «Комунікація». Робота платформи — збірка, стадія, надіслане оновлення — сюди не рахується."')
    +'</tr></thead><tbody>'];
  for(var i=0;i<rows.length;i++){
    var r=rows[i], mg=r.manager||null, lc=r.last_contact||{};
    h.push('<tr role="button" tabindex="0" title="Відкрити картку контрагента" style="cursor:pointer"'
      +' onclick="crmOpenParty(\''+crmJsq(r.id)+'\')"'
      +' onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();crmOpenParty(\''+crmJsq(r.id)+'\');}">'
      /* ⛒ ГАЛОЧКА НЕ ВІДКРИВАЄ КАРТКУ. Без `stopPropagation` кожен клік по
         вибору відкривав би вікно контрагента — і вибрати десяток стало б
         неможливо.
         🩸 СТОРОЖ ТУТ РІВНО ОДИН — на самій галочці. Другий (на комірці)
         виглядав би надійніше, а насправді робив би обох невидимими: зняття
         будь-якого поодинці нічого не ламало б, і мутація лишалась зеленою.
         Урок 12.08 у чистому вигляді: захист, що тримається на сусідньому
         захисті, зникає разом із ним і нічого не тримає сам. */
      +'<td style="'+td+'">'
        +'<input type="checkbox" aria-label="Вибрати «'+crmEsc(r.name)+'»"'
        +(crmSelOn(r.id)?' checked':'')+(crmBaseState.selAll?' disabled':'')
        +' onclick="event.stopPropagation();crmSelToggle(\''+crmJsq(r.id)+'\')" style="cursor:pointer"></td>'
      +'<td style="'+td+'"><b>'+crmEsc(r.name)+'</b>'
        +'<div style="font-size:11px;color:var(--muted)">'+crmEsc(r.id)+' · '+crmEsc(r.kind_name||'')
        +(r.match_name?(' · знайдено за: '+crmEsc(r.match_name)):'')+'</div></td>'
      /* ⛒ «—» означає РІВНО «ніхто не веде», а не «не знаю»: порожнє місце в
         цьому стовпці — це і є те, заради чого починався напрям D. */
      +'<td style="'+td+'">'+(mg?(crmEsc(mg.name||mg.id)
        +(mg.dismissed?'<div style="font-size:11px;color:var(--warn)">звільнений</div>':'')
        +(mg.gone?'<div style="font-size:11px;color:var(--warn)">немає в оргструктурі</div>':'')
        ):'<span style="color:var(--muted)">—</span>')+'</td>'
      +'<td style="'+td+'">'+((r.role_names||[]).length?crmEsc((r.role_names||[]).join(', ')):'<span style="color:var(--muted)">—</span>')+'</td>'
      +'<td style="'+td+'">'+(lc.date?(crmDate(lc.date)
        +(lc.name?('<div style="font-size:11px;color:var(--muted)">'+crmEsc(lc.name)+'</div>'):''))
        :'<span style="color:var(--muted)">—</span>')+'</td>'
      +'</tr>');
  }
  h.push('</tbody></table></div>');
  return h.join('');
}
/* Сторінки. ⛒ Кнопки їдуть навіть на одній сторінці бути не мусять — але число
   «знайдено» стоїть вище ЗАВЖДИ, і в цьому вся суть: скільки є насправді. */
function crmBasePagerHtml(sr){
  var page=sr.page||1, pages=sr.pages||1;
  if(pages<2) return '';
  return '<div style="display:flex;gap:8px;align-items:center;justify-content:center;margin-top:12px;flex-wrap:wrap">'
    +'<button class="crmtab" onclick="crmBasePage('+(page-1)+')"'+(page<=1?' disabled style="opacity:.45;cursor:default"':'')+' aria-label="Попередня сторінка">‹ Назад</button>'
    +'<span style="font-size:12px;color:var(--muted)">сторінка '+page+' з '+pages+'</span>'
    +'<button class="crmtab" onclick="crmBasePage('+(page+1)+')"'+(page>=pages?' disabled style="opacity:.45;cursor:default"':'')+' aria-label="Наступна сторінка">Далі ›</button>'
    +'</div>';
}
async function crmPromote(i){
  var it=crmBaseState.inbox[i]; if(!it) return;
  var name=(document.getElementById('pb_name_'+i)||{}).value||'';
  var kind=(document.getElementById('pb_kind_'+i)||{}).value||'';
  var role=(document.getElementById('pb_role_'+i)||{}).value||'client';
  crmBaseMsg('Кладу в базу…');
  try{
    var r=await fetch('/api/crm/promote',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({channel:it.channel,identity:it.identity,name:name,kind:kind,roles:[role]})});
    var d=await r.json();
    if(!r.ok||d.error){ crmBaseMsg(d.error||'Не вийшло покласти в базу.',true); return; }
    crmBaseMsg('У базі: '+((d.result&&d.result.party&&d.result.party.name)||name));
    await loadBase();
  }catch(e){ crmBaseMsg('Не вийшло покласти в базу: '+(e.message||e),true); }
}
async function crmInboxDrop(i){
  var it=crmBaseState.inbox[i]; if(!it) return;
  if(!confirm('Прибрати «'+it.identity+'» з черги? Контрагент у базі не зʼявиться, а наступне звернення з цієї адреси знову стане в чергу.')) return;
  try{
    await fetch('/api/crm/inbox_clear',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({channel:it.channel,identity:it.identity})});
    await loadBase();
  }catch(e){ crmBaseMsg('Не вийшло прибрати: '+(e.message||e),true); }
}


/* ── ⭐ ДВЕРІ КЛІЄНТСЬКОЇ БАЗИ (13.08.2026) ──────────────────────────────────
   КОРІНЬ. Розділ «Клієнти» (зміна 167) вийшов ВІТРИНОЮ БЕЗ ДВЕРЕЙ: контрагент
   малювався прямокутником, який не відкривався, не правився і не видалявся, а
   завести його руками не було чим. Довідник, у який можна лише дивитись, — це
   не актив компанії, а картинка активу.
   ⛒ ОДИН ПИСАР КАРТКИ. Вміст угоди (профіль, контакти, ліцензія, історія,
   досьє, нотатки) малює `openCrmCard` — і другого такого малювальника ми не
   заводимо. Картка контрагента ДОКЛЕЮЄ свій блок довідника згори до того, що
   вже намалював він. Тому будь-яка майбутня правка картки угоди зʼявиться тут
   сама, без «а ще не забудь оновити в базі». */
function crmPartyById(pid){
  var ps=crmBaseState.parties||[];
  for(var i=0;i<ps.length;i++){ if(ps[i].id===pid) return ps[i]; }
  return null;
}
/* Блок довідника: хто це, як звати, за якими адресами впізнаємо. */
function crmPartyDirHtml(pr){
  /* 🩸 15.08.2026 (знайдено ЖИВИМ прогоном B5). Тут лежав ВЛАСНИЙ список ролей —
     і картка Іллі показала «жодної ролі», бо роль «контактна особа» цей екран не
     знав. Екран, який тримає свій словник, розходиться з платформою назавтра.
     Тепер словник приїжджає з платформи (`/api/parties` → `roles`/`kinds`), а
     зашитий лишається запасним на випадок, якщо база ще не прочиталась. */
  var kinds=(crmBaseState&&crmBaseState.kinds&&Object.keys(crmBaseState.kinds).length)?crmBaseState.kinds:{'':'не вказано','person':'фізична особа','company':'компанія'};
  var roles=(crmBaseState&&crmBaseState.roles&&Object.keys(crmBaseState.roles).length)?crmBaseState.roles:{'client':'клієнт','supplier':'постачальник','partner':'партнер'};
  var hs=pr.handles||{}, rows=[];
  /* 🩸 28.08.2026, зміна 247. ТУТ ЛЕЖАВ ДРУГИЙ СЛОВНИК РУЧОК - копія
     `HANDLE_NAMES`/`HANDLE_KINDS` з `parties.py`. Рівно та сама дірка, яку
     15.08 вже знайшли на ролях: нова ручка, додана в платформі, мовчки не
     зʼявилась би на екрані, і людина бачила б неповну картку, не знаючи цього.
     Тепер словник і порядок приїжджають З ПЛАТФОРМИ (`party_card` →
     `handles_signal`), а зашитий лишається ЗАПАСНИМ на випадок, якщо картка
     ще не прочиталась. */
  var sig=(crmCard&&crmCard.rel&&crmCard.rel.handles_signal)||null;
  var HN=(sig&&sig.names&&Object.keys(sig.names).length)?sig.names
        :{email:'пошта',telegram_id:'телеграм',telegram_user:'телеграм-імʼя',phone:'телефон',edrpou:'ЄДРПОУ'};
  var order=(sig&&sig.order&&sig.order.length)?sig.order
        :['email','telegram_id','telegram_user','phone','edrpou'];
  for(var o=0;o<order.length;o++){
    var k=order[o], vals=hs[k]||[];
    for(var v=0;v<vals.length;v++){
      rows.push('<div class="crmrow"><span style="color:var(--muted)">'+HN[k]+'</span>'
        +'<span style="margin-left:auto;display:flex;gap:8px;align-items:center">'+crmEsc(vals[v])
        +'<button class="crmtab" style="min-height:26px;padding:2px 8px" title="Відвʼязати цю адресу від контрагента" onclick="crmPartyHandle(\''+crmJsq(pr.id)+'\',\''+k+'\',\''+crmJsq(vals[v])+'\',false)">✕</button>'
        +'</span></div>');
    }
  }
  if(!rows.length) rows.push('<div style="font-size:12px;color:var(--muted)">Жодної адреси. За такими контрагентами вхідне не впізнається.</div>');
  var ropts='';
  var rk=Object.keys(roles);
  for(var r=0;r<rk.length;r++){
    var on=(pr.roles||[]).indexOf(rk[r])>=0;
    ropts+='<label style="font-size:12px;display:inline-flex;gap:5px;align-items:center;margin-right:12px"><input type="checkbox" id="pd_role_'+rk[r]+'"'+(on?' checked':'')+'> '+roles[rk[r]]+'</label>';
  }
  var kopts='';
  var kk=Object.keys(kinds);
  for(var q=0;q<kk.length;q++){ kopts+='<option value="'+kk[q]+'"'+((pr.kind||'')===kk[q]?' selected':'')+'>'+kinds[kk[q]]+'</option>'; }
  return '<div class="crmsec"><h4>Довідник контрагента</h4>'
    +'<div class="crmrow"><span style="color:var(--muted)">Номер</span><span style="margin-left:auto"><b>'+crmEsc(pr.id)+'</b> · не міняється ніколи</span></div>'
    +'<div style="margin:8px 0 6px"><label style="font-size:11px;color:var(--muted)">Назва<br>'
    +'<input id="pd_name" type="text" value="'+crmEsc(pr.name||'')+'" style="width:100%;padding:7px 9px;border-radius:8px;border:1px solid var(--line);background:var(--panel2);color:var(--txt)"></label></div>'
    +'<div style="margin:6px 0"><label style="font-size:11px;color:var(--muted)">Тип<br>'
    +'<select id="pd_kind" style="padding:7px 9px;border-radius:8px;border:1px solid var(--line);background:var(--panel2);color:var(--txt)">'+kopts+'</select></label></div>'
    +'<div style="margin:8px 0 4px;font-size:11px;color:var(--muted)">Ролі (їх може бути кілька)</div><div style="margin-bottom:8px">'+ropts+'</div>'
    +'<div style="margin:10px 0 4px;font-size:11px;color:var(--muted)">За якими адресами впізнаємо'
      /* ⭐ ДУБЛЬ - ЦЕ НЕ СМІТТЯ, А СИГНАЛ (розбір CareerSwift, 27.08.2026).
         Число рахує ПЛАТФОРМА тими самими ручками, якими впізнає `find()`.
         Екран нічого не рахує сам - інакше телеграм показав би своє число. */
      +(sig?'<span style="margin-left:8px;color:var(--txt)"><b>'+sig.known+'</b> з '+sig.total+'</span>':'')
      +'</div>'
    +(sig&&sig.known>=2
        ? '<div style="margin:0 0 6px;font-size:11.5px;color:var(--muted)">Ця картка зійшлась за '
          +sig.known+' ручками — вхідне від нього впізнається '+sig.known+' різними дорогами.</div>'
        : '')
    +rows.join('')
    +'<div style="display:flex;gap:6px;margin-top:8px;flex-wrap:wrap;align-items:center">'
    +'<select id="pd_hk" style="padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--panel2);color:var(--txt)"><option value="email">пошта</option><option value="telegram_id">телеграм</option><option value="telegram_user">телеграм-імʼя</option><option value="phone">телефон</option><option value="edrpou">ЄДРПОУ</option></select>'
    +'<input id="pd_hv" type="text" placeholder="значення" style="flex:1;min-width:140px;padding:6px 8px;border-radius:8px;border:1px solid var(--line);background:var(--panel2);color:var(--txt)">'
    +'<button class="crmtab" onclick="crmPartyHandle(\''+crmJsq(pr.id)+'\',\'\',\'\',true)">Додати адресу</button>'
    +'</div>'
    +'<div style="margin:6px 0 2px"><label style="font-size:11px;color:var(--muted)">Примітка<br>'
    +'<input id="pd_note" type="text" value="'+crmEsc(pr.note||'')+'" style="width:100%;padding:7px 9px;border-radius:8px;border:1px solid var(--line);background:var(--panel2);color:var(--txt)"></label></div>'
    +'<div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">'
    +'<button class="crmbtn accent" style="max-width:200px" onclick="crmPartySave(\''+crmJsq(pr.id)+'\')">Зберегти</button>'
    +'<button class="crmbtn warn" style="max-width:220px" onclick="crmPartyDelete(\''+crmJsq(pr.id)+'\',false)">Видалити з бази…</button>'
    +'</div>'
    +'<div id="pd_msg" role="status" aria-live="polite" style="font-size:12px;color:var(--muted);margin-top:8px;min-height:14px"></div>'
    +'</div>';
}
/* ── ⭐⭐⭐ ІСТОРІЯ ВЗАЄМОВІДНОСИН (крок B3, 14.08.2026) ──────────────────────
   Пряме слово Андрія 14.08: «будь-яка картка контакта має розділ "Історія
   взаємовідносин з клієнтом"… і головне, гортаючи історію, ми повинні мати
   змогу по назві задачі або по назві угоди в один клік перейти у відповідну
   картку». Це вимога до НАВІГАЦІЇ, а не до даних.
   ⛒ ДВІ ЧАСТИНИ, І ВОНИ НЕ ЗМІШУЮТЬСЯ: «Повʼязані картки» — це СТАН (реєстр
   звʼязків, картка живе й міняє стадію), «Стрічка подій» — це ІСТОРІЯ (подія
   незмінна назавжди). Для людини — один розділ; для платформи — дві відповіді.
   ⛒ ЕКРАН НІЧОГО НЕ СКЛАДАЄ САМ: і речення про звʼязок, і адресу переходу
   рахує сервер (`relations` + `entity.screen`). Інакше картка й телеграм
   назвали б те саме різними словами, а перший забутий екран показав би назву,
   яка нікуди не веде. */
/* ══════════════════════════════════════════════════════════════════════════
   ⭐⭐⭐ C3 — ОДИН РУШІЙ КАРТКИ (15.08.2026). Склад картки більше не живе тут.
   Раніше розділи склеювались один за одним прямо в коді екрана; «вид картки для
   відділу продажів» довелося б вирізати з HTML. Тепер сервер (`card_layout`)
   каже, ЩО і В ЯКОМУ ПОРЯДКУ стоїть у картці, а екран лише МАЛЮЄ оголошене.

   ⛒ СТЕЛЯ ЕКРАНА ОГОЛОШЕНА ВГОЛОС — `CARD_BLOCK_DRAW`. Сервер може оголосити
   блок, якого екран не вміє малювати: тоді людина побачила б порожнє місце й
   вирішила, що даних немає (це наш найдорожчий клас — «зелена брехня поверхом
   нижче»). Тому невідомий блок КАЖЕ ПРО СЕБЕ червоним рядком, а чек
   `card_engine_test.py` звіряє два переліки ще до запуску.
   ══════════════════════════════════════════════════════════════════════════ */
/* ⭐ C1 (15.08.2026): у стані картки зʼявилась УГОДА (`d`) і ВИД сутності
   (`kind`). Один рушій малює обидві картки — різниця лише в тому, чиї дані
   під ним лежать. */
var crmCard={cust:'',pid:'',did:'',kind:'party',ref:'',c:null,d:null,pr:null,rel:null,tab:'',flt:{},rows:[],pins:{}};

var CARD_BLOCK_DRAW={
  party_dir:   function(x){ return x.pr?crmPartyDirHtml(x.pr):''; },
  manager:     function(x){ return crmManagerHtml(x); },
  comms:       function(x){ return x.c?crmCommsHub(x.c):''; },
  deals:       function(x){ return crmDealsHtml(x); },
  license:     function(x){ return x.c?crmLicenseHtml(x.c):''; },
  systems:     function(x){ return x.c?crmSystemsHtml(x.c):''; },
  profile:     function(x){ return x.c?crmProfileHtml(x.c):''; },
  contacts:    function(x){ return x.c?crmContactsHtml(x.c):''; },
  dossier:     function(x){ return x.c?crmDossierHtml(x.c):''; },
  notes:       function(x){ return x.c?crmNotesHtml(x.c):''; },
  history_add: function(x){ return x.c?crmHistAddHtml(x.c):''; },
  related:     function(x){ return crmRelatedHtml(x.rel); },
  /* картка УГОДИ */
  deal_head:    function(x){ return x.d?crmDealHeadHtml(x.d):''; },
  deal_mail:    function(x){ return x.d?crmDealMailHtml(x.d):''; },
  deal_amount:  function(x){ return x.d?crmDealAmountHtml(x.d):''; },
  deal_people:  function(x){ return x.d?crmDealPeopleHtml(x.d):''; },
  /* ⛒ 443: блок ліцензії -- НАШ сервіс-центр, не товар. */
  deal_license: function(x){ return (CRM_KITCHEN && x.d)?crmDealLicenseHtml(x.d):''; },
  deal_note:    function(x){ return x.d?crmDealNoteHtml(x.d):''; },
  deal_archive: function(x){ return x.d?crmDealArchiveHtml(x.d):''; },
  deal_next:    function(x){ return x.d?crmDealNextHtml(x.d):''; },
  feed:        function(x){ return crmFeedHtml(); },
  /* ⭐⭐⭐ 526: ВЛАСНІ ПОЛЯ КОМПАНІЇ — окрема вкладка картки. */
  own_fields:  function(x){ return crmOwnFieldsHtml(x); },
  /* ⭐⭐⭐ 536: ПОЗИЦІЇ УГОДИ — окрема вкладка картки. */
  deal_items:  function(x){ return crmDealItemsHtml(x); },
  /* ⭐⭐⭐ 585: ДОКУМЕНТИ УГОДИ — окрема вкладка картки. */
  deal_docs:   function(x){ return crmDealDocsHtml(x); }
};

/* ⭐⭐⭐ ПОЗИЦІЇ УГОДИ (зміна 536, 07.09.2026).

   ⛒ МАЛЮЄМО ЗНІМОК, А НЕ БАЗУ. У рядку стоїть назва, артикул і одиниця ТАКІ,
   ЯКИМИ вони були на момент домовленості: сьогоднішня картка товару сюди не
   заглядає — інакше вчорашня домовленість переписалась би завтрашньою ціною.

   ⛔ ЖОДНОГО «РАЗОМ». Сума угоди вводиться руками (слово Андрія 02.09.2026):
   знижки й акції втягнули б нас у бухгалтерію кожної окремої компанії. Тому
   тут немає ані множення, ані підсумку — навіть «довідкового». */
var CRM_GOODS = null;

function crmDealItemRow(it){
  var s = it.snap || {};
  var name = crmEsc(s.name || 'без назви')
    + (s.sku ? (' <span style="opacity:.6">арт. ' + crmEsc(s.sku) + '</span>') : '');
  var unit = s.unit ? (' ' + crmEsc(s.unit)) : '';
  var cur = s.currency ? (' ' + crmEsc(s.currency)) : '';
  return '<tr>'
    + '<td style="padding:6px 8px;border-bottom:1px solid var(--line)">' + name
    + (it.stage ? ('<div style="font-size:11px;opacity:.6">домовились на стадії: '
                   + crmEsc(it.stage) + '</div>') : '')
    + '</td>'
    + '<td style="padding:6px 8px;border-bottom:1px solid var(--line);width:110px">'
    + '<input id="qty_' + crmEsc(it.id) + '" style="' + CRM_INP + '" value="'
    + crmEsc(it.qty || '') + '" onchange="crmItemSave(\'' + crmEsc(it.id) + '\')">'
    + '<div style="font-size:11px;opacity:.6">кількість' + unit + '</div></td>'
    + '<td style="padding:6px 8px;border-bottom:1px solid var(--line);width:130px">'
    + '<input id="prc_' + crmEsc(it.id) + '" style="' + CRM_INP + '" value="'
    + crmEsc(it.price || '') + '" onchange="crmItemSave(\'' + crmEsc(it.id) + '\')">'
    + '<div style="font-size:11px;opacity:.6">ціна домовленості' + cur + '</div></td>'
    + '<td style="padding:6px 8px;border-bottom:1px solid var(--line);width:110px">'
    + '<button class="crmbtn" onclick="crmItemRemove(\'' + crmEsc(it.id)
    + '\')">Прибрати</button></td></tr>';
}

function crmDealItemsHtml(x){
  if(!x.d) return '';
  var rows = (x.rel && x.rel.deal_items) || [];
  var body = rows.length
    ? ('<table style="width:100%;border-collapse:collapse;font-size:12.5px">'
       + rows.map(crmDealItemRow).join('') + '</table>')
    : '<div style="opacity:.6;font-size:12.5px">Позицій ще немає. Оберіть товар '
      + 'або послугу зі своєї бази — назва й артикул запамʼятаються такими, '
      + 'якими вони є зараз.</div>';
  var add = '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;'
    + 'margin-top:12px">'
    + '<div style="flex:2 1 220px"><div style="font-size:11px;opacity:.6;'
    + 'margin-bottom:3px">що додаємо</div>'
    + '<select id="crmItemGood" style="' + CRM_INP + '">'
    + '<option value="">— зачекайте, читаю базу —</option></select></div>'
    + '<div style="flex:0 1 100px"><div style="font-size:11px;opacity:.6;'
    + 'margin-bottom:3px">кількість</div>'
    + '<input id="crmItemQty" style="' + CRM_INP + '"></div>'
    + '<div style="flex:0 1 120px"><div style="font-size:11px;opacity:.6;'
    + 'margin-bottom:3px">ціна</div>'
    + '<input id="crmItemPrice" style="' + CRM_INP + '" '
    + 'placeholder="як у базі"></div>'
    + '<button class="crmbtn accent" onclick="crmItemAdd()">Додати</button></div>';
  setTimeout(crmGoodsFill, 0);
  return '<div class="crmsec"><h4>Позиції угоди</h4>' + body + add
    + '<div id="crmItemsMsg" style="font-size:12px;color:var(--muted);'
    + 'margin-top:8px;min-height:16px"></div>'
    + '<div style="font-size:11px;opacity:.6;margin-top:4px">Сума угоди '
    + 'вводиться руками на вкладці «Основне» — платформа її не рахує.</div>'
    + '</div>';
}

/* ⭐ Перелік товарів читаємо ОДИН раз на сеанс і беремо в того самого писаря,
   що й екран «Товари і послуги»: другий перелік поруч розійшовся б із першим. */
async function crmGoodsFill(){
  var sel = document.getElementById('crmItemGood');
  if(!sel) return;
  if(CRM_GOODS === null){
    try{
      var r = await fetch('/api/goods/list?archived=0');
      var d = await r.json();
      CRM_GOODS = (r.ok && !d.error) ? (d.goods || []) : [];
    }catch(e){ CRM_GOODS = []; }
    sel = document.getElementById('crmItemGood');
    if(!sel) return;
  }
  if(!CRM_GOODS.length){
    sel.innerHTML = '<option value="">база товарів ще порожня</option>';
    return;
  }
  sel.innerHTML = '<option value="">— оберіть зі своєї бази —</option>'
    + CRM_GOODS.map(function(g){
        return '<option value="' + crmEsc(g.id) + '">' + crmEsc(g.name)
          + (g.sku ? (' · ' + crmEsc(g.sku)) : '')
          + (g.price ? (' · ' + crmEsc(g.price)) : '') + '</option>';
      }).join('');
}

async function crmItemDoor(door, body){
  try{
    var r = await fetch('/api/crm/' + door, {method:'POST',
      headers:{'Content-Type':'application/json'}, body: JSON.stringify(body||{})});
    var d = await r.json();
    if(!r.ok || d.error){ crmItemsSay(d.error || 'Не вдалося', true); return null; }
    /* ⛒ Свіжий перелік приїхав РАЗОМ із відповіддю — другого запиту не робимо. */
    if(crmCard && crmCard.rel) crmCard.rel.deal_items = d.items || [];
    crmCardPaintLeft();
    await crmFeedFetch(true); crmFeedPaint();
    return d;
  }catch(e){ crmItemsSay('Не вдалося: ' + (e.message || e), true); return null; }
}

function crmItemVal(id){ var e = document.getElementById(id); return e ? e.value : ''; }
function crmItemsSay(t, bad){
  var m = document.getElementById('crmItemsMsg');
  if(!m) return;
  m.textContent = t || '';
  m.style.color = bad ? 'var(--bad)' : 'var(--muted)';
}

async function crmItemAdd(){
  var gid = crmItemVal('crmItemGood');
  if(!gid){ crmItemsSay('Спершу оберіть товар або послугу зі своєї бази.', true); return; }
  await crmItemDoor('deal_item_add', {deal: crmCard.did, good: gid,
                                      qty: crmItemVal('crmItemQty'),
                                      price: crmItemVal('crmItemPrice')});
}
async function crmItemSave(iid){
  await crmItemDoor('deal_item_save', {id: iid, qty: crmItemVal('qty_' + iid),
                                       price: crmItemVal('prc_' + iid)});
}
async function crmItemRemove(iid){
  await crmItemDoor('deal_item_remove', {id: iid});
}


/* ⭐⭐⭐ ДОКУМЕНТИ УГОДИ (зміна 585, 16.09.2026).

   ⛒ ЦЕ НЕ «ВКЛАДЕННЯ», А ПРАВИЛО ЗАКРИТТЯ. Слово Андрія 13.09.2026: «Жодна
   угода без договору, який причеплений до цієї угоди, не може вважатися
   успішно завершеною». Тому екран не просто показує перелік — він вголос
   каже, є договір чи немає, і що станеться без нього.

   ⛒ НОМЕР НАБИРАТИ НЕ ТРЕБА. Порожнє поле означає «видай сам»: номер
   `ДД.ММ-N` видає платформа, і двічі той самий не видасть. Руками номер
   вписують лише тоді, коли папір уже підписаний і номер у ньому стоїть.

   ⛒ ЗАВАНТАЖУВАЧ НА ПЛАТФОРМІ ОДИН (`/api/files/upload`). Спершу файл лягає
   у сховище, потім його `file_id` їде в двері документа: другого шляху для
   тих самих байтів ми не заводимо. */
function crmDocRow(doc){
  return '<tr>'
    + '<td style="padding:6px 8px;border-bottom:1px solid var(--line)">'
    + '<b>' + crmEsc(crmDocKindName(doc.kind)) + '</b>'
    + '<div style="font-size:11px;opacity:.6">№ ' + crmEsc(doc.number || '—')
    + ' від ' + crmEsc(doc.date || '—') + '</div></td>'
    + '<td style="padding:6px 8px;border-bottom:1px solid var(--line);width:130px">'
    + crmEsc(doc.amount || '') + '</td>'
    + '<td style="padding:6px 8px;border-bottom:1px solid var(--line)">'
    + (doc.file_id
       ? ('<a href="/api/files/get?id=' + encodeURIComponent(doc.file_id) + '">'
          + crmEsc(doc.file_name || 'файл') + '</a>')
       : '<span style="opacity:.6">файла немає</span>')
    + '</td>'
    + '<td style="padding:6px 8px;border-bottom:1px solid var(--line);width:110px">'
    + '<button class="crmbtn" onclick="crmDocRemove(\'' + crmJsq(doc.id)
    + '\')">Відчепити</button></td></tr>';
}

function crmDocKindName(kind){
  var kinds = (crmCard && crmCard.rel && crmCard.rel.deal_doc_kinds) || [];
  for(var i=0;i<kinds.length;i++){ if(kinds[i].id===kind) return kinds[i].name; }
  return kind || 'документ';
}

function crmDealDocsHtml(x){
  if(!x.d) return '';
  var rows = (x.rel && x.rel.deal_docs) || [];
  var kinds = (x.rel && x.rel.deal_doc_kinds) || [];
  var has = !!(x.rel && x.rel.deal_has_contract);
  /* ⛒ Стан правила — першим рядком, а не дрібним шрифтом унизу. Людина мусить
     бачити, чому стадія не переводиться, ДО того, як натисне і впреться. */
  /* ⭐ 615: ДАТА ПІДПИСАННЯ — рядком у картці, від одного писаря на сервері.
     Окремого поля, яке треба заповнювати вдруге, тут немає навмисно. */
  var signed = (x.rel && x.rel.deal_signed_at) || '';
  var signedLine = '<div style="font-size:12.5px;margin-bottom:10px">'
    + '<b>Дата підписання:</b> '
    + (signed ? crmEsc(signed)
              : '<span style="opacity:.6">немає — її дає дата підписаного '
                + 'договору</span>') + '</div>';
  var state = has
    ? '<div class="crmnote-ok" style="margin-bottom:10px">Договір причеплено — '
      + 'угоду можна переводити на «Укладення угоди», «Чекаємо оплати» і '
      + '«Активні клієнти».</div>'
    : '<div class="crmnote-err" style="margin-bottom:10px">Договору ще немає. '
      + 'Доки він не причеплений, угода не переходить на «Укладення угоди», '
      + '«Чекаємо оплати» та «Активні клієнти»: угода без договору не '
      + 'вважається успішно завершеною.</div>';
  var body = rows.length
    ? ('<table style="width:100%;border-collapse:collapse;font-size:12.5px">'
       + rows.map(crmDocRow).join('') + '</table>')
    : '<div style="opacity:.6;font-size:12.5px">Документів ще немає.</div>';
  var opts = kinds.map(function(k){
    return '<option value="' + crmEsc(k.id) + '">' + crmEsc(k.name) + '</option>';
  }).join('');
  var add = '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end;'
    + 'margin-top:12px">'
    + '<div style="flex:0 1 150px"><div style="font-size:11px;opacity:.6;'
    + 'margin-bottom:3px">що чіпляємо</div>'
    + '<select id="crmDocKind" style="' + CRM_INP + '">' + opts + '</select></div>'
    + '<div style="flex:0 1 120px"><div style="font-size:11px;opacity:.6;'
    + 'margin-bottom:3px">номер</div>'
    + '<input id="crmDocNumber" style="' + CRM_INP + '" '
    + 'placeholder="видасть платформа"></div>'
    + '<div style="flex:0 1 120px"><div style="font-size:11px;opacity:.6;'
    + 'margin-bottom:3px">дата</div>'
    + '<input id="crmDocDate" style="' + CRM_INP + '" placeholder="ДД.ММ.РРРР"></div>'
    + '<div style="flex:0 1 130px"><div style="font-size:11px;opacity:.6;'
    + 'margin-bottom:3px">сума</div>'
    + '<input id="crmDocAmount" style="' + CRM_INP + '"></div>'
    + '<div style="flex:1 1 200px"><div style="font-size:11px;opacity:.6;'
    + 'margin-bottom:3px">файл</div>'
    + '<input type="file" id="crmDocFile" style="' + CRM_INP + '"></div>'
    + '<button class="crmbtn accent" onclick="crmDocAdd()">Причепити</button></div>';
  /* ⭐⭐⭐ 615. КНОПКА КП ПЕРЕЇХАЛА В ШАПКУ КАРТКИ (`CARD_ACTION_DRAW`).
     🩸 613 поставила її сюди — і вона опинилась третьою вкладкою вглиб:
     власник відкрив картку і дії не побачив. Тут лишається тільки пояснення
     поруч із документами; сама дія одна на всю картку. */
  var kp = '<div style="font-size:11.5px;opacity:.65;margin-top:12px;'
    + 'padding-top:12px;border-top:1px solid var(--line)">Готову пропозицію '
    + 'робить кнопка «Створити КП» у шапці картки: платформа візьме ціни з '
    + 'позицій цієї угоди і поверне документ сюди ж, під своїм номером.</div>';
  return '<div class="crmsec"><h4>Документи угоди</h4>' + signedLine + state + body + add + kp
    + '<div id="crmDocsMsg" style="font-size:12px;color:var(--muted);'
    + 'margin-top:8px;min-height:16px"></div>'
    + '<div style="font-size:11px;opacity:.6;margin-top:4px">Номер лишіть '
    + 'порожнім — платформа видасть наступний за форматом ДД.ММ-N і двічі той '
    + 'самий не видасть. Вписуйте руками лише номер, який уже стоїть у '
    + 'підписаному папері.</div></div>';
}

function crmDocsSay(t, bad){
  var m = document.getElementById('crmDocsMsg');
  if(!m) return;
  m.textContent = t || '';
  m.style.color = bad ? 'var(--bad)' : 'var(--muted)';
}
function crmDocVal(id){ var e = document.getElementById(id); return e ? e.value : ''; }

async function crmDocDoor(door, body){
  try{
    var r = await fetch('/api/crm/' + door, {method:'POST',
      headers:{'Content-Type':'application/json'}, body: JSON.stringify(body||{})});
    var d = await r.json();
    /* ⛒ ВІДМОВА ПРИХОДИТЬ СЛОВАМИ. Тиха відмова = вимкнений сторож. */
    if(!r.ok || d.error){ crmDocsSay(d.message || d.error || 'Не вдалося', true); return null; }
    if(crmCard && crmCard.rel){
      crmCard.rel.deal_docs = d.docs || [];
      crmCard.rel.deal_has_contract = !!d.has_contract;
    }
    crmCardPaintLeft();
    await crmFeedFetch(true); crmFeedPaint();
    return d;
  }catch(e){ crmDocsSay('Не вдалося: ' + (e.message || e), true); return null; }
}

/* ⭐ 613. Кнопка КП. Одні двері (`deal_kp`), одна відмова — словами. */
async function crmKpPrepare(){
  var b = document.getElementById('crmKpBtn');
  if(b){ b.disabled = true; b.textContent = 'Готую КП…'; }
  crmDocsSay('Готую комерційну пропозицію: беру ціни з позицій угоди, '
             + 'пускаю конвеєр і перевіряю документ. Це кілька хвилин.');
  var d = await crmDocDoor('deal_kp', {deal: crmCard.did});
  if(b){ b.disabled = false; b.textContent = 'Підготувати КП'; }
  if(d && d.ok){
    var r = d.result || {};
    var doc = r.doc || {};
    crmDocsSay('КП причеплено до угоди: ' + (doc.number ? '№ ' + doc.number + ' ' : '')
               + (r.file || 'документ') + '.');
  }
}

async function crmDocAdd(){
  var el = document.getElementById('crmDocFile');
  var f = el && el.files && el.files[0];
  if(!f){ crmDocsSay('Спершу оберіть файл: договір — це папір, а не запис про папір.', true); return; }
  crmDocsSay('Кладу файл у сховище…');
  var fid = '';
  try{
    var up = await fetch('/api/files/upload', {method:'POST',
      headers:{'X-File-Name': encodeURIComponent(f.name)}, body: f});
    var ud = await up.json();
    if(!up.ok || ud.error){ crmDocsSay(ud.error || 'Файл не зберігся', true); return; }
    fid = (ud.file && ud.file.id) || '';
  }catch(e){ crmDocsSay('Файл не зберігся: ' + (e.message || e), true); return; }
  if(!fid){ crmDocsSay('Файл не зберігся: сховище не назвало його номер.', true); return; }
  var d = await crmDocDoor('deal_doc_add', {deal: crmCard.did,
                                            kind: crmDocVal('crmDocKind'),
                                            file_id: fid,
                                            number: crmDocVal('crmDocNumber'),
                                            date: crmDocVal('crmDocDate'),
                                            amount: crmDocVal('crmDocAmount')});
  if(d && d.result){
    crmDocsSay('Причеплено: ' + (d.result.number || '') + '.');
  }
}

async function crmDocRemove(docId){
  await crmDocDoor('deal_doc_remove', {id: docId});
}

/* ⭐⭐⭐ ВЛАСНІ ПОЛЯ (526) — МАЛЮЄ СПІЛЬНИЙ ПИСАР `ui/own_fields.js`
   (зміна 527, 06.09.2026). Малюнок один на всі екрани платформи; CRM приносить
   лише свій одяг і те, що робити після збереження. Другий такий самий малюнок
   на екрані задачі розійшовся б із цим на першій же правці. */
function crmOwnFieldsHtml(x){
  var rows=(x.rel&&x.rel.own_fields)||[];
  if(!rows.length) return '';
  OwnFields.mount({
    ref: crmCard.ref, rows: rows, can: true,
    inp: CRM_INP, btn: 'crmbtn', accent: 'crmbtn accent',
    wrap: 'crmsec', head: 'h4',
    after: async function(fields){
      if(crmCard.rel) crmCard.rel.own_fields=fields||[];
      crmCardPaintLeft();
      /* Заповнення лишає слід у стрічці — показуємо його одразу. */
      await crmFeedFetch(true); crmFeedPaint();
    }
  });
  return OwnFields.html();
}

function crmRelName(r){
  var t=r.title||r.ident||r.ref;
  return crmEsc(t);
}
function crmRelRow(r){
  var badge=r.kind_name?'<span class="crmpill" style="flex:none">'+crmEsc(r.kind_name)+'</span>':'';
  /* ⛒ МЕРТВИЙ ЗВʼЯЗОК НІКУДИ НЕ ВЕДЕ І КАЖЕ ПРО СЕБЕ. Кнопка в нікуди гірша
     за її відсутність — те саме рішення, що й у реєстрі звʼязків. */
  var body = r.href
    ? '<a href="'+crmEsc(crmHref(r.href))+'" style="color:var(--accent);text-decoration:none">'+crmEsc(r.phrase)+'</a>'
    : '<span style="opacity:.6">'+crmEsc(r.phrase)+(r.alive?'':' · сутності більше немає')+'</span>';
  var who=r.by_name?(' · '+crmEsc(r.by_name)):'';
  /* ⭐ Крок B5: у звʼязку буває ПІДПИС (посада на «працює в», «посередник у
     переписці» на «стосується»). Він живе на звʼязку — значить, показувати його
     має той, хто показує звʼязок, інакше підпис видно лише в одному розділі. */
  var sig=r.note?('<span style="color:var(--muted)"> · '+crmEsc(r.note)+'</span>'):'';
  return '<div class="crmrow" style="gap:8px;align-items:flex-start">'+badge
    +'<span style="flex:1;min-width:0">'+body+sig+'</span>'
    +'<span style="color:var(--muted);font-size:11px;white-space:nowrap">'+crmDate(r.at)+who+'</span></div>';
}
function crmFeedRow(r,pinned){
  var mark = r.source==='talk' ? '✉' : '⚙';
  var kind = r.kind_name?('<span class="crmlog-t">'+crmEsc(r.kind_name)+'</span>'):'';
  var text = crmEsc(r.text||'');
  if(r.href && r.ref_title){
    /* один клік просто зі стрічки — по назві сутності, як і просив Андрій */
    text += ' <a href="'+crmEsc(crmHref(r.href))+'" style="color:var(--accent);text-decoration:none">↗ відкрити</a>';
  }
  var warn = r.warn?('<span style="color:var(--bad)"> · '+crmEsc(r.warn)+'</span>'):'';
  var money = (r.cost_usd>0)?('<span class="crmlog-t">$'+Number(r.cost_usd).toFixed(4)+'</span>'):'';
  var bad = (r.outcome && r.outcome!=='ok')?('<span class="crmlog-t" style="color:var(--bad)">'+crmEsc(r.outcome_name||r.outcome)+'</span>'):'';
  /* ⭐ C3: важливе не тоне. Кнопка стоїть на КОЖНІЙ події й каже, що зробить. */
  var pin = r.key
    ? '<button class="crmpinb'+(pinned?' on':'')+'" title="'+(pinned?'Відкріпити':'Закріпити вгорі')+'"'
      +' aria-label="'+(pinned?'Відкріпити':'Закріпити вгорі')+'"'
      +' onclick="crmPin(\''+crmJsq(r.key)+'\','+(pinned?'false':'true')+')">'+(pinned?'★':'☆')+'</button>'
    : '';
  return '<div class="crmlog"><div class="crmlog-h">'
    +'<span class="crmlog-d">'+mark+' '+(r.at_key?crmDateTime(r.at_key):crmEsc(r.at||'—'))+'</span>'
    +kind+bad+money+'<span style="margin-left:auto">'+pin+'</span></div>'
    +'<div class="crmlog-n">'+text+warn+'</div></div>';
}
/* ── ВКЛАДКА «ЗВʼЯЗКИ»: ЩО ІСНУЄ ─────────────────────────────────────────── */
function crmRelatedHtml(d){
  var rel=(d&&d.related)||[];
  var body = rel.length
    ? rel.map(crmRelRow).join('')
    : '<div style="font-size:12px;color:var(--muted)">Повʼязаних карток немає. Задачі, угоди й заявки про цього контрагента зʼявляться тут одразу, щойно їх звʼяжуть.</div>';
  return '<div class="crmsec" style="margin-top:0"><h4>Повʼязані картки <span style="color:var(--muted)">'+rel.length+'</span></h4>'+body+'</div>';
}

/* ── ПРАВА ПОЛОВИНА: ТАЙМЛАЙН ────────────────────────────────────────────────
   ⛒ ЖОДНОГО ПІДРАХУНКУ ТУТ. «Показано N із M», «закріплено 3 із 7», «фільтр
   сховав K подій без дати» — усе це рахує `relations.feed` і віддає готовим.
   Порахувавши те саме ще й у браузері, ми завели б другого писаря арифметики, і
   майбутній телеграм показав би СВОЄ число з тих самих даних. */
function crmFeedOpts(list,sel,any){
  var h='<option value="">'+any+'</option>';
  for(var i=0;i<(list||[]).length;i++){
    var o=list[i];
    h+='<option value="'+crmEsc(o.id)+'"'+(sel===o.id?' selected':'')+'>'+crmEsc(o.name)+' ('+o.n+')</option>';
  }
  return h;
}
function crmFeedFilterHtml(f){
  var fl=f.filter||{};
  /* ⛒ «Про кого» рахує сервер зі САМОЇ СТРІЧКИ. Взявши сюди перелік звʼязків,
     екран пропонував би вибір, який дає порожньо. */
  var about=(f.refs||[]).length
    ? '<select onchange="crmFeedSet(\'about\',this.value)" aria-label="Про яку сутність подія">'
      +crmFeedOpts(f.refs,fl.about,'будь-яка сутність')+'</select>'
    : '';
  var reset = f.filtered
    ? '<button class="crmtab" onclick="crmFeedReset()">Скинути фільтр</button>'
    : '';
  return '<div class="crmfltr">'
    +'<select onchange="crmFeedSet(\'source\',this.value)" aria-label="Джерело події">'+crmFeedOpts(f.sources,fl.source,'усі джерела')+'</select>'
    +'<select onchange="crmFeedSet(\'kind\',this.value)" aria-label="Тип події">'+crmFeedOpts(f.kinds,fl.kind,'усі типи')+'</select>'
    +about
    /* ⛒ Два безіменні поля дат людина читає як загадку — підписуємо «від» і «до». */
    +'<span class="lb">від</span><input type="date" value="'+crmEsc((fl.since||'').slice(0,10))+'" onchange="crmFeedSet(\'since\',this.value)" aria-label="Події від дати">'
    +'<span class="lb">до</span><input type="date" value="'+crmEsc((fl.until||'').slice(0,10))+'" onchange="crmFeedSet(\'until\',this.value)" aria-label="Події до дати">'
    +reset+'</div>';
}
function crmFeedHtml(){
  var d=crmCard.rel;
  if(!d) return '';
  var f=d.feed||{}, lay=(d.layout&&d.layout.feed)||{};
  var rows=crmCard.rows||[];
  var h='<div style="display:flex;align-items:center;gap:8px;margin:0 0 6px">'
    +'<span style="font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);font-weight:700">Стрічка подій</span>'
    /* ⛔ МОВЧАЗНЕ ОБРІЗАННЯ СПИСКУ — заборонене. Межа називає себе завжди. */
    /* ⛒ ЧИСЛО НА ЕКРАНІ НЕ СМІЄ БУТИ МЕНШИМ ЗА ПОКАЗАНЕ. Поки сервер старий (до
       перезапуску), `matched` не приїжджає — і «показано 50 із 0» було б брехнею
       просто тому, що поле нове. Побачив ОКОМ на живому екрані, чеки мовчали. */
    +'<span style="margin-left:auto;font-size:11px;color:var(--muted)">показано '+rows.length+' із '
    +((f.matched!==undefined)?f.matched:(f.total||rows.length))
    +(f.filtered?(' · усього подій '+(f.total||0)):'')+'</span></div>';
  if(lay.filter) h+=crmFeedFilterHtml(f);
  /* Закріплені — над стрічкою, і в самій стрічці вони НЕ повторюються. */
  if(lay.pins && (f.pin_count>0 || f.pin_lost>0)){
    var pb=(f.pinned||[]).map(function(r){ return crmFeedRow(r,true); }).join('');
    h+='<div class="crmpinned">'
      +'<div style="font-size:11px;color:var(--warn);font-weight:700;letter-spacing:.4px;margin-bottom:4px">ЗАКРІПЛЕНО '+(f.pin_count||0)+' ІЗ '+(f.pin_limit||0)+'</div>'
      +pb
      +(f.pin_lost>0?'<div class="crmnote-warn">Закріплень без події: '+f.pin_lost+'. Подію могли прибрати руками — зніміть позначку або поверніть запис.</div>':'')
      +'</div>';
  }
  if(f.undated_hidden>0) h+='<div class="crmnote-warn">Фільтр дат сховав '+f.undated_hidden+' подій, у яких дата не читається.</div>';
  h += rows.length
    ? rows.map(function(r){ return crmFeedRow(r,false); }).join('')
    : '<div style="font-size:12px;color:var(--muted)">'+(f.filtered?'За цим фільтром подій немає.':'Подій ще немає.')+'</div>';
  if(f.has_more){
    h+='<div style="margin-top:10px"><button class="crmtab" onclick="crmFeedMore()">Показати ще ('+f.cut+')</button></div>';
  }
  if(f.protocol_since){
    h+='<div style="font-size:11px;color:var(--muted);margin-top:12px">Дії платформи журнал веде з '+crmDate(f.protocol_since)+'; спілкування — з дня заведення картки.</div>';
  }
  return h;
}

/* ── ЧИТАННЯ СТРІЧКИ ─────────────────────────────────────────────────────── */
async function crmFeedFetch(reset){
  /* ⭐ C1: стрічку й склад картки читає ОДИН читач (`relations.card`) — для
     контакту і для угоди однаково. Другого читача не заводимо. */
  var q;
  if(crmCard.kind==='deal'){
    if(!crmCard.did){ crmCard.rel=null; crmCard.rows=[]; return null; }
    q='/api/crm/entity_card?ref='+encodeURIComponent('deal:'+crmCard.did);
  }else{
    if(!crmCard.pid){ crmCard.rel=null; crmCard.rows=[]; return null; }
    q='/api/crm/party_card?id='+encodeURIComponent(crmCard.pid);
  }
  var f=crmCard.flt||{};
  ['source','kind','about','since','until'].forEach(function(k){
    if(f[k]) q+='&'+k+'='+encodeURIComponent(f[k]);
  });
  if(!reset) q+='&offset='+(crmCard.rows||[]).length;
  try{
    var r=await fetch(q);
    var d=await r.json();
    if(!r.ok||d.error){ crmCard.rel=null; return null; }
    crmCard.rel=d;
    crmCard.ref=d.ref||'';
    var got=(d.feed&&d.feed.rows)||[];
    crmCard.rows = reset ? got : (crmCard.rows||[]).concat(got);
    return d;
  }catch(e){ crmCard.rel=null; return null; }
}
function crmFeedPaint(){
  var el=document.getElementById('crmPaneRight');
  if(!el||!crmCard.rel) return;
  var lay=(crmCard.rel.layout&&crmCard.rel.layout.feed)||{};
  var top = lay.top ? (CARD_BLOCK_DRAW[lay.top]?CARD_BLOCK_DRAW[lay.top](crmCard):crmCardMissing([lay.top])) : '';
  el.innerHTML=top+crmFeedHtml();
}
async function crmFeedMore(){ await crmFeedFetch(false); crmFeedPaint(); }
async function crmFeedSet(field,value){
  crmCard.flt[field]=(value||'').trim();
  if(!crmCard.flt[field]) delete crmCard.flt[field];
  await crmFeedFetch(true); crmFeedPaint();
}
async function crmFeedReset(){ crmCard.flt={}; await crmFeedFetch(true); crmFeedPaint(); }
async function crmPin(key,on){
  if(!crmCard.ref) return;
  try{
    var r=await fetch('/api/crm/pin',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({ref:crmCard.ref,key:key,on:!!on})});
    var d=await r.json();
    /* ⛒ ВІДМОВУ ПРО МЕЖУ ЛЮДИНА БАЧИТЬ СЛОВАМИ. Мовчазне «нічого не сталось» на
       восьмому закріпленні було б гіршим за саму межу. */
    if(!r.ok||d.error){ crmFlash(d.error||'Не вдалося змінити закріплення',true); return; }
  }catch(e){ crmFlash('Не вдалося змінити закріплення: '+(e.message||e),true); return; }
  await crmFeedFetch(true); crmFeedPaint();
}

/* ── ДІЇ КАРТКИ: ВИДНІ З БУДЬ-ЯКОЇ ВКЛАДКИ ───────────────────────────────
   ⛒ 615. СТЕЛЯ ЕКРАНА ОГОЛОШЕНА ВГОЛОС — `CARD_ACTION_DRAW`, так само як
   `CARD_BLOCK_DRAW`. Сервер може оголосити дію, якої екран не вміє; тоді це
   видно чеком `card_engine_test`, а не порожнім місцем у людини. */
var CARD_ACTION_DRAW={
  deal_kp:function(x){
    if(!x||!x.d) return '';
    return '<button class="crmbtn accent" id="crmKpBtn" onclick="crmKpPrepare()">'
      +'Створити КП</button>';
  }
};
function crmCardActionsHtml(lay){
  var acts=(lay&&lay.actions)||[]; if(!acts.length) return '';
  var h='', miss=[];
  for(var i=0;i<acts.length;i++){
    var fn=CARD_ACTION_DRAW[acts[i].id];
    if(!fn){ miss.push(acts[i].id); continue; }
    h+=(fn(crmCard)||'');
  }
  if(!h && !miss.length) return '';
  return '<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;'
    +'margin-bottom:12px">'+h+'</div>'
    +(miss.length?crmCardMissing(miss):'');
}

/* ── ЛІВА ПОЛОВИНА: ВКЛАДКИ Й РОЗДІЛИ ПОЛІВ ──────────────────────────────── */
function crmCardMissing(ids){
  return '<div class="crmnote-err">Сервер оголосив блок(и) «'+crmEsc(ids.join(', '))
    +'», яких цей екран малювати не вміє. Це не порожні дані — це розбіжність '
    +'між складом картки і екраном.</div>';
}
function crmCardTab(id){ crmCard.tab=id; crmCardPaintLeft(); }
function crmCardLeftHtml(){
  var lay=crmCard.rel&&crmCard.rel.layout;
  if(!lay){
    var why=(crmCard.rel&&crmCard.rel.layout_error)||'';
    if(why) return '<div class="crmnote-err">'+crmEsc(why)+'</div>';
    /* Картка контрагента без номера в довіднику: складу питати нема в кого. */
    return (crmCard.pr?crmPartyDirHtml(crmCard.pr):'')
      +(crmCard.c?(crmCommsHub(crmCard.c)+crmDealsHtml(crmCard)
      +crmLicenseHtml(crmCard.c)+crmSystemsHtml(crmCard.c)+crmProfileHtml(crmCard.c)
      +crmContactsHtml(crmCard.c)+crmDossierHtml(crmCard.c)+crmNotesHtml(crmCard.c)
      +crmHistAddHtml(crmCard.c)):'');
  }
  var tabs=[], body={};
  for(var i=0;i<lay.tabs.length;i++){
    var t=lay.tabs[i], h='', miss=[];
    for(var j=0;j<t.blocks.length;j++){
      var b=t.blocks[j], fn=CARD_BLOCK_DRAW[b.id];
      if(!fn){ miss.push(b.id); continue; }
      h+=(fn(crmCard)||'');
    }
    if(miss.length) h+=crmCardMissing(miss);
    /* ⛒ ПОРОЖНЯ ВКЛАДКА НЕ МАЛЮЄТЬСЯ — кнопка в нікуди гірша за її відсутність. */
    if(h){ body[t.id]=h; tabs.push(t); }
  }
  if(!tabs.length) return '<div style="font-size:12.5px;color:var(--muted)">Показувати ще нічого: картки угоди немає, довідник порожній.</div>';
  var act=crmCard.tab;
  if(!body[act]){ act=(tabs.filter(function(t){return t.main;})[0]||tabs[0]).id; crmCard.tab=act; }
  var bar='<div class="crmtabs">';
  for(var k=0;k<tabs.length;k++){
    var tt=tabs[k], n=crmCardTabCount(tt);
    bar+='<button class="crmtab'+(tt.id===act?' on':'')+'" onclick="crmCardTab(\''+crmJsq(tt.id)+'\')">'
      +crmEsc(tt.name)+(n===null?'':'<span class="n">'+n+'</span>')+'</button>';
  }
  bar+='</div>';
  /* ⛒ 615: дія картки стоїть НАД вкладками — вкладка ховає вміст, а не дію. */
  return crmCardActionsHtml(lay)+bar+body[act];
}
function crmCardTabCount(t){
  /* Лічильник показуємо ЛИШЕ там, де його справді є з чого порахувати. */
  if(t.count==='related') return ((crmCard.rel&&crmCard.rel.related)||[]).length;
  return null;
}
function crmCardPaintLeft(){
  var el=document.getElementById('crmPaneLeft');
  if(el) el.innerHTML=crmCardLeftHtml();
  crmSysCountInit();
}
function crmCardPaint(){
  document.getElementById('crmDrawerBody').innerHTML=
    '<div class="crmcard2"><div class="crmpane left" id="crmPaneLeft"></div>'
   +'<div class="crmpane right" id="crmPaneRight"></div></div>';
  crmCardPaintLeft();
  crmFeedPaint();
}
function crmPdMsg(t,bad){ var m=document.getElementById('pd_msg'); if(!m) return; m.textContent=t||''; m.style.color=bad?'var(--bad)':'var(--muted)'; }
/* ⛒ ОБИДВІ ДВЕРІ ВЕДУТЬ В ОДНУ КАРТКУ. Урок 14.08: правило, яке живе на одному
   шляху відкриття, — наш найдорожчий клас помилок. Тому склад і стрічку малює
   один рушій, а різниця між дверима лише в тому, чи є картка угоди. */
async function crmOpenParty(pid){
  var pr=crmPartyById(pid); if(!pr) return;
  crmState.lastParty=pid;
  if(pr.customer){ await openCrmCard(pr.customer,pid); return; }
  /* Контакт без картки угоди: даних угоди немає, решта картки — та сама. */
  var mark='party:'+pid;
  if(crmState.lastCard!==mark){ crmEdit={}; crmCard.tab=''; crmCard.flt={}; }
  crmState.lastCard=mark; crmState.cur=null;
  crmCard.kind='party'; crmCard.did=''; crmCard.d=null;
  crmCard.cust=''; crmCard.c=null; crmCard.pid=pid; crmCard.pr=pr; crmCard.rows=[];
  crmAddr('party='+encodeURIComponent(pid));
  await crmFeedFetch(true);
  document.getElementById('crmDrawerHead').innerHTML=
     '<div style="width:44px;height:44px;border-radius:50%;background:var(--panel2);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;color:var(--accent);flex:none">'+crmInit(pr.name||pr.id)+'</div>'
    +'<div style="flex:1;min-width:0"><div style="font-weight:600;font-size:16px">'+crmEsc(pr.name||pr.id)+'</div><div style="font-size:11.5px;color:var(--muted)">'+crmEsc(pr.id)+' · картки угоди ще немає</div></div>'
    +'<button class="modal-x" style="flex:none;margin-left:4px" onclick="closeDrawer()" title="Закрити">✕</button>';
  crmCardPaint();
  document.getElementById('crmDrawer').classList.add('open');
}
async function crmPartySave(pid){
  /* ⛒ Зберігаємо рівно ті ролі, які показали людині: перелік ключів — той самий
     словник платформи, що й у малюванні. Два списки розійшлись би, і галочка
     «контактна особа» тихо не зберігалась би. */
  var roles=[]; var rk=Object.keys((crmBaseState&&crmBaseState.roles)||{'client':1,'supplier':1,'partner':1});
  for(var r=0;r<rk.length;r++){ var el=document.getElementById('pd_role_'+rk[r]); if(el&&el.checked) roles.push(rk[r]); }
  var body={id:pid,name:(document.getElementById('pd_name')||{}).value||'',
            kind:(document.getElementById('pd_kind')||{}).value||'',
            roles:roles,note:(document.getElementById('pd_note')||{}).value||''};
  crmPdMsg('Зберігаю…');
  try{
    var r2=await fetch('/api/crm/party',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    var d=await r2.json();
    if(!r2.ok||d.error){ crmPdMsg(d.error||'Не вдалося зберегти.',true); return; }
    crmPdMsg('Збережено. Номер контрагента не змінився — історія при ньому.');
    await loadBase(); var pr=crmPartyById(pid); if(pr) await crmOpenParty(pid);
  }catch(e){ crmPdMsg('Не вдалося зберегти: '+(e.message||e),true); }
}
async function crmPartyHandle(pid,kind,value,add){
  var body={id:pid};
  if(add){
    kind=(document.getElementById('pd_hk')||{}).value||''; value=(document.getElementById('pd_hv')||{}).value||'';
    if(!value){ crmPdMsg('Порожня адреса не привʼязується.',true); return; }
    body.add_handle={kind:kind,value:value};
  } else {
    if(!confirm('Відвʼязати «'+value+'» від контрагента '+pid+'?\nСам контрагент лишиться, але вхідне з цієї адреси перестане його впізнавати.')) return;
    body.remove_handle={kind:kind,value:value};
  }
  crmPdMsg('Зберігаю…');
  try{
    var r2=await fetch('/api/crm/party',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    var d=await r2.json();
    if(!r2.ok||d.error){ crmPdMsg(d.error||'Не вдалося.',true); return; }
    await loadBase(); await crmOpenParty(pid);
  }catch(e){ crmPdMsg('Не вдалося: '+(e.message||e),true); }
}
/* ⛒ ВИДАЛЕННЯ НЕ ВГАДУЄ ФОРМУ: спершу перелік, що зникне і що ЗАЛИШИТЬСЯ. */
async function crmPartyDelete(pid,confirmed){
  crmPdMsg(confirmed?'Видаляю…':'Дивлюсь, що саме зникне…');
  try{
    var r2=await fetch('/api/crm/party_delete',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({id:pid,confirm:!!confirmed})});
    var d=await r2.json();
    if(d.error){ crmPdMsg(d.error,true); return; }
    if(!confirmed){
      var pl=d.plan||{};
      var txt='ЗНИКНЕ:\n· '+(pl.goes||[]).join('\n· ')+'\n\nЗАЛИШИТЬСЯ:\n· '+(pl.stays||[]).join('\n· ')+'\n\n'+(pl.protocol||'')+'\n\nВидаляємо?';
      if(!confirm(txt)){ crmPdMsg('Скасовано. Нічого не змінилось.'); return; }
      return crmPartyDelete(pid,true);
    }
    closeDrawer(); await loadBase(); crmBaseMsg('Контрагента '+pid+' прибрано з довідника.');
  }catch(e){ crmPdMsg('Не вдалося: '+(e.message||e),true); }
}
/* ── ⭐⭐⭐ ЗМІНА 189 (16.08.2026): ОДИН ПИСАР НОВОГО КОНТРАГЕНТА НА ДВА МІСЦЯ ──
   Питання Андрія: «додати нового клієнта прямо у виборі клієнта — це не друга
   рука?» Друга рука зʼявилась би не від ґудзика, а від ДРУГОЇ ФОРМИ: завтра
   «ЄДРПОУ» додався б у розділі «Клієнти» і не додався б у вибирачі.
   ⛒ Тому форму малює ОДИН писар, а відправляє ОДИН писар. Хто покликав — той
   лише каже, ЯК звати поля, КОМУ доповідати і ЩО робити після.
   ⛒ ІМЕНА ПОЛІВ — ІЗ ПРЕФІКСА, а не зашиті: обидві форми можуть лежати на
   сторінці одночасно (вибирач стоїть НАД розділом «Клієнти»), і з однаковими
   іменами читач брав би поля ЧУЖОЇ форми — мовчки й завжди. */
function crmPartyFormHtml(pfx,onSave,onCancel){
  var INP='padding:7px 9px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--txt)';
  return '<div style="font-weight:700;font-size:13px;margin-bottom:8px">Новий контрагент</div>'
    +'<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:flex-end">'
    +'<label style="font-size:11px;color:var(--muted)">Назва<br><input id="'+pfx+'name" type="text" placeholder="ТОВ «…» або Прізвище Імʼя" style="min-width:230px;'+INP+'"></label>'
    +'<label style="font-size:11px;color:var(--muted)">Тип<br><select id="'+pfx+'kind" style="'+INP+'"><option value="">не вказано</option><option value="person">фізична особа</option><option value="company">компанія</option></select></label>'
    +'<label style="font-size:11px;color:var(--muted)">Роль<br><select id="'+pfx+'role" style="'+INP+'"><option value="client">клієнт</option><option value="supplier">постачальник</option><option value="partner">партнер</option></select></label>'
    +'<label style="font-size:11px;color:var(--muted)">Пошта<br><input id="'+pfx+'email" type="text" style="'+INP+'"></label>'
    +'<label style="font-size:11px;color:var(--muted)">Телефон<br><input id="'+pfx+'phone" type="text" placeholder="+380…" style="'+INP+'"></label>'
    +'<button class="crmtab on" style="min-height:34px" onclick="'+onSave+'">Завести</button>'
    +'<button class="crmtab" style="min-height:34px" onclick="'+onCancel+'">Скасувати</button>'
    +'</div><div style="font-size:11px;color:var(--muted);margin-top:8px">Пошта й телефон — це те, за чим платформа впізнає вхідне. Одна адреса належить лише одному контрагенту.</div>';
}
function crmPartyNewForm(){
  var el=document.getElementById('crmPartyNew'); if(!el) return;
  if(el.style.display==='block'){ el.style.display='none'; return; }
  el.style.display='block';
  el.innerHTML=crmPartyFormHtml('pn_',"crmPartyNew('pn_',crmBaseMsg,loadBase)","crmPartyNewForm()");
}
async function crmPartyNew(pfx,say,after){
  /* ⛒ Успіх кажемо ПІСЛЯ `after`: перечитування розділу перемальовує його
     цілком і стерло б рядок, який людина не встигла прочитати. */
  var tell=say||crmBaseMsg, g=function(k){ return (document.getElementById(pfx+k)||{}).value||''; };
  var handles={};
  if(g('email')) handles.email=[g('email')];
  if(g('phone')) handles.phone=[g('phone')];
  tell('Заводжу…');
  try{
    var r2=await fetch('/api/crm/party_new',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({name:g('name'),kind:g('kind'),
                           roles:[g('role')||'client'],handles:handles})});
    var d=await r2.json();
    if(!r2.ok||d.error){ tell(d.error||'Не вдалося завести.',true); return null; }
    if(after) await after(d.party||{});
    tell('Заведено: '+((d.party||{}).id||'')+' · '+((d.party||{}).name||''));
    return d.party||{};
  }catch(e){ tell('Не вдалося завести: '+(e.message||e),true); return null; }
}
/* ⛒ ОДИН ЧИТАЧ РЯДКА КОНТРАГЕНТА — той самий писар пошуку D2. Другий читач
   означав би друге джерело правди про те, ХТО ВЕДЕ клієнта. */
async function crmPartyRow(pid){
  try{
    var d=await fetch('/api/crm/party_search?q='+encodeURIComponent(pid)+'&filter=all&page=1&per=5')
      .then(function(r){return r.json();});
    var rows=(d&&d.rows)||[];
    for(var i=0;i<rows.length;i++){ if(rows[i].id===pid) return rows[i]; }
  }catch(e){}
  return null;
}
async function crmInboxAttach(i){
  var it=crmBaseState.inbox[i]; if(!it) return;
  var pid=(((crmBaseState.attach||{})[i])||{}).id||'';
  if(!pid){ crmBaseMsg('Оберіть контрагента — вгадувати, до кого це, платформа не буде.',true); return; }
  crmBaseMsg('Привʼязую…');
  try{
    var r2=await fetch('/api/crm/inbox_attach',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({channel:it.channel,identity:it.identity,name:it.name||'',party_id:pid})});
    var d=await r2.json();
    if(!r2.ok||d.error){ crmBaseMsg(d.error||'Не вдалося привʼязати.',true); return; }
    await loadBase(); crmBaseMsg('Привʼязано до '+pid+' — дубля в базі не зʼявилось.');
  }catch(e){ crmBaseMsg('Не вдалося привʼязати: '+(e.message||e),true); }
}

/* ── ⭐⭐⭐ ЗМІНА 188 (16.08.2026): ОДИН ВИБИРАЧ КОНТРАГЕНТА, ОДНЕ ВІКНО УГОДИ ──
   КОРІНЬ. Завести угоду можна було ЛИШЕ всередині картки контрагента, а на
   воронці дверей не було. Повісити другу кнопку «просто щоб була» означало б
   завести ДРУГОГО писаря народження угоди — і завтра вони розійшлись би
   (перевірки, підказки, ворота стадії).
   ⛒ Тому писар ОДИН: `crmMakeOpen`. Хто б не покликав — воронка чи картка
   контрагента — угода народжується в одному місці.
   ⛒ І вибір контрагента теж ОДИН: `crmPickOpen` питає СЕРВЕР (`party_search`,
   писар D2). Старий `select` віз усю базу одним шматком — на трьох тисячах це
   рівно та сама поламана робота, від якої лікував D2.
   ⛒ У вибирачі ВИДНО «хто веде клієнта» — це вимога Андрія 15.08, а не
   прикраса: менеджер має знати, з ким порадитись, ще ДО того як почне продаж. */
var crmPick={seq:0,q:'',page:1,per:20,filter:'all',res:null,onPick:null};
function crmPickAsk(){ crmPick.seq=(crmPick.seq||0)+1; return crmPick.seq; }
function crmPickStale(my){ return my!==crmPick.seq; }
function crmPickUrl(){
  return '/api/crm/party_search?q='+encodeURIComponent(crmPick.q||'')
    +'&filter='+encodeURIComponent(crmPick.filter||'all')
    +'&page='+(crmPick.page||1)+'&per='+(crmPick.per||20);
}
function crmPickOpen(opts){
  opts=opts||{};
  crmPick.filter=opts.filter||'all'; crmPick.onPick=opts.onPick||null;
  crmPick.q=''; crmPick.page=1; crmPick.res=null; crmPick.newForm=false;
  document.getElementById('crmPickTitle').textContent=opts.title||'Оберіть контрагента';
  document.getElementById('crmPickHint').textContent=opts.hint||'';
  document.getElementById('crmPickOverlay').classList.add('show');
  crmPickRender(); crmPickLoad(true);
}
function crmPickClose(){
  /* ⛒ Відповідь, яка вже їде, не намалює закрите вікно: номер питання росте. */
  crmPickAsk(); crmPick.onPick=null; crmPick.res=null;
  document.getElementById('crmPickOverlay').classList.remove('show');
}
async function crmPickLoad(focus){
  /* 🩸 ТОЙ САМИЙ УРОК, ЩО Й У D2: відповідь на СТАРЕ питання не сміє перебити
     нове. Лічильник тут СВІЙ — спільний із базою зробив би два екрани
     залежними один від одного, і перевірка почала б брехати. */
  var my=crmPickAsk();
  try{
    var d=await fetch(crmPickUrl()).then(function(r){return r.json();});
    if(crmPickStale(my)) return;
    crmPick.res=d.error?{rows:[],found:0,page:1,pages:1,error:d.error}:d;
    if(!d.error) crmPick.page=d.page||1;
    crmPickRender(focus);
  }catch(e){
    if(crmPickStale(my)) return;
    crmPick.res={rows:[],found:0,page:1,pages:1,error:'Не вдалося знайти: '+(e.message||e)};
    crmPickRender();
  }
}
function crmPickFind(){ crmPick.q=(crmVal('crmPickQ')||'').trim(); crmPick.page=1; crmPickLoad(true); }
function crmPickPage(n){
  var r=crmPick.res||{}, p=Math.max(1,Math.min(n,r.pages||1));
  if(p===(crmPick.page||1)) return;
  crmPick.page=p; crmPickLoad(false);
}
function crmPickTake(pid,row){
  var fn=crmPick.onPick, rows=((crmPick.res||{}).rows)||[];
  if(!row){ for(var i=0;i<rows.length;i++){ if(rows[i].id===pid) row=rows[i]; } }
  crmPickClose();
  if(fn) fn(pid,row);
}
/* ⭐ ЗМІНА 189: клієнта, якого в базі ще немає, заводимо ПРЯМО ТУТ — і він
   одразу стає обраним. Інакше вибирач був би глухим кутом: «нема в базі —
   закрий вікно, піди в розділ «Клієнти», заведи, повернись і почни спочатку». */
function crmPickMsg(t,bad){
  var m=document.getElementById('crmPickMsg'); if(!m) return;
  m.textContent=t||''; m.style.color=bad?'var(--err)':'var(--muted)';
}
function crmPickNewForm(on){ crmPick.newForm=!!on; crmPickRender(); }
async function crmPickPartySave(){
  /* ⛒ Кличемо ТОГО САМОГО писаря, що й розділ «Клієнти» — лише з іншим
     префіксом полів і своїм місцем для відповіді. */
  await crmPartyNew('pk_pn_',crmPickMsg,async function(party){
    if(!party||!party.id) return;
    var row=await crmPartyRow(party.id);
    crmPick.newForm=false;
    crmPickTake(party.id,row);
  });
}
function crmPickWhoHtml(r){
  var mg=r.manager||null, lc=r.last_contact||{};
  /* ⛒ «Нікого не веде» — це ВІДПОВІДЬ, а не порожнє місце: саме з неї
     починається розмова «а чий це клієнт». */
  return '<div style="font-size:12px;margin-top:3px">'
    +(mg?('веде: <b>'+crmEsc(mg.name||mg.id)+'</b>'
          +(mg.dismissed?' <span style="color:var(--warn)">(звільнений)</span>':'')
          +(mg.gone?' <span style="color:var(--warn)">(немає в оргструктурі)</span>':''))
        :'<span style="color:var(--warn)">нікого не веде</span>')
    +(lc.date?('<span style="color:var(--muted)"> · останній контакт '+crmDate(lc.date)+'</span>'):'')
    +'</div>';
}
function crmPickRender(focus){
  var st=crmPick, r=st.res, h=[];
  h.push('<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-bottom:10px">'
    +'<input id="crmPickQ" type="search" placeholder="Назва, ЄДРПОУ, пошта, телефон, номер угоди (d0014) або картки (p0020)"'
    +' aria-label="Пошук контрагента"'
    +' onkeydown="if(event.key===\'Enter\'){event.preventDefault();crmPickFind();}"'
    +' style="flex:1;min-width:220px;padding:8px 10px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--txt);font-size:13px">'
    +'<button class="crmtab on" onclick="crmPickFind()">Знайти</button>'
    +'<button class="crmtab" onclick="crmPickNewForm('+(st.newForm?'false':'true')+')" title="Завести контрагента, якого в базі ще немає">'
    +(st.newForm?'Не заводити':'+ Завести нового')+'</button></div>');
  h.push('<div id="crmPickMsg" role="status" aria-live="polite" style="font-size:12px;color:var(--muted);min-height:14px;margin-bottom:6px"></div>');
  if(st.newForm){
    h.push('<div style="border:1px solid var(--line);border-radius:10px;padding:12px;margin-bottom:12px;background:var(--panel2)">'
      +crmPartyFormHtml('pk_pn_','crmPickPartySave()','crmPickNewForm(false)')+'</div>');
  }
  if(!r){ h.push('<div style="color:var(--muted);font-size:12.5px">Читаю базу…</div>'); }
  else if(r.error){
    h.push('<div style="color:var(--bad);font-size:12.5px;border:1px solid var(--line);border-radius:10px;padding:12px">'
      +(r.error==='not_found'
        ? 'Пошук недоступний: сторінка новіша за програму. Онови сторінку (Ctrl+F5), а якщо не допомогло — перезапусти SensFlow.'
        : crmEsc(r.error))+'</div>');
  } else {
    var rows=r.rows||[], found=r.found||0, page=r.page||1, pages=r.pages||1;
    /* 🩸 МОВЧАЗНЕ ОБРІЗАННЯ СПИСКУ — З ПЕРЕЛІКУ «ЩО ВБИВАЄ ПРОДУКТ»: скільки
       знайшлось УСЬОГО, вибирач каже завжди. */
    h.push('<div style="font-size:12px;color:var(--muted);margin-bottom:8px">'
      +(st.q?('Знайдено <b style="color:var(--txt)">'+found+'</b> за запитом «'+crmEsc(st.q)+'»')
            :('У базі <b style="color:var(--txt)">'+found+'</b>'))
      +(pages>1?(' · показано '+rows.length+' (сторінка '+page+' з '+pages+')'):'')+'</div>');
    if(!rows.length){
      h.push('<div style="color:var(--muted);font-size:12.5px;border:1px dashed var(--line);border-radius:10px;padding:12px">Нічого не знайшлось. Шукаю за назвою, ЄДРПОУ, поштою, телефоном, номером угоди (d0014) і номером картки (p0020) — цифри від трьох знаків.</div>');
    } else {
      for(var i=0;i<rows.length;i++){
        var pr=rows[i], rls=(pr.role_names||[]).join(', ');
        h.push('<div role="button" tabindex="0" title="Обрати цього контрагента"'
          +' onclick="crmPickTake(\''+crmJsq(pr.id)+'\')"'
          +' onkeydown="if(event.key===\'Enter\'||event.key===\' \'){event.preventDefault();crmPickTake(\''+crmJsq(pr.id)+'\');}"'
          +' style="border:1px solid var(--line);border-radius:10px;padding:9px 11px;margin-bottom:7px;background:var(--panel2);cursor:pointer">'
          +'<div style="font-weight:700;font-size:13px">'+crmEsc(pr.name)+'</div>'
          +'<div style="font-size:11px;color:var(--muted)">'+crmEsc(pr.id)+' · '+crmEsc(pr.kind_name||'')
          +(rls?(' · '+crmEsc(rls)):'')
          +(pr.match_name?(' · знайдено за: '+crmEsc(pr.match_name)):'')+'</div>'
          +crmPickWhoHtml(pr)
          +'</div>');
      }
      if(pages>1){
        h.push('<div style="display:flex;gap:8px;align-items:center;justify-content:center;margin-top:10px;flex-wrap:wrap">'
          +'<button class="crmtab" onclick="crmPickPage('+(page-1)+')"'+(page<=1?' disabled style="opacity:.45;cursor:default"':'')+'>‹ Назад</button>'
          +'<span style="font-size:12px;color:var(--muted)">сторінка '+page+' з '+pages+'</span>'
          +'<button class="crmtab" onclick="crmPickPage('+(page+1)+')"'+(page>=pages?' disabled style="opacity:.45;cursor:default"':'')+'>Далі ›</button></div>');
      }
    }
  }
  document.getElementById('crmPickBody').innerHTML=h.join('');
  var qi=document.getElementById('crmPickQ');
  if(qi){ qi.value=st.q||''; if(focus){ try{ qi.focus(); qi.setSelectionRange(qi.value.length,qi.value.length); }catch(e){} } }
}

/* ── ⭐ ВІКНО «НОВА УГОДА» — ЄДИНИЙ ПИСАР НАРОДЖЕННЯ УГОДИ ─────────────────── */
var crmMake={party:null,busy:false,msg:'',bad:false};
function crmMakeOpen(pid){
  crmMake.party=null; crmMake.busy=false; crmMake.msg=''; crmMake.bad=false;
  document.getElementById('crmMakeOverlay').classList.add('show');
  crmMakeRender();
  if(pid) crmMakeSet(pid); else crmMakePick();
}
function crmMakeClose(){
  crmMake.party=null; crmMake.busy=false; crmMake.msg='';
  document.getElementById('crmMakeOverlay').classList.remove('show');
}
function crmMakeMsg(text,bad){ crmMake.msg=text||''; crmMake.bad=!!bad; crmMakeRender(); }
function crmMakePick(){
  /* ⛒ Набране імʼя угоди переживає похід у вибирач: вікно перемальовується, і
     без цього рядка людина щоразу друкувала б назву заново. */
  crmMake.name=(crmVal('crmMakeName')||crmMake.name||'');
  crmPickOpen({title:'Клієнт нової угоди',
    hint:'Видно, чи контрагент уже є в базі і хто його веде — щоб не завести дубля і було з ким порадитись.',
    filter:'all',
    onPick:function(pid,row){ crmMake.party=row||{id:pid,name:pid}; crmMakeMsg(''); }});
}
async function crmMakeSet(pid){
  /* ⛒ Дані про клієнта беремо в ТОГО САМОГО писаря пошуку, а не з окремого
     переліку: два джерела «хто веде» розійшлись би вже наступного тижня. */
  crmMake.party={id:pid,name:pid}; crmMakeRender();
  var row=await crmPartyRow(pid);
  if(row) crmMake.party=row;
  crmMakeRender();
}
function crmMakeRender(){
  var p=crmMake.party, h=[];
  if(crmMake.msg){
    h.push('<div style="font-size:12px;margin-bottom:10px;border-radius:8px;padding:7px 10px;border:1px solid '
      +(crmMake.bad?'var(--err);color:var(--err);background:var(--tint-err)':'var(--ok);color:var(--ok);background:var(--tint-ok)')
      +'">'+crmEsc(crmMake.msg)+'</div>');
  }
  h.push('<div style="font-size:11.5px;color:var(--muted);margin-bottom:4px">Клієнт</div>');
  if(p&&p.id){
    h.push('<div style="border:1px solid var(--line);border-radius:10px;padding:9px 11px;background:var(--panel2)">'
      +'<div style="font-weight:700;font-size:13px">'+crmEsc(p.name||p.id)+'</div>'
      +'<div style="font-size:11px;color:var(--muted)">'+crmEsc(p.id)
      +(p.kind_name?(' · '+crmEsc(p.kind_name)):'')
      +((p.role_names||[]).length?(' · '+crmEsc((p.role_names||[]).join(', '))):'')
      +' · <span style="color:var(--ok)">уже є в базі</span></div>'
      +crmPickWhoHtml(p)
      +'<div style="margin-top:8px"><button class="crmtab" onclick="crmMakePick()">Змінити клієнта</button></div></div>');
  } else {
    h.push('<div style="border:1px dashed var(--line);border-radius:10px;padding:11px;color:var(--muted);font-size:12.5px">'
      +'Клієнта не обрано. Угода без клієнта не заводиться — вона вела б у порожнечу.'
      +'<div style="margin-top:8px"><button class="crmtab on" onclick="crmMakePick()">Обрати клієнта</button></div></div>');
  }
  h.push('<div style="font-size:11.5px;color:var(--muted);margin:12px 0 4px">Назва угоди</div>'
    +'<input id="crmMakeName" type="text" placeholder="Про що продаж — коротко"'
    +' onkeydown="if(event.key===\'Enter\'){event.preventDefault();crmMakeGo();}"'
    +' style="width:100%;box-sizing:border-box;padding:8px 10px;border-radius:8px;border:1px solid var(--line);background:var(--panel);color:var(--txt);font-size:13px">'
    +'<div style="font-size:11.5px;color:var(--muted);margin-top:6px">Стадія — «Новий клієнт». Суму й наступну дію додасте в картці угоди.</div>');
  h.push('<div style="display:flex;gap:8px;margin-top:14px">'
    +'<button class="crmbtn accent" onclick="crmMakeGo()"'+(crmMake.busy?' disabled style="opacity:.5;cursor:default"':'')+'>Завести угоду</button>'
    +'<button class="crmbtn" onclick="crmMakeClose()">Скасувати</button></div>');
  document.getElementById('crmMakeBody').innerHTML=h.join('');
  var ni=document.getElementById('crmMakeName');
  if(ni){ ni.value=crmMake.name||''; if(p&&p.id){ try{ ni.focus(); }catch(e){} } }
}
async function crmMakeGo(){
  var p=crmMake.party;
  crmMake.name=(crmVal('crmMakeName')||'');
  if(!p||!p.id){ crmMakeMsg('Спершу оберіть клієнта: угода без клієнта — не угода.',true); return; }
  var nm=crmMake.name.trim();
  if(!nm){ crmMakeMsg('Назва угоди порожня — воронці нема що показати.',true); return; }
  if(crmMake.busy) return;
  crmMake.busy=true; crmMakeMsg('Заводжу угоду…');
  /* ⛒ Той самий писар запиту, що й уся картка угоди, і ТІ САМІ двері
     `/api/crm/deal_new`. Нових дверей ця зміна не робить. */
  var d=await crmDealPost('deal_new',{name:nm,party:p.id},'',
                          function(t,bad){ crmMakeMsg(t,bad); });
  crmMake.busy=false;
  if(!d||!d.deal){ crmMakeRender(); return; }
  crmMake.name='';
  crmMakeClose();
  if(crmState.view==='board') loadBoard();
  await openCrmDeal(d.deal.id);
}
/* ⭐ Вибір контрагента для черги «Не оброблені» — ТОЙ САМИЙ вибирач. */
function crmAttachPick(i){
  crmPickOpen({title:'До кого привʼязати звернення',
    hint:'Шукає по всій базі: назва, ЄДРПОУ, пошта, телефон, номер угоди чи картки.',
    filter:'all',
    onPick:function(pid,row){
      crmBaseState.attach=crmBaseState.attach||{};
      crmBaseState.attach[i]={id:pid,name:(row&&row.name)||pid};
      renderBase();
    }});
}
function crmScroll(dir){ var b=document.getElementById('crmBoard'); if(b) b.scrollBy({left:dir*Math.max(300,Math.round(b.clientWidth*0.7)),behavior:'smooth'}); }
function crmUpdateNav(){ var b=document.getElementById('crmBoard'),L=document.getElementById('crmNavL'),R=document.getElementById('crmNavR'); if(!b||!L||!R) return; var max=b.scrollWidth-b.clientWidth-2; if(max<=0){ L.disabled=true; R.disabled=true; return; } L.disabled=(b.scrollLeft<=2); R.disabled=(b.scrollLeft>=max); }
function crmView(v){
  /* ⛒ 443: вид «плитка» -- це НАШ перелік ліцензійних карток. Без кухні його
     немає, і мовчки показати порожнє гірше, ніж не показати нічого. */
  if(v==='tiles' && !CRM_KITCHEN) v='board';
  crmState.view=v; crmViewUI();
  if(v==='board'){ crmShowBoard(); loadBoard(); }
  else if(v==='dashboard'){ crmShowDash(); loadDash(); }
  else if(v==='base'){ crmShowBase(); loadBase(); }
  else { crmShowList(); loadCrm(); }
}
function crmEsc(s){ return (s==null?'':String(s)).replace(/[&<>"]/g,function(m){return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m];}); }
function crmJsq(s){ return String(s).replace(/\\/g,'\\\\').replace(/'/g,"\\'"); }
function crmDate(s){ if(!s) return ''; var p=String(s).slice(0,10).split('-'); return p.length===3?(p[2]+'.'+p[1]+'.'+p[0]):String(s); }
function crmDateTime(s){ if(!s) return ''; var d=crmDate(s); var t=String(s).slice(11,16); return t?(d+' '+t):d; }
function crmInit(n){ var p=(n||'').trim().split(/\s+/); return ((p[0]||'').slice(0,1)+((p[1]||p[0]||'').slice(0,1))).toUpperCase(); }
function crmStat(c){ if(c.archived) return {t:'архів',col:'var(--muted)',bg:'var(--tint-muted)'}; if(c.edition && c.edition!=='trial' && c.edition!=='тріал') return {t:'активна',col:'var(--ok)',bg:'var(--tint-ok)'}; return {t:'тріал',col:'var(--warn)',bg:'var(--tint-warn)'}; }
async function loadCrm(){
  try{
    var d=await fetch('/api/crm/list').then(function(r){return r.json();});
    if(d.error){ document.getElementById('crmMsg').textContent='Розділ доступний лише адміністратору.'; document.getElementById('crmGrid').innerHTML=''; return; }
    crmState.data=d;
    document.getElementById('crmCntActive').textContent=d.counts.active;
    document.getElementById('crmCntArch').textContent=d.counts.archived;
    crmRender();
  }catch(e){ document.getElementById('crmMsg').textContent='Не вдалося завантажити картки.'; }
}
function crmRender(){
  var list = crmState.tab==='active'?crmState.data.active:crmState.data.archived;
  var g=document.getElementById('crmGrid'); g.innerHTML='';
  document.getElementById('crmMsg').textContent = list.length?'':(crmState.tab==='active'?'Поки немає активних клієнтів. Картка створюється під час збірки клієнта (make_client_build).':'Архів порожній.');
  list.forEach(function(c){
    var s=crmStat(c);
    var d=document.createElement('div'); d.className='crmcard'; d.onclick=function(){ openCrmCard(c.customer); };
    d.innerHTML='<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">'
      +'<div style="width:36px;height:36px;border-radius:50%;background:var(--panel);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:var(--accent)">'+crmInit(c.customer)+'</div>'
      +'<div style="min-width:0"><div style="font-weight:600;font-size:13.5px">'+crmEsc(c.customer)+'</div><div style="font-size:11px;color:var(--muted)">оновлень: '+c.applied+'</div></div>'
      +'<span style="margin-left:auto;width:9px;height:9px;border-radius:50%;background:'+s.col+'"></span></div>'
      +'<div style="display:flex;gap:6px;flex-wrap:wrap">'
      +'<span class="crmpill">'+(crmEsc(c.edition)||'—')+'</span>'
      +'<span class="crmpill">v'+(crmEsc(c.version)||'—')+'</span>'
      +(c.expiry?'<span class="crmpill">до '+crmDate(c.expiry)+'</span>':'')
      /* ⭐ C1: скільки в цього контрагента угод — те, чого картка раніше сказати
         не могла в принципі (угода була самою карткою). */
      +(c.deals_total?'<span class="crmpill">угод: '+c.deals_total+(c.live_deals?(' · живих '+c.live_deals):'')+'</span>':'')
      +'</div>';
    g.appendChild(d);
  });
}
/* Довідник контрагентів у памʼять — БЕЗ перемальовування розділу «Клієнти».
   ⛒ Блок «Довідник контрагента» мусить бути в картці незалежно від того, з яких
   дверей її відкрили; для цього потрібен сам запис довідника. */
async function crmEnsureParties(){
  try{
    var dp=await fetch('/api/crm/parties').then(function(r){return r.json();});
    crmBaseState.parties=dp.parties||[]; crmBaseState.counts=dp.counts||{};
    crmBaseState.kinds=dp.kinds||{}; crmBaseState.roles=dp.roles||{};
  }catch(e){}
}
async function openCrmCard(cust,pid){
  if(crmState.lastCard!==cust){ crmEdit={}; crmCard.tab=''; crmCard.flt={}; }
  crmState.lastCard=cust;
  if(!crmState.channels){ try{ crmState.channels=await fetch('/api/crm/channels').then(function(r){return r.json();}); }catch(e){ crmState.channels={}; } }
  if(!crmState.products){ try{ crmState.products=(await fetch('/api/crm/products').then(function(r){return r.json();})).systems||[]; }catch(e){ crmState.products=[]; } }
  var c=await fetch('/api/crm/card?customer='+encodeURIComponent(cust)).then(function(r){return r.json();});
  if(c.error){ return; }
  crmState.cur=c;
  var s=crmStat(c);
  document.getElementById('crmDrawerHead').innerHTML=
     '<div style="width:44px;height:44px;border-radius:50%;background:var(--panel2);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;color:var(--accent);flex:none">'+crmInit(c.customer)+'</div>'
    +'<div style="flex:1;min-width:0"><div style="font-weight:600;font-size:16px">'+crmEsc(c.customer)+'</div><div style="font-size:11.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+(crmEsc((c.profile||{}).org)||(c.archived?'в архіві':'клієнт'))+'</div></div>'
    +'<span style="background:'+s.bg+';color:'+s.col+';border-radius:20px;padding:4px 10px;font-size:11.5px;font-weight:600;flex:none">'+s.t+'</span>'
    +'<button class="modal-x" style="flex:none;margin-left:4px" onclick="closeDrawer()" title="Закрити">✕</button>';
  /* ⭐⭐⭐ ВИПРАВЛЕННЯ 14.08.2026 (B3), яке C3 довів до кінця. Спершу розділ
     «Історія взаємовідносин» жив лише на одному шляху відкриття картки — і
     Андрій, відкривши ту саму картку з Сервіс-центру, його не побачив. Тепер
     СКЛАД КАРТКИ ПРИЇЖДЖАЄ З СЕРВЕРА (`card_layout`), а екран лише малює: обидві
     двері ведуть до однієї картки за побудовою, а не за уважністю. */
  crmCard.kind='party'; crmCard.did=''; crmCard.d=null;
  crmCard.cust=cust; crmCard.c=c;
  crmCard.pid=pid||c.party_id||'';
  if(crmCard.pid && !crmPartyById(crmCard.pid)) await crmEnsureParties();
  crmCard.pr=crmCard.pid?crmPartyById(crmCard.pid):null;
  crmAddr(crmCard.pid?('party='+encodeURIComponent(crmCard.pid)):'');
  crmCard.rows=[];
  await crmFeedFetch(true);
  crmCardPaint();
  document.getElementById('crmDrawer').classList.add('open');
}
/* Розділи, які раніше були вклеєні просто в код відкриття картки. Тепер у
   кожного своя функція — інакше рушій не може ними керувати. */
function crmLicenseHtml(c){
  return '<div class="crmsec"><h4>Ліцензія та версія</h4><div style="display:flex;flex-direction:column;gap:6px">'
    +'<div class="crmrow"><span style="color:var(--muted)">Ліцензія</span><span style="margin-left:auto">'+(crmEsc(c.edition)||'—')+(c.expiry?' · до '+crmDate(c.expiry):'')+'</span></div>'
    +'<div class="crmrow"><span style="color:var(--muted)">Версія</span><span style="margin-left:auto">'+(crmEsc(c.version)||'—')+' · оновлень: '+((c.applied||[]).length)+'</span></div>'
    +'<div class="crmrow"><span style="color:var(--muted)">Ключ ліцензії</span><span style="margin-left:auto">'+(c.license_key?'вшито у збірку':'тріал (без ключа)')+'</span></div>'
    +'</div></div>';
}
/* ⛒ ЦЕ ФОРМА ЗАПИСУ, А НЕ ДРУГИЙ ПЕРЕЛІК. Самі записи спілкування видно у
   стрічці праворуч; показувати їх ще й тут означало б мати на екрані двох
   писарів однієї правди — і людина рахувала б роботу з клієнтом удвічі. */
function crmHistAddHtml(c){
  return '<div class="crmsec"><h4>Додати в історію спілкування</h4>'
    +'<div style="display:flex;gap:6px;margin-bottom:4px;align-items:center">'
    +  '<select id="crmHistType" style="flex:none;cursor:pointer;background:var(--panel2);border:1px solid var(--line);border-radius:8px;color:var(--txt);font-size:12px;padding:8px 6px"><option value="comm">Комунікація</option><option value="note">Нотатка</option><option value="stage">Етап</option></select>'
    +  '<input id="crmHistNote" type="text" placeholder="Що сталося з клієнтом… (Enter — додати)" onkeydown="if(event.key===\'Enter\'){event.preventDefault();crmAddHist(\''+crmJsq(c.customer)+'\');}" style="flex:1;min-width:0;background:var(--panel2);border:1px solid var(--line);border-radius:8px;color:var(--txt);font-size:13px;padding:8px 10px;font-family:inherit">'
    +  '<button class="crmbtn accent" style="flex:none;max-width:120px" onclick="crmAddHist(\''+crmJsq(c.customer)+'\')">Додати</button>'
    +'</div></div>';
}
function closeDrawer(){ document.getElementById('crmDrawer').classList.remove('open'); crmAddr(''); crmEdit={}; crmState.lastCard=null; crmState.lastParty=null; if(crmState.view==='board'){ loadBoard(); } else if(crmState.view==='dashboard'){ loadDash(); } else if(crmState.view==='base'){ loadBase(); } else { loadCrm(); } }
/* ⛒ ВІДМОВА МУСИТЬ БУТИ ВИДНОЮ ТАК САМО, ЯК УСПІХ. До C3 тут був лише зелений
   рядок — і відмова про межу закріплень не мала б чим себе показати.
   ⚠ Кладемо в ЛІВУ ПОЛОВИНУ: полотно картки більше не гортається саме. */
function crmFlash(msg,bad){
  var b=document.getElementById('crmPaneLeft')||document.getElementById('crmDrawerBody');
  if(!b) return;
  var f=document.createElement('div');
  /* 448: помилку читач з екрана мусить почути ОДРАЗУ (alert), а успіх --
     дочекавшись паузи (status). Доти не оголошувалось ані те, ані те. */
  f.setAttribute('role', bad ? 'alert' : 'status');
  f.setAttribute('aria-live', bad ? 'assertive' : 'polite');
  f.textContent=(bad?'✕ ':'✓ ')+msg;
  f.style.cssText='position:sticky;top:0;background:'+(bad?'var(--tint-err)':'var(--tint-ok)')
    +';color:'+(bad?'var(--err)':'var(--ok)')+';border:1px solid '+(bad?'var(--err)':'var(--ok)')
    +';border-radius:8px;padding:7px 10px;font-size:12px;margin-bottom:10px;z-index:5';
  b.insertBefore(f,b.firstChild);
  setTimeout(function(){ if(f.parentNode) f.parentNode.removeChild(f); },bad?5200:2400);
}
/* ⛒ ОДИН ПИСАР АДРЕСИ ЕКРАНА (зміна 181, 15.08.2026). До цього `/?deal=` і
   `/?party=` працювали ЛИШЕ як вхід: відкрив угоду з воронки — у рядку браузера
   лишалась попередня адреса, і скопіювати адресу того, що дивишся, було
   НЕМОЖЛИВО. Форму адреси знає сервер (`entity.screen()`), сторінка лише тримає
   рядок браузера рівно на тій картці, яка зараз відкрита. */
function crmAddr(q){
  /* 🩸 УРОК 15.08.2026: на цій сторінці глобальне імʼя `history` ЗАЙНЯТЕ масивом
     листування чату, тому `history.replaceState` тут — не функція. Адресу пише
     РІВНО `window.history`. І жодного `try{}catch{}` навколо: перша спроба
     ховала цей самий збій у тиху відмову, і адреса мовчки не змінювалась. */
  var h=window.history; if(!h||!h.replaceState) return;
  h.replaceState(null,'',q?(location.pathname+'?'+q):location.pathname);
}
/* ⛒ ПЕРЕМАЛЬОВУЄМО ТУ КАРТКУ, ЩО ВІДКРИТА (зміна 181, 15.08.2026). Раніше
   rerender умів лише картку контрагента, а `openCrmDeal` обнуляє `crmState.cur`
   — тому на картці УГОДИ кожна ✏ і «Прибрати угоду» ставили прапорець і не
   малювали НІЧОГО. Той самий найдорожчий клас: правило жило на одному шляху. */
function crmRerender(){
  /* ⚠ Саме crmCardPaint(), а НЕ crmCardPaintLeft(): «Що потрібно зробити» живе в
     ПРАВІЙ половині картки. Перемалювавши половину, я побачив би ✏ на назві —
     і не побачив би ✏ на наступній дії. Перемальовуємо картку ЦІЛКОМ. */
  if(crmCard&&crmCard.kind==='deal'&&crmCard.did){ crmCardPaint(); return; }
  if(crmState.cur&&crmState.cur.customer) openCrmCard(crmState.cur.customer);
}
function crmEditOn(sec){ crmEdit[sec]=true; crmRerender(); }
function crmEditOff(sec){ delete crmEdit[sec]; crmRerender(); }
var CRM_EDITBTN='<button class="crmbtn" style="flex:none;padding:5px 10px" ';
function crmReadActions(sec,cu,clearFn,doneFn){ var h='<div style="margin-top:8px;display:flex;gap:8px">'; if(doneFn){ h+='<button class="crmbtn" style="flex:none;padding:5px 10px;border-color:var(--ok);color:var(--ok)" onclick="'+doneFn+'(\''+cu+'\')">✓ Виконано</button>'; } h+=CRM_EDITBTN+'onclick="crmEditOn(\''+sec+'\')">✏ Редагувати</button>'; if(clearFn){ h+='<button class="crmbtn" style="flex:none;padding:5px 10px;border-color:var(--err);color:var(--err)" onclick="'+clearFn+'(\''+cu+'\')">✕ Очистити</button>'; } return h+'</div>'; }
function crmBack(){ closeDrawer(); }
function crmNotesHtml(c){
  var cu=crmJsq(c.customer); var nv=c.notes||'';
  if(!crmEdit['notes'] && nv){
    return '<div class="crmsec"><h4>Нотатки</h4>'
     +'<div style="font-size:12.5px;line-height:1.5;white-space:pre-wrap;background:var(--code-bg);border:1px solid var(--line);border-radius:8px;padding:10px 12px">'+crmEsc(nv)+'</div>'
     +crmReadActions('notes',cu,'crmClearNotes')+'</div>';
  }
  return '<div class="crmsec"><h4>Нотатки</h4><textarea id="crmNote" style="'+CRM_INP+';min-height:60px" placeholder="Короткі нотатки по клієнту">'+crmEsc(nv)+'</textarea>'
   +'<div style="display:flex;gap:8px;margin-top:6px"><button class="crmbtn accent" style="flex:none" onclick="crmSaveNote(\''+cu+'\')">Зберегти нотатку</button>'
   +(nv?'<button class="crmbtn" style="flex:none" onclick="crmEditOff(\'notes\')">Скасувати</button>':'')+'</div></div>';
}
async function crmSaveNote(cust){ var v=crmVal('crmNote'); await fetch('/api/crm/note',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:cust,notes:v})}); delete crmEdit['notes']; await openCrmCard(cust); crmFlash('Нотатку збережено'); }
async function crmClearNotes(cust){ await fetch('/api/crm/note',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:cust,notes:''})}); delete crmEdit['notes']; await openCrmCard(cust); crmFlash('Нотатку очищено'); }
/* ⭐⭐⭐ 594: ЗВУЖЕННЯ ВОРОНКИ ЗА ПОЛЕМ КАРТКИ. Перелік полів і їхні значення
   рахує СЕРВЕР (`filters`) — екран свого словника не тримає, інакше перемикач
   не побачив би поля, заведеного адміністратором учора. */
function crmFilterQuery(){
  var f=crmState.filter||{};
  if(!f.field||!f.value) return '';
  return '?field='+encodeURIComponent(f.field)+'&value='+encodeURIComponent(f.value);
}
async function loadBoard(){
  try{
    var b=await fetch('/api/crm/board'+crmFilterQuery()).then(function(r){return r.json();});
    if(b.error){ document.getElementById('crmMsg').textContent=b.error; return; }
    crmState.board=b; renderBoard();
  }catch(e){ document.getElementById('crmMsg').textContent='Не вдалося завантажити воронку.'; }
}
/* Один рядок перемикачів: «Усі» плюс значення кожного поля-списку. */
function crmFilterBar(b){
  var rows=(b&&b.filters)||[]; if(!rows.length) return '';
  var cur=crmState.filter||{field:'',value:''};
  var h='<div class="crmrow" style="gap:10px;flex-wrap:wrap;margin:0 0 10px">';
  h+='<button type="button" class="crmbtn'+(cur.value?'':' on')+'" '
    +'data-fld="" data-val="">Усі</button>';
  rows.forEach(function(f){
    (f.choices||[]).forEach(function(v){
      var on=(cur.field===f.id&&cur.value===v);
      h+='<button type="button" class="crmbtn'+(on?' on':'')+'" data-fld="'
        +crmEsc(f.id)+'" data-val="'+crmEsc(v)+'" title="'+crmEsc(f.name)+'">'
        +crmEsc(v)+'</button>';
    });
  });
  return h+'</div>';
}
function crmFilterWire(box){
  var bs=box.querySelectorAll('button[data-fld]');
  for(var i=0;i<bs.length;i++) bs[i].onclick=function(){
    crmState.filter={field:this.getAttribute('data-fld'),
                     value:this.getAttribute('data-val')};
    loadBoard();
  };
}
/* 449: ОДИН ПИСАР ЗГОРТАННЯ. Показ керується класом на дошці, а не
   перемальовуванням: перемалювати дошку під час перетягування означало б
   обірвати саме те перетягування. */
function crmFoldApply(){
  var bd=document.getElementById('crmBoard');
  var cb=document.getElementById('crmShowEmpty');
  if(bd) bd.classList.toggle('showempty', !!(cb && cb.checked));
}
function crmFoldSay(n){
  var el=document.getElementById('crmFoldWhy');
  if(!el) return;
  el.textContent = n ? ('Порожніх стадій сховано: ' + n + '.') : '';
  crmFoldApply();
}
function renderBoard(){
  var b=crmState.board; if(!b) return;
  var wrap=document.getElementById('crmBoard'); wrap.innerHTML='';
  /* 594: перемикач звуження стоїть НАД дошкою, окремим рядком. */
  var fb=document.getElementById('crmFilterBar');
  if(!fb){ fb=document.createElement('div'); fb.id='crmFilterBar';
           wrap.parentNode.insertBefore(fb, wrap); }
  fb.innerHTML=crmFilterBar(b); crmFilterWire(fb);
  if(crmState.view==='board') document.getElementById('crmMsg').textContent='Перетягни картку між стадіями, щоб змінити статус.';
  /* 449: порожні стадії згортаються (див. заголовок правки). */
  var _empty=0;
  b.stages.forEach(function(st){
    var col=document.createElement('div'); col.className='crmcol'; col.dataset.stage=st;
    if(!(b.counts[st]||0)){ col.classList.add('empty'); _empty++; }
    col.style.background=CRM_STAGE_BG[st]||'var(--board-col-bg)';
    col.ondragover=function(e){ e.preventDefault(); col.classList.add('over'); };
    col.ondragleave=function(){ col.classList.remove('over'); };
    col.ondrop=function(e){ e.preventDefault(); col.classList.remove('over'); crmMove(e.dataTransfer.getData('text/plain'), st); };
    var att=b.attention[st]||0;
    var h=document.createElement('div'); h.className='crmcolh';
    h.style.background=CRM_STAGE_COL[st]||'var(--board-colh-bg)'; h.style.color='var(--on-accent)'; h.style.borderBottom='2px solid var(--on-accent-a28)';
    h.innerHTML='<span>'+crmEsc(st)+'</span>'+(att>0?'<span class="crmbadge" title="потребує уваги">'+att+'</span>':'')+'<span class="crmcnt" style="background:var(--on-accent-a18);border-color:var(--on-accent-a25);color:var(--on-accent)">'+(b.counts[st]||0)+'</span>';
    col.appendChild(h);
    /* ⭐⭐⭐ C1 (15.08.2026): плитка воронки — це УГОДА, а не картка клієнта.
       Ключ плитки — НОМЕР УГОДИ; клієнт стоїть другим рядком. До переїзду тут
       лежали 23 картки, з них 11 — тестувальники CosmetoCard. */
    (b.by_stage[st]||[]).forEach(function(c){
      var d=document.createElement('div'); d.className='crmcard mini'; d.draggable=true;
      d.ondragstart=function(e){ e.dataTransfer.setData('text/plain',c.id); e.dataTransfer.effectAllowed='move';
        /* 449: поки тягнемо -- показуємо ВСІ стадії, зокрема порожні:
           інакше згортання відібрало б саму можливість покласти туди угоду. */
        var bd=document.getElementById('crmBoard'); if(bd) bd.classList.add('dragging'); };
      d.ondragend=function(){ var bd=document.getElementById('crmBoard'); if(bd) bd.classList.remove('dragging'); };
      d.onclick=function(){ openCrmDeal(c.id); };
      var money = c.mrr?(crmEsc(c.mrr)+' '+crmEsc(c.currency||'')+'/міс'):(c.one_time?(crmEsc(c.one_time)+' '+crmEsc(c.currency||'')):'');
      /* 594: плитка каже, чого вона (напрям, категорія) — щоб відфільтрований
         канбан і повний не виглядали однаково. */
      var tags=[]; var fv=c.fields||{};
      for(var fk in fv){ if(fv[fk]) tags.push(String(fv[fk])); }
      var sub = crmEsc(c.client||'без клієнта')+(money?(' · '+money):'')
                +(tags.length?(' · '+crmEsc(tags.join(' · '))):'');
      d.innerHTML='<div style="display:flex;align-items:center;gap:8px">'
        +'<div style="width:28px;height:28px;border-radius:50%;background:var(--panel);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;color:var(--accent);flex:none">'+crmInit(c.client||c.name)+'</div>'
        +'<div style="min-width:0;flex:1"><div style="font-weight:600;font-size:12.5px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+crmEsc(c.name)+'</div><div style="font-size:10.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+sub+'</div></div>'
        +(c.attention>0?'<span class="crmbadge" style="flex:none">'+c.attention+'</span>':'')+'</div>'
        +(c.next_action?'<div style="margin-top:7px;font-size:10.5px;color:var(--accent);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">▶ '+crmEsc(c.next_action)+(c.next_date?(' · '+crmDate(c.next_date)):'')+'</div>':'');
      if(c.due){ d.style.boxShadow='inset 4px 0 0 var(--bad)'; }
      col.appendChild(d);
    });
    wrap.appendChild(col);
  });
  crmFoldSay(_empty);
  setTimeout(crmUpdateNav,0);
}
async function crmMove(did, stage){
  if(!did) return;
  /* ⛒ Стадію рухає УГОДА (крок C1). Відмову показуємо словами: тиха відмова на
     перетягуванні читалась би як «зависло». */
  try{
    var r=await fetch('/api/crm/deal_stage',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id:did,stage:stage})});
    var d=await r.json();
    if(!r.ok||d.error){ crmFlash(d.error||'Стадію не змінено',true); }
  }catch(e){ crmFlash('Стадію не змінено: '+(e.message||e),true); }
  loadBoard();
}
function crmMoney(n,cur){ try{ return Number(n||0).toLocaleString('uk-UA')+' '+(cur||'₴'); }catch(e){ return (n||0)+' '+(cur||'₴'); } }
async function loadDash(){
  try{
    var p=await fetch('/api/crm/pipeline'+crmFilterQuery()).then(function(r){return r.json();});
    if(p.error){ document.getElementById('crmDash').innerHTML='<div style="color:var(--muted)">Доступно лише адміністратору.</div>'; return; }
    renderDash(p);
  }catch(e){ document.getElementById('crmDash').innerHTML='<div style="color:var(--muted)">Не вдалося завантажити дашборд.</div>'; }
}
function renderDash(p){
  /* ⭐ 431: коли валют кілька, сервер спільної суми не віддає — і дашборд
     каже про це словами, а не малює число, якого не існує. */
  var cur=p.currency||'₴';
  var many=!!p.mixed_currency;
  function money2(v){ return many ? '—' : crmMoney(v,cur); }
  function metric(label,val,accent){ return '<div style="background:var(--code-bg);border:1px solid var(--line);border-radius:12px;padding:14px 16px;flex:1;min-width:150px"><div style="font-size:11.5px;color:var(--muted);margin-bottom:6px">'+label+'</div><div style="font-size:21px;font-weight:700;color:'+(accent||'var(--txt)')+'">'+val+'</div></div>'; }
  /* 446: КОЛИ ВАЛЮТ КІЛЬКА, ЖОДНОГО СПІЛЬНОГО ЧИСЛА НЕ МАЛЮЄМО -- ані суми,
     ані ПРОГНОЗУ (доти прогноз лишався поза цією умовою й складав гривні з
     доларами) -- а показуємо суми ПО КОЖНІЙ валюті й КАЖЕМО СЛОВАМИ, чому
     спільного числа немає. Число, яке не може бути правильним, не видається. */
  var metrics='<div style="display:flex;gap:12px;flex-wrap:wrap;margin-bottom:18px">'
    +metric('Живих угод',p.deals)
    +metric('Клієнтів у роботі',p.clients);
  var curs=Object.keys(p.by_currency||{});
  if(many){
    for(var ci=0;ci<curs.length;ci++){
      var cv=p.by_currency[curs[ci]]||{};
      metrics+=metric('Разово, '+curs[ci],crmMoney(cv.one_time||0,curs[ci]));
      metrics+=metric('Щомісяця, '+curs[ci],crmMoney(cv.mrr||0,curs[ci]));
    }
    metrics+=metric('Прогноз (зважений)','—');
  } else {
    metrics+=metric('Разові угоди',money2(p.sum_one_time))
      +metric('Щомісячно (MRR)',money2(p.sum_mrr))
      +metric('Прогноз (зважений)',crmMoney(p.forecast_one_time,cur)+' + '+crmMoney(p.forecast_mrr,cur)+'/міс','var(--ok)');
  }
  metrics+=metric('Потребує уваги',p.due_count,p.due_count?'var(--err)':'var(--ok)')
    +'</div>';
  var curWhy = many
    ? '<p id="crmCurWhy" style="font-size:12.5px;color:var(--gold2);margin:-6px 0 14px">Угоди ведуться в різних валютах ('+crmEsc(curs.join(', '))+') — тому спільної суми немає, показано окремо по кожній.</p>'
    : '<p id="crmCurWhy" style="font-size:12.5px;color:var(--muted);margin:-6px 0 14px">Усі живі угоди в одній валюті ('+crmEsc(cur)+') — суми складаються чесно.</p>';
  var due = p.due.length ? p.due.map(function(x){ return '<div class="crmcard" style="cursor:pointer;margin-bottom:8px" onclick="openCrmDeal(\''+crmJsq(x.deal)+'\')"><div style="display:flex;align-items:center;gap:10px"><span style="width:9px;height:9px;border-radius:50%;background:var(--err);flex:none"></span><div style="flex:1;min-width:0"><div style="font-weight:600;font-size:13px">'+crmEsc(x.name)+' <span style="color:var(--muted);font-weight:400;font-size:11.5px">· '+crmEsc(x.client||'без клієнта')+' · '+crmEsc(x.stage)+'</span></div><div style="font-size:11.5px;color:var(--gold2)">'+crmEsc(x.reason)+'</div></div><span style="color:var(--muted)">›</span></div></div>'; }).join('') : '<div style="font-size:12.5px;color:var(--ok)">✓ Все під контролем — нічого не потребує уваги.</div>';
  var rows='';
  p.stages.forEach(function(s){ var v=p.by_stage_value[s]||{count:0,one_time:0,mrr:0}; if(!v.count) return; rows+='<div class="crmrow" style="padding:7px 0;border-bottom:1px solid var(--line)"><span style="flex:none;width:180px;color:var(--txt-soft)">'+crmEsc(s)+'</span><span style="flex:none;width:44px;color:var(--muted)">'+v.count+'</span><span style="flex:1;text-align:right">'+(many?'—':crmMoney(Math.round(v.one_time),cur))+'</span><span style="flex:1;text-align:right;color:var(--muted)">'+(many?'—':crmMoney(Math.round(v.mrr),cur)+'/міс')+'</span></div>'; });
  var hdr='<div class="crmrow" style="padding:4px 0;font-size:10.5px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted)"><span style="flex:none;width:180px">Стадія</span><span style="flex:none;width:44px">К-сть</span><span style="flex:1;text-align:right">Разові</span><span style="flex:1;text-align:right">MRR</span></div>';
  document.getElementById('crmDash').innerHTML=metrics+curWhy
    +'<h4 style="font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin:0 0 10px">Потребує уваги сьогодні</h4>'+due
    +'<h4 style="font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin:22px 0 6px">Воронка за стадіями</h4>'+hdr+rows;
}
var CRM_INP='background:var(--inp-bg);border:1px solid var(--inp-line);border-radius:7px;color:var(--inp-txt);padding:7px 9px;font-size:12.5px;font-family:inherit;box-sizing:border-box;width:100%';
function crmVal(id){ var el=document.getElementById(id); return el?el.value:''; }
function crmProfileHtml(c){
  var p=c.profile||{}; var cu=crmJsq(c.customer);
  var hasAny=['org','region','industry','website','phone','email','address','about'].some(function(k){return p[k];});
  if(!crmEdit['prof'] && hasAny){
    var labels={org:'Організація',region:'Регіон',industry:'Галузь',website:'Сайт',phone:'Телефон',email:'Пошта',address:'Адреса',about:'Про клієнта'};
    var rows = c.name_en ? '<div class="crmrow"><span style="color:var(--muted)">Імʼя англ.</span><span style="margin-left:auto;text-align:right">'+crmEsc(c.name_en)+'</span></div>' : '';
    ['org','region','industry','website','phone','email','address','about'].forEach(function(k){ if(p[k]) rows+='<div class="crmrow"><span style="color:var(--muted)">'+labels[k]+'</span><span style="margin-left:auto;text-align:right">'+crmEsc(p[k])+'</span></div>'; });
    return '<div class="crmsec"><h4>Профіль організації</h4><div style="display:flex;flex-direction:column;gap:4px">'+rows+'</div>'+crmReadActions('prof',cu,null)+'</div>';
  }
  function f(label,key,ph){ return '<label style="display:flex;flex-direction:column;gap:3px;font-size:11px;color:var(--muted)">'+label+'<input id="crmP_'+key+'" value="'+crmEsc(p[key]||'')+'" placeholder="'+(ph||'')+'" style="'+CRM_INP+'"></label>'; }
  return '<div class="crmsec"><h4>Профіль організації</h4>'
   +'<label style="display:flex;flex-direction:column;gap:3px;font-size:11px;color:var(--muted);margin-bottom:8px">Імʼя англ. (для збірки й назв файлів)<input id="crmP_name_en" value="'+crmEsc(c.name_en||'')+'" placeholder="напр. Smolyar (латиницею)" style="'+CRM_INP+'"></label>'
   +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">'
   +f('Організація','org','повна назва')+f('Регіон','region','місто / країна')
   +f('Галузь','industry','напрям')+f('Сайт','website','')
   +f('Телефон','phone','')+f('Пошта','email','')+'</div>'
   +'<label style="display:flex;flex-direction:column;gap:3px;font-size:11px;color:var(--muted);margin-top:8px">Адреса<input id="crmP_address" value="'+crmEsc(p.address||'')+'" style="'+CRM_INP+'"></label>'
   +'<label style="display:flex;flex-direction:column;gap:3px;font-size:11px;color:var(--muted);margin-top:8px">Про клієнта<textarea id="crmP_about" style="'+CRM_INP+';min-height:48px">'+crmEsc(p.about||'')+'</textarea></label>'
   +'<div style="display:flex;gap:8px;margin-top:8px"><button class="crmbtn accent" style="flex:none" onclick="crmSaveProfile(\''+cu+'\')">Зберегти профіль</button>'
   +(hasAny?'<button class="crmbtn" style="flex:none" onclick="crmEditOff(\'prof\')">Скасувати</button>':'')+'</div></div>';
}
/* ⭐ КРОК B5 (15.08.2026): контактна особа — окремий контрагент, тому її імʼя
   ВЕДЕ в її картку. Адресу дає платформа полем `href` — екран її не складає
   (урок B4: знання, яке живе в екрані, — стеля, якої не видно).
   ⛒ Особа, яка ще не переїхала, чесно каже про це, а не вдає кнопку. */
function crmPersonName(p){
  if(p && p.href) return '<a href="'+crmEsc(crmHref(p.href))+'" style="color:var(--accent);text-decoration:none">'+crmEsc(p.name)+'</a>';
  return crmEsc(p.name)+' <span style="font-size:10.5px;color:var(--muted)">· ще без картки</span>';
}
function crmContactsHtml(c){
  var ct=c.contacts||[];
  var rows = ct.length ? ct.map(function(p,i){
    return '<div style="display:flex;align-items:flex-start;gap:10px;padding:9px;border:1px solid var(--line);border-radius:9px;margin-bottom:6px">'
      +'<div style="width:30px;height:30px;border-radius:50%;background:var(--panel2);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:11px;color:var(--accent);flex:none">'+crmInit(p.name)+'</div>'
      +'<div style="flex:1;min-width:0"><div style="font-weight:600;font-size:12.5px">'+crmPersonName(p)+(p.role?' <span style="color:var(--muted);font-weight:400">· '+crmEsc(p.role)+'</span>':'')+'</div>'
      +'<div style="font-size:11.5px;color:var(--muted)">'+[p.phone,p.email].filter(Boolean).map(crmEsc).join(' · ')+'</div>'
      +(p.note?'<div style="font-size:11.5px;color:var(--muted);margin-top:2px">'+crmEsc(p.note)+'</div>':'')+'</div>'
      +'<span onclick="crmRemoveContact(\''+crmJsq(c.customer)+'\','+i+')" title="Видалити" style="cursor:pointer;color:var(--muted);font-weight:700">✕</span></div>';
  }).join('') : '<div style="font-size:12px;color:var(--muted)">Пов’язаних осіб ще немає.</div>';
  return '<div style="margin-top:16px"><div style="font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:var(--muted);margin-bottom:8px">Пов’язані особи</div>'
   +rows
   +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;margin-top:8px">'
   +'<input id="crmC_name" placeholder="Імʼя" style="'+CRM_INP+'">'
   +'<input id="crmC_role" placeholder="Роль / посада" style="'+CRM_INP+'">'
   +'<input id="crmC_phone" placeholder="Телефон" style="'+CRM_INP+'">'
   +'<input id="crmC_email" placeholder="Пошта" style="'+CRM_INP+'"></div>'
   +'<input id="crmC_note" placeholder="Нотатка" style="'+CRM_INP+';margin-top:6px">'
   +'<button class="crmbtn accent" style="flex:none;margin-top:6px" onclick="crmAddContact(\''+crmJsq(c.customer)+'\')">+ Додати особу</button></div>';
}
async function crmSaveProfile(cust){
  var p={}; ['org','region','industry','website','phone','email','address','about'].forEach(function(k){ var el=document.getElementById('crmP_'+k); if(el) p[k]=el.value; });
  var body={customer:cust,profile:p}; var neEl=document.getElementById('crmP_name_en'); if(neEl) body.name_en=neEl.value;
  await fetch('/api/crm/profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
  delete crmEdit['prof']; await openCrmCard(cust); crmFlash('Профіль збережено');
}
async function crmAddContact(cust){
  var person={name:crmVal('crmC_name'),role:crmVal('crmC_role'),phone:crmVal('crmC_phone'),email:crmVal('crmC_email'),note:crmVal('crmC_note')};
  if(!person.name){ crmFlash('Вкажіть імʼя особи'); return; }
  await fetch('/api/crm/contact',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:cust,contact:person})});
  await openCrmCard(cust); crmFlash('Особу додано');
}
async function crmRemoveContact(cust,i){
  await fetch('/api/crm/contact_remove',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:cust,index:i})});
  openCrmCard(cust);
}
/* ══════════════════════════════════════════════════════════════════════════
   ⭐⭐⭐ КАРТКА УГОДИ (крок C1, 15.08.2026). «Наступна дія», «Вартість угоди» й
   «Архів картки» ПЕРЕЇХАЛИ СЮДИ разом із самими полями: у картці контрагента їх
   більше немає, бо угод у клієнта буває кілька, і сума однієї з них перестала
   бути властивістю клієнта. Кожна дія має СВОЇ двері (`/api/crm/deal_*`) —
   одні двері «зміни щось в угоді» мовчки губили б незнайоме поле.
   ══════════════════════════════════════════════════════════════════════════ */
/* ── ХТО ВЕДЕ КЛІЄНТА (крок D1, 15.08.2026) ──────────────────────
   ⛒ Екран НЕ рахує, кого можна призначити: і чинний відповідальний, і
   перелік вибору приїжджають від писаря довідника. Власний список людей
   у браузері розійшовся б із сервером на першому ж звільненні. */
function crmManagerHtml(x){
  var m=(x.rel&&x.rel.manager)||null;
  if(!m) return '';
  var cur=m.manager||null;
  var who = cur
    ? ('<div style="color:var(--accent)">'+crmEsc(cur.name)+'</div>'
       +(cur.dismissed?'<div class="crmnote-warn">Цей працівник звільнений. Клієнт лишається за ним, доки ви не передасте його іншому.</div>':'')
       +(cur.gone?'<div class="crmnote-warn">Такого працівника більше немає в оргструктурі — передайте клієнта чинному.</div>':''))
    : '<div style="color:var(--muted)">не призначено</div>';
  var opts='<option value="">— не призначено —</option>';
  (m.options||[]).forEach(function(o){
    opts+='<option value="'+crmEsc(o.id)+'"'+((cur&&cur.id===o.id)?' selected':'')+'>'+crmEsc(o.name)+'</option>';
  });
  var door = m.no_people
    ? '<div style="font-size:12px;color:var(--muted);margin-top:8px">Працівників у платформі ще немає — призначати нема кого. Люди заводяться в розділі «Люди».</div>'
    : ('<div style="display:flex;gap:6px;margin-top:8px">'
       +'<select id="crmMgrSel" style="'+CRM_INP+'">'+opts+'</select>'
       +'<button class="crmbtn accent" style="flex:none;max-width:150px" onclick="crmSetManager(\''+crmJsq(m.party_id)+'\')">Зберегти</button></div>');
  return '<div class="crmsec"><h4>Відповідальний</h4>'+who+door+'</div>';
}
async function crmSetManager(pid){
  var el=document.getElementById('crmMgrSel');
  var v=el?el.value:'';
  try{
    var r=await fetch('/api/crm/party_manager',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({id:pid,employee:v})});
    var d=await r.json();
    /* ⛒ ВІДМОВУ ЛЮДИНА ЧИТАЄ СЛОВАМИ. */
    if(!r.ok||d.error){ crmFlash(d.error||'Не вдалося змінити відповідального',true); return; }
    crmFlash(v?'Відповідального призначено':'Відповідального знято');
  }catch(e){ crmFlash('Не вдалося змінити відповідального: '+(e.message||e),true); return; }
  await crmFeedFetch(true); crmCardPaintLeft(); crmFeedPaint();
}
function crmDealsHtml(x){
  var c=x.c; var pid=x.pid||(c&&c.party_id)||'';
  /* ⛒ ПЕРЕЛІК УГОД БЕРЕМО З КАРТКИ САМОГО КОНТРАГЕНТА, а не з картки-ліцензії:
     у контактної особи картки-ліцензії немає взагалі, і список був би порожнім
     при живих угодах. */
  var list=(x.rel&&x.rel.deals)||(c&&c.deals)||[];
  var rows=list.map(function(d){
    var money=d.mrr?(crmEsc(d.mrr)+' '+crmEsc(d.currency||'')+'/міс'):(d.one_time?(crmEsc(d.one_time)+' '+crmEsc(d.currency||'')):'');
    return '<div class="crmrow" style="gap:8px;align-items:flex-start;cursor:pointer" onclick="openCrmDeal(\''+crmJsq(d.id)+'\')">'
      +'<span class="crmpill" style="flex:none">'+crmEsc(d.stage)+'</span>'
      +'<span style="flex:1;min-width:0"><span style="color:var(--accent)">'+crmEsc(d.name)+'</span>'
      +(money?('<span style="color:var(--muted)"> · '+money+'</span>'):'')
      +(d.next_action?('<div style="font-size:11px;color:var(--muted)">▶ '+crmEsc(d.next_action)+(d.next_date?(' · до '+crmDate(d.next_date)):'')+'</div>'):'')
      +'</span>'
      +(d.attention>0?'<span class="crmbadge" style="flex:none">'+d.attention+'</span>':'')
      +(d.archived?'<span style="color:var(--muted);font-size:11px;flex:none">архів</span>':'')
      +'</div>';
  }).join('');
  /* ⭐ ЗМІНА 188: та сама кнопка веде в ТЕ САМЕ вікно, що й «+ Створити угоду»
     на воронці — з уже підставленим клієнтом. Окремого поля тут більше немає:
     два поля народження угоди означали б двох писарів. */
  var add = pid
    ? ('<div style="margin-top:8px">'
       +'<button class="crmbtn accent" style="flex:none;max-width:190px" onclick="crmMakeOpen(\''+crmJsq(pid)+'\')">+ Завести угоду</button></div>')
    : '<div style="font-size:12px;color:var(--muted);margin-top:8px">Щоб завести угоду, картку треба привʼязати до контрагента.</div>';
  return '<div class="crmsec"><h4>Угоди <span style="color:var(--muted)">'+list.length+'</span></h4>'
    +(rows||'<div style="font-size:12px;color:var(--muted)">Угод ще немає. Продаж живе в УГОДІ — заведіть її, і воронка рахуватиме саме її, а не картку.</div>')
    +add+'</div>';
}
async function crmDealPost(path,body,okMsg,say){
  /* ⛒ ЗМІНА 188: ВІДМОВА МУСИТЬ ЛЕЖАТИ ТАМ, КУДИ ЛЮДИНА ДИВИТЬСЯ. `crmFlash`
     кладе рядок у картку — а вікно «Нова угода» відкривається і з воронки, де
     картки немає взагалі, і відмова тихо гинула б за склом. */
  var tell=say||crmFlash;
  try{
    var r=await fetch('/api/crm/'+path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    var d=await r.json();
    /* ⛒ ВІДМОВУ ЛЮДИНА ЧИТАЄ СЛОВАМИ. Мовчазне «нічого не сталось» — це та сама
       тиха відмова, від якої ми лікували ворота платформи. */
    if(!r.ok||d.error){ tell(d.error||'Не вдалося зберегти',true); return null; }
    if(okMsg) tell(okMsg);
    return d;
  }catch(e){ tell('Не вдалося зберегти: '+(e.message||e),true); return null; }
}
async function crmDealSet(path,body,msg){
  var d=await crmDealPost(path,Object.assign({id:crmCard.did},body||{}),msg);
  if(d){ crmEdit={}; await openCrmDeal(crmCard.did); if(crmState.view==='board') loadBoard(); }
}
function crmDealHeadHtml(d){
  var opts=(d.stages||[]).map(function(s){ return '<option value="'+crmEsc(s)+'"'+(s===d.stage?' selected':'')+'>'+crmEsc(s)+'</option>'; }).join('');
  var cl={name:d.client||'',href:d.client_href||'',party_id:d.party_id||''};
  var client = cl.name
    ? '<a href="'+crmEsc(crmHref(cl.href))+'" style="color:var(--accent);text-decoration:none">'+crmEsc(cl.name)+'</a>'
    : '<span style="color:var(--bad)">клієнта немає — угода ні до кого не привʼязана</span>';
  var name = crmEdit['dname']
    ? ('<div style="display:flex;gap:6px"><input id="crmDName" value="'+crmEsc(d.name)+'" style="'+CRM_INP+'">'
       +'<button class="crmbtn accent" style="flex:none" onclick="crmDealSet(\'deal_name\',{name:crmVal(\'crmDName\')},\'Назву змінено — номер угоди той самий\')">Зберегти</button>'
       +'<button class="crmbtn" style="flex:none" onclick="crmEditOff(\'dname\')">Скасувати</button></div>')
    : ('<div class="crmrow"><span style="font-size:14px;font-weight:600">'+crmEsc(d.name)+'</span>'
       +'<button class="crmbtn" style="flex:none;margin-left:auto;padding:4px 9px" onclick="crmEditOn(\'dname\')">✏</button></div>');
  var att = d.attention>0
    ? ('<div class="crmrow"><span style="color:var(--muted)">Потребує уваги</span>'
       +'<span class="crmbadge" style="margin-left:auto">'+d.attention+'</span>'
       +'<button class="crmbtn" style="flex:none;padding:4px 9px" onclick="crmDealSet(\'deal_attention\',{value:0},\'Увагу опрацьовано\')">✓ опрацьовано</button></div>')
    : '';
  var due = d.due_reason ? '<div class="crmnote-warn">'+crmEsc(d.due_reason)+'</div>' : '';
  return '<div class="crmsec" style="margin-top:0"><h4>Угода</h4>'+name
    +'<div class="crmrow"><span style="color:var(--muted)">Клієнт</span><span style="margin-left:auto">'+client+'</span></div>'
    +'<div class="crmrow"><span style="color:var(--muted)">Стадія</span><span style="margin-left:auto">'
    +'<select onchange="crmDealSet(\'deal_stage\',{stage:this.value},\'Стадію змінено\')" style="cursor:pointer;background:var(--panel2);border:1px solid var(--line);border-radius:8px;color:var(--txt);font-size:12px;padding:6px 8px">'+opts+'</select></span></div>'
    +att+due+'</div>';
}
function crmDealAmountHtml(d){
  var a={one_time:d.one_time||'',mrr:d.mrr||'',currency:d.currency||''}; var cur=crmEsc(a.currency||'₴'); var has=(a.one_time||a.mrr);
  if(!crmEdit['damount'] && has){
    var parts=[]; if(a.one_time) parts.push('Разовий: <b>'+crmEsc(a.one_time)+' '+cur+'</b>');
    if(a.mrr) parts.push('Щомісяця: <b>'+crmEsc(a.mrr)+' '+cur+'</b>');
    return '<div class="crmsec"><h4>Вартість угоди</h4><div style="font-size:13px">'+parts.join(' · ')
      +'<div style="margin-top:8px"><button class="crmbtn" style="flex:none;padding:5px 10px" onclick="crmEditOn(\'damount\')">✏ Редагувати</button></div></div></div>';
  }
  return '<div class="crmsec"><h4>Вартість угоди</h4>'
   +'<div style="display:grid;grid-template-columns:1fr 1fr 64px;gap:6px">'
   +'<label style="font-size:11px;color:var(--muted);display:flex;flex-direction:column;gap:3px">Разовий<input id="crmDA_one" value="'+crmEsc(a.one_time||'')+'" style="'+CRM_INP+'"></label>'
   +'<label style="font-size:11px;color:var(--muted);display:flex;flex-direction:column;gap:3px">Щомісяця<input id="crmDA_mrr" value="'+crmEsc(a.mrr||'')+'" style="'+CRM_INP+'"></label>'
   +'<label style="font-size:11px;color:var(--muted);display:flex;flex-direction:column;gap:3px">Валюта<input id="crmDA_cur" value="'+cur+'" style="'+CRM_INP+'"></label>'
   +'</div><div style="display:flex;gap:8px;margin-top:6px">'
   +'<button class="crmbtn accent" style="flex:none" onclick="crmDealSet(\'deal_amount\',{amount:{one_time:crmVal(\'crmDA_one\'),mrr:crmVal(\'crmDA_mrr\'),currency:crmVal(\'crmDA_cur\')}},\'Суму збережено\')">Зберегти суму</button>'
   +(has?'<button class="crmbtn" style="flex:none" onclick="crmEditOff(\'damount\')">Скасувати</button>':'')+'</div></div>';
}
function crmDealNextHtml(d){
  var na={text:d.next_action||'',date:d.next_date||''};
  if(!crmEdit['dna'] && na.text){
    return '<div class="crmsec" style="margin-top:0"><h4>Що потрібно зробити</h4>'
     +'<div style="background:var(--tint-accent);border:1px solid var(--accent);border-radius:8px;padding:10px 12px;font-size:12.5px">'
     +'<b style="color:var(--accent)">▶ Далі:</b> '+crmEsc(na.text)+(na.date?' <span style="color:var(--muted)">· до '+crmDate(na.date)+'</span>':'')
     +'<div style="margin-top:8px;display:flex;gap:8px">'
     +'<button class="crmbtn" style="flex:none;padding:5px 10px;border-color:var(--ok);color:var(--ok)" onclick="crmDealSet(\'deal_action_done\',{},\'Дію виконано, увагу опрацьовано\')">✓ Виконано</button>'
     +'<button class="crmbtn" style="flex:none;padding:5px 10px" onclick="crmEditOn(\'dna\')">✏ Редагувати</button>'
     +'<button class="crmbtn" style="flex:none;padding:5px 10px;border-color:var(--err);color:var(--err)" onclick="crmDealSet(\'deal_next_action\',{text:\'\',date:\'\'},\'Дію очищено\')">✕ Очистити</button>'
     +'</div></div></div>';
  }
  return '<div class="crmsec" style="margin-top:0"><h4>Що потрібно зробити</h4>'
   +'<div style="display:flex;gap:6px">'
   +'<input id="crmDNA_text" value="'+crmEsc(na.text||'')+'" placeholder="напр. передзвонити, надіслати КП" style="'+CRM_INP+'">'
   +'<input id="crmDNA_date" type="date" value="'+crmEsc(na.date||'')+'" style="'+CRM_INP+';max-width:150px">'
   +'</div><div style="display:flex;gap:8px;margin-top:6px">'
   +'<button class="crmbtn accent" style="flex:none" onclick="crmDealSet(\'deal_next_action\',{text:crmVal(\'crmDNA_text\'),date:crmVal(\'crmDNA_date\')},\'Дію збережено\')">Зберегти дію</button>'
   +(na.text?'<button class="crmbtn" style="flex:none" onclick="crmEditOff(\'dna\')">Скасувати</button>':'')+'</div></div>';
}
function crmDealPeopleHtml(d){
  var ppl=d.people||[];
  var rows=ppl.map(function(p){
    return '<div class="crmrow" style="gap:8px"><a href="'+crmEsc(crmHref(p.href))+'" style="color:var(--accent);text-decoration:none">'+crmEsc(p.name)+'</a>'
      +(p.note?'<span style="color:var(--muted)"> · '+crmEsc(p.note)+'</span>':'')
      +'<button class="crmbtn" style="flex:none;margin-left:auto;padding:4px 9px;border-color:var(--err);color:var(--err)" onclick="crmDealSet(\'deal_person_remove\',{party:\''+crmJsq(p.party_id)+'\'},\'Особу прибрано з угоди\')">✕</button></div>';
  }).join('');
  var pick=((crmBaseState&&crmBaseState.parties)||[]).map(function(pr){
    return '<option value="'+crmEsc(pr.id)+'">'+crmEsc(pr.name)+' ('+crmEsc(pr.id)+')</option>';
  }).join('');
  return '<div class="crmsec"><h4>Контактні особи угоди <span style="color:var(--muted)">'+ppl.length+'</span></h4>'
    +(rows||'<div style="font-size:12px;color:var(--muted)">Осіб ще не додано. Директор і бухгалтер в одній угоді — нормальна робота, а не виняток.</div>')
    +'<div style="display:flex;gap:6px;margin-top:8px">'
    +'<select id="crmDP_id" style="'+CRM_INP+';max-width:220px"><option value="">— оберіть особу —</option>'+pick+'</select>'
    +'<input id="crmDP_note" placeholder="підпис (напр. бухгалтер)" style="'+CRM_INP+'">'
    +'<button class="crmbtn accent" style="flex:none;max-width:120px" onclick="crmDealSet(\'deal_person\',{party:crmVal(\'crmDP_id\'),note:crmVal(\'crmDP_note\')},\'Особу додано в угоду\')">+ Додати</button>'
    +'</div></div>';
}
function crmDealLicenseHtml(d){
  var l=d.license||{};
  if(!l.customer){
    return '<div class="crmsec"><h4>Ліцензія та оновлення клієнта</h4>'
      +'<div style="font-size:12px;color:var(--muted)">У цього контрагента немає картки ліцензії — продаж є, збірки ще немає.</div></div>';
  }
  return '<div class="crmsec"><h4>Ліцензія та оновлення клієнта</h4>'
    +'<div style="display:flex;flex-direction:column;gap:6px">'
    +'<div class="crmrow"><span style="color:var(--muted)">Картка ліцензії</span><span style="margin-left:auto">'+crmEsc(l.customer)+'</span></div>'
    +'<div class="crmrow"><span style="color:var(--muted)">Ліцензія</span><span style="margin-left:auto">'+(crmEsc(l.edition)||'—')+(l.expiry?' · до '+crmDate(l.expiry):'')+'</span></div>'
    +'<div class="crmrow"><span style="color:var(--muted)">Версія</span><span style="margin-left:auto">'+(crmEsc(l.version)||'—')+' · оновлень: '+(l.applied||0)+'</span></div>'
    +'<div class="crmrow"><span style="color:var(--muted)">Ключ</span><span style="margin-left:auto">'+(l.has_key?'вшито у збірку':'тріал (без ключа)')+'</span></div>'
    +'</div><div style="font-size:11px;color:var(--muted);margin-top:6px">Ліцензія живе в картці клієнта — угода її лише читає (крок C1).</div></div>';
}
function crmDealNoteHtml(d){
  var nv=d.note||'';
  if(!crmEdit['dnote'] && nv){
    return '<div class="crmsec"><h4>Нотатки угоди</h4>'
     +'<div style="font-size:12.5px;line-height:1.5;white-space:pre-wrap;background:var(--card-bg);border:1px solid var(--line);border-radius:8px;padding:10px 12px">'+crmEsc(nv)+'</div>'
     +'<div style="margin-top:8px"><button class="crmbtn" style="flex:none;padding:5px 10px" onclick="crmEditOn(\'dnote\')">✏ Редагувати</button></div></div>';
  }
  return '<div class="crmsec"><h4>Нотатки угоди</h4><textarea id="crmDNote" style="'+CRM_INP+';min-height:60px" placeholder="Короткі нотатки по цій угоді">'+crmEsc(nv)+'</textarea>'
   +'<div style="display:flex;gap:8px;margin-top:6px"><button class="crmbtn accent" style="flex:none" onclick="crmDealSet(\'deal_note\',{note:crmVal(\'crmDNote\')},\'Нотатку збережено\')">Зберегти нотатку</button>'
   +(nv?'<button class="crmbtn" style="flex:none" onclick="crmEditOff(\'dnote\')">Скасувати</button>':'')+'</div></div>';
}
/* ⭐⭐⭐ КРОК C2 (15.08.2026) — ЛИСТУВАННЯ З АДРЕСОЮ УГОДИ.
   Токен у темі формує СЕРВЕР (`deal_mail.token`) і привозить у картці полем
   `mail_token`. Зібрати «[SF-…]» тут рядком означало б завести ДРУГИЙ формат
   адреси — і вхідне перестало б упізнавати власний токен на першій же правці. */
function crmDealMailHtml(d){
  var tok=d.mail_token||'';
  return '<div class="crmsec"><h4>Листування угоди</h4>'
   +'<div style="font-size:12.5px;line-height:1.5">Адреса цієї угоди — '
   +'<b style="color:var(--accent)">'+crmEsc(tok)+'</b>.</div>'
   +'<div style="font-size:11.5px;color:var(--muted);line-height:1.5;margin-top:4px">'
   +'Вона їде в темі листа й повертається у «Re:» — тому відповідь ляже саме сюди, '
   +'а не в сусідню угоду з тим самим клієнтом. Лист відкриється у твоїй поштовій '
   +'програмі: платформа пошту не надсилає.</div>'
   +'<div style="margin-top:8px"><button class="crmbtn accent" style="flex:none" onclick="crmDealMail()">✉ Написати з угоди</button></div>'
   +'<div id="crmDealMailArea"></div></div>';
}
async function crmDealMail(){
  var area=document.getElementById('crmDealMailArea'); if(!area) return;
  var d=await crmDealPost('deal_mail',{id:crmCard.did},'');
  if(!d) return;
  area.innerHTML='<div style="margin-top:8px;border:1px solid var(--line);border-radius:8px;padding:10px">'
    +'<input id="crmDM_to" value="'+crmEsc(d.to||'')+'" placeholder="кому (email)" style="'+CRM_INP+';margin-bottom:6px">'
    +'<input id="crmDM_sub" value="'+crmEsc(d.subject||'')+'" placeholder="тема листа — про що він" style="'+CRM_INP+';margin-bottom:6px">'
    +'<div style="font-size:11px;color:var(--muted);margin:-2px 0 6px">Адреса '+crmEsc(d.token||'')+' у темі — по ній повернеться відповідь клієнта. Допиши, ПРО ЩО лист: без теми платформа його не випустить.</div>'
    +'<textarea id="crmDM_body" placeholder="текст листа" style="'+CRM_INP+';min-height:70px"></textarea>'
    +'<div style="display:flex;gap:8px;margin-top:6px">'
    +'<button class="crmbtn accent" style="flex:none" onclick="crmDealMailOpen()">Відкрити у пошті й зафіксувати</button>'
    +'<button class="crmbtn" style="flex:none" onclick="document.getElementById(\'crmDealMailArea\').innerHTML=\'\'">Скасувати</button>'
    +'</div></div>';
}
/* ⭐⭐⭐ ЗМІНА 183. ДВЕРІ НАЗОВНІ ПЕРЕВІРЯЛИ ЛИШЕ «КОМУ». Адресу угоди — те
   єдине, заради чого писався C2, — можна було стерти з теми одним Backspace, і
   лист усе одно відкривався в пошті: відповідь клієнта поверталась у нікуди, а
   в протоколі стояло бадьоре «сформовано». Ворота тепер у ПИСАРІ
   (`deal_mail.check_mail_ready`), а екран іде ТИМ САМИМ шляхом, що й будь-який
   інший вхід:
     1) сервер приводить тему до канонічної (`stamp` поверне стерту адресу —
        складати «[SF-…]» тут рядком не можна, це був би ДРУГИЙ формат адреси);
     2) сервер судить готовність і пише слід;
     3) і лише тоді відкривається поштова програма — рівно з тим текстом, який
        платформа щойно записала в протокол.
   ⛒ Відмову людина читає СЛОВАМИ в самій картці (`crmDealPost` → `crmFlash`).
   Системне вікно `alert` заборонене: воно спиняє сторінку і виглядає як збій. */
async function crmDealMailOpen(){
  var to=crmVal('crmDM_to'), sub=crmVal('crmDM_sub'), body=crmVal('crmDM_body');
  var prep=await crmDealPost('deal_mail',{id:crmCard.did,subject:sub,to:to},'');
  if(!prep) return;
  var sub2=prep.subject||sub, to2=prep.to||to;
  /* ⛒ Тиха підстановка заборонена: якщо адресу довелось повернути в тему,
     людина мусить це ПРОЧИТАТИ, а не здогадатись. */
  if(sub2!==sub) crmFlash('Адресу угоди повернуто в тему — без неї відповідь клієнта не знайшла б дороги назад.');
  var el=document.getElementById('crmDM_sub'); if(el) el.value=sub2;
  var sent=await crmDealPost('deal_mail_sent',{id:crmCard.did,subject:sub2,to:to2},'');
  if(!sent) return;
  var url='mailto:'+encodeURIComponent(to2)+'?subject='+encodeURIComponent(sub2)+'&body='+encodeURIComponent(body);
  var w=window.open(url,'_blank');
  /* ⛒ Не мовчати, коли вікно не відкрилось: інакше слід у протоколі є, а листа
     людина не бачила — і не має ЧОГО натиснути. */
  if(!w){
    var area=document.getElementById('crmDealMailArea');
    if(area) area.insertAdjacentHTML('beforeend','<div style="margin-top:8px;font-size:12px">Поштова програма не відкрилась сама — <a href="'+crmEsc(url)+'" style="color:var(--accent)">відкрий лист тут</a>.</div>');
    crmFlash('Лист сформовано, слід у протоколі є');
    return;
  }
  crmFlash('Лист сформовано, слід у протоколі є');
  crmEdit={}; await openCrmDeal(crmCard.did);
}
function crmDealArchiveHtml(d){
  /* ⛒ ВИДАЛЕННЯ НЕ ВГАДУЄ ФОРМУ і не мовчить про наслідки: перед ним людина
     бачить ПЕРЕЛІК того, що зникне (урок 10.08). */
  var del = crmEdit['ddel']
    ? ('<div class="crmnote-warn" style="margin-top:8px">Буде прибрано: угода «'+crmEsc(d.name)+'» ('+crmEsc(d.id)+')'
       +' · її звʼязок із клієнтом'+((d.people||[]).length?(' · '+(d.people||[]).length+' звʼязок з особами'):'')
       +'. Рядки протоколу НЕ зникають.'
       +'<div style="display:flex;gap:8px;margin-top:8px">'
       +'<button class="crmbtn" style="flex:none;border-color:var(--err);color:var(--err)" onclick="crmDealDelete()">Так, прибрати</button>'
       +'<button class="crmbtn" style="flex:none" onclick="crmEditOff(\'ddel\')">Скасувати</button></div></div>')
    : '';
  return '<div style="display:flex;gap:8px;margin:18px 0 8px">'
    +(d.archived
       ? '<button class="crmbtn accent" onclick="crmDealSet(\'deal_archive\',{on:false},\'Угоду повернуто в роботу\')">↩ Повернути з архіву</button>'
       : '<button class="crmbtn warn" onclick="crmDealSet(\'deal_archive\',{on:true},\'Угоду перенесено в архів\')">Перенести в архів</button>')
    +'<button class="crmbtn" style="border-color:var(--err);color:var(--err)" onclick="crmEditOn(\'ddel\')">Прибрати угоду</button>'
    +'</div>'+del;
}
async function crmDealDelete(){
  var d=await crmDealPost('deal_delete',{id:crmCard.did},'Угоду прибрано');
  if(d){ crmEdit={}; closeDrawer(); }
}
/* ⭐ ДВЕРІ В КАРТКУ УГОДИ. Той самий рушій, що й у контрагента: сервер каже
   склад (`card_layout`), екран лише малює. */
async function openCrmDeal(did){
  if(!did) return;
  if(crmState.lastCard!=='deal:'+did){ crmEdit={}; crmCard.tab=''; crmCard.flt={}; }
  crmState.lastCard='deal:'+did;
  if(!(crmBaseState&&(crmBaseState.parties||[]).length)) await crmEnsureParties();
  var d;
  try{
    var r=await fetch('/api/crm/deal_card?id='+encodeURIComponent(did));
    d=await r.json();
    if(!r.ok||d.error){ crmFlash((d&&d.error)||'Угоду не знайдено',true); return; }
  }catch(e){ crmFlash('Не вдалося відкрити угоду: '+(e.message||e),true); return; }
  crmState.cur=null;
  crmCard.kind='deal'; crmCard.did=did; crmCard.d=d; crmAddr('deal='+encodeURIComponent(did));
  crmCard.cust=''; crmCard.c=null; crmCard.pid=d.party_id||''; crmCard.pr=crmCard.pid?crmPartyById(crmCard.pid):null;
  crmCard.rows=[];
  await crmFeedFetch(true);
  var cl=d.client||'без клієнта';
  document.getElementById('crmDrawerHead').innerHTML=
     '<div style="width:44px;height:44px;border-radius:50%;background:var(--panel2);border:1px solid var(--line);display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:var(--accent);flex:none">'+crmEsc(d.id)+'</div>'
    +'<div style="flex:1;min-width:0"><div style="font-weight:600;font-size:16px">'+crmEsc(d.name)+'</div>'
    +'<div style="font-size:11.5px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis">угода · '+crmEsc(cl)+' · '+crmEsc(d.stage)+'</div></div>'
    +'<button class="modal-x" style="flex:none;margin-left:4px" onclick="closeDrawer()" title="Закрити">✕</button>';
  crmCardPaint();
  document.getElementById('crmDrawer').classList.add('open');
}
function crmCommsHub(c){
  var ch=crmState.channels||{}; var tg=ch.telegram&&ch.telegram.available;
  var t='';
  t+='<button class="crmtool" onclick="crmEmail(\''+crmJsq(c.customer)+'\')">✉️ Лист</button>';
  t+='<button class="crmtool" onclick="crmCallLog(\''+crmJsq(c.customer)+'\')">📞 Дзвінок</button>';
  t+='<button class="crmtool" onclick="crmKP(\''+crmJsq(c.customer)+'\')">📄 КП</button>';
  t+= tg ? '<button class="crmtool" onclick="crmTelegram(\''+crmJsq(c.customer)+'\')">💬 Telegram</button>'
        : '<button class="crmtool off" onclick="crmConnect(\'telegram\')" title="Канал не підключено">💬 Telegram · підключити</button>';
  return '<div class="crmsec" style="margin-top:0"><h4>Комунікації</h4><div style="display:flex;flex-wrap:wrap;gap:6px">'+t+'</div><div id="crmCommArea"></div></div>';
}
/* ⭐ C1: бейдж «увага» живе на УГОДІ — записана комунікація його вже не гасить
   із картки клієнта. Опрацювати увагу можна в самій угоді (там і кнопка). */
async function crmComm(cust,channel,note){ await fetch('/api/crm/comm',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:cust,channel:channel,note:note})}); if(crmState.view==='board') loadBoard(); await openCrmCard(cust); crmFlash('Зафіксовано в історію'); }
async function crmAddHist(cust){ var note=crmVal('crmHistNote'); if(!note||!note.trim()){ return; } var ty=crmVal('crmHistType')||'note'; await fetch('/api/crm/comm',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:cust,channel:ty,note:note.trim()})}); await openCrmCard(cust); crmFlash('Запис додано в історію'); }
function crmConnect(ch){ if(ch==='telegram'){ window.open('/telegram','_blank'); } }
// Сервіс-центр — лише для адмін-збірки. У клієнта кнопку ховаємо.
/* 524g: VKHID U SERVIS-TSENTR PYTAYE OBYDVI POLOVYNY. Ranishe tut stoialo pytannia PRO ZBIRKU, i tilky pro neyi: u nashiy zbirtsi vidpovid zavzhdy 'tak', tozh kliyentskyy administrator na mashyni Andriya bachyv vkhid i distavav vidmovu. Teper -- te same yedyne dzherelo, shcho y u reshty kukhni. Movchannia lyshaie knopku skhovanoyu. */
/* 524d: tut zhyv riadok, yakyi khovav stару knopku vkhodu v CRM. Takoyi knopky v rozmitsi bilshe NEMAYE zhodnoyi -- mertvyi zamok hirshyi za vidsutniy, bo stvoriuie vrazhennia, shcho vkhid sterezhetsia. Vkhid u kukhniu zhyve na domashniy (miniService) i pytaie /api/crm/access. */
function crmEmail(cust){
  var c=crmState.cur||{}; var to=(c.profile&&c.profile.email)||((c.contacts||[])[0]||{}).email||'';
  document.getElementById('crmCommArea').innerHTML='<div style="margin-top:8px;border:1px solid var(--line);border-radius:8px;padding:10px">'
    +'<input id="crmEM_to" value="'+crmEsc(to)+'" placeholder="кому (email)" style="'+CRM_INP+';margin-bottom:6px">'
    +'<input id="crmEM_sub" placeholder="тема" style="'+CRM_INP+';margin-bottom:6px">'
    +'<textarea id="crmEM_body" placeholder="текст листа" style="'+CRM_INP+';min-height:70px"></textarea>'
    +'<button class="crmbtn accent" style="flex:none;margin-top:6px" onclick="crmEmailSend(\''+crmJsq(cust)+'\')">Відкрити у пошті й зафіксувати</button></div>';
}
function crmEmailSend(cust){
  var to=crmVal('crmEM_to'),sub=crmVal('crmEM_sub'),body=crmVal('crmEM_body');
  if(!to){ alert('Вкажіть email'); return; }
  window.open('mailto:'+encodeURIComponent(to)+'?subject='+encodeURIComponent(sub)+'&body='+encodeURIComponent(body),'_blank');
  crmComm(cust,'email','Лист: '+(sub||'(без теми)')+' → '+to);
}
function crmCallLog(cust){
  document.getElementById('crmCommArea').innerHTML='<div style="margin-top:8px;border:1px solid var(--line);border-radius:8px;padding:10px">'
    +'<textarea id="crmCL_note" placeholder="Результат дзвінка / зустрічі" style="'+CRM_INP+';min-height:60px"></textarea>'
    +'<button class="crmbtn accent" style="flex:none;margin-top:6px" onclick="crmComm(\''+crmJsq(cust)+'\',\'call\',crmVal(\'crmCL_note\'))">Зафіксувати дзвінок</button></div>';
}
function crmTelegram(cust){
  document.getElementById('crmCommArea').innerHTML='<div style="margin-top:8px;border:1px solid var(--line);border-radius:8px;padding:10px">'
    +'<textarea id="crmTG_note" placeholder="Повідомлення / нотатка" style="'+CRM_INP+';min-height:60px"></textarea>'
    +'<button class="crmbtn accent" style="flex:none;margin-top:6px" onclick="crmComm(\''+crmJsq(cust)+'\',\'telegram\',crmVal(\'crmTG_note\'))">Зафіксувати в історію</button></div>';
}
function crmKP(cust){
  var c=crmState.cur||{}; var p=c.profile||{}; var dl=c.deal||{};
  var kp='КОМЕРЦІЙНА ПРОПОЗИЦІЯ\n\nКлієнт: '+(c.customer||'')+(p.org?(' ('+p.org+')'):'')+'\nДата: '+new Date().toISOString().slice(0,10)
    +'\n\nПродукт: SensFlow — локальна платформа ШІ-агентів.\n\nУмови:\n- Разовий платіж: '+(dl.one_time||'—')+' '+(dl.currency||'')
    +'\n- Щомісячна ліцензія: '+(dl.mrr||'—')+' '+(dl.currency||'')+'\n\nКонтакт: '+(((c.contacts||[])[0]||{}).name||'')+'\n';
  document.getElementById('crmCommArea').innerHTML='<div style="margin-top:8px;border:1px solid var(--line);border-radius:8px;padding:10px"><textarea style="'+CRM_INP+';min-height:160px">'+crmEsc(kp)+'</textarea><div style="font-size:11px;color:var(--muted);margin-top:6px">Чернетку КП згенеровано з даних картки — скопіюй або доопрацюй. Повноцінний документ — наступним кроком.</div></div>';
}
/* ⭐⭐⭐ 07.08.2026, ЕТАП 4. ЩО САМЕ КУПИВ ЦЕЙ КЛІЄНТ.
   Три стани, і вони РІЗНІ навмисно:
     набору немає  -> їде увесь продукт (так у всіх, кого вже обслуговуємо);
     список        -> їдуть рівно ці системи;
     порожній список -> платформа без систем.
   Стан написано СЛОВАМИ, а не лише кольором: колір сам по собі нічого не
   пояснює людині, яка вирішує, що клієнт отримає за свої гроші. */
function crmSystemsHtml(c){
  var cu=crmJsq(c.customer);
  var all=(crmState.products||[]);
  var named=Object.prototype.hasOwnProperty.call(c,'systems') && c.systems!==null;
  var sel=named?(c.systems||[]):[];
  var state = !named ? {t:'Набір не названий — їде увесь продукт ('+all.length+')', col:'var(--muted)'}
            : (sel.length===0 ? {t:'Лише платформа — жодної системи', col:'var(--warn)'}
                              : {t:'Обрано '+sel.length+' із '+all.length, col:'var(--accent)'});
  var rows=all.map(function(x){
    var on=named && sel.indexOf(x.id)>=0;
    return '<label class="crmsysrow"><input type="checkbox" class="crmsysbox" value="'+crmEsc(x.id)+'"'+(on?' checked':'')+'>'
         + '<span class="crmsysname">'+crmEsc(x.name)+'</span>'
         + '<span class="crmsysid">'+crmEsc(x.id)+'</span></label>';
  }).join('') || '<div style="font-size:12px;color:var(--muted)">Перелік систем не завантажився.</div>';
  return '<div class="crmsec"><h4>Які системи купив клієнт</h4>'
   +'<div style="font-size:12.5px;color:'+state.col+';margin-bottom:8px">'+crmEsc(state.t)+'</div>'
   +'<div class="crmsyslist" onchange="crmSysCountUpdate()">'+rows+'</div>'
   // ⭐ 07.08.2026, зауваження Андрія з живої збірки: після збереження він бачив
   // лише короткий спалах «Набір збережено» і не знав, скільки саме обрано.
   // Лічильник живий: він показує стан ПЕРЕД натисканням і не зникає після.
   +'<div id="crmSysCount" style="font-size:12.5px;color:var(--accent);margin-top:8px;font-weight:600"></div>'
   +'<div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">'
   +'<button class="crmbtn accent" style="flex:none" onclick="crmSaveSystems(\''+cu+'\')">Зберегти набір</button>'
   +'<button class="crmbtn" style="flex:none" onclick="crmMarkAllSystems(true)">Позначити всі</button>'
   +'<button class="crmbtn" style="flex:none" onclick="crmMarkAllSystems(false)">Зняти всі</button>'
   +(named?'<button class="crmbtn warn" style="flex:none" onclick="crmClearSystems(\''+cu+'\')">Повернути «увесь продукт»</button>':'')
   +'</div>'
   +'<div style="font-size:11.5px;color:var(--muted);margin-top:6px;line-height:1.5">'
   +'Непродані системи не потрапляють ані в збірку, ані в оновлення — їх у клієнта фізично немає. '
   +'Поки набір не названий, клієнт отримує увесь продукт, як і раніше.</div>'
   +'</div>';
}
function crmSysCountUpdate(){
  var b=document.querySelectorAll('.crmsysbox'), n=0;
  for(var i=0;i<b.length;i++){ if(b[i].checked) n++; }
  var el=document.getElementById('crmSysCount');
  if(!el) return;
  el.textContent = (n===0)
     ? ('Позначено: 0 з '+b.length+' — після збереження клієнт матиме лише платформу')
     : ('Позначено: '+n+' з '+b.length);
  el.style.color = (n===0) ? 'var(--warn)' : 'var(--accent)';
}
function crmMarkAllSystems(on){
  var b=document.querySelectorAll('.crmsysbox'); for(var i=0;i<b.length;i++){ b[i].checked=!!on; }
  crmSysCountUpdate();
}
function crmSysCountInit(){ try{ crmSysCountUpdate(); }catch(e){} }
async function crmSaveSystems(cust){
  var b=document.querySelectorAll('.crmsysbox'), picked=[];
  for(var i=0;i<b.length;i++){ if(b[i].checked) picked.push(b[i].value); }
  if(picked.length===0 && !confirm('Зберегти набір БЕЗ жодної системи?\n\nКлієнт отримає лише платформу.')) return;
  var r=await fetch('/api/crm/systems',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({customer:cust,systems:picked})});
  if(!r.ok){ var e={}; try{ e=await r.json(); }catch(_){}
    crmFlash(e.message||'Набір не збережено'); return; }
  await openCrmCard(cust); crmFlash('Набір систем збережено');
}
async function crmClearSystems(cust){
  if(!confirm('Прибрати набір?\n\nКлієнт знову отримуватиме УВЕСЬ продукт.')) return;
  await fetch('/api/crm/systems',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({customer:cust,systems:null})});
  await openCrmCard(cust); crmFlash('Набір прибрано — їде увесь продукт');
}
function crmDossierHtml(c){
  var cu=crmJsq(c.customer); var dv=c.dossier||'';
  if(!crmEdit['doss'] && dv){
    return '<div class="crmsec"><h4>Додаткова інформація про клієнта</h4>'
     +'<div style="font-size:12.5px;line-height:1.5;white-space:pre-wrap;background:var(--code-bg);border:1px solid var(--line);border-radius:8px;padding:10px 12px">'+crmEsc(dv)+'</div>'
     +crmReadActions('doss',cu,'crmClearDossier')+'</div>';
  }
  return '<div class="crmsec"><h4>Додаткова інформація про клієнта</h4>'
   +'<textarea id="crmDoss" style="'+CRM_INP+';min-height:150px" placeholder="Профіль, історія знайомства, домовленості, обіцянки, оточення… Доповнюється вручну й автоматично.">'+crmEsc(dv)+'</textarea>'
   +'<div style="display:flex;gap:8px;margin-top:6px"><button class="crmbtn accent" style="flex:none" onclick="crmSaveDossier(\''+cu+'\')">Зберегти інформацію</button>'
   +(dv?'<button class="crmbtn" style="flex:none" onclick="crmEditOff(\'doss\')">Скасувати</button>':'')+'</div></div>';
}
async function crmSaveDossier(cust){ await fetch('/api/crm/dossier',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:cust,text:crmVal('crmDoss')})}); delete crmEdit['doss']; await openCrmCard(cust); crmFlash('Інформацію збережено'); }
async function crmClearDossier(cust){ if(!confirm('Очистити додаткову інформацію?')) return; await fetch('/api/crm/dossier',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({customer:cust,text:''})}); delete crmEdit['doss']; await openCrmCard(cust); crmFlash('Очищено'); }
/* crm_core.js END */
