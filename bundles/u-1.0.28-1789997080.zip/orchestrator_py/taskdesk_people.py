# -*- coding: utf-8 -*-
"""
taskdesk_people.py — ОРГСТРУКТУРА TASK DESK: підрозділи, посади, працівники.

Крок 1.1 етапу 1 (проєкт: «Аудити та стратегії\\TaskDesk_етап1_детальний_проєкт_06.08.2026.md»).
Це фундамент, якого в платформі не було взагалі: сьогодні вона одноосібна й
поняття «працівник», «підрозділ», «хто чий керівник» не існує ніде.

ТРИ ЗАКОНИ, ЗА ЯКИМИ ЦЕЙ ФАЙЛ ЗБУДОВАНО (уклад узятий із `scheduler.py`,
де він уже доведений):
  1. ОДИН НОРМАЛІЗАТОР — `_normalize()`. Будь-який запис, хоч побитий, виходить
     звідси з повним набором полів. Зламаність — це ОЗНАКА (`broken` +
     `broken_reason`), а не окреме життя й не тиша.
  2. ОДИН ЧИТАЧ — `load()`. І людина, і будь-який інший код беруть правду звідси.
     `read_text` цього файла стану є РІВНО В ОДНОМУ місці модуля.
  3. ОДИН ПИСАР — `save()`. Кожна зміна лягає в ЗАГАЛЬНИЙ ПРОТОКОЛ платформи
     (`protocol.jsonl`) — з дієсловом, головною річчю і тим, ХТО діяв. Тому
     журнал оргструктури дописується в одному місці, а не в десяти, і не має
     ні стелі, ні власного формату.

⭐⭐⭐ ГОЛОВНЕ АРХІТЕКТУРНЕ РІШЕННЯ: «ХТО ЧИЙ КЕРІВНИК» НЕ ЗБЕРІГАЄТЬСЯ.
Воно ОБЧИСЛЮЄТЬСЯ з дерева підрозділів при читанні (`manager_of`). Якби керівник
лежав полем у працівника, ми б отримали двох писарів однієї правди: перемістили
підрозділ — і половина карток тихо бреше. Похідні поля не лягають на диск ніколи
(`DERIVED_*`), рівно як у планувальнику.

⚠ ПРАЦІВНИКА НЕ ВИДАЛЯЮТЬ. Звільнений стає неактивним: нових задач не отримує,
але лишається у всіх старих записах. Видалення осиротило б історію задач, а
історія — це те, заради чого Task Desk узагалі будується. Тому функції видалення
працівника в цьому модулі НЕМАЄ (це перевіряє чек деревом коду).
"""

import json
import re
import uuid
from pathlib import Path

import clock          # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import entity          # спільне ІМʼЯ речі
import protocol        # спільний ЖУРНАЛ усіх дій платформи
import one_writer

# Тека стану Task Desk. У клієнта вона своя; чеки відводять її вбік через
# config.STATE_DIR, тому бойова тека від прогонів не смітиться.
DESK_DIR = config.STATE_DIR / "taskdesk"

# ⛒ ДРУГИЙ ЗАМОК (27.08.2026): чек, завантажений не через файл, не сміє
# працювати по бойовому стану — тут лежать живі люди, ролі й задачі.
config.refuse_live_state_for_checks(__name__)
PEOPLE_JSON = DESK_DIR / "people.json"

# ⛒ СТЕЛІ БІЛЬШЕ НЕМАЄ. Історія компанії — це роки; будь-яке число тут
# означало б, що найдавніше тихо зникає саме тоді, коли воно найцінніше.
# Новий слід іде в `protocol.jsonl`, який не викидає нічого.
# Старий список `audit[]` лишається на диску ЗАМОРОЖЕНИМ (див. `save`).

# Дієслова, якими писар оргструктури має право підписати зміну. `org.legacy`
# сюди не входить свідомо: ним підписані лише СТАРІ записи, і видати його
# за сьогоднішню дію не можна.
ORG_WRITE_ACTIONS = tuple(a for a in protocol.ORG_ACTIONS
                          if a != protocol.A_ORG_LEGACY)


def org_ref() -> str:
    """Оргструктура як ціле — головна річ для змін, що стосуються КОМПАНІЇ
    (посада, горизонт), а не якогось одного підрозділу."""
    return entity.ref(entity.KIND_ORG, entity.ORG_COMPANY)


def unit_ref(unit_id) -> str:
    return entity.ref(entity.KIND_UNIT, _s(unit_id))


def person_ref(emp_id) -> str:
    return entity.person_of_employee(_s(emp_id))

# ⭐ ГОРИЗОНТИ — ВІСІМ ГОТОВИХ МІСЦЬ (слово Андрія 30.08.2026). Номер це і
# назва, і висота: окремого поля порядку немає СВІДОМО.
HORIZON_MAX = 8
HORIZON_NUMBERS = tuple(str(i) for i in range(1, HORIZON_MAX + 1))
# ⛒ ЩО ТАКЕ КОЛІР — сказано ТУТ і більше ніде. Колір набирає людина, а все
# набране людиною потрапляє в картинку як розмітка; тому придатність кольору
# судить один сторож, а не кожен читач по-своєму.
_HORIZON_COLOR_RE = re.compile(r"^#(?:[0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$")


def is_horizon_color(raw) -> bool:
    """Чи є це кольором, придатним до малювання."""
    return bool(_HORIZON_COLOR_RE.match((raw or "").strip()))

# Похідні поля: ОБЧИСЛЮЮТЬСЯ при читанні й НІКОЛИ не лежать на диску.
DERIVED_UNIT = ("broken", "broken_reason", "depth", "path", "head_name",
                # ⭐ «Живий» — це просто відсутність дати ліквідації. Тримати
                # ще й окрему галочку означало б двох писарів однієї правди.
                "alive",
                # ⭐ Скільки людей накриває горизонт цього підрозділу.
                # Нуль при заведеному горизонті означає, що вибір не дав
                # нічого — і екран мусить сказати про це одразу.
                "horizon_reaches")
# ⭐ Горизонт працівника ОБЧИСЛЮЄТЬСЯ (свій, інакше свого підрозділу),
# тому лягати на диск він не сміє: другий писар розійшовся б із першим.
DERIVED_EMP = ("broken", "broken_reason", "manager_id", "manager_name", "unit_name",
               "position_name", "can_receive_tasks", "direct_report_ids", "photo_url",
               # ⭐ ЗАМІЩЕННЯ (зміна 224): на диску лежить лише ПЕРІОД, а
               # «хто зараз за кого» ОБЧИСЛЮЄТЬСЯ. Зберігати обчислене
               # означало б завести другого писаря, який завтра відстане
               # від календаря.
               "absent_now", "deputy_id", "deputy_name", "absent_from",
               "absent_to", "deputy_broken", "principal_ids", "principal_names",
               "horizon_effective_id")

# Фото працівників лежать поруч зі станом; у картці зберігається лише імʼя файла.
PHOTOS_DIR = DESK_DIR / "photos"

# ⭐ Фото приймається за ВМІСТОМ, а не за назвою: «фото.png», усередині якого
# лежить не картинка, — найдешевший спосіб покласти в теку клієнта що завгодно.
PHOTO_KINDS = (
    (b"\x89PNG\r\n\x1a\n", "png", "image/png"),
    (b"\xff\xd8\xff", "jpg", "image/jpeg"),
    (b"RIFF", "webp", "image/webp"),
)
MAX_PHOTO_BYTES = 2 * 1024 * 1024


class PeopleError(Exception):
    """Відмова писаря, названа людськими словами. Тиші тут не буває."""


# ---------------------------------------------------------------------------
# ОДИН НОРМАЛІЗАТОР
# ---------------------------------------------------------------------------
def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _check_card_fields(fields: dict):
    """Перевірка полів картки. Кожна відмова називає причину словами —
    мовчазне «зрізали й записали» заборонене."""
    b = _s(fields.get("birthday"))
    if b and not re.match(r"^\d{4}-\d{2}-\d{2}$", b):
        raise PeopleError("день народження пишеться як 1980-05-17 (рік-місяць-день); "
                          "у картці людині він показується як 17.05.1980")
    for key, human in (("phone_mobile", "мобільний"), ("phone_work", "робочий")):
        v = _s(fields.get(key))
        if v and len(re.sub(r"\D", "", v)) < 7:
            raise PeopleError("%s телефон «%s» не схожий на номер" % (human, v))
    e = _s(fields.get("email"))
    if e and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", e):
        raise PeopleError("пошта «%s» не схожа на адресу" % e)
    ph = _s(fields.get("photo"))
    if ph and ("/" in ph or "\\" in ph or ".." in ph):
        raise PeopleError("у картці зберігається лише імʼя файла фото, не шлях")


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЗАМІЩЕННЯ НА ЧАС ВІДСУТНОСТІ (зміна 224, 26.08.2026).
#
# КОРІНЬ: права в Task Desk прибиті до `id` людини. Людина пішла у відпустку —
# і все, що чекало саме її руки, стоїть. Обхідні шляхи псували правду: або
# адміністратор міняв виконавця (задача назавжди переставала бути задачею Y),
# або постановник переставляв сам — а якщо у відпустці постановник, приймати
# роботу не було кому взагалі.
#
# РІШЕННЯ: не копія задачі й не нова стадія, а ШАР НАД РОЛЯМИ — за формою
# такий самий, як уже наявний шар адміністратора. На диску лежить лише ПЕРІОД
# з делегатом; «хто зараз за кого» рахується з календаря при читанні.
#
# 🩸 Рішення Андрія 26.08.2026: делегат бере ПОВНІ права відсутнього, і кожна
# його дія підписана «Х (заміщує Y)».
# ---------------------------------------------------------------------------
DATE_LEN = 10                       # 2026-09-01


def today() -> str:
    """Сьогоднішня дата ОДНИМ писарем часу. Заміщення живе за календарем, тому
    брати день з `datetime` машини заборонено так само, як і час."""
    return clock.now()[:DATE_LEN]


def _norm_absences(raw) -> list:
    """Періоди відсутності в єдиному вигляді. Побите значення не валить читання
    оргструктури: воно просто не стає періодом."""
    out = []
    for a in (raw or []):
        if not isinstance(a, dict):
            continue
        item = {"id": _s(a.get("id")) or _new_id("abs"),
                "from": _s(a.get("from"))[:DATE_LEN],
                "to": _s(a.get("to"))[:DATE_LEN],
                "delegate_id": _s(a.get("delegate_id")),
                "reason": _s(a.get("reason"))}
        if not (item["from"] and item["to"] and item["delegate_id"]):
            continue
        out.append(item)
    return out


def _active_absence(emp: dict, day: str) -> dict:
    """Період, який триває САМЕ ЗАРАЗ. Кінці включно: «по 14.09» означає, що
    14.09 людини ще немає."""
    for a in (emp.get("absences") or []):
        if a["from"] <= day <= a["to"]:
            return a
    return {}


def _check_absence_dates(date_from: str, date_to: str):
    for v, human in ((date_from, "початок"), (date_to, "кінець")):
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", _s(v)):
            raise PeopleError("%s відсутності пишеться як 2026-09-01 "
                              "(рік-місяць-день)" % human)
    if _s(date_to) < _s(date_from):
        raise PeopleError("кінець відсутності раніший за початок")


def _new_id(prefix: str) -> str:
    return "%s-%s" % (prefix, uuid.uuid4().hex[:8])


def _unit_chain(units_by_id: dict, unit_id: str) -> list:
    """Ланцюг підрозділів від заданого до кореня. Цикл НЕ вішає систему:
    щойно вузол повторився — ланцюг обривається (а сам цикл позначається)."""
    chain, seen = [], set()
    cur = _s(unit_id)
    while cur and cur in units_by_id and cur not in seen:
        seen.add(cur)
        chain.append(cur)
        cur = _s(units_by_id[cur].get("parent_id"))
    return chain


def _normalize(raw) -> dict:
    """ЄДИНЕ представлення оргструктури. Приймає будь-що, віддає повний запис."""
    if not isinstance(raw, dict):
        raw = {}

    units, positions, employees = [], [], []
    for u in (raw.get("units") or []):
        if not isinstance(u, dict):
            continue
        units.append({"id": _s(u.get("id")) or _new_id("unit"),
                      "name": _s(u.get("name")),
                      "parent_id": _s(u.get("parent_id")),
                      "head_employee_id": _s(u.get("head_employee_id")),
                      # ⭐ Горизонт цілого підрозділу (зміна 282). Діє на тих,
                      # чий unit_id — САМЕ цей підрозділ, і не спускається
                      # нижче по дереву.
                      "horizon_id": _s(u.get("horizon_id")),
                      # ⭐ ЛІКВІДАЦІЯ (зміна 350). Дата, а не галочка: історія
                      # компанії має казати КОЛИ, а не лише «вже нема».
                      "liquidated_at": _s(u.get("liquidated_at"))})
    for p in (raw.get("positions") or []):
        if not isinstance(p, dict):
            continue
        positions.append({"id": _s(p.get("id")) or _new_id("pos"),
                          "name": _s(p.get("name"))})
    for e in (raw.get("employees") or []):
        if not isinstance(e, dict):
            continue
        employees.append({"id": _s(e.get("id")) or _new_id("emp"),
                          "full_name": _s(e.get("full_name")),
                          "unit_id": _s(e.get("unit_id")),
                          "position_id": _s(e.get("position_id")),
                          "email": _s(e.get("email")),
                          "telegram_id": _s(e.get("telegram_id")),
                          # ⭐ Картка працівника (рішення Андрія 06.08.2026).
                          # «У кого в підпорядкуванні» і «ким керує» тут НЕ
                          # зберігаються: вони обчислюються з дерева.
                          "birthday": _s(e.get("birthday")),
                          "phone_mobile": _s(e.get("phone_mobile")),
                          "phone_work": _s(e.get("phone_work")),
                          "photo": _s(e.get("photo")),
                          "active": bool(e.get("active", True)),
                          "hired_at": _s(e.get("hired_at")),
                          "dismissed_at": _s(e.get("dismissed_at")),
                          # ⭐ Періоди відсутності з делегатом (зміна 224).
                          # ⭐ Горизонт людини (зміна 282). У людини він ОДИН.
                          "horizon_id": _s(e.get("horizon_id")),
                          "absences": _norm_absences(e.get("absences"))})

    # ⭐ ГОРИЗОНТИ (зміни 282, 297): вісім готових МІСЦЬ з номерами 1..8.
    # Горизонт має лише НОМЕР і КОЛІР. Назви немає свідомо — це візуальний
    # орієнтир; поля порядку немає свідомо — порядок і є номер.
    horizons, seen_h = [], set()
    for h in (raw.get("horizons") or []):
        if not isinstance(h, dict):
            continue
        num = _s(h.get("id"))
        if num not in HORIZON_NUMBERS or num in seen_h:
            continue
        seen_h.add(num)
        horizons.append({"id": num, "color": _s(h.get("color"))})
    horizons.sort(key=lambda x: int(x["id"]))
    hor_ids = {h["id"] for h in horizons}

    units_by_id = {u["id"]: u for u in units}
    pos_by_id = {p["id"]: p for p in positions}
    emp_by_id = {e["id"]: e for e in employees}

    # ── підрозділи: глибина, шлях і чесна ознака зламаності ────────────────
    for u in units:
        reasons = []
        parent = u["parent_id"]
        if parent and parent not in units_by_id:
            reasons.append("батьківського підрозділу «%s» немає" % parent)
        chain = _unit_chain(units_by_id, u["id"])
        # Цикл: піднімаючись угору, знову впираємось у себе.
        cur, seen, cycle = _s(u["parent_id"]), set(), False
        while cur and cur in units_by_id and cur not in seen:
            if cur == u["id"]:
                cycle = True
                break
            seen.add(cur)
            cur = _s(units_by_id[cur].get("parent_id"))
        if cycle:
            reasons.append("підрозділ підпорядкований сам собі (кільце в дереві)")
        head = u["head_employee_id"]
        if head and head not in emp_by_id:
            reasons.append("керівника «%s» немає серед працівників" % head)
        if not u["name"]:
            reasons.append("немає назви")
        u["depth"] = len(chain) - 1 if chain else 0
        u["path"] = " / ".join(_s(units_by_id[c]["name"]) for c in reversed(chain))
        u["head_name"] = _s(emp_by_id.get(head, {}).get("full_name"))
        u["broken"] = bool(reasons)
        u["broken_reason"] = "; ".join(reasons)
        u["alive"] = not u["liquidated_at"]

    # ── працівники: керівник ОБЧИСЛЮЄТЬСЯ, а не зберігається ───────────────
    for e in employees:
        reasons = []
        if not e["full_name"]:
            reasons.append("немає ПІБ")
        if e["unit_id"] and e["unit_id"] not in units_by_id:
            reasons.append("підрозділу «%s» немає" % e["unit_id"])
        if e["position_id"] and e["position_id"] not in pos_by_id:
            reasons.append("посади «%s» немає" % e["position_id"])
        e["unit_name"] = _s(units_by_id.get(e["unit_id"], {}).get("name"))
        e["position_name"] = _s(pos_by_id.get(e["position_id"], {}).get("name"))
        e["manager_id"] = _manager_id(units_by_id, e)
        e["photo_url"] = ("taskdesk/photos/%s" % e["photo"]) if e["photo"] else ""
        e["can_receive_tasks"] = bool(e["active"]) and not reasons
        e["broken"] = bool(reasons)
        e["broken_reason"] = "; ".join(reasons)

    # ── ЗАМІЩЕННЯ: хто зараз відсутній і хто за нього (зміна 224) ─────────
    # ⭐⭐⭐ ЗАМІЩЕННЯ НЕ ТРАНЗИТИВНЕ І НЕ ЛАНЦЮГОВЕ. Ланцюг тут не будується
    # ФІЗИЧНО: список принципалів береться ОДНИМ проходом по тих, хто назвав
    # цю людину делегатом. Якщо делегат сам відсутній — заміщення мертве, а не
    # передається далі: інакше через три картки права розповзлись би по всій
    # компанії, і ніхто б не довів, звідки вони взялись.
    day = today()
    for e in employees:
        act = _active_absence(e, day)
        e["absent_now"] = bool(act)
        e["absent_from"] = _s(act.get("from")) if act else ""
        e["absent_to"] = _s(act.get("to")) if act else ""
        e["deputy_id"] = _s(act.get("delegate_id")) if act else ""
    for e in employees:
        dep = emp_by_id.get(e["deputy_id"]) if e["deputy_id"] else None
        e["deputy_name"] = _s(dep.get("full_name")) if dep else ""
        # Чесна ознака: делегата назвали, а він не може прийняти права.
        why = ""
        if e["absent_now"] and e["deputy_id"]:
            if not dep:
                why = "делегата «%s» немає серед працівників" % e["deputy_id"]
            elif not dep.get("active"):
                why = "делегат звільнений"
            elif dep.get("absent_now"):
                why = "делегат сам відсутній"
        e["deputy_broken"] = why
    for e in employees:
        # Кого ця людина заміщує ПРЯМО ЗАРАЗ.
        # ⛒ ОДИН СТОРОЖ НА ОДНЕ ПРАВИЛО. Тут навмисно НЕМАЄ ні
        # «o["absent_now"]», ні «o["id"] != e["id"]»: перше вже сказане тим, що
        # делегат зʼявляється лише на час періоду (`_active_absence`), друге —
        # тим, що самозаміщення завжди означає «делегат сам відсутній» і ловиться
        # `deputy_broken`. Два сторожі на одне правило — це нуль сторожів:
        # зняття будь-якого поодинці нічого не ламає, і мутація йде непоміченою.
        for_whom = [o["id"] for o in employees
                    if o["deputy_id"] == e["id"] and not o["deputy_broken"]]
        e["principal_ids"] = for_whom
        e["principal_names"] = [_s(emp_by_id.get(i, {}).get("full_name"))
                                for i in for_whom]

    # «Ким керує» — теж обчислюване: прямі підлеглі це ті, для кого ця людина
    # вийшла керівником. Зберігати цей список означало б другого писаря правди.
    reports = {}
    for e in employees:
        if e["manager_id"]:
            reports.setdefault(e["manager_id"], []).append(e["id"])
    for e in employees:
        e["manager_name"] = _s(emp_by_id.get(e["manager_id"], {}).get("full_name"))
        e["direct_report_ids"] = reports.get(e["id"], [])

    # ⭐ ДІЙСНИЙ ГОРИЗОНТ (зміна 282). Свій горизонт людини сильніший за
    # горизонт її підрозділу — часткове правило б'є загальне. Посилання на
    # горизонт, якого немає в переліку, вважається порожнім: схема не сміє
    # малювати смугу, якої не існує.
    for e in employees:
        own = e.get("horizon_id") or ""
        if own not in hor_ids:
            own = ""
        if not own:
            u = units_by_id.get(e.get("unit_id"), {})
            # ⭐ Слово Андрія 30.08.2026: горизонт ПІДРОЗДІЛУ не діє на самого
            # КЕРІВНИКА цього підрозділу. Він структурно на щабель вище за
            # своїх людей і стоїть на смузі керівників, а не на їхній.
            if _s(u.get("head_employee_id")) != e["id"]:
                own = u.get("horizon_id") or ""
                if own not in hor_ids:
                    own = ""
        e["horizon_effective_id"] = own

    # ⭐ Скільки людей дістає горизонт ВІД ЦЬОГО підрозділу. Керівник сюди не
    # рахується — на нього горизонт підрозділу не діє (правило 293).
    for u in units:
        u["horizon_reaches"] = sum(
            1 for e in employees
            if e.get("unit_id") == u["id"] and e.get("active")
            and e["id"] != _s(u.get("head_employee_id"))
            and e.get("horizon_effective_id") == _s(u.get("horizon_id"))
            and _s(u.get("horizon_id")))

    return {"units": units, "positions": positions, "employees": employees,
            "horizons": horizons,
            "audit": [a for a in (raw.get("audit") or []) if isinstance(a, dict)]}


def _manager_id(units_by_id: dict, emp: dict) -> str:
    """Керівник працівника — керівник його підрозділу; якщо працівник САМ
    керівник цього підрозділу, піднімаємось на рівень вище. Кільце в дереві не
    вішає розрахунок: ланцюг уже обірваний у `_unit_chain`."""
    chain = _unit_chain(units_by_id, emp.get("unit_id"))
    for unit_id in chain:
        head = _s(units_by_id[unit_id].get("head_employee_id"))
        if head and head != emp.get("id"):
            return head
    return ""


def _strip_derived(state: dict) -> dict:
    """Те, що лягає на диск: без жодного обчисленого поля."""
    out = {"units": [], "positions": [], "employees": [],
           "horizons": [dict(h) for h in (state.get("horizons") or [])],
           "audit": list(state.get("audit") or [])}
    for u in state.get("units") or []:
        out["units"].append({k: v for k, v in u.items() if k not in DERIVED_UNIT})
    for p in state.get("positions") or []:
        out["positions"].append(dict(p))
    for e in state.get("employees") or []:
        out["employees"].append({k: v for k, v in e.items() if k not in DERIVED_EMP})
    return out


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ
# ---------------------------------------------------------------------------
def load() -> dict:
    """ЄДИНИЙ ЧИТАЧ оргструктури. Побитий файл не зникає: він повертається
    порожньою структурою з причиною в `unreadable_reason`, і писар відмовиться
    писати поверх нього (fail-closed над чужою роботою)."""
    if not PEOPLE_JSON.exists():
        st = _normalize({})
        st["unreadable_reason"] = ""
        return st
    try:
        raw = one_writer.read_json(PEOPLE_JSON)
        if not isinstance(raw, dict):
            st = _normalize({})
            st["unreadable_reason"] = ("у файлі не оргструктура, а %s"
                                       % type(raw).__name__)
            return st
        st = _normalize(raw)
        st["unreadable_reason"] = ""
        return st
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception as e:
        st = _normalize({})
        st["unreadable_reason"] = "файл не читається: %s" % type(e).__name__
        return st


def company_name() -> str:
    """⭐ 616. ЯК НАЗИВАЄТЬСЯ ЦЯ КОМПАНІЯ — ОДИН ПИСАР, І ВІН ТУТ.

    ⛒ Своєї назви платформа окремо не тримає, і заводити другу не можна:
    назва вже названа один раз — у ВЕРШИНІ оргструктури. Доти цю відповідь
    рахували два місця (прайс КП і замовлення в магазині), а два писарі
    однієї назви розходяться на першому ж перейменуванні.
    ⛒ Немає оргструктури — немає назви, і той, хто питає, обходиться без неї.
    """
    try:
        rows = units() or []
    except Exception:
        return ""
    have = {_s(u.get("id")) for u in rows}
    for u in rows:
        if _s(u.get("parent")) not in have:
            return _s(u.get("name"))
    return ""


def units(include_liquidated: bool = False) -> list:
    """⭐ Ліквідований підрозділ НЕ показується за замовчуванням — так само, як
    звільнений працівник. Він не зник: щоб побачити всіх, треба попросити явно.
    Так перелік підрозділів лишається переліком ТОГО, ЩО ПРАЦЮЄ, а історія
    нікуди не дівається."""
    out = load()["units"]
    return out if include_liquidated else [u for u in out if u["alive"]]


def positions() -> list:
    return load()["positions"]


def employees(include_dismissed: bool = False) -> list:
    """⭐ 06.08.2026 (Андрій): звільнений НЕ показується за замовчуванням.
    Він не зник — щоб побачити всіх, треба попросити явно
    (`include_dismissed=True`). Так список працівників лишається списком тих,
    хто працює, а історія нікуди не дівається."""
    out = load()["employees"]
    return out if include_dismissed else [e for e in out if e["active"]]


def employee(emp_id: str) -> dict:
    for e in load()["employees"]:
        if e["id"] == _s(emp_id):
            return e
    return None


def unit(unit_id: str) -> dict:
    for u in load()["units"]:
        if u["id"] == _s(unit_id):
            return u
    return None


def manager_of(emp_id: str) -> str:
    """Хто керівник цього працівника. Обчислюється щоразу з дерева."""
    e = employee(emp_id)
    return e["manager_id"] if e else ""


def direct_reports(emp_id: str) -> list:
    """Ким керує безпосередньо (для картки працівника)."""
    e = employee(emp_id)
    return list(e["direct_report_ids"]) if e else []


def is_manager_of(boss_id: str, emp_id: str, state: dict = None) -> bool:
    """Чи є `boss_id` керівником `emp_id` на будь-якому рівні вгору.
    `state` — уже прочитана оргструктура: щоб не читати файл на кожну пару."""
    st = state or load()
    chain_of = {e["id"]: e["manager_id"] for e in st["employees"]}
    boss_id, seen, cur = _s(boss_id), set(), _s(emp_id)
    while cur and cur not in seen:
        seen.add(cur)
        nxt = chain_of.get(cur, "")
        if not nxt:
            return False
        if nxt == boss_id:
            return True
        cur = nxt
    return False


def subordinates_of(emp_id: str) -> list:
    """Усі, для кого ця людина — керівник (свій підрозділ і все, що нижче)."""
    st = load()
    return [e["id"] for e in st["employees"] if is_manager_of(emp_id, e["id"], st)]


# ⭐⭐⭐ 24.08.2026. ПОРОЖНЯ СИСТЕМА — ЦЕ НЕ ПОМИЛКА, А ПЕРШИЙ КРОК.
# Клієнт, якому щойно відкрили Task Desk, не має ні підрозділів, ні працівників.
# Доти екран задач відповідав йому «Увійдіть під своїм працівником» — глухий
# кут: увійти нема під ким. Тепер відповідь на «чому ще не працює» має ОДНОГО
# писаря, і його однаково питають екран, постановка задачі й телеграм-пульт.
# ⛒ Слова тут, а не в екрані: інакше телеграм казав би своє, а сторінка своє.
SETUP_NO_PEOPLE = "no_people"
SETUP_NOT_EMPLOYEE = "not_employee"
SETUP_READY = "ready"
SETUP_CODE = "setup_needed"          # машинний код для екрана
SETUP_WHERE = "Працівники й підрозділи"


def setup_state(emp_id: str = "") -> dict:
    """ЧОМУ TASK DESK ЩЕ НЕ ПРАЦЮЄ ДЛЯ ЦІЄЇ ЛЮДИНИ І ЩО ЗРОБИТИ ПЕРШИМ.

    Три відповіді, і кожна лікується по-різному:
      • людей ще немає взагалі — заводити оргструктуру;
      • люди є, але цієї людини серед них немає — завести картку на себе;
      • усе гаразд.
    """
    if not employees():
        return {"ready": False, "stage": SETUP_NO_PEOPLE, "code": SETUP_CODE,
                "where": SETUP_WHERE,
                "title": "Task Desk ще порожній",
                "hint": ("Платформа поки не знає ваших людей. Почніть із розділу "
                         "«%s»: заведіть підрозділ і кількох працівників — після "
                         "цього можна ставити задачі." % SETUP_WHERE)}
    if not _s(emp_id) or not employee(_s(emp_id)):
        return {"ready": False, "stage": SETUP_NOT_EMPLOYEE, "code": SETUP_CODE,
                "where": SETUP_WHERE,
                "title": "Вас ще немає в переліку працівників",
                "hint": ("Задачі ставить і виконує працівник компанії, а вашої "
                         "картки в переліку ще немає. Заведіть її в розділі «%s» "
                         "— і зможете ставити задачі." % SETUP_WHERE)}
    return {"ready": True, "stage": SETUP_READY, "code": "", "where": "",
            "title": "", "hint": ""}


def card(emp_id: str) -> dict:
    """КАРТКА ПРАЦІВНИКА (склад узгоджений з Андрієм 06.08.2026).
    Половина картки — обчислена: керівник і підлеглі беруться з дерева, а не
    зберігаються полями."""
    e = employee(emp_id)
    if not e:
        return None
    st = load()
    by_id = {x["id"]: x for x in st["employees"]}
    return {
        "id": e["id"],
        "full_name": e["full_name"],
        "position": e["position_name"],
        "unit": e["unit_name"],
        "birthday": e["birthday"],
        "manager": {"id": e["manager_id"], "name": e["manager_name"]},
        "manages": [{"id": i, "name": _s(by_id.get(i, {}).get("full_name"))}
                    for i in e["direct_report_ids"]],
        "phone_mobile": e["phone_mobile"],
        "phone_work": e["phone_work"],
        "email": e["email"],
        "telegram_id": e["telegram_id"],
        # ⭐ Не лише НАЗВИ, а й ідентифікатори: форма правки має чим заповнити
        # вибір підрозділу й посади. Назва для ока, ідентифікатор для машини.
        "unit_id": e["unit_id"],
        "position_id": e["position_id"],
        # ⭐ ГОРИЗОНТ. Свій номер людини — те, що лежить на диску; а
        # «горизонт, який діє» обчислюється (свій, інакше свого підрозділу, і
        # ніколи — для керівника цього підрозділу). Картка показує обидва, бо
        # людина мусить бачити, чому в неї саме цей номер.
        "horizon_id": e["horizon_id"],
        "horizon_effective_id": e["horizon_effective_id"],
        "photo_url": e["photo_url"],
        "active": e["active"],
        "dismissed_at": e["dismissed_at"],
        # ⭐ ЗАМІЩЕННЯ (зміна 224) — обидва боки в одному місці: «мене немає, за
        # мене Х» і «я зараз за Y». Другий бік важливіший: саме він пояснює
        # людині, звідки в неї взялись чужі задачі.
        "absences": [dict(a) for a in e["absences"]],
        "absent_now": e["absent_now"],
        "absent_from": e["absent_from"],
        "absent_to": e["absent_to"],
        "deputy": {"id": e["deputy_id"], "name": e["deputy_name"]},
        "deputy_broken": e["deputy_broken"],
        "i_stand_for": [{"id": i, "name": n}
                        for i, n in zip(e["principal_ids"], e["principal_names"])],
    }


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ХТО ЩО МОЖЕ ПРАВИТИ В КАРТЦІ. ОДНА ВІДПОВІДЬ НА ВЕСЬ ПРОДУКТ.
#
# Рішення Андрія 08.08.2026: «людина може правити свої дані. Це норма.»
# Тому картка ділиться НЕ на «читати/писати», а на ДВА ШАРИ:
#   • СВОЄ — як з тобою звʼязатись і коли тебе вітати. Це знає сама людина,
#     і бігати з цим до адміністратора — марна робота для обох.
#   • МІСЦЕ В КОМПАНІЇ — імʼя, посада, підрозділ. Це не про людину, це про
#     структуру: підрозділ тягне за собою керівника, видимість задач і права.
#     Такого собі не призначають.
#
# Цю відповідь питають ОБИДВА: екран — щоб намалювати поля, і код дії — щоб не
# пустити чужого. Друга відповідь у другому місці розійшлася б із першою, і
# зʼявилась би кнопка, яка відмовить, — брехня на екрані.
# ---------------------------------------------------------------------------
SELF_FIELDS = ("phone_mobile", "phone_work", "email", "birthday", "telegram_id")
ADMIN_FIELDS = ("full_name", "unit_id", "position_id", "horizon_id")
EDITABLE_FIELDS = SELF_FIELDS + ADMIN_FIELDS

FIELD_NAMES = {
    "full_name": "ПІБ", "unit_id": "підрозділ", "position_id": "посада",
    "phone_mobile": "мобільний телефон", "phone_work": "робочий телефон",
    "email": "пошта", "birthday": "день народження", "telegram_id": "телеграм",
    "horizon_id": "горизонт",
}


def card_rights(actor_emp_id: str, emp_id: str, is_admin: bool = False) -> dict:
    """ЩО САМЕ ця людина може правити в ЦІЙ картці.

    ⭐ Звільненого править лише адміністратор: його картка — вже історія, а не
    його робоче місце."""
    actor_emp_id, emp_id = _s(actor_emp_id), _s(emp_id)
    e = employee(emp_id)
    active = bool(e and e["active"])
    is_self = bool(actor_emp_id) and actor_emp_id == emp_id
    fields = []
    if is_admin:
        fields = list(ADMIN_FIELDS) + list(SELF_FIELDS)
    elif is_self and active:
        fields = list(SELF_FIELDS)
    # ⭐ ВІДСУТНІСТЬ — ОКРЕМЕ ПРАВО, А НЕ ПОЛЕ КАРТКИ. Її заводить сама людина,
    # ЇЇ КЕРІВНИК або адміністратор. Керівник тут не зайвий: людина може зникнути
    # раптово і вже нічого не ввести, а робота стоятиме.
    may_absence = bool(active) and (is_admin or is_self
                                    or (bool(actor_emp_id)
                                        and is_manager_of(actor_emp_id, emp_id)))
    return {"fields": fields,
            "photo": bool(fields),
            "may_edit": bool(fields),
            "absence": may_absence,
            "is_self": is_self,
            "is_admin": bool(is_admin)}


def who_may_edit(field: str) -> str:
    """Відмова завжди називає ТОГО, ХТО Б ЦЕ ЗМІГ. Тиха відмова = вимкнені ворота."""
    return ("адміністратор" if field in ADMIN_FIELDS
            else "сама людина або адміністратор")


def can_receive_tasks(emp_id: str) -> bool:
    """Звільнений лишається в історії, але нових задач не отримує ніколи."""
    e = employee(emp_id)
    return bool(e and e["can_receive_tasks"])


# ---------------------------------------------------------------------------
# ЗАМІЩЕННЯ: ОДИН ЧИТАЧ І ОДИН ПИСАР
# ---------------------------------------------------------------------------
# ⭐ ШВИДКИЙ ЧИТАЧ. `principals_of()` питають на КОЖНУ задачу в списку, тому
# читати й нормалізувати весь файл щоразу не можна. Памʼять тут не бреше: вона
# прибита до відбитка файла (шлях · час · розмір · лічильник наших записів) і
# до ДНЯ — щойно змінилось будь-що з цього, карта будується наново.
_DEPUTY = {"stamp": None, "principals": {}, "deputies": {}}
_WRITES = 0


def _stamp() -> tuple:
    try:
        st = PEOPLE_JSON.stat()
        return (str(PEOPLE_JSON), st.st_mtime_ns, st.st_size, _WRITES, today())
    except OSError:
        return (str(PEOPLE_JSON), 0, 0, _WRITES, today())


def _deputy_maps() -> tuple:
    stamp = _stamp()
    if _DEPUTY["stamp"] != stamp:
        principals, deputies = {}, {}
        for e in load()["employees"]:
            if e["principal_ids"]:
                principals[e["id"]] = tuple(e["principal_ids"])
            if e["absent_now"] and e["deputy_id"] and not e["deputy_broken"]:
                deputies[e["id"]] = {"id": e["deputy_id"], "name": e["deputy_name"],
                                     "from": e["absent_from"], "to": e["absent_to"]}
        _DEPUTY["principals"], _DEPUTY["deputies"] = principals, deputies
        _DEPUTY["stamp"] = stamp
    return _DEPUTY["principals"], _DEPUTY["deputies"]


def principals_of(emp_id: str) -> tuple:
    """КОГО ця людина заміщує прямо зараз. Порожньо — звичайний випадок.

    ⛒ Ланцюг не будується: якщо Y заміщує Z, а X заміщує Y, то X НЕ отримує
    прав Z. Тут повертається рівно один крок, і другого кроку в коді немає."""
    principals, _ = _deputy_maps()
    return principals.get(_s(emp_id), ())


def deputy_of(emp_id: str) -> dict:
    """ХТО ЗАРАЗ ЗА ЦЮ ЛЮДИНУ. Порожньо, якщо вона на місці або делегат не може
    прийняти права (звільнений, сам відсутній) — і тоді це видно словами в
    картці, а не мовчазним «нічого не сталось»."""
    _, deputies = _deputy_maps()
    return dict(deputies.get(_s(emp_id)) or {})


def absences_of(emp_id: str) -> list:
    e = employee(emp_id)
    return list(e["absences"]) if e else []


def set_absence(emp_id: str, date_from: str, date_to: str, delegate_id: str,
                reason: str = "") -> dict:
    """Завести період відсутності з делегатом.

    ⛒ МЕЖІ, БЕЗ ЯКИХ ЦЕ ЗБРОЯ: себе не заміщують · делегатом не буває той, хто
    не може отримувати задачі · кільце (X за Y і Y за X у ті самі дні)
    заборонене · періоди однієї людини не перетинаються · період, що вже
    минув, не заводиться."""
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id, delegate_id = _s(emp_id), _s(delegate_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    if not delegate_id:
        raise PeopleError("відсутність без делегата не заводиться: саме він "
                          "веде роботу, поки людини немає")
    if delegate_id == emp_id:
        raise PeopleError("людина не заміщує сама себе")
    if delegate_id not in by_id:
        raise PeopleError("делегата «%s» немає" % delegate_id)
    _check_absence_dates(date_from, date_to)
    date_from, date_to = _s(date_from), _s(date_to)
    if date_to < today():
        raise PeopleError("цей період уже минув (%s), заводити його нема сенсу"
                          % date_to)
    if not by_id[delegate_id]["can_receive_tasks"]:
        raise PeopleError("«%s» не може бути делегатом: %s"
                          % (by_id[delegate_id]["full_name"],
                             by_id[delegate_id]["broken_reason"] or "звільнений"))
    for a in by_id[emp_id]["absences"]:
        if a["from"] <= date_to and date_from <= a["to"]:
            raise PeopleError("на ці дні відсутність уже заведена (%s — %s): "
                              "два делегати на один день означали б дві "
                              "відповіді на питання «хто зараз за людину»"
                              % (a["from"], a["to"]))
    for a in by_id[delegate_id]["absences"]:
        if a["delegate_id"] == emp_id and a["from"] <= date_to and date_from <= a["to"]:
            raise PeopleError("кільце: «%s» на ці самі дні заміщує «%s». "
                              "Хтось із двох мусить лишитись на місці"
                              % (by_id[delegate_id]["full_name"],
                                 by_id[emp_id]["full_name"]))
    item = {"id": _new_id("abs"), "from": date_from, "to": date_to,
            "delegate_id": delegate_id, "reason": _s(reason)}
    by_id[emp_id]["absences"] = list(by_id[emp_id]["absences"]) + [item]
    save(st, protocol.A_ORG_ABSENCE_SET,
         "відсутність «%s» з %s по %s, заміщує «%s»"
         % (by_id[emp_id]["full_name"], date_from, date_to,
            by_id[delegate_id]["full_name"]), person_ref(emp_id))
    return employee(emp_id)


def clear_absence(emp_id: str, absence_id: str) -> dict:
    """Прибрати період. Видалення НЕ вгадує форму: id періоду називають прямо."""
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id, absence_id = _s(emp_id), _s(absence_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    have = by_id[emp_id]["absences"]
    left = [a for a in have if a["id"] != absence_id]
    if len(left) == len(have):
        raise PeopleError("такого періоду відсутності в картці немає")
    by_id[emp_id]["absences"] = left
    save(st, protocol.A_ORG_ABSENCE_CLEAR,
         "прибрано період відсутності «%s»" % by_id[emp_id]["full_name"],
         person_ref(emp_id))
    return employee(emp_id)


# ---------------------------------------------------------------------------
# ОДИН ПИСАР
# ---------------------------------------------------------------------------
def save(state: dict, action: str, reason: str, subject: str) -> dict:
    """ЄДИНЕ місце у продукті, де оргструктура лягає на диск.

    `action`  — ДІЄСЛОВО із закритого словника протоколу (`org.*`): що це за дія.
    `reason`  — людськими словами, ЩО саме змінилось; це і читає людина.
    `subject` — ГОЛОВНА РІЧ: підрозділ, працівник або оргструктура як ціле.

    ⭐⭐⭐ ДІЄСЛОВО Й РІЧ — ОБОВʼЯЗКОВІ ПАРАМЕТРИ, А НЕ ПРОХАННЯ. Той самий
    уклад, що й у нерва задач («задачу не зберегти без події»): забути
    неможливо, бо без них виклик не збереться.

    FAIL-CLOSED: якщо на диску лежить нечитабельний файл, писати поверх
    заборонено — врятувати руками ще можна, а затерте вже ні."""
    if not _s(reason):
        raise PeopleError("зміна без причини не пишеться: журнал оргструктури "
                          "мусить лишатись читабельним")
    if _s(action) not in ORG_WRITE_ACTIONS:
        raise PeopleError(
            "зміна оргструктури без дієслова зі словника не пишеться: «%s». "
            "Платформа знає лише: %s" % (_s(action), ", ".join(ORG_WRITE_ACTIONS)))
    if not _s(subject):
        raise PeopleError("зміна оргструктури без головної речі не пишеться: "
                          "журнал мусить казати, ЧОГО саме вона стосується")
    entity.parse(subject)          # невідома річ — відмова, а не тихий рядок
    on_disk = load()
    if on_disk.get("unreadable_reason"):
        raise PeopleError("оргструктура на диску не читається (%s) — писати "
                          "поверх заборонено, поки людина не вирішить її долю"
                          % on_disk["unreadable_reason"])
    st = _normalize(state)
    disk = _strip_derived(st)
    # ⛒ `audit[]` ЇДЕ НА ДИСК НЕЗМІННИМ. Не дописуємо і не обрізаємо: старий
    # слід заморожено назавжди, новий іде в протокол нижче.
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(PEOPLE_JSON, disk)
    # ⛒ Швидкий читач заміщення памʼятає карту за відбитком файла. Час файла на
    # деяких дисках грубий, тому писар піднімає ще й лічильник: інакше два
    # записи в одну мить лишили б у памʼяті вчорашню правду.
    global _WRITES
    _WRITES += 1
    _to_protocol(action, subject, reason)
    out = _normalize(disk)
    out["unreadable_reason"] = ""
    return out


def _to_protocol(action: str, subject: str, reason: str) -> None:
    """ТОЧКА ВРІЗКИ — ОРГСТРУКТУРА (зміна 361, 30.08.2026).

    ⭐ ХТО ДІЯВ, СЮДИ НЕ ПЕРЕДАЄТЬСЯ, і це навмисно. Актор відомий рівно в одних
    дверях (`taskdesk_api.run_action`) і живе в контексті потоку протоколу —
    так само, як задача й клієнт. Якби кожна дія тягла його окремим параметром,
    перша ж нова дія забула б його передати, і рядок мовчки став би безіменним.

    ⭐ КОЖЕН РЯДОК ЗГАДУЄ ОРГСТРУКТУРУ ЦІЛОМ (`about`), тому «покажи всю історію
    компанії» — це один прохід журналом, а не збирання по видах речей.

    ⚠ Ніколи не кидає: структура вже на диску, і журнал не сміє завалити роботу.
    Відхилений рядок не зникає мовчки — його ловить `protocol_failures.jsonl`."""
    try:
        protocol.write(action, subject, about=[org_ref()], note=reason)
    except Exception:
        pass


def legacy_audit() -> list:
    """СТАРИЙ, ЗАМОРОЖЕНИЙ слід оргструктури — той, що писався до зміни 361.

    Він не знає ні автора, ні дієслова, і більше не росте. Показує його екран
    історії окремим хвостом із чесним підписом; змішати його з новими рядками
    означало б видати «невідомо хто» за когось конкретного."""
    return list(load().get("audit") or [])


# ---------------------------------------------------------------------------
# Дії над оргструктурою (усі проходять через одного писаря)
# ---------------------------------------------------------------------------
def _refuse_liquidated(st: dict, unit_id: str, what: str) -> None:
    """⛒ ЛІКВІДОВАНИЙ ПІДРОЗДІЛ НЕ ПРИЙМАЄ НІКОГО. Інакше в компанії зʼявився б
    підрозділ, якого офіційно немає, а люди в ньому є."""
    if not unit_id:
        return
    for u in st["units"]:
        if u["id"] == unit_id and u["liquidated_at"]:
            raise PeopleError("підрозділ «%s» ліквідовано %s — %s не можна"
                              % (u["name"], u["liquidated_at"][:10], what))


def add_unit(name: str, parent_id: str = "", head_employee_id: str = "") -> dict:
    st = load()
    name = _s(name)
    if not name:
        raise PeopleError("підрозділ без назви не заводиться")
    ids = {u["id"] for u in st["units"]}
    if _s(parent_id) and _s(parent_id) not in ids:
        raise PeopleError("батьківського підрозділу «%s» немає" % parent_id)
    _refuse_liquidated(st, _s(parent_id), "завести в ньому підрозділ")
    if _s(head_employee_id) and _s(head_employee_id) not in {e["id"] for e in st["employees"]}:
        raise PeopleError("керівника «%s» немає серед працівників" % head_employee_id)
    rec = {"id": _new_id("unit"), "name": name, "parent_id": _s(parent_id),
           "head_employee_id": _s(head_employee_id)}
    st["units"].append(rec)
    save(st, protocol.A_ORG_UNIT_CREATED,
         "заведено підрозділ «%s»" % name, unit_ref(rec["id"]))
    return unit(rec["id"])


def set_unit_parent(unit_id: str, parent_id: str) -> dict:
    """Переміщення гілки. Кільце заборонене ВОРОТАМИ, а не проханням."""
    st = load()
    by_id = {u["id"]: u for u in st["units"]}
    unit_id, parent_id = _s(unit_id), _s(parent_id)
    if unit_id not in by_id:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    if parent_id:
        if parent_id not in by_id:
            raise PeopleError("батьківського підрозділу «%s» немає" % parent_id)
        if parent_id == unit_id:
            raise PeopleError("підрозділ не може бути підпорядкований сам собі")
        _refuse_liquidated(st, parent_id, "перемістити в нього підрозділ")
        # Новий батько не сміє бути нащадком цього ж підрозділу.
        cur, seen = parent_id, set()
        while cur and cur in by_id and cur not in seen:
            if cur == unit_id:
                raise PeopleError("так вийде кільце: «%s» лежить усередині «%s»"
                                  % (by_id[parent_id]["name"], by_id[unit_id]["name"]))
            seen.add(cur)
            cur = _s(by_id[cur].get("parent_id"))
    by_id[unit_id]["parent_id"] = parent_id
    save(st, protocol.A_ORG_UNIT_MOVED,
         "підрозділ «%s» переміщено" % by_id[unit_id]["name"], unit_ref(unit_id))
    return unit(unit_id)



def liquidate_unit(unit_id: str, children_to: str = "") -> dict:
    """ЛІКВІДАЦІЯ ПІДРОЗДІЛУ (слово Андрія 30.08.2026).

    ⚖ ЛИШЕ ПОРОЖНІЙ. Спершу людей переводять або звільняють — і тільки тоді
    підрозділ закривають. Відмова НАЗИВАЄ людей поіменно: сказати «не можна»
    і не сказати кому саме — це залишити людину без наступного кроку.

    ⚖ ПОРОЖНЄЧА НЕ Є ПРИВОДОМ. Підрозділ без людей живе далі, посади стоять
    вакантними; ліквідація — окрема свідома дія, а не наслідок порожнечі.

    ⚖ ДОЧІРНІ НЕ ГИНУТЬ. Вони переходять до батьківського підрозділу або до
    суміжного, чий керівник розширює повноваження.

    ⛒ Запис лишається на диску з датою: історія не має осиротіти."""
    st = load()
    by_id = {u["id"]: u for u in st["units"]}
    unit_id, children_to = _s(unit_id), _s(children_to)
    if unit_id not in by_id:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    me = by_id[unit_id]
    if me["liquidated_at"]:
        raise PeopleError("підрозділ «%s» уже ліквідовано %s"
                          % (me["name"], me["liquidated_at"][:10]))

    inside = [e for e in st["employees"]
              if _s(e.get("unit_id")) == unit_id and e.get("active")]
    if inside:
        names = ", ".join("«%s»" % _s(e.get("full_name")) for e in inside[:10])
        more = "" if len(inside) <= 10 else " та ще %d" % (len(inside) - 10)
        raise PeopleError(
            "у підрозділі «%s» ще працюють люди (%d): %s%s. Ліквідувати можна "
            "лише порожній підрозділ — спершу переведіть цих людей до інших "
            "підрозділів або звільніть їх."
            % (me["name"], len(inside), names, more))

    kids = [u for u in st["units"]
            if _s(u.get("parent_id")) == unit_id and u["alive"]]
    if kids:
        if not children_to:
            children_to = _s(me.get("parent_id"))
        if children_to:
            if children_to not in by_id:
                raise PeopleError("підрозділу «%s», якому передати дочірні, "
                                  "немає" % children_to)
            # ⛒ Окремої умови «не самому собі» тут НЕМАЄ свідомо: обхід
            # дерева нижче ловить цей випадок першим же кроком. Два сторожі на
            # одне правило — це нуль сторожів.
            if by_id[children_to]["liquidated_at"]:
                raise PeopleError("підрозділ «%s» ліквідовано — передати дочірні "
                                  "йому не можна" % by_id[children_to]["name"])
            # Новий батько не сміє лежати ВСЕРЕДИНІ гілки, яку передаємо.
            cur, seen = children_to, set()
            while cur and cur in by_id and cur not in seen:
                if cur == unit_id:
                    raise PeopleError(
                        "так вийде кільце: «%s» лежить усередині «%s»"
                        % (by_id[children_to]["name"], me["name"]))
                seen.add(cur)
                cur = _s(by_id[cur].get("parent_id"))
        for k in kids:
            k["parent_id"] = children_to

    me["liquidated_at"] = clock.now()
    # Керівника ліквідованого підрозділу немає: посади в ньому більше немає.
    me["head_employee_id"] = ""
    if not kids:
        tail = ""
    elif children_to:
        tail = ("; дочірні підрозділи (%d) підпорядковано «%s»"
                % (len(kids), by_id[children_to]["name"]))
    else:
        tail = ("; дочірні підрозділи (%d) стали самостійними" % len(kids))
    save(st, protocol.A_ORG_UNIT_LIQUIDATED,
         "ліквідовано підрозділ «%s»%s" % (me["name"], tail), unit_ref(unit_id))
    return unit(unit_id)


def restore_unit(unit_id: str) -> dict:
    """Помилкову ліквідацію можна відкотити — інакше одне зайве натискання
    коштувало б підрозділу назавжди. Дочірні НЕ повертаються самі: вони вже
    живуть під новим керівником, і мовчки забрати їх назад означало б
    перекроїти компанію вдруге."""
    st = load()
    by_id = {u["id"]: u for u in st["units"]}
    unit_id = _s(unit_id)
    if unit_id not in by_id:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    me = by_id[unit_id]
    if not me["liquidated_at"]:
        raise PeopleError("підрозділ «%s» і так працює" % me["name"])
    parent = _s(me.get("parent_id"))
    if parent and by_id.get(parent, {}).get("liquidated_at"):
        raise PeopleError("батьківський підрозділ «%s» ліквідовано — спершу "
                          "поверніть його або перемістіть цей"
                          % by_id[parent]["name"])
    me["liquidated_at"] = ""
    save(st, protocol.A_ORG_UNIT_RESTORED,
         "відновлено підрозділ «%s»" % me["name"], unit_ref(unit_id))
    return unit(unit_id)

def set_unit_head(unit_id: str, head_employee_id: str) -> dict:
    st = load()
    by_id = {u["id"]: u for u in st["units"]}
    unit_id, head = _s(unit_id), _s(head_employee_id)
    if unit_id not in by_id:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    if head and head not in {e["id"] for e in st["employees"]}:
        raise PeopleError("керівника «%s» немає серед працівників" % head)
    by_id[unit_id]["head_employee_id"] = head
    save(st, protocol.A_ORG_UNIT_HEAD,
         "змінено керівника підрозділу «%s»" % by_id[unit_id]["name"],
         unit_ref(unit_id))
    return unit(unit_id)


def horizon_users(state: dict, number: str) -> tuple:
    """Хто стоїть на цьому місці: (підрозділи, працівники). Чесний перелік для
    відмови — видалення не сміє вгадувати, кого воно зачепить."""
    number = _s(number)
    units_on = [u["name"] or u["id"] for u in (state.get("units") or [])
                if _s(u.get("horizon_id")) == number]
    emps_on = [e["full_name"] or e["id"] for e in (state.get("employees") or [])
               if _s(e.get("horizon_id")) == number]
    return units_on, emps_on


def set_horizon_color(number: str, color: str) -> dict:
    """Колір одного з ВОСЬМИ місць. Порожній колір ЗВІЛЬНЯЄ місце."""
    number, color = _s(number), _s(color)
    if number not in HORIZON_NUMBERS:
        raise PeopleError("горизонтів рівно %d: номер від 1 до %d"
                          % (HORIZON_MAX, HORIZON_MAX))
    st = load()
    rest = [h for h in st["horizons"] if h["id"] != number]
    if not color:
        units_on, emps_on = horizon_users(st, number)
        if units_on or emps_on:
            raise PeopleError(
                "горизонт %s звільнити не можна: на ньому %s. Спершу зніміть "
                "його з них." % (number, ", ".join(
                    ([("підрозділи: " + ", ".join(units_on))] if units_on else []) +
                    ([("працівники: " + ", ".join(emps_on))] if emps_on else []))))
        st["horizons"] = rest
        save(st, protocol.A_ORG_HORIZON,
             "горизонт %s звільнено" % number, org_ref())
        return {"horizons": load()["horizons"]}
    if not is_horizon_color(color):
        raise PeopleError("колір пишеться як #RRGGBB, наприклад #CCE5FF")
    st["horizons"] = sorted(rest + [{"id": number, "color": color}],
                            key=lambda x: int(x["id"]))
    save(st, protocol.A_ORG_HORIZON,
         "горизонт %s дістав колір %s" % (number, color), org_ref())
    return {"horizons": load()["horizons"]}


def set_unit_horizon(unit_id: str, number: str) -> dict:
    """Горизонт цілого підрозділу. 🩸 На його КЕРІВНИКА не діє (слово Андрія
    30.08.2026) — керівник стоїть на смузі керівників."""
    st = load()
    by_id = {u["id"]: u for u in st["units"]}
    unit_id, number = _s(unit_id), _s(number)
    if unit_id not in by_id:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    if number and number not in {h["id"] for h in st["horizons"]}:
        raise PeopleError("горизонт %s ще не заведено: спершу дайте йому колір"
                          % number)
    by_id[unit_id]["horizon_id"] = number
    save(st, protocol.A_ORG_UNIT_HORIZON,
         ("підрозділ «%s» поставлено на горизонт %s" % (by_id[unit_id]["name"], number))
         if number else ("підрозділ «%s» знято з горизонту" % by_id[unit_id]["name"]),
         unit_ref(unit_id))
    return unit(unit_id)


def add_position(name: str) -> dict:
    st = load()
    name = _s(name)
    if not name:
        raise PeopleError("посада без назви не заводиться")
    for p in st["positions"]:
        if p["name"].lower() == name.lower():
            return p
    rec = {"id": _new_id("pos"), "name": name}
    st["positions"].append(rec)
    save(st, protocol.A_ORG_POSITION_CREATED,
         "заведено посаду «%s»" % name, org_ref())
    return rec


def add_employee(full_name: str, unit_id: str = "", position_id: str = "",
                 email: str = "", telegram_id: str = "", birthday: str = "",
                 phone_mobile: str = "", phone_work: str = "", photo: str = "") -> dict:
    st = load()
    full_name = _s(full_name)
    if not full_name:
        raise PeopleError("працівник без ПІБ не заводиться")
    if _s(unit_id) and _s(unit_id) not in {u["id"] for u in st["units"]}:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    if _s(position_id) and _s(position_id) not in {p["id"] for p in st["positions"]}:
        raise PeopleError("посади «%s» немає" % position_id)
    _check_card_fields({"email": email, "birthday": birthday, "photo": photo,
                        "phone_mobile": phone_mobile, "phone_work": phone_work})
    rec = {"id": _new_id("emp"), "full_name": full_name, "unit_id": _s(unit_id),
           "position_id": _s(position_id), "email": _s(email),
           "telegram_id": _s(telegram_id), "birthday": _s(birthday),
           "phone_mobile": _s(phone_mobile), "phone_work": _s(phone_work),
           "photo": _s(photo), "active": True,
           "hired_at": clock.now(), "dismissed_at": ""}
    st["employees"].append(rec)
    save(st, protocol.A_ORG_EMP_HIRED,
         "заведено працівника «%s»" % full_name, person_ref(rec["id"]))
    return employee(rec["id"])


def update_employee(emp_id: str, **fields) -> dict:
    """Зміна картки. Керівника тут немає й бути не може — він обчислюється."""
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id = _s(emp_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    allowed = {"full_name", "unit_id", "position_id", "email", "telegram_id",
               "birthday", "phone_mobile", "phone_work", "photo", "horizon_id"}
    unknown = set(fields) - allowed
    if unknown:
        raise PeopleError("цих полів у картці працівника немає: %s"
                          % ", ".join(sorted(unknown)))
    if "unit_id" in fields and _s(fields["unit_id"]) and \
            _s(fields["unit_id"]) not in {u["id"] for u in st["units"]}:
        raise PeopleError("підрозділу «%s» немає" % fields["unit_id"])
    if "position_id" in fields and _s(fields["position_id"]) and \
            _s(fields["position_id"]) not in {p["id"] for p in st["positions"]}:
        raise PeopleError("посади «%s» немає" % fields["position_id"])
    if "horizon_id" in fields and _s(fields["horizon_id"]) and \
            _s(fields["horizon_id"]) not in {h["id"] for h in st["horizons"]}:
        raise PeopleError("горизонт %s ще не заведено: спершу дайте йому колір"
                          % fields["horizon_id"])
    _check_card_fields(fields)
    for k, v in fields.items():
        by_id[emp_id][k] = _s(v)
    save(st, protocol.A_ORG_EMP_CHANGED,
         "змінено картку працівника «%s»" % by_id[emp_id]["full_name"],
         person_ref(emp_id))
    return employee(emp_id)


def dismiss_employee(emp_id: str, reason: str = "") -> dict:
    """Звільнення. Запис НЕ видаляється: історія задач не має осиротіти."""
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id = _s(emp_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    by_id[emp_id]["active"] = False
    by_id[emp_id]["dismissed_at"] = clock.now()
    # Звільнений не лишається керівником підрозділу: інакше дерево віддавало б
    # начальника, якого в компанії вже немає.
    for u in st["units"]:
        if u["head_employee_id"] == emp_id:
            u["head_employee_id"] = ""
    what = "звільнено працівника «%s»" % by_id[emp_id]["full_name"]
    save(st, protocol.A_ORG_EMP_DISMISSED,
         what + (": %s" % _s(reason) if _s(reason) else ""), person_ref(emp_id))
    return employee(emp_id)


def _photo_kind(raw: bytes) -> tuple:
    for magic, ext, mime in PHOTO_KINDS:
        if raw[:len(magic)] == magic:
            if ext == "webp" and raw[8:12] != b"WEBP":
                continue
            return ext, mime
    return "", ""


def set_photo(emp_id: str, raw: bytes) -> dict:
    """Фото працівника. Імʼя файла робимо МИ (з id), а не приймаємо ззовні:
    назва з чужих рук — це шлях у чужу теку."""
    emp = employee(emp_id)
    if not emp:
        raise PeopleError("працівника «%s» немає" % emp_id)
    raw = raw or b""
    if len(raw) > MAX_PHOTO_BYTES:
        raise PeopleError("фото більше за %d МБ — стисніть його"
                          % (MAX_PHOTO_BYTES // (1024 * 1024)))
    ext, _mime = _photo_kind(raw)
    if not ext:
        raise PeopleError("це не схоже на картинку: приймаємо PNG, JPEG або WEBP")
    PHOTOS_DIR.mkdir(parents=True, exist_ok=True)
    for _m, old_ext, _mm in PHOTO_KINDS:      # старе фото іншого роду прибираємо
        old = PHOTOS_DIR / ("%s.%s" % (emp["id"], old_ext))
        if old.exists() and old_ext != ext:
            old.unlink()
    (PHOTOS_DIR / ("%s.%s" % (emp["id"], ext))).write_bytes(raw)
    return update_employee(emp["id"], photo="%s.%s" % (emp["id"], ext))


def photo_bytes(emp_id: str) -> tuple:
    """Фото для показу: (байти, тип). Немає — (None, "")."""
    emp = employee(emp_id)
    if not emp or not emp["photo"]:
        return None, ""
    p = PHOTOS_DIR / emp["photo"]
    if not p.exists():
        return None, ""
    raw = p.read_bytes()
    _ext, mime = _photo_kind(raw)
    return raw, (mime or "application/octet-stream")


def restore_employee(emp_id: str) -> dict:
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id = _s(emp_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    by_id[emp_id]["active"] = True
    by_id[emp_id]["dismissed_at"] = ""
    save(st, protocol.A_ORG_EMP_RESTORED,
         "поновлено працівника «%s»" % by_id[emp_id]["full_name"], person_ref(emp_id))
    return employee(emp_id)
