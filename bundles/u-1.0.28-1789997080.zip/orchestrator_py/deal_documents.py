# -*- coding: utf-8 -*-
"""deal_documents.py — ДОКУМЕНТИ УГОДИ (зміна 585, 16.09.2026).

⛒ ЗАКОН, ЗАРАДИ ЯКОГО ЦЕ НАПИСАНО. Слово Андрія 13.09.2026:
«Жодна угода без договору, який причеплений до цієї угоди, не може вважатися
успішно завершеною.»

Це НЕ поле в картці. Це ПРАВИЛО ЗАКРИТТЯ УГОДИ, а поле — лише те, чим правило
вміє себе довести. Тому тут живе САМ ДОКУМЕНТ як сутність (тип · номер · дата ·
сума · файл), а ворота стадії стоять там, де стоять усі ворота стадій, — у
`deals.check_stage_ready`. Другого сторожа поруч не заводимо.

🩸 ЩО БУЛО ДО ЦЬОГО. Картка угоди d0014 («Каспер») знала суму й стадію, але не
знала, що договір узагалі існує: номер `14.09-1` жив лише в документах
бухгалтера і в теці на робочому столі. Через півроку питання «за яким договором
ми йому щось винні» розвʼязувалось би пошуком по диску.

⛒ ОКРЕМЕ СХОВИЩЕ, А НЕ ПОЛЕ В УГОДІ — з тієї ж причини, що й позиції:
`deals.json` читає кожен екран списку й кожна воронка.

⛒ ФАЙЛ КОПІЮЄТЬСЯ В СХОВИЩЕ ПЛАТФОРМИ (`file_store`), а не лишається
посиланням на чужий диск. Картка не має ламатись від того, що хтось переклав
файл у себе на робочому столі. Оригінал людини ми не чіпаємо.

⛒ НОМЕР ВИДАЄ ОДИН ПИСАР (`doc_numbers`). Номер, набраний руками, рано чи
пізно збігається з чужим. Але номер, який УЖЕ стоїть у паперах бухгалтера,
заводиться як факт — платформа не вдає, ніби світ почався з неї.

⛒ ОБОВʼЯЗКОВИЙ — ДОГОВІР. Рахунок і акт живуть у тій самій картці, але
шлагбаумом не є: не роздуваємо правило ширше, ніж його назвав власник.
"""
import config
import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import deals
import doc_numbers as numbers     # ОДИН ПИСАР НОМЕРІВ
import entity                     # спільне імʼя сутності на всю платформу
import file_store                 # ОДИН рушій файлового сховища
import one_writer
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій

config.refuse_live_state_for_checks(__name__)

DIR = config.CRM_DIR
DOCS_JSON = DIR / "deal_documents.json"

KIND_CONTRACT = "contract"
KIND_INVOICE = "invoice"
KIND_ACT = "act"
KIND_OTHER = "other"
# ⭐⭐⭐ 615 (20.09.2026). ЧОТИРИ СЛОТИ ДОГОВОРУ — СЛОВО АНДРІЯ, З ПРИЦІЛОМ НА
# МАЙБУТНІЙ РЕПОЗИТОРІЙ ДОГОВОРІВ: «Проект договору», «Додатки» (кілька),
# «Підписаний договір з додатками» (кілька), «Дата підписання».
# ⛒ Це НЕ нові поля збоку. Власні поля картки поруч із цим реєстром дали б
# ДВОХ ПИСАРІВ однієї правди, і репозиторій збирався б із двох джерел, які
# розійдуться. Тому слоти — це ТИПИ в тому самому реєстрі, множинність у
# ньому вже є за побудовою (документів до угоди може бути скільки завгодно),
# а «дата підписання» — це дата підписаного договору (`signed_at`), а не
# друге поле з тією самою датою.
# ⛒ І правило 585 не розхитується: закриває угоду ЛИШЕ підписаний договір.
# Проект і додаток — ні, і саме тому вони окремі типи, а не «договір».
KIND_DRAFT = "draft_contract"
KIND_ANNEX = "annex"

# ⛒ ПЕРЕЛІК ЗАКРИТИЙ: невідомий тип — відмова, а не тихий запис «other».
KINDS = (KIND_DRAFT, KIND_ANNEX, KIND_CONTRACT, KIND_INVOICE, KIND_ACT, KIND_OTHER)
KIND_NAMES = {
    KIND_DRAFT: "проект договору",
    KIND_ANNEX: "додаток до договору",
    KIND_CONTRACT: "підписаний договір з додатками",
    KIND_INVOICE: "рахунок",
    KIND_ACT: "акт",
    KIND_OTHER: "інший документ",
}


class DealDocError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ───────────────────────── ОДИН ЧИТАЧ / ОДИН ПИСАР ─────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(DOCS_JSON)
    except PermissionError:
        raise                      # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("docs", {})
    d.setdefault("seq", 0)
    return d


def _save(d: dict) -> None:
    DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(DOCS_JSON, d)


def _new_id(d: dict) -> str:
    seq = int(d.get("seq") or 0) + 1
    while ("doc%04d" % seq) in d["docs"]:
        seq += 1
    d["seq"] = seq
    return "doc%04d" % seq


def _to_protocol(action: str, did: str, what: str) -> None:
    """Хто зберігає — той і звітує. Слід іде в журнал УГОДИ.
    ⚠ Ніколи не валить роботу: реєстр — актив, журнал — його тінь."""
    try:
        about = []
        pid = deals.client_of(did)
        if pid:
            about.append(entity.ref(entity.KIND_PARTY, pid))
        protocol.write(action, entity.ref(entity.KIND_DEAL, _s(did)),
                       about=about, note=what)
    except Exception:
        pass


def check_kind(kind) -> str:
    k = _s(kind)
    if k not in KINDS:
        raise DealDocError("Невідомий тип документа «%s». Угода знає: %s."
                           % (k, ", ".join("%s (%s)" % (KIND_NAMES[x], x)
                                           for x in KINDS)))
    return k


def said(row: dict) -> str:
    """Як документ звучить у журналі й на екрані — ОДНИМ писарем на всі місця."""
    out = KIND_NAMES.get(_s(row.get("kind")), "документ")
    if _s(row.get("number")):
        out += " № " + _s(row.get("number"))
    if _s(row.get("date")):
        out += " від " + _s(row.get("date"))
    if _s(row.get("amount")):
        out += " на " + _s(row.get("amount"))
    return out


# ───────────────────────────────── ЧИТАННЯ ─────────────────────────────────
def get(doc_id) -> dict:
    return dict(_load()["docs"].get(_s(doc_id)) or {}) or {}


def exists(doc_id) -> bool:
    return bool(get(doc_id))


def documents_of(did) -> list:
    """Документи однієї угоди, у порядку додавання.

    ⭐ 592: СУМА ДОКУМЕНТА — ТЕЖ ГРОШІ УГОДИ. Сам факт «договір № такий-то від
    такої дати є» лишається видимим — на ньому тримається правило 585 («угода
    без договору не закривається»), і колега мусить бачити, що папір існує.
    А скільки в тому папері — справа відповідального й керівника."""
    key = _s(did)
    out = [dict(v) for v in _load()["docs"].values() if _s(v.get("deal")) == key]
    out.sort(key=lambda x: (_s(x.get("created")), _s(x.get("id"))))
    try:
        import entity_scope as _vs592d
        return _vs592d.hide_money(out, ("amount",), did=key)
    except Exception:
        return out


def contracts_of(did) -> list:
    return [x for x in documents_of(did) if _s(x.get("kind")) == KIND_CONTRACT]


def has_contract(did) -> bool:
    """⭐⭐⭐ ВІДПОВІДЬ, ЯКУ ПИТАЮТЬ ВОРОТА СТАДІЇ. Одна, і живе вона тут."""
    return bool(contracts_of(did))


def annexes_of(did) -> list:
    """Додатки до договору. Їх може бути скільки завгодно."""
    return [x for x in documents_of(did) if _s(x.get("kind")) == KIND_ANNEX]


def drafts_of(did) -> list:
    """Проекти договору — те, що ще не підписано."""
    return [x for x in documents_of(did) if _s(x.get("kind")) == KIND_DRAFT]


def signed_at(did) -> str:
    """⭐⭐⭐ 615. ДАТА ПІДПИСАННЯ — ОДИН ПИСАР, І ВІН ТУТ.

    ⛒ Це НЕ окреме поле, яке хтось заповнює вдруге: це дата ПІДПИСАНОГО
    договору. Друге поле з тією самою датою означало б, що завтра вони
    розійдуться, і репозиторій договорів не знатиме, якому вірити.
    ⛒ Немає підписаного договору — немає й дати. Дату проекту ми не видаємо
    за дату підписання: це рівно та тиха брехня, від якої лікувались 609.
    """
    dates = [_s(x.get("date")) for x in contracts_of(did) if _s(x.get("date"))]
    return dates[-1] if dates else ""


# ───────────────────────────────── ЗАПИС ───────────────────────────────────
def add(did, kind, src=None, name: str = "", date: str = "", amount: str = "",
        number: str = "", by: str = "", file_id: str = "") -> dict:
    """Причепити документ до угоди.

    `number` порожній — номер видає платформа; названий — заводиться як ФАКТ,
    що вже стався (папір бухгалтера). Обидва шляхи ведуть через одного писаря
    номерів, тому два документи одного дня не зіткнуться.

    ⛒ СПЕРШУ ПЕРЕВІРЯЄМО ВСЕ, ПОТІМ ПИШЕМО. Половини не буває: файл у сховищі
    без запису в реєстрі — це сирота, а запис без файла — брехня в картці."""
    dk = _s(did)
    if not deals.exists(dk):
        raise DealDocError("Угоди %s немає." % (dk or "«»"))
    k = check_kind(kind)
    ds = numbers.check_date(date) if _s(date) else numbers.today()
    what = "%s, угода %s" % (KIND_NAMES[k], dk)

    # ⛒ ПОРЯДОК КРОКІВ НЕ ВИПАДКОВИЙ. Спершу файл, потім номер.
    # Номер із реєстру не повертається НІКОЛИ (у цьому його сенс), тому взяти
    # його першим означало б палити номер на кожній невдалій спробі: диск
    # скінчився, файл завеликий — а в реєстрі вже дірка, якої ніхто не пояснить.
    # Файл, навпаки, прибрати можна, і нижче ми це й робимо, якщо номер не ліг.

    # 1. Файл у сховищі платформи. Оригінал людини не чіпаємо.
    # ⛒ ЗАВАНТАЖУВАЧ НА ПЛАТФОРМІ ОДИН (`/api/files/upload` -> `file_store`).
    # Екран кладе файл ним і приносить сюди готовий `file_id`; другого шляху
    # для тих самих байтів ми не заводимо. `src` лишається для проб і для
    # роботи з коду, де HTTP немає.
    if _s(file_id):
        blob = file_store.info(_s(file_id))
        if not blob:
            raise DealDocError("Файла %s немає у сховищі — документ без файла "
                               "не чіпляється." % _s(file_id))
    else:
        if src is None:
            raise DealDocError("Документ без файла не чіпляється: договір — це "
                               "папір, а не запис про папір.")
        try:
            blob = file_store.put(src, name, by=by)
        except Exception as ex:
            raise DealDocError("Документ не збережено: %s" % ex)

    # 2. Номер. Якщо він не ліг, а файл клали МИ — прибираємо за собою:
    # половини не буває, і сироти в сховищі теж.
    try:
        num = (numbers.reserve(number, ds, what) if _s(number)
               else numbers.issue(ds, what))
    except Exception:
        if not _s(file_id):
            try:
                file_store.remove(_s(blob.get("id")))
            except Exception:
                pass
        raise

    d = _load()
    doc_id = _new_id(d)
    row = {
        "id": doc_id,
        "deal": dk,
        "kind": k,
        "number": num,
        "date": ds,
        # ⛒ Сума лежить ТЕКСТОМ, як її ввела людина: платформа нічого не рахує
        # (те саме рішення, що й у позиціях угоди).
        "amount": _s(amount),
        "file_id": _s(blob.get("id")),
        "file_name": _s(blob.get("name")) or _s(name),
        "by": _s(by),
        "created": clock.now(),
    }
    d["docs"][doc_id] = row
    _save(d)
    _to_protocol(protocol.A_DEAL_DOC_ADDED, dk, "причеплено: " + said(row))
    return dict(row)


@one_writer.guard("DEAL_DOCS_JSON")
def remove(doc_id, by: str = "") -> bool:
    """Відчепити документ від угоди — разом із його файлом у сховищі.

    ⛔ ДОГОВІР НЕ ВІДЧІПЛЯЄТЬСЯ З-ПІД УГОДИ, ЯКА СТОЇТЬ НА УСПІШНІЙ СТАДІЇ.
    Інакше правило обходилось би за два кроки: причепив — перевів — відчепив.
    ⛒ І ми свідомо НЕ повертаємо угоду назад самі: мовчки зсунути живого
    клієнта з «Активних» на «Перемовини» гірше, ніж чесно сказати людині, що
    спершу треба повернути угоду. Стадія — рішення людини, а не наслідок
    прибирання файла."""
    key = _s(doc_id)
    d = _load()
    row = d["docs"].get(key)
    if not row:
        raise DealDocError("Документа %s немає в угоді." % (key or "«»"))
    dk = _s(row.get("deal"))
    if _s(row.get("kind")) == KIND_CONTRACT and len(contracts_of(dk)) <= 1:
        stage = _s((deals.get(dk) or {}).get("stage"))
        if "contract" in (deals.STAGE_REQUIRES.get(stage) or ()):
            raise DealDocError(
                "Угода стоїть на стадії «%s», а ця стадія без договору не "
                "буває. Спершу поверніть угоду на попередню стадію, потім "
                "відчіплюйте договір." % stage)
    del d["docs"][key]
    _save(d)
    # Файл більше нікому не належить: лишити його означало б наробити сиріт,
    # які потім світяться в ревізії сховища.
    try:
        if _s(row.get("file_id")):
            file_store.remove(_s(row.get("file_id")))
    except Exception:
        pass
    _to_protocol(protocol.A_DEAL_DOC_REMOVED, dk, "відчеплено: " + said(row))
    return True
