# -*- coding: utf-8 -*-
"""
taskdesk_link_codes.py — РАЗОВІ КОДИ ПІДКЛЮЧЕННЯ ЧАТУ.

ЧОМУ ОКРЕМИЙ ФАЙЛ, А НЕ ДВА РЯДКИ В `taskdesk_identity`. Спершу я поклав коди
туди — і чек `taskdesk_identity_test` почервонів: у шарі «хто це» на диск
пишуть РІВНО ДВА місця (записи й сесії), і третій писар там заборонений.
Чек має рацію: код підключення — це не «хто це», а КВИТОК, який живе хвилини.
Своя правда — свій єдиний писар.

⚠ ЦЕЙ ФАЙЛ НІЧОГО НЕ ЗНАЄ ПРО ОБЛІКОВІ ЗАПИСИ. Він тримає пару «код → id
запису» і термін. Чи має право той запис діяти — питає `taskdesk_identity`.
Так не виникає кола і не зʼявляється другий суддя доступу.

⚠ САМА ПРИВʼЯЗКА ТУТ НЕ ЖИВЕ. Вона лежить у `telegram_chat_id` облікового
запису — один писар, `identity.set_telegram()`.
"""

import json
import secrets
from datetime import datetime, timedelta

import clock
import config

DESK_DIR = config.STATE_DIR / "taskdesk"
LINKS_JSON = DESK_DIR / "telegram_links.json"

TTL_MIN = 15
# Без 0/O, 1/I, S/5, B/8 — код людина переписує очима з екрана в телефон.
ALPHABET = "ACDEFGHJKLMNPQRTUVWXY34679"
LENGTH = 6


class CodeError(Exception):
    """Відмова, названа людськими словами."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _now():
    return datetime.fromisoformat(clock.now())


def _load() -> dict:
    """ЄДИНИЙ ЧИТАЧ. Побитий файл не валить підключення — він просто порожній:
    код живе 15 хвилин, втратити його не страшно, а впасти на вході — так."""
    try:
        raw = json.loads(LINKS_JSON.read_text(encoding="utf-8"))
        codes = raw.get("codes") if isinstance(raw, dict) else None
        return {k: v for k, v in (codes or {}).items() if isinstance(v, dict)}
    except Exception:
        return {}


def _save(codes: dict):
    """ЄДИНИЙ ПИСАР."""
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    LINKS_JSON.write_text(json.dumps({"codes": codes}, ensure_ascii=False, indent=2),
                          encoding="utf-8")


def _alive(codes: dict) -> dict:
    """Прострочені прибираємо на кожному дотику — окремого прибиральника для
    двох рядків заводити нема сенсу."""
    now = _now()
    out = {}
    for code, rec in codes.items():
        try:
            if datetime.fromisoformat(_s(rec.get("expires_at"))) > now:
                out[code] = rec
        except Exception:
            continue
    return out


def issue(acc_id: str) -> dict:
    """Видати код. Один запис — один живий код: новий гасить попередній,
    інакше людина не знала б, який із них діє."""
    acc_id = _s(acc_id)
    if not acc_id:
        raise CodeError("Немає, кому видавати код.")
    codes = {c: r for c, r in _alive(_load()).items() if _s(r.get("acc_id")) != acc_id}
    code = "".join(secrets.choice(ALPHABET) for _ in range(LENGTH))
    codes[code] = {"acc_id": acc_id,
                   "expires_at": (_now() + timedelta(minutes=TTL_MIN)).isoformat(timespec="seconds")}
    _save(codes)
    return {"code": code, "expires_at": codes[code]["expires_at"], "ttl_minutes": TTL_MIN}


def take(code) -> str:
    """Прийняти код і ПОГАСИТИ його. -> id облікового запису.

    ⭐ Дві причини відмови — РІЗНІ. «Немає такого» і «прострочений» людина
    лікує однаково, але шукає по-різному, тож плутати їх не можна."""
    key = _s(code).upper()
    if not key:
        raise CodeError("Порожній код.")
    codes = _load()
    if key not in codes:
        raise CodeError("Такого коду немає. Візьміть новий у своїй картці "
                        "працівника — кнопка «Підключити телеграм».")
    alive = _alive(codes)
    if key not in alive:
        _save(alive)
        raise CodeError("Код прострочений (він живе %d хвилин). Візьміть новий "
                        "у своїй картці працівника." % TTL_MIN)
    acc_id = _s(alive.pop(key).get("acc_id"))
    _save(alive)
    return acc_id


def live_for(acc_id: str) -> dict:
    """Живий код цього запису (для екрана) або порожньо."""
    for code, rec in _alive(_load()).items():
        if _s(rec.get("acc_id")) == _s(acc_id):
            return {"code": code, "expires_at": _s(rec.get("expires_at")),
                    "ttl_minutes": TTL_MIN}
    return {"code": "", "expires_at": "", "ttl_minutes": TTL_MIN}


def drop_for(acc_id: str):
    """Погасити коди запису — щоб після підключення не лишалось живого квитка."""
    codes = _alive(_load())
    _save({c: r for c, r in codes.items() if _s(r.get("acc_id")) != _s(acc_id)})
