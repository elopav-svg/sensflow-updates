"""
owner_profile.py — ХТО АВТОР І ЯКИЙ БРЕНД: ОДИН ПИСАР ПРАВДИ.

⭐⭐⭐ КОРІНЬ 31.07.2026. Система `copywriter` поїхала клієнту з зашитим у мозок
автором: «агент-автор для проєкту Обрій | SensFlow (Андрій Петренко)», «інтервʼю
з Андрієм», «пишеш голосом Андрія». Клієнт (КАСПЕР) попросив написати ЗА СЕБЕ —
і перевірка достатності двічі відхилила задачу, бо система вміє писати лише за
одного автора. Той самий клас уже ловили 15.07 на `seo_geo_strateg` (зашитий під
sensflow.net) — тоді полагодили ОДНУ систему, а КЛАС лишили.

ЛІКУВАННЯ КЛАСУ: імʼя автора і бренд — це ДАНІ, а не текст промпта.
Мозок системи пише ПЛЕЙСХОЛДЕР, а рушій підставляє значення з цього профілю в
момент читання мозку (`executor._read_brain_text`). Один писар — тут.

ЗВІДКИ БЕРЕТЬСЯ ПРАВДА (порядок, перше непорожнє виграє):
  1. `owner_profile.json` поруч із рушієм — заповнює власник копії;
  2. імʼя замовника з ЛІЦЕНЗІЇ (у клієнта воно є завжди);
  3. нейтрально: «автор» / «бренд замовника» — щоб текст лишався читабельним,
     а не показував порожнечу.

⚠ ФАЙЛ НЕ ЇДЕ В КЛІЄНТСЬКИЙ ПАКЕТ. Це ідентичність КОПІЇ, а не наш актив: у
клієнта вона народжується з його ж ліцензії. Канал оновлень кладе файли ПОВЕРХ,
тож будь-який наш `owner_profile.json` у бандлі затер би профіль клієнта.
"""

import json

import config

# ── ПЛЕЙСХОЛДЕРИ (єдиний перелік; ним користуються і рушій, і Будівник) ──────
# Ключ → як дістати значення. Українські й латинські назви означають ОДНЕ І ТЕ
# САМЕ, бо мозок систем пишуть і українською, і англійською.
PLACEHOLDER_NAME = ("АВТОР", "AUTHOR", "OWNER_NAME")
PLACEHOLDER_BRAND = ("БРЕНД", "BRAND", "OWNER_BRAND")

NEUTRAL_NAME = "автор"
NEUTRAL_BRAND = "бренд замовника"

_PATH = config.ENGINE_DIR / "owner_profile.json"

# ⭐ 10.08.2026. Позначка «це ВЕНДОРСЬКИЙ профіль» — тобто профіль НАШОЇ копії.
# Потрібна лише для самолікування: якщо такий файл випадково опиниться в
# інсталяції клієнта (як сталось у бандлі 1.0.15), платформа впізнає його як
# чужий і візьме правду з ліцензії, а не з нього.
VENDOR_COPY = "sensflow-vendor"

# Транслітерація для звірки: наше імʼя може лежати в НАЗВІ файла латиницею
# (`style_guide_andrii_petrenko.md`), і саме так воно й протекло в продукт.
_TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "h", "ґ": "g", "д": "d", "е": "e",
    "є": "ie", "ж": "zh", "з": "z", "и": "y", "і": "i", "ї": "i", "й": "i",
    "к": "k", "л": "l", "м": "m", "н": "n", "о": "o", "п": "p", "р": "r",
    "с": "s", "т": "t", "у": "u", "ф": "f", "х": "kh", "ц": "ts", "ч": "ch",
    "ш": "sh", "щ": "shch", "ь": "", "ю": "iu", "я": "ia", "'": "", "ʼ": "",
}


def translit(word: str) -> str:
    """Кирилиця → латиниця (спрощено, за офіційною таблицею КМУ)."""
    out = []
    for ch in (word or ""):
        low = ch.lower()
        rep = _TRANSLIT.get(low)
        if rep is None:
            out.append(ch)
        else:
            out.append(rep.upper() if ch.isupper() and rep else rep)
    return "".join(out)


def _read_file() -> dict:
    try:
        d = json.loads(_PATH.read_text(encoding="utf-8-sig"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _from_license() -> str:
    try:
        import license as licensing
        ent = licensing.entitlement()
        if ent.get("active") and ent.get("mode") == "license":
            return (ent.get("customer") or "").strip()
    except Exception:
        pass
    return ""


def load() -> dict:
    """Профіль власника цієї копії. Читається щоразу з диска — щоб зміна в
    налаштуваннях підхоплювалась БЕЗ рестарту (той самий закон, що й у списку
    доступу Telegram)."""
    d = _read_file()
    name = (d.get("name") or "").strip()
    brand = (d.get("brand") or "").strip()
    aliases = [str(a).strip() for a in (d.get("aliases") or []) if str(a).strip()]
    exact_only = [str(a).strip() for a in (d.get("exact_only") or []) if str(a).strip()]
    source = "file"
    # ⭐⭐⭐ 10.08.2026. САМОЛІКУВАННЯ: У КЛІЄНТА ПРАВДА — ЛІЦЕНЗІЯ, НЕ ФАЙЛ.
    # Наш `owner_profile.json` поїхав у бандлі 1.0.15, а оновлення кладеться
    # ПОВЕРХ — тобто на машині клієнта міг зʼявитись НАШ профіль і копірайтер
    # почав би писати нашим іменем. Ворота на бандл я поставив, але вони
    # захищають ЛИШЕ майбутнє: те, що вже поїхало, каналом не забрати.
    # Тому лікуємо там, де читається правда: якщо ліцензія активна і називає
    # замовника — виграє ЛІЦЕНЗІЯ, а не файл. У нашій копії клієнтської ліцензії
    # немає, тому там і далі виграє файл. Один писар, обидві копії здорові.
    # ⚠ 10.08.2026, ДРУГА РЕДАКЦІЯ ЦІЄЇ ПРАВКИ. Перша казала «ліцензія завжди
    # сильніша за файл» — і ворота ідентичності одразу почервоніли, бо в НАШІЙ
    # копії ліцензія теж активна: правило знецінювало власний профіль розробника.
    # Чек мав рацію першим. Правильний розрізнювач — не «чи є ліцензія», а «ЧИЙ
    # ЦЕ ФАЙЛ»: наш вендорський профіль позначає себе сам (`copy`). Якщо в
    # інсталяції лежить ВЕНДОРСЬКИЙ профіль, а ліцензія називає іншого замовника —
    # це залітний файл із нашого бандла, і виграє ЛІЦЕНЗІЯ. Профіль без позначки
    # (свій, заповнений власником копії) працює як працював.
    _lic = _from_license()
    if (d.get("copy") == VENDOR_COPY) and _lic and name and _lic.lower() != name.lower():
        name, brand, aliases, exact_only, source = _lic, "", [], [], "license"
    if not name:
        name = _lic
        source = "license" if name else "neutral"
    if not brand:
        brand = name
    return {"name": name, "brand": brand, "aliases": aliases, "source": source,
            "exact_only": exact_only, "configured": bool(name)}


def name() -> str:
    return load()["name"] or NEUTRAL_NAME


def brand() -> str:
    return load()["brand"] or NEUTRAL_BRAND


def is_configured() -> bool:
    return load()["configured"]


def save(name_: str = "", brand_: str = "", aliases=None) -> bool:
    """Записати профіль (налаштування власника). Пишемо ЛИШЕ звідси."""
    d = _read_file()
    if name_ is not None and str(name_).strip():
        d["name"] = str(name_).strip()
    if brand_ is not None and str(brand_).strip():
        d["brand"] = str(brand_).strip()
    if aliases is not None:
        d["aliases"] = [str(a).strip() for a in aliases if str(a).strip()]
    try:
        _PATH.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False


def values() -> dict:
    """Плейсхолдер → значення. ОДИН перелік на весь продукт."""
    out = {}
    for k in PLACEHOLDER_NAME:
        out[k] = name()
    for k in PLACEHOLDER_BRAND:
        out[k] = brand()
    return out


def render(text: str) -> str:
    """Підставити профіль у текст мозку. Порожній/невідомий плейсхолдер НЕ
    лишається на екрані: невідомий — прибираємо разом із дужками, щоб клієнт
    ніколи не побачив «{{АВТОР}}» у своєму тексті."""
    if not text or "{{" not in text:
        return text or ""
    import re
    vals = values()

    def _sub(m):
        key = (m.group(1) or "").strip()
        if key in vals:
            return vals[key]
        upper = key.upper()
        if upper in vals:
            return vals[upper]
        return key

    return re.sub(r"\{\{\s*([^{}]{1,40}?)\s*\}\}", _sub, text)


def identity_terms() -> list:
    """⭐ ЛІТЕРАЛИ НАШОЇ ІДЕНТИЧНОСТІ — ОБЧИСЛЕНІ З ПРОФІЛЮ, а не переписані
    руками в чек. Змінився профіль — змінилися ворота, без правки коду.
    Перелік слів у тілі чека — це не ворота [[feedback_wordlist_is_not_a_gate]].

    ⚠ ПРІЗВИЩЕ НЕ ВГАДУЄМО. Перша версія брала «найдовше слово ПІБ» — і замість
    «Петренко» взяла «Васильович», тобто саме той літерал, що протік у продукт
    («Андрій Петренко»), ворота б ПРОПУСТИЛИ. Тому беремо КОЖНЕ слово імені
    (від 4 знаків) і всі його пари: у мозку продукту не має бути ЖОДНОЇ
    персоналії, а не лише зручної для нас.
    Короткі уламки (<4 знаків) відкидаємо — вони ловлять випадкові збіги."""
    d = load()
    raw = set()
    parts = [w for w in (d["name"] or "").replace(",", " ").split() if len(w) >= 4]
    if parts:
        raw.add(d["name"])
        for a in parts:
            raw.add(a)
            for b in parts:
                if a != b:
                    raw.add(f"{a} {b}")
    if d["brand"]:
        raw.add(d["brand"])
    for a in d["aliases"]:
        raw.add(a)
    terms = set()
    for t in raw:
        t = (t or "").strip()
        if len(t) < 4:
            continue
        terms.add(t)
        tr = translit(t)
        if len(tr) >= 4 and tr.lower() != t.lower() and "|" not in tr:
            terms.add(tr)
            terms.add(tr.replace(" ", "_"))
            terms.add(tr.replace(" ", "-"))
    return sorted(terms, key=lambda s: (-len(s), s.lower()))


def _is_cyrillic(word: str) -> bool:
    return any("\u0400" <= ch <= "\u04ff" for ch in (word or ""))


def search_stems() -> list:
    """⭐⭐⭐ 31.07.2026, ХИБНИЙ ЗЕЛЕНИЙ. Перша версія шукала ТОЧНІ літерали — і
    прогін на зламаному продукті («Пиши голосом Андрія Петренка») пройшов як
    чистий: українське слово ВІДМІНЮЄТЬСЯ, а «Петренко» не є підрядком у
    «Петренка». Ворота, які ловлять лише називний відмінок, — це не ворота.
    Тому шукаємо за ОСНОВОЮ слова: кирилицю вкорочуємо на закінчення, латиницю
    лишаємо як є (вона не відмінюється)."""
    # ⚠ Слово, чия ОСНОВА збігається зі звичайним словом мови, шукаємо ТОЧНО:
    # основа «Обрі» ловила «LinkedIn обрізає текст» — хибний червоний у трьох
    # системах. Виняток лежить У ПРОФІЛІ (дані), а не в тілі чека.
    skip = {w.lower() for e in load()["exact_only"] for w in e.split()}
    out = set()
    for term in identity_terms():
        for w in term.replace("|", " ").split():
            if w.strip(" .,:;()«»\"'").lower() in skip:
                continue
            w = w.strip(" .,:;()«»\"'")
            if len(w) < 4:
                continue
            if _is_cyrillic(w):
                # довге слово віддає 2 знаки закінчення, коротке — 1: «Андрій» ->
                # «Андрі» (Андрія/Андрію/Андрієм), «Петренко» -> «Петренк».
                out.add(w[:-2] if len(w) >= 7 else (w[:-1] if len(w) >= 5 else w))
            else:
                out.add(w)
    return sorted(out, key=lambda s: (-len(s), s.lower()))


def found_terms(text: str) -> list:
    """Які саме основи нашої ідентичності є в тексті (без регістру, з
    урахуванням відмінювання)."""
    low = (text or "").lower()
    hits = [t for t in search_stems() if t.lower() in low]
    hits += [e for e in load()["exact_only"] if e.lower() in low]
    return hits
