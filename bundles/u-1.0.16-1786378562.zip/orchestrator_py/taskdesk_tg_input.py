# -*- coding: utf-8 -*-
"""
taskdesk_tg_input.py — ВУХО TASK DESK: натискання кнопки й відповідь у чат
перетворюються на дію в задачі.

КОРІНЬ, ЯКИЙ ЦЕ ЛІКУЄ (живий тест 09.08.2026). Рот навчився приносити задачу в
телефон — і тим створив нове очікування: людина, отримавши задачу, ПРИРОДНО
відповідає в чат. А бот казав «дії із задачею — на екрані задач у SensFlow».
Екран стоїть на `127.0.0.1`: з телефона до нього шляху НЕМАЄ. Це не «ще нема
кнопок» — це «не можу» без «ось як зможу», ще й із хибним напрямком.

⭐⭐⭐ НОВА ЗДАТНІСТЬ СТВОРЮЄ НОВЕ ОЧІКУВАННЯ — І ЗАКРИВАТИ ЙОГО ТРЕБА В ТІЙ
САМІЙ ПОРЦІЇ.

ЩО ЦЕЙ ФАЙЛ Є І ЧИМ ВІН НЕ Є:
  • Є — ВХІД: розбір натискання, звірка прав, виклик готової дії Task Desk.
  • НЕ Є — писарем прав (їх оголошує `tasks.ACTION_ROLES`), писарем тексту для
    людини (це рот `taskdesk_telegram`), писарем стану очікування
    (`taskdesk_tg_dialog`) і власним дротом назовні (лише `telegram_bot`).

⭐⭐⭐ БОТ НЕ ОТРИМУЄ ПРАВ, ЯКИХ НЕМАЄ В ЛЮДИНИ НА ЕКРАНІ. Кнопку малює
`taskdesk_telegram.buttons_for()`, і ВОНА Ж питається вдруге в момент
натискання. Джерело одне — `ACTION_ROLES`, другої таблиці прав немає. Звідси ж
безкоштовно виходить закон «повторне натискання не народжує події»: якщо стадія
вже та сама, кнопки в переліку дозволених більше немає — і зберігати нема чого.

⭐⭐⭐ ХТО ДІЄ — ВИРІШУЄ ЧАТ, І ТІЛЬКИ ПРИВʼЯЗАНИЙ. Тут свідомо НЕ кличеться
`identity.resolve_actor()`: він уміє віддати ВЛАСНИКА, коли обліковий запис
один. Для бота задач, у якому сидять УСІ працівники клієнта, це було б
катастрофою — чужий чат діяв би від імені господаря. Питаємо рівно
`account_by_telegram()`: немає привʼязки — немає актора.
"""

import sys

import clock
import taskdesk_identity as identity
import taskdesk_people as people
import taskdesk_tasks as tasks
import taskdesk_telegram as mouth
import taskdesk_tg_dialog as dialog

ROLE = mouth.ROLE                 # той самий бот задач

# Позначка прохання про термін. Права виконавця це НЕ розширює: він лишає
# ГОЛОС у стрічці, а термін рухає той, хто й так має на це право
# [[project_taskdesk_request_not_right]].
DUE_PREFIX = "📅 Прошу інший термін. "

# Що бот питає, коли кнопка веде в короткий діалог.
PROMPT = {
    mouth.BTN_DONE: ("Напишіть, ЩО зроблено — це піде в задачу як результат.\n"
                     "Без результату задачу не приймають."),
    mouth.BTN_NOTE: "Напишіть коментар — я додам його в задачу.",
    mouth.BTN_DUE: ("Напишіть, ДО КОЛИ і ЧОМУ потрібен інший термін.\n"
                    "Я передам це постановнику — рішення за ним."),
}


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ---------------------------------------------------------------------------
# ДРІТ НАЗОВНІ — ЧУЖИЙ. Свого тут немає й не буде.
# ---------------------------------------------------------------------------
def _reply(chat_id, text, markup=None) -> bool:
    import telegram_bot
    return bool(telegram_bot.send_as(ROLE, chat_id, text, markup))


def _answer(cb_id, text="") -> bool:
    import telegram_bot
    return bool(telegram_bot.answer_callback_as(ROLE, cb_id, text))


def _edit(chat_id, message_id, markup=None) -> bool:
    import telegram_bot
    return bool(telegram_bot.edit_markup_as(ROLE, chat_id, message_id, markup))


# ---------------------------------------------------------------------------
# ХТО ДІЄ
# ---------------------------------------------------------------------------
def admin_of_chat(chat_id) -> bool:
    """Чи цей чат належить адміністратору. Відповідь дає той самий писар, що й
    для екрана (`identity.is_admin`) — двох правд про владу не буває."""
    return identity.is_admin(identity.account_by_telegram(_s(chat_id)))


def actor_of(chat_id) -> str:
    """Працівник за чатом або порожньо. Порожньо — це НЕ «власник за
    замовчуванням», а «нікого»: див. шапку файла."""
    acc = identity.account_by_telegram(_s(chat_id))
    return _s((acc or {}).get("employee_id"))


# ---------------------------------------------------------------------------
# ДІЇ. Кожен код кнопки з реєстру рота МУСИТЬ мати тут обробника — і навпаки.
# Осиротіла кнопка й осиротіла дія однаково брешуть людині (урок зміни 116).
# ---------------------------------------------------------------------------
def _do_stage(stage):
    def go(tid, emp, text="", is_admin=False):
        tasks.set_stage(tid, emp, stage, is_admin)
        return "Стадія: %s" % tasks.STAGE_NAMES[stage]
    return go


def _do_result(tid, emp, text="", is_admin=False):
    """«Готово» виконавця — це ЗДАТИ РОБОТУ, а не закрити задачу.

    ⭐ Завершує задачу постановник (`STAGE_RIGHTS[STAGE_DONE] = author`), і без
    результату вона не завершується взагалі. Тому кнопка робить рівно те, що
    людина й так робила б на екрані: кладе результат у стрічку і переводить
    задачу на перевірку."""
    tasks.comment(tid, emp, text, True, is_admin)
    tasks.set_stage(tid, emp, tasks.STAGE_REVIEW, is_admin)
    return "Результат записано, задача на перевірці."


def _do_note(tid, emp, text="", is_admin=False):
    tasks.comment(tid, emp, text, False, is_admin)
    return "Коментар додано."


def _do_due(tid, emp, text="", is_admin=False):
    tasks.comment(tid, emp, DUE_PREFIX + text, False, is_admin)
    return "Прохання передано постановнику."


# Обробник + чи потрібна спершу відповідь людини (текст).
HANDLERS = {
    mouth.BTN_WORK:   {"run": _do_stage(tasks.STAGE_WORK), "asks": False},
    mouth.BTN_DONE:   {"run": _do_result,                  "asks": True},
    mouth.BTN_ACCEPT: {"run": _do_stage(tasks.STAGE_DONE),  "asks": False},
    mouth.BTN_BACK:   {"run": _do_stage(tasks.STAGE_WORK), "asks": False},
    mouth.BTN_NOTE:   {"run": _do_note,                    "asks": True},
    mouth.BTN_DUE:    {"run": _do_due,                     "asks": True},
}


# ---------------------------------------------------------------------------
# ВЛАСНИЙ ВХІД: МЕНЮ, ПЕРЕХОДИ, ФОРМА ПОСТАНОВКИ ЗАДАЧІ
#
# Доти бот умів лише відповідати на власні повідомлення. Меню під полем вводу
# і є той вхід: людина відкриває чат і бачить, ЩО тут можна.
# ---------------------------------------------------------------------------
FORM_NEW = "new"                 # імʼя форми в памʼяті діалогу
STEP_TITLE = "title"
STEP_WHO = "who"
STEP_WHEN = "when"

WHEN_DAYS = {"today": 0, "tomorrow": 1, "week": 7}


def _due_of(word) -> str:
    """Слово кнопки -> машинний термін. «Без терміну» — це теж відповідь."""
    word = _s(word)
    if word == "none":
        return ""
    if word not in WHEN_DAYS:
        return ""
    from datetime import datetime, timedelta
    day = datetime.fromisoformat(clock.now()) + timedelta(days=WHEN_DAYS[word])
    return day.strftime("%Y-%m-%d")


def _ask_who(chat_id, draft, reply, page: int = 0):
    pg = mouth.people_page(page)
    dialog.ask(chat_id, FORM_NEW, "", STEP_WHO, draft)
    reply(chat_id, "«%s»\nКому доручити? Оберіть людину (%d із %d)."
          % (_s(draft.get("title"))[:60], pg["shown"], pg["total"]), pg["markup"])
    return pg


def _ask_when(chat_id, draft, reply):
    dialog.ask(chat_id, FORM_NEW, "", STEP_WHEN, draft)
    reply(chat_id, "До коли? Можна натиснути кнопку або написати дату "
                   "(наприклад 15.08.2026 або 15.08.2026 17:00).",
          mouth.when_markup())


def _make_task(chat_id, emp, draft, reply) -> dict:
    """Створити задачу з чернетки й показати її ПУЛЬТОМ, а не просто «готово»."""
    out = {"taken": True, "done": False, "why": "", "task_id": ""}
    try:
        t = tasks.create(emp, _s(draft.get("title")), _s(draft.get("assignee_id")),
                         _s(draft.get("due_at")))
    except Exception as e:
        dialog.clear(chat_id)
        out["why"] = str(e)
        reply(chat_id, out["why"])
        return out
    dialog.clear(chat_id)
    out["done"], out["task_id"] = True, t["id"]
    out["why"] = "Задачу створено."
    # Хто про неї дізнається — кажемо ОДРАЗУ. Та сама правда, що на екрані.
    note = ""
    try:
        note = _s(mouth.reach(t, emp).get("note"))
    except Exception as e:
        note = "Не вдалося порахувати, кому це піде: %s" % e
    reply(chat_id, "Задачу створено.\n\n%s\n\n%s"
          % (mouth.card_text(t, emp), note),
          mouth.markup_for_task(t, emp, admin_of_chat(chat_id)))
    return out


# --- ПЕРЕХОДИ (жодної дії над задачею — лише показ і вибір) ---------------
def _nav_open(out, chat_id, arg, emp, adm, reply, answer, edit):
    """Відкрити задачу зі списку. Ворота тут — ВИДИМІСТЬ, а не права."""
    try:
        t = tasks.task(arg)
    except Exception as e:
        out["why"] = str(e)
        answer("Задачі немає")
        reply(chat_id, out["why"])
        return out
    if arg not in tasks.visible_ids(emp):
        out["why"] = "Ця задача вам не видима."
        answer("Не видно")
        reply(chat_id, out["why"])
        return out
    out["done"] = True
    answer("")
    reply(chat_id, mouth.card_text(t, emp), mouth.markup_for_task(t, emp, adm))
    return out


def _form(chat_id):
    w = dialog.pending(chat_id)
    if not w or _s(w.get("action")) != FORM_NEW or w.get("expired"):
        return None
    return w


def _nav_pick(out, chat_id, arg, emp, adm, reply, answer, edit):
    w = _form(chat_id)
    if not w:
        out["why"] = "Ця форма вже закрита. Почніть заново кнопкою «Поставити задачу»."
        answer("Форму закрито")
        reply(chat_id, out["why"])
        return out
    if not people.employee(arg) or not people.can_receive_tasks(arg):
        out["why"] = "Цьому працівникові задачу поставити не можна (звільнений або немає такого)."
        answer("Не можна")
        reply(chat_id, out["why"])
        return out
    draft = dict(w.get("draft") or {})
    draft["assignee_id"] = arg
    answer(_s(people.employee(arg).get("full_name"))[:60])
    _ask_when(chat_id, draft, reply)
    out["done"] = True
    return out


def _nav_when(out, chat_id, arg, emp, adm, reply, answer, edit):
    w = _form(chat_id)
    if not w:
        out["why"] = "Ця форма вже закрита. Почніть заново кнопкою «Поставити задачу»."
        answer("Форму закрито")
        reply(chat_id, out["why"])
        return out
    draft = dict(w.get("draft") or {})
    draft["due_at"] = _due_of(arg)
    answer("")
    made = _make_task(chat_id, emp, draft, reply)
    out["done"] = made["done"]
    out["why"] = made["why"]
    return out


def _nav_page(out, chat_id, arg, emp, adm, reply, answer, edit):
    w = _form(chat_id)
    if not w:
        out["why"] = "Ця форма вже закрита."
        answer("Форму закрито")
        reply(chat_id, out["why"])
        return out
    try:
        page = int(arg)
    except Exception:
        page = 0
    answer("")
    _ask_who(chat_id, dict(w.get("draft") or {}), reply, page)
    out["done"] = True
    return out


def _nav_drop(out, chat_id, arg, emp, adm, reply, answer, edit):
    had = dialog.clear(chat_id)
    out["done"] = True
    out["why"] = "Скасовано." if had else "Нічого скасовувати."
    answer(out["why"])
    reply(chat_id, out["why"])
    return out


NAV_HANDLERS = {
    mouth.NAV_OPEN: _nav_open,
    mouth.NAV_PICK: _nav_pick,
    mouth.NAV_WHEN: _nav_when,
    mouth.NAV_PAGE: _nav_page,
    mouth.NAV_DROP: _nav_drop,
}


# --- МЕНЮ ------------------------------------------------------------------
def _menu_my(chat_id, emp, adm, reply) -> dict:
    got = mouth.my_tasks(emp)
    reply(chat_id, got["text"], got["markup"])
    return {"taken": True, "done": True, "why": "список задач", "total": got["total"]}


def _menu_new(chat_id, emp, adm, reply) -> dict:
    dialog.ask(chat_id, FORM_NEW, "", STEP_TITLE, {})
    reply(chat_id, "Що треба зробити? Напишіть назву задачі одним рядком.\n"
                   "Щоб передумати — просто натисніть «Мої задачі».")
    return {"taken": True, "done": True, "why": "форма відкрита"}


MENU_HANDLERS = {"my": _menu_my, "new": _menu_new}


def orphans() -> dict:
    """Кнопки без дії та дії без кнопки — для чека й для консолі."""
    codes = {b["code"] for b in mouth.BUTTONS}
    navs = {n["code"] for n in mouth.NAV}
    menu = {m["code"] for m in mouth.MENU}
    return {"buttons_without_action": sorted(codes - set(HANDLERS)),
            "actions_without_button": sorted(set(HANDLERS) - codes),
            "nav_without_handler": sorted(navs - set(NAV_HANDLERS)),
            "handler_without_nav": sorted(set(NAV_HANDLERS) - navs),
            "menu_without_handler": sorted(menu - set(MENU_HANDLERS)),
            "handler_without_menu": sorted(set(MENU_HANDLERS) - menu)}


# ---------------------------------------------------------------------------
# НАТИСКАННЯ КНОПКИ
# ---------------------------------------------------------------------------
def _why_not(t, emp, code, adm=False) -> str:
    """Чому цієї кнопки більше не можна. Відмова МУСИТЬ називати причину —
    інакше людина тисне ще раз і думає, що зламалось."""
    btn = mouth.button(code)
    if not btn:
        return "Ця кнопка з давнього повідомлення й більше не діє."
    for act in btn["acts"]:
        if not tasks.may(t, emp, act, adm):
            try:
                tasks.require(t, emp, act, adm)
            except Exception as e:
                return str(e)
    return ("Цю дію вже зроблено: задача зараз у стадії «%s»."
            % tasks.STAGE_NAMES.get(t.get("stage"), t.get("stage")))


def on_press(cb, reply=None, answer=None, edit=None) -> dict:
    """Натиснули кнопку під повідомленням.

    ⭐ `answerCallbackQuery` — ОБОВʼЯЗКОВО і ЗАВЖДИ, навіть на відмові: інакше в
    людини крутиться годинник, і вона тисне ще раз.

    ⭐ Дроти передаються ззовні — так чек бачить кожен вихід на очі, і жоден
    прогін не стукає в мережу."""
    reply = reply or _reply
    answer = answer or _answer
    edit = edit or _edit
    cb = cb or {}
    cb_id = _s(cb.get("id"))
    msg = cb.get("message") or {}
    chat_id = _s((msg.get("chat") or {}).get("id"))
    message_id = (msg or {}).get("message_id")
    out = {"code": "", "task_id": "", "actor": "", "done": False, "why": ""}

    code, tid = mouth.parse_press(cb.get("data"))
    out["code"], out["task_id"] = code, tid
    if not code:
        out["why"] = "Ця кнопка з давнього повідомлення й більше не діє."
        answer(cb_id, out["why"])
        return out

    emp = actor_of(chat_id)
    adm = admin_of_chat(chat_id)
    out["actor"] = emp
    if not emp:
        out["why"] = ("Цей чат не підключено до працівника. Відкрийте свою картку "
                      "в розділі «Люди», натисніть «Підключити телеграм» і "
                      "надішліть сюди код.")
        answer(cb_id, "Чат не підключено")
        reply(chat_id, out["why"])
        return out

    # ПЕРЕХОДИ йдуть ПЕРШИМИ і по своїй дорозі: у них немає ні задачі, ні
    # права в ACTION_ROLES — «обрати людину» нічого не змінює. Ворота в них
    # свої: видимість задачі й наявність відкритої форми.
    if code in NAV_HANDLERS:
        def _ans(txt=""):
            return answer(cb_id, txt)
        return NAV_HANDLERS[code](out, chat_id, tid, emp, adm, reply, _ans, edit)

    try:
        t = tasks.task(tid)
    except Exception as e:
        out["why"] = str(e)
        answer(cb_id, "Задачі більше немає")
        reply(chat_id, out["why"])
        return out

    if tid not in tasks.visible_ids(emp):
        # Спливашка зникає за секунду. Відмова, якої не лишилось у чаті, для
        # людини те саме, що мовчання, — тому кажемо й повідомленням.
        out["why"] = ("Ця задача вам не видима — можливо, вас прибрали з неї "
                      "або повідомлення переслали з чужого чату.")
        answer(cb_id, "Не видно задачі")
        reply(chat_id, out["why"])
        return out

    # ⭐⭐⭐ ОДНІ ВОРОТА НА ВСІ КНОПКИ. Права, стадія і «вже зроблено» питаються
    # НЕ по одній кнопці, а тим самим переліком, який їх і намалював.
    if code not in {b["code"] for b in mouth.buttons_for(t, emp, adm)}:
        out["why"] = _why_not(t, emp, code, adm)
        answer(cb_id, "Не можна")
        reply(chat_id, out["why"])
        return out

    h = HANDLERS.get(code)
    if not h:
        # Кнопка без дії. Чек цього не пустить, але мовчати тут не сміємо.
        out["why"] = "Ця кнопка поки нічого не робить — повідомте адміністратора."
        answer(cb_id, "Не можу")
        reply(chat_id, out["why"])
        sys.stderr.write("[вухо] кнопка «%s» без обробника\n" % code)
        return out

    if h["asks"]:
        dialog.ask(chat_id, code, tid)
        out["why"] = "чекаю відповіді"
        answer(cb_id, "Чекаю на текст")
        reply(chat_id, "«%s» · %s\n%s" % (_s(t.get("title"))[:120], tid,
                                          PROMPT.get(code, "Напишіть відповідь.")))
        return out

    try:
        said = h["run"](tid, emp, "", adm)
    except Exception as e:
        out["why"] = str(e)
        answer(cb_id, "Не вдалося")
        reply(chat_id, out["why"])
        return out

    out["done"] = True
    out["why"] = said
    answer(cb_id, said)
    # ⭐⭐⭐ 09.08.2026, ЗНАЙДЕНО АНДРІЄМ НА ЖИВОМУ. Спершу я тут кнопки ПРИБИРАВ
    # — і повідомлення ставало мертвим: людина взяла задачу в роботу, а здати її
    # з телефона вже не могла. Це рівно той корінь, який ця порція й лікує:
    # «не можу» без «ось як зможу», тільки на крок далі.
    #
    # ⭐⭐⭐ НЕ ПРИБИРАЙ ДІЮ — ПОКАЖИ ТУ, ЯКА МОЖЛИВА ЗАРАЗ. Повідомлення про
    # задачу перестає бути новиною і стає ПУЛЬТОМ до неї: після кожного
    # натискання воно перемальовується під поточну стадію. Задача закрилась —
    # кнопок не лишається, і це теж правда, а не порожнеча.
    if message_id is not None:
        try:
            edit(chat_id, message_id,
                 mouth.markup_for_task(tasks.task(tid), emp, adm))
        except Exception as e:
            sys.stderr.write("[вухо] не перемалював кнопки: %s\n" % e)
    return out


# ---------------------------------------------------------------------------
# ВІДПОВІДЬ НА ПИТАННЯ БОТА
# ---------------------------------------------------------------------------
def on_message(chat_id, text, reply=None) -> dict:
    """Звичайне повідомлення в чат. -> {"taken": True} якщо це була відповідь
    на наше питання; інакше {"taken": False} — і бот відповідає як завжди."""
    reply = reply or _reply
    chat_id = _s(chat_id)
    out = {"taken": False, "done": False, "why": "", "code": "", "task_id": ""}
    emp0 = actor_of(chat_id)
    adm0 = admin_of_chat(chat_id)

    # МЕНЮ ПЕРЕМАГАЄ ВІДКРИТЕ ПИТАННЯ. Людина, яка тисне «Мої задачі» посеред
    # форми, передумала — і тримати її в старому питанні було б пасткою.
    m = mouth.menu_code(text)
    if m:
        if not emp0:
            out["taken"] = True
            out["why"] = ("Цей чат не підключено до працівника. Візьміть код у "
                          "своїй картці в розділі «Люди».")
            reply(chat_id, out["why"])
            return out
        h = MENU_HANDLERS.get(m)
        if not h:
            out["taken"] = True
            out["why"] = "Цей пункт меню поки нічого не робить."
            reply(chat_id, out["why"])
            sys.stderr.write("[вухо] пункт меню «%s» без обробника\n" % m)
            return out
        dialog.clear(chat_id)
        got = h(chat_id, emp0, adm0, reply)
        out.update(got)
        out["code"] = m
        return out

    w = dialog.pending(chat_id)
    if not w:
        return out
    out["taken"] = True
    out["code"], out["task_id"] = _s(w.get("action")), _s(w.get("task_id"))

    if w.get("expired"):
        dialog.clear(chat_id)
        out["why"] = ("Минуло понад %d хвилин, тож я вже не чекав відповіді. "
                      "Натисніть кнопку під повідомленням про задачу ще раз."
                      % dialog.TTL_MIN)
        reply(chat_id, out["why"])
        return out

    text = _s(text)
    if not text:
        out["why"] = "Порожня відповідь не приймається — напишіть текст."
        reply(chat_id, out["why"])
        return out

    # ФОРМА ПОСТАНОВКИ ЗАДАЧІ — своя дорога: тут немає ні задачі, ні прав над
    # нею, бо задачі ще не існує.
    if out["code"] == FORM_NEW:
        if not emp0:
            dialog.clear(chat_id)
            out["why"] = "Цей чат більше не підключено до працівника."
            reply(chat_id, out["why"])
            return out
        step = _s(w.get("step"))
        draft = dict(w.get("draft") or {})
        if step == STEP_TITLE:
            draft["title"] = text[:200]
            _ask_who(chat_id, draft, reply)
            out["done"] = True
            out["why"] = "чекаю виконавця"
            return out
        if step == STEP_WHO:
            # Людину обирають КНОПКОЮ. Але мовчати на набраний текст не можна:
            # людина не зрозуміє, чому нічого не сталось.
            _ask_who(chat_id, draft, reply)
            out["why"] = ("Виконавця треба обрати кнопкою — так ми не переплутаємо "
                          "однофамільців.")
            reply(chat_id, out["why"])
            return out
        if step == STEP_WHEN:
            due = tasks.due_from_human(text)
            if not due:
                out["why"] = ("Не впізнав дату «%s». Напишіть у вигляді 15.08.2026 "
                              "(можна з часом: 15.08.2026 17:00) або натисніть кнопку."
                              % text[:40])
                reply(chat_id, out["why"], mouth.when_markup())
                return out
            draft["due_at"] = due
            made = _make_task(chat_id, emp0, draft, reply)
            out["done"], out["why"] = made["done"], made["why"]
            out["task_id"] = made["task_id"]
            return out
        dialog.clear(chat_id)
        out["why"] = "Форма загубила крок — почніть заново кнопкою «Поставити задачу»."
        reply(chat_id, out["why"])
        return out

    emp = actor_of(chat_id)
    adm = admin_of_chat(chat_id)
    if not emp:
        dialog.clear(chat_id)
        out["why"] = "Цей чат більше не підключено до працівника."
        reply(chat_id, out["why"])
        return out

    # ⭐ ПРАВА ПИТАЄМО ЗАНОВО. Між питанням і відповіддю минули хвилини —
    # людину могли прибрати із задачі, а задачу закрити.
    try:
        t = tasks.task(out["task_id"])
    except Exception as e:
        dialog.clear(chat_id)
        out["why"] = str(e)
        reply(chat_id, out["why"])
        return out

    if out["code"] not in {b["code"] for b in mouth.buttons_for(t, emp, adm)}:
        dialog.clear(chat_id)
        out["why"] = _why_not(t, emp, out["code"], adm)
        reply(chat_id, out["why"])
        return out

    h = HANDLERS.get(out["code"]) or {}
    try:
        said = (h.get("run") or (lambda *a, **k: ""))(out["task_id"], emp, text, adm)
    except Exception as e:
        dialog.clear(chat_id)
        out["why"] = str(e)
        reply(chat_id, out["why"])
        return out

    dialog.clear(chat_id)
    out["done"] = True
    out["why"] = said
    # ⭐ Підтвердження теж несе КНОПКИ, можливі зараз: людина відповіла текстом,
    # і в неї під рукою мусить лишитись пульт до цієї задачі, а не глухий кінець.
    try:
        after = tasks.task(out["task_id"])
    except Exception:
        after = t
    reply(chat_id, "✅ %s\n«%s» · %s" % (said, _s(after.get("title"))[:120], out["task_id"]),
          mouth.markup_for_task(after, emp, adm))
    return out
