# -*- coding: utf-8 -*-
"""
taskdesk_tg_dialog.py — ПАМʼЯТЬ ОДНОГО ПИТАННЯ: чого бот чекає від цього чату.

КОРІНЬ, ЯКИЙ ЦЕ ЛІКУЄ (09.08.2026). Кнопка «Готово» не може завершити задачу
одним натисканням: у Task Desk є закон — БЕЗ РЕЗУЛЬТАТУ НЕ ЗАВЕРШУЮТЬ. Отже
кнопка веде в короткий діалог: бот просить написати результат НАСТУПНИМ
повідомленням. А діалог — це стан, і в нього має бути свій писар.

⚠ ЧОМУ НЕ В ПАМʼЯТІ ПРОЦЕСУ. Сервер перезапускають після кожного оновлення
(і просто закривають вікно ввечері). Стан у памʼяті означав би: людина
відповіла боту, а слухача вже немає — питання зависло без відповіді. Це той
самий глухий кут, який ми й лікуємо, тільки на крок далі.

⚠ ЧОМУ ОКРЕМИЙ ФАЙЛ, А НЕ ДВА РЯДКИ В РОТІ. Урок зміни 117 (`taskdesk_link_codes`):
рот — це писар ТЕКСТУ для людини, а не сховище стану. Своя правда — свій
єдиний писар. Тут правда одна: «чат X зараз відповідає на питання Y про
задачу Z, і в нього на це 15 хвилин».

⚠ ЦЕЙ ФАЙЛ НЕ ЗНАЄ НІ ПРО ПРАВА, НІ ПРО ЗАДАЧІ. Він тримає квиток очікування.
Чи має право той чат щось робити — питає `taskdesk_tg_input` у `tasks.may()`.
Так не виникає ні кола імпортів, ні другого судді прав.
"""

import json
from datetime import datetime, timedelta

import clock
import config

DESK_DIR = config.STATE_DIR / "taskdesk"
DIALOG_JSON = DESK_DIR / "tg_dialog.json"

# Скільки живе питання. Довше — і людина відповість «так» на питання, якого
# вже не памʼятає; коротше — не встигне набрати результат з телефона.
TTL_MIN = 15


class DialogError(Exception):
    """Відмова, названа людськими словами."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _now():
    return datetime.fromisoformat(clock.now())


def _load() -> dict:
    """ЄДИНИЙ ЧИТАЧ. Побитий файл не валить бота: питання живе хвилини,
    втратити його не страшно, а впасти на вході — так."""
    try:
        raw = json.loads(DIALOG_JSON.read_text(encoding="utf-8"))
        waits = raw.get("waiting") if isinstance(raw, dict) else None
        return {k: v for k, v in (waits or {}).items() if isinstance(v, dict)}
    except Exception:
        return {}


def _save(waits: dict):
    """ЄДИНИЙ ПИСАР."""
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    DIALOG_JSON.write_text(
        json.dumps({"waiting": waits}, ensure_ascii=False, indent=2),
        encoding="utf-8")


def ask(chat_id, action: str, task_id: str = "", step: str = "",
        draft: dict = None) -> dict:
    """Запамʼятати, чого чекаємо від чату. Одне питання на чат: нове гасить
    старе — інакше людина не знала б, на що саме відповідає.

    ⭐ 09.08.2026: сюди додались КРОК і ЧЕРНЕТКА. Постановка задачі з телефона —
    це не одне питання, а три (що зробити → кому → до коли), і між ними треба
    десь тримати вже назбиране. Заводити для цього ДРУГОГО писаря стану було б
    тим самим «два писарі однієї правди»: правда одна — «чого бот чекає від
    цього чату», просто в неї побільшало полів.

    ⚠ `task_id` став НЕОБОВʼЯЗКОВИМ: у форми створення задачі ще немає."""
    chat = _s(chat_id)
    action = _s(action)
    if not chat:
        raise DialogError("Немає чату, від якого чекати відповіді.")
    if not action:
        raise DialogError("Питання без дії не ставиться.")
    rec = {"action": action, "task_id": _s(task_id), "step": _s(step),
           "draft": dict(draft or {}),
           "asked_at": _now().isoformat(timespec="seconds"),
           "expires_at": (_now() + timedelta(minutes=TTL_MIN)).isoformat(timespec="seconds")}
    waits = _load()
    waits[chat] = rec
    _save(waits)
    return dict(rec, chat_id=chat)


def pending(chat_id) -> dict:
    """Чого чекаємо від цього чату — або порожньо.

    ⭐ ПРОСТРОЧЕНЕ ПИТАННЯ НЕ ЗНИКАЄ МОВЧКИ: воно повертається з позначкою
    `expired`, щоб бот сказав ПРИЧИНУ («минуло 15 хвилин»), а не проковтнув
    відповідь людини. Мовчазна відмова — те, що вбиває продукт."""
    rec = _load().get(_s(chat_id))
    if not rec:
        return {}
    out = dict(rec, chat_id=_s(chat_id))
    out.setdefault("step", "")
    out.setdefault("draft", {})
    try:
        out["expired"] = datetime.fromisoformat(_s(rec.get("expires_at"))) <= _now()
    except Exception:
        out["expired"] = True
    return out


def clear(chat_id) -> bool:
    """Питання закрите (відповіли, скасували або прострочили)."""
    chat = _s(chat_id)
    waits = _load()
    if chat not in waits:
        return False
    waits.pop(chat, None)
    _save(waits)
    return True


def snapshot() -> dict:
    """Стан діалогів одним поглядом — для консолі й для чеків."""
    waits = _load()
    live = 0
    for chat in list(waits):
        if not pending(chat).get("expired"):
            live += 1
    return {"waiting": len(waits), "live": live, "ttl_minutes": TTL_MIN,
            "file": str(DIALOG_JSON)}
