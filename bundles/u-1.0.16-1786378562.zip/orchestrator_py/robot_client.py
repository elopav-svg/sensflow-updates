# -*- coding: utf-8 -*-
"""
robot_client.py — РОБОТ-КЛІЄНТ: програє повні розмови так, як їх грає людина.

ЧОМУ ЦЕЙ МОДУЛЬ ІСНУЄ (Статут №15, 29.07.2026).

  КЛАС ПРОБЛЕМИ: наші 400 безкоштовних чеків перевіряють ФУНКЦІЮ — «такий вхід
  дав такий вихід». А продукт ламається на ШЛЯХУ: друга репліка діалогу, зміна
  виконавця посеред роботи, збірка годинної давнини, мозок, який не знає про
  власний інструмент. Ці баги живуть МІЖ кроками — туди жоден юніт-тест не
  заглядає, і вони доживають рівно до Андрія. 28.07 три зриви з чотирьох не
  спіймав ЖОДЕН чек.

  ТОЧКА РІШЕННЯ: одна — тут. Не новий чек на кожну функцію, а гравець, який
  заходить у систему ТИМ САМИМ входом, що й веб-консоль (`agent.run`), веде
  розмову з історією і дивиться на ТЕКСТ, який побачить людина на екрані.

  ВСІ КАНАЛИ: мозок, ворота права, резолвер тендерного контексту, лічильник
  грошей, пауза й продовження, відмова провайдера, фінальна здача результату.

  ЧИ ПРОТЕЧЕ МАЙБУТНІЙ КАНАЛ: сценарій, якого тут немає, не перевіряється —
  це чесна межа. Гарантія не «жодного бага», а «той самий біль не приходить
  двічі»: кожен зрив у Андрія стає сценарієм ТУТ і більше не повторюється.

ГРОШІ: $0. Модель підмінена заглушкою (`llmtools.tool_turn`, `llm.complete`,
`llm.complete_json`). Ворота, юрист, міст, резолвер і лічильник — СПРАВЖНІ.
Заглушка не вміє ходити в мережу — якщо шлях спробує піти по гроші, прогін
впаде, і це теж результат.

Запуск: Run robot client.bat  (або python robot_client.py)
"""
import json
import os
import re
import sys
import tempfile
import traceback

# ⭐ 29.07.2026. РОБОТ ГРАЄ РОЗМОВИ ЧЕРЕЗ СПРАВЖНІЙ РУШІЙ — отже може створити
# автоматизацію чи профіль у БОЙОВІЙ теці. Відводимо стан убік ДО першого
# імпорту config (він читає змінну один раз при завантаженні). `setdefault` —
# щоб раннер, який уже виставив свою теку, лишався головним.
os.environ.setdefault("SENSFLOW_STATE_DIR",
                      os.path.join(tempfile.gettempdir(), "sensflow_robot_state"))
os.makedirs(os.environ["SENSFLOW_STATE_DIR"], exist_ok=True)

import run_log

run_log.start("robot_client")

import config          # noqa: E402
import llm             # noqa: E402
import llmtools        # noqa: E402
import costs           # noqa: E402

# ── ЗАГЛУШКА МОДЕЛІ ──────────────────────────────────────────────────────
# Одна точка підміни. Сценарій каже, ЩО модель «відповість»; усе інше —
# справжній код платформи.

_ORIG = {}


class Stub(object):
    """Детермінована заглушка мозку й виконавця.

    brain_turns — черга ходів мозку. Кожен хід або
        {"text": "..."}                      -> фінальна відповідь користувачу
        {"tool": "run_system", "args": {...}} -> виклик інструменту
    Коли черга порожня — мозок каже `default_text`.

    worker_text — що «пише» виконавець усередині системи.
    worker_error — якщо задано, виконавець кидає цю помилку (сценарій відмови).
    tokens_per_call — скільки токенів «спалює» виклик (для сценарію межі).
    """

    def __init__(self, brain_turns=None, worker_text="", worker_error=None,
                 tokens_per_call=0, default_text="Готово."):
        self.brain_turns = list(brain_turns or [])
        self.worker_text = worker_text
        self.worker_error = worker_error
        self.tokens_per_call = int(tokens_per_call or 0)
        self.default_text = default_text
        self.brain_calls = 0
        self.worker_calls = 0
        self.last_tool_result = ""
        self.seen_system_prompts = []

    # -- мозок --------------------------------------------------------
    def tool_turn(self, system, messages, tools, model=None, max_tokens=None):
        self.brain_calls += 1
        self.seen_system_prompts.append(system or "")
        if not self.brain_turns:
            return {"text": self.default_text, "tool_calls": [], "stop_reason": "end_turn"}
        step = self.brain_turns.pop(0)
        if step.get("relay"):
            # Живий мозок після інструменту ПЕРЕКАЗУЄ його результат людині.
            # Якщо тут поставити свій текст, робот перевірятиме мій сценарій,
            # а не продукт — і сховає, скажімо, пропозицію паузи за вартістю.
            last = ""
            for m in reversed(messages or []):
                if m.get("role") == "tool":
                    last = m.get("content") or ""
                    break
            self.last_tool_result = last
            return {"text": last or self.default_text, "tool_calls": [],
                    "stop_reason": "end_turn"}
        if "tool" in step:
            return {"text": step.get("thought", ""), "stop_reason": "tool_use",
                    "tool_calls": [{"id": "call_%d" % self.brain_calls,
                                    "name": step["tool"],
                                    "args": step.get("args", {})}]}
        return {"text": step.get("text", self.default_text), "tool_calls": [],
                "stop_reason": "end_turn"}

    # -- виконавець ---------------------------------------------------
    # ⚠ УРОК ПЕРШОГО ПРОГОНУ (29.07.2026): заглушка МУСИТЬ проходити ті самі
    # запобіжники, що й справжній виклик. Перша версія обходила `_budget_stop`
    # (він — перший рядок справжнього `llm.complete`), і робот доповів про
    # «пауза за вартістю не спрацювала», хоча в продукті вона ціла. Робот, який
    # вигадує баги, гірший за відсутність робота: він з'їдає день на пусте.
    def _guard_and_charge(self, where):
        llm._budget_stop(where)          # той самий запобіжник, що в реальному виклику
        if self.tokens_per_call > 0:
            # Витрата — через СПРАВЖНІЙ лічильник справжніми цінами.
            costs.record(config.worker_model(),
                         self.tokens_per_call, self.tokens_per_call)

    def complete(self, system, user, temperature=None, max_tokens=None, model=None,
                 **kw):
        self.worker_calls += 1
        self._guard_and_charge("complete")
        if self.worker_error is not None:
            raise self.worker_error
        return self.worker_text

    def complete_json(self, system, user, temperature=0.1, model=None, **kw):
        self.worker_calls += 1
        self._guard_and_charge("complete_json")
        if self.worker_error is not None:
            raise self.worker_error
        return _json_for(system, user)


def _json_for(system, user):
    """Мінімальна коректна JSON-відповідь під того, хто питає.

    Дивимось на системний промпт: кожен споживач JSON у платформі має свою
    форму. Незнайомому — порожній словник: код платформи фейл-клоузед і
    підставить свої значення за замовчуванням.
    """
    s = (system or "").lower()
    if "pipeline" in s or "етап" in s or "конвеєр" in s:
        return {"pipeline": [{"role": "Виконавець", "goal": "Відповісти на запит"}],
                "summary": "Один етап"}
    if "маршрут" in s or "route" in s:
        return {"stops": []}
    return {}


# ── 🔒 ЗАМОК НА ГРОШІ ────────────────────────────────────────────────────
# ЗНАХІДКА ПЕРШОГО Ж ПРОГОНУ (29.07.2026): я заглушив мозок і виконавця, а
# шлях `web_search` пішов у мережу по-справжньому — тобто «безкоштовний»
# набір списав би гроші Андрія. Той самий клас, що й 28.07.
# ТОЧКА РІШЕННЯ: не заглушувати кожного, хто кличе модель (їх завтра стане
# більше), а замкнути ОДНІ ДВЕРІ, крізь які гроші виходять — мережевий
# виклик у llm. Незаглушений шлях тепер не витрачає, а ГОЛОСНО падає.
_MONEY_DOORS = ("_http_post", "_http_post_stream", "_open_stream", "_chat_stream")


def _no_money(*a, **k):
    raise RuntimeError(
        "РОБОТ-КЛІЄНТ: хтось спробував піти в мережу по гроші. Це ЗНАХІДКА, "
        "а не збій: цей шлях не заглушено. Додай заглушку — або прогін "
        "коштуватиме грошей у клієнта.")


def install(stub):
    _ORIG.clear()
    _ORIG["tool_turn"] = llmtools.tool_turn
    for name in ("complete", "complete_json", "complete_vision", "search_complete",
                 "embed") + _MONEY_DOORS:
        _ORIG[name] = getattr(llm, name, None)
    _ORIG["provider_ready"] = config.provider_ready

    llmtools.tool_turn = stub.tool_turn
    llm.complete = stub.complete
    llm.complete_json = stub.complete_json
    llm.complete_vision = lambda *a, **k: stub.worker_text
    llm.search_complete = lambda *a, **k: {"text": stub.worker_text, "sources": []}
    llm.embed = lambda texts: [[0.0] * 8 for _ in (texts or [])]
    for name in _MONEY_DOORS:
        if hasattr(llm, name):
            setattr(llm, name, _no_money)
    config.provider_ready = lambda *a, **k: True


def restore():
    if not _ORIG:
        return
    llmtools.tool_turn = _ORIG["tool_turn"]
    for name, fn in list(_ORIG.items()):
        if name in ("tool_turn", "provider_ready"):
            continue
        if fn is not None:
            setattr(llm, name, fn)
    config.provider_ready = _ORIG["provider_ready"]
    _ORIG.clear()


# ── ГРА В КЛІЄНТА ────────────────────────────────────────────────────────

def play(replies, stub):
    """Веде розмову: список реплік людини -> список того, що вона побачила.

    ⚠ ВХІД — `engine.handle_message`, ТІ САМІ ДВЕРІ, що й у веб-консолі, а не
    `agent.run` глибше. Перша версія робота заходила глибше — і пропустила
    `costs.start_run()`, після чого доповіла про неіснуючу поломку паузи за
    вартістю. Робот, який заходить не тими дверима, бачить не той продукт.

    Історія накопичується так само, як її веде веб-консоль, — саме на другій
    репліці 28.07 і вимкнулись правові ворота.
    """
    import engine
    history = []
    seen = []
    for text in replies:
        import taskdesk_identity as _tdid
        out = engine.handle_message(_tdid.resolve_actor(None), text, history=history)
        reply = (out or {}).get("reply") or ""
        extra = ""
        res = (out or {}).get("result") or {}
        if isinstance(res, dict):
            extra = res.get("markdown") or res.get("primary_markdown") or ""
        visible = (reply + "\n" + extra).strip()
        seen.append({"питання": text, "видно": visible, "raw": out})
        history.append({"role": "user", "content": text})
        history.append({"role": "assistant", "content": reply})
    return seen


# ── ЧЕКИ ─────────────────────────────────────────────────────────────────

_ok = [0]
_bad = []


def check(cond, title, evidence=""):
    n = _ok[0] = _ok[0] + 1
    print("  [%02d] %s - %s" % (n, "PASS" if cond else "FAIL", title))
    if not cond:
        _bad.append(title)
        if evidence:
            for line in str(evidence).splitlines()[:6]:
                print("         | " + line[:160])


def _has(text, *words):
    t = (text or "").lower()
    return any(w.lower() in t for w in words)


def scenario(title):
    print("-" * 62)
    print("  СЦЕНАРІЙ: " + title)


# ── СЦЕНАРІЇ (усі шість — з болю 28.07.2026) ─────────────────────────────

TENDER = "UA-2026-07-22-012074-a"


def s1_continue_keeps_legal_gate():
    scenario("1. Питання з номером -> «продовжуй» без номера")
    stub = Stub(
        brain_turns=[
            {"text": "Тендер %s: спрощена оборонна закупівля. Строк подання — "
                     "за ст. 14 ЗУ 922." % TENDER},
            {"text": "Продовжую: скарга до АМКУ в цій процедурі не передбачена."},
        ],
        worker_text="Відповідь юриста.")
    install(stub)
    try:
        seen = play(["Що по тендеру %s?" % TENDER, "продовжуй"], stub)
    finally:
        restore()
    second = seen[1]["видно"]
    check(not _has(second, "вкажіть номер тендера", "не вказано номер",
                   "уточніть номер"),
          "друга репліка «продовжуй» НЕ втрачає тендер із розмови", second)
    check(len(second.strip()) > 0, "на «продовжуй» узагалі є що показати людині", second)
    return seen


def s2_question_without_number():
    scenario("2. «А якщо відхилять?» — питання без номера в тій самій розмові")
    stub = Stub(
        brain_turns=[
            {"text": "Тендер %s: спрощена оборонна закупівля." % TENDER},
            {"text": "Якщо відхилять — оскарження в цій процедурі не передбачене."},
        ],
        worker_text="Відповідь юриста.")
    install(stub)
    try:
        seen = play(["Розбери тендер %s" % TENDER, "а якщо відхилять?"], stub)
    finally:
        restore()
    second = seen[1]["видно"]
    check(not _has(second, "вкажіть номер", "уточніть, про який тендер"),
          "система розуміє, про який тендер мова, без повторного номера", second)
    return seen


def s3_budget_pause():
    scenario("3. Прогін впирається в межу вартості")
    stub = Stub(
        brain_turns=[{"tool": "run_system",
                      "args": {"system_id": "legal_assistant",
                               "task": "Розбери тендер %s" % TENDER}},
                     {"relay": True}],
        worker_text="Довга відповідь юриста.",
        tokens_per_call=400000)
    install(stub)
    try:
        seen = play(["Розбери тендер %s детально" % TENDER], stub)
    finally:
        restore()
    # ⚠ ЧЕСНА МЕЖА СЦЕНАРІЮ: остаточні слова клієнту пише жива модель, а тут
    # вона — заглушка. Тому перевіряємо не красу формулювання, а те, що в нашій
    # владі: чи гроші СПРАВДІ зупинились і чи мозку дано правильну команду.
    tool = stub.last_tool_result or ""
    check(stub.worker_calls > 0, "прогін справді дійшов до виконавця, а не обірвався раніше",
          "викликів виконавця: %d" % stub.worker_calls)
    check(_has(tool, "паузі за вартістю", "на паузі"),
          "на межі прогін СТАЄ НА ПАУЗУ, а не тихо доробляє за гроші клієнта", tool)
    check(_has(tool, "зібрати відповідь") and _has(tool, "підняти межу"),
          "клієнту дають РІВНО ДВА варіанти, а не тупик", tool)
    check(re.search(r"запропонуй \$\d", tool or "") is not None,
          "пропонується конкретна нова сума, а не «підвищіть щось»", tool)
    check(_has(tool, "без назв файлів, налаштувань і службових слів"),
          "продукт САМ наказує мозку говорити людською мовою", tool)
    check(_has(tool, "за вже зроблене повторно НЕ платять"),
          "клієнт не платить двічі за вже оплачене", tool)
    return seen


def s4_provider_refuses():
    scenario("4. Виконавець відмовляє посеред роботи (чужа квота)")
    stub = Stub(
        brain_turns=[{"tool": "run_system",
                      "args": {"system_id": "legal_assistant",
                               "task": "Розбери тендер %s" % TENDER}},
                     {"relay": True}],
        worker_error=llm.LLMError("429 quota exceeded for project 12345"))
    install(stub)
    try:
        seen = play(["Розбери тендер %s" % TENDER], stub)
    finally:
        restore()
    v = seen[0]["видно"]
    check(not _has(v, "traceback", "quota exceeded for project", "429"),
          "клієнт НЕ бачить сирої помилки провайдера", v)
    check(len(v.strip()) > 20, "клієнт бачить людське пояснення, а не порожнечу", v)
    return seen


def s5_no_access_to_prozorro():
    scenario("5. Фраза «не маю доступу до Прозорро» має бути НЕМОЖЛИВОЮ")
    stub = Stub(
        brain_turns=[{"text": "На жаль, я не маю доступу до Прозорро і не можу "
                              "подивитись цей тендер."}])
    install(stub)
    try:
        seen = play(["Подивись тендер %s" % TENDER], stub)
    finally:
        restore()
    v = seen[0]["видно"]
    check(not _has(v, "не маю доступу до прозорро", "немає доступу до прозорро",
                   "не можу подивитись цей тендер"),
          "платформа НЕ віддає клієнту фразу про відсутній доступ (міст на "
          "107 198 пар у нас є)", v)
    return seen


def s6_no_invented_norm():
    scenario("6. Питання не про тендер — юрист не вигадує норму")
    stub = Stub(
        brain_turns=[{"text": "Строк подання — 7 днів."}])
    install(stub)
    try:
        seen = play(["Скільки днів на відповідь за договором постачання?"], stub)
    finally:
        restore()
    v = seen[0]["видно"]
    check(not re.search(r"\b\d+\s*(дн|днів|день)\b.*ст\.\s*\d+", v or "", re.S)
          or _has(v, "джерел", "ст.", "закон"),
          "строк без прив'язки до акта не подається як факт", v)
    return seen


SCENARIOS = [s1_continue_keeps_legal_gate, s2_question_without_number,
             s3_budget_pause, s4_provider_refuses,
             s5_no_access_to_prozorro, s6_no_invented_norm]


def main():
    print("=" * 62)
    print("  РОБОТ-КЛІЄНТ — програю розмови так, як їх грає людина")
    print("  Модель підмінена заглушкою. Ворота, юрист, міст, гроші — справжні.")
    print("  Вартість прогону: $0")
    print("=" * 62)
    transcripts = []
    for fn in SCENARIOS:
        try:
            transcripts.append((fn.__name__, fn()))
        except Exception:
            check(False, "сценарій %s упав з винятком" % fn.__name__,
                  traceback.format_exc())
            restore()
    print("=" * 62)
    print("  СТЕНОГРАМА (те, що побачила б людина)")
    for name, seen in transcripts:
        print("  --- %s ---" % name)
        for step in seen:
            print("    ЛЮДИНА: " + step["питання"])
            for line in (step["видно"] or "(порожньо)").splitlines()[:10]:
                print("    ЕКРАН : " + line[:150])
    print("=" * 62)
    if _bad:
        print("РОБОТ-КЛІЄНТ: FAIL (%d із %d)" % (len(_bad), _ok[0]))
        for t in _bad:
            print("   - " + t)
        return 1
    print("РОБОТ-КЛІЄНТ: PASS (%d чеків)" % _ok[0])
    return 0


if __name__ == "__main__":
    sys.exit(main())
