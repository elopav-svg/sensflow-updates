# -*- coding: utf-8 -*-
"""clock.py — ОДИН ПИСАР ЧАСУ НА ВЕСЬ ПРОДУКТ.

⭐⭐⭐ КОРІНЬ 05.08.2026 (лікувався в CRM, узагальнено 06.08.2026).
Записи роблять різні процеси, і частина з них живе за UTC. Через це в історії
клієнта запис «о 15:18» опинявся ПІСЛЯ запису «о 18:08»: журнал, який ми самі
ведемо, ставав нечитабельним. Причина не в тому, ХТО пише, а в тому, що час
брався з годинника машини.

Тому час у продукті має ОДНЕ джерело — цей файл. Хто заводить новий журнал
(картка CRM, задача розкладу, Task Desk) — бере час звідси, а не з `datetime`.
Другий писар часу = розбіжність у журналі, яку потім нікому не довести.
"""
from datetime import datetime, timedelta

KYIV_OFFSET_HOURS = 3          # Europe/Kiev, літній час (UTC+3)


def now() -> str:
    """Київський час у вигляді ISO до секунд, з якої б машини не прийшов запис."""
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("Europe/Kiev")).replace(
            tzinfo=None).isoformat(timespec="seconds")
    except Exception:
        # Немає бази часових зон (буває у мінімальних збірках) — рахуємо від UTC.
        return (datetime.utcnow() + timedelta(hours=KYIV_OFFSET_HOURS)).isoformat(
            timespec="seconds")
