# -*- coding: utf-8 -*-
"""
run_log.py — ⭐ ВИВІД ПРОГОНУ ЙДЕ ОДНОЧАСНО НА ЕКРАН І У ФАЙЛ logs\\.

ЧОМУ ЦЕЙ МОДУЛЬ ІСНУЄ (Статут №15, 27.07.2026).

  КЛАС ПРОБЛЕМИ: результат прогону існував ЛИШЕ на екрані Андрія. Батник
  робив «python ... + pause» і не писав нічого. Тому єдиним способом
  показати мені, що видала жива проба, були СКРІНШОТИ — сім штук, зроблених
  руками. Андрій справедливо спитав: «чого ти не прочитаєш лог сам?». Логу
  не існувало.

  ТОЧКА РІШЕННЯ: одна — тут. Не в кожному батнику (їх сорок, ASCII-only,
  і перенаправлення «> file» забрало б у Андрія екран), а в python-старті
  прогону: пишемо В ОБИДВА місця.

  ВСІ КАНАЛИ: усі тендерні проби + живий прогін сторожа.

  ЧИ ПРОТЕЧЕ МАЙБУТНІЙ КАНАЛ: нова проба без цього рядка протекла б. Тому
  tender_render_test.py СКАНУЄ файли прогонів і падає, якщо котрийсь не
  підключив run_log. Домовленість на словах не тримає — тримає чек.

Підключення (один рядок у блоці __main__ прогону):
    import run_log; run_log.start("імʼя_прогону")
"""
import atexit
import datetime
import io
import os
import sys

LOGS_DIR = "logs"
_opened = []


class _Tee(object):
    """Пише в кілька потоків одразу. Помилка одного не валить прогін."""

    def __init__(self, *streams):
        self._streams = streams

    def write(self, data):
        # ⭐⭐⭐ 09.08.2026. ЖУРНАЛ, ЯКИЙ ЗАПОВНЮЄТЬСЯ ЛИШЕ ПРИ ВИХОДІ, — ЦЕ НЕ
        # ЖУРНАЛ. Файл був повністю буферизований: усе, що продукт друкував,
        # лежало в памʼяті до кінця процесу. Для проби (секунди) це не було
        # видно, а СЕРВЕР живе годинами — і в його лозі стояв рівно один
        # рядок. Тому збою доставки задач у телеграм у лозі не було ВИДНО,
        # хоча рот справно писав про нього.
        #
        # Лікуємо в ОДНІЙ точці — там, де вивід роздвоюється, — а не проханням
        # до кожного автора «не забудь flush». Ціна: скидання на диск раз на
        # рядок; вивід продукту — це десятки рядків, не мегабайти.
        for s in self._streams:
            try:
                s.write(data)
                if "\n" in (data or ""):
                    s.flush()
            except Exception:
                pass
        return len(data or "")

    def flush(self):
        for s in self._streams:
            try:
                s.flush()
            except Exception:
                pass

    def isatty(self):
        return False


def logs_dir():
    """Де живуть журнали — ОДНА точка на модуль.

    ⭐ 29.07.2026. Бойова тека рушія, а в пісочниці (SENSFLOW_STATE_DIR) — тека
    пісочниці: наші власні чеки не смітять у теку, яка їде клієнту
    [[project_state_isolation]]. Свідомо БЕЗ `import config` — цим модулем
    користуються проби, які стартують ДО конфігурації рушія.
    """
    engine = os.path.dirname(os.path.abspath(__file__))
    # ⭐⭐⭐ 01.08.2026 (живий випадок). ДОКАЗ, ЗАПИСАНИЙ ТУДИ, ДЕ ЙОГО НІХТО НЕ
    # ШУКАЄ, — ЦЕ НЕ ДОКАЗ. Андрій прогнав пробу архіву торгів; вона чесно
    # відпрацювала й лягла журналом у тимчасову теку системи — недосяжну ні для
    # нього, ні для мене. Ізоляція чеків мала одну мету: не смітити СТАНОМ у теки,
    # що їдуть клієнту. Журнал — не стан, а єдиний канал доказу.
    # Розрізняємо ДВА випадки:
    #   • стан відвели МИ САМІ (`SENSFLOW_CHECK_AUTOSTATE`) -> журнал у теку рушія;
    #   • пісочницю попросили ЯВНО (selfcheck, мутації) -> усе туди, як і було.
    if os.environ.get("SENSFLOW_CHECK_AUTOSTATE") == "1":
        return os.path.join(engine, LOGS_DIR)
    root = os.environ.get("SENSFLOW_STATE_DIR") or engine
    return os.path.join(root, LOGS_DIR)


def log_path(name, when=None):
    """Куди ляже лог цього прогону (без створення файлу)."""
    stamp = (when or datetime.datetime.now()).strftime("%Y-%m-%d_%H%M%S")
    return os.path.join(logs_dir(), "%s_%s.log" % (name, stamp))


def latest(name):
    """Найсвіжіший журнал із цим імʼям або None (для звіту підтримки)."""
    try:
        d = logs_dir()
        files = [os.path.join(d, f) for f in os.listdir(d)
                 if f.startswith(str(name) + "_") and f.endswith(".log")]
        return max(files, key=os.path.getmtime) if files else None
    except Exception:
        return None


def prune(name, keep=20):
    """Лишає `keep` найсвіжіших журналів цього імені, решту прибирає.

    ⭐ Запобіжник може сам смітити: щоденний запуск продукту за рік дав би
    сотні файлів у теці клієнта. Чистимо по ФАКТУ вмісту теки, не «памʼятаючи»
    про це десь в іншому місці.
    """
    n = 0
    try:
        d = logs_dir()
        files = sorted([os.path.join(d, f) for f in os.listdir(d)
                        if f.startswith(str(name) + "_") and f.endswith(".log")],
                       key=os.path.getmtime, reverse=True)
        for path in files[max(int(keep), 1):]:
            try:
                os.remove(path)
                n += 1
            except Exception:
                pass
    except Exception:
        pass
    return n


def start(name, when=None):
    """Вмикає подвійний вивід. Повертає шлях до лога і друкує його на екран.

    Файл закривається сам при виході — навіть якщо прогін упав із помилкою,
    у лозі лишається все, що встигло надрукуватись, включно з трасуванням.
    """
    path = log_path(name, when)
    folder = os.path.dirname(path)
    if not os.path.isdir(folder):
        os.makedirs(folder)
    # Прибирання — ТУТ, а не в кожному викликачі: інакше наступний автор про
    # нього не знатиме, і тека власника заросте журналами за рік.
    prune(name, keep=20)
    # ⭐⭐⭐ 06.08.2026. КОНСОЛЬ WINDOWS — ЦЕ cp1251, І ВОНА ВБИВАЛА ПРОГОНИ.
    # Український апостроф «ʼ» (U+02BC) у виводі не влазить у cp1251, і замість
    # результату чека Андрій отримував UnicodeEncodeError. Лікуємо в ОДНОМУ
    # місці — там, де прогін бере свій вивід, — а не проханням до авторів чеків
    # «не вживайте апостроф»: правило в голові автора воротами не є.
    for _stream in (sys.stdout, sys.stderr):
        try:
            _stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass      # старий python або підмінений потік — не привід падати
    # buffering=1 — порядкова буферизація: другий запобіжник на випадок, якщо
    # хтось колись обійде _Tee і писатиме у файл напряму.
    f = io.open(path, "w", encoding="utf-8", buffering=1)
    _opened.append(f)
    sys.stdout = _Tee(sys.stdout, f)
    sys.stderr = _Tee(sys.stderr, f)
    print("LOG: %s" % path)
    sys.stdout.flush()
    return path


@atexit.register
def _close():
    for f in _opened:
        try:
            f.flush()
            f.close()
        except Exception:
            pass
