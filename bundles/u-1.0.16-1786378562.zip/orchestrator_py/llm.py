"""
llm.py — провайдер-агностичний клієнт LLM (OpenAI + Anthropic + Gemini; маршрут за моделлю).

Тільки стандартна бібліотека (urllib). Один публічний метод: complete().
Чесна деградація: якщо ключ не заданий — кидає LLMNotConfigured, а рушій
показує це користувачу як технічну проблему конфігурації, а не як фейкову відповідь.
"""

import json
import socket
import sys
import time
import urllib.request
import urllib.error

import config


class LLMNotConfigured(Exception):
    pass


class LLMError(Exception):
    pass


class JudgeUnavailable(LLMError):
    """Судження моделі НЕ отримано після повтору й ескалації на надійну модель.

    Окремий клас, а не звичайний LLMError: викликач мусить мати змогу відрізнити
    «модель сказала ні» від «моделі не вдалося спитати». Несе перелік спроб —
    щоб у журналі було видно, ЩО саме пробували, а не лише останній рядок.
    """

    def __init__(self, message, attempts=None):
        LLMError.__init__(self, message)
        self.attempts = list(attempts or [])


class BudgetExceeded(LLMError):
    """Прогін вичерпав АВАРІЙНУ межу вартості. Свідомо підклас LLMError — щоб усі
    наявні мʼякі деградації спрацювали самі: крок пропускається, резервна модель
    не кличеться, робота клієнта не валиться з трасою помилки."""


def _log(msg):
    sys.stderr.write(msg + "\n")
    sys.stderr.flush()


def _http_post(url: str, headers: dict, payload: dict, timeout: int = None, _attempt: int = 1) -> dict:
    _is_local = bool(config.LOCAL_BASE_URL) and config.LOCAL_BASE_URL in url
    prov = ("anthropic" if "anthropic.com" in url
            else "gemini" if "googleapis.com" in url
            else "moonshot" if "moonshot" in url
            else "local" if _is_local else "openai")
    # Локальні моделі рахують повільно — їм окремий, набагато більший таймаут.
    tmo = timeout or (config.LOCAL_TIMEOUT if _is_local else config.LLM_TIMEOUT)
    t0 = time.time()
    _log(f"[llm] -> {prov} model={payload.get('model')} timeout={tmo}s")
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=tmo) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
        _log(f"[llm] <- {prov} OK за {time.time()-t0:.1f}s")
        data = json.loads(raw)
        # Облік вартості (оцінка): єдина точка — усі виклики йдуть через _http_post.
        try:
            import costs
            u = data.get("usage") or {}
            it = u.get("input_tokens", u.get("prompt_tokens", 0))
            ot = u.get("output_tokens", u.get("completion_tokens", 0))
            costs.record(payload.get("model"), it, ot)
        except Exception:
            pass
        return data
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8", errors="replace")
        except Exception:
            detail = ""
        # Вичерпані кредити/квота/білінг — це НЕ тимчасово (буває і 429, і 400):
        # повтори марні, тож одразу падаємо з людською підказкою.
        _dl = (detail or "").lower()
        if ("insufficient_quota" in _dl or "exceeded your current quota" in _dl
                or "credit balance is too low" in _dl or "billing" in _dl
                or "plans & billing" in _dl):
            _log(f"[llm] !! {prov} рахунок вичерпано (кредити/квота) — без повторів")
            raise LLMError(
                f"Рахунок {prov} вичерпано — немає кредитів/квоти. Поповніть баланс {prov} "
                f"АБО перемкніть провайдера у консолі (кнопка «⚙ змінити» вгорі ліворуч).")
        # Авто-повтор при ліміті (429) або тимчасовій помилці (5xx) — до 3 спроб.
        if e.code in (429, 500, 502, 503, 529) and _attempt < 3:
            import time as _t
            wait = 4 * _attempt
            _log(f"[llm] !! {prov} HTTP {e.code} — повтор #{_attempt+1} через {wait}s")
            _t.sleep(wait)
            return _http_post(url, headers, payload, timeout, _attempt + 1)
        # ⭐ 10.08.2026, зміна 146. «ТАКОЇ МОДЕЛІ НЕМАЄ» — ОСТАТОЧНО.
        # Сирий JSON провайдера людині не їде; модель вибуває з драбини.
        if is_model_gone_error(e.code, detail):
            _mdl = ""
            try:
                _mdl = str((payload or {}).get("model") or "")
            except Exception:
                pass
            if not _mdl:
                import re as _re
                _m = _re.search(r"models/([A-Za-z0-9._-]+)", detail or "")
                _mdl = _m.group(1) if _m else ""
            mark_model_gone(_mdl, "HTTP 404: %s" % (detail or "")[:200])
            raise LLMError(gone_message(_mdl, prov))
        _log(f"[llm] !! {prov} HTTP {e.code} за {time.time()-t0:.1f}s: {detail[:400]}")
        raise LLMError(f"HTTP {e.code} від {prov}: {detail[:600]}")
    except urllib.error.URLError as e:
        reason = str(getattr(e, "reason", e))
        rl = reason.lower()
        # SSL-сертифікати не встановлені (типово на macOS, python.org-збірка) — повтори марні, даємо чітку підказку.
        if ("certificate_verify_failed" in rl or "unable to get local issuer" in rl
                or "certificate verify failed" in rl):
            raise LLMError(
                "SSL-сертифікати Python не встановлені (типово на macOS). Це НЕ про ключ. "
                "У Terminal виконай одну команду: "
                "open \"/Applications/Python 3.14/Install Certificates.command\" "
                "(підстав свою версію Python — глянь у /Applications), дочекайся «update complete» і "
                "ПЕРЕЗАПУСТИ SensFlow. Після цього перевірка ключа пройде.")
        # Тимчасовий мережевий/DNS-збій (getaddrinfo, відмова/скидання зʼєднання) — перечекати й повторити.
        transient = ("getaddrinfo" in rl or "name or service" in rl or "temporary failure" in rl
                     or "11001" in rl or "11002" in rl or "connection" in rl or "reset" in rl
                     or "unreachable" in rl)
        # Таймаут зʼєднання (приходить як URLError) — теж тимчасовий, теж повторюємо.
        if (transient or "timed out" in rl) and _attempt < 3:
            import time as _t
            wait = 2 * _attempt
            _log(f"[llm] !! {prov} мережа ({reason[:50]}) — повтор #{_attempt+1} через {wait}s")
            _t.sleep(wait)
            return _http_post(url, headers, payload, timeout, _attempt + 1)
        _log(f"[llm] !! {prov} URLError за {time.time()-t0:.1f}s: {reason}")
        raise LLMError(f"Мережа/DNS {prov}: {reason}. Перевір інтернет/VPN і повтори запит.")
    except (TimeoutError, socket.timeout) as e:
        # READ-таймаут: запит пішов, але відповідь не дочиталася вчасно. Майже завжди
        # тимчасово — повторний виклик зазвичай відповідає одразу. До 2 повторів (разом
        # 3 спроби), коротка пауза (таймаут уже зʼїв багато часу). ⚠ _http_post — СПІЛЬНА
        # точка ВСІХ систем, тож ця стійкість підсилює всі флагмани нараз. Раніше цей
        # випадок падав у загальний except БЕЗ повтору → «Несподівана помилка ... timed out».
        if _attempt < 3:
            import time as _t
            wait = 3 * _attempt
            _log(f"[llm] !! {prov} read-таймаут — повтор #{_attempt+1} через {wait}s")
            _t.sleep(wait)
            return _http_post(url, headers, payload, timeout, _attempt + 1)
        _log(f"[llm] !! {prov} read-таймаут вичерпав {_attempt} спроби за {time.time()-t0:.1f}s")
        raise LLMError(f"{prov}: сервіс не встиг відповісти вчасно навіть після повторів "
                       "(таймаут). Спробуй ще раз за хвилину або перемкни провайдера у консолі.")
    except Exception as e:  # noqa
        _log(f"[llm] !! {prov} помилка за {time.time()-t0:.1f}s: {e}")
        raise LLMError(f"Несподівана помилка {prov}: {e}")


# ---------------------------------------------------------------------------
# Потокове читання (SSE) для довгих викликів із веб-пошуком.
# КОРІНЬ ФІКСУ ТАЙМАУТУ: сервер може довго шукати (кілька пошуків за виклик), і в
# НЕпотоковому режимі канал мовчить → «таймаут тиші» рве живий запит. У потоці
# сервер шле події (текст + службові ping), тож таймаут рахуємо від ОСТАННЬОГО
# отриманого шматка (idle) — пауза на пошук більше не вбиває виклик. Загальний
# запобіжник (cap) чесно спиняє лише СПРАВЖНЄ зависання. Відповідь збираємо в ТУ
# САМУ форму, що й _http_post: {"content":[...],"usage":{...}} — щоб наявні
# розбирачі працювали без змін.
# ---------------------------------------------------------------------------
def _prov_of(url: str) -> str:
    return ("anthropic" if "anthropic.com" in url
            else "gemini" if "googleapis.com" in url
            else "moonshot" if "moonshot" in url else "openai")


def _record_cost(model, usage):
    try:
        import costs
        costs.record(model, usage.get("input_tokens", 0), usage.get("output_tokens", 0))
    except Exception:
        pass


def _safe_json(s):
    s = (s or "").strip()
    if not s or s == "[DONE]":
        return None
    try:
        return json.loads(s)
    except Exception:
        return None


def _open_stream(url: str, headers: dict, payload: dict, idle: int, prov: str, _attempt: int = 1):
    """Відкриває потокове з'єднання. Помилки СТАРТУ: білінг/квота — без повтору; 429/5xx
    або тимчасова мережа — ОДИН безпечний повтор (жоден пошук ще не витрачено). Повертає
    відкритий resp або кидає LLMError."""
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    try:
        return urllib.request.urlopen(req, timeout=idle)
    except urllib.error.HTTPError as e:
        try:
            detail = e.read().decode("utf-8", errors="replace")
        except Exception:
            detail = ""
        _dl = (detail or "").lower()
        if ("insufficient_quota" in _dl or "exceeded your current quota" in _dl
                or "credit balance is too low" in _dl or "billing" in _dl
                or "plans & billing" in _dl):
            _log(f"[llm] !! {prov} рахунок вичерпано (кредити/квота) — без повторів")
            raise LLMError(
                f"Рахунок {prov} вичерпано — немає кредитів/квоти. Поповніть баланс {prov} "
                f"АБО перемкніть провайдера у консолі (кнопка «⚙ змінити» вгорі ліворуч).")
        if e.code in (429, 500, 502, 503, 529) and _attempt < 2:
            import time as _t
            _t.sleep(4 * _attempt)
            _log(f"[llm] !! {prov} STREAM HTTP {e.code} на старті — повтор #{_attempt+1}")
            return _open_stream(url, headers, payload, idle, prov, _attempt + 1)
        _log(f"[llm] !! {prov} STREAM HTTP {e.code}: {detail[:400]}")
        raise LLMError(f"HTTP {e.code} від {prov}: {detail[:600]}")
    except urllib.error.URLError as e:
        reason = str(getattr(e, "reason", e))
        rl = reason.lower()
        if ("certificate_verify_failed" in rl or "unable to get local issuer" in rl
                or "certificate verify failed" in rl):
            raise LLMError(
                "SSL-сертифікати Python не встановлені (типово на macOS). Це НЕ про ключ. "
                "У Terminal виконай: open \"/Applications/Python 3.14/Install Certificates.command\" "
                "(підстав свою версію Python), дочекайся «update complete» і ПЕРЕЗАПУСТИ SensFlow.")
        transient = ("getaddrinfo" in rl or "name or service" in rl or "temporary failure" in rl
                     or "11001" in rl or "11002" in rl or "connection" in rl or "reset" in rl
                     or "unreachable" in rl or "timed out" in rl)
        if transient and _attempt < 2:
            import time as _t
            _t.sleep(2 * _attempt)
            _log(f"[llm] !! {prov} STREAM мережа ({reason[:40]}) на старті — повтор #{_attempt+1}")
            return _open_stream(url, headers, payload, idle, prov, _attempt + 1)
        raise LLMError(f"Мережа/DNS {prov}: {reason}. Перевір інтернет/VPN і повтори запит.")


def _stream_events(url: str, headers: dict, payload: dict,
                   idle_timeout: int = None, total_cap: int = None, stream_flag: bool = True):
    """ЄДИНИЙ транспорт потоку (SSE) для всіх провайдерів. Тримає з'єднання живим: таймаут
    рахується від ОСТАННЬОГО шматка (idle), а не від початку — сервер може довго шукати
    (шле ping/службові події). cap — стеля на весь виклик (запобіжник від справжнього
    зависання). Генерує (event_name, obj) на кожну SSE-подію. Anthropic/OpenAI вмикають
    потік полем stream:true; Gemini — окремим ендпоінтом (stream_flag=False)."""
    prov = _prov_of(url)
    idle = idle_timeout or config.WEB_SEARCH_TIMEOUT
    cap = total_cap or getattr(config, "WEB_SEARCH_TOTAL_CAP", 300)
    p = dict(payload)
    if stream_flag:
        p["stream"] = True
    t0 = time.time()
    _log(f"[llm] -> {prov} model={p.get('model')} STREAM idle={idle}s cap={cap}s")
    resp = _open_stream(url, headers, p, idle, prov)
    event_name = None
    data_lines = []
    n = 0
    try:
        while True:
            if time.time() - t0 > cap:
                _log(f"[llm] !! {prov} STREAM перевищив стелю {cap}s — стоп")
                raise LLMError(f"{prov}: веб-пошук перевищив ліміт часу {cap}s. "
                               "Спробуй вужчий запит або повтори за хвилину.")
            try:
                raw = resp.readline()
            except (TimeoutError, socket.timeout):
                _log(f"[llm] !! {prov} STREAM тиша > {idle}s — чесний стоп")
                raise LLMError(f"{prov}: сервіс не відповідає (тиша {idle}s під час пошуку). "
                               "Спробуй ще раз за хвилину або перемкни провайдера у консолі.")
            if not raw:
                if data_lines:
                    n += 1
                    yield (event_name, _safe_json("\n".join(data_lines)))
                break
            line = raw.decode("utf-8", errors="replace").rstrip("\r\n")
            if line == "":
                if data_lines:
                    n += 1
                    yield (event_name, _safe_json("\n".join(data_lines)))
                event_name = None
                data_lines = []
                continue
            if line.startswith(":"):
                continue
            if line.startswith("event:"):
                event_name = line[6:].strip()
            elif line.startswith("data:"):
                data_lines.append(line[5:].lstrip())
    finally:
        try:
            resp.close()
        except Exception:
            pass
    _log(f"[llm] <- {prov} STREAM закрито за {time.time()-t0:.1f}s (подій={n})")


def _http_post_stream(url: str, headers: dict, payload: dict,
                      idle_timeout: int = None, total_cap: int = None) -> dict:
    """Anthropic Messages (веб-пошук) через потік → форма {"content":[...],"usage":{...}},
    ідентична НЕпотоковому виклику (розбирач _search_anthropic не змінюється)."""
    blocks = {}
    order = []
    usage = {"input_tokens": 0, "output_tokens": 0}
    stop_reason = None
    for ev, obj in _stream_events(url, headers, payload, idle_timeout, total_cap):
        if obj is None:
            continue
        etype = obj.get("type") or ev
        if etype == "error":
            err = obj.get("error") or {}
            raise LLMError(f"anthropic потік-помилка: {err.get('message') or err}")
        if etype == "message_start":
            u = (obj.get("message") or {}).get("usage") or {}
            usage["input_tokens"] = u.get("input_tokens", usage["input_tokens"])
            usage["output_tokens"] = u.get("output_tokens", usage["output_tokens"])
        elif etype == "content_block_start":
            i = obj.get("index", len(order))
            cb = dict(obj.get("content_block") or {})
            if cb.get("type") == "text":
                cb.setdefault("text", "")
                cb.setdefault("citations", [])
            blocks[i] = cb
            if i not in order:
                order.append(i)
        elif etype == "content_block_delta":
            i = obj.get("index")
            d = obj.get("delta") or {}
            b = blocks.get(i)
            if b is None:
                b = {"type": "text", "text": "", "citations": []}
                blocks[i] = b
                order.append(i)
            dt = d.get("type")
            if dt == "text_delta":
                b["text"] = (b.get("text") or "") + (d.get("text") or "")
            elif dt == "citations_delta":
                cit = d.get("citation")
                if cit:
                    b.setdefault("citations", []).append(cit)
        elif etype == "message_delta":
            u = obj.get("usage") or {}
            if "output_tokens" in u:
                usage["output_tokens"] = u["output_tokens"]
            sr = (obj.get("delta") or {}).get("stop_reason")
            if sr:
                stop_reason = sr
    content = [blocks[i] for i in order]
    _record_cost(payload.get("model"), usage)
    _log(f"[llm] <- anthropic STREAM зібрано блоків={len(content)}")
    return {"content": content, "usage": usage, "stop_reason": stop_reason}


def _gen_budget(is_local: bool):
    """(idle, cap) для потокової ГЕНЕРАЦІЇ. Хмара: швидкий idle, бо провайдер сипле
    токени безперервно (тиша > idle = справжній завис → резерв спрацьовує швидко).
    Локаль: перший токен може йти довго (модель вантажиться в памʼять) — даємо
    LOCAL_TIMEOUT на idle й не менше нього на стелю, щоб не рвати живу локальну збірку."""
    if is_local:
        lt = config.LOCAL_TIMEOUT
        return (lt, max(getattr(config, "GEN_STREAM_CAP", 600), lt))
    return (getattr(config, "GEN_STREAM_IDLE", 120), getattr(config, "GEN_STREAM_CAP", 600))


def _chat_stream(url: str, headers: dict, payload: dict,
                 idle_timeout: int = None, total_cap: int = None) -> dict:
    """OpenAI-сумісний /chat/completions (OpenAI/Gemini/Kimi/локаль) через ПОТІК →
    форма {"choices":[{"message":{"content":...}}],"usage":{...}}, ідентична
    НЕпотоковому виклику (розбирач _call_openai не змінюється)."""
    prov = _prov_of(url)
    p = dict(payload)
    # Облік токенів у потоці просимо ЛИШЕ у справжнього OpenAI — інші OpenAI-сумісні
    # (Gemini/Kimi/локаль) можуть відхилити цей параметр.
    if "api.openai.com" in url:
        p["stream_options"] = {"include_usage": True}
    parts = []
    usage = {"input_tokens": 0, "output_tokens": 0}
    finish = None
    for ev, obj in _stream_events(url, headers, p, idle_timeout, total_cap):
        if obj is None:
            continue
        err = obj.get("error")
        if isinstance(err, dict):
            raise LLMError(f"{prov} потік-помилка: {err.get('message') or err}")
        for ch in obj.get("choices", []) or []:
            delta = ch.get("delta") or {}
            if delta.get("content"):
                parts.append(delta["content"])
            if ch.get("finish_reason"):
                finish = ch["finish_reason"]
        u = obj.get("usage") or {}
        if u:
            usage["input_tokens"] = u.get("prompt_tokens", usage["input_tokens"])
            usage["output_tokens"] = u.get("completion_tokens", usage["output_tokens"])
    _record_cost(payload.get("model"), usage)
    return {"choices": [{"message": {"role": "assistant", "content": "".join(parts)},
                         "finish_reason": finish}],
            "usage": {"prompt_tokens": usage["input_tokens"],
                      "completion_tokens": usage["output_tokens"]}}


def _call_openai(system: str, user: str, temperature: float, max_tokens: int, model: str = None,
                 provider: str = None, timeout: int = None, stream: bool = False) -> str:
    # Працює для OpenAI і Gemini (OpenAI-сумісний ендпоінт): base+key за провайдером моделі.
    base, key = config.openai_compat(provider)
    if not key:
        raise LLMNotConfigured(f"Немає API-ключа провайдера {provider or config.LLM_PROVIDER} у .env.local")
    mdl = model or config.brain_model()
    _url = f"{base}/chat/completions"
    _headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {key}",
    }

    def _payload(with_temp):
        p = {
            "model": mdl,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "max_tokens": max_tokens,
        }
        # Деякі OpenAI-сумісні моделі (напр. kimi-k2.7-code-highspeed) приймають лише
        # власну температуру й відхиляють інші значення (HTTP 400 «invalid temperature»).
        # Такі моделі запам'ятовуємо в _NO_TEMPERATURE_MODELS і далі параметр не шлемо
        # (той самий механізм, що вже діє для Anthropic-гілки).
        if with_temp and mdl not in _NO_TEMPERATURE_MODELS:
            p["temperature"] = temperature
        return p

    _is_local = bool(config.LOCAL_BASE_URL) and config.LOCAL_BASE_URL in _url

    def _post(pl):
        # Важкі виклики — ПОТОКОМ (idle-таймаут), решта — доведений непотоковий шлях.
        if stream and getattr(config, "GEN_STREAM", True):
            _idle, _cap = _gen_budget(_is_local)
            return _chat_stream(_url, _headers, pl, idle_timeout=_idle, total_cap=_cap)
        return _http_post(_url, _headers, pl, timeout=timeout)

    try:
        data = _post(_payload(True))
    except LLMError as e:
        s = str(e)
        if "HTTP 400" in s and "temperature" in s.lower():
            _NO_TEMPERATURE_MODELS.add(mdl)
            _log(f"[llm] {provider or 'openai'}: {mdl} не приймає temperature — далі без нього")
            data = _post(_payload(False))
        else:
            raise
    try:
        return data["choices"][0]["message"]["content"] or ""
    except (KeyError, IndexError):
        raise LLMError(f"Неочікувана відповідь {config.LLM_PROVIDER}: {json.dumps(data)[:400]}")


# Моделі, які відхиляють параметр temperature (напр. claude-opus-4-8).
# Доповнюється на льоту при першому HTTP 400 про temperature, далі його не шлемо.
_NO_TEMPERATURE_MODELS = {"claude-opus-4-8"}


def _join_sys(system):
    return "".join(system) if isinstance(system, list) else system


def _sys_field(system, use_cache=True):
    """Системне поле для Anthropic із prompt-caching. ГАРАНТІЯ: конкатенація тексту
    блоків БАЙТ-У-БАЙТ = вхідному system (нуль зміни того, що бачить модель).
    - str >3000 символів -> один кеш-блок; <=3000 -> як є.
    - список сегментів -> блоки з кеш-брейкпоінтами після 1-го й останнього сегмента."""
    if isinstance(system, list):
        segs = [s for s in system if s]
        if not segs:
            return ""
        if not use_cache:
            return "".join(segs)
        blocks, last = [], len(segs) - 1
        for i, seg in enumerate(segs):
            blk = {"type": "text", "text": seg}
            if i == 0 or i == last:
                blk["cache_control"] = {"type": "ephemeral"}
            blocks.append(blk)
        return blocks
    if use_cache and system and len(system) > 3000:
        return [{"type": "text", "text": system, "cache_control": {"type": "ephemeral"}}]
    return system


def _call_anthropic(system: str, user: str, temperature: float, max_tokens: int, model: str = None,
                    timeout: int = None, stream: bool = False) -> str:
    if not config.ANTHROPIC_API_KEY:
        raise LLMNotConfigured("ANTHROPIC_API_KEY не заданий у .env.local")
    mdl = model or config.ANTHROPIC_MODEL

    def _payload(use_cache, with_temp):
        # Кешування великого системного промпту: повторні виклики з тим самим
        # system стають значно швидші й дешевші (prompt caching).
        sys_field = _sys_field(system, use_cache)
        p = {
            "model": mdl,
            "system": sys_field,
            "messages": [{"role": "user", "content": user}],
            "max_tokens": max_tokens,
        }
        if with_temp and mdl not in _NO_TEMPERATURE_MODELS:
            p["temperature"] = temperature
        return p

    _headers = {
        "Content-Type": "application/json",
        "x-api-key": config.ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
    }
    _url = "https://api.anthropic.com/v1/messages"

    def _post(pl):
        # Важкі виклики — ПОТОКОМ (перевикористовуємо доведений збирач Messages),
        # решта — доведений непотоковий шлях. Форма відповіді ідентична.
        if stream and getattr(config, "GEN_STREAM", True):
            _idle, _cap = _gen_budget(False)  # Anthropic — завжди хмара
            return _http_post_stream(_url, _headers, pl, idle_timeout=_idle, total_cap=_cap)
        return _http_post(_url, _headers, pl, timeout=timeout)

    try:
        data = _post(_payload(True, True))
    except LLMError as e:
        s = str(e)
        # 400 може бути через кешування АБО через непідтримуваний temperature — прибираємо обидва.
        if "HTTP 400" in s:
            if "temperature" in s.lower():
                _NO_TEMPERATURE_MODELS.add(mdl)
                _log(f"[llm] anthropic: {mdl} не приймає temperature — далі без нього")
            _log("[llm] anthropic: повтор без prompt-caching/temperature")
            data = _post(_payload(False, False))
        else:
            raise
    try:
        parts = data.get("content", [])
        return "".join(p.get("text", "") for p in parts if p.get("type") == "text")
    except Exception:
        raise LLMError(f"Неочікувана відповідь Anthropic: {json.dumps(data)[:400]}")


def ping(timeout: int = 15):
    """Швидка перевірка зв'язку з активним провайдером. Повертає (ok: bool, msg: str)."""
    t0 = time.time()
    try:
        prov = config.brain_provider()
        # Локальна модель при першому запиті вантажиться в памʼять — це довго.
        if prov == "local" and timeout < 90:
            timeout = 120
        if prov == "anthropic":
            if not config.ANTHROPIC_API_KEY:
                return (False, "немає ключа Anthropic")
            _http_post("https://api.anthropic.com/v1/messages",
                       {"Content-Type": "application/json", "x-api-key": config.ANTHROPIC_API_KEY,
                        "anthropic-version": "2023-06-01"},
                       {"model": config.brain_model(), "max_tokens": 8,
                        "messages": [{"role": "user", "content": "ок"}]}, timeout=timeout)
        else:
            base, key = config.openai_compat(prov)
            if not key:
                return (False, f"немає ключа {prov}")
            _http_post(f"{base}/chat/completions",
                       {"Content-Type": "application/json", "Authorization": f"Bearer {key}"},
                       {"model": config.brain_model(), "max_tokens": 8,
                        "messages": [{"role": "user", "content": "ок"}]}, timeout=timeout)
        return (True, f"OK за {time.time()-t0:.1f}s")
    except Exception as e:
        return (False, str(e)[:220])


def today_note() -> str:
    """Системний контекст із реальною сьогоднішньою датою — щоб модель не вважала,
    що зараз рік її навчання. ЄДИНЕ джерело правди про дату для УСІХ точок входу
    (complete, complete_json, search_complete і tool_turn мозку)."""
    import datetime
    note = ("[Системний контекст: сьогоднішня реальна дата — "
            + datetime.date.today().strftime("%d.%m.%Y")
            + ". Орієнтуйся САМЕ на неї, а не на рік свого навчання. Якщо потрібні "
            "актуальні дані (ринок, ціни, події, версії, чинні норми) — користуйся "
            "веб-пошуком, а не памʼяттю.]\n\n")
    # Локаль збірки (мова/право/валюта) — інжектиться ЛИШЕ для країнових збірок
    # (напр. Ізраїль: ru/IL/₪). Майстер (uk/UA/гривня) лишається без змін.
    try:
        if (config.UI_DEFAULT_LANG != "uk" or config.DEFAULT_JURISDICTION != "UA"
                or config.DEFAULT_CURRENCY != "UAH"):
            note += "[Системний контекст: " + config.locale_note() + "]\n\n"
    except Exception:
        pass
    return note


# ⭐⭐⭐ 29.07.2026. ЄДИНИЙ ВАРТОВИЙ ПЕРЕД ГРОШИМА.
# Публічна функція цього файлу, яка може дійти до мережі з викликом моделі, мусить
# АБО пройти `_budget_stop()`, АБО стояти в цьому переліку з написаною причиною.
# Третього не дано, і це перевіряє машина: `automation_cost_test` сам обчислює
# граф викликів у llm.py і знаходить кожну функцію, що дістає до мережі. Тому
# ЗАБУТИ вартового на новій функції не вийде — ворота почервоніють до збірки.
# (Саме так 29.07 знайшлася `embed()`: вона рахувала гроші, але вартового не мала.)
BUDGET_EXEMPT = {
    # Перевірка звʼязку — не робота клієнта, а діагностика. Вартість мізерна, і
    # блокувати діагностику межею вартості означало б: скінчились гроші —
    # скінчилась і можливість зрозуміти, ЧОМУ. Свідомий виняток.
    "ping": "діагностика звʼязку, а не робота клієнта",
}


def _budget_stop(where: str = ""):
    """Останній запобіжник ПЕРЕД платним викликом. Мʼяка зупинка (між кроками)
    лишається в executor; ця — проти втечі всередині одного кроку.

    ⭐ 29.07.2026: ПЕРШИМ ДІЛОМ переконуємось, що лічильник узагалі існує. Раніше
    прогін відкривав лише `engine.handle_message`, тож автоматизації, підтримка й
    сторож тендерів приходили сюди без лічильника — `over_hard_cap()` бачив нуль і
    чемно пропускав усе. Тепер канал без лічильника отримує прогін із базовою
    стелею і НАЗИВАЄ себе в журналі сервера [[project_run_cost_control]]."""
    try:
        import costs as _c
        _c.ensure_run(where or "llm")
        if _c.over_hard_cap():
            cap, spent = _c.run_cap(), _c.spent_usd()
            raise BudgetExceeded(
                "зупинено за межею вартості прогону: витрачено $%.2f при стелі $%.2f%s. "
                "Підняти межу можна рядком MAX_RUN_USD у файлі .env.local."
                % (spent, cap, (" (%s)" % where if where else "")))
        # ДЕННА межа — тільки для безпілотних спрацювань за розкладом. Питання
        # людини в чаті нею не блокується ніколи (рішення Андрія 29.07.2026).
        if _c.current_kind() == _c.KIND_AUTOMATION and _c.over_day_cap():
            raise BudgetExceeded(
                "зупинено за денною межею автоматизацій: за добу витрачено $%.2f "
                "при межі $%.2f%s. Підняти можна рядком MAX_DAY_USD у файлі .env.local."
                % (_c.day_spent_usd(), _c.day_cap(), (" (%s)" % where if where else "")))
    except BudgetExceeded:
        raise
    except Exception:
        return


def complete(system: str, user: str, temperature: float = None, max_tokens: int = None,
             model: str = None, timeout: int = None) -> str:
    """Єдина точка входу. model=None -> модель за замовчуванням (brain). Передай
    config.worker_model() для виконавчих викликів агентів. timeout=None -> стандартний
    (config.LLM_TIMEOUT); для важких викликів (фінальна збірка) передай більший."""
    _budget_stop("complete")
    if isinstance(system, list):
        _segs = [s for s in system if s]
        system = ([today_note() + _segs[0]] + _segs[1:]) if _segs else today_note()
    else:
        system = today_note() + (system or "")
    temperature = config.TEMPERATURE if temperature is None else temperature
    max_tokens = config.MAX_OUTPUT_TOKENS if max_tokens is None else max_tokens
    mdl = model or config.brain_model()
    prov = config.provider_for_model(mdl)  # маршрут за моделлю -> змішування ролей
    # ПОТІК — лише для ВАЖКИХ викликів (великий ліміт виводу) або локальної моделі:
    # саме там непотоковий канал ловив фальшивий таймаут і тягнув важкий 3× повтор.
    # Дрібні швидкі виклики лишаються на доведеному непотоковому транспорті.
    _stream = bool(getattr(config, "GEN_STREAM", True)
                   and (max_tokens >= getattr(config, "GEN_STREAM_MIN_TOKENS", 6000)
                        or prov == "local"))
    if prov == "anthropic":
        return _call_anthropic(system, user, temperature, max_tokens, mdl,
                               timeout=timeout, stream=_stream)
    return _call_openai(_join_sys(system), user, temperature, max_tokens, mdl,
                        provider=prov, timeout=timeout, stream=_stream)


def complete_vision(system: str, user: str, images, temperature: float = None,
                    max_tokens: int = None, model: str = None) -> str:
    """Як complete(), але з зображеннями (скріншоти клієнта).
    images = [{"media_type": "image/jpeg", "data": bytes|base64-str}, ...].
    Маршрут за провайдером моделі (Anthropic або OpenAI-сумісний: openai/gemini).
    Якщо провайдер не підтримує зір (напр. local) — кидає LLMError, викликач деградує."""
    _budget_stop("complete_vision")
    import base64
    system = today_note() + (system or "")
    temperature = config.TEMPERATURE if temperature is None else temperature
    max_tokens = config.MAX_OUTPUT_TOKENS if max_tokens is None else max_tokens
    mdl = model or config.brain_model()
    prov = config.provider_for_model(mdl)

    def _b64(im):
        d = im.get("data")
        if isinstance(d, (bytes, bytearray)):
            return base64.b64encode(bytes(d)).decode("ascii")
        return d  # вже base64-рядок

    norm = [{"media_type": (im.get("media_type") or "image/jpeg"), "b64": _b64(im)}
            for im in (images or []) if im.get("data")]
    if not norm:
        return complete(system, user, temperature=temperature, max_tokens=max_tokens, model=mdl)

    if prov == "anthropic":
        if not config.ANTHROPIC_API_KEY:
            raise LLMNotConfigured("ANTHROPIC_API_KEY не заданий")
        content = [{"type": "image", "source": {"type": "base64",
                    "media_type": im["media_type"], "data": im["b64"]}} for im in norm]
        content.append({"type": "text", "text": user})
        payload = {"model": mdl, "system": _sys_field(system), "max_tokens": max_tokens,
                   "messages": [{"role": "user", "content": content}]}
        if mdl not in _NO_TEMPERATURE_MODELS:
            payload["temperature"] = temperature
        data = _http_post("https://api.anthropic.com/v1/messages",
                          {"Content-Type": "application/json", "x-api-key": config.ANTHROPIC_API_KEY,
                           "anthropic-version": "2023-06-01"}, payload)
        parts = data.get("content", [])
        return "".join(p.get("text", "") for p in parts if p.get("type") == "text")

    if prov in ("openai", "gemini", "moonshot"):
        base, key = config.openai_compat(prov)
        if not key:
            raise LLMNotConfigured(f"Немає ключа {prov}")
        content = [{"type": "text", "text": user}]
        for im in norm:
            content.append({"type": "image_url",
                            "image_url": {"url": f"data:{im['media_type']};base64,{im['b64']}"}})
        payload = {"model": mdl,
                   "messages": [{"role": "system", "content": system},
                                {"role": "user", "content": content}],
                   "max_tokens": max_tokens, "temperature": temperature}
        data = _http_post(f"{base}/chat/completions",
                          {"Content-Type": "application/json", "Authorization": f"Bearer {key}"}, payload)
        try:
            return data["choices"][0]["message"]["content"] or ""
        except (KeyError, IndexError):
            raise LLMError(f"Неочікувана відповідь {prov}: {json.dumps(data)[:300]}")

    raise LLMError(f"Провайдер «{prov}» не підтримує зображення в цій збірці. "
                   "Для аналізу скрінів увімкніть Claude або GPT як мозок.")


def complete_json(system: str, user: str, temperature: float = 0.1, model: str = None,
                  max_tokens: int = None) -> dict:
    """Просить модель повернути JSON і надійно його витягує."""
    text = complete(system, user, temperature=temperature, model=model, max_tokens=max_tokens)
    return extract_json(text)


def judge_json(system: str, user: str, temperature: float = 0.1, model: str = None,
               max_tokens: int = None, purpose: str = "") -> dict:
    """⭐⭐⭐ 01.08.2026. ОДИН ПИСАР НАДІЙНОГО СУДЖЕННЯ МОДЕЛІ.

    КЛАС проблеми (живий випадок 01.08.2026, клієнт Каспер). Кожне місце, де ми
    просимо модель ЩОСЬ ОЦІНИТИ у форматі JSON, винаходило власну поведінку на
    збій: одні тихо йшли далі, інші зачиняли двері перед реальним запитом
    клієнта. Спільного не було НІЧОГО — ані повтору, ані ескалації. При цьому
    ми ЗНАЛИ, що дешевий виконавець на великих промптах віддає порожнечу:
    транспортні повтори в `_http_post` таку відповідь не ловлять, бо мережа
    відпрацювала бездоганно — зіпсований лише ЗМІСТ.

    ТОЧКА РІШЕННЯ — тут, одна на весь продукт:
      1) спитати задану (зазвичай дешеву) модель;
      2) якщо зміст непридатний — ОДИН повтор тією ж моделлю (порожнеча
         випадкова частіше, ніж системна);
      3) якщо знову ні — ескалація на `config.reliable_model()`;
      4) лише після цього — `JudgeUnavailable`.

    Що НЕ повторюємо і не ескалюємо: межу вартості (у неї власний шлях, пауза з
    вибором для клієнта) і відсутню конфігурацію — повтор там лише палив би час
    і гроші. На відмову ключа (auth) другу спробу ТІЄЮ Ж моделлю пропускаємо:
    вона зайва, а от інший провайдер може мати робочий ключ.
    """
    import config as _cfg
    first = model or _cfg.worker_model()
    chain = [first, first]
    try:
        _rel = _cfg.reliable_model()
    except Exception:
        _rel = ""
    if _rel and _rel != first:
        chain.append(_rel)
    label = purpose or "судження"
    attempts = []
    i = 0
    while i < len(chain):
        mdl = chain[i]
        try:
            return complete_json(system, user, temperature=temperature, model=mdl,
                                 max_tokens=max_tokens)
        except LLMNotConfigured:
            raise
        except BudgetExceeded:
            raise
        except LLMError as e:
            attempts.append("%s -> %s" % (mdl, str(e)[:140]))
            _log("[judge] %s: спроба %d/%d на %s не вдалася (%s)"
                 % (label, i + 1, len(chain), mdl, str(e)[:160]))
            _hard = False
            try:
                import failure as _f
                if _f.is_budget(e):
                    raise
                _hard = _f.classify(e) == "auth"
            except LLMError:
                raise
            except Exception:
                _hard = False
            # Той самий ключ вдруге не оживе — стрибаємо на наступну ІНШУ модель.
            while _hard and i + 1 < len(chain) and chain[i + 1] == mdl:
                i += 1
            i += 1
    raise JudgeUnavailable(
        "судження моделі не отримано після %d спроб(и): %s" % (len(chain), "; ".join(attempts)),
        attempts=attempts)


def embed(texts) -> list:
    """Вектори для тексту(ів) через OpenAI-сумісний /embeddings (OpenAI або Gemini).
    Повертає список векторів (один на кожен вхідний рядок).

    ⭐ 29.07.2026: вартового тут не було — виклик платний, гроші рахувались, а
    межа їх не бачила. Знайдено не оком, а обчислюваними воротами."""
    _budget_stop("embed")
    base, key, model = config.embed_config()
    if not key:
        raise LLMNotConfigured("Немає ключа для ембедингів (потрібен OPENAI_API_KEY або GEMINI_API_KEY)")
    inp = texts if isinstance(texts, list) else [texts]
    data = _http_post(
        f"{base}/embeddings",
        {"Content-Type": "application/json", "Authorization": f"Bearer {key}"},
        {"model": model, "input": inp}, timeout=60,
    )
    try:
        return [d["embedding"] for d in data.get("data", [])]
    except Exception:
        raise LLMError(f"Неочікувана відповідь ембедингів: {json.dumps(data)[:300]}")


# ---------------------------------------------------------------------------
# Веб-пошук через нативний інструмент провайдера (окремий ключ не потрібен)
# ---------------------------------------------------------------------------
def search_complete(system: str, user: str, max_tokens: int = None) -> dict:
    """
    Виконує запит з УВІМКНЕНИМ веб-пошуком провайдера.
    Повертає {"text": str, "sources": [{"title","url"}], "used_search": bool}.
    Кидає LLMError/LLMNotConfigured при збої — викликач має деградувати мʼяко.
    """
    _budget_stop("search_complete")
    system = today_note() + (system or "")
    max_tokens = max_tokens or config.MAX_OUTPUT_TOKENS
    sp = config.search_provider()  # роль, чий провайдер уміє шукати (anthropic|openai|gemini)
    if not sp:
        raise LLMError("Веб-пошук недоступний: жодна роль не на провайдері з пошуком. "
                       "Додайте ключ Claude, OpenAI або Gemini.")
    if sp == "anthropic":
        return _search_anthropic(system, user, max_tokens)
    if sp == "gemini":
        return _search_gemini(system, user, max_tokens)
    return _search_openai(system, user, max_tokens)


def _dedupe_sources(sources):
    seen, out = set(), []
    for s in sources:
        url = (s or {}).get("url")
        if url and url not in seen:
            seen.add(url)
            out.append({"title": s.get("title") or url, "url": url})
    return out


def _stream_openai(url: str, headers: dict, payload: dict) -> dict:
    """OpenAI Responses (веб-пошук) через потік. Фінальний обʼєкт response беремо з події
    response.completed/response.incomplete — він має ту саму форму (output[...]), що й
    НЕпотоковий виклик, тож розбирач _search_openai не змінюється."""
    final = None
    for ev, obj in _stream_events(url, headers, payload):
        if obj is None:
            continue
        etype = obj.get("type") or ev
        if etype in ("response.failed", "response.error", "error"):
            err = (obj.get("response") or {}).get("error") or obj.get("error") or {}
            raise LLMError(f"openai потік-помилка: {err.get('message') or err}")
        if etype in ("response.completed", "response.incomplete"):
            final = obj.get("response") or final
            break
    if final is None:
        raise LLMError("openai: потік завершився без фінальної відповіді")
    u = final.get("usage") or {}
    _record_cost(final.get("model") or payload.get("model"),
                 {"input_tokens": u.get("input_tokens", 0), "output_tokens": u.get("output_tokens", 0)})
    return final


def _search_openai(system: str, user: str, max_tokens: int) -> dict:
    if not config.OPENAI_API_KEY:
        raise LLMNotConfigured("OPENAI_API_KEY не заданий")
    payload = {
        "model": config.search_model(),
        "tools": [{"type": config.OPENAI_WEB_SEARCH_TOOL}],
        "input": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        "max_output_tokens": max_tokens,
    }
    data = _stream_openai(
        "https://api.openai.com/v1/responses",
        {"Content-Type": "application/json", "Authorization": f"Bearer {config.OPENAI_API_KEY}"},
        payload,
    )
    # Захисний розбір відповіді Responses API (та сама форма, що й НЕпотоковий виклик)
    text_parts, sources, used = [], [], False
    if isinstance(data.get("output_text"), str):
        text_parts.append(data["output_text"])
    for item in data.get("output", []) or []:
        if item.get("type") == "web_search_call":
            used = True
        content = item.get("content")
        if isinstance(content, list):
            for c in content:
                if c.get("type") in ("output_text", "text") and c.get("text"):
                    text_parts.append(c["text"])
                for ann in c.get("annotations", []) or []:
                    if ann.get("type") in ("url_citation", "url") and ann.get("url"):
                        sources.append({"title": ann.get("title"), "url": ann.get("url")})
    text = "\n".join([t for t in text_parts if t]).strip()
    return {"text": text, "sources": _dedupe_sources(sources), "used_search": used or bool(sources)}


def _search_anthropic(system: str, user: str, max_tokens: int) -> dict:
    if not config.ANTHROPIC_API_KEY:
        raise LLMNotConfigured("ANTHROPIC_API_KEY не заданий")
    payload = {
        "model": config.search_model(),
        "max_tokens": max_tokens,
        "system": _sys_field(system),
        "messages": [{"role": "user", "content": user}],
        "tools": [{"type": config.ANTHROPIC_WEB_SEARCH_TOOL, "name": "web_search",
                   "max_uses": config.WEB_SEARCH_MAX_USES}],
    }
    data = _http_post_stream(
        "https://api.anthropic.com/v1/messages",
        {"Content-Type": "application/json", "x-api-key": config.ANTHROPIC_API_KEY,
         "anthropic-version": "2023-06-01"},
        payload, idle_timeout=config.WEB_SEARCH_TIMEOUT,
    )
    text_parts, sources, used = [], [], False
    for block in data.get("content", []) or []:
        btype = block.get("type")
        if btype == "text" and block.get("text"):
            text_parts.append(block["text"])
            for cit in block.get("citations", []) or []:
                if cit.get("url"):
                    sources.append({"title": cit.get("title"), "url": cit.get("url")})
        elif btype in ("web_search_tool_result", "server_tool_use"):
            used = True
            content = block.get("content")
            if isinstance(content, list):
                for r in content:
                    if r.get("url"):
                        sources.append({"title": r.get("title"), "url": r.get("url")})
    text = "\n".join([t for t in text_parts if t]).strip()
    return {"text": text, "sources": _dedupe_sources(sources), "used_search": used or bool(sources)}


def _stream_gemini(url: str, headers: dict, payload: dict) -> dict:
    """Gemini grounding (Google Search) через потік. Стрім вмикається ЕНДПОІНТОМ
    (:streamGenerateContent?alt=sse), не полем у тілі — тож stream_flag=False. Склеюємо
    текст і grounding з усіх шматків у форму generateContent (розбирач _search_gemini
    не змінюється)."""
    texts = []
    gmeta = {"webSearchQueries": [], "groundingChunks": []}
    usage = {"input_tokens": 0, "output_tokens": 0}
    for ev, obj in _stream_events(url, headers, payload, stream_flag=False):
        if obj is None:
            continue
        err = obj.get("error")
        if isinstance(err, dict):
            raise LLMError(f"gemini потік-помилка: {err.get('message') or err}")
        for cand in obj.get("candidates", []) or []:
            content = cand.get("content") or {}
            for part in content.get("parts", []) or []:
                if part.get("text"):
                    texts.append(part["text"])
            gm = cand.get("groundingMetadata") or {}
            for q in gm.get("webSearchQueries", []) or []:
                gmeta["webSearchQueries"].append(q)
            for ch in gm.get("groundingChunks", []) or []:
                gmeta["groundingChunks"].append(ch)
        um = obj.get("usageMetadata") or {}
        if um:
            usage["input_tokens"] = um.get("promptTokenCount", usage["input_tokens"])
            usage["output_tokens"] = um.get("candidatesTokenCount", usage["output_tokens"])
    _record_cost(payload.get("model"), usage)
    return {"candidates": [{"content": {"parts": [{"text": "".join(texts)}]},
                            "groundingMetadata": gmeta}]}


def _search_gemini(system: str, user: str, max_tokens: int) -> dict:
    """Веб-пошук через Gemini grounding (Google Search) — потоковий streamGenerateContent."""
    if not config.GEMINI_API_KEY:
        raise LLMNotConfigured("GEMINI_API_KEY не заданий")
    native = config.GEMINI_BASE.rstrip("/")
    if native.endswith("/openai"):
        native = native[: -len("/openai")]          # OpenAI-compat → нативний base
    model = config.search_model()
    url = f"{native}/models/{model}:streamGenerateContent?alt=sse"
    payload = {
        "contents": [{"role": "user", "parts": [{"text": user}]}],
        "systemInstruction": {"parts": [{"text": system}]},
        "tools": [{"google_search": {}}],
        "generationConfig": {"maxOutputTokens": max_tokens},
    }
    data = _stream_gemini(
        url,
        {"Content-Type": "application/json", "x-goog-api-key": config.GEMINI_API_KEY},
        payload,
    )
    text_parts, sources, used = [], [], False
    for cand in data.get("candidates", []) or []:
        content = cand.get("content") or {}
        for part in content.get("parts", []) or []:
            if part.get("text"):
                text_parts.append(part["text"])
        gm = cand.get("groundingMetadata") or {}
        if gm.get("webSearchQueries") or gm.get("groundingChunks"):
            used = True
        for ch in gm.get("groundingChunks", []) or []:
            web = ch.get("web") or {}
            if web.get("uri"):
                sources.append({"title": web.get("title"), "url": web.get("uri")})
    text = "\n".join([t for t in text_parts if t]).strip()
    return {"text": text, "sources": _dedupe_sources(sources), "used_search": used or bool(sources)}


def extract_json(text: str) -> dict:
    """Витягує перший збалансований JSON-обʼєкт з тексту (терпить ```json огортки)."""
    if not text:
        raise LLMError("Порожня відповідь моделі")
    s = text.strip()
    if s.startswith("```"):
        s = s.split("```", 2)[1] if s.count("```") >= 2 else s
        if s.startswith("json"):
            s = s[4:]
    # Знайти збалансований {...}
    start = s.find("{")
    if start == -1:
        raise LLMError(f"У відповіді немає JSON: {text[:300]}")
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(s)):
        ch = s[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    candidate = s[start : i + 1]
                    return json.loads(candidate)
    raise LLMError(f"Незбалансований JSON у відповіді: {text[:300]}")


# ═════════ МОДЕЛЬ, ЯКОЇ В ПРОВАЙДЕРА НЕМАЄ (10.08.2026, зміна 146) ═════════
# ⭐⭐⭐ КОРІНЬ, ЗНАЙДЕНИЙ У КОНСОЛІ КЛІЄНТА. Google перестав видавати
# `gemini-2.5-flash` НОВИМ ключам: HTTP 404, "no longer available to new users".
# У власника ключ старий і модель працює; у клієнта ключ новий — і платформа на
# КОЖНОМУ кроці билась у мертву модель, вивалювала людині сирий JSON провайдера
# і падала на дорогий мозок. Клієнт платив більше і читав стіну помилок.
#
# «НЕМАЄ ТАКОЇ МОДЕЛІ» — це ОСТАТОЧНО, а не «тимчасово». Такий щабель вибуває з
# драбини на весь прогін: один раз сказали людині, один раз записали — і більше
# не витрачаємо ні часу, ні грошей. Це та сама відмінність, що між «зайнято»
# і «номер більше не існує».
_GONE_MODELS = {}          # {модель: чому саме вона вибула}

# Ознаки саме ЗНИКЛОЇ моделі, а не будь-якого 404.
# Слово «model» у тексті вже обовʼязкове (див. is_model_gone_error), тому тут
# достатньо ознак самої НЕІСНУВАНОСТІ.
_GONE_MARKS = ("no longer available", "not found", "notfound", "does not exist",
               "unsupported model", "unknown model", "deprecated and is no longer",
               "is not supported")


def gone_models() -> dict:
    """Реєстр моделей, які провайдер оголосив неіснуючими (машинний слід)."""
    return _GONE_MODELS


def model_is_gone(model) -> bool:
    return str(model or "") in _GONE_MODELS


def mark_model_gone(model, why: str = "") -> None:
    m = str(model or "").strip()
    if not m:
        return
    if m not in _GONE_MODELS:
        _GONE_MODELS[m] = str(why or "провайдер не знає цієї моделі")[:300]
        _log("[llm] !! МОДЕЛЬ ВИБУЛА: %s — %s" % (m, _GONE_MODELS[m][:160]))


def is_model_gone_error(code, detail) -> bool:
    """Чи це саме «такої моделі немає», а не тимчасова біда.

    Судимо ЗМІСТ, а не лише код: 404 буває й на чужий шлях, і на друкарську
    помилку в адресі. Слово «model» у тексті обовʼязкове — інакше це не про модель.
    """
    try:
        code = int(code)
    except (TypeError, ValueError):
        return False
    if code != 404:
        return False
    d = str(detail or "").lower()
    if "model" not in d:
        return False
    return any(w in d for w in _GONE_MARKS)


def gone_message(model, provider: str = "") -> str:
    """Що бачить ЛЮДИНА. Сирий JSON провайдера сюди не потрапляє."""
    return ("Модель «%s» більше не видається цим ключем%s — постачальник її зняв. "
            "Перемикаюсь на наступну доступну модель і більше в цю не стукаю. "
            "Щоб повернути дешевий режим, виберіть свіжу модель у консолі "
            "(кнопка «⚙ змінити» вгорі ліворуч)."
            % (str(model or "").strip(), (" у " + provider) if provider else ""))
