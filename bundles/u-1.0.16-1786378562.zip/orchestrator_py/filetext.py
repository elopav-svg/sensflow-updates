"""
filetext.py — витяг тексту з прикріплених файлів (для подачі агентам як вхід).

Працює з сирими байтами (файли приходять у чат як base64). Опційні бібліотеки
(python-docx, openpyxl, pypdf) визначаються під час виконання — без них формати
docx/xlsx/pdf просто позначаються як недоступні, рушій не падає.
"""

import io
import csv
import re

# ⭐ 10.08.2026. СТЕЛЯ НА ФАЙЛ. Була 20 000 — і справжнє оголошення замовника
# (34 743 знаки, тендер UA-2026-08-05-000303-a) не вміщалось у неї ЦІЛКОМ.
# Стеля мусить вміщати типовий документ замовника, інакше вона ріже не «хвіст
# зайвого», а сам зміст. Загальний обсяг матеріалу тримає СПОЖИВАЧ (executor
# .fit_context для доданих файлів, tender_docs.read_docs_job для документації
# тендера) — саме там про нього знають.
MAX_CHARS = 40000


def _cap(text: str) -> str:
    if text and len(text) > MAX_CHARS:
        return text[:MAX_CHARS] + f"\n\n…[обрізано, показано перші {MAX_CHARS} символів]"
    return text or ""


def _ext(name: str) -> str:
    return ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""


def _decode(raw: bytes) -> str:
    for enc in ("utf-8-sig", "utf-8", "cp1251", "latin-1"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", errors="replace")


def _docx_blocks(parent):
    """Абзаци й таблиці В ПОРЯДКУ ДОКУМЕНТА, з будь-якої глибини вкладеності.

    python-docx дає `d.paragraphs` і `d.tables` ДВОМА окремими плоскими списками
    верхнього рівня. Через це текст у таблиці всередині таблиці не існував ані в
    першому, ані в другому. Обхід іде по САМОМУ дереву документа, тому порядок
    зберігається, а вкладеність не має значення.
    """
    from docx.document import Document as _Doc
    from docx.oxml.ns import qn
    from docx.table import Table, _Cell
    from docx.text.paragraph import Paragraph

    if isinstance(parent, _Doc):
        el = parent.element.body
    elif isinstance(parent, _Cell):
        el = parent._tc
    else:
        return
    for child in el.iterchildren():
        if child.tag == qn("w:p"):
            yield Paragraph(child, parent)
        elif child.tag == qn("w:tbl"):
            yield Table(child, parent)


def _docx_render(parent, depth=0):
    """Текст гілки дерева. Рядок таблиці лишається одним рядком (`a | b | c`),
    щоб нумеровані переліки в клітинці не злиплись — на них спирається розбір
    вимог тендера."""
    from docx.table import Table
    out = []
    if depth > 12:            # запобіжник від хворого документа, не межа змісту
        return out
    for block in _docx_blocks(parent):
        if isinstance(block, Table):
            for row in block.rows:
                cells, seen = [], set()
                try:
                    row_cells = row.cells
                except Exception:
                    continue
                for cell in row_cells:
                    key = id(cell._tc)
                    if key in seen:      # обʼєднана клітинка: той самий вміст
                        continue
                    seen.add(key)
                    cells.append("\n".join(_docx_render(cell, depth + 1)).strip())
                if any(cells):
                    out.append(" | ".join(cells))
        else:
            t = (block.text or "").strip()
            if t:
                out.append(t)
    return out


def _docx_xml_paragraphs(raw: bytes):
    """ПРАВДА ПРО ДОКУМЕНТ, здобута НЕ обходом дерева: усі абзаци word/document.xml.

    Незалежна опора. Ворота, які звіряють результат із власним недоліком, — не
    ворота: якщо обхід дерева чогось не побачив (напис у текстовому полі, поле
    форми, вміст `w:sdt`), помітити це можна лише зовнішнім джерелом.
    """
    import zipfile
    try:
        with zipfile.ZipFile(io.BytesIO(raw)) as z:
            xml = z.read("word/document.xml").decode("utf-8", "replace")
    except Exception:
        return []
    out = []
    for m in re.finditer(r"<w:p[ >].*?</w:p>", xml, re.S):
        t = "".join(re.findall(r"<w:t[^>]*>([^<]*)</w:t>", m.group(0))).strip()
        if t:
            out.append(t)
    return out


def _from_docx(raw: bytes) -> str:
    """⭐⭐⭐ 10.08.2026. ВИТЯГ, ЯКИЙ НЕ ГУБИТЬ ТЕКСТ МОВЧКИ.

    Що було. Читались абзаци верхнього рівня плюс таблиці верхнього рівня, а
    `cell.text` віддає лише абзаци, що лежать у клітинці НАПРЯМУ. Справжнє
    оголошення замовника — одна велика таблиця, а всередині неї ВКЛАДЕНА ще
    одна: із 34 743 знаків до систем доїжджало 6 395, тобто 81 відсоток зникав,
    і платформа про це НЕ КАЗАЛА НІЧОГО. Тихе обрізання гірше за відмову: людина
    отримує впевнений висновок, зроблений із пʼятої частини документа.

    Що тепер. Два незалежні шари:
      1. ОБХІД ДЕРЕВА — абзаци й таблиці будь-якої вкладеності, у порядку
         документа (`_docx_render`).
      2. ЗАПОБІЖНИК — звірка з word/document.xml (`_docx_xml_paragraphs`). Усе,
         чого обхід не побачив, доїжджає окремим ПОЗНАЧЕНИМ блоком. Тому навіть
         невідомий сьогодні різновид .docx не зможе загубити текст непомітно.
    """
    try:
        import docx
    except Exception:
        return "[docx не розпізнано: встановіть python-docx]"
    try:
        d = docx.Document(io.BytesIO(raw))
        parts = _docx_render(d)
    except Exception as e:
        return f"[помилка читання docx: {e}]"

    text = "\n".join(parts)
    seen_lines = {ln.strip() for ln in text.split("\n")}
    extra = []
    for para in _docx_xml_paragraphs(raw):
        if para in seen_lines or para in text:
            continue
        extra.append(para)
    if extra:
        text += ("\n\n[ДОДАТКОВО ЗНАЙДЕНО В ДОКУМЕНТІ %d рядків тексту поза основною "
                 "структурою (напис, поле, вкладення). Наведено як є, порядок може "
                 "відрізнятись:]\n" % len(extra)) + "\n".join(extra)
    return text


def _from_xlsx(raw: bytes) -> str:
    try:
        import openpyxl
    except Exception:
        return "[xlsx не розпізнано: встановіть openpyxl]"
    try:
        wb = openpyxl.load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        out = []
        for ws in wb.worksheets:
            out.append(f"# Аркуш: {ws.title}")
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i > 500:
                    out.append("…[обрізано рядки]")
                    break
                vals = ["" if c is None else str(c) for c in row]
                if any(v.strip() for v in vals):
                    out.append(" | ".join(vals))
        return "\n".join(out)
    except Exception as e:
        return f"[помилка читання xlsx: {e}]"


def _from_pdf(raw: bytes) -> str:
    try:
        import pypdf
    except Exception:
        try:
            import PyPDF2 as pypdf  # запасний варіант
        except Exception:
            return "[pdf не розпізнано: встановіть pypdf]"
    try:
        reader = pypdf.PdfReader(io.BytesIO(raw))
        pages = []
        for i, page in enumerate(reader.pages):
            if i > 80:
                pages.append("…[обрізано сторінки]")
                break
            try:
                pages.append(page.extract_text() or "")
            except Exception:
                pages.append("")
        text = "\n".join(pages).strip()
        return text or "[pdf без текстового шару — можливо, скан без OCR]"
    except Exception as e:
        return f"[помилка читання pdf: {e}]"


def _from_csv(raw: bytes) -> str:
    text = _decode(raw)
    try:
        rows = list(csv.reader(io.StringIO(text)))
        return "\n".join(" | ".join(r) for r in rows[:600])
    except Exception:
        return text


def extract_text(name: str, raw: bytes) -> str:
    ext = _ext(name)
    if ext == ".docx":
        return _cap(_from_docx(raw))
    if ext in (".xlsx", ".xlsm"):
        return _cap(_from_xlsx(raw))
    if ext == ".pdf":
        return _cap(_from_pdf(raw))
    if ext in (".csv", ".tsv"):
        return _cap(_from_csv(raw))
    if ext in (".txt", ".md", ".json", ".log", ".yaml", ".yml", ".html", ".xml"):
        return _cap(_decode(raw))
    # невідомий тип: спроба як текст
    text = _decode(raw)
    printable = sum(1 for ch in text[:500] if ch.isprintable() or ch in "\n\r\t")
    if text and printable / max(1, min(len(text), 500)) > 0.85:
        return _cap(text)
    return f"[формат {ext or '?'} не підтримується для витягу тексту]"


def build_files_context(files: list) -> tuple:
    """
    files: [{'name': str, 'b64': 'data:...;base64,XXXX' або чистий base64}]
    Повертає (files_context_text, [meta]) де meta = {'name','chars'}.
    """
    import base64
    blocks = []
    meta = []
    for f in files or []:
        name = (f.get("name") or "file").strip()
        b64 = f.get("b64") or ""
        if "," in b64 and b64.strip().startswith("data:"):
            b64 = b64.split(",", 1)[1]
        try:
            raw = base64.b64decode(b64)
        except Exception:
            blocks.append(f"## Файл: {name}\n[не вдалося декодувати вміст]")
            meta.append({"name": name, "chars": 0})
            continue
        text = extract_text(name, raw)
        blocks.append(f"## Файл: {name}\n{text}")
        meta.append({"name": name, "chars": len(text)})
    return ("\n\n".join(blocks), meta)
