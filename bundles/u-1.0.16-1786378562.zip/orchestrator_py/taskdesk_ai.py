# -*- coding: utf-8 -*-
"""
taskdesk_ai.py — ЄДИНИЙ МІСТ МІЖ TASK DESK І МОЗКОМ (рішення 21).

Навіщо він окремим файлом. Ядро задач (`taskdesk_tasks.py`) НЕ ІМПОРТУЄ мозок —
це судить чек деревом коду. Стадії, права, терміни й закриття — логіка, і вона
має бути передбачуваною до останнього кроку. Мозок потрібен рівно там, де треба
ЗРОЗУМІТИ ЛЮДСЬКИЙ ТЕКСТ, — і більше ніде.

⭐⭐⭐ ТРИ ЗАКОНИ ЦЬОГО ФАЙЛА

1. **МОЗОК ПРОПОНУЄ, ЛЮДИНА ВИРІШУЄ.** Він не пише термін і взагалі нічого не
   змінює в задачі. Він повертає ПРОПОЗИЦІЮ; записує її `taskdesk_tasks`, а
   застосовує — та сама `update()` під тими самими правами, і в журналі стоїть
   ЛЮДИНА. Інакше термін мав би двох писарів — машину й людину, — і за тиждень
   ніхто не сказав би, звідки взялась дата.

2. **КОД ВИРІШУЄ, ЧИ ВЗАГАЛІ ПИТАТИ МОЗОК.** Спершу безкоштовна перевірка
   `might_hold_a_date()`: якщо в коментарі немає нічого схожого на дату, гроші
   Андрія не витрачаються взагалі. Мозок платний — питати його «про всяк
   випадок» на кожен коментар не можна.

3. **МОЗОК НЕ ПРИДУМУЄ ДАТ.** Усе, що він повернув, проходить перевірку кодом:
   дата має бути справжньою, у майбутньому й ВЗЯТОЮ З ТЕКСТУ (цитата мусить у
   ньому знайтись). Не пройшло — пропозиції немає. Здогад, який видають за
   факт, гірший за мовчання.

4. **МОЗОК НЕ ТРИМАЄ ЛЮДИНУ ЗА РУКУ.** Коментар зберігається МИТТЄВО, ще до
   будь-якого виклику. Мозок отримує ПОВІДЕЦЬ у секундах: не встиг — екран так і
   каже, а коментар уже на місці. Живий прогін 08.08.2026 показав 6 секунд
   очікування на непрацюючій мережі; шість секунд на кожен коментар — це
   зламаний екран, а не «трохи повільно».

⚠ Вимикач: `SENSFLOW_TASKDESK_AI=off` — і жодного платного виклику.
⚠ Повідець: `SENSFLOW_TASKDESK_AI_WAIT` секунд (типово 8).
"""

import re

import clock
import config

SWITCH = "SENSFLOW_TASKDESK_AI"
WAIT_KEY = "SENSFLOW_TASKDESK_AI_WAIT"
WAIT_DEFAULT = 8.0

MONTHS = {
    "січ": 1, "лют": 2, "бере": 3, "квіт": 4, "трав": 5, "черв": 6,
    "лип": 7, "серп": 8, "верес": 9, "жовт": 10, "листоп": 11, "груд": 12,
}

# Дешевий сторож: щось схоже на дату в тексті. Жодних грошей.
DATE_HINTS = (
    re.compile(r"\b\d{1,2}[.\-/]\d{1,2}(?:[.\-/]\d{2,4})?\b"),      # 11.08 / 11.08.2026
    re.compile(r"\b\d{4}-\d{2}-\d{2}\b"),                            # 2026-08-11
    re.compile(r"\b\d{1,2}\s+(?:%s)\w*" % "|".join(MONTHS), re.I),   # 11 серпня
)


def enabled() -> bool:
    """ЄДИНА відповідь «чи мозок Task Desk увімкнений»."""
    return str(config.ENV.get(SWITCH, "on")).strip().lower() not in ("off", "0", "no")


def might_hold_a_date(text: str) -> bool:
    """БЕЗКОШТОВНИЙ сторож перед платним викликом."""
    t = str(text or "")
    return any(rx.search(t) for rx in DATE_HINTS)


SYSTEM = (
    "Ти читаєш ОДИН коментар до робочої задачі й відповідаєш, чи людина назвала "
    "нову дату, до якої задачу неможливо зробити раніше (наприклад, чекають "
    "чужої відповіді або документа).\n"
    "Поверни СТРОГО JSON без пояснень:\n"
    '{"is_new_date": true|false, "date": "YYYY-MM-DD", '
    '"quote": "<точний уривок коментаря, де названа дата>", '
    '"why": "<одне коротке речення українською, чому саме ця дата>"}\n'
    "Правила:\n"
    "- is_new_date=false, якщо дата в тексті стосується минулого, іншої задачі, "
    "зустрічі без звʼязку з терміном або якщо дати немає взагалі;\n"
    "- date бери ЛИШЕ з тексту, не вигадуй і не рахуй сам;\n"
    "- quote мусить бути ДОСЛІВНИМ уривком коментаря;\n"
    "- рік, якщо не названий, бери поточний."
)


def _to_iso(value, today: str) -> str:
    """Приводимо відповідь мозку до нашого вигляду. Що не сходиться — відкидаємо."""
    v = str(value or "").strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", v)
    if m:
        y, mo, d = m.groups()
    else:
        m = re.match(r"^(\d{1,2})[.\-/](\d{1,2})(?:[.\-/](\d{2,4}))?$", v)
        if not m:
            return ""
        d, mo, y = m.group(1), m.group(2), m.group(3) or today[:4]
        if len(y) == 2:
            y = "20" + y
    try:
        from datetime import date
        date(int(y), int(mo), int(d))
    except Exception:
        return ""
    return "%04d-%02d-%02d" % (int(y), int(mo), int(d))


def read_comment(title: str, text: str, today: str = "", ask=None) -> dict:
    """Прочитати коментар і, якщо там названа нова дата, повернути пропозицію.

    Повертає {} — коли пропозиції немає (це НЕ помилка).
    Кидає RuntimeError — коли мозок не відповів; тоді екран скаже про це вголос,
    а не змовчить."""
    today = today or clock.now()[:10]
    if not enabled() or not might_hold_a_date(text):
        return {}
    if ask is None:
        import llm
        # ⭐⭐⭐ 08.08.2026. ЖОДНЕ СУДЖЕННЯ НЕ ЙДЕ ПОВЗ ОДНОГО СУДДЮ.
        # Тут стояв ПРЯМИЙ `llm.complete_json` — і цей платний виклик не рахувався
        # в денну стелю вартості, не мав запасної спроби на мовчазну модель і не
        # лишав сліду в журналі суджень. Другий облік замість одного.
        ask = lambda sys_p, usr: llm.judge_json(
            sys_p, usr, temperature=0, model=config.worker_model(), max_tokens=300,
            purpose="taskdesk: новий термін з коментаря")
    user = ("Сьогодні %s.\nЗадача: %s\nКоментар: %s" % (today, title, text))
    try:
        out = ask(SYSTEM, user) or {}
    except Exception as e:
        raise RuntimeError("мозок не відповів: %s" % e)
    if not isinstance(out, dict) or not out.get("is_new_date"):
        return {}

    date = _to_iso(out.get("date"), today)
    if not date:
        return {}
    # ⭐ Дата з минулого нового терміну не робить.
    if date <= today:
        return {}
    # ⭐ Цитата мусить знайтись у самому коментарі — інакше це вигадка.
    quote = str(out.get("quote") or "").strip()
    if not quote or _squash(quote) not in _squash(text):
        return {}
    return {"kind": "due", "date": date, "quote": quote[:300],
            "why": str(out.get("why") or "").strip()[:300]}


def leash_seconds() -> float:
    """Скільки секунд людина чекає на мозок, перш ніж екран відповість без нього."""
    try:
        v = float(str(config.ENV.get(WAIT_KEY, "")).strip() or WAIT_DEFAULT)
    except Exception:
        v = WAIT_DEFAULT
    return max(1.0, min(60.0, v))


def read_comment_soon(title: str, text: str, today: str = "", ask=None,
                      wait: float = None):
    """`read_comment` на повідці. Повертає (пропозиція, примітка).

    Не встиг — повертаємо примітку словами, а не мовчимо й не тримаємо екран.
    Результат запізнілої відповіді ВИКИДАЄМО: писати в задачу з фонового потоку
    означало б другого писаря того самого файла."""
    import threading
    if not enabled() or not might_hold_a_date(text):
        return {}, ""
    box = {}

    def work():
        try:
            box["out"] = read_comment(title, text, today, ask)
        except Exception as e:
            box["err"] = str(e)

    th = threading.Thread(target=work, daemon=True)
    th.start()
    th.join(leash_seconds() if wait is None else wait)
    if th.is_alive():
        return {}, ("ШІ не встиг відповісти за %g с — коментар збережено, "
                    "пропозиції немає." % (leash_seconds() if wait is None else wait))
    if "err" in box:
        return {}, box["err"]
    return box.get("out") or {}, ""


def _squash(s: str) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()
