"""
license.py — легкий механізм ліцензування (офлайн-перевірка підписаного ключа).
Підтримує пер-клієнт секрет підпису (параметр secret у generate/parse).

ФІЛОСОФІЯ (за планом): головний захист від тиражування — ЛІЦЕНЗІЙНА УГОДА,
а не DRM. Цей механізм — «анти-казуальний»: підтверджує видання, термін дії та
клієнта, ловить просте редагування ключа (HMAC-підпис), працює офлайн і лише на
stdlib. Це НЕ криптографічно стійкий захист (секрет підпису присутній і в
клієнтській збірці для перевірки) — і не претендує на нього.

Формат ключа:  SF-<base64(payload)>.<hmac24>
payload = {"c": клієнт, "e": видання, "x": термін YYYY-MM-DD}

Видача ключа (для підтримки):
    python license.py generate "Назва клієнта" pilot 365
"""

import base64
import json
import hmac
import hashlib
import sys
from datetime import date, timedelta

import config

# Секрет підпису. Тримається у нас для генерації; у клієнті присутній для
# перевірки HMAC (звідси «легкість» захисту). Можна перевизначити в .env.local.
_SECRET = (config.ENV.get("LICENSE_SIGNING_SECRET")
           or "SensFlow-license-signing-2026-change-me").encode("utf-8")
_PREFIX = "SF-"


def _b64e(obj) -> str:
    raw = json.dumps(obj, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


def _b64d(s: str):
    pad = "=" * (-len(s) % 4)
    return json.loads(base64.urlsafe_b64decode((s + pad).encode("ascii")).decode("utf-8"))


def _as_bytes(secret) -> bytes:
    """Нормалізує секрет до bytes. None -> майстер-секрет збірки (_SECRET)."""
    if secret is None:
        return _SECRET
    return secret.encode("utf-8") if isinstance(secret, str) else secret


def _sign(payload_b64: str, secret=None) -> str:
    return hmac.new(_as_bytes(secret), payload_b64.encode("ascii"), hashlib.sha256).hexdigest()[:24]


# ── ⭐⭐⭐ 07.08.2026. МОДЕЛЬ ОПЛАТИ — ЧАСТИНА ПОСВІДЧЕННЯ, А НЕ ДОМОВЛЕНОСТІ ──
# Бізнес-модель (07.08.2026) назвала дві моделі, і вони РІЗНО ЗАКІНЧУЮТЬСЯ:
#   A — стартовий платіж + абонплата: строк минув -> ПРАЦЮЄ ДАЛІ на тій версії,
#       що є; гаснуть лише оновлення й підтримка. Оновлення гаснуть самі —
#       ми просто перестаємо додавати записи в маніфест клієнта, коду не треба.
#   B — тільки абонплата: строк минув -> користування ПРИПИНЯЄТЬСЯ.
# ⭐ КЛЮЧ БЕЗ ЦЬОГО ПОЛЯ = СЬОГОДНІШНЯ ПОВЕДІНКА (зупинка). Це навмисно:
# технічна правка не сміє тихо змінити умови ЖИВОМУ клієнтові. Модель A
# вмикається лише явно виписаним новим ключем.
MODEL_PERPETUAL = "A"     # стартовий платіж + абонплата
MODEL_RENT = "B"          # тільки абонплата


def generate(customer: str, edition: str = "pilot", days: int = 365, role: str = "admin",
             support_hours: int = 0, secret=None, model: str = "") -> str:
    """Створює ліцензійний ключ. Інструмент для ПІДТРИМКИ, не для клієнта.
    role: 'admin' (повні права) або 'operator' (обмежені права — лише запуск задач).
    support_hours: місячна квота годин техпідтримки (0 = не задано/без обліку).
    model: 'A' — право користування безстрокове (гаснуть оновлення й підтримка);
           'B' або порожньо — після строку користування припиняється.
    secret: per-client секрет підпису (None = майстер-секрет збірки). Для пер-клієнт
    моделі ключ підписується ТИМ САМИМ секретом, що вшито в збірку клієнта."""
    role = (role or "admin").strip().lower()
    if role not in ("admin", "operator"):
        role = "admin"
    try:
        sh = max(0, int(support_hours or 0))
    except Exception:
        sh = 0
    mdl = (model or "").strip().upper()
    if mdl not in (MODEL_PERPETUAL, MODEL_RENT):
        mdl = ""
    payload = {"c": (customer or "").strip(), "e": (edition or "pilot").strip(),
               "x": (date.today() + timedelta(days=int(days))).isoformat(),
               "r": role, "sh": sh, "m": mdl}
    b64 = _b64e(payload)
    return f"{_PREFIX}{b64}.{_sign(b64, secret)}"


def parse(key: str, secret=None) -> dict:
    """Розбирає й перевіряє ключ. Повертає {valid, customer, edition, expiry, expired, reason}."""
    out = {"valid": False, "customer": "", "edition": "", "expiry": "",
           "expired": False, "reason": "", "role": "admin", "support_hours": 0,
           "model": ""}
    key = (key or "").strip()
    if not key:
        out["reason"] = "ключ не задано"
        return out
    if not key.startswith(_PREFIX) or "." not in key:
        out["reason"] = "невірний формат ключа"
        return out
    body = key[len(_PREFIX):]
    b64, sig = body.rsplit(".", 1)
    if not hmac.compare_digest(sig, _sign(b64, secret)):
        out["reason"] = "підпис не збігається (ключ змінено або недійсний)"
        return out
    try:
        payload = _b64d(b64)
    except Exception:
        out["reason"] = "пошкоджений ключ"
        return out
    out["customer"] = str(payload.get("c", ""))
    out["edition"] = str(payload.get("e", ""))
    out["expiry"] = str(payload.get("x", ""))
    out["role"] = (str(payload.get("r", "admin")).strip().lower() or "admin")
    _m = str(payload.get("m", "") or "").strip().upper()
    out["model"] = _m if _m in (MODEL_PERPETUAL, MODEL_RENT) else ""
    try:
        out["support_hours"] = max(0, int(payload.get("sh", 0) or 0))
    except Exception:
        out["support_hours"] = 0
    try:
        expired = date.fromisoformat(out["expiry"]) < date.today()
    except Exception:
        out["reason"] = "невірна дата у ключі"
        return out
    out["expired"] = expired
    if expired:
        out["reason"] = f"підписка завершилась {out['expiry']}"
        return out
    out["valid"] = True
    out["reason"] = "активна"
    return out


def status() -> dict:
    """Стан поточної ліцензії з config.LICENSE_KEY (для UI/гейтів)."""
    return parse(config.LICENSE_KEY)


def is_valid() -> bool:
    return status().get("valid", False)


# ── Право на роботу: активна ліцензія АБО незавершений пробний період ────────
TRIAL_DAYS = 30
_TRIAL_PATH = config.RUNS_DIR / "_trial.json"


def _trial_start() -> str:
    """Дата початку тріалу (підписана). Створюється при першому виклику."""
    try:
        d = __import__("json").loads(_TRIAL_PATH.read_text(encoding="utf-8"))
        ts, sig = d.get("start"), d.get("sig")
        if ts and hmac.compare_digest(sig or "", _sign("T" + ts)):
            return ts
    except Exception:
        pass
    ts = date.today().isoformat()
    try:
        _TRIAL_PATH.parent.mkdir(parents=True, exist_ok=True)
        _TRIAL_PATH.write_text(__import__("json").dumps({"start": ts, "sig": _sign("T" + ts)}),
                               encoding="utf-8")
    except Exception:
        pass
    return ts


def trial_days_left() -> int:
    try:
        used = (date.today() - date.fromisoformat(_trial_start())).days
        return max(0, TRIAL_DAYS - used)
    except Exception:
        return 0


def entitlement() -> dict:
    """Право на роботу: {active, mode, message, ...}. Ліцензія > тріал."""
    lic = status()
    if lic.get("valid"):
        return {"active": True, "mode": "license", "customer": lic.get("customer", ""),
                "edition": lic.get("edition", ""), "until": lic.get("expiry", ""),
                "role": lic.get("role", "admin"),
                "support_hours": lic.get("support_hours", 0),
                "model": lic.get("model", ""),
                "message": f"Ліцензія активна до {lic.get('expiry', '')}."}
    if config.LICENSE_KEY and lic.get("expired"):
        _m = lic.get("model", "")
        if _m == MODEL_PERPETUAL:
            # Модель A: платформа працює далі; гаснуть лише оновлення й підтримка.
            return {"active": False, "mode": "expired", "model": _m,
                    "message": (lic.get("reason", "Підписку завершено.")
                                + " Платформа працює далі на поточній версії; "
                                  "оновлення й підтримка призупинені.")}
        return {"active": False, "mode": "expired", "model": _m,
                "message": lic.get("reason", "Підписку завершено.") + " Поновіть підписку."}
    left = trial_days_left()
    if left > 0:
        return {"active": True, "mode": "trial", "days_left": left,
                "message": f"Пробний період: лишилось {left} дн."}
    return {"active": False, "mode": "trial_expired",
            "message": "Пробний період завершився. Активуйте підписку, щоб продовжити роботу."}


def is_entitled() -> bool:
    return entitlement().get("active", False)


# ── ⭐⭐⭐ 07.08.2026. ОДИН АВТОР ВІДПОВІДІ «ЧИ МОЖНА ЗАРАЗ ПРАЦЮВАТИ» ─────────
# Це НЕ те саме, що «чи активна підписка», і саме тому потрібна окрема функція:
# у моделі A підписка вже НЕ активна, а працювати можна далі — безстроково.
# Питати цю функцію може скільки завгодно входів (мозок, єдина точка запуску,
# розклад, телеграм) — але ВІДПОВІДЬ одна, і живе вона тут.
# ⚠ Ключ без поля моделі -> зупинка, тобто сьогоднішня поведінка. Технічна
# правка не сміє тихо змінити умови живому клієнтові.
def work_allowed() -> tuple:
    """Чи має право платформа зараз виконувати роботу.

    Повертає (можна, причина словами). Причина потрібна завжди: тиха відмова —
    це вимкнені ворота, яких ніхто не помітить.
    ⚠ Виду зупинки тут НЕМАЄ навмисно: як назвати зупинку — поняття виконавця,
    і воно живе в його реєстрі. Ліцензія відповідає лише на «чи можна».
    Інакше ім'я зупинки мало б двох писарів у різних шарах."""
    ent = entitlement()
    if ent.get("active"):
        return True, ""
    if ent.get("mode") == "expired" and status().get("model") == MODEL_PERPETUAL:
        # Модель A: строк абонплати минув, право користування лишається.
        return True, ""
    return False, (ent.get("message") or "Потрібна активна підписка.")


def role() -> str:
    """Роль поточного посвідчення. 'operator' — ЛИШЕ при активній ліцензії-оператора.
    Інакше (адмін-ліцензія / тріал / без ліцензії) — 'admin' (повні права, як зараз)."""
    ent = entitlement()
    if ent.get("active") and ent.get("mode") == "license" and ent.get("role") == "operator":
        return "operator"
    return "admin"


def is_admin() -> bool:
    """Чи має поточний сеанс адмінські права (повний доступ до налаштувань/керування)."""
    return role() != "operator"


if __name__ == "__main__":
    # Інструмент підтримки: python license.py generate "Клієнт" [видання] [днів]
    if len(sys.argv) >= 3 and sys.argv[1] == "generate":
        cust = sys.argv[2]
        ed = sys.argv[3] if len(sys.argv) > 3 else "pilot"
        dn = sys.argv[4] if len(sys.argv) > 4 else "365"
        rl = sys.argv[5] if len(sys.argv) > 5 else "admin"
        sh = sys.argv[6] if len(sys.argv) > 6 else "0"
        k = generate(cust, ed, int(dn), rl, int(sh))
        print(k)
        print("→ перевірка:", parse(k))
    else:
        print('Використання: python license.py generate "Назва клієнта" [pilot|standard|enterprise] [днів] [admin|operator] [години_підтримки/міс]')
