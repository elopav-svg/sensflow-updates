# -*- coding: utf-8 -*-
"""
taskdesk_people.py — ОРГСТРУКТУРА TASK DESK: підрозділи, посади, працівники.

Крок 1.1 етапу 1 (проєкт: «Аудити та стратегії\TaskDesk_етап1_детальний_проєкт_06.08.2026.md»).
Це фундамент, якого в платформі не було взагалі: сьогодні вона одноосібна й
поняття «працівник», «підрозділ», «хто чий керівник» не існує ніде.

ТРИ ЗАКОНИ, ЗА ЯКИМИ ЦЕЙ ФАЙЛ ЗБУДОВАНО (уклад узятий із `scheduler.py`,
де він уже доведений):
  1. ОДИН НОРМАЛІЗАТОР — `_normalize()`. Будь-який запис, хоч побитий, виходить
     звідси з повним набором полів. Зламаність — це ОЗНАКА (`broken` +
     `broken_reason`), а не окреме життя й не тиша.
  2. ОДИН ЧИТАЧ — `load()`. І людина, і будь-який інший код беруть правду звідси.
     `read_text` цього файла стану є РІВНО В ОДНОМУ місці модуля.
  3. ОДИН ПИСАР — `save()`. Кожна зміна лишає слід в `audit[]`, тому журнал
     оргструктури дописується в одному місці, а не в десяти.

⭐⭐⭐ ГОЛОВНЕ АРХІТЕКТУРНЕ РІШЕННЯ: «ХТО ЧИЙ КЕРІВНИК» НЕ ЗБЕРІГАЄТЬСЯ.
Воно ОБЧИСЛЮЄТЬСЯ з дерева підрозділів при читанні (`manager_of`). Якби керівник
лежав полем у працівника, ми б отримали двох писарів однієї правди: перемістили
підрозділ — і половина карток тихо бреше. Похідні поля не лягають на диск ніколи
(`DERIVED_*`), рівно як у планувальнику.

⚠ ПРАЦІВНИКА НЕ ВИДАЛЯЮТЬ. Звільнений стає неактивним: нових задач не отримує,
але лишається у всіх старих записах. Видалення осиротило б історію задач, а
історія — це те, заради чого Task Desk узагалі будується. Тому функції видалення
працівника в цьому модулі НЕМАЄ (це перевіряє чек деревом коду).
"""

import json
import re
import uuid
from pathlib import Path

import clock          # ОДИН ПИСАР ЧАСУ на весь продукт
import config

# Тека стану Task Desk. У клієнта вона своя; чеки відводять її вбік через
# config.STATE_DIR, тому бойова тека від прогонів не смітиться.
DESK_DIR = config.STATE_DIR / "taskdesk"
PEOPLE_JSON = DESK_DIR / "people.json"

AUDIT_KEEP = 200

# Похідні поля: ОБЧИСЛЮЮТЬСЯ при читанні й НІКОЛИ не лежать на диску.
DERIVED_UNIT = ("broken", "broken_reason", "depth", "path", "head_name")
DERIVED_EMP = ("broken", "broken_reason", "manager_id", "manager_name", "unit_name",
               "position_name", "can_receive_tasks", "direct_report_ids", "photo_url")

# Фото працівників лежать поруч зі станом; у картці зберігається лише імʼя файла.
PHOTOS_DIR = DESK_DIR / "photos"

# ⭐ Фото приймається за ВМІСТОМ, а не за назвою: «фото.png», усередині якого
# лежить не картинка, — найдешевший спосіб покласти в теку клієнта що завгодно.
PHOTO_KINDS = (
    (b"\x89PNG\r\n\x1a\n", "png", "image/png"),
    (b"\xff\xd8\xff", "jpg", "image/jpeg"),
    (b"RIFF", "webp", "image/webp"),
)
MAX_PHOTO_BYTES = 2 * 1024 * 1024


class PeopleError(Exception):
    """Відмова писаря, названа людськими словами. Тиші тут не буває."""


# ---------------------------------------------------------------------------
# ОДИН НОРМАЛІЗАТОР
# ---------------------------------------------------------------------------
def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _check_card_fields(fields: dict):
    """Перевірка полів картки. Кожна відмова називає причину словами —
    мовчазне «зрізали й записали» заборонене."""
    b = _s(fields.get("birthday"))
    if b and not re.match(r"^\d{4}-\d{2}-\d{2}$", b):
        raise PeopleError("день народження пишеться як 1980-05-17 (рік-місяць-день); "
                          "у картці людині він показується як 17.05.1980")
    for key, human in (("phone_mobile", "мобільний"), ("phone_work", "робочий")):
        v = _s(fields.get(key))
        if v and len(re.sub(r"\D", "", v)) < 7:
            raise PeopleError("%s телефон «%s» не схожий на номер" % (human, v))
    e = _s(fields.get("email"))
    if e and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", e):
        raise PeopleError("пошта «%s» не схожа на адресу" % e)
    ph = _s(fields.get("photo"))
    if ph and ("/" in ph or "\\" in ph or ".." in ph):
        raise PeopleError("у картці зберігається лише імʼя файла фото, не шлях")


def _new_id(prefix: str) -> str:
    return "%s-%s" % (prefix, uuid.uuid4().hex[:8])


def _unit_chain(units_by_id: dict, unit_id: str) -> list:
    """Ланцюг підрозділів від заданого до кореня. Цикл НЕ вішає систему:
    щойно вузол повторився — ланцюг обривається (а сам цикл позначається)."""
    chain, seen = [], set()
    cur = _s(unit_id)
    while cur and cur in units_by_id and cur not in seen:
        seen.add(cur)
        chain.append(cur)
        cur = _s(units_by_id[cur].get("parent_id"))
    return chain


def _normalize(raw) -> dict:
    """ЄДИНЕ представлення оргструктури. Приймає будь-що, віддає повний запис."""
    if not isinstance(raw, dict):
        raw = {}

    units, positions, employees = [], [], []
    for u in (raw.get("units") or []):
        if not isinstance(u, dict):
            continue
        units.append({"id": _s(u.get("id")) or _new_id("unit"),
                      "name": _s(u.get("name")),
                      "parent_id": _s(u.get("parent_id")),
                      "head_employee_id": _s(u.get("head_employee_id"))})
    for p in (raw.get("positions") or []):
        if not isinstance(p, dict):
            continue
        positions.append({"id": _s(p.get("id")) or _new_id("pos"),
                          "name": _s(p.get("name"))})
    for e in (raw.get("employees") or []):
        if not isinstance(e, dict):
            continue
        employees.append({"id": _s(e.get("id")) or _new_id("emp"),
                          "full_name": _s(e.get("full_name")),
                          "unit_id": _s(e.get("unit_id")),
                          "position_id": _s(e.get("position_id")),
                          "email": _s(e.get("email")),
                          "telegram_id": _s(e.get("telegram_id")),
                          # ⭐ Картка працівника (рішення Андрія 06.08.2026).
                          # «У кого в підпорядкуванні» і «ким керує» тут НЕ
                          # зберігаються: вони обчислюються з дерева.
                          "birthday": _s(e.get("birthday")),
                          "phone_mobile": _s(e.get("phone_mobile")),
                          "phone_work": _s(e.get("phone_work")),
                          "photo": _s(e.get("photo")),
                          "active": bool(e.get("active", True)),
                          "hired_at": _s(e.get("hired_at")),
                          "dismissed_at": _s(e.get("dismissed_at"))})

    units_by_id = {u["id"]: u for u in units}
    pos_by_id = {p["id"]: p for p in positions}
    emp_by_id = {e["id"]: e for e in employees}

    # ── підрозділи: глибина, шлях і чесна ознака зламаності ────────────────
    for u in units:
        reasons = []
        parent = u["parent_id"]
        if parent and parent not in units_by_id:
            reasons.append("батьківського підрозділу «%s» немає" % parent)
        chain = _unit_chain(units_by_id, u["id"])
        # Цикл: піднімаючись угору, знову впираємось у себе.
        cur, seen, cycle = _s(u["parent_id"]), set(), False
        while cur and cur in units_by_id and cur not in seen:
            if cur == u["id"]:
                cycle = True
                break
            seen.add(cur)
            cur = _s(units_by_id[cur].get("parent_id"))
        if cycle:
            reasons.append("підрозділ підпорядкований сам собі (кільце в дереві)")
        head = u["head_employee_id"]
        if head and head not in emp_by_id:
            reasons.append("керівника «%s» немає серед працівників" % head)
        if not u["name"]:
            reasons.append("немає назви")
        u["depth"] = len(chain) - 1 if chain else 0
        u["path"] = " / ".join(_s(units_by_id[c]["name"]) for c in reversed(chain))
        u["head_name"] = _s(emp_by_id.get(head, {}).get("full_name"))
        u["broken"] = bool(reasons)
        u["broken_reason"] = "; ".join(reasons)

    # ── працівники: керівник ОБЧИСЛЮЄТЬСЯ, а не зберігається ───────────────
    for e in employees:
        reasons = []
        if not e["full_name"]:
            reasons.append("немає ПІБ")
        if e["unit_id"] and e["unit_id"] not in units_by_id:
            reasons.append("підрозділу «%s» немає" % e["unit_id"])
        if e["position_id"] and e["position_id"] not in pos_by_id:
            reasons.append("посади «%s» немає" % e["position_id"])
        e["unit_name"] = _s(units_by_id.get(e["unit_id"], {}).get("name"))
        e["position_name"] = _s(pos_by_id.get(e["position_id"], {}).get("name"))
        e["manager_id"] = _manager_id(units_by_id, e)
        e["photo_url"] = ("taskdesk/photos/%s" % e["photo"]) if e["photo"] else ""
        e["can_receive_tasks"] = bool(e["active"]) and not reasons
        e["broken"] = bool(reasons)
        e["broken_reason"] = "; ".join(reasons)

    # «Ким керує» — теж обчислюване: прямі підлеглі це ті, для кого ця людина
    # вийшла керівником. Зберігати цей список означало б другого писаря правди.
    reports = {}
    for e in employees:
        if e["manager_id"]:
            reports.setdefault(e["manager_id"], []).append(e["id"])
    for e in employees:
        e["manager_name"] = _s(emp_by_id.get(e["manager_id"], {}).get("full_name"))
        e["direct_report_ids"] = reports.get(e["id"], [])

    return {"units": units, "positions": positions, "employees": employees,
            "audit": [a for a in (raw.get("audit") or []) if isinstance(a, dict)]}


def _manager_id(units_by_id: dict, emp: dict) -> str:
    """Керівник працівника — керівник його підрозділу; якщо працівник САМ
    керівник цього підрозділу, піднімаємось на рівень вище. Кільце в дереві не
    вішає розрахунок: ланцюг уже обірваний у `_unit_chain`."""
    chain = _unit_chain(units_by_id, emp.get("unit_id"))
    for unit_id in chain:
        head = _s(units_by_id[unit_id].get("head_employee_id"))
        if head and head != emp.get("id"):
            return head
    return ""


def _strip_derived(state: dict) -> dict:
    """Те, що лягає на диск: без жодного обчисленого поля."""
    out = {"units": [], "positions": [], "employees": [],
           "audit": list(state.get("audit") or [])}
    for u in state.get("units") or []:
        out["units"].append({k: v for k, v in u.items() if k not in DERIVED_UNIT})
    for p in state.get("positions") or []:
        out["positions"].append(dict(p))
    for e in state.get("employees") or []:
        out["employees"].append({k: v for k, v in e.items() if k not in DERIVED_EMP})
    return out


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ
# ---------------------------------------------------------------------------
def load() -> dict:
    """ЄДИНИЙ ЧИТАЧ оргструктури. Побитий файл не зникає: він повертається
    порожньою структурою з причиною в `unreadable_reason`, і писар відмовиться
    писати поверх нього (fail-closed над чужою роботою)."""
    if not PEOPLE_JSON.exists():
        st = _normalize({})
        st["unreadable_reason"] = ""
        return st
    try:
        raw = json.loads(PEOPLE_JSON.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            st = _normalize({})
            st["unreadable_reason"] = ("у файлі не оргструктура, а %s"
                                       % type(raw).__name__)
            return st
        st = _normalize(raw)
        st["unreadable_reason"] = ""
        return st
    except Exception as e:
        st = _normalize({})
        st["unreadable_reason"] = "файл не читається: %s" % type(e).__name__
        return st


def units() -> list:
    return load()["units"]


def positions() -> list:
    return load()["positions"]


def employees(include_dismissed: bool = False) -> list:
    """⭐ 06.08.2026 (Андрій): звільнений НЕ показується за замовчуванням.
    Він не зник — щоб побачити всіх, треба попросити явно
    (`include_dismissed=True`). Так список працівників лишається списком тих,
    хто працює, а історія нікуди не дівається."""
    out = load()["employees"]
    return out if include_dismissed else [e for e in out if e["active"]]


def employee(emp_id: str) -> dict:
    for e in load()["employees"]:
        if e["id"] == _s(emp_id):
            return e
    return None


def unit(unit_id: str) -> dict:
    for u in load()["units"]:
        if u["id"] == _s(unit_id):
            return u
    return None


def manager_of(emp_id: str) -> str:
    """Хто керівник цього працівника. Обчислюється щоразу з дерева."""
    e = employee(emp_id)
    return e["manager_id"] if e else ""


def direct_reports(emp_id: str) -> list:
    """Ким керує безпосередньо (для картки працівника)."""
    e = employee(emp_id)
    return list(e["direct_report_ids"]) if e else []


def is_manager_of(boss_id: str, emp_id: str, state: dict = None) -> bool:
    """Чи є `boss_id` керівником `emp_id` на будь-якому рівні вгору.
    `state` — уже прочитана оргструктура: щоб не читати файл на кожну пару."""
    st = state or load()
    chain_of = {e["id"]: e["manager_id"] for e in st["employees"]}
    boss_id, seen, cur = _s(boss_id), set(), _s(emp_id)
    while cur and cur not in seen:
        seen.add(cur)
        nxt = chain_of.get(cur, "")
        if not nxt:
            return False
        if nxt == boss_id:
            return True
        cur = nxt
    return False


def subordinates_of(emp_id: str) -> list:
    """Усі, для кого ця людина — керівник (свій підрозділ і все, що нижче)."""
    st = load()
    return [e["id"] for e in st["employees"] if is_manager_of(emp_id, e["id"], st)]


def card(emp_id: str) -> dict:
    """КАРТКА ПРАЦІВНИКА (склад узгоджений з Андрієм 06.08.2026).
    Половина картки — обчислена: керівник і підлеглі беруться з дерева, а не
    зберігаються полями."""
    e = employee(emp_id)
    if not e:
        return None
    st = load()
    by_id = {x["id"]: x for x in st["employees"]}
    return {
        "id": e["id"],
        "full_name": e["full_name"],
        "position": e["position_name"],
        "unit": e["unit_name"],
        "birthday": e["birthday"],
        "manager": {"id": e["manager_id"], "name": e["manager_name"]},
        "manages": [{"id": i, "name": _s(by_id.get(i, {}).get("full_name"))}
                    for i in e["direct_report_ids"]],
        "phone_mobile": e["phone_mobile"],
        "phone_work": e["phone_work"],
        "email": e["email"],
        "telegram_id": e["telegram_id"],
        # ⭐ Не лише НАЗВИ, а й ідентифікатори: форма правки має чим заповнити
        # вибір підрозділу й посади. Назва для ока, ідентифікатор для машини.
        "unit_id": e["unit_id"],
        "position_id": e["position_id"],
        "photo_url": e["photo_url"],
        "active": e["active"],
        "dismissed_at": e["dismissed_at"],
    }


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ХТО ЩО МОЖЕ ПРАВИТИ В КАРТЦІ. ОДНА ВІДПОВІДЬ НА ВЕСЬ ПРОДУКТ.
#
# Рішення Андрія 08.08.2026: «людина може правити свої дані. Це норма.»
# Тому картка ділиться НЕ на «читати/писати», а на ДВА ШАРИ:
#   • СВОЄ — як з тобою звʼязатись і коли тебе вітати. Це знає сама людина,
#     і бігати з цим до адміністратора — марна робота для обох.
#   • МІСЦЕ В КОМПАНІЇ — імʼя, посада, підрозділ. Це не про людину, це про
#     структуру: підрозділ тягне за собою керівника, видимість задач і права.
#     Такого собі не призначають.
#
# Цю відповідь питають ОБИДВА: екран — щоб намалювати поля, і код дії — щоб не
# пустити чужого. Друга відповідь у другому місці розійшлася б із першою, і
# зʼявилась би кнопка, яка відмовить, — брехня на екрані.
# ---------------------------------------------------------------------------
SELF_FIELDS = ("phone_mobile", "phone_work", "email", "birthday", "telegram_id")
ADMIN_FIELDS = ("full_name", "unit_id", "position_id")
EDITABLE_FIELDS = SELF_FIELDS + ADMIN_FIELDS

FIELD_NAMES = {
    "full_name": "ПІБ", "unit_id": "підрозділ", "position_id": "посада",
    "phone_mobile": "мобільний телефон", "phone_work": "робочий телефон",
    "email": "пошта", "birthday": "день народження", "telegram_id": "телеграм",
}


def card_rights(actor_emp_id: str, emp_id: str, is_admin: bool = False) -> dict:
    """ЩО САМЕ ця людина може правити в ЦІЙ картці.

    ⭐ Звільненого править лише адміністратор: його картка — вже історія, а не
    його робоче місце."""
    actor_emp_id, emp_id = _s(actor_emp_id), _s(emp_id)
    e = employee(emp_id)
    active = bool(e and e["active"])
    is_self = bool(actor_emp_id) and actor_emp_id == emp_id
    fields = []
    if is_admin:
        fields = list(ADMIN_FIELDS) + list(SELF_FIELDS)
    elif is_self and active:
        fields = list(SELF_FIELDS)
    return {"fields": fields,
            "photo": bool(fields),
            "may_edit": bool(fields),
            "is_self": is_self,
            "is_admin": bool(is_admin)}


def who_may_edit(field: str) -> str:
    """Відмова завжди називає ТОГО, ХТО Б ЦЕ ЗМІГ. Тиха відмова = вимкнені ворота."""
    return ("адміністратор" if field in ADMIN_FIELDS
            else "сама людина або адміністратор")


def can_receive_tasks(emp_id: str) -> bool:
    """Звільнений лишається в історії, але нових задач не отримує ніколи."""
    e = employee(emp_id)
    return bool(e and e["can_receive_tasks"])


# ---------------------------------------------------------------------------
# ОДИН ПИСАР
# ---------------------------------------------------------------------------
def save(state: dict, reason: str) -> dict:
    """ЄДИНЕ місце у продукті, де оргструктура лягає на диск.

    `reason` — людськими словами, ЩО саме змінилось; лягає в `audit[]`.
    FAIL-CLOSED: якщо на диску лежить нечитабельний файл, писати поверх
    заборонено — врятувати руками ще можна, а затерте вже ні."""
    if not _s(reason):
        raise PeopleError("зміна без причини не пишеться: журнал оргструктури "
                          "мусить лишатись читабельним")
    on_disk = load()
    if on_disk.get("unreadable_reason"):
        raise PeopleError("оргструктура на диску не читається (%s) — писати "
                          "поверх заборонено, поки людина не вирішить її долю"
                          % on_disk["unreadable_reason"])
    st = _normalize(state)
    disk = _strip_derived(st)
    disk["audit"] = list(disk.get("audit") or [])
    disk["audit"].append({"at": clock.now(), "what": _s(reason)[:300]})
    disk["audit"] = disk["audit"][-AUDIT_KEEP:]
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    PEOPLE_JSON.write_text(json.dumps(disk, ensure_ascii=False, indent=2),
                           encoding="utf-8")
    out = _normalize(disk)
    out["unreadable_reason"] = ""
    return out


# ---------------------------------------------------------------------------
# Дії над оргструктурою (усі проходять через одного писаря)
# ---------------------------------------------------------------------------
def add_unit(name: str, parent_id: str = "", head_employee_id: str = "") -> dict:
    st = load()
    name = _s(name)
    if not name:
        raise PeopleError("підрозділ без назви не заводиться")
    ids = {u["id"] for u in st["units"]}
    if _s(parent_id) and _s(parent_id) not in ids:
        raise PeopleError("батьківського підрозділу «%s» немає" % parent_id)
    if _s(head_employee_id) and _s(head_employee_id) not in {e["id"] for e in st["employees"]}:
        raise PeopleError("керівника «%s» немає серед працівників" % head_employee_id)
    rec = {"id": _new_id("unit"), "name": name, "parent_id": _s(parent_id),
           "head_employee_id": _s(head_employee_id)}
    st["units"].append(rec)
    save(st, "заведено підрозділ «%s»" % name)
    return unit(rec["id"])


def set_unit_parent(unit_id: str, parent_id: str) -> dict:
    """Переміщення гілки. Кільце заборонене ВОРОТАМИ, а не проханням."""
    st = load()
    by_id = {u["id"]: u for u in st["units"]}
    unit_id, parent_id = _s(unit_id), _s(parent_id)
    if unit_id not in by_id:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    if parent_id:
        if parent_id not in by_id:
            raise PeopleError("батьківського підрозділу «%s» немає" % parent_id)
        if parent_id == unit_id:
            raise PeopleError("підрозділ не може бути підпорядкований сам собі")
        # Новий батько не сміє бути нащадком цього ж підрозділу.
        cur, seen = parent_id, set()
        while cur and cur in by_id and cur not in seen:
            if cur == unit_id:
                raise PeopleError("так вийде кільце: «%s» лежить усередині «%s»"
                                  % (by_id[parent_id]["name"], by_id[unit_id]["name"]))
            seen.add(cur)
            cur = _s(by_id[cur].get("parent_id"))
    by_id[unit_id]["parent_id"] = parent_id
    save(st, "підрозділ «%s» переміщено" % by_id[unit_id]["name"])
    return unit(unit_id)


def set_unit_head(unit_id: str, head_employee_id: str) -> dict:
    st = load()
    by_id = {u["id"]: u for u in st["units"]}
    unit_id, head = _s(unit_id), _s(head_employee_id)
    if unit_id not in by_id:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    if head and head not in {e["id"] for e in st["employees"]}:
        raise PeopleError("керівника «%s» немає серед працівників" % head)
    by_id[unit_id]["head_employee_id"] = head
    save(st, "змінено керівника підрозділу «%s»" % by_id[unit_id]["name"])
    return unit(unit_id)


def add_position(name: str) -> dict:
    st = load()
    name = _s(name)
    if not name:
        raise PeopleError("посада без назви не заводиться")
    for p in st["positions"]:
        if p["name"].lower() == name.lower():
            return p
    rec = {"id": _new_id("pos"), "name": name}
    st["positions"].append(rec)
    save(st, "заведено посаду «%s»" % name)
    return rec


def add_employee(full_name: str, unit_id: str = "", position_id: str = "",
                 email: str = "", telegram_id: str = "", birthday: str = "",
                 phone_mobile: str = "", phone_work: str = "", photo: str = "") -> dict:
    st = load()
    full_name = _s(full_name)
    if not full_name:
        raise PeopleError("працівник без ПІБ не заводиться")
    if _s(unit_id) and _s(unit_id) not in {u["id"] for u in st["units"]}:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    if _s(position_id) and _s(position_id) not in {p["id"] for p in st["positions"]}:
        raise PeopleError("посади «%s» немає" % position_id)
    _check_card_fields({"email": email, "birthday": birthday, "photo": photo,
                        "phone_mobile": phone_mobile, "phone_work": phone_work})
    rec = {"id": _new_id("emp"), "full_name": full_name, "unit_id": _s(unit_id),
           "position_id": _s(position_id), "email": _s(email),
           "telegram_id": _s(telegram_id), "birthday": _s(birthday),
           "phone_mobile": _s(phone_mobile), "phone_work": _s(phone_work),
           "photo": _s(photo), "active": True,
           "hired_at": clock.now(), "dismissed_at": ""}
    st["employees"].append(rec)
    save(st, "заведено працівника «%s»" % full_name)
    return employee(rec["id"])


def update_employee(emp_id: str, **fields) -> dict:
    """Зміна картки. Керівника тут немає й бути не може — він обчислюється."""
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id = _s(emp_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    allowed = {"full_name", "unit_id", "position_id", "email", "telegram_id",
               "birthday", "phone_mobile", "phone_work", "photo"}
    unknown = set(fields) - allowed
    if unknown:
        raise PeopleError("цих полів у картці працівника немає: %s"
                          % ", ".join(sorted(unknown)))
    if "unit_id" in fields and _s(fields["unit_id"]) and \
            _s(fields["unit_id"]) not in {u["id"] for u in st["units"]}:
        raise PeopleError("підрозділу «%s» немає" % fields["unit_id"])
    if "position_id" in fields and _s(fields["position_id"]) and \
            _s(fields["position_id"]) not in {p["id"] for p in st["positions"]}:
        raise PeopleError("посади «%s» немає" % fields["position_id"])
    _check_card_fields(fields)
    for k, v in fields.items():
        by_id[emp_id][k] = _s(v)
    save(st, "змінено картку працівника «%s»" % by_id[emp_id]["full_name"])
    return employee(emp_id)


def dismiss_employee(emp_id: str, reason: str = "") -> dict:
    """Звільнення. Запис НЕ видаляється: історія задач не має осиротіти."""
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id = _s(emp_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    by_id[emp_id]["active"] = False
    by_id[emp_id]["dismissed_at"] = clock.now()
    # Звільнений не лишається керівником підрозділу: інакше дерево віддавало б
    # начальника, якого в компанії вже немає.
    for u in st["units"]:
        if u["head_employee_id"] == emp_id:
            u["head_employee_id"] = ""
    what = "звільнено працівника «%s»" % by_id[emp_id]["full_name"]
    save(st, what + (": %s" % _s(reason) if _s(reason) else ""))
    return employee(emp_id)


def _photo_kind(raw: bytes) -> tuple:
    for magic, ext, mime in PHOTO_KINDS:
        if raw[:len(magic)] == magic:
            if ext == "webp" and raw[8:12] != b"WEBP":
                continue
            return ext, mime
    return "", ""


def set_photo(emp_id: str, raw: bytes) -> dict:
    """Фото працівника. Імʼя файла робимо МИ (з id), а не приймаємо ззовні:
    назва з чужих рук — це шлях у чужу теку."""
    emp = employee(emp_id)
    if not emp:
        raise PeopleError("працівника «%s» немає" % emp_id)
    raw = raw or b""
    if len(raw) > MAX_PHOTO_BYTES:
        raise PeopleError("фото більше за %d МБ — стисніть його"
                          % (MAX_PHOTO_BYTES // (1024 * 1024)))
    ext, _mime = _photo_kind(raw)
    if not ext:
        raise PeopleError("це не схоже на картинку: приймаємо PNG, JPEG або WEBP")
    PHOTOS_DIR.mkdir(parents=True, exist_ok=True)
    for _m, old_ext, _mm in PHOTO_KINDS:      # старе фото іншого роду прибираємо
        old = PHOTOS_DIR / ("%s.%s" % (emp["id"], old_ext))
        if old.exists() and old_ext != ext:
            old.unlink()
    (PHOTOS_DIR / ("%s.%s" % (emp["id"], ext))).write_bytes(raw)
    return update_employee(emp["id"], photo="%s.%s" % (emp["id"], ext))


def photo_bytes(emp_id: str) -> tuple:
    """Фото для показу: (байти, тип). Немає — (None, "")."""
    emp = employee(emp_id)
    if not emp or not emp["photo"]:
        return None, ""
    p = PHOTOS_DIR / emp["photo"]
    if not p.exists():
        return None, ""
    raw = p.read_bytes()
    _ext, mime = _photo_kind(raw)
    return raw, (mime or "application/octet-stream")


def restore_employee(emp_id: str) -> dict:
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id = _s(emp_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    by_id[emp_id]["active"] = True
    by_id[emp_id]["dismissed_at"] = ""
    save(st, "поновлено працівника «%s»" % by_id[emp_id]["full_name"])
    return employee(emp_id)
