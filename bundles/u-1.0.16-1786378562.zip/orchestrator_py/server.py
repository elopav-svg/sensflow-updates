"""
server.py — точка входу. Легкий HTTP-сервер на стандартній бібліотеці.

Запуск:  python server.py
Відкрити: http://127.0.0.1:7799

Жодних зовнішніх залежностей для самого сервера. Потрібен лише API-ключ LLM
у orchestrator_py/.env.local (OPENAI_API_KEY або ANTHROPIC_API_KEY).
"""

import json
import sys
import os
import time
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# Дозволяємо плоскі імпорти (import config, import llm, ...)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
import registry
import store
import engine
import scheduler
import artifacts
import filetext
import discovery
import capabilities
import threads
import projects
import llm
import tools


def _json_bytes(payload) -> bytes:
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")


def _persist_turn(tid, user_message, incoming_fc, reply, result_obj=None) -> bool:
    """ОДИН ПИСАР ХОДУ В ТРЕД (30.07.2026).

    НАВІЩО. Запис ходу жив ЛИШЕ на успішній гілці обох дверей чату: якщо рушій
    падав винятком, користувач бачив текст аварії, але в треді не лишалось НІ
    його питання, НІ відповіді. Після перезапуску діалогу просто не існувало —
    людина не могла ні повторити, ні показати, що саме питала.

    ⛔ ХІД, ЗАПИСАНИЙ ЛИШЕ НА УСПІШНІЙ ГІЛЦІ, ЗНИКАЄ САМЕ ТОДІ, КОЛИ ПОТРІБЕН.

    Тому писар ОДИН і викликається на ОБОХ гілках (успіх і виняток) обох дверей
    (`/api/chat` і `/api/chat/stream`). Сам він мовчазним бути не має права:
    якщо не зміг записати — каже про це в журнал, а не «пас».
    """
    if not tid:
        return False
    try:
        threads.append(tid, "user", user_message or "(прикріплені файли)",
                       files_context=incoming_fc or None)
        _r = result_obj or {}
        threads.append(tid, "assistant", reply or "",
                       extra=({"result": {
                           "final_markdown": _r.get("final_markdown", ""),
                           "artifacts": _r.get("artifacts", []),
                           "sources": _r.get("sources", []),
                           "verification": _r.get("verification"),
                           "brain_trace": [x for x in (_r.get("brain_trace") or [])
                                           if x.get("type") == "tool"],
                       }} if _r else None))
        return True
    except Exception as e:
        try:
            llm._log("[server] ХІД НЕ ЗАПИСАНО В ТРЕД %s: %s" % (tid, e))
        except Exception:
            pass
        return False


# ── RBAC-lite: роль із ліцензії (operator = обмежені права) ──────────────────
# Адмінські дії (налаштування, керування системами/ключами/Telegram) недоступні
# в режимі оператора. Запуск задач, читання й свої чати — доступні.
_ADMIN_POST_PATHS = {"/api/automations/toggle", "/api/automations/schedule",
                     "/api/automations/run_now", "/api/automations/delete",
                     "/api/discover", "/api/llm/config",
                     "/api/system/status",
                     "/api/setup", "/api/setup/local", "/api/llm/stealth",
                     "/api/license", "/api/license/generate",
                     "/api/telegram/token", "/api/telegram/tasks_token",
                     "/api/telegram/support_mode", "/api/support/log",
                     "/api/update/apply", "/api/llm/demo",
                     "/api/crm/note", "/api/crm/archive", "/api/crm/unarchive", "/api/crm/history",
                     "/api/crm/stage", "/api/crm/attention",
                     "/api/crm/profile", "/api/crm/contact", "/api/crm/contact_remove",
                     "/api/crm/systems",
                     "/api/crm/next_action", "/api/crm/deal", "/api/crm/comm", "/api/crm/dossier",
                     "/api/crm/action_done", "/api/crm/inbound", "/api/crm/inbox_clear"}
_ADMIN_GET_PATHS = {"/setup", "/setup.html", "/telegram", "/telegram.html",
                    "/genkey", "/genkey.html", "/api/telegram/users", "/api/license/admin",
                    "/api/support",
                    "/api/crm/list", "/api/crm/card", "/api/crm/board", "/api/crm/channels",
                    "/api/crm/products",
                    "/api/crm/pipeline", "/api/crm/inbox"}


def _is_admin_request() -> bool:
    """True, якщо поточне посвідчення має адмінські права. Fail-open: за будь-якої
    помилки перевірки — НЕ блокуємо (щоб не зламати роботу)."""
    try:
        import license as _lic
        return _lic.is_admin()
    except Exception:
        return True


def _me_for_screen(session_actor):
    """ОДНА відповідь «хто я» для екранів — через того самого `resolve_actor()`,
    що вирішує, хто діє. Друга відповідь у другому місці розійшлася б із першою."""
    import taskdesk_identity as _tdid
    try:
        acc = _tdid.resolve_actor(session_actor)
    except Exception:
        acc = None
    if not acc or not acc.get("employee_id"):
        return None
    return {"employee_id": acc.get("employee_id"),
            "name": acc.get("employee_name") or "",
            "is_admin": bool(acc.get("is_admin"))}


class Handler(BaseHTTPRequestHandler):
    server_version = "AIOrchestratorPy/1.0"

    # ---- утиліти ----------------------------------------------------------
    def _send(self, status, payload, content_type="application/json; charset=utf-8",
              headers=None):
        body = payload if isinstance(payload, (bytes, bytearray)) else _json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    # ⭐⭐⭐ ВОРОТА 1 «ХТО ЦЕ» (крок 1.3 Task Desk, 06.08.2026).
    # Стоять В ОДНОМУ місці на всі ~60 обробників: інакше кожен новий обробник
    # мусив би памʼятати про перевірку — а той, хто забуде, і стане дірою.
    # Поки в компанії один обліковий запис (як у Каспера), ворота пропускають
    # усе, як і раніше: живу роботу клієнта вони не чіпають.
    def _taskdesk_gate(self):
        import taskdesk_identity as _tdid
        ok, who, why = _tdid.web_gate(self.path.split("?", 1)[0],
                                      self.headers.get("Cookie") or "")
        self.actor = who
        return ok, why

    # ⭐ ХТО ДІЄ В ЦЬОМУ ЗАПИТІ (крок 1.5). Консоль не вирішує сама: питає
    # єдиного відповідача. `self.actor` сюди кладуть ворота `_taskdesk_gate`.
    def _actor(self):
        import taskdesk_identity as _tdid
        return _tdid.resolve_actor(getattr(self, "actor", None))

    def _read_json(self):
        length = int(self.headers.get("Content-Length", "0") or "0")
        if not length:
            return {}
        raw = self.rfile.read(length)
        try:
            return json.loads(raw.decode("utf-8"))
        except Exception:
            return {}

    def log_message(self, fmt, *args):  # тихіший лог
        sys.stderr.write("[srv] " + (fmt % args) + "\n")

    # ---- GET --------------------------------------------------------------
    def do_GET(self):
        path = self.path.split("?", 1)[0]

        _ok, _why = self._taskdesk_gate()
        if not _ok:
            return self._send(401, {"error": "login_required", "message": _why})

        if path == "/api/taskdesk/whoami":
            import taskdesk_identity as _tdid
            who = getattr(self, "actor", None)
            import taskdesk_api as _tdapi0
            return self._send(200, {"enabled": _tdapi0.enabled(),
                                    "login_required": _tdid.login_required(),
                                    "light_mode": _tdid.light_mode(),
                                    "actor": ({"id": who["id"], "login": who["login"],
                                               "name": who["employee_name"],
                                               "is_admin": who["is_admin"],
                                               "layers": who["layers"],
                                               "orchestrator": who["orchestrator"]}
                                              if who else None),
                                    # ⭐ «Хто я» для екрана — це РОЗВʼЯЗАНИЙ актор
                                    # (`resolve_actor`), а не лише жива сесія: в
                                    # одноосібного клієнта сесії немає, а людина є.
                                    # Без цього кнопці «Моя картка» нема куди вести.
                                    "me": _me_for_screen(who)})

        # ── Екрани Task Desk (крок 1.4). Поки робота вимкнена — їх немає зовсім:
        # вимкнена річ не мусить світитись у клієнта навіть сторінкою.
        if path in ("/taskdesk.css", "/taskdesk.js"):
            page = config.UI_DIR / path.lstrip("/")
            if not page.exists():
                return self._send(404, {"error": "not_found"})
            kind = ("text/css" if path.endswith(".css") else "application/javascript")
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="%s; charset=utf-8" % kind)

        if path in ("/login", "/people", "/access", "/employee", "/tasks", "/task"):
            import taskdesk_api as _tdapi
            if not _tdapi.enabled():
                return self._send(404, {"error": "not_found"})
            names = {"/login": "taskdesk_login.html", "/people": "taskdesk_people.html",
                     "/access": "taskdesk_access.html",
                     "/employee": "taskdesk_employee.html",
                     "/tasks": "taskdesk_tasks.html", "/task": "taskdesk_task.html"}
            page = config.UI_DIR / names[path]
            if not page.exists():
                return self._send(500, {"error": "taskdesk_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        if path in ("/api/taskdesk/people", "/api/taskdesk/accounts",
                    "/api/taskdesk/employee_card"):
            import taskdesk_api as _tdapi
            who = getattr(self, "actor", None)
            try:
                if path == "/api/taskdesk/people":
                    return self._send(200, _tdapi.people_state(who))
                if path == "/api/taskdesk/accounts":
                    return self._send(200, _tdapi.accounts_state(who))
                from urllib.parse import urlparse as _up, parse_qs as _pq
                q = _pq(_up(self.path).query)
                return self._send(200, _tdapi.employee_card(who, (q.get("id") or [""])[0]))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path in ("/api/taskdesk/board", "/api/taskdesk/task"):
            import taskdesk_api as _tdapi
            from urllib.parse import urlparse as _upb, parse_qs as _pqb
            q = _pqb(_upb(self.path).query)
            # ⭐ «Хто діє» питаємо ЄДИНОГО відповідача (крок 1.5), а не сирий
            # actor сесії: інакше єдиний власник без входу перестає бути людиною.
            who = self._actor()
            try:
                if path == "/api/taskdesk/board":
                    return self._send(200, _tdapi.board_state(
                        who, (q.get("scope") or ["all"])[0],
                        (q.get("closed") or [""])[0] == "1",
                        None, (q.get("q") or [""])[0],
                        (q.get("fresh") or [""])[0] == "1"))
                return self._send(200, _tdapi.task_state(who, (q.get("id") or [""])[0]))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/photo":
            import taskdesk_api as _tdapi
            from urllib.parse import urlparse as _up2, parse_qs as _pq2
            q = _pq2(_up2(self.path).query)
            try:
                raw, mime = _tdapi.photo_get(getattr(self, "actor", None),
                                             (q.get("id") or [""])[0])
                return self._send(200, raw, content_type=mime)
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/light_list":
            # Легкий режим: список людей для вибору себе без пароля. Поза легким
            # режимом список нікому не показується — це не довідник для чужих.
            import taskdesk_identity as _tdid
            if not _tdid.light_mode():
                return self._send(403, {"error": "light_mode_off",
                                        "message": "Вхід без пароля вимкнений."})
            return self._send(200, {"accounts": [
                {"id": a["id"], "name": a["employee_name"], "login": a["login"]}
                for a in _tdid.accounts() if a["can_login"]]})

        # Сервіс-центр (CRM) — ЛИШЕ у збірці адміністратора (LICENSE_ADMIN=1).
        # У клієнтських/тріальних збірках LICENSE_ADMIN відсутній → повна відмова.
        if path.startswith("/api/crm") and not config.LICENSE_ADMIN:
            return self._send(403, {"error": "admin_only",
                                     "message": "Сервіс-центр доступний лише у збірці адміністратора."})

        if path in _ADMIN_GET_PATHS and not _is_admin_request():
            return self._send(403, {"error": "operator_forbidden",
                                     "message": "Сторінка доступна лише адміністратору (режим оператора)."})

        if path == "/" or path == "/index.html":
            return self._serve_ui()

        if path == "/setup" or path == "/setup.html":
            page = config.UI_DIR / "setup.html"
            if not page.exists():
                return self._send(500, {"error": "setup_ui_missing"})
            return self._send(200, self._localized_html(page),
                              content_type="text/html; charset=utf-8")

        if path == "/telegram" or path == "/telegram.html":
            page = config.UI_DIR / "telegram.html"
            if not page.exists():
                return self._send(500, {"error": "telegram_ui_missing"})
            return self._send(200, self._localized_html(page),
                              content_type="text/html; charset=utf-8")

        if path == "/genkey" or path == "/genkey.html":
            page = config.UI_DIR / "genkey.html"
            if not page.exists():
                return self._send(500, {"error": "genkey_ui_missing"})
            body = page.read_text(encoding="utf-8").encode("utf-8")
            return self._send(200, body, content_type="text/html; charset=utf-8")

        if path == "/i18n.js":
            page = config.UI_DIR / "i18n.js"
            if not page.exists():
                return self._send(500, {"error": "i18n_missing"})
            body = page.read_text(encoding="utf-8").encode("utf-8")
            return self._send(200, body,
                              content_type="application/javascript; charset=utf-8")

        if path == "/api/telegram/users":
            import telegram_access, telegram_bot
            import config as _cfg
            snap = telegram_access.snapshot()
            snap["bot"] = telegram_bot.status()
            snap["support_mode"] = _cfg.TELEGRAM_SUPPORT_MODE
            return self._send(200, snap)

        if path == "/api/update/check":
            import update as _upd
            return self._send(200, _upd.check_for_update())

        if path == "/api/health":
            try:
                import license as _lic
                _role = _lic.role()
            except Exception:
                _role = "admin"
            try:
                import costs as _costs
                _sess = _costs.session()
            except Exception:
                _sess = {}
            return self._send(200, {
                "ok": True,
                "orchestrator": "python_global_orchestrator",
                "brain": config.provider_status(),
                "artifacts": artifacts.capabilities(),
                "role": _role,
                "is_admin": _role != "operator",
                "costs": {"session_usd": round(_sess.get("usd", 0.0), 4),
                          "session_calls": _sess.get("calls", 0)},
            })

        if path == "/api/support":
            import support
            return self._send(200, support.summary())

        # ── Кнопка «Допомога з технічних питань» ─────────────────────────────
        # Доступна КЛІЄНТУ (не адмінська): це його спосіб покликати підтримку.
        # Сервер нічого не надсилає — лише показує, що піде у файл.
        if path == "/api/support_report/preview":
            import support_report
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            opts = {"task_texts": (q.get("task_texts", ["0"])[0] == "1")}
            rep = support_report.build(opts)
            rep["folder"] = str(support_report.reports_dir())
            return self._send(200, rep)

        if path == "/api/automations":
            return self._send(200, {"automations": scheduler.list_automations()})

        if path == "/api/llm/config":
            st = config.provider_status()
            st["suggestions"] = config.MODEL_SUGGESTIONS
            st["demo"] = (config.ENV.get("DEMO_MODE") == "1")
            return self._send(200, st)

        if path == "/api/capabilities":
            return self._send(200, capabilities.self_model())

        if path == "/api/styles":
            import styles
            return self._send(200, {"styles": styles.list_styles()})

        if path == "/api/threads":
            return self._send(200, {"threads": threads.list_threads()})

        if path.startswith("/api/threads/"):
            tid = path.split("/api/threads/", 1)[1]
            rec = threads.get(tid)
            if not rec:
                return self._send(404, {"error": "thread_not_found"})
            return self._send(200, rec)

        if path == "/api/projects":
            return self._send(200, {"projects": projects.list_projects()})

        if path.startswith("/api/projects/"):
            rest = path.split("/api/projects/", 1)[1]
            if rest.endswith("/documents"):
                pid = rest[:-len("/documents")]
                return self._send(200, {"documents": projects.documents(pid)})
            rec = projects.get(rest)
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/registry":
            return self._send(200, {"systems": registry.load_systems()})

        if path == "/api/connectors":
            return self._send(200, {"connectors": registry.connector_inventory()})

        if path == "/api/runs":
            return self._send(200, {"runs": store.list_runs()})

        if path == "/api/egress/log":
            # Журнал виходів назовні (режим максимального збереження) — доказ, що
            # жоден вихід не стався без явного дозволу. Найновіші — в кінці.
            import egress_guard
            return self._send(200, {"log": egress_guard.tail(100),
                                    "stealth": egress_guard.stealth_on()})

        if path == "/api/version":
            import update
            return self._send(200, {"version": update.current_version()})

        if path == "/api/license":
            import license as licensing
            st = licensing.status()
            st["entitlement"] = licensing.entitlement()
            return self._send(200, st)

        if path == "/api/license/admin":
            return self._send(200, {"admin": config.LICENSE_ADMIN})

        if path == "/api/update/check":
            import update
            return self._send(200, update.check_for_update())

        if path == "/api/crm/list":
            import crm
            return self._send(200, {"active": crm.list_clients(False),
                                    "archived": crm.list_clients(True),
                                    "counts": crm.counts()})

        if path == "/api/crm/products":
            # ⭐ ЕТАП 4: що взагалі можна купити. Перелік — з ОДНОГО місця
            # (`make_client_build.PRODUCT_SYSTEMS`), назви — з реєстру.
            import make_client_build as _mcb
            import registry as _reg
            _names = {x.get("id"): (x.get("name") or x.get("id"))
                      for x in _reg.load_systems()}
            return self._send(200, {"systems": [
                {"id": _sid, "name": _names.get(_sid, _sid)}
                for _sid in sorted(_mcb.PRODUCT_SYSTEMS,
                                   key=lambda i: (_names.get(i, i) or "").lower())]})

        if path == "/api/crm/card":
            import crm
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            cust = (q.get("customer", [""])[0] or "").strip()
            card = crm.card_public(cust)
            if not card:
                return self._send(404, {"error": "client_not_found"})
            return self._send(200, card)

        if path == "/api/crm/board":
            import crm
            return self._send(200, crm.board())

        if path == "/api/crm/pipeline":
            import crm
            return self._send(200, crm.pipeline())

        if path == "/api/crm/inbox":
            import crm
            return self._send(200, {"inbox": crm.inbox()})

        if path == "/api/crm/channels":
            import config as _cfg
            return self._send(200, {
                "email": {"available": True, "mode": "mailto",
                          "hint": "Лист відкривається у вашій поштовій програмі; пряму відправку (SMTP) можна підключити пізніше."},
                "telegram": {"available": bool(getattr(_cfg, "TELEGRAM_BOT_TOKEN", "") or _cfg.ENV.get("TELEGRAM_BOT_TOKEN")),
                             "connect": "/telegram",
                             "hint": "Підключіть бота у розділі Telegram, щоб писати клієнту з картки."},
                "call": {"available": True, "mode": "log",
                         "hint": "Дзвоніть через месенджер/телефон, а тут фіксуйте результат у історію."},
            })

        if path.startswith("/artifacts/"):
            return self._serve_artifact(path)

        return self._send(404, {"error": "not_found", "path": path})

    # ---- POST -------------------------------------------------------------
    def do_POST(self):
        path = self.path.split("?", 1)[0]

        _ok, _why = self._taskdesk_gate()
        if not _ok:
            return self._send(401, {"error": "login_required", "message": _why})

        if path == "/api/taskdesk/login":
            import taskdesk_identity as _tdid
            data = self._read_json()
            try:
                if data.get("account_id"):
                    token = _tdid.login_light(data.get("account_id"))
                else:
                    token = _tdid.login(data.get("login") or "", data.get("password") or "")
            except _tdid.IdentityError as e:
                return self._send(401, {"error": "login_failed", "message": str(e)})
            return self._send(200, {"ok": True},
                              headers={"Set-Cookie": _tdid.cookie_header(token)})

        if path == "/api/taskdesk/photo":
            import taskdesk_api as _tdapi
            data = self._read_json()
            try:
                return self._send(200, _tdapi.photo_set(getattr(self, "actor", None),
                                                        data.get("id") or "",
                                                        data.get("data") or ""))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/tasks/action":
            import taskdesk_api as _tdapi
            try:
                return self._send(200, _tdapi.run_task_action(
                    self._actor(), self._read_json()))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        # Вигляд списку, фільтр, збережені набори і вивантаження в Excel. Ворота
        # тут ті самі, що в задачах: веде сама людина, не адміністратор.
        if path == "/api/taskdesk/prefs/action":
            import taskdesk_api as _tdapi
            try:
                return self._send(200, _tdapi.run_prefs_action(
                    self._actor(), self._read_json()))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path in ("/api/taskdesk/people/action", "/api/taskdesk/access/action"):
            import taskdesk_api as _tdapi
            table = "people" if path.endswith("/people/action") else "access"
            try:
                return self._send(200, _tdapi.run_action(getattr(self, "actor", None),
                                                         table, self._read_json()))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/logout":
            import taskdesk_identity as _tdid
            _tdid.logout(_tdid.token_from_cookies(self.headers.get("Cookie") or ""))
            return self._send(200, {"ok": True},
                              headers={"Set-Cookie": _tdid.clear_cookie_header()})

        # Сервіс-центр (CRM) — ЛИШЕ у збірці адміністратора (LICENSE_ADMIN=1).
        if path.startswith("/api/crm") and not config.LICENSE_ADMIN:
            return self._send(403, {"error": "admin_only",
                                     "message": "Сервіс-центр доступний лише у збірці адміністратора."})

        if path in _ADMIN_POST_PATHS and not _is_admin_request():
            return self._send(403, {"error": "operator_forbidden",
                                     "message": "Дія доступна лише адміністратору (режим оператора)."})

        if path == "/api/support_report/save":
            import support_report
            data = self._read_json()
            keys = data.get("keys")
            opts = {"task_texts": bool(data.get("task_texts"))}
            res = support_report.save(message=(data.get("message") or ""),
                                      keys=(list(keys) if isinstance(keys, list) else None),
                                      options=opts)
            if data.get("open_folder", True):
                res["opened"] = support_report.open_folder(res.get("path"))
            return self._send(200, res)

        if path == "/api/support_report/open":
            import support_report
            data = self._read_json()
            return self._send(200, {"ok": support_report.open_folder(data.get("path"))})

        if path == "/api/chat/stream":
            import runstate
            data = self._read_json()
            message = (data.get("message") or "").strip()
            files = data.get("files") or []
            cancel_token = data.get("cancel_token") or ""
            runstate.clear(cancel_token)
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self.close_connection = True  # закрити сокет після стріму

            def emit(etype, payload):
                try:
                    self.wfile.write(("data: " + json.dumps({"type": etype, "data": payload},
                                                             ensure_ascii=False) + "\n\n").encode("utf-8"))
                    self.wfile.flush()
                except Exception:
                    pass

            # Тред заводимо ДО спроби виконати: інакше на винятку немає куди
            # записати хід — і питання людини зникає разом з аварією.
            tid, incoming_fc = "", ""
            try:
                tid = data.get("thread_id") or threads.create()["id"]
            except Exception:
                pass
            try:
                # Новий чат, створений у проєкті: спершу зробити його членом проєкту,
                # ЩОБ контекст проєкту дійшов до мозку вже в ПЕРШОМУ повідомленні.
                _pid = data.get("project_id")
                if _pid:
                    try:
                        projects.add_thread(_pid, tid)
                    except Exception:
                        pass
                incoming_fc, _m = filetext.build_files_context(files) if files else ("", [])
                if not incoming_fc:
                    incoming_fc = data.get("files_context") or ""
                # Успадкувати документ із попередніх ходів, якщо зараз нічого не прикріплено.
                files_context = incoming_fc or threads.latest_files_context(tid)
                _url_ctx = tools.fetch_urls_in_text(message)
                if _url_ctx:
                    files_context = (files_context + "\n\n" + _url_ctx).strip()
                result = engine.handle_message(
                    self._actor(),
                    message=message or "(див. прикріплені файли)",
                    history=threads.history_for_brain(tid),
                    files_context=files_context,
                    pending=data.get("pending"),
                    confirm=data.get("confirm"),
                    emit=emit,
                    should_cancel=(lambda: runstate.is_cancelled(cancel_token)) if cancel_token else None,
                    project_context=projects.context_for_thread(tid),
                    egress_allowed=bool(data.get("egress_allowed")),
                )
                _persist_turn(tid, message, incoming_fc,
                              result.get("reply", ""), result.get("result"))
                result["thread_id"] = tid
                emit("final", result)
            except Exception as e:
                import traceback
                traceback.print_exc()
                # Аварія — теж хід розмови: питання людини й чесна відповідь
                # лягають у тред ТИМ САМИМ писарем, що й успішна відповідь.
                import failure
                _reply = failure.client_text(e, "server/chat_stream")
                _persist_turn(tid, message, incoming_fc, _reply)
                emit("final", {"reply": _reply, "thread_id": tid,
                               "decision": {"status": "error"}, "result": None, "pending": None})
            finally:
                runstate.clear(cancel_token)
            return

        if path == "/api/chat":
            data = self._read_json()
            message = (data.get("message") or "").strip()
            files = data.get("files") or []
            if not message and not data.get("pending") and not files:
                return self._send(400, {"error": "empty_message"})
            # Тред заводимо ДО спроби виконати (див. _persist_turn): хід мусить
            # мати куди лягти й тоді, коли рушій упав.
            tid, incoming_fc = "", ""
            try:
                tid = data.get("thread_id") or threads.create()["id"]
            except Exception:
                pass
            try:
                # Новий чат, створений у проєкті: спершу зробити його членом проєкту,
                # ЩОБ контекст проєкту дійшов до мозку вже в ПЕРШОМУ повідомленні.
                _pid = data.get("project_id")
                if _pid:
                    try:
                        projects.add_thread(_pid, tid)
                    except Exception:
                        pass
                incoming_fc, _meta = filetext.build_files_context(files) if files else ("", [])
                if not incoming_fc:
                    incoming_fc = data.get("files_context") or ""
                # Успадкувати документ із попередніх ходів, якщо зараз нічого не прикріплено.
                files_context = incoming_fc or threads.latest_files_context(tid)
                _url_ctx = tools.fetch_urls_in_text(message)
                if _url_ctx:
                    files_context = (files_context + "\n\n" + _url_ctx).strip()
                result = engine.handle_message(
                    self._actor(),
                    message=message or "(див. прикріплені файли)",
                    history=threads.history_for_brain(tid),
                    files_context=files_context,
                    pending=data.get("pending"),
                    confirm=data.get("confirm"),
                    project_context=projects.context_for_thread(tid),
                    egress_allowed=bool(data.get("egress_allowed")),
                )
                # Збереження у архів чатів — ОДИН писар (див. _persist_turn)
                _persist_turn(tid, message, incoming_fc,
                              result.get("reply", ""), result.get("result"))
                result["thread_id"] = tid
                return self._send(200, result)
            except Exception as e:  # ніколи не падаємо мовчки
                import traceback
                traceback.print_exc()
                import failure
                _reply = failure.client_text(e, "server/chat")
                _persist_turn(tid, message, incoming_fc, _reply)
                return self._send(500, {
                    "reply": _reply, "thread_id": tid,
                    "decision": {"status": "error"}, "result": None, "pending": None,
                })

        if path == "/api/automations/toggle":
            data = self._read_json()
            ok = scheduler.set_enabled(data.get("id"), bool(data.get("enabled")))
            return self._send(200, {"ok": ok})

        # ⭐ 28.07.2026: розклад можна не лише вмикати, а й НАЛАШТОВУВАТИ —
        # періодичність і час наступного запуску. Раніше був самий вимикач.
        if path == "/api/automations/schedule":
            data = self._read_json()
            res = scheduler.set_schedule(data.get("id"),
                                         cadence=data.get("cadence"),
                                         next_run_at=data.get("next_run_at"))
            return self._send(200 if res.get("ok") else 400, res)

        # ⭐ 30.07.2026 (Зміна B). Двері НІЧОГО не виконують і нічого не стирають:
        # вони лише переказують прохання дошці. «Запустити зараз» пересуває час і
        # віддає задачу тому самому єдиному виконавцеві; «видалити» переносить
        # теку в архів. Обидві відповідають словами людини, а не кодом помилки.
        if path == "/api/automations/run_now":
            data = self._read_json()
            res = scheduler.request_run_now(data.get("id"))
            return self._send(200 if res.get("ok") else 400, res)

        if path == "/api/automations/delete":
            data = self._read_json()
            res = scheduler.delete(data.get("id"))
            return self._send(200 if res.get("ok") else 400, res)

        if path == "/api/discover":
            result = discovery.sync(register=True)
            return self._send(200, result)

        if path == "/api/system/status":
            # Активація/деактивація системи однією кнопкою в UI (лише адмін — див.
            # _ADMIN_POST_PATHS). Активація також пише статус у папку системи
            # (management → registry.write_folder_state), щоб пережити оновлення.
            import management
            data = self._read_json()
            sid = (data.get("system_id") or "").strip()
            status = (data.get("status") or "").strip().lower()
            if status not in ("active", "inactive"):
                return self._send(400, {"ok": False, "message": "status має бути active або inactive."})
            action = "activate" if status == "active" else "deactivate"
            res = management.apply_action(self._actor(), action, sid)
            return self._send(200 if res.get("ok") else 400, res)

        if path == "/api/llm/config":
            data = self._read_json()
            st = config.set_llm(
                provider=(data.get("provider") or "").strip().lower() or None,
                brain=(data.get("brain") or "").strip() or None,
                worker=(data.get("worker") or "").strip() or None,
            )
            # Самомодель залежить від активної моделі — скинути кеш, щоб мозок знав про зміну.
            try:
                capabilities.invalidate()
            except Exception:
                pass
            st["suggestions"] = config.MODEL_SUGGESTIONS
            return self._send(200, st)

        if path == "/api/llm/demo":
            data = self._read_json()
            on = bool(data.get("on"))
            ks = config.keys_status()
            if on:
                if ks.get("gemini"):
                    # ⭐ 10.08.2026, зміна 146. ДЕМО-РЕЖИМ — ЦЕ ПЕРШИЙ ДОТИК
                    # НОВОГО КЛІЄНТА, і зашита тут модель робила його першим
                    # враженням помилку 404. Беремо ЖИВІ моделі в одного писаря.
                    _g = config.MODEL_SUGGESTIONS.get("gemini") or []
                    b = _g[0] if _g else config.brain_model()
                    w = config.GEMINI_WORKER_MODEL
                elif ks.get("openai"):
                    b, w = "gpt-4.1", "gpt-4o"
                elif ks.get("anthropic"):
                    b, w = "claude-sonnet-4-6", "claude-haiku-4-5-20251001"
                else:
                    return self._send(200, {"error": "no_keys", "demo": False,
                                            "message": "Немає ключа жодного хмарного провайдера."})
                if config.ENV.get("DEMO_MODE") != "1":
                    prev = {"DEMO_PREV_BRAIN": config.brain_model(),
                            "DEMO_PREV_WORKER": config.worker_model()}
                    config.update_env_local(prev)
                    config.ENV.update(prev)
                st = config.set_llm(brain=b, worker=w)
                config.update_env_local({"DEMO_MODE": "1"}); config.ENV["DEMO_MODE"] = "1"
                st["demo"] = True
            else:
                pb = (config.ENV.get("DEMO_PREV_BRAIN") or "").strip()
                pw = (config.ENV.get("DEMO_PREV_WORKER") or "").strip()
                st = config.set_llm(brain=pb or None, worker=pw or None)
                config.update_env_local({"DEMO_MODE": "0"}); config.ENV["DEMO_MODE"] = "0"
                st["demo"] = False
            try:
                capabilities.invalidate()
            except Exception:
                pass
            st["suggestions"] = config.MODEL_SUGGESTIONS
            return self._send(200, st)

        if path == "/api/setup":
            # Майстер налаштування: зберегти ключі (локально в .env.local) і перевірити звʼязок.
            data = self._read_json()
            st = config.set_keys({
                "openai": data.get("openai"),
                "anthropic": data.get("anthropic"),
                "gemini": data.get("gemini"),
            })
            ping_ok, ping_msg = (False, "немає ключа")
            if st.get("ready"):
                try:
                    ping_ok, ping_msg = llm.ping()
                except Exception as e:
                    ping_ok, ping_msg = False, str(e)
            st["ping"] = {"ok": ping_ok, "message": ping_msg}
            st["keys"] = config.keys_status()
            return self._send(200, st)

        if path == "/api/setup/local":
            # Локальна / on-prem модель: зберегти base_url+модель і зробити активною,
            # потім перевірити зв'язок із локальним сервером (Ollama/vLLM/LM Studio).
            data = self._read_json()
            st = config.set_local(
                base_url=(data.get("base_url") or "").strip() or None,
                model=(data.get("model") or "").strip() or None,
                worker=(data.get("worker") or "").strip() or None,
            )
            try:
                capabilities.invalidate()
            except Exception:
                pass
            ping_ok, ping_msg = (False, "не задано base_url/модель")
            if st.get("local") and config.LOCAL_MODEL:
                try:
                    ping_ok, ping_msg = llm.ping()
                except Exception as e:
                    ping_ok, ping_msg = False, str(e)
            st["ping"] = {"ok": ping_ok, "message": ping_msg}
            st["keys"] = config.keys_status()
            return self._send(200, st)

        if path == "/api/llm/stealth":
            # Режим Стелс: повна локальна ізоляція. on=true вмикає локальну модель
            # (за потреби з переданими base_url+model), on=false повертає хмару.
            data = self._read_json()
            st = config.set_stealth(
                bool(data.get("on")),
                base_url=(data.get("base_url") or "").strip() or None,
                model=(data.get("model") or "").strip() or None,
                worker=(data.get("worker") or "").strip() or None,
            )
            try:
                capabilities.invalidate()
            except Exception:
                pass
            ping_ok, ping_msg = (True, "")
            if st.get("stealth"):
                try:
                    ping_ok, ping_msg = llm.ping()
                except Exception as e:
                    ping_ok, ping_msg = False, str(e)
            st["ping"] = {"ok": ping_ok, "message": ping_msg}
            st["suggestions"] = config.MODEL_SUGGESTIONS
            return self._send(200, st)

        if path == "/api/cancel":
            import runstate
            data = self._read_json()
            ok = runstate.request_cancel(data.get("cancel_token") or "")
            return self._send(200, {"ok": ok})

        if path == "/api/license":
            import license as licensing
            data = self._read_json()
            config.set_license(data.get("key") or "")
            st = licensing.status()
            st["entitlement"] = licensing.entitlement()
            return self._send(200, st)

        if path == "/api/license/generate":
            if not config.LICENSE_ADMIN:
                return self._send(403, {"error": "admin_disabled",
                                        "message": "Генерація вимкнена. Увімкніть LICENSE_ADMIN=1 у .env.local."})
            import license as licensing
            data = self._read_json()
            try:
                days = int(data.get("days") or 365)
            except Exception:
                days = 365
            key = licensing.generate((data.get("customer") or "").strip(),
                                     (data.get("edition") or "pilot").strip(), days)
            return self._send(200, {"key": key, "info": licensing.parse(key)})

        if path == "/api/telegram/token":
            import telegram_bot
            data = self._read_json()
            return self._send(200, telegram_bot.set_token(data.get("token") or ""))

        if path == "/api/telegram/tasks_token":
            import telegram_bot
            data = self._read_json()
            return self._send(200, telegram_bot.set_tasks_token(data.get("token") or ""))

        if path == "/api/telegram/support_mode":
            import config as _cfg
            data = self._read_json()
            return self._send(200, _cfg.set_support_mode(bool(data.get("on"))))

        if path == "/api/update/apply":
            import update as _upd
            data = self._read_json()
            ids = data.get("ids")
            return self._send(200, _upd.apply_updates(ids=ids or None))

        if path in ("/api/telegram/allow", "/api/telegram/revoke", "/api/telegram/dismiss"):
            import telegram_access
            data = self._read_json()
            cid = data.get("id")
            try:
                cid = int(cid)
            except Exception:
                return self._send(400, {"error": "bad_chat_id"})
            if path.endswith("/allow"):
                snap = telegram_access.allow(cid, (data.get("label") or "").strip())
            elif path.endswith("/revoke"):
                snap = telegram_access.revoke(cid)
            else:
                snap = telegram_access.dismiss_pending(cid)
            return self._send(200, snap)

        if path == "/api/threads/new":
            return self._send(200, threads.create())

        if path == "/api/threads/delete":
            data = self._read_json()
            return self._send(200, {"ok": threads.delete(data.get("id"))})

        if path == "/api/projects/new":
            data = self._read_json()
            return self._send(200, projects.create(data.get("name")))

        if path == "/api/projects/update":
            data = self._read_json()
            rec = projects.update(data.get("id"), name=data.get("name"),
                                  context=data.get("context"))
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/projects/delete":
            data = self._read_json()
            return self._send(200, {"ok": projects.delete(data.get("id"))})

        if path == "/api/projects/add-thread":
            data = self._read_json()
            rec = projects.add_thread(data.get("id"), data.get("thread_id"))
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/projects/remove-thread":
            data = self._read_json()
            rec = projects.remove_thread(data.get("id"), data.get("thread_id"))
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/support/log":
            import support
            data = self._read_json()
            e = support.log(data.get("hours"), data.get("note", ""))
            return self._send(200, {"ok": bool(e), "entry": e, "summary": support.summary()})

        if path == "/api/crm/inbound":
            # Зовнішній інбаунд-сигнал (ранкова автоперевірка пошти). Зіставляє
            # відправника з карткою й піднімає «увагу»; для нового ліда створює картку.
            import inbound
            data = self._read_json()
            channel = (data.get("channel") or "email").strip()
            if channel == "telegram":
                res = inbound.from_telegram(data.get("chat_id"),
                                            username=data.get("username", ""),
                                            name=data.get("name", ""),
                                            text=data.get("preview", ""))
            else:
                email = (data.get("email") or "").strip()
                if not email:
                    return self._send(400, {"error": "no_email"})
                res = inbound.from_email(email, name=data.get("name", ""),
                                         subject=data.get("subject", ""),
                                         preview=data.get("preview", ""),
                                         org=data.get("org", ""),
                                         create_if_missing=bool(data.get("create_if_missing", True)))
            import crm
            return self._send(200, {"ok": True, "result": res, "counts": crm.counts()})

        if path == "/api/crm/inbox_clear":
            import crm
            data = self._read_json()
            ok = crm.clear_inbox((data.get("channel") or "").strip(),
                                 (data.get("identity") or "").strip())
            return self._send(200, {"ok": bool(ok), "inbox": crm.inbox()})

        if path in ("/api/crm/note", "/api/crm/archive", "/api/crm/unarchive", "/api/crm/history",
                    "/api/crm/stage", "/api/crm/attention",
                    "/api/crm/profile", "/api/crm/contact", "/api/crm/contact_remove",
                    "/api/crm/next_action", "/api/crm/deal", "/api/crm/comm", "/api/crm/dossier",
                    "/api/crm/action_done", "/api/crm/systems"):
            import crm
            data = self._read_json()
            cust = (data.get("customer") or "").strip()
            if not cust:
                return self._send(400, {"error": "no_customer"})
            if path.endswith("/note"):
                crm.set_notes(cust, data.get("notes", ""))
            elif path.endswith("/archive"):
                crm.set_archived(cust, True)
            elif path.endswith("/unarchive"):
                crm.set_archived(cust, False)
            elif path.endswith("/stage"):
                if not crm.set_stage(cust, data.get("stage", "")):
                    return self._send(400, {"error": "bad_stage"})
            elif path.endswith("/attention"):
                crm.set_attention(cust, value=data.get("value"), inc=int(data.get("inc") or 0))
            elif path.endswith("/profile"):
                crm.set_profile(cust, data.get("profile") or {})
                if "name_en" in data:
                    crm.ensure_client(cust, name_en=(data.get("name_en") or "").strip())
            elif path.endswith("/contact_remove"):
                crm.remove_contact(cust, data.get("index"))
            elif path.endswith("/contact"):
                crm.add_contact(cust, data.get("contact") or {})
            elif path.endswith("/next_action"):
                crm.set_next_action(cust, data.get("text", ""), data.get("date", ""))
            elif path.endswith("/deal"):
                crm.set_deal(cust, data.get("deal") or {})
            elif path.endswith("/comm"):
                ch = (data.get("channel") or "note").strip()
                crm.add_history(cust, ch, data.get("note", ""))
            elif path.endswith("/systems"):
                # ⭐⭐⭐ ЕТАП 4. Набір судить ОДИН суддя — той самий, що й збірка.
                # Помилку показуємо людині ТУТ, а не в мовчазній збірці потім.
                _raw = data.get("systems")
                if _raw is not None:
                    import make_client_build as _mcb
                    try:
                        _mcb.client_systems(cust, card={"systems": _raw})
                    except _mcb.EntitlementError as _e:
                        return self._send(400, {"error": "bad_systems", "message": str(_e)})
                crm.set_systems(cust, _raw)
            elif path.endswith("/dossier"):
                crm.set_dossier(cust, data.get("text", ""))
            elif path.endswith("/action_done"):
                crm.mark_action_done(cust)
            else:
                crm.add_history(cust, (data.get("type") or "note"), data.get("note", ""))
            return self._send(200, {"ok": True, "card": crm.card_public(cust),
                                    "counts": crm.counts()})

        return self._send(404, {"error": "not_found", "path": path})

    # ---- статика ----------------------------------------------------------
    def _localized_html(self, page):
        """Читає HTML-сторінку UI й підставляє дефолтну мову зі збірки.
        Вибір користувача в localStorage має пріоритет (логіка в ui/i18n.js).
        Спільний шлях для index/setup/telegram → один шов на всі сторінки."""
        lang = (getattr(config, "UI_DEFAULT_LANG", "uk") or "uk").lower()
        if lang not in ("uk", "ru", "en"):
            lang = "uk"
        html = page.read_text(encoding="utf-8").replace("__UI_DEFAULT_LANG__", lang)
        return html.encode("utf-8")

    def _serve_ui(self):
        index = config.UI_DIR / "index.html"
        if not index.exists():
            return self._send(500, {"error": "ui_missing"})
        return self._send(200, self._localized_html(index),
                          content_type="text/html; charset=utf-8")

    def _serve_artifact(self, path):
        parts = path.split("/")
        # /artifacts/<run_id>/<filename>
        if len(parts) < 4:
            return self._send(404, {"error": "bad_artifact_path"})
        run_id, filename = parts[2], "/".join(parts[3:])
        fpath = store.artifact_path(run_id, filename)
        if not fpath.exists():
            return self._send(404, {"error": "artifact_not_found"})
        data = fpath.read_bytes()
        ctypes = {
            ".md": "text/markdown; charset=utf-8",
            ".html": "text/html; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".csv": "text/csv; charset=utf-8",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        }
        ext = "." + filename.rsplit(".", 1)[-1] if "." in filename else ""
        return self._send(200, data, content_type=ctypes.get(ext, "application/octet-stream"))


def _scheduler_loop():
    # Фоновий потік: перевіряє автоматизації, що настали.
    while True:
        try:
            executed = scheduler.run_due(engine.automation_runner)
            for e in executed:
                print(f"[auto] виконано: {e['name']} -> {e['entry'].get('status')}")
        except Exception as ex:
            sys.stderr.write(f"[auto] помилка планувальника: {ex}\n")
        time.sleep(60)


def main():
    # ⭐ 29.07.2026. Консоль продукту існувала ЛИШЕ на екрані: коли в клієнта
    # щось падало, від збою не лишалось нічого, крім слів. Тепер той самий
    # вивід іде і у файл logs\\server_*.log — його бере звіт підтримки
    # (support_report). Один прийом, що вже працює в наших пробах.
    try:
        import run_log
        run_log.start("server")
        run_log.prune("server", 20)
    except Exception as ex:
        sys.stderr.write("[log] журнал сервера не увімкнувся: %s\n" % ex)
    # ⭐ 30.07.2026. Клієнт міг відредагувати .env.local руками або отримати
    # збірку із запіненою моделлю чужого провайдера — тоді продукт казав
    # «немає API-ключа», хоча ключі є. Канал «правка файлу» повз set_keys не
    # проходить, тому звіряємо досяжність ролей ще й на старті — і НАЗИВАЄМО
    # зміну в журналі, а не підмінюємо вибір клієнта мовчки.
    try:
        _rt = config.ensure_reachable_models()
        if _rt.get("changed"):
            for _role in ("brain", "worker"):
                _r = _rt.get(_role)
                if _r:
                    print("[llm] %s: модель %s недосяжна (немає ключа) -> %s (%s)"
                          % (_role, _r["was"], _r["now"], _r["provider"]))
    except Exception as _ex:
        sys.stderr.write("[llm] звірка досяжності моделей не виконалась: %s\n" % _ex)
    brain = config.provider_status()
    print("=" * 64)
    print(" AI Orchestrator Platform — Python engine")
    print("=" * 64)
    print(f" Робочий простір : {config.WORKSPACE_ROOT}")
    print(f" Реєстр систем   : {config.REGISTRY_JSON}")
    print(f" Провайдер       : {brain['provider']} [{'готовий' if brain['ready'] else 'НЕМАЄ КЛЮЧА'}]")
    print(f" Мозок (думання) : {brain.get('brain_model')}")
    print(f" Виконавець      : {brain.get('worker_model')}")
    if brain["ready"]:
        ok, msg = llm.ping()
        print(f" Перевірка мозку : {'✓ OK' if ok else '✗ ПОМИЛКА'} — {msg}")
    if not brain["ready"]:
        print("  УВАГА: додайте OPENAI_API_KEY або ANTHROPIC_API_KEY у orchestrator_py/.env.local")
    print(f" Консоль         : http://127.0.0.1:{config.PORT}")
    try:
        import keepawake
        if keepawake.start():
            print(" Енергозбереження : сон ПК вимкнено, поки працює застосунок")
    except Exception:
        pass
    caps = artifacts.capabilities()
    fmts = "md, html" + (", docx" if caps["docx"] else "") + (", xlsx" if caps["xlsx"] else "") + (", pptx" if caps.get("pptx") else "")
    missing = ([] + (["python-docx"] if not caps["docx"] else []) + (["openpyxl"] if not caps["xlsx"] else []) + (["python-pptx"] if not caps.get("pptx") else []))
    print(f" Артефакти       : {fmts}"
          + (f"   [для повного набору: pip install {' '.join(missing)}]" if missing else "   (повний набір доступний)"))
    print(f" Планувальник    : активний (фонова перевірка щохвилини)")
    # Виявлення ресурсів: знайти нові системи у проєктах і додати в оркестр
    try:
        disc = discovery.sync(register=True)
        if disc.get("added"):
            print(f" Виявлено нових систем: {len(disc['added'])} -> {', '.join(disc['added'])}")
        if disc.get("missing"):
            print(f" Позначено зниклими: {', '.join(disc['missing'])}")
        if disc.get("healed"):
            print(f" Відновлено статус із папки: {', '.join(disc['healed'])}")
        print(f" Систем в оркестрі: {len(registry.load_systems())}")
    except Exception as ex:
        sys.stderr.write(f"[discovery] помилка: {ex}\n")
    print("=" * 64)

    url = f"http://127.0.0.1:{config.PORT}"
    threading.Thread(target=_scheduler_loop, daemon=True).start()
    # Telegram-вхід (опційно): активується, якщо в .env.local є TELEGRAM_BOT_TOKEN
    try:
        import telegram_bot
        if telegram_bot.start_in_background():
            print(" Telegram-бот     : активний (long-polling)")
            print(f" Доступ до бота    : керування на http://127.0.0.1:{config.PORT}/telegram")
        else:
            print(" Telegram-бот     : вимкнено (немає TELEGRAM_BOT_TOKEN у .env.local)")
    except Exception as ex:
        sys.stderr.write(f"[telegram] не вдалося запустити: {ex}\n")
    # РОТ TASK DESK: доставка подій нерва в телеграм. Окремий потік, окремий
    # курсор. Немає бота задач — рота просто немає, і це нормальний стан
    # (закритий контур): нерв від цього не страждає.
    try:
        import taskdesk_telegram as _mouth
        if _mouth.start_in_background():
            print(" Задачі в телеграм : доставка активна")
        else:
            print(" Задачі в телеграм : вимкнено (немає TELEGRAM_TASKS_BOT_TOKEN)")
    except Exception as ex:
        sys.stderr.write(f"[рот] не вдалося запустити доставку: {ex}\n")
    # Зайнятий порт = SensFlow уже працює (часта ситуація: лишилось кілька відкритих
    # вікон). НЕ падаємо з трасою OSError[Errno 48] — просто відкриваємо вже запущену
    # консоль і виходимо чисто. Це прибирає цілий клас «не запускается» у клієнтів.
    try:
        httpd = ThreadingHTTPServer(("127.0.0.1", config.PORT), Handler)
    except OSError as ex:
        import errno
        if ex.errno in (errno.EADDRINUSE, 48, 98, 10048):
            print("=" * 64)
            print(f" SensFlow вже запущено на {url} — відкриваю наявну консоль.")
            print(" Це друге вікно можна закрити. Якщо консоль відкрилась не та —")
            print(" закрийте ВСІ вікна SensFlow і запустіть лише один раз.")
            print("=" * 64)
            try:
                webbrowser.open(url)
            except Exception:
                pass
            return
        raise
    try:
        # Автоматично відкрити консоль у браузері (можна вимкнути: AUTO_OPEN_BROWSER=0)
        if (config.ENV.get("AUTO_OPEN_BROWSER", "1") or "1") != "0":
            threading.Timer(1.2, lambda: webbrowser.open(url)).start()
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nЗупинено.")
        httpd.server_close()


if __name__ == "__main__":
    main()
