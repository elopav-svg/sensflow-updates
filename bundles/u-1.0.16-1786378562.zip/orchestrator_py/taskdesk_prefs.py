# -*- coding: utf-8 -*-
"""
taskdesk_prefs.py — ЩО САМЕ ЦЯ ЛЮДИНА НАЛАШТУВАЛА СОБІ НА ЕКРАНІ ЗАДАЧ.

Реєстр полів (`taskdesk_fields`) каже, ЩО буває. Цей файл — єдиний писар того,
ЩО ОБРАЛА КОНКРЕТНА ЛЮДИНА: набір колонок списку, живий фільтр і збережені під
назвою набори вибірки («Прострочені по відділу продажів»).

Уклад той самий, що в решті Task Desk: ОДИН НОРМАЛІЗАТОР · ОДИН ЧИТАЧ · ОДИН
ПИСАР. Один файл на людину: `taskdesk/prefs/<id працівника>.json`.

⭐ ЧОМУ НАЛАШТУВАННЯ — НЕ ЧАСТИНА ЗАДАЧІ. Колонки й фільтр належать людині, а не
задачі. Якби вони лежали поруч із задачами, ми б мали спільний стан там, де його
не повинно бути: двоє людей на одній машині перетирали б вигляд одне одному.

⭐ ЧОМУ ЗБЕРЕЖЕНИЙ НАБІР ЗБЕРІГАЄ ЛИШЕ ФІЛЬТР, А НЕ СПИСОК ЗАДАЧ. Набір — це
ПИТАННЯ, а не відповідь. Список задач у ньому застарів би тієї ж хвилини;
питання ж лишається правдивим завжди і щоразу дає свіжу відповідь.

⚠ Мозок (LLM) сюди не ходить.
"""

import json
import re

import clock
import config
import taskdesk_fields as fields
import taskdesk_tasks as tasks

PREFS_DIR = config.STATE_DIR / "taskdesk" / "prefs"
# ⭐ Вигляд списку КОМПАНІЇ лежить ОКРЕМО від особистих, а не файлом «_company»
# серед них: інакше працівник з таким номером мовчки перетер би спільне.
COMPANY_FILE = config.STATE_DIR / "taskdesk" / "prefs_company.json"

VIEWS_MAX = 40
NAME_MAX = 60


class PrefsError(Exception):
    """Відмова з причиною словами."""


def _s(v) -> str:
    return str(v or "").strip()


def _safe_name(emp_id: str) -> str:
    emp_id = _s(emp_id)
    if not emp_id or not re.match(r"^[A-Za-z0-9_-]{1,64}$", emp_id):
        raise PrefsError("Не видно, чиї це налаштування.")
    return emp_id


def _path(emp_id: str):
    return PREFS_DIR / ("%s.json" % _safe_name(emp_id))


# ---------------------------------------------------------------------------
# ОДИН НОРМАЛІЗАТОР — сюди сходяться і свіжий файл, і старий, і зіпсований.
# ---------------------------------------------------------------------------
def _normalize(raw, company=None) -> dict:
    """⭐⭐⭐ ДВА ШАРИ, І ОСОБИСТИЙ ЗАВЖДИ СИЛЬНІШИЙ.
    Компанійський вигляд — це ТИПОВЕ, а не примус: він діє рівно доти, доки
    людина не обрала СВОЄ. Налаштування, яке можна ввімкнути, але не можна
    вимкнути, стоїть у нас у переліку того, що вбиває продукт.

    Щоб «людина нічого не обирала» відрізнялось від «обрала таке саме», у
    ФАЙЛІ ЛЮДИНИ ключа просто немає, доки вона його не задала (див. `_save`)."""
    raw = raw if isinstance(raw, dict) else {}
    base = company if isinstance(company, dict) else {}
    own_cols = bool(raw.get("columns"))
    own_sort = isinstance(raw.get("sort"), dict)
    out = {
        "columns": fields.normalize_columns(
            raw.get("columns") if own_cols else base.get("columns")),
        "columns_own": own_cols,
        "filter": _clean_filter(raw.get("filter")),
        "view_id": _s(raw.get("view_id")),
        "sort": _clean_sort(raw.get("sort") if own_sort else base.get("sort")),
        "sort_own": own_sort,
        "default_view_id": _s(raw.get("default_view_id")),
        "views": [],
        "updated_at": _s(raw.get("updated_at")),
    }
    seen = set()
    for v in (raw.get("views") or [])[:VIEWS_MAX]:
        if not isinstance(v, dict):
            continue
        vid, name = _s(v.get("id")), _s(v.get("name"))[:NAME_MAX]
        if not vid or not name or vid in seen:
            continue
        seen.add(vid)
        out["views"].append({"id": vid, "name": name,
                             "filter": _clean_filter(v.get("filter")),
                             "columns": fields.normalize_columns(v.get("columns"))})
    if out["view_id"] not in seen:
        out["view_id"] = ""
    if out["default_view_id"] not in seen:
        out["default_view_id"] = ""
    return out


def _clean_sort(srt) -> dict:
    """Поле, якого більше немає, тихо перестає бути порядком — це чистка
    ЗБЕРЕЖЕНОГО, а не свіжого прохання людини."""
    srt = srt if isinstance(srt, dict) else {}
    fid = _s(srt.get("field"))
    if fid not in fields.BY_ID:
        return {"field": "", "desc": False}
    return {"field": fid, "desc": bool(srt.get("desc"))}


def _clean_filter(flt) -> dict:
    """Викидаємо поля, яких більше немає в реєстрі (могли зникнути з оновленням),
    і ті, за якими фільтрувати не можна. Це не «тиха відмова»: тут ми чистимо
    ЗБЕРЕЖЕНЕ РАНІШЕ, а не виконуємо свіже прохання людини — свіже прохання
    з невідомим полем зупиняє `taskdesk_fields.apply_filter` словами."""
    if not isinstance(flt, dict):
        return {}
    out = {}
    for fid, cond in flt.items():
        f = fields.BY_ID.get(_s(fid))
        if f is None or f["filter"] == "none":
            continue
        if cond in (None, "", [], {}):
            continue
        out[f["id"]] = cond
    return out


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ
# ---------------------------------------------------------------------------
def company() -> dict:
    """Типовий вигляд списку для всієї компанії. Немає файла — немає й шару."""
    if not COMPANY_FILE.exists():
        return {}
    try:
        raw = json.loads(COMPANY_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}
    if not isinstance(raw, dict):
        return {}
    out = {}
    if raw.get("columns"):
        out["columns"] = fields.normalize_columns(raw.get("columns"))
    if isinstance(raw.get("sort"), dict):
        out["sort"] = _clean_sort(raw.get("sort"))
    out["updated_at"] = _s(raw.get("updated_at"))
    out["by"] = _s(raw.get("by"))
    return out


def load(emp_id: str) -> dict:
    p = _path(emp_id)
    co = company()
    if not p.exists():
        return _normalize({}, co)
    try:
        return _normalize(json.loads(p.read_text(encoding="utf-8")), co)
    except Exception:
        # Зіпсований файл налаштувань не має ламати екран задач: людина
        # побачить типовий вигляд, а не пʼятисотку.
        return _normalize({}, co)


# ---------------------------------------------------------------------------
# ОДИН ПИСАР
# ---------------------------------------------------------------------------
def _save(emp_id: str, state: dict) -> dict:
    """⭐ У ФАЙЛ ЛЮДИНИ ПИШЕМО ЛИШЕ ТЕ, ЩО ВОНА СПРАВДІ ЗАДАЛА. Якби ми щоразу
    писали ВЕСЬ стан, перше ж збереження колонок зробило б людину «власником» і
    порядку теж — і компанійський вигляд тихо перестав би на неї діяти."""
    PREFS_DIR.mkdir(parents=True, exist_ok=True)
    co = company()
    state = _normalize(state, co)
    state["updated_at"] = clock.now()
    on_disk = dict(state)
    if not state.get("columns_own"):
        on_disk.pop("columns", None)
    if not state.get("sort_own"):
        on_disk.pop("sort", None)
    on_disk.pop("columns_own", None)
    on_disk.pop("sort_own", None)
    _path(emp_id).write_text(json.dumps(on_disk, ensure_ascii=False, indent=2),
                             encoding="utf-8")
    return state


def set_columns(emp_id: str, columns) -> dict:
    st = load(emp_id)
    asked = [c for c in (columns or []) if _s(c)]
    for c in asked:
        fields.field(c)                     # невідома колонка = відмова словами
    if not asked:
        raise PrefsError("У списку має лишитись хоча б одна колонка.")
    st["columns"] = fields.normalize_columns(asked)
    return _save(emp_id, st)


def set_filter(emp_id: str, flt, view_id: str = "") -> dict:
    st = load(emp_id)
    st["filter"] = _clean_filter(flt)
    st["view_id"] = _s(view_id)
    return _save(emp_id, st)


def save_view(emp_id: str, name: str, flt, columns=None, view_id: str = "") -> dict:
    """Зберегти поточну вибірку під назвою. Та сама назва = переписуємо той набір,
    а не плодимо близнюків."""
    name = _s(name)[:NAME_MAX]
    if not name:
        raise PrefsError("Наберіть назву набору — без неї його не знайти.")
    st = load(emp_id)
    cols = fields.normalize_columns(columns or st["columns"])
    flt = _clean_filter(flt)
    target = None
    for v in st["views"]:
        if (view_id and v["id"] == view_id) or v["name"].lower() == name.lower():
            target = v
            break
    if target is None:
        if len(st["views"]) >= VIEWS_MAX:
            raise PrefsError("Збережених наборів уже %d — більше не вміщається. "
                             "Видаліть непотрібний." % VIEWS_MAX)
        target = {"id": "V-%s" % clock.now().replace("-", "").replace(":", "")[:15]}
        st["views"].append(target)
    target["name"], target["filter"], target["columns"] = name, flt, cols
    st["filter"], st["view_id"] = flt, target["id"]
    return _save(emp_id, st)


def delete_view(emp_id: str, view_id: str) -> dict:
    view_id = _s(view_id)
    st = load(emp_id)
    left = [v for v in st["views"] if v["id"] != view_id]
    if len(left) == len(st["views"]):
        raise PrefsError("Такого збереженого набору немає.")
    st["views"] = left
    if st["view_id"] == view_id:
        st["view_id"] = ""
    return _save(emp_id, st)


def use_view(emp_id: str, view_id: str) -> dict:
    """Перемкнутись на збережений набір: він приносить і фільтр, і свої колонки."""
    view_id = _s(view_id)
    st = load(emp_id)
    if not view_id:
        st["view_id"], st["filter"] = "", {}
        return _save(emp_id, st)
    for v in st["views"]:
        if v["id"] == view_id:
            st["view_id"], st["filter"], st["columns"] = v["id"], dict(v["filter"]), list(v["columns"])
            return _save(emp_id, st)
    raise PrefsError("Такого збереженого набору немає.")


# ---------------------------------------------------------------------------
# ⭐ ГОТОВІ НАБОРИ — відповідь на «незручно».
#
# Раніше над дошкою стояли чотири взаємовиключні зрізи: «Усі · Мої · Я поставив
# · Протерміновані». Одне значення на всіх, тому НАЙЧАСТІШЕ ПИТАННЯ КЕРІВНИКА ДО
# СЕБЕ ЩОРАНКУ — «мої протерміновані» — однією кнопкою було НЕМОЖЛИВЕ: треба було
# обрати зріз, розкрити панель і заповнити ще одне поле.
#
# ⭐⭐⭐ ЛІКУЄМО НЕ КНОПКУ, А КЛАС: готовий набір — це ЗВИЧАЙНИЙ ФІЛЬТР, а фільтри
# СКЛАДАЮТЬСЯ. Тому «мої» + «протерміновані» — це один набір умов, а не два
# зрізи, які борються за одне значення.
#
# ⭐⭐ І ЧОМУ ВОНИ ТУТ, А НЕ НА СТОРІНЦІ. Готовий набір і збережений набір — те
# саме поняття: ПИТАННЯ, а не відповідь. Один писар наборів — цей файл; сторінка
# лише малює те, що він дав. Інакше екран знав би імена полів від себе.
# ---------------------------------------------------------------------------
PRESETS = (
    ("mine", "Мої", lambda me: {"assignee": [me]}),
    ("mine_late", "Мої протерміновані", lambda me: {"assignee": [me], "overdue": True}),
    ("i_set", "Я поставив", lambda me: {"author": [me]}),
    ("review", "На перевірці", lambda me: {"stage": [tasks.STAGE_REVIEW]}),
)


def presets(emp_id: str) -> list:
    """Готові набори для ЦІЄЇ людини. Проходять ту саму чистку, що й збережені:
    якби набір посилався на поле, якого немає в реєстрі, він мовчки перетворився б
    на «показати все» — і людина читала б повний список як відфільтрований."""
    me = _safe_name(emp_id)
    out = []
    for pid, name, make in PRESETS:
        flt = _clean_filter(make(me))
        out.append({"id": pid, "name": name, "filter": flt})
    return out


def set_sort(emp_id: str, fid: str, desc: bool) -> dict:
    """Порядок списку належить ЛЮДИНІ, як і колонки: двоє на одній машині не
    мають перетирати вигляд одне одному."""
    st = load(emp_id)
    fid = _s(fid)
    if fid:
        fields.field(fid)                    # невідоме поле = відмова словами
    st["sort"] = {"field": fid, "desc": bool(desc)}
    return _save(emp_id, st)


def set_default_view(emp_id: str, view_id: str) -> dict:
    """Який набір відкривається ПРИ ВХОДІ. Порожньо = жодного, як було."""
    view_id = _s(view_id)
    st = load(emp_id)
    if view_id and not [v for v in st["views"] if v["id"] == view_id]:
        raise PrefsError("Такого збереженого набору немає.")
    st["default_view_id"] = view_id
    return _save(emp_id, st)


def apply_default(emp_id: str) -> dict:
    """⭐ Кличеться ЛИШЕ на вході на екран. Якби набір за замовчуванням ставився
    на кожен запит, людина не змогла б тимчасово подивитись інше — фільтр
    скидався б їй під руками."""
    st = load(emp_id)
    vid = st["default_view_id"]
    if not vid:
        return st
    return use_view(emp_id, vid)


def reset_view(emp_id: str) -> dict:
    """Повернутись до типового вигляду компанії. Без цієї дії «встановити для
    всіх» став би налаштуванням, яке можна ввімкнути, але не можна вимкнути."""
    st = load(emp_id)
    st["columns_own"] = False
    st["sort_own"] = False
    st.pop("columns", None)
    st.pop("sort", None)
    return _save(emp_id, st)


def set_company(emp_id: str, columns=None, sort=None) -> dict:
    """⭐ ВИГЛЯД ДЛЯ ВСІХ. Пише той, кому це дозволили ВОРОТА в `taskdesk_api`, —
    сам файл прав не судить. Записуємо ІМʼЯ того, хто натиснув: доказ тримає не
    заборона, а слід."""
    cols = fields.normalize_columns(columns or load(emp_id)["columns"])
    srt = _clean_sort(sort if isinstance(sort, dict) else load(emp_id)["sort"])
    COMPANY_FILE.parent.mkdir(parents=True, exist_ok=True)
    COMPANY_FILE.write_text(json.dumps(
        {"columns": cols, "sort": srt, "by": _s(emp_id), "updated_at": clock.now()},
        ensure_ascii=False, indent=2), encoding="utf-8")
    return company()
