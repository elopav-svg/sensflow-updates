# -*- coding: utf-8 -*-
"""
client_export.py — ⭐⭐⭐ ЕКСПОРТ ДАНИХ КЛІЄНТА. Обіцяне бізнес-моделлю (07.08.2026).

ЩО ЦЕ І ЧОМУ САМЕ ТАК.
  Модель B (оренда): строк минув -> користування припиняється **і клієнт забирає
  свої дані**. Обіцянка, не покрита механізмом, — це борг [[promise_must_be_covered]],
  і найгірше в ньому те, що він настає рівно тоді, коли стосунки закінчуються.

  ⭐ ГОЛОВНЕ РІШЕННЯ: **ЕКСПОРТ НЕ ПИТАЄ ЛІЦЕНЗІЮ.** Взагалі. Це не милість
  платформи, а робота з файлами: людина забирає СВОЄ. Якби експорт стояв за тими
  самими ворітьми, що й робота, він відмовляв би саме в той день, заради якого
  існує. Тому тут немає жодного виклику `license`, і чек це стереже.

  ⭐ ДРУГЕ РІШЕННЯ: що саме є «даними клієнта», каже ОДИН ПИСАР — `state_files`.
  Він уже відповідає на дзеркальне питання («що НЕ везти клієнту й не затирати
  оновленням»). Заводити другий перелік означало б, що завтра нова тека стану
  зʼявиться в одному місці й не зʼявиться в іншому — і людина недоотримає своє.

ЩО ПОТРАПЛЯЄ В АРХІВ
  1. живий стан рушія: `runs`, `threads`, `projects`, `chains`, `automations`,
     `taskdesk`, `state`, `runs_paused` + іменовані файли стану;
  2. робота систем: `Input`, `Output`, `outputs` у кожній теці системи;
  3. накопичені знання систем: `Database`, `Knowledge`, `Memory`, `Wiki`;
  4. база клієнтів CRM, якщо людина нею користувалась.

ЩО НЕ ПОТРАПЛЯЄ
  Секрети (`.env`, `.env.local`) — ключ провайдера лишається лише на машині
  людини; кеш і `__pycache__`; наш код (це не її дані, і він у неї вже є).

Запуск: python client_export.py  (або «Export my data.bat»)
"""
import os
import sys
import zipfile
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent          # orchestrator_py
ROOT = HERE.parent                              # корінь продукту

sys.path.insert(0, str(HERE))
import state_files  # noqa: E402  (ОДИН писар про те, що є станом)

WORK_DIRS = ("Input", "Output", "outputs")
KNOWLEDGE_DIRS = ("Database", "Knowledge", "Memory", "Wiki")
SKIP_DIRS = {"__pycache__", ".git"}
SKIP_NAMES = set(state_files.SECRET_FILES)


def _iter_dir(base: Path):
    for f in base.rglob("*"):
        if not f.is_file():
            continue
        if any(p in SKIP_DIRS for p in f.parts):
            continue
        if f.name in SKIP_NAMES:
            continue
        yield f


def collect(root: Path = None) -> list:
    """Файли, які є ДАНИМИ КЛІЄНТА. Повертає список (шлях, імʼя в архіві)."""
    root = Path(root or ROOT)
    engine = root / "orchestrator_py"
    picked, seen = [], set()

    def add(f: Path):
        try:
            rel = f.relative_to(root).as_posix()
        except ValueError:
            return
        if rel in seen:
            return
        seen.add(rel)
        picked.append((f, rel))

    for d in state_files.STATE_DIRS:                 # 1. живий стан рушія
        p = engine / d
        if p.is_dir():
            for f in _iter_dir(p):
                add(f)
    for n in state_files.STATE_FILES:
        p = engine / n
        if p.is_file():
            add(p)

    gen = root / "generated_systems"                 # 2-3. робота і знання систем
    if gen.is_dir():
        for sysdir in sorted(p for p in gen.iterdir() if p.is_dir()):
            for sub in WORK_DIRS + KNOWLEDGE_DIRS:
                p = sysdir / sub
                if p.is_dir():
                    for f in _iter_dir(p):
                        add(f)

    crm = root / "crm" / "clients.json"              # 4. база клієнтів
    if crm.is_file():
        add(crm)
    return picked


def export(root: Path = None, out_path=None) -> dict:
    """Складає архів даних клієнта. НЕ питає ліцензію — і не сміє питати."""
    root = Path(root or ROOT)
    files = collect(root)
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M")
    out = Path(out_path) if out_path else (root / ("SensFlow_dani_%s.zip" % stamp))
    out.parent.mkdir(parents=True, exist_ok=True)
    total = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for f, rel in files:
            try:
                z.write(f, rel)
                total += f.stat().st_size
            except Exception as e:
                print("  [!] не вдалось покласти %s: %s" % (rel, e))
        z.writestr("ЯК_ЧИТАТИ_ЦЕЙ_АРХІВ.txt", _readme(len(files), total))
    return {"ok": True, "path": str(out), "files": len(files), "bytes": total}


def _readme(n, total) -> str:
    return (
        "ВАШІ ДАНІ З SENSFLOW\r\n"
        "====================\r\n\r\n"
        "Файлів: %d, обсяг: %.1f МБ.\r\n"
        "Дата вивантаження: %s\r\n\r\n"
        "Що всередині:\r\n"
        "  orchestrator_py/runs      - результати всіх прогонів (текст, .docx, .xlsx, .html)\r\n"
        "  orchestrator_py/threads   - листування з оркестратором\r\n"
        "  orchestrator_py/projects  - ваші робочі напрями\r\n"
        "  orchestrator_py/taskdesk  - підрозділи, люди, задачі\r\n"
        "  generated_systems/*/Output- те, що зробили системи\r\n"
        "  generated_systems/*/Input - те, що ви їм давали\r\n"
        "  crm/clients.json          - ваша база клієнтів\r\n\r\n"
        "Усі файли — у звичайних форматах і відкриваються без SensFlow.\r\n"
        "Ключів доступу до провайдерів в архіві НЕМАЄ: вони лишаються тільки на вашій машині.\r\n"
        % (n, total / 1048576.0, datetime.now().strftime("%d.%m.%Y %H:%M"))
    )


if __name__ == "__main__":
    print("=" * 60)
    print(" SensFlow - експорт ваших даних")
    print("=" * 60)
    res = export()
    print(" Готово: %s" % res["path"])
    print(" Файлів: %d, обсяг: %.1f МБ" % (res["files"], res["bytes"] / 1048576.0))
    print("=" * 60)
