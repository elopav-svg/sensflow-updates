# -*- coding: utf-8 -*-
"""
taskdesk_api.py — ТОНКИЙ ШАР МІЖ КОНСОЛЛЮ І ЯДРОМ TASK DESK (крок 1.4).

`server.py` лишається транспортом: він приймає запит, питає ворота «хто це» і
віддає сюди. Уся логіка дій живе тут, в ОДНІЙ таблиці дій. Так новий екран не
може винайти собі власний шлях повз перевірки — таблиця одна.

ТРИ ПЕРЕВІРКИ, ЯКІ ПРОХОДИТЬ КОЖНА ДІЯ:
  1. **вимикач роботи** — поки Task Desk не ввімкнений, тут не працює нічого;
  2. **адміністратор** — оргструктуру й доступи веде лише він;
  3. **дія з таблиці** — невідома назва дії не виконується, а називається.
Відмова завжди має причину словами: тиха відмова = вимкнені ворота.
"""

import features
import taskdesk_identity as identity
import taskdesk_ai as ai
import taskdesk_export as export
import taskdesk_fields as fields
import taskdesk_people as people
import taskdesk_prefs as prefs
import taskdesk_tasks as tasks
import taskdesk_telegram as mouth

WORK_ID = "taskdesk"


class ApiError(Exception):
    def __init__(self, message, status=400, code="taskdesk_error"):
        Exception.__init__(self, message)
        self.status = status
        self.code = code


def enabled() -> bool:
    """ЄДИНА відповідь «чи Task Desk увімкнений». Поки робота не завершена, вона
    їде клієнту вимкненою — це вимога воріт складу релізу."""
    return features.enabled(WORK_ID)


def _require_enabled():
    if not enabled():
        raise ApiError("Task Desk у цій збірці вимкнений.", 403, "taskdesk_off")


def _require_admin(actor):
    """Оргструктуру й доступи веде адміністратор.

    Поки вхід не вимагається (одноосібний клієнт, як Каспер сьогодні), господар
    машини і є адміністратор — так само, як у решті консолі. Щойно людей стає
    двоє, вхід обовʼязковий, і тут уже потрібен саме адміністратор."""
    if not identity.login_required():
        return
    if not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    if not actor.get("is_admin"):
        raise ApiError("Ці налаштування веде адміністратор.", 403, "admin_only")


# ---------------------------------------------------------------------------
# ЧИТАННЯ
# ---------------------------------------------------------------------------
def people_state(actor) -> dict:
    """⭐ РІШЕННЯ АНДРІЯ 08.08.2026: розділ «Люди» — це ДОВІДНИК компанії, а не
    панель адміністратора. Колега має знайти телефон колеги, не питаючи нікого.

    Тому дивляться ВСІ, а от ВЕДЕ структуру адміністратор. Різниця не в тому,
    що показати, а в тому, що можна: інструменти й службовий журнал змін їдуть
    лише адміністратору. Екран їх не ховає «про всяк випадок» — він їх просто
    не отримує, і намалювати кнопку, якої немає, не може."""
    _require_enabled()
    # ⭐ «Відкрито всім працівникам» не означає «відкрито нікому»: коли вхід
    # обовʼязковий, довідник компанії бачить лише впізнана людина.
    if identity.login_required() and not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    adm = _is_admin(actor)
    st = people.load()
    out = {"units": st["units"], "positions": st["positions"],
           "employees": st["employees"],
           "unreadable_reason": st.get("unreadable_reason", ""),
           # ⭐ Один писар «хто я тут» — екран не здогадується за виглядом даних.
           "rights": {"is_admin": adm, "me": _me(actor),
                      "may_manage": adm}}
    if adm:
        out["audit"] = st["audit"][-30:]
    return out


def employee_card(actor, emp_id: str) -> dict:
    """Картку ЧИТАЄ кожен працівник — це довідник компанії (рішення Андрія
    08.08.2026). А от ПРАВИТИ можна лише те, що дозволяє `people.card_rights()`:
    свої контакти — сама людина, місце в компанії — адміністратор."""
    _require_enabled()
    adm = _is_admin(actor)
    me = _me(actor)
    emp_id = str(emp_id or "").strip()
    card = people.card(emp_id)
    if not card:
        raise ApiError("Такого працівника немає.", 404, "not_found")
    # ⭐ Права їдуть РАЗОМ із карткою: екран малює лише те, що людині належить.
    # Кнопка, яка відмовить, бреше не менше за її відсутність.
    card["rights"] = people.card_rights(me, emp_id, adm)
    # ⭐ СТАН КАНАЛУ ЇДЕ РАЗОМ ІЗ КАРТКОЮ, як і права: екран не здогадується,
    # підключений телеграм чи ні, і не малює кнопку, за якою нічого немає.
    card["telegram"] = _telegram_state(emp_id)
    if adm:
        card["units"] = [{"id": u["id"], "name": u.get("name") or u["id"]}
                         for u in people.units()]
        card["positions"] = [{"id": p["id"], "name": p.get("name") or p["id"]}
                             for p in people.positions()]
    return card


def _acc_of(emp_id: str) -> dict:
    """Обліковий запис працівника. Немає запису — немає й каналу: бот упізнає
    людину лише через вхід у платформу."""
    acc = identity.account_of_employee(str(emp_id or "").strip())
    if acc is None:
        raise ApiError("У цього працівника немає облікового запису, тож "
                       "підключати телеграм нема до чого. Це заводить адміністратор "
                       "у розділі «Доступи».", 400, "no_account")
    return acc


def _telegram_state(emp_id: str) -> dict:
    """Чи є в людини канал і чи взагалі є куди підключатись.

    ⭐ `available` — це чесність екрана: якщо в клієнта не заведений бот задач
    (закритий контур або просто ще не завели), кнопки не буде взагалі, а не
    буде кнопки, яка відмовить."""
    import taskdesk_telegram as mouth
    out = {"available": mouth.enabled(), "bot": mouth.bot_username(),
           "linked": False, "code": "", "expires_at": "", "has_account": False}
    acc = identity.account_of_employee(str(emp_id or "").strip())
    if acc is None:
        return out
    out["has_account"] = True
    out.update(identity.telegram_state(acc["id"]))
    return out


def accounts_state(actor) -> dict:
    _require_enabled()
    _require_admin(actor)
    import registry
    try:
        systems = [{"id": s.get("id"), "name": s.get("name") or s.get("id")}
                   for s in (registry.load_systems() or [])]
    except Exception:
        systems = []
    return {"accounts": identity.accounts(),
            "employees": people.employees(),
            "systems": systems,
            "login_required": identity.login_required(),
            "light_mode": identity.light_mode()}


def photo_set(actor, emp_id: str, data_url: str) -> dict:
    """Фото приходить із браузера рядком «data:image/png;base64,...».
    Розбираємо його ТУТ, а ядро отримує вже байти — воно не мусить знати про веб."""
    _require_enabled()
    rights = people.card_rights(_me(actor), emp_id, _is_admin(actor))
    if not rights["photo"]:
        raise ApiError("Фото ставить сама людина або адміністратор.", 403, "not_allowed")
    raw_b64 = str(data_url or "")
    if "," in raw_b64:
        raw_b64 = raw_b64.split(",", 1)[1]
    import base64
    try:
        raw = base64.b64decode(raw_b64, validate=True)
    except Exception:
        raise ApiError("Файл не прочитався — спробуйте інший.", 400, "bad_photo")
    try:
        return {"ok": True, "result": people.set_photo(emp_id, raw)}
    except people.PeopleError as e:
        raise ApiError(str(e), 400, "refused")


def photo_get(actor, emp_id: str) -> tuple:
    _require_enabled()
    _require_admin(actor)
    raw, mime = people.photo_bytes(emp_id)
    if not raw:
        raise ApiError("Фото немає.", 404, "no_photo")
    return raw, mime


# ---------------------------------------------------------------------------
# ЗАДАЧІ. Тут інші ворота, ніж в оргструктурі: задачі веде НЕ адміністратор,
# а сам працівник. Тому питаємо не «чи ти адмін», а «хто ти» — і далі все
# вирішує ОДНА функція видимості з `taskdesk_tasks`.
# ---------------------------------------------------------------------------
def _is_admin(actor) -> bool:
    """⭐ ОДНА відповідь «чи ця людина адміністратор» — та сама умова, що й у
    `_require_admin`: поки вхід не вимагається, господар машини і є адміністратор.
    Друга відповідь у другому місці розійшлася б із першою."""
    return identity.is_admin(actor)


def _me(actor) -> str:
    """Хто дивиться. ОДНА відповідь; порожньо — коли людина не впізнана."""
    return str((actor or {}).get("employee_id") or "").strip()


def _require_actor(actor):
    if not actor or not actor.get("employee_id"):
        raise ApiError("Не видно, хто ви. Увійдіть під своїм працівником.",
                       401, "login_required")
    return actor["employee_id"]


SCOPE_NAMES = {"all": "усі видимі", "mine": "мої", "i_set": "я поставив",
               "overdue": "протерміновані"}


def _desk(actor, scope, show_closed, flt=None, use_saved=True, query=""):
    """ОДИН збирач того, що людина бачить на екрані задач. І список, і дошка, і
    вивантаження виходять ЗВІДСИ — тому файл не може розійтися з екраном."""
    me = _require_actor(actor)
    my = prefs.load(me)
    flt = my["filter"] if (flt is None and use_saved) else (flt or {})
    ctx = fields.context()
    try:
        # ⭐⭐⭐ ОДНІ ВОРОТА НА ОБИДВА ЗВУЖЕННЯ: спершу фільтр, потім пошук — і
        # обидва всередині ОДНОГО `narrow`. Тому перевірка `board()` «фільтр не
        # має права додавати задач» накриває й пошук: другого шляху до списку
        # немає фізично, а не за домовленістю.
        data = tasks.board(me, scope=scope, show_closed=show_closed,
                           narrow=lambda lst: fields.search_narrow(
                               fields.apply_filter(lst, flt, ctx), query, ctx))
    except fields.FieldError as e:
        raise ApiError(str(e), 400, "bad_filter")
    except tasks.TaskError as e:
        raise ApiError(str(e), 400, "refused")
    flat = [t for c in data["columns"] for t in c["tasks"]]
    # ⭐⭐⭐ ПОРЯДОК РАХУЄТЬСЯ ОДИН РАЗ І НА ВСЕ: список, дошка і xlsx не мають
    # права розійтися. Тому сортувальник кличеться РІВНО ТУТ, а колонки дошки
    # лише переставляються за вже порахованим порядком.
    srt = my.get("sort") or {}
    if srt.get("field"):
        try:
            flat = fields.sort_rows(flat, srt["field"], srt.get("desc"), ctx)
        except fields.FieldError as e:
            raise ApiError(str(e), 400, "bad_sort")
        order = {t["id"]: i for i, t in enumerate(flat)}
        for c in data["columns"]:
            c["tasks"].sort(key=lambda t: order[t["id"]])
    return me, my, ctx, flt, data, flat


def board_state(actor, scope: str = "all", show_closed: bool = False,
                flt=None, query: str = "", fresh: bool = False) -> dict:
    _require_enabled()
    # ⭐ Набір за замовчуванням ставиться ЛИШЕ на вході на екран (`fresh`),
    # а не на кожен запит: інакше він скидав би фільтр людині під руками
    # щоразу, коли вона щось шукає.
    if fresh:
        try:
            prefs.apply_default(_require_actor(actor))
        except prefs.PrefsError:
            pass
    me, my, ctx, flt, data, flat = _desk(actor, scope, show_closed, flt,
                                        query=query)
    cols = my["columns"]
    data["me"] = {"id": me, "name": people.employee(me).get("full_name", "")}
    data["people"] = [{"id": e["id"], "name": e.get("full_name", "")}
                      for e in people.employees()]
    # ⭐ Рядки списку рахує РЕЄСТР, а не сторінка: інакше екран став би другим
    # форматувальником і розійшовся б із файлом xlsx.
    data["fields"] = fields.catalogue()
    data["columns_all"] = [f["id"] for f in fields.FIELDS]
    data["columns_used"] = cols
    data["heads"] = [fields.field(c)["label"] for c in cols]
    data["rows"] = [{"id": t["id"], "overdue": bool(t["overdue"]),
                     "cells": fields.row(t, cols, ctx)} for t in flat]
    # ⭐ Кожна картка несе СВОЇ права — з тієї самої таблиці, що й картка задачі.
    # Без цього перетягування мишею вирішувало б саме, куди можна кинути, і
    # стало б другим писарем прав.
    adm = _is_admin(actor)
    for t in flat:
        t["may"] = tasks.rights(t, me, adm)
    data["filter"] = flt
    data["filter_options"] = fields.options(flat, ctx)
    data["views"] = [{"id": v["id"], "name": v["name"]} for v in my["views"]]
    data["view_id"] = my["view_id"]
    # ⭐ ПОШУК — ТРЕТЄ ПИТАННЯ ЕКРАНА, і він НЕ ЗБЕРІГАЄТЬСЯ в налаштуваннях:
    # «де та задача про оплату» — питання на півхвилини, а не вигляд списку.
    # Але екран мусить КАЗАТИ, що він звужений — тому запит йде назад.
    data["query"] = str(query or "")
    data["search_hint"] = fields.SEARCH_HINT
    # ⭐ Готові набори рахує ОДИН писар наборів, а не сторінка: інакше
    # екран знав би імена полів від себе й розійшовся б із реєстром.
    data["presets"] = prefs.presets(me)
    data["sort"] = my.get("sort") or {"field": "", "desc": False}
    data["default_view_id"] = my.get("default_view_id") or ""
    # ⭐ ВЛАДА НЕ СМІЄ БУТИ ТИХОЮ, а правда про вигляд — теж влада: екран каже,
    # чиї зараз колонки — свої чи компанійські, і хто задав компанійські.
    data["is_admin"] = adm
    data["view_own"] = bool(my.get("columns_own") or my.get("sort_own"))
    data["company"] = prefs.company()
    return data


def task_state(actor, tid: str) -> dict:
    _require_enabled()
    me = _require_actor(actor)
    if tid not in tasks.visible_ids(me):
        raise ApiError("Цієї задачі вам не видно.", 403, "not_visible")
    t = tasks.task(tid)
    names = {e["id"]: e.get("full_name", "") for e in people.employees(True)}
    t["my_role"] = tasks.role_of(t, me)
    # ⭐ Кнопки малюються з ЦЬОГО, а не з власних «якщо» на сторінці: інакше
    # екран став би другим писарем прав і розійшовся б із кодом дії.
    t["may"] = tasks.rights(t, me, _is_admin(actor))
    t["reach"] = mouth.reach(t, me)
    t["names"] = names
    t["me"] = {"id": me, "name": names.get(me, "")}
    t["people"] = [{"id": e["id"], "name": e.get("full_name", "")}
                   for e in people.employees()]
    return t


def _comment(me, d, adm: bool = False) -> dict:
    """Коментар зберігається ЗАВЖДИ. Мозок читає його ПІСЛЯ і лише пропонує.

    Якщо мозок не відповів — коментар від цього не пропадає, але й мовчати про
    це не можна: екран скаже вголос. Тиха невдача = вимкнені ворота."""
    tid = d.get("id") or ""
    t = tasks.comment(tid, me, d.get("text") or "", bool(d.get("as_result")), adm)
    if not ai.enabled() or not ai.might_hold_a_date(d.get("text") or ""):
        return t
    cid = ""
    for c in reversed(t.get("feed") or []):
        if c["kind"] == "comment":
            cid = c["id"]
            break
    found, note = ai.read_comment_soon(t.get("title", ""), d.get("text") or "")
    if note:
        t = dict(t)
        t["ai_note"] = note
        return t
    if not found:
        return t
    try:
        t = tasks.add_proposal(tid, found["kind"], found["date"], found.get("why", ""),
                               found.get("quote", ""), cid)
        t = dict(t)
        t["ai_note"] = "ok"
    except tasks.TaskError as e:
        t = dict(t)
        t["ai_note"] = str(e)
    return t


# ⭐ Третій аргумент `adm` — прапорець адміністратора. Він іде ЗВЕРХУ, з шару
# облікових записів, бо в самій задачі адміністратора може не бути взагалі.
TASK_ACTIONS = {
    "create": lambda me, d, adm: tasks.create(
        me, d.get("title") or "", d.get("assignee_id") or "", d.get("due_at") or "",
        d.get("description") or "", d.get("coassignee_ids") or [],
        d.get("watcher_ids") or [], d.get("checklist") or []),
    "comment": lambda me, d, adm: _comment(me, d, adm),
    "result": lambda me, d, adm: tasks.mark_result(d.get("id") or "", me,
                                                   d.get("comment_id") or "", adm),
    "stage": lambda me, d, adm: tasks.set_stage(d.get("id") or "", me,
                                                d.get("stage") or "", adm),
    "delegate": lambda me, d, adm: tasks.delegate(d.get("id") or "", me,
                                                  d.get("assignee_id") or "", adm),
    "refuse": lambda me, d, adm: tasks.refuse(d.get("id") or "", me,
                                              d.get("reason") or "", adm),
    "check": lambda me, d, adm: tasks.check_item(d.get("id") or "", me,
                                                 d.get("item_id") or "",
                                                 bool(d.get("done")), adm),
    "proposal": lambda me, d, adm: tasks.resolve_proposal(
        d.get("id") or "", me, d.get("proposal_id") or "",
        bool(d.get("accept")), adm),
    "update": lambda me, d, adm: tasks.update(d.get("id") or "", me, adm,
                                              **{k: v for k, v in d.items()
                                                 if k in ("title", "description", "due_at",
                                                          "coassignee_ids", "watcher_ids")}),
}


def run_task_action(actor, data: dict) -> dict:
    """ЄДИНИЙ вхід усіх дій над задачами — щоб новий екран не винайшов свій шлях
    повз перевірки. Невідома дія не виконується, а називається."""
    _require_enabled()
    me = _require_actor(actor)
    name = str((data or {}).get("action") or "").strip()
    fn = TASK_ACTIONS.get(name)
    if fn is None:
        raise ApiError("Невідома дія «%s». Відомі: %s"
                       % (name, ", ".join(sorted(TASK_ACTIONS))), 400, "unknown_action")
    try:
        res = fn(me, data or {}, _is_admin(actor))
    except tasks.TaskError as e:
        raise ApiError(str(e), 400, "refused")
    except people.PeopleError as e:
        raise ApiError(str(e), 400, "refused")
    out = {"ok": True, "result": res}
    # ⭐⭐⭐ ПРАВДА ПРО ТИШУ ЇДЕ З КОЖНОЮ ДІЄЮ, а не лише зі створенням: людина
    # має знати, хто про її крок дізнається, коли б вона його не зробила.
    # Порахувати це має ОДИН писар (`mouth.reach`), інакше екран створення й
    # картка задачі казали б різне.
    if isinstance(res, dict) and res.get("id") and res.get("stage"):
        try:
            out["reach"] = mouth.reach(res, me)
        except Exception as e:
            # Тиша про тишу — рівно те, що ми тут і лікуємо.
            out["reach"] = {"note": "Не вдалося порахувати, кому це піде: %s" % e}
    return out


# ---------------------------------------------------------------------------
# ДІЇ — ОДНА ТАБЛИЦЯ НА ВСЮ КОНСОЛЬ
# ---------------------------------------------------------------------------
def _d(data, *names):
    return [(data.get(n) or "") for n in names]


PEOPLE_ACTIONS = {
    "unit_add": lambda d: people.add_unit(*_d(d, "name", "parent_id", "head_employee_id")),
    "unit_parent": lambda d: people.set_unit_parent(*_d(d, "unit_id", "parent_id")),
    "unit_head": lambda d: people.set_unit_head(*_d(d, "unit_id", "head_employee_id")),
    "position_add": lambda d: people.add_position(d.get("name") or ""),
    "employee_add": lambda d: people.add_employee(
        d.get("full_name") or "", d.get("unit_id") or "", d.get("position_id") or "",
        d.get("email") or "", d.get("telegram_id") or "", d.get("birthday") or "",
        d.get("phone_mobile") or "", d.get("phone_work") or ""),
    "employee_update": lambda d: people.update_employee(
        d.get("id") or "", **{k: v for k, v in d.items()
                              if k in ("full_name", "unit_id", "position_id", "email",
                                       "telegram_id", "birthday", "phone_mobile",
                                       "phone_work")}),
    "employee_dismiss": lambda d: people.dismiss_employee(d.get("id") or "",
                                                          d.get("reason") or ""),
    "employee_restore": lambda d: people.restore_employee(d.get("id") or ""),
    # ⭐ КАНАЛ ПІДКЛЮЧАЄ САМА ЛЮДИНА. Номер чату не знає ні вона, ні
    # адміністратор — його знає лише телеграм. Тому екран видає РАЗОВИЙ КОД,
    # а звʼязує код із чатом бот.
    "telegram_code": lambda d: identity.link_code(_acc_of(d.get("id") or "")["id"]),
    "telegram_unlink": lambda d: identity.unlink_telegram(_acc_of(d.get("id") or "")["id"]),
}

ACCESS_ACTIONS = {
    "account_add": lambda d: identity.create_account(
        d.get("login") or "", d.get("password") or "", d.get("employee_id") or "",
        bool(d.get("is_admin"))),
    "password": lambda d: identity.set_password(d.get("id") or "", d.get("password") or ""),
    "active": lambda d: identity.set_active(d.get("id") or "", bool(d.get("active"))),
    "layers": lambda d: identity.set_layers(d.get("id") or "", d.get("layers") or []),
    "orchestrator": lambda d: identity.set_orchestrator_access(
        d.get("id") or "", d.get("mode") or "", d.get("systems") or []),
}


# ⭐ РЕЄСТР ТАБЛИЦЬ ДІЙ — одне місце, де перелічені ВСІ таблиці Task Desk.
# Нова таблиця, не вписана сюди, не має входу з сервера; чек 1.4 звіряє реєстр
# із тим, що насправді оголошено у файлі, — тому «таблиця повз реєстр» не живе.
# ---------------------------------------------------------------------------
# НАЛАШТУВАННЯ ЕКРАНА Й ВИВАНТАЖЕННЯ. Ворота тут ті самі, що в задачах: це веде
# САМА ЛЮДИНА, не адміністратор. Тому окремий вхід `run_prefs_action`, а не
# спільний із оргструктурою.
# ---------------------------------------------------------------------------
def _export(actor, d) -> dict:
    scope = str(d.get("scope") or "all")
    show_closed = bool(d.get("closed"))
    # ⭐ ЩО НА ЕКРАНІ, ТЕ Й У ФАЙЛІ: пошук йде в вивантаження тим самим
    # шляхом, що й у список. Інакше людина шукала б одне, а вивантажувала інше.
    query = str(d.get("q") or "")
    me, my, ctx, flt, data, flat = _desk(actor, scope, show_closed,
                                        d.get("filter"),
                                        use_saved=d.get("filter") is None,
                                        query=query)
    who = people.employee(me).get("full_name", "")
    try:
        res = export.build(flat, my["columns"], ctx, who_name=who, flt=flt,
                           scope_name=SCOPE_NAMES.get(scope, scope), query=query)
    except export.ExportError as e:
        raise ApiError(str(e), 400, "no_excel")
    if d.get("open", True):
        try:
            import support_report          # ОДИН писар «відкрити провідник»
            res["opened"] = support_report.open_folder(res["path"])
        except Exception:
            res["opened"] = False
    return res


PREFS_ACTIONS = {
    "columns": lambda me, d: prefs.set_columns(me, d.get("columns") or []),
    "filter": lambda me, d: prefs.set_filter(me, d.get("filter") or {},
                                             d.get("view_id") or ""),
    "view_save": lambda me, d: prefs.save_view(me, d.get("name") or "",
                                               d.get("filter") or {},
                                               d.get("columns"),
                                               d.get("view_id") or ""),
    "view_delete": lambda me, d: prefs.delete_view(me, d.get("view_id") or ""),
    "view_use": lambda me, d: prefs.use_view(me, d.get("view_id") or ""),
    "view_default": lambda me, d: prefs.set_default_view(me, d.get("view_id") or ""),
    "sort": lambda me, d: prefs.set_sort(me, d.get("field") or "", d.get("desc")),
    "view_reset": lambda me, d: prefs.reset_view(me),
    "company_set": lambda me, d: prefs.set_company(me, d.get("columns"),
                                                   d.get("sort")),
}


# ⭐ ОДИН ПЕРЕЛІК ДІЙ, ЯКІ ВЕДЕ АДМІНІСТРАТОР. Решта в цій таблиці — це те, що
# людина робить СОБІ. Змішати їх означало б віддати вигляд компанії будь-кому.
PREFS_ADMIN_ONLY = ("company_set",)


def run_prefs_action(actor, data: dict) -> dict:
    """ЄДИНИЙ вхід налаштувань екрана й вивантаження."""
    _require_enabled()
    me = _require_actor(actor)
    name = str((data or {}).get("action") or "").strip()
    if name in PREFS_ADMIN_ONLY:
        _require_admin(actor)
    if name == "export":                    # не налаштування, а дія над списком
        return {"ok": True, "result": _export(actor, data or {})}
    fn = PREFS_ACTIONS.get(name)
    if fn is None:
        raise ApiError("Невідома дія «%s». Відомі: %s"
                       % (name, ", ".join(sorted(list(PREFS_ACTIONS) + ["export"]))),
                       400, "unknown_action")
    try:
        return {"ok": True, "result": fn(me, data or {})}
    except prefs.PrefsError as e:
        raise ApiError(str(e), 400, "refused")
    except fields.FieldError as e:
        raise ApiError(str(e), 400, "refused")


ACTION_TABLES = {
    "people": PEOPLE_ACTIONS,     # оргструктура — веде адміністратор
    "access": ACCESS_ACTIONS,     # доступи — веде адміністратор
    "tasks": TASK_ACTIONS,        # задачі — веде сам працівник (інші ворота)
    "prefs": PREFS_ACTIONS,       # вигляд списку й вивантаження — теж сам працівник
}


# ⭐⭐⭐ ХТО МОЖЕ ЯКУ ДІЮ. Доти тут стояло глухе «все веде адміністратор», і
# рішення «людина править свої дані» просто не мало куди лягти. Тепер правило
# живе ОДНІЄЮ таблицею, як `ACTION_ROLES` у задачах: що не названо — адміністратор.
WHO_ADMIN = "admin"
WHO_SELF_OR_ADMIN = "self_or_admin"

WHO_MY_CARD = "my_card"

ACTION_WHO = {
    "people": {"employee_update": WHO_SELF_OR_ADMIN,
               # Своя картка цілком: тут не поле правлять, а вмикають канал.
               "telegram_code": WHO_MY_CARD,
               "telegram_unlink": WHO_MY_CARD},
}


def _guard_my_card(actor, data: dict):
    """Дія над СВОЄЮ карткою (не над полем). Адміністратор може й над чужою:
    він видає код людині, яка ще не має доступу до екрана, і знімає канал
    звільненому."""
    emp_id = str((data or {}).get("id") or "").strip()
    if not emp_id:
        raise ApiError("Не сказано, чия це картка.", 400, "no_id")
    if _is_admin(actor):
        return
    if not people.card_rights(_me(actor), emp_id, False).get("is_self"):
        raise ApiError("Телеграм людина підключає у своїй картці — чужу картку "
                       "змінює адміністратор.", 403, "not_allowed")


def _guard_card_fields(actor, data: dict):
    """Людина править СВОЄ, адміністратор — усе. Поле не за правом — відмова, яка
    називає, хто б це зміг."""
    emp_id = str((data or {}).get("id") or "").strip()
    if not emp_id:
        raise ApiError("Не сказано, чию картку правити.", 400, "no_id")
    rights = people.card_rights(_me(actor), emp_id, _is_admin(actor))
    asked = [k for k in (data or {}) if k not in ("action", "id")]
    if not asked:
        raise ApiError("Не сказано, що саме змінити.", 400, "no_fields")
    # ⭐ Відмова називає ПРИЧИНУ і того, хто б це зміг. Дві причини — різні:
    # «це не твоя картка» і «це поле не твоє» плутати не можна, бо людина
    # шукатиме зовсім не там. (`.capitalize()` тут теж не місце: «ПІБ» він
    # перетворював на «Піб» — знайдено живим прогоном 08.08.2026.)
    for f in asked:
        if f not in rights["fields"]:
            what = people.FIELD_NAMES.get(f, f)
            if not rights["is_self"]:
                raise ApiError(
                    "Це картка іншої людини: свої дані вона міняє сама, "
                    "а решту — адміністратор.", 403, "not_allowed")
            raise ApiError("У своїй картці %s змінює %s."
                           % (what, people.who_may_edit(f)), 403, "not_allowed")


def run_action(actor, table: str, data: dict) -> dict:
    """ЄДИНИЙ вхід для всіх дій обох екранів."""
    _require_enabled()
    actions = ACTION_TABLES.get(table)
    if actions is None:
        raise ApiError("Невідомий розділ «%s»." % table, 404, "unknown_table")
    name = str((data or {}).get("action") or "").strip()
    fn = actions.get(name)
    if fn is None:
        raise ApiError("Невідома дія «%s». Відомі: %s"
                       % (name, ", ".join(sorted(actions))), 400, "unknown_action")
    who = ACTION_WHO.get(table, {}).get(name, WHO_ADMIN)
    if who == WHO_ADMIN:
        _require_admin(actor)
    elif who == WHO_MY_CARD:
        _guard_my_card(actor, data or {})
    else:
        _guard_card_fields(actor, data or {})
    try:
        result = fn(data or {})
    except (people.PeopleError, identity.IdentityError) as e:
        raise ApiError(str(e), 400, "refused")
    return {"ok": True, "result": result}
