# -*- coding: utf-8 -*-
"""secrets_gate.py — КЛІТКА НА ВИХОДІ ДО БРАУЗЕРА (626в, 22.09.2026).

🩸 ЗНАЙДЕНО 22.09.2026 у ТОВ «КАСПЕР УКРАЇНА». Відповідь `telegram_unlink`
везла в браузер ВЕСЬ запис облікового запису — разом із `salt` і `pwd_hash`.
Екран із цього показує одне слово «відключено». Те саме везли зміна пароля,
вмикання запису, рівень адміністратора — і перелік `/api/taskdesk/accounts`
віддавав хеші паролів УСІЄЇ компанії за один запит.

⛒ КЛАС, А НЕ ВИПАДОК. Винен не обробник: кожна дія віддає те, що повернув
писар, а писар повертає запис ЦІЛИМ. «Передавайте акуратно» — домовленість, а
домовленість не запобіжник: завтра зʼявиться новий обробник і повезе те саме.

⛒ ЛІК — ТОЙ САМИЙ ПРИЙОМ, ЩО ВЖЕ ПРАЦЮЄ В ЖУРНАЛІ. Зміна 257 закрила аудит
кліткою на ВХОДІ (`audit._safe_record`). Тут — клітка на ВИХОДІ, в `_send`:
єдиний вихід сервера, і звідти таємниця не виходить, хоч би хто її туди поклав.

⛒ ДВА ПРАВИЛА, І ОБИДВА ТОЧНІ — БЕЗ ЗДОГАДІВ.
  1. ЗА НАЗВОЮ ПОЛЯ, і назва звіряється ЦІЛКОМ, а не шматком. Саме тому
     `has_token` і `password_changed_at` лишаються на місці: це не таємниці, а
     факти, і екран на них стоїть. ⚠ Слова `token` у переліку НЕМАЄ свідомо:
     `deal_mail.token` — це публічна позначка листа в темі, її видно клієнту в
     пошті, і зрізати її означало б зламати картку угоди.
  2. ЗА ЗНАЧЕННЯМ — але лише тим, що ця машина ТОЧНО ЗНАЄ як свій секрет
     (токени й ключі з `config.ENV`). Тому поле, перейменоване завтра, теж не
     винесе токен бота. ⛒ Здогадів «схоже на ключ» тут НЕМАЄ: через двері
     їдуть документи й відповіді клієнта, і слово «api_key» у тексті довідки —
     це текст довідки, а не витік. Здогад зіпсував би живі екрани.

Нічого не ховає під заглушку: таємниці в відповіді просто немає.
"""

# Назви полів, яких у відповіді браузеру не буває НІКОЛИ. Звіряються ЦІЛКОМ.
SECRET_FIELDS = frozenset((
    "salt", "pwd_hash", "pwd", "password", "passwd", "password_hash",
    "api_key", "apikey", "secret", "client_secret", "private_key",
    "access_token", "refresh_token", "bot_token", "session_token",
    "authorization", "cookie", "set-cookie",
))

# Змінні оточення, чиє ЗНАЧЕННЯ є секретом цієї машини.
_ENV_MARKS = ("TOKEN", "KEY", "SECRET", "PASSWORD")
_MIN_SECRET = 12


def _live_secrets() -> frozenset:
    """Справжні секрети цієї машини — щоб їх не винесло поле з будь-якою назвою."""
    out = set()
    try:
        import config
        for name, value in (config.ENV or {}).items():
            if not any(m in str(name).upper() for m in _ENV_MARKS):
                continue
            v = str(value or "").strip()
            if len(v) >= _MIN_SECRET:
                out.add(v)
    except Exception:
        pass
    return frozenset(out)


def _carries(value, live) -> bool:
    return (isinstance(value, str) and len(value) >= _MIN_SECRET
            and any(s in value for s in live))


def clean(payload, live=None):
    """Відповідь без таємниць. Оригінал не змінюється — робиться копія."""
    if live is None:
        live = _live_secrets()
    if isinstance(payload, dict):
        out = {}
        for k, v in payload.items():
            if str(k).strip().lower() in SECRET_FIELDS:
                continue
            if _carries(v, live):
                continue
            out[k] = clean(v, live)
        return out
    if isinstance(payload, list):
        return [clean(v, live) for v in payload if not _carries(v, live)]
    if isinstance(payload, tuple):
        return [clean(v, live) for v in payload if not _carries(v, live)]
    return payload
