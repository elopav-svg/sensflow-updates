# -*- coding: utf-8 -*-
"""trainer_report.py — ЗВІТ ТРЕНАЖЕРА ОДНИМ ПИСАРЕМ ПЛАТФОРМИ (628, 22.09.2026).

⛒ КЛАС. Тренажер приніс власний генератор DOCX на `python-docx`: свої поля,
свої рамки, свій шрифт — і жодного логотипа, колонтитула й печатки
походження, які платформа ставить на КОЖЕН свій папір. Два писарі одного
паперу розходяться на першій правці фірмового стилю, і клієнт дістає два
різні бланки з однієї програми.

⭐ РІШЕННЯ: розбір перетворюється на markdown, а в DOCX його кладе той самий
`artifacts.md_to_docx`, яким платформа робить комерційні пропозиції й акти.
Один бланк, один колонтитул, один штамп походження.

⛒ ЧОГО ТУТ НЕМАЄ. Тут немає суджень: усе, що пишеться, вже перевірено
(`trainer.check_review`). Писар паперу нічого не вигадує і нічого не ховає.
"""
import trainer


def _s(v) -> str:
    return "" if v is None else str(v)


def _esc(v) -> str:
    """Текст людини всередині таблиці не сміє розʼїхатись на стовпці."""
    return _s(v).replace("|", "/").replace("\n", " ").strip()


SCALE = ("Шкала: 0-2 — шкідлива поведінка; 3-4 — слабко; 5-6 — базовий рівень; "
         "7-8 — впевнено; 9-10 — послідовно й переконливо. Без оцінки — "
         "недостатньо даних. Середній бал рахується лише за оціненими "
         "критеріями, усі з однаковою вагою.")


def report_markdown(session: dict) -> str:
    """Повний розбір у markdown: методика, оцінки, докази, план, стенограма."""
    r = session.get("report") or {}
    if not r:
        raise trainer.TrainerError("Звіт ще не сформовано.")
    product = session.get("product") or {}
    profile = session.get("profile") or {}
    direction = "Продаж" if session.get("direction") == "sell" else "Закупівля"
    out = []
    add = out.append

    add("# Розбір навчальних переговорів")
    add("")
    add("**%s** · %s · опонент: %s" % (direction, _s(product.get("name")),
                                        _s(profile.get("name"))))
    who = _s(session.get("employee_name"))
    # ⛒ 628: слово-мітка тендерного паперу тут не вживається: його склад
    # стереже окремий сторож (`tender_honesty_test`), і жоден інший модуль
    # не сміє складати текст такої форми. Звіт Тренажера до тендерів
    # стосунку не має, тому говорить своїм словом, а не займає чуже.
    add("Дата сесії: %s   Код сесії: %s%s"
        % (_s(session.get("created"))[:10], _s(session.get("id"))[:8],
           ("   Менеджер: " + who) if who else ""))
    add("")
    if r.get("mode") == "demo":
        add("> Демонстраційний режим. Розбір сформовано локальними правилами; "
            "це не повна оцінка переговорних навичок, і числові бали не "
            "виставляються.")
    else:
        add("> Навчальна оцінка за цією сесією. Це інструмент розвитку "
            "навичок, а не психологічний висновок і не атестація працівника.")
    add("")
    add(_s(r.get("summary")))
    add("")

    add("## Результат переговорів")
    add(_s(r.get("outcome_label")))
    add("")
    add(_s(r.get("outcome_reason")))
    add("")
    overall = r.get("overall")
    add("Середній бал: %s. Критеріїв із достатніми даними: %s з 8."
        % (("%s з 10" % overall) if overall is not None else "не визначено",
           _s(r.get("coverage"))))
    add("")
    add(SCALE)
    add("")

    add("## Оцінка навичок")
    add("")
    add("| Критерій | Бал із 10 |")
    add("| --- | --- |")
    for d in r.get("dimensions") or []:
        score = d.get("score")
        add("| %s | %s |" % (_esc(trainer.CRITERION_NAMES.get(d.get("id"), d.get("id"))),
                             score if score is not None else "Без оцінки"))
    add("")

    for d in r.get("dimensions") or []:
        add("### " + _s(trainer.CRITERION_NAMES.get(d.get("id"), d.get("id"))))
        add(_s(d.get("analysis")))
        add("")
        for e in d.get("evidence") or []:
            add("> Репліка %s: «%s»" % (_s(e.get("turn")), _s(e.get("quote"))))
        add("")
        add("**Рекомендація.** " + _s(d.get("recommendation")))
        add("")

    for title, items in (("Сильні сторони", r.get("strengths")),
                         ("Зони розвитку", r.get("weaknesses"))):
        add("## " + title)
        for item in (items or []):
            add("- " + _s(item))
        add("")

    if r.get("rewrites"):
        add("## Як можна посилити репліки")
        for item in r["rewrites"]:
            add("**Репліка %s:** «%s»" % (_s(item.get("turn")), _s(item.get("original"))))
            add("Альтернатива: " + _s(item.get("better")))
            add(_s(item.get("why")))
            add("")

    add("## План розвитку")
    for i, item in enumerate(r.get("improvements") or [], 1):
        add("### Крок %d" % i)
        add(_s(item.get("action")))
        add("Вправа: " + _s(item.get("exercise")))
        add("Критерій успіху: " + _s(item.get("success")))
        add("")

    add("## Чого слід уникати")
    for item in (r.get("avoid") or []):
        add("- " + _s(item))
    add("")

    add("## Умови навчального сценарію")
    add(_s(product.get("description")))
    if product.get("source"):
        add("")
        add("Джерело опису товару: " + _s(product.get("source")))
    add("")

    add("## Повна стенограма переговорів")
    dialogue = session.get("dialogue") or []
    if not dialogue:
        add("Діалог не розпочався.")
    for turn in dialogue:
        name = ("Менеджер" if turn.get("role") == "manager"
                else _s(profile.get("name")) or "Опонент")
        add("**%s. %s:** %s" % (_s(turn.get("turn")), name, _s(turn.get("text"))))
    add("")
    return "\n".join(out)


def build_docx(session: dict, path) -> bool:
    """DOCX тим самим писарем, що й решта паперів платформи."""
    import artifacts
    return bool(artifacts.md_to_docx(report_markdown(session), path))


def file_name(session: dict) -> str:
    return "Розбір переговорів %s %s.docx" % (
        _s(session.get("created"))[:10], _s(session.get("id"))[:8])
