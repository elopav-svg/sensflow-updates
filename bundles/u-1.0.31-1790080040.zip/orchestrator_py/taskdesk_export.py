# -*- coding: utf-8 -*-
"""
taskdesk_export.py — ВИВАНТАЖЕННЯ НАЛАШТОВАНОГО СПИСКУ ЗАДАЧ У XLSX.

⭐⭐⭐ ЗАКОН ЦЬОГО ФАЙЛА: **ЩО НА ЕКРАНІ — ТЕ Й У ФАЙЛІ.** Він не знає жодного
поля, жодної колонки й жодного правила фільтрації — усе це він питає в
`taskdesk_fields`, того самого реєстру, з якого малюється список. Тому файл
фізично не може розійтися з тим, що людина бачила, коли натискала кнопку.

Що він робить сам: кладе аркуш, шапку, ширину колонок, заморожує перший рядок і
дописує підпис — хто, коли і за яким фільтром вивантажив. Підпис потрібен, бо
таблиця без нього через тиждень бреше: незрозуміло, це всі задачі чи вибірка.

⚠ Тека вивантажень — поруч із «Запустити SensFlow.bat», щоб клієнт знайшов її
очима. Коли рушій піднято в пісочниці (`SENSFLOW_STATE_DIR`), файли йдуть туди ж,
щоб наші чеки не смітили в бойову теку [[project_state_isolation]].

⚠ Мозок (LLM) сюди не ходить.
"""

import origin
import re
from datetime import datetime
from pathlib import Path

import config
import taskdesk_fields as fields

FOLDER_NAME = "Вивантаження задач"
KEEP_FILES = 60          # старіші прибираємо самі, щоб тека не заростала


class ExportError(Exception):
    """Відмова з причиною словами."""


def exports_dir() -> Path:
    root = config.STATE_DIR if config.STATE_SANDBOXED else config.PLATFORM_ROOT
    return Path(root) / FOLDER_NAME


def _safe(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "-", str(name or "")).strip() or "Задачі"


def _filter_words(flt, ctx) -> str:
    """Фільтр — словами, щоб підпис у файлі читала людина, а не програміст."""
    if not flt:
        return "без фільтра — усе, що видно"
    parts = []
    for fid, cond in flt.items():
        f = fields.BY_ID.get(fid)
        if not f:
            continue
        if f["filter"] == "set":
            if f["kind"] == "person":
                vals = [ctx["names"].get(v, v) for v in (cond or [])]
            elif f["id"] == "stage":
                import taskdesk_tasks as _t
                vals = [_t.STAGE_NAMES.get(v, v) for v in (cond or [])]
            else:
                vals = list(cond or [])
            if vals:
                parts.append("%s: %s" % (f["label"], ", ".join([str(v) for v in vals])))
        elif f["filter"] == "text" and str(cond or "").strip():
            parts.append('%s містить «%s»' % (f["label"], cond))
        elif f["filter"] == "date":
            lo, hi = (cond or {}).get("from"), (cond or {}).get("to")
            if lo or hi:
                parts.append("%s: %s — %s" % (f["label"], lo or "…", hi or "…"))
        elif f["filter"] == "flag" and cond not in (None, "", "any"):
            yes = cond in (True, "true", "1", 1, "так")
            parts.append("%s: %s" % (f["label"], "так" if yes else "ні"))
    return " · ".join(parts) or "без фільтра — усе, що видно"


def _require_openpyxl():
    try:
        import openpyxl                                    # noqa: F401
        return openpyxl
    except Exception:
        raise ExportError(
            "Для вивантаження в Excel потрібна бібліотека openpyxl, а її тут немає. "
            "Встановіть її одним рядком у командному рядку: "
            "python -m pip install openpyxl — і натисніть «Вивантажити» ще раз.")


def build(tasks_list, columns, ctx, who_name: str = "", flt=None,
          scope_name: str = "", query: str = "") -> dict:
    """Складає файл і каже, куди саме поклав. Нічого нікуди не надсилає."""
    openpyxl = _require_openpyxl()
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    cols = fields.normalize_columns(columns)
    heads = [fields.field(c)["label"] for c in cols]

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Задачі"

    ws.append(heads)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="173A44")
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"

    late = Font(color="B3261E", bold=True)
    for t in tasks_list:
        ws.append(fields.row(t, cols, ctx))
        if t.get("overdue"):
            for cell in ws[ws.max_row]:
                cell.font = late

    for i, c in enumerate(cols, start=1):
        ws.column_dimensions[get_column_letter(i)].width = fields.field(c)["w"]

    stamp = datetime.now().strftime("%d.%m.%Y %H:%M")
    ws.append([])
    ws.append(["Вивантажив: %s · %s" % (who_name or "—", stamp)])
    ws.append(["Показано: %s" % (scope_name or "усі видимі задачі")])
    ws.append(["Фільтр: %s" % _filter_words(flt, ctx)])
    # Файл каже ПРАВДУ про те, як його звузили: без цього рядка вивантаження
    # з пошуком читалось би як «всі задачі» — те саме мовчазне обрізання.
    ws.append(["Пошук: %s" % (str(query or "").strip() or "не задавали")])
    ws.append(["Задач у файлі: %d" % len(tasks_list)])
    note = Font(italic=True, color="5F6B70")
    for r in range(ws.max_row - 4, ws.max_row + 1):
        ws.cell(row=r, column=1).font = note

    folder = exports_dir()
    folder.mkdir(parents=True, exist_ok=True)
    name = "%s %s.xlsx" % (_safe("Задачі SensFlow"),
                           datetime.now().strftime("%d-%m-%Y %H-%M-%S"))
    path = folder / name
    wb.save(str(path))
    origin.stamp(path)   # ⛒ 583: ОДИН писар походження на всі виходи
    _trim(folder)
    return {"ok": True, "path": str(path), "folder": str(folder), "name": name,
            "rows": len(tasks_list), "columns": cols,
            "bytes": path.stat().st_size if path.exists() else 0}


def _trim(folder: Path):
    """Старі вивантаження прибираємо самі — тека клієнта не має заростати."""
    try:
        files = sorted(folder.glob("Задачі SensFlow *.xlsx"),
                       key=lambda p: p.stat().st_mtime, reverse=True)
        for p in files[KEEP_FILES:]:
            p.unlink()
    except Exception:
        pass
