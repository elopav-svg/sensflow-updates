# -*- coding: utf-8 -*-
"""
taskdesk_ai.py — ЄДИНИЙ МІСТ МІЖ TASK DESK І МОЗКОМ (рішення 21).

Навіщо він окремим файлом. Ядро задач (`taskdesk_tasks.py`) НЕ ІМПОРТУЄ мозок —
це судить чек деревом коду. Стадії, права, терміни й закриття — логіка, і вона
має бути передбачуваною до останнього кроку. Мозок потрібен рівно там, де треба
ЗРОЗУМІТИ ЛЮДСЬКИЙ ТЕКСТ, — і більше ніде.

⭐⭐⭐ ТРИ ЗАКОНИ ЦЬОГО ФАЙЛА

1. **МОЗОК ПРОПОНУЄ, ЛЮДИНА ВИРІШУЄ.** Він не пише термін і взагалі нічого не
   змінює в задачі. Він повертає ПРОПОЗИЦІЮ; записує її `taskdesk_tasks`, а
   застосовує — та сама `update()` під тими самими правами, і в журналі стоїть
   ЛЮДИНА. Інакше термін мав би двох писарів — машину й людину, — і за тиждень
   ніхто не сказав би, звідки взялась дата.

2. **КОД ВИРІШУЄ, ЧИ ВЗАГАЛІ ПИТАТИ МОЗОК.** Спершу безкоштовна перевірка
   `might_hold_a_date()`: якщо в коментарі немає нічого схожого на дату, гроші
   Андрія не витрачаються взагалі. Мозок платний — питати його «про всяк
   випадок» на кожен коментар не можна.

3. **МОЗОК НЕ ПРИДУМУЄ ДАТ.** Усе, що він повернув, проходить перевірку кодом:
   дата має бути справжньою, у майбутньому й ВЗЯТОЮ З ТЕКСТУ (цитата мусить у
   ньому знайтись). Не пройшло — пропозиції немає. Здогад, який видають за
   факт, гірший за мовчання.

4. **МОЗОК НЕ ТРИМАЄ ЛЮДИНУ ЗА РУКУ.** Коментар зберігається МИТТЄВО, ще до
   будь-якого виклику. Мозок отримує ПОВІДЕЦЬ у секундах: не встиг — екран так і
   каже, а коментар уже на місці. Живий прогін 08.08.2026 показав 6 секунд
   очікування на непрацюючій мережі; шість секунд на кожен коментар — це
   зламаний екран, а не «трохи повільно».

⚠ Вимикач: `SENSFLOW_TASKDESK_AI=off` — і жодного платного виклику.
⚠ Повідець: `SENSFLOW_TASKDESK_AI_WAIT` секунд (типово 8).
"""

import re

import clock
import config

SWITCH = "SENSFLOW_TASKDESK_AI"
WAIT_KEY = "SENSFLOW_TASKDESK_AI_WAIT"
WAIT_DEFAULT = 8.0

MONTHS = {
    "січ": 1, "лют": 2, "бере": 3, "квіт": 4, "трав": 5, "черв": 6,
    "лип": 7, "серп": 8, "верес": 9, "жовт": 10, "листоп": 11, "груд": 12,
}

# Дешевий сторож: щось схоже на дату в тексті. Жодних грошей.
DATE_HINTS = (
    re.compile(r"\b\d{1,2}[.\-/]\d{1,2}(?:[.\-/]\d{2,4})?\b"),      # 11.08 / 11.08.2026
    re.compile(r"\b\d{4}-\d{2}-\d{2}\b"),                            # 2026-08-11
    re.compile(r"\b\d{1,2}\s+(?:%s)\w*" % "|".join(MONTHS), re.I),   # 11 серпня
)


def enabled() -> bool:
    """ЄДИНА відповідь «чи мозок Task Desk увімкнений»."""
    return str(config.ENV.get(SWITCH, "on")).strip().lower() not in ("off", "0", "no")


def might_hold_a_date(text: str) -> bool:
    """БЕЗКОШТОВНИЙ сторож перед платним викликом."""
    t = str(text or "")
    return any(rx.search(t) for rx in DATE_HINTS)


SYSTEM = (
    "Ти читаєш ОДИН коментар до робочої задачі й відповідаєш, чи людина назвала "
    "нову дату, до якої задачу неможливо зробити раніше (наприклад, чекають "
    "чужої відповіді або документа).\n"
    "Поверни СТРОГО JSON без пояснень:\n"
    '{"is_new_date": true|false, "date": "YYYY-MM-DD", '
    '"quote": "<точний уривок коментаря, де названа дата>", '
    '"why": "<одне коротке речення українською, чому саме ця дата>"}\n'
    "Правила:\n"
    "- is_new_date=false, якщо дата в тексті стосується минулого, іншої задачі, "
    "зустрічі без звʼязку з терміном або якщо дати немає взагалі;\n"
    "- date бери ЛИШЕ з тексту, не вигадуй і не рахуй сам;\n"
    "- quote мусить бути ДОСЛІВНИМ уривком коментаря;\n"
    "- рік, якщо не названий, бери поточний."
)


def _to_iso(value, today: str) -> str:
    """Приводимо відповідь мозку до нашого вигляду. Що не сходиться — відкидаємо."""
    v = str(value or "").strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", v)
    if m:
        y, mo, d = m.groups()
    else:
        m = re.match(r"^(\d{1,2})[.\-/](\d{1,2})(?:[.\-/](\d{2,4}))?$", v)
        if not m:
            return ""
        d, mo, y = m.group(1), m.group(2), m.group(3) or today[:4]
        if len(y) == 2:
            y = "20" + y
    try:
        from datetime import date
        date(int(y), int(mo), int(d))
    except Exception:
        return ""
    return "%04d-%02d-%02d" % (int(y), int(mo), int(d))


def read_comment(title: str, text: str, today: str = "", ask=None) -> dict:
    """Прочитати коментар і, якщо там названа нова дата, повернути пропозицію.

    Повертає {} — коли пропозиції немає (це НЕ помилка).
    Кидає RuntimeError — коли мозок не відповів; тоді екран скаже про це вголос,
    а не змовчить."""
    today = today or clock.now()[:10]
    if not enabled() or not might_hold_a_date(text):
        return {}
    if ask is None:
        import llm
        # ⭐⭐⭐ 08.08.2026. ЖОДНЕ СУДЖЕННЯ НЕ ЙДЕ ПОВЗ ОДНОГО СУДДЮ.
        # Тут стояв ПРЯМИЙ `llm.complete_json` — і цей платний виклик не рахувався
        # в денну стелю вартості, не мав запасної спроби на мовчазну модель і не
        # лишав сліду в журналі суджень. Другий облік замість одного.
        ask = lambda sys_p, usr: llm.judge_json(
            sys_p, usr, temperature=0, model=config.worker_model(), max_tokens=300,
            purpose="taskdesk: новий термін з коментаря")
    user = ("Сьогодні %s.\nЗадача: %s\nКоментар: %s" % (today, title, text))
    try:
        out = ask(SYSTEM, user) or {}
    except Exception as e:
        raise RuntimeError("мозок не відповів: %s" % e)
    if not isinstance(out, dict) or not out.get("is_new_date"):
        return {}

    date = _to_iso(out.get("date"), today)
    if not date:
        return {}
    # ⭐ Дата з минулого нового терміну не робить.
    if date <= today:
        return {}
    # ⭐ Цитата мусить знайтись у самому коментарі — інакше це вигадка.
    quote = str(out.get("quote") or "").strip()
    if not quote or _squash(quote) not in _squash(text):
        return {}
    return {"kind": "due", "date": date, "quote": quote[:300],
            "why": str(out.get("why") or "").strip()[:300]}


def leash_seconds() -> float:
    """Скільки секунд людина чекає на мозок, перш ніж екран відповість без нього."""
    try:
        v = float(str(config.ENV.get(WAIT_KEY, "")).strip() or WAIT_DEFAULT)
    except Exception:
        v = WAIT_DEFAULT
    return max(1.0, min(60.0, v))


def read_comment_soon(title: str, text: str, today: str = "", ask=None,
                      wait: float = None):
    """`read_comment` на повідці. Повертає (пропозиція, примітка).

    Не встиг — повертаємо примітку словами, а не мовчимо й не тримаємо екран.
    Результат запізнілої відповіді ВИКИДАЄМО: писати в задачу з фонового потоку
    означало б другого писаря того самого файла."""
    import threading
    if not enabled() or not might_hold_a_date(text):
        return {}, ""
    box = {}

    def work():
        try:
            box["out"] = read_comment(title, text, today, ask)
        except Exception as e:
            box["err"] = str(e)

    th = threading.Thread(target=work, daemon=True)
    th.start()
    th.join(leash_seconds() if wait is None else wait)
    if th.is_alive():
        return {}, ("ШІ не встиг відповісти за %g с — коментар збережено, "
                    "пропозиції немає." % (leash_seconds() if wait is None else wait))
    if "err" in box:
        return {}, box["err"]
    return box.get("out") or {}, ""



# ---------------------------------------------------------------------------
# ⭐⭐⭐ КРИТЕРІЙ ПРИЙМАННЯ (зміна 223, 26.08.2026) — ВОРОТА ВХОДУ.
#
# Мозок робить тут РІВНО ОДНЕ: пропонує, ЗА ЧИМ приймемо результат. Він не
# пише це в задачу, не забороняє її поставити і не тримає людину: задача вже
# збережена, коли він тільки починає думати.
#
# ⛒ ТРИ ВОРОТА НА ЙОГО ВІДПОВІДЬ, І ЖОДНІ НЕ ЗАЙВІ:
# 1) не порожньо і не питання — порада, яка сама питає, це не порада;
# 2) не довше за одне речення — критерій на абзац ніхто не читатиме;
# 3) МУСИТЬ ГОВОРИТИ ПРО ЦЮ задачу: хоч одне змістовне слово з постановки.
#    Без цієї умови модель радо видає «Результат відповідає вимогам» на будь-що,
#    і людина за тиждень перестає читати пропозиції взагалі.
# ---------------------------------------------------------------------------
SYSTEM_ACCEPT = (
    "Ти помічник у задачнику. Тобі дають постановку задачі. "
    "Запропонуй ОДНЕ речення — за чим ми зрозуміємо, що задача виконана. "
    "Пиши словами постановника, конкретно, без загальних слів на кшталт "
    "«відповідає вимогам» чи «якісно виконано». Не питай нічого. "
    "Відповідай JSON: {\"acceptance\": \"...\", \"why\": \"...\"}"
)

_STOP_WORDS = {"задача", "зробити", "треба", "потрібно", "також", "після",
               "перед", "новий", "нова", "нове"}


def _meaningful(text: str) -> set:
    words = re.findall(r"[^\W\d_]{4,}", str(text or ""), flags=re.UNICODE)
    return {w.lower() for w in words} - _STOP_WORDS


def propose_acceptance(title: str, description: str = "", ask=None) -> dict:
    """Повертає {"acceptance": …, "why": …} або {} — коли пропозиції немає.

    {} — це НЕ помилка. Мовчання краще за вигадану пораду."""
    if not enabled():
        return {}
    body = (str(title or "") + " " + str(description or "")).strip()
    if not body:
        return {}
    if ask is None:
        import llm
        ask = lambda sys_p, usr: llm.judge_json(
            sys_p, usr, temperature=0, model=config.worker_model(), max_tokens=300,
            purpose="taskdesk: критерій приймання")
    user = "Постановка: %s" % body
    try:
        out = ask(SYSTEM_ACCEPT, user) or {}
    except Exception as e:
        raise RuntimeError("мозок не відповів: %s" % e)
    if not isinstance(out, dict):
        return {}
    text = str(out.get("acceptance") or "").strip()
    if not text or "?" in text or len(text) > 300:
        return {}
    # ⛒ Порада мусить говорити ПРО ЦЮ задачу, а не бути шаблоном на все.
    if not (_meaningful(text) & _meaningful(body)):
        return {}
    return {"acceptance": text, "why": str(out.get("why") or "").strip()[:300]}


def propose_acceptance_soon(title: str, description: str = "", ask=None,
                            wait: float = None):
    """`propose_acceptance` на повідці. Повертає (пропозиція, примітка).

    Той самий закон, що й для терміну: задача вже на місці, мозок людину не
    тримає, а запізніла відповідь ВИКИДАЄТЬСЯ — інакше в задачі зʼявився б
    другий писар із фонового потоку."""
    import threading
    if not enabled():
        return {}, ""
    box = {}

    def work():
        try:
            box["out"] = propose_acceptance(title, description, ask)
        except Exception as e:
            box["err"] = str(e)

    th = threading.Thread(target=work, daemon=True)
    th.start()
    secs = leash_seconds() if wait is None else wait
    th.join(secs)
    if th.is_alive():
        return {}, ("ШІ не встиг за %g с — задача створена, пропозиції немає." % secs)
    if "err" in box:
        return {}, box["err"]
    return box.get("out") or {}, ""


def _squash(s: str) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЗВІРЯННЯ РЕЗУЛЬТАТУ (зміна 236, 27.08.2026) — ВОРОТА 3.
#
# У всіх перевіряючий читає результат і НАМАГАЄТЬСЯ ЗГАДАТИ, що взагалі
# просили. У нас платформа кладе поруч три речі:
#     ЩО ПРОСИЛИ · ЩО ЗДАЛИ · ЧОГО НЕ ВИДНО.
#
# ⛔ МОЗОК НЕ ПРИЙМАЄ І НЕ ВІДХИЛЯЄ. У нього немає слова «приймати». Рішення й
# підпис лишаються за людиною — інакше ми зробили б рівно те, чого не робимо
# ніколи: машину, яка судить роботу людей.
#
# ⛒ ВОРОТА НА ЙОГО ВІДПОВІДЬ, І ЖОДНІ НЕ ЗАЙВІ:
# 1) немає критерію приймання або немає результату — звіряти НЕМА З ЧИМ, і ми
#    мовчимо. Звірка «ні з чим» — це вигадка з виглядом висновку;
# 2) відповідь мусить говорити про ЦЮ задачу: хоч одне змістовне слово з
#    критерію або з результату. Без цієї умови модель радо видає «здано
#    частково» на будь-що, і людина за тиждень перестає читати звірку взагалі;
# 3) «чого не видно» — КОРОТКІ пункти, не абзаци: не більше пʼяти, кожен в
#    одне речення. Перелік на пів екрана не читають;
# 4) слова вироку («приймати», «відхилити», «зараховано») ВИКИДАЮТЬСЯ — навіть
#    якщо модель їх написала. Вирок — не її робота.
# ---------------------------------------------------------------------------
SYSTEM_MATCH = (
    "Ти помічник у задачнику. Тобі дають КРИТЕРІЙ ПРИЙМАННЯ задачі і ТЕКСТ "
    "РЕЗУЛЬТАТУ, який здав виконавець. Порівняй їх і поверни три речі: "
    "asked — що просили, одним реченням; "
    "given — що здали, одним реченням; "
    "missing — перелік того, чого в результаті не видно (від 0 до 5 коротких "
    "пунктів, кожен в одне речення). "
    "Не оцінюй людину. НЕ пиши, приймати роботу чи ні — це вирішує людина. "
    "Не питай нічого. Відповідай JSON: "
    "{\"asked\": \"...\", \"given\": \"...\", \"missing\": [\"...\"]}"
)

# Слова вироку. Побачили — викинули пункт: вирок виносить людина.
_VERDICT = re.compile(r"(прийма|приймат|відхил|зарахов|залік|не\s+зарахов)",
                      re.IGNORECASE)

MISSING_MAX = 5          # більше пʼяти пунктів ніхто не читає
MISSING_CHARS = 200      # пункт — речення, а не абзац


def _one_line(value) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()


def compare_result(acceptance: str, result_text: str, ask=None) -> dict:
    """Повертає {"asked":…, "given":…, "missing":[…]} або {} — коли звірки немає.

    {} — це НЕ помилка. Мовчання краще за вигадану звірку."""
    if not enabled():
        return {}
    crit = _one_line(acceptance)
    done = _one_line(result_text)
    # ⛒ ВОРОТА 1: звіряти нема з чим. Без критерію або без результату будь-яка
    # «звірка» була б переказом одного тексту, виданим за порівняння двох.
    if not crit or not done:
        return {}
    if ask is None:
        import llm
        ask = lambda sys_p, usr: llm.judge_json(
            sys_p, usr, temperature=0, model=config.worker_model(),
            max_tokens=500, purpose="taskdesk: звіряння результату")
    user = "КРИТЕРІЙ ПРИЙМАННЯ: %s\n\nРЕЗУЛЬТАТ: %s" % (crit, done)
    try:
        out = ask(SYSTEM_MATCH, user) or {}
    except Exception as e:
        raise RuntimeError("мозок не відповів: %s" % e)
    if not isinstance(out, dict):
        return {}

    asked = _one_line(out.get("asked"))
    given = _one_line(out.get("given"))
    if not asked or not given:
        return {}
    if asked.endswith("?") or given.endswith("?"):
        return {}

    # ⛒ ВОРОТА 3 і 4: короткі пункти, без вироку.
    missing = []
    raw_missing = out.get("missing")
    if isinstance(raw_missing, str):
        raw_missing = [raw_missing]
    for item in (raw_missing or []):
        line = _one_line(item)
        if not line or len(line) > MISSING_CHARS:
            continue
        if _VERDICT.search(line):
            continue
        missing.append(line)
        if len(missing) >= MISSING_MAX:
            break

    # ⛒ ВОРОТА 2: звірка мусить говорити про ЦЮ задачу.
    theirs = _meaningful(crit + " " + done)
    mine = _meaningful(asked + " " + given + " " + " ".join(missing))
    if not (theirs & mine):
        return {}

    return {"asked": asked, "given": given, "missing": missing}


def compare_result_soon(acceptance: str, result_text: str, ask=None,
                        wait: float = None):
    """`compare_result` на повідці. Повертає (звірка, примітка).

    Той самий закон, що й для терміну та критерію: РЕЗУЛЬТАТ УЖЕ ЗДАНО, мозок
    людину не тримає, а запізніла відповідь ВИКИДАЄТЬСЯ — інакше в задачі
    зʼявився б другий писар із фонового потоку."""
    import threading
    if not enabled():
        return {}, ""
    box = {}

    def work():
        try:
            box["out"] = compare_result(acceptance, result_text, ask)
        except Exception as e:
            box["err"] = str(e)

    th = threading.Thread(target=work, daemon=True)
    th.start()
    secs = leash_seconds() if wait is None else wait
    th.join(secs)
    if th.is_alive():
        return {}, ("ШІ не встиг за %g с — результат здано, звірки немає." % secs)
    if "err" in box:
        return {}, box["err"]
    return box.get("out") or {}, ""
