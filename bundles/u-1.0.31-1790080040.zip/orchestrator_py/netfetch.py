"""
netfetch.py — СПІЛЬНИЙ надійний читач веб-контенту для ВСІХ систем платформи.

Єдине місце, що правильно РОЗПАКОВУЄ відповідь сервера (gzip / deflate / br).
Без цього стиснені сторінки декодуються в «кашу» (напр. zakon.rada віддавав
бінарщину, і ми хибно вважали це «важким JavaScript»). Будь-яка система, що
читає сайт чи офіційне джерело під запит користувача, бере тіло ЧЕРЕЗ цей модуль —
тому «будь-який сайт» (стиснений чи ні, будь-яка юрисдикція) обробляється
однаково надійно, а не через розкидані urllib, кожен зі своїм багом стиснення.

Тільки стандартна бібліотека. Brotli (br) — опційно: якщо пакет `brotli` не
встановлено, тіло лишається як є, а детектор каші в page_render віддасть таку
сторінку в локальний браузер (той розпакує сам).
"""

import gzip as _gzip
import json as _json
import zlib as _zlib
import threading as _threading
import ssl as _ssl
import urllib.request
import urllib.error  # noqa: F401  (реекспорт для викликачів, що ловлять помилки)

DEFAULT_UA = "AI-Orchestrator/1.0"

# ── ⭐⭐⭐ 623 (21.09.2026). ДОВІРА ДО СЕРТИФІКАТА — ОДИН ПИСАР ─────────────
# 🩸 КЛАС: платформа перевіряла сертифікат ЧУЖИМ списком коренів — тим, що
# лежить у системі клієнта, — і мовчала, коли той застарілий.
# Живий випадок 21.09.2026 (ТОВ «КАСПЕР УКРАЇНА»): Telegram віддав СПРАВЖНІЙ
# сертифікат GoDaddy, але у Windows тієї машини кореня GoDaddy немає — система
# не активована й не тягнула оновлень. Chrome носить власний список і відкривав
# сторінку; ми дивились у Windows і мовчки клали бота. Година роботи двох людей
# пішла на те, чого платформа не сказала одним рядком.
# ⛒ ТЕПЕР: свій свіжий список коренів їде З ПЛАТФОРМОЮ (`certifi`), а сховище
# системи береться ДОДАТКОМ — щоб не зламати корпоративний перехоплювач, якому
# машина вже вірить. Вимикати перевірку не можна НІКОЛИ: це не лік, а діра.
_CTX = None


def ssl_context():
    """ЄДИНИЙ контекст довіри на всі виходи платформи. Системне сховище ПЛЮС
    власний свіжий список коренів."""
    global _CTX
    if _CTX is not None:
        return _CTX
    ctx = _ssl.create_default_context()          # корені системи (і перехоплювач)
    try:
        import certifi
        ctx.load_verify_locations(cafile=certifi.where())   # + наш свіжий список
    except Exception:
        pass                                     # немає пакета — лишаємось на системі
    _CTX = ctx
    return ctx


# ⛒ ВІДМОВА МУСИТЬ ГОВОРИТИ. Мовчазний CERTIFICATE_VERIFY_FAILED — це те саме,
# що й мовчання: людина не знає ні причини, ні дії. Перекладач ОДИН, і він
# МОВЧИТЬ про чужу біду: якби кожна мережева помилка ставала «поставте
# сертифікат», відмовам перестали б вірити.
def explain_ssl_error(exc) -> str:
    """Людське пояснення, якщо біда саме в сертифікаті. Інакше — порожньо."""
    txt = ""
    e = exc
    for _ in range(4):
        txt += " " + str(getattr(e, "reason", "") or "") + " " + str(e)
        e = getattr(e, "reason", None) or getattr(e, "__cause__", None)
        if e is None:
            break
    low = txt.lower()
    if "certificate_verify_failed" not in low and "certificate verify failed" not in low:
        return ""
    return ("Сертифікат сайту не вдалося перевірити на ЦІЙ машині. Найчастіше це "
            "означає, що в її списку кореневих центрів бракує потрібного кореня — "
            "браузер має власний список і тому відкриває, а платформа дивиться в "
            "систему. Що зробити: оновити Windows (він оновлює й корені) або "
            "поставити потрібний кореневий сертифікат у «Довірені кореневі центри "
            "сертифікації». Якщо машина за корпоративним фільтром HTTPS — попросіть "
            "адміністратора додати його корінь у це саме сховище.")



# ── ВОРОТА ВИХОДУ НАЗОВНІ (режим максимального збереження / Стелс) ─────────────
# Це ЄДИНЕ вікно назовні для всіх систем, тож жорсткий запобіжник ставимо саме тут:
# у режимі повної локальної ізоляції (config.LLM_PROVIDER == "local") будь-який GET
# ФІЗИЧНО блокується, доки поточний потік не отримав явний дозвіл користувача
# (agent.run викликає allow_egress(True) одразу після згоди й скидає назад).
_egress_tl = _threading.local()


class EgressBlocked(urllib.error.URLError):
    """Вихід назовні заблоковано режимом максимального збереження (без дозволу).
    Успадковує URLError — наявні викликачі, що ловлять URLError/Exception, деградують
    безпечно (порожньо / чесний стоп), а не падають."""

    def __init__(self, url):
        super().__init__("egress blocked: max-preservation mode")
        self.blocked_url = url


def allow_egress(flag: bool = True):
    """Дозволити (True) вихід назовні для ПОТОЧНОГО потоку — ставиться ПІСЛЯ явної
    згоди користувача. Скидати у False одразу після дозволеної дії."""
    _egress_tl.allow = bool(flag)


def _egress_blocked(url: str) -> bool:
    # Явний дозвіл цього потоку — пропускаємо.
    if getattr(_egress_tl, "allow", False):
        return False
    # Блокуємо ЛИШЕ в режимі максимального збереження (повна локальна ізоляція).
    try:
        import config
        if getattr(config, "LLM_PROVIDER", "") != "local":
            return False
    except Exception:
        return False
    # Стелс і без дозволу → блок. Фіксуємо у журнал виходів (ліниво, без циклів імпорту).
    try:
        import egress_guard
        egress_guard.log("blocked", {"url": (url or "")[:200]})
    except Exception:
        pass
    return True


def decode_response(resp, cap: int = 3_000_000) -> str:
    """Читає тіло відповіді (до cap байтів) і розпаковує за Content-Encoding.
    Невідомий формат — лишає як є (не кидає). Повертає рядок utf-8."""
    raw = resp.read(cap)
    enc = (resp.headers.get("Content-Encoding") or "").lower()
    try:
        if "gzip" in enc or "x-gzip" in enc:
            raw = _gzip.decompress(raw)
        elif "deflate" in enc:
            try:
                raw = _zlib.decompress(raw)
            except Exception:
                raw = _zlib.decompress(raw, -_zlib.MAX_WBITS)
        elif "br" in enc:
            try:
                import brotli
                raw = brotli.decompress(raw)
            except Exception:
                pass
    except Exception:
        pass
    return raw.decode("utf-8", errors="replace")


def get_text(url: str, ua: str = DEFAULT_UA, timeout: int = 30,
             cap: int = 3_000_000, extra_headers: dict = None) -> str:
    """GET сторінки з правильними заголовками + розпакуванням тіла — ОДНАКОВО
    для всіх систем (без винятків per-система). Кидає urllib-винятки НАЗОВНІ —
    викликач сам вирішує, як їх обробити. Advertise-имо лише gzip/deflate (те, що
    decode_response уміє), тож стиснене тіло завжди розпакується без каші."""
    if _egress_blocked(url):
        raise EgressBlocked(url)
    headers = {"User-Agent": ua, "Accept-Encoding": "gzip, deflate"}
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout, context=ssl_context()) as resp:
        return decode_response(resp, cap)


def post_json(url: str, payload=None, ua: str = DEFAULT_UA, timeout: int = 30,
              cap: int = 3_000_000, extra_headers: dict = None) -> str:
    """POST з тілом JSON — те саме ЄДИНЕ вікно назовні, що й get_text.

    Навіщо окремо: частина офіційних джерел не має GET-пошуку (напр. повнотекстовий
    пошук Prozorro відповідає 405 на GET і працює лише через POST). Робити для них
    власний urllib повз цей модуль НЕ можна: тоді запит обійде ворота виходу
    (_egress_blocked), і в режимі максимального збереження / Стелс дані потечуть
    назовні непоміченими. Тому POST живе тут, під тими самими воротами.

    payload: dict/list -> серіалізується в JSON; str/bytes -> надсилається як є;
    None -> порожнє тіло "{}" (деякі API вимагають валідний JSON).
    Кидає urllib-винятки НАЗОВНІ, як і get_text.
    """
    if _egress_blocked(url):
        raise EgressBlocked(url)
    if payload is None:
        body = b"{}"
    elif isinstance(payload, bytes):
        body = payload
    elif isinstance(payload, str):
        body = payload.encode("utf-8")
    else:
        body = _json.dumps(payload, ensure_ascii=False).encode("utf-8")
    headers = {
        "User-Agent": ua,
        "Accept-Encoding": "gzip, deflate",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, data=body, headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout, context=ssl_context()) as resp:
        return decode_response(resp, cap)


def get_bytes(url: str, ua: str = DEFAULT_UA, timeout: int = 60,
              cap: int = 50_000_000, extra_headers: dict = None) -> bytes:
    """Завантаження ДВІЙКОВОГО вмісту (файл, картинка) — те саме ЄДИНЕ вікно назовні.

    Навіщо окремо від get_text: get_text декодує тіло в текст, і на PDF/JPG це
    зіпсувало б байти. Робити для файлів власний urllib повз цей модуль НЕ можна:
    тоді завантаження обійде ворота виходу (_egress_blocked) і в режимі
    максимального збереження зв'язок назовні лишиться непоміченим.
    Кидає urllib-винятки НАЗОВНІ, як get_text/post_json.
    """
    if _egress_blocked(url):
        raise EgressBlocked(url)
    headers = {"User-Agent": ua}
    if extra_headers:
        headers.update(extra_headers)
    req = urllib.request.Request(url, headers=headers)
    with urllib.request.urlopen(req, timeout=timeout, context=ssl_context()) as resp:
        return resp.read(cap)

# ── ⭐⭐⭐ ОДИН ПИСАР МЕЖI АДРЕСИ (10.08.2026, змiна 148) ─────────────────────
# 🩸 ЗНАЙДЕНО ЖИВИМ ПРОГОНОМ. Межу URL у продуктi писали ЧОТИРИ рiзнi мiсця, i
# кожне знало свiй набiр «стоп-символiв». Ворота джерел не знали зворотного
# апострофа — тому з `URL` у markdown вони захоплювали й ЗАКРИВАЛЬНИЙ апостроф,
# i пiсля пiдмiни в клiєнта лишався обiрваний бектик: чесний запобiжник виглядав
# як поломка. Класичнi ДВА (тут аж чотири) ПИСАРI ОДНIЄЇ ПРАВДИ.
# Тепер межа адреси одна на весь продукт. Ким би не був викликач — вiн бачить
# однаковi межi: пробiл, дужки, лапки, апостроф, бектик, кутовi дужки, кома,
# зiрочка (markdown-видiлення).
import re as _re

URL_RE = _re.compile(r"""https?://[^\s()\[\]{}<>"'`*,]+""")
_URL_TAIL = "/.,);:*`\"'>]}"


def find_urls(text) -> list:
    """Усi адреси в текстi, з обрiзаною пунктуацiєю на хвостi. Без дублiв."""
    out = []
    for u in URL_RE.findall(str(text or "")):
        u = u.rstrip(_URL_TAIL)
        if u and u not in out:
            out.append(u)
    return out


def first_url(text) -> str:
    """Перша адреса в текстi або порожньо."""
    us = find_urls(text)
    return us[0] if us else ""
