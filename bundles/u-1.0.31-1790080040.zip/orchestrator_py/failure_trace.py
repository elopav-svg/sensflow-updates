# -*- coding: utf-8 -*-
"""failure_trace.py — ⭐⭐⭐ СЛІД ПРОВАЛУ СТАВЛЯТЬ ДО ТОГО, ЯК ПЛАТЯТЬ (зміна 600).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ: **ПРОВАЛ БЕЗ ДОКАЗІВ.**
16.09.2026 живий прогін за $2,39 згорів так: складач чотири рази підряд уперся
в межу довжини (по ~350 с кожен), робота була відхилена, гроші пішли — а сказати,
ЧОМУ, було неможливо. У журналі стояло саме лише «обірвано». Сирого виводу не
лишилось ніде: ні тексту, ні довжини, ні місця обриву. Розбиратись не було по чому,
і єдине, що лишалось, — здогади. Здогад коштує ще одного прогону.

⭐ РІШЕННЯ: кожна відмова, яка коштувала грошей, лишає ФАЙЛ. Сирий вивід моделі,
відхилена спека і дослівна причина лягають у теку сліду, а в журнал іде ШЛЯХ до
неї. Наступна невдача розбирається по файлу, а не по памʼяті.

Тека: <RUNS_DIR>/_trace/<дата-час>-<мітка>/
Тримаємо останні TRACE_KEEP тек — слід має бути корисним, а не нескінченним.
"""
import re
import shutil
import time
from pathlib import Path

import config

TRACE_KEEP = 40
_MAX_BYTES = 2 * 1024 * 1024          # більше однієї відповіді моделі не буває


def _root() -> Path:
    return Path(config.RUNS_DIR) / "_trace"


def _slug(s: str) -> str:
    s = re.sub(r"[^\w\-]+", "-", str(s or "trace"), flags=re.U).strip("-")
    return (s[:40] or "trace")


def open_case(label: str = "") -> Path:
    """Заводить теку одного випадку. Повертає шлях (створений)."""
    d = _root() / ("%s-%s" % (time.strftime("%Y-%m-%dT%H-%M-%S"), _slug(label)))
    try:
        d.mkdir(parents=True, exist_ok=True)
        _prune()
    except Exception:
        pass
    return d


def put(case: Path, name: str, text) -> str:
    """Кладе один файл у теку випадку. Повертає шлях рядком (або «» на невдачі).

    🩸 Ніколи не валить прогін: слід — це допомога, а не ще одна точка відмови."""
    try:
        case.mkdir(parents=True, exist_ok=True)
        _n = Path(str(name))
        p = case / (_slug(_n.stem) + (_n.suffix or ".txt"))
        body = text if isinstance(text, str) else str(text)
        p.write_text(body[:_MAX_BYTES], encoding="utf-8", errors="replace")
        return str(p)
    except Exception:
        return ""


def _prune() -> None:
    try:
        dirs = sorted([d for d in _root().iterdir() if d.is_dir()])
        for d in dirs[:-TRACE_KEEP]:
            shutil.rmtree(d, ignore_errors=True)
    except Exception:
        pass
