# -*- coding: utf-8 -*-
"""kp_document.py — ⭐⭐⭐ ОДИН ПИСАР ЗАКОНУ ПРО КОМЕРЦІЙНУ ПРОПОЗИЦІЮ
(зміна 610, 18.09.2026).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ: **ЧИСЛО, НАПИСАНЕ ПРОЗОЮ.**
Перший живий прогін конвеєра КП видав документ, де сказано «суми зрівнюються
на 12-му місяці», тоді як його ж власні числа кажуть 13-й (на 12-му 412 000
проти 408 000 — другий варіант ще дешевший). Модель не рахує — модель пише.

Спроба полікувати це промптом («перерахуй і звір») не дала нічого: критик і
складальник працюють на найдешевшій моделі, і прохання до них — це сподівання,
а не гарантія. Старша модель тут теж гарантії не дає: рішення власника
18.09.2026 — лікуємо КОДОМ.

⭐ ТОМУ ЗАКОН ЖИВЕ ТУТ ОДИН РАЗ. Його питають ДВОЄ і однаково:
  * `kp_document_test.py` — доводить, що закон уміє червоніти;
  * `kp_live_probe.py`   — після прогону судить документ і, якщо є розбіжність,
    повертає складальникові ЙОГО Ж помилки дослівно на один перезапуск.

⛒ Тихого виправлення тексту клієнта тут немає і не буде: код НЕ переписує
пропозицію. Він або підтверджує, або називає розбіжність словами.

Офлайн, $0, без жодної моделі.
"""
import re

# Внутрішній жаргон, якому не місце в документі для клієнта.
ZHARGON = ("лпр", "конвеєр", "агент", "промпт", "пайплайн")
# Уточнення про домовленості, яких ми клієнтові не казали.
VYHADKY = ("усн", "орієнтовно", "попередньо", "приблизно")
# Слова, за якими видно, що дослідження ринку дійшло до документа.
RYNOK = ("ринк", "конкурент", "проти ринку", "бенчмарк")

# ⛒ ЧИСЛО ПРО РИНОК БЕЗ ДЖЕРЕЛА — ЦЕ ЧИСЛО З ГОЛОВИ. Клієнт має право спитати
# «звідки 400 000?», і відповідь «так написала модель» коштує угоди.
DZHERELO_RE = re.compile(r"[a-z0-9][a-z0-9-]*\.(ua|com|net|org|io|app|ai|info|biz)\b"
                         r"|за\s+даними|джерел|відкрит\w*\s+цін", re.I | re.U)
# ⛒ КЛІЄНТ БАЧИТЬ ТЕ, ЩО НАДРУКОВАНО. Формульна розмітка на кшталт
# «$160\\,000 \\times 13$» у пропозиції показується як сміття посеред цифр.
ROZMITKA_RE = re.compile(r"\\times|\\,|\\cdot|\\frac|\$\s*\d|\d\s*\$", re.U)
DATA_RE = re.compile(r"\b\d{2}\.\d{2}\.\d{4}\b")
KOMENTAR_RE = re.compile(r"<!--.*?-->", re.S)

_RE_A = re.compile(r"варіант\s*[аa]\b", re.I | re.U)
_RE_B = re.compile(r"варіант\s*[вb]\b", re.I | re.U)
_NO_START = re.compile(r"без\s+старт|нульов\w*\s+старт", re.I | re.U)
_TOTAL = re.compile(r"витрат|разом|усього|підсумок|за\s+\d+\s+рок|за\s+1\s+рік",
                    re.I | re.U)
_MONTH = re.compile(r"щоміс|/\s*міс|на\s+місяць|абонплат|абонент\w*\s+плат",
                    re.I | re.U)
_START = re.compile(r"старт", re.I | re.U)
_PERELOM = re.compile(r"(\d{1,3})[\-\s*]*му\s+місяц", re.I | re.U)
# ⛒ ДІАПАЗОН — ЦЕ НЕ ВІДПОВІДЬ. «Точка зрівнювання настає на 12–13 місяці» —
# це хеджування там, де код знає точний місяць. Клієнт, який читає «12–13»,
# бачить, що ми самі не порахували (спіймано 18.09.2026 на третьому прогоні).
_DIAPAZON = re.compile(r"\d{1,3}\s*[–—-]\s*\d{1,3}\s*місяц", re.I | re.U)
# ⛒ КОРІНЬ СЛОВА, А НЕ ФОРМА. «зрівнюються» і «зрівнювання» — одне й те саме
# для читача; сторож, який бачить лише одну форму, пропускає ту саму вправу,
# написану іншим відмінком (спіймано на собі 18.09.2026).
_PRO_PERELOM = ("зрівн", "перетин", "вигідніш", "вирівн", "точка окупн")

HORYZONTY = ((1, "1 рік"), (2, "2 роки"), (3, "3 роки"))


def ochystyty(text: str) -> str:
    """Службові примітки — не документ. Позначку прогону судити не можна."""
    return KOMENTAR_RE.sub(" ", str(text or ""))


def bez_rozmitky(text: str) -> str:
    """Прибирає ФОРМУЛЬНУ РОЗМІТКУ, не чіпаючи жодної цифри й жодного слова.

    ⛒ МЕЖА, ЯКУ КОД НЕ ПЕРЕТИНАЄ: тут виправляється ФОРМА, а не ЗМІСТ.
    «$160\\,000 \\times 13$» і «160 000 × 13» — це те саме число, написане
    по-різному; клієнт має побачити друге. Числа, твердження й ціни код не
    переписує ніколи — на них є вирок і перезбір."""
    t = str(text or "")
    t = t.replace("\\times", "×").replace("\\cdot", "·")
    t = t.replace("\\,", " ").replace("\\ ", " ")
    t = re.sub(r"\$([^$\n]{1,120})\$", r"\1", t)
    t = re.sub(r"[ \t]{2,}", " ", t)
    return t


def chysla(line: str) -> list:
    """Числа рядка, з якими б пробілами їх не написали: «160 000» -> 160000."""
    out = []
    for raw in re.findall(r"\d[\d   ]*", str(line or "")):
        digits = re.sub(r"[^\d]", "", raw)
        if digits:
            out.append(int(digits))
    return out


def umovy(text: str):
    """(старт A, місяць A, місяць B) або None, якщо документ умов не назвав.

    ⛒ ЧИТАЄМО РОЗДІЛАМИ, А НЕ ОДНИМ РЯДКОМ: живий документ пише варіант
    заголовком, а суми — списком під ним. Число має значення лише разом зі
    словом, яке його називає."""
    vals = {"a": {"start": None, "month": None}, "b": {"start": None, "month": None}}
    cur = None
    for line in ochystyty(text).split("\n"):
        low = line.lower()
        if _RE_A.search(low):
            cur = "a"
        elif _RE_B.search(low):
            cur = "b"
        if not cur or _TOTAL.search(low):
            continue
        if _NO_START.search(low) and vals[cur]["start"] is None:
            vals[cur]["start"] = 0
        n = [x for x in chysla(line) if x >= 1000]
        if not n:
            continue
        has_start = bool(_START.search(low)) and not _NO_START.search(low)
        has_month = bool(_MONTH.search(low))
        if has_start and has_month and len(n) >= 2:
            if vals[cur]["start"] is None:
                vals[cur]["start"] = n[0]
            if vals[cur]["month"] is None:
                vals[cur]["month"] = n[1]
        elif has_start and vals[cur]["start"] is None:
            vals[cur]["start"] = n[0]
        elif has_month and vals[cur]["month"] is None:
            vals[cur]["month"] = n[0]
    a_start, a_month = vals["a"]["start"], vals["a"]["month"]
    b_month = vals["b"]["month"]
    if a_start is None or a_month is None or b_month is None:
        return None
    return a_start, a_month, b_month


def perelom(a_start: int, a_month: int, b_month: int) -> int:
    """Перший місяць, на якому варіант A стає не дорожчим за B. 0 — ніколи."""
    if b_month <= a_month:
        return 0
    m = 1
    while m <= 600:
        if a_start + a_month * m <= b_month * m:
            return m
        m += 1
    return 0


def pidsumky(a_start: int, a_month: int, b_month: int) -> dict:
    """Похідні числа пропозиції. ⭐ Рахує КОД, і більше ніхто."""
    out = {"perelom": perelom(a_start, a_month, b_month), "horyzonty": {}}
    for years, label in HORYZONTY:
        months = years * 12
        out["horyzonty"][label] = {"A": a_start + a_month * months,
                                   "B": b_month * months}
    tri = out["horyzonty"]["3 роки"]
    out["ekonomiya_3_roky"] = abs(tri["A"] - tri["B"])
    return out


def _znahidka(code, human):
    return {"code": code, "human": human}


def vlasni_chysla(text: str) -> set:
    """⭐ 620. ЧИСЛА, ЯКІ ДОКУМЕНТ РАХУЄ САМ — умови пропозиції і все похідне.

    Це ланка «розрахунок» у ланцюгу походження: власну ціну не треба шукати в
    чужих джерелах, і кричати на неї означало б зробити сторожа нестерпним."""
    u = umovy(text)
    if not u:
        return set()
    own = set(u)
    calc = pidsumky(*u)
    for _label, pair in (calc.get("horyzonty") or {}).items():
        own.update(int(v) for v in pair.values())
    own.add(int(calc.get("ekonomiya_3_roky") or 0))
    return own


def review(text: str, evid=None) -> list:
    """Перелік розбіжностей документа з його ж числами і з нашими правилами.

    Порожній перелік = документ можна віддавати. Кожна знахідка написана
    ЛЮДСЬКОЮ мовою: її ж дослівно отримує складальник на перезапуск.

    ⛒ 620. `evid` — те, що платформа СПРАВДІ прочитала в цьому прогоні.
    Без нього писар походження чисел судити не може і каже це окремо: суддя,
    який мовчки пропускає непідперте число, гірший за відсутність судді."""
    t = ochystyty(text)
    low = t.lower()
    out = []

    if not DATA_RE.search(t):
        out.append(_znahidka(
            "data",
            "У пропозиції немає дати у форматі DD.MM.YYYY. «Вересень 2026» — "
            "це не дата: постав повну дату."))

    zh = [w for w in ZHARGON if re.search(r"(?<![^\W\d_])" + w, low, re.U)]
    if zh:
        out.append(_znahidka(
            "zhargon",
            "У документі для клієнта є внутрішній жаргон: %s. Прибери — пиши "
            "так, як пишуть людині." % ", ".join("«%s»" % w for w in zh)))

    vyh = []
    for line in t.split("\n"):
        if "домовлен" in line.lower():
            vyh += [w for w in VYHADKY if w in line.lower()]
    if vyh:
        out.append(_znahidka(
            "vyhadka",
            "Про домовленість із клієнтом дописано уточнення, якого у вхідних "
            "даних НЕ БУЛО (%s). Викресли: у комерційній пропозиції вигадане "
            "уточнення працює проти того, хто її підписує."
            % ", ".join("«%s…»" % w for w in sorted(set(vyh)))))

    if not any(w in low for w in RYNOK):
        out.append(_znahidka(
            "rynok",
            "Дослідження ринку не дійшло до документа: немає жодного рядка про "
            "ринок і конкурентів. Додай короткий розділ «Наша ціна проти "
            "ринку» — 3–5 рядків із тим, що реально знайдено. Якщо не знайдено "
            "нічого, так і напиши одним рядком."))

    # Розділ про ринок є — але чи можна його захистити перед клієнтом.
    rows = t.split("\n")
    rynok_rows = [i for i, ln in enumerate(rows) if any(w in ln.lower() for w in RYNOK)]
    if rynok_rows:
        vikno = " ".join(rows[max(0, rynok_rows[0] - 1):rynok_rows[-1] + 4])
        if [x for x in chysla(vikno) if x >= 1000] and not DZHERELO_RE.search(vikno):
            out.append(_znahidka(
                "dzherelo",
                "У розділі про ринок стоять числа, але не названо ЖОДНОГО "
                "джерела. Клієнт спитає «звідки ця цифра» — і відповісти буде "
                "нічим. Назви, звідки взято ринкові ціни (сайт, публікація), "
                "або прибери число і напиши якісно, без цифри."))

    # ⛒⛒⛒ 620. НАЗВАНЕ ДЖЕРЕЛО — ЩЕ НЕ ПЕРЕВІРЕНЕ. Рядок вище питає лише, чи
    # стоїть поруч підпис. Тут питається ПОХОДЖЕННЯ: чи лежить це число в
    # тому, що платформа справді читала, — або чи рахується воно з умов
    # самого документа. Третього чесного походження в числа немає.
    try:
        import number_trace
        out += number_trace.findings(t, evid, own=vlasni_chysla(t))
    except Exception as _e:                      # писар не сміє валити суд
        import sys as _snt
        _snt.stderr.write("[number_trace] писар походження впав: %r\n" % (_e,))

    if ROZMITKA_RE.search(t):
        out.append(_znahidka(
            "rozmitka",
            "У документі є формульна розмітка ($, \\times, \\,) — клієнт "
            "побачить її як сміття посеред цифр. Пиши числа звичайним текстом: "
            "«160 000 + 21 000 × 13 = 433 000 грн»."))

    u = umovy(t)
    if not u:
        out.append(_znahidka(
            "umovy",
            "Умови варіантів оплати не названо числом: мають бути стартовий "
            "платіж і щомісячний платіж для кожного варіанта."))
        return out

    a_start, a_month, b_month = u
    calc = pidsumky(a_start, a_month, b_month)

    said = None
    for line in t.split("\n"):
        ll = line.lower()
        if any(w in ll for w in _PRO_PERELOM):
            got = _PERELOM.search(ll)
            if got:
                said = int(got.group(1))
                break
    for line in t.split("\n"):
        ll = line.lower()
        if any(w in ll for w in _PRO_PERELOM) and _DIAPAZON.search(ll):
            out.append(_znahidka(
                "diapazon",
                "Місяць перелому названо ДІАПАЗОНОМ («%s»), хоча він рахується "
                "точно: %d-й. Діапазон у комерційній пропозиції читається як "
                "«ми самі не порахували». Постав одне число."
                % (_DIAPAZON.search(ll).group(0).strip(), calc["perelom"])))
            break

    if said is not None and calc["perelom"] and said != calc["perelom"]:
        out.append(_znahidka(
            "perelom",
            "Місяць перелому названо неправильно: у тексті «%d-й», а за "
            "умовами цього ж документа (старт %d + %d/міс проти %d/міс) — "
            "%d-й. На %d-му місяці виходить %d проти %d, тобто другий варіант "
            "ще дешевший. Постав %d-й."
            % (said, a_start, a_month, b_month, calc["perelom"], said,
               a_start + a_month * said, b_month * said, calc["perelom"])))

    vsi = set()
    for line in t.split("\n"):
        vsi.update(chysla(line))
    for years, label in HORYZONTY:
        if label.lower() not in low:
            continue
        for who in ("A", "B"):
            want = calc["horyzonty"][label][who]
            if want not in vsi:
                out.append(_znahidka(
                    "suma",
                    "Сума за %s для варіанта %s має бути %d — порахував із "
                    "умов самого документа, а такого числа в ньому немає."
                    % (label, who, want)))
    return out


def doruchennya(findings) -> str:
    """Зауваження складальникові — дослівно, без пом'якшень."""
    rows = "\n".join("%d. %s" % (i, f["human"])
                     for i, f in enumerate(findings or [], 1))
    return (
        "ПЕРЕВІРКА КОДОМ ЗНАЙШЛА РОЗБІЖНОСТІ В ЗІБРАНОМУ ДОКУМЕНТІ.\n"
        "Це не думка моделі — це арифметика, порахована з умов, які ти сам же й\n"
        "написав. Збери документ ЩЕ РАЗ, виправивши рівно це:\n\n%s\n\n"
        "Усе інше в документі лиши як є. Жодних нових чисел не вигадуй: усі "
        "суми беруться з умов, названих у пропозиції." % rows)
