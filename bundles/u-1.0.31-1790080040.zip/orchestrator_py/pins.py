# -*- coding: utf-8 -*-
"""pins.py — ЗАКРІПЛЕНІ ПОДІЇ (крок C3, 15.08.2026).

⭐⭐⭐ ПЕРШЕ РІШЕННЯ C3, І ВОНО ПРО ДАНІ, А НЕ ПРО КНОПКУ. Закріплення — це
позначка «це важливе, тримай його вгорі». Найпростіше було б дописати прапорець у
сам рядок події. Не можна: журнал (`state/protocol.jsonl`) — append-only, його не
переписують. Подія незмінна назавжди — саме на цьому стоїть увесь хребет.

⛒ ТОМУ ЗАКРІПЛЕННЯ ЖИВЕ ОКРЕМИМ РЕЄСТРОМ — той самий клас, що реєстр звʼязків у
B2: не чіпаємо чужі файли, а заводимо свій, який знає рівно одне.

⛒ І ВІН НЕ ЗНАЄ, ЩО ТАКЕ ПОДІЯ. Сюди приїжджає непрозорий КЛЮЧ події, який рахує
`relations.event_key()` — один писар тотожності події на всю платформу. Якби ключ
складався ще й тут, у нас було б два писарі однієї правди, і вони розійшлись би на
першому ж новому виді події.

⛒ ЗАКРІПЛЕННЯ НЕ ПИШЕТЬСЯ В ЗАГАЛЬНИЙ ЖУРНАЛ. Журнал веде дії ПРО КЛІЄНТА
(лист, прогін, оновлення), а закріплення — це те, як людина дивиться на екран.
Записавши його в журнал, ми б засмітили стрічку подіями про саму стрічку — і
кожне закріплення народжувало б рядок, який теж можна закріпити.

🩸 МЕЖА СІМ І ВОНА НАЗИВАЄ СЕБЕ. Межа взята зі зразка (Бітрікс24), і причина в
неї своя: закріплено все = не закріплено нічого. Мовчазна відмова на восьмому
записі була б гіршою за саму межу — тому `pin()` кидає відмову СЛОВАМИ, а екран
показує «закріплено 7 із 7».
"""

import json
import one_writer

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import entity                     # спільне імʼя сутності на всю платформу

_DIR = config.STATE_DIR / "state"
PINS_JSON = _DIR / "pins.json"

# Скільки подій можна тримати вгорі. Змінюється ТУТ і ніде більше: число, зашите
# у двох місцях, розходиться на першій же правці.
LIMIT = 7

# Довший «ключ» — це вже не ключ, а чийсь текст, який заїхав не туди.
MAX_KEY = 64


class PinError(Exception):
    """Відмова з причиною словами."""


def _s(v) -> str:
    return "" if v is None else str(v).strip()


# ── СХОВИЩЕ ──────────────────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(PINS_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    if not isinstance(d.get("pins"), dict):
        d["pins"] = {}
    return d


def _save(d: dict) -> None:
    """Атомарний запис: або старий файл цілий, або новий цілий. Половини не буває."""
    PINS_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(PINS_JSON, d)


def _key(raw) -> str:
    k = _s(raw)
    if not k:
        raise PinError("Порожній ключ події не закріплюється: закріпити «нічого» "
                       "означало б тримати вгорі рядок, якого немає.")
    if len(k) > MAX_KEY:
        raise PinError("Ключ події довший за %d знаків — це вже не ключ, а текст." % MAX_KEY)
    return k


def _rows(d: dict, ref: str) -> list:
    rows = d["pins"].get(ref)
    return rows if isinstance(rows, list) else []


# ── ЧИТАННЯ ──────────────────────────────────────────────────────────────────
def list_pins(ref) -> list:
    """Закріплення цієї сутності: ключ, коли й хто. Свіжіші — першими."""
    me = entity.norm(ref)                  # невідомий вид сутності — відмова
    rows = []
    for r in _rows(_load(), me):
        if not isinstance(r, dict):
            continue                       # побитий рядок не валить читання решти
        k = _s(r.get("key"))
        if not k:
            continue
        rows.append({"key": k, "at": _s(r.get("at")), "by": _s(r.get("by"))})
    rows.sort(key=lambda r: r.get("at") or "", reverse=True)
    return rows


def keys(ref) -> list:
    """Тільки ключі — саме це питає стрічка."""
    return [r["key"] for r in list_pins(ref)]


def count(ref) -> int:
    return len(list_pins(ref))


def is_pinned(ref, key) -> bool:
    return _s(key) in keys(ref)


# ── ЗАПИС ────────────────────────────────────────────────────────────────────
@one_writer.guard("PINS_JSON")
def pin(ref, key, by="") -> dict:
    """Закріпити подію. Межа переповнена — ВІДМОВА СЛОВАМИ, а не тихе ігнорування."""
    me = entity.norm(ref)
    k = _key(key)
    d = _load()
    rows = [r for r in _rows(d, me) if isinstance(r, dict)]
    if any(_s(r.get("key")) == k for r in rows):
        # Повторне закріплення того самого — не помилка й не другий рядок.
        return {"ref": me, "key": k, "count": len(rows), "limit": LIMIT, "added": False}
    if len(rows) >= LIMIT:
        raise PinError(
            "Закріплено вже %d подій із %d можливих. Закріплено все — не закріплено "
            "нічого: звільніть місце, знявши те, що вже не потрібно вгорі."
            % (len(rows), LIMIT))
    rows.append({"key": k, "at": clock.now(), "by": _s(by)})
    d["pins"][me] = rows
    _save(d)
    return {"ref": me, "key": k, "count": len(rows), "limit": LIMIT, "added": True}


@one_writer.guard("PINS_JSON")
def unpin(ref, key) -> dict:
    """Зняти закріплення. Знімати нема чого — кажемо це, а не мовчимо."""
    me = entity.norm(ref)
    k = _key(key)
    d = _load()
    rows = [r for r in _rows(d, me) if isinstance(r, dict)]
    left = [r for r in rows if _s(r.get("key")) != k]
    removed = len(rows) - len(left)
    if left:
        d["pins"][me] = left
    else:
        d["pins"].pop(me, None)
    _save(d)
    return {"ref": me, "key": k, "count": len(left), "limit": LIMIT,
            "removed": bool(removed)}
