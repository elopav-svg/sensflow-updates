# -*- coding: utf-8 -*-
"""why_red.py — ОДИН ПИСАР ПРИЧИНИ ЧЕРВОНОГО (зміна 559, 11.09.2026).

⭐⭐⭐ НАВІЩО. 11.09.2026 передача зміни назвала причину червоного чека
`client_numbers` ЗА НАЗВОЮ ЧЕКА — «числа в документах застаріли, лікує кнопка».
Насправді впала зовсім інша проба — писар чисел не вписав число в .docx. Рядок
із правдою лежав у журналі прогону, і його ніхто не прочитав. Ціна помилки:
зайва кнопка для людини, зайва зміна, втрачений ранок.

⛒ КЛАС: ПРИЧИНУ ЧЕРВОНОГО НАЗИВАЮТЬ ПО ПАМʼЯТІ, А НЕ ПО ЖУРНАЛУ.
Лік той самий, що й скрізь у платформі: ОДИН ПИСАР. Причину червоного пише не
людина і не памʼять, а цей файл — з журналу останнього прогону, дослівно.

🩸 ПРАВИЛО: у передачі зміни причина червоного чека НЕ переказується своїми
словами. Туди клеїться вивід цього інструмента.

Запуск:  python3 why_red.py            — останній журнал у logs\\
         python3 why_red.py <файл.log> — конкретний журнал
Офлайн, $0, нічого не пише на диск.
"""
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
LOGS = HERE / "logs"

# Рядок проби: «  FAIL  текст» · «  [12] FAIL - текст» · «  FAIL текст»
PROBE = re.compile(r"^\s*(?:\[\d+\]\s*)?FAIL\b[\s\-]*(.*)$")
HEAD = re.compile(r"^---\s*(.*?)\s*\(([\w\.]+\.py)\)\s*---\s*$")
# Підсумок, а не проба: «FAILED: 3», «РЕЗУЛЬТАТ: FAIL — 1 червоних».
SUMMARY = re.compile(r"^\s*(?:FAIL(?:ED)?\s*:\s*\d+|РЕЗУЛЬТАТ\s*:\s*FAIL|FAIL\s*\(\d+\))")
# Під підсумком чеки перелічують імена проб рядками «   - назва».
LISTED = re.compile(r"^\s+-\s+(.+)$")


def newest_log():
    if not LOGS.is_dir():
        return None
    logs = sorted(LOGS.glob("selfcheck_*.log"))
    return logs[-1] if logs else None


def blocks(text):
    """Журнал → шматки «один чек». Заголовок дає ІМʼЯ ФАЙЛА чека."""
    out, cur = [], {"file": "(початок журналу)", "name": "", "lines": []}
    for line in text.splitlines():
        m = HEAD.match(line)
        if m:
            out.append(cur)
            cur = {"file": m.group(2), "name": m.group(1), "lines": []}
        else:
            cur["lines"].append(line)
    out.append(cur)
    return out


def say(text, seen):
    """Один рядок проби. Ту саму пробу двічі не друкуємо: чеки називають її
    і в місці падіння, і в підсумку — людині це виглядає як дві вади."""
    t = text.strip()[:200]
    # Ключ — САМА проба без «<- подробиця»: у місці падіння вона йде з
    # подробицею, у підсумку — без неї, і без цього виглядала б як дві.
    key = re.split(r"\s+(?:<-|->)\s*", t)[0].strip().lower()
    if key in seen:
        return
    seen.add(key)
    print("   \u2717 %s" % t)


def main():
    path = Path(sys.argv[1]) if len(sys.argv) > 1 else newest_log()
    if not path or not path.exists():
        print("Журналу прогону немає — нема що читати.")
        print("Спершу прожени набір: python3 selfcheck.py")
        return 2
    text = path.read_text(encoding="utf-8", errors="replace")
    print("ЖУРНАЛ: %s" % path.name)

    verdict = [l for l in text.splitlines() if l.startswith("SELF-CHECK:")]
    if not verdict:
        # ⚠ Обірваний прогін виглядає як завершений — хвіст 80. Кажемо вголос.
        print("⚠ ВИРОКУ В ЖУРНАЛІ НЕМАЄ — прогін ОБІРВАВСЯ, а не завершився.")
    else:
        print("ВИРОК: %s" % verdict[-1].split(" -> ")[0])
    print("=" * 70)

    red = 0
    for b in blocks(text):
        body = "\n".join(b["lines"])
        if "RESULT FAIL" not in body:
            continue
        red += 1
        print()
        print("🔴 %s" % b["file"])
        print("   обіцянка: %s" % b["name"][:150])
        prev, after_summary, said, seen = None, False, 0, set()
        for line in b["lines"]:
            if SUMMARY.match(line):
                # «FAILED: 3» / «РЕЗУЛЬТАТ: FAIL — 1 червоних» — це ПІДСУМОК,
                # а не проба. Але одразу під ним чеки перелічують імена проб.
                after_summary, prev = True, False
                continue
            if after_summary:
                m2 = LISTED.match(line)
                if m2:
                    say(m2.group(1), seen)
                    said += 1
                    prev = False
                    continue
                if line.strip():
                    after_summary = False
            m = PROBE.match(line)
            if m and "RESULT" not in line and m.group(1).strip():
                say(m.group(1), seen)
                prev = True
                said += 1
                continue
            if prev and line.strip().startswith("->"):
                print("     %s" % line.strip()[:300])
            prev = False
        if not said:
            # Чек упав до першої проби — виняток, MISSING, тайм-аут.
            tail = [l for l in b["lines"] if l.strip()][-6:]
            print("   ✗ жодної названої проби — чек упав раніше. Хвіст журналу:")
            for l in tail:
                print("     %s" % l.strip()[:200])
    print()
    print("=" * 70)
    print("ЧЕРВОНИХ ЧЕКІВ: %d. Вище — ДОСЛІВНІ рядки з журналу." % red)
    print("🩸 У передачу зміни клеїти ЦЕ, а не переказ своїми словами.")
    return 0


sys.exit(main())
