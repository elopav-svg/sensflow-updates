# -*- coding: utf-8 -*-
"""file_store.py — РУШІЙ ФАЙЛОВОГО СХОВИЩА (зміна 529, 07.09.2026).

ФІЛОСОФІЯ, ЯКУ ЗАДАВ АНДРІЙ 06.09.2026 — дослівно:
«Адміністратор відповідає за збереження і підтримання файлового сховища.
Кожні 10 ГБ він проводить ревізію резерву місця на диску і свідомо вирішує,
чи продовжити накопичення, чи скоротити глибину зберігання.»

З неї випливає геть усе, що тут написано:
  · файли лежать на МАШИНІ ПЛАТФОРМИ, у теці `files` у корені продукту —
    поруч із текою `crm`. Жодної хмари;
  · 10 ГБ — це ПОРІГ, А НЕ ЗАМОК: платформа попереджає й далі приймає файли,
    і повторює попередження на кожних наступних 10 ГБ;
  · бекапу завантажених файлів ми НЕ робимо — свідомо, щоб не переобтяжувати.
    Перенесення на іншу машину: адміністратор везе бекап і теку `files`
    ОКРЕМО, зберігши її назву й місце;
  · файл прибрали з теки руками — платформа ЧЕСНО каже, що його немає. Не
    мовчить і не вдає, ніби він є.

⛒ СТЕЛЯ НА ОДИН ФАЙЛ — 100 МБ (слово Андрія). Вміщає специфікацію, скан
договору, креслення; відсікає відео й архіви, якими одна людина за день зʼїла
б половину сховища.

⛒ НА ДИСКУ ФАЙЛ ЛЕЖИТЬ ПІД ТЕХНІЧНИМ ІМЕНЕМ, а людині показується те, яке
вона завантажила. Дві угоди легко матимуть «Специфікація.pdf», і затирати
одну одною не можна. Технічне імʼя закриває й другу біду: як би не звався
файл у людини (хоч «..\\..\\system32\\щось»), на диск він лягає під НАШИМ
іменем усередині `files` — вийти за межі теки нема чим.

⛒ ЛІЧИЛЬНИК МІСЦЯ ЖИВЕ В РЕЄСТРІ, А НЕ РАХУЄТЬСЯ ОБХОДОМ ТЕКИ на кожне
завантаження: на десятках тисяч файлів обхід став би помітним. Але він МУСИТЬ
уміти перерахуватись від нуля (`recount`) — адміністратор видаляє файли
руками, і платформа про це не знає.

⛒ РЕЄСТР — ЦЕ СТАН, І ВІН ЇДЕ В БЕКАПІ; самі файли — ні. Саме тому
перенесення двоскладове: бекап каже, ЩО має лежати, тека `files` везе САМІ
файли. Розійшлись — `recount` називає, чого бракує.

⚠ НАЗВАНА МЕЖА 1: рушій НЕ ЗНАЄ, до якої картки файл прикріплений. Це знає
`card_values` (крок 530). Тому «сироту» — файл, який уже нікуди не
прикріплений, — тут не видно; його називає екран сховища (крок 532), звіряючи
`all_ids()` зі значеннями карток.
⚠ НАЗВАНА МЕЖА 2: слід у протоколі пише той, хто знає подію діловими словами
(«прикріпив до угоди»), тобто двері 530. Тут пишеться лише хто і коли
завантажив.
⚠ НАЗВАНА МЕЖА 3: рушій НІКОМУ НІЧОГО НЕ ВІДДАЄ ПО HTTP. Як файл їде людині
(завжди як завантаження, ніколи не відкривається всередині сторінки) — справа
дверей 530.
"""
import json
import os
import re
import shutil
import uuid
from pathlib import Path

import clock
import config
import one_writer

config.refuse_live_state_for_checks(__name__)

# ── МЕЖІ, НАЗВАНІ ВГОЛОС ────────────────────────────────────────────────────
MAX_FILE_BYTES = 100 * 1024 * 1024            # стеля на ОДИН файл — 100 МБ
WARN_STEP_BYTES = 10 * 1024 * 1024 * 1024     # поріг ревізії — кожні 10 ГБ
DISK_RESERVE_BYTES = 200 * 1024 * 1024        # запас диска, який не займаємо
CHUNK = 1024 * 1024
NAME_MAX = 180

# ⛒ Тека файлів стоїть у КОРЕНІ ПРОДУКТУ (слово Андрія: «назва й місце ті
# самі»), рівно як тека `crm`. У пісочниці чека вона відводиться вбік разом з
# усім станом — інакше чек смітив би в бойову теку Андрія.
# Адресу дає ОДИН ВЛАСНИК — `config` (зміна 529в). Рушій її не рахує:
# два писарі адреси розходяться на першій же правці (урок зміни 418).
FILES_DIR = config.FILES_DIR
REGISTRY_JSON = config.STATE_DIR / "state" / "file_store.json"


class FileStoreError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def human(n) -> str:
    """Розмір людськими словами: «10,4 ГБ»."""
    n = float(n or 0)
    for unit, step in (("ГБ", 1024 ** 3), ("МБ", 1024 ** 2), ("КБ", 1024)):
        if n >= step:
            return ("%.1f %s" % (n / step, unit)).replace(".", ",")
    return "%d Б" % int(n)


def _clean_name(name) -> str:
    """Людське імʼя файла — ЛИШЕ для показу. Шляху в ньому бути не може."""
    nm = _s(name).replace("\\", "/")
    nm = nm.split("/")[-1]
    nm = "".join(ch for ch in nm if ch >= " " and ch not in '"<>|*?:')
    nm = nm.strip(" .")
    return nm[:NAME_MAX]


def _safe_ext(name) -> str:
    m = re.search(r"\.([A-Za-z0-9]{1,10})$", _s(name))
    return ("." + m.group(1).lower()) if m else ""


def _load() -> dict:
    try:
        d = one_writer.read_json(REGISTRY_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("files", {})
    d.setdefault("total", 0)
    d.setdefault("ack_steps", 0)
    return d


def _save(d: dict) -> None:
    REGISTRY_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(REGISTRY_JSON, d)


def _rel_for(fid: str, ext: str) -> str:
    # ⛒ Дві літери попереду — не прикраса: у теці з десятками тисяч файлів
    # Windows помітно повільнішає. Для перенесення це нічого не міняє: тека
    # `files` їде цілком.
    return "%s/%s%s" % (fid[:2], fid, ext)


def _blob(rec: dict) -> Path:
    return FILES_DIR / _s(rec.get("path"))


def _drop(p) -> None:
    try:
        Path(p).unlink()
    except Exception:
        pass


def _free_bytes() -> int:
    """Скільки місця на диску. -1 — спитати не вдалось, і вигадувати не будемо."""
    try:
        FILES_DIR.mkdir(parents=True, exist_ok=True)
        return int(shutil.disk_usage(str(FILES_DIR)).free)
    except Exception:
        return -1


def _chunks(src):
    if isinstance(src, (bytes, bytearray)):
        if src:
            yield bytes(src)
        return
    read = getattr(src, "read", None)
    if not callable(read):
        raise FileStoreError("Нема чого зберігати: дали не файл і не байти.")
    while True:
        part = read(CHUNK)
        if not part:
            break
        yield part


# ── ЗАПИС ───────────────────────────────────────────────────────────────────
@one_writer.guard("REGISTRY_JSON")
def put(src, name, by: str = "") -> dict:
    """Покласти файл у сховище. `src` — байти або те, що вміє `.read(n)`.

    ⛒ ВІДМОВЛЯЄ СЛОВАМИ і НІКОЛИ не лишає по собі половини файла: порожній ·
    більший за 100 МБ · на диску скінчилось місце. 🩸 Диск чужий, і він може
    скінчитись раніше за наш поріг — тоді запис мусить сказати про це, а не
    впасти."""
    nm = _clean_name(name)
    if not nm:
        raise FileStoreError("Файл без імені не приймається.")

    free = _free_bytes()
    if 0 <= free <= DISK_RESERVE_BYTES:
        raise FileStoreError(
            "На диску не лишилось вільного місця — файл «%s» не збережено. "
            "Звільніть місце і повторіть." % nm)
    limit = (MAX_FILE_BYTES if free < 0
             else min(MAX_FILE_BYTES, free - DISK_RESERVE_BYTES))

    fid = uuid.uuid4().hex
    rel = _rel_for(fid, _safe_ext(nm))
    dest = FILES_DIR / rel
    try:
        dest.parent.mkdir(parents=True, exist_ok=True)
    except Exception as ex:
        raise FileStoreError("Не вдалось відкрити теку сховища: %s" % ex)

    tmp = dest.with_name(dest.name + ".part")
    size = 0
    try:
        with open(str(tmp), "wb") as fh:
            for chunk in _chunks(src):
                size += len(chunk)
                if size > MAX_FILE_BYTES:
                    raise FileStoreError(
                        "Файл «%s» більший за 100 МБ — це стеля на один файл. "
                        "Розділіть його або покладіть стисненим." % nm)
                if size > limit:
                    raise FileStoreError(
                        "На диску забракло місця для файла «%s» — його не "
                        "збережено." % nm)
                fh.write(chunk)
            fh.flush()
            os.fsync(fh.fileno())
    except FileStoreError:
        _drop(tmp)
        raise
    except OSError as ex:
        _drop(tmp)
        raise FileStoreError("Файл «%s» не записався на диск: %s" % (nm, ex))

    if size <= 0:
        _drop(tmp)
        raise FileStoreError("Порожній файл не зберігається.")

    try:
        one_writer.replace_with_patience(tmp, dest)
    except OSError as ex:
        _drop(tmp)
        raise FileStoreError("Файл «%s» не став на місце: %s" % (nm, ex))

    d = _load()
    d["files"][fid] = {"name": nm, "path": rel, "size": size,
                       "at": clock.now(), "by": _s(by)}
    d["total"] = int(d.get("total") or 0) + size
    _save(d)
    return info(fid)


@one_writer.guard("REGISTRY_JSON")
def remove(fid) -> dict:
    """РЕВІЗІЯ АДМІНІСТРАТОРА: прибрати файл справді — з диска й з реєстру.

    ⛒ Це НЕ «відкріпити від картки». Відкріплення лишає файл лежати — він і
    стає сиротою, глибину зберігання яких вирішує адміністратор."""
    key = _s(fid)
    d = _load()
    rec = (d["files"] or {}).get(key)
    if not rec:
        raise FileStoreError("Такого файла у сховищі немає.")
    p = _blob(rec)
    was = p.exists()
    if was:
        try:
            p.unlink()
        except OSError as ex:
            raise FileStoreError("Файл «%s» не прибрався з диска: %s"
                                 % (_s(rec.get("name")), ex))
    d["files"].pop(key, None)
    d["total"] = max(0, int(d.get("total") or 0) - int(rec.get("size") or 0))
    _save(d)
    return {"id": key, "name": _s(rec.get("name")), "was_on_disk": was}


@one_writer.guard("REGISTRY_JSON")
def ack_threshold() -> dict:
    """Адміністратор побачив поріг і провів ревізію. Наступне попередження —
    через наступні 10 ГБ, а не одразу знову."""
    d = _load()
    d["ack_steps"] = int(d.get("total") or 0) // WARN_STEP_BYTES
    _save(d)
    return usage()


@one_writer.guard("REGISTRY_JSON")
def recount() -> dict:
    """ПЕРЕРАХУВАТИ ВІД ДИСКА, а не від памʼяті: адміністратор видаляє файли
    руками, і лічильник про це не знає.

    ⛒ ЗАПИСІВ ПРО ЗНИКЛІ ФАЙЛИ НЕ СТИРАЄ: картка на них посилається, і
    платформа мусить чесно казати, що файла немає, а не мовчати."""
    d = _load()
    total = 0
    missing = []
    known = set()
    for fid, rec in (d["files"] or {}).items():
        p = _blob(rec)
        if p.exists():
            try:
                sz = int(p.stat().st_size)
            except OSError:
                sz = int(rec.get("size") or 0)
            rec["size"] = sz
            total += sz
            try:
                known.add(str(p.resolve()))
            except Exception:
                known.add(str(p))
        else:
            missing.append({"id": fid, "name": _s(rec.get("name"))})
    stray = []
    if FILES_DIR.exists():
        for p in FILES_DIR.rglob("*"):
            try:
                if not p.is_file() or p.suffix == ".part":
                    continue
                if str(p.resolve()) in known:
                    continue
                stray.append(str(p.relative_to(FILES_DIR)).replace("\\", "/"))
            except Exception:
                continue
    d["total"] = total
    _save(d)
    out = usage()
    out["missing"] = missing
    out["stray"] = sorted(stray)
    return out


# ── ЧИТАННЯ ─────────────────────────────────────────────────────────────────
def info(fid):
    """Що ми знаємо про файл. `present` каже правду про ДИСК, а не про реєстр.
    Ніколи не приймали такого — None."""
    key = _s(fid)
    rec = (_load()["files"] or {}).get(key)
    if not rec:
        return None
    out = dict(rec)
    out["id"] = key
    out["present"] = _blob(rec).exists()
    out["size_text"] = human(rec.get("size"))
    return out


def exists(fid) -> bool:
    rec = (_load()["files"] or {}).get(_s(fid))
    return bool(rec) and _blob(rec).exists()


def path_of(fid) -> Path:
    """Шлях до файла на диску. Немає — ВІДМОВА СЛОВАМИ, а не порожнеча."""
    key = _s(fid)
    rec = (_load()["files"] or {}).get(key)
    if not rec:
        raise FileStoreError("Такого файла платформа не приймала.")
    p = _blob(rec)
    if not p.exists():
        raise FileStoreError(
            "Файла «%s» немає у сховищі — його прибрали з теки поза платформою."
            % _s(rec.get("name")))
    return p


def threshold_text(total) -> str:
    return ("Сховище файлів займає %s. Час ревізії: подивіться резерв місця на "
            "диску і вирішіть, чи продовжувати накопичення, чи скоротити "
            "глибину зберігання. Платформа приймати файли не припиняє."
            % human(total))


def usage() -> dict:
    """Скільки зайнято, скільки файлів і чи час ревізії."""
    d = _load()
    total = int(d.get("total") or 0)
    steps = total // WARN_STEP_BYTES
    ack = int(d.get("ack_steps") or 0)
    warn = steps > ack
    return {"total": total, "total_text": human(total),
            "count": len(d["files"] or {}),
            "step": WARN_STEP_BYTES, "steps": steps, "ack_steps": ack,
            "max_file": MAX_FILE_BYTES,
            "warn": warn, "text": (threshold_text(total) if warn else "")}


def all_files() -> list:
    """Усе, що платформа приймала, — найбільше зверху. Для ревізії (крок 532)."""
    out = []
    for fid, rec in (_load()["files"] or {}).items():
        row = dict(rec)
        row["id"] = fid
        row["present"] = _blob(rec).exists()
        row["size_text"] = human(rec.get("size"))
        out.append(row)
    out.sort(key=lambda r: (-int(r.get("size") or 0), _s(r.get("name"))))
    return out


def all_ids() -> list:
    return list((_load()["files"] or {}).keys())
