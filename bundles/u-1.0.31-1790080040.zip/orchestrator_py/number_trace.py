# -*- coding: utf-8 -*-
"""number_trace.py — ⭐⭐⭐ ОДИН ПИСАР: ЗВІДКИ ЦЕ ЧИСЛО (зміна 620, 20.09.2026).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ: **НАЗВАНЕ ДЖЕРЕЛО ЗАРАХОВУЄТЬСЯ ЗА ПЕРЕВІРЕНЕ.**

Суддя комерційної пропозиції (610) питав про ринкове число рівно одне: чи стоїть
поруч хоч якесь слово-джерело — домен, «за даними», «джерел». Тобто судилась
ФОРМА ПІДПИСУ. Рядок «за даними відкритих джерел ринкова ціна — 400 000 грн»
проходив бездоганно, і клієнт діставав число з голови під виглядом знайденого.
Те саме робили ворота посилань: домен без глибокої адреси вони не судять узагалі.

⭐ ЛАНЦЮГ, ЯКИЙ МУСИТЬ СХОДИТИСЬ (план, крок 1):

    твердження → джерело → фрагмент → дата → розрахунок

Число в документі має рівно два чесні походження, і третього немає:
  • **джерело** — воно лежить у тексті, який платформа СПРАВДІ прочитала; тоді
    ми називаємо сторінку, дослівний рядок із неї і дату читання;
  • **розрахунок** — воно рахується з умов самого документа або стоїть під
    надрукованою поруч викладкою; тоді ми називаємо викладку.
Усе інше — число з голови, і його не можна захистити перед замовником.

⛒ СВІДЧЕННЯ ОГОЛОШУЄ ШЛЯХ, А НЕ ВГАДУЄ ПИСАР. Тому станів три, а не два:
прочитане є · платформа не читала нічого · **шлях свідчень не оголосив**. Третє
не мовчить: мовчазний пропуск — це саме те, чим живе чорний хід (урок 618).

⛒ ДРУГА ПОЛОВИНА РОБОТИ — МОВЧАТИ. Сторож, який кричить на рік «2026», на
власну ціну пропозиції, на номер розділу й на число під власною викладкою, буде
вимкнений на третій день — і тоді не спіймає нічого. Тому тут стільки ж правил
про те, ЧОГО НЕ ЧІПАТИ, скільки про те, що ловити:
  • судяться лише числа В РЯДКУ, ЯКИЙ САМ ПРЕТЕНДУЄ НА ЗОВНІШНЄ ПОХОДЖЕННЯ —
    блок про ринок, конкурентів або з названим джерелом;
  • і лише ГРОШОВІ за формою: із розрядкою тисяч, від 10 000, або з валютою
    впритул. Рік, відсоток, номер і кількість не чіпаємо;
  • число під надрукованою викладкою судить `arith` — другого писаря викладки
    в продукті немає.

⛒ ЧЕСНА МЕЖА, ЯКУ ТРЕБА ЗНАТИ ВЛАСНИКОВІ. Писар звіряє ЗНАЧЕННЯ, а не сенс:
25 000, знайдені на прочитаній сторінці, він зарахує, навіть якщо на тій
сторінці це ціна іншого товару. Проти вигадки він працює; проти чесної помилки
в читанні — ні. Джерело, назване СЛОВАМИ («за даними Держстату»), а не адресою,
він перевірити не може і мовчить про нього — судяться лише адреси.

Модуль без залежностей від платформи: його можна спитати без сервера, офлайн і
за $0.
"""
import re

# ── ЩО ВВАЖАЄМО ЧИСЛОМ ──────────────────────────────────────────────────────
# Дві форми: з розрядкою тисяч («1 224 000», зокрема нерозривними пробілами) і
# звичайна. Кома й крапка всередині — дріб, а не розрядка: «848,6» — одне число.
_SEP = "    "
# 🩸 ХВІСТ РОЗРЯДКИ МУСИТЬ БУТИ РІВНО ТРИ ЦИФРИ. Без заборони четвертої
# «Q1 2026» читалось як число «1 202», і сторож брав у суд квартал. Знайдено
# на живому корпусі 20.09.2026 — вигадані рядки цього не показали.
_TOK = re.compile(r"\d{1,3}(?:[%s]\d{3})+(?!\d)|\d+(?:[.,]\d+)?" % _SEP)

# Валюта й міра грошей упритул за числом.
_HROSHI = re.compile(r"^\s{0,2}(?:грн|₴|\$|USD|EUR|€|тис|тыс|млн|млрд|"
                     r"гривень|гривні|[kKкК]\b)", re.I | re.U)

# ⛒ МАСШТАБ — ЧАСТИНА ЧИСЛА, А НЕ СУСІД. «$25 млн» і «25 000 000» — одне й
# те саме число; порівнювати 25 із 25 означало б зараховувати будь-яке джерело,
# де трапилась двійка з пʼятіркою. Множник читається однаково і в документі, і
# в джерелі, бо числа звідти бере той самий писар.
_MASHTAB = ((re.compile(r"^\s{0,2}млрд", re.I | re.U), 10 ** 9),
            (re.compile(r"^\s{0,2}(?:млн|мільйон)", re.I | re.U), 10 ** 6),
            (re.compile(r"^\s{0,2}(?:тис|тыс|[kKкК]\b)", re.I | re.U), 10 ** 3))

# 🩸 АДРЕСА — НЕ ТВЕРДЖЕННЯ ПРО СВІТ. На живому корпусі писар брав у суд
# числа З ПОСИЛАНЬ: «.../2026/04/87372», «PMC12431166», «ed20230410#Text».
_URL = re.compile(r"https?://\S+|\b[\w-]+\.(?:ua|com|net|org|io|app|ai|info|biz)/\S*",
                  re.I)

# Слова, якими блок сам оголошує, що пише про ЧУЖІ числа, а не про свої.
RYNOK = ("ринк", "конкурент", "бенчмарк", "аналог")

# ⛒ ЧИМ ЧИСЛО НЕ Є. Реквізит, код і номер — не гроші й не твердження про світ.
# 🩸 Без цього рядка розрахунковий рахунок «UA263052990000026001234567890» і
# ЄДРПОУ 12345678 у підвалі документа з доменом пошти ставали «ринковими
# числами без джерела», і чесний документ не поїхав би клієнтові взагалі.
_REKVIZYT = re.compile(
    r"(?:єдрпоу|едрпоу|iban|р\s*/\s*р|рахун\w*|рахівн\w*|мфо|ipн|інн|"
    r"код\w*|№|тел\w*|моб\w*|факс|індекс|картк\w*|паспорт|ліценз\w*|"
    r"реєстр\w*\s*номер|ua\d*)\s*[:№.,-]?\s*$", re.I | re.U)

# Підпис, яким текст посилається на джерело.
DOMEN = re.compile(r"\b(?:https?://)?([a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)*"
                   r"\.(?:ua|com|net|org|io|app|ai|info|biz))\b", re.I)
PIDPYS = re.compile(r"за\s+даними|джерел|відкрит\w*\s+цін|за\s+публікац",
                    re.I | re.U)

# Заголовок прочитаної сторінки в корпусі прогону — його ставить виконавець.
# ⛒ Літера «i» тут буває і кирилична, і латинська (консоль Windows): беремо
# обидві, інакше писар «не побачить» половини прогонів.
STORINKA = re.compile(r"^###\s*Прочитана\s+стор[iі]нка\s*\d*\s*:\s*(\S+)",
                      re.M | re.U)
DATA_RE = re.compile(r"\b\d{2}\.\d{2}\.\d{4}\b")
_FENCE = re.compile(r"```.*?```", re.S)
_KOMENTAR = re.compile(r"<!--.*?-->", re.S)

# Стани походження. Порядок — від певного до непевного.
DZHERELO = "джерело"
ROZRAKHUNOK = "розрахунок"
NIZVIDKY = "нізвідки"


def _znach(tok: str):
    """Значення числа. Повертає int або None, якщо це дріб чи не число."""
    raw = str(tok or "")
    if re.search(r"[.,]\d", raw):
        return None                      # дріб — не грошова сума документа
    digits = re.sub(r"[^\d]", "", raw)
    if not digits:
        return None
    try:
        return int(digits)
    except ValueError:
        return None


def _rozryadka(tok: str) -> bool:
    return bool(re.search(r"\d[%s]\d" % _SEP, str(tok or "")))


def _posylannya(line: str) -> list:
    return [(m.start(), m.end()) for m in _URL.finditer(str(line or ""))]


def chysla_ryadka(line: str) -> list:
    """Числа рядка: [(значення разом із масштабом, як написано, кінець)].

    ⛒ Число всередині адреси пропускається мовчки: адреса — не твердження."""
    t = str(line or "")
    spans = _posylannya(t)
    out = []
    for m in _TOK.finditer(t):
        if any(a <= m.start() < b for a, b in spans):
            continue
        v = _znach(m.group(0))
        if v is None:
            continue
        hvist = t[m.end():m.end() + 8]
        for rx, mult in _MASHTAB:
            if rx.match(hvist):
                v *= mult
                break
        out.append((v, m.group(0), m.end()))
    return out


def sudyme(line: str, val: int, raw: str, kinets: int) -> bool:
    """⛒ ЧИ ЦЕ ВЗАГАЛІ ЧИСЛО ПРО СВІТ. Реквізит, рік і відсоток — не про світ.

    Три ознаки величини, будь-якої досить: розрядка тисяч; валюта впритул; від
    10 000. І три відсікання, будь-якого досить, щоб мовчати: перед числом
    стоїть слово-реквізит або літера; після числа стоїть «%». Рік відсікає сам
    поріг: «2031» — це не десять тисяч, а «2026 грн» — це вже ціна, і мовчати
    про неї було б помилкою в інший бік.
    ⛒ Відсікання йдуть ПЕРШИМИ — хибний крик дорожчий за пропущене число."""
    t = str(line or "")
    pochatok = max(0, kinets - len(str(raw)))
    if _REKVIZYT.search(t[max(0, pochatok - 28):pochatok]):
        return False
    if t[kinets:kinets + 1] == "%":
        return False
    # 🩸 ЧИСЛО, ПРИЛІПЛЕНЕ ДО ЛІТЕРИ ЗЛІВА, — це ідентифікатор, а не сума:
    # «PMC12431166», «UA26305…», «ISO9001». Гроші так не пишуть ніколи.
    if pochatok > 0 and t[pochatok - 1].isalpha():
        return False
    if _HROSHI.match(t[kinets:kinets + 12]):
        return True
    if _rozryadka(raw):
        return True
    # ⛒ Довгий суцільний ряд цифр — це ідентифікатор (номер запису, картки,
    # публікації), а не сума: гроші такого розміру пишуть із розрядкою.
    if len(re.sub(r"[^\d]", "", str(raw))) >= 9 and not _rozryadka(raw):
        return False
    # ⛒ ПОРІГ І Є ПРАВИЛОМ ПРО РІК. Окремого рядка «1900..2100 — не сума»
    # тут стояти не може: до нього чергу не доходить (рік менший за поріг), а
    # якби доходила — він відкидав би чесну ціну «2026 грн». Правило, яке
    # ніколи не спрацьовує, — не охорона, а прикраса, і мутація це показала.
    return val >= 10000


# ── СВІДЧЕННЯ: ЩО ПЛАТФОРМА СПРАВДІ ЧИТАЛА В ЦЬОМУ ПРОГОНІ ──────────────────
def _chastyny_z_tekstu(text: str, name: str, kind: str) -> list:
    """Розбирає прочитане на ІМЕНОВАНІ шматки.

    Корпус прогону вже каже, з якої сторінки кожен шматок, — заголовком
    «### Прочитана сторiнка N: адреса». Заводити для цього другий реєстр
    означало б завести другого писаря тієї самої правди."""
    t = str(text or "")
    marks = list(STORINKA.finditer(t))
    if not marks:
        return [{"name": name, "kind": kind, "text": t}] if t.strip() else []
    out = []
    head = t[:marks[0].start()].strip()
    if head:
        out.append({"name": name or "підсумок пошуку", "kind": "переказ",
                    "text": head})
    for i, m in enumerate(marks):
        kin = marks[i + 1].start() if i + 1 < len(marks) else len(t)
        out.append({"name": m.group(1), "kind": "сторінка",
                    "text": t[m.end():kin]})
    return out


def evidence(parts, read_on: str = "") -> dict:
    """ОГОЛОШЕННЯ свідчень прогону. Порожній перелік — теж оголошення.

    parts — те, що платформа СПРАВДІ мала перед очима: текст відкритих
    сторінок, документи людини, її задача. Рядок або {"name","kind","text"}.
    ⛔ Напрацьоване агентами сюди НЕ кладеться ніколи: інакше вигадане число
    підтверджувало б себе тим, що його написала модель (урок `fact_trust`)."""
    if not read_on:
        from datetime import date
        read_on = date.today().strftime("%d.%m.%Y")
    out = []
    for p in (parts or []):
        if isinstance(p, dict):
            out.extend(_chastyny_z_tekstu(p.get("text"), p.get("name") or "",
                                          p.get("kind") or "прочитане"))
        else:
            out.extend(_chastyny_z_tekstu(p, "", "прочитане"))
    for ch in out:
        ch["chysla"] = {}
        for line in str(ch["text"]).splitlines():
            for val, raw, _k in chysla_ryadka(line):
                ch["chysla"].setdefault(val, line.strip()[:200])
    return {"declared": True, "parts": out, "read_on": read_on}


def run_evidence(live_corpus=None, files_context: str = "", seo_page: str = "",
                 task: str = "", read_on: str = "") -> dict:
    """⭐ ОГОЛОШЕННЯ ПРОГОНУ СКЛАДАЄ ПИСАР, А НЕ ШЛЯХ.

    Інакше завтра другий шлях складе його інакше — забуде документи людини
    або, навпаки, підкладе напрацьоване агентами, — і писар почне
    підтверджувати вигадку тим, що її написала модель. Склад оголошення
    живе тут одним переліком і однаковий для всіх дверей."""
    parts = [{"name": "", "kind": "сторінка", "text": t}
             for t in (live_corpus or []) if str(t or "").strip()]
    if files_context:
        parts.append({"name": "документи замовника", "kind": "файл",
                      "text": files_context})
    if seo_page:
        parts.append({"name": "витяг сторінки", "kind": "сторінка",
                      "text": seo_page})
    if task:
        parts.append({"name": "слова замовника", "kind": "задача", "text": task})
    return evidence(parts, read_on=read_on)


def NICHOHO_NE_CHYTALY(read_on: str = "") -> dict:
    """Чесне оголошення шляху, який джерел не відкривав узагалі."""
    return evidence([], read_on=read_on)


# ── ВІКНА, ЯКІ ПРЕТЕНДУЮТЬ НА ЗОВНІШНЄ ПОХОДЖЕННЯ ───────────────────────────
def _bloky(text: str) -> list:
    """Абзаци документа: [(номер першого рядка, [рядки])]."""
    t = _KOMENTAR.sub(" ", _FENCE.sub(" ", str(text or "")))
    bloky, cur, start = [], [], 0
    for i, line in enumerate(t.split("\n")):
        if line.strip():
            if not cur:
                start = i
            cur.append(line)
        elif cur:
            bloky.append((start, cur))
            cur = []
    if cur:
        bloky.append((start, cur))
    return bloky


def pretenziyni(text: str) -> list:
    """Блоки, що самі оголосили себе твердженням про ЧУЖІ числа.

    ⛒ Судимо БЛОК, а не рядок: живий документ пише підпис джерела в одному
    рядку, а число — у наступному («За даними відкритих прайсів …\\nподібні
    рішення коштують від 25 000 …»)."""
    out = []
    for start, rows in _bloky(text):
        vikno = " ".join(rows)
        low = vikno.lower()
        # ⛒ САМА АДРЕСА В БЛОЦІ ПРЕТЕНЗІЄЮ НЕ Є. Підвал із поштою й сайтом
        # виконавця має домен — і ставав би «твердженням про ринок» разом із
        # усіма реквізитами. Претензію оголошують СЛОВА: про ринок або про
        # джерело. Адреса лише КАЖЕ, яке саме джерело названо.
        if any(w in low for w in RYNOK) or PIDPYS.search(vikno):
            out.append((start, rows))
    return out


def _vyvedene(line: str) -> set:
    """Числа, які стоять під НАДРУКОВАНОЮ ПОРУЧ викладкою.

    ⛒ Питаємо `arith` — єдиного писаря викладки в продукті. Другий розбирач
    ланцюгів розійшовся б із ним на першій же правці."""
    try:
        import arith
        return arith.derived(line)
    except Exception:
        return set()


def trace(text: str, evid=None, own=None) -> list:
    """Ланцюг походження для кожного числа, що претендує на зовнішнє джерело.

    Рядок відповіді: твердження · число · стан · джерело · фрагмент · дата ·
    розрахунок. Порожньо — документ на чужі числа не претендує."""
    own = {int(x) for x in (own or []) if isinstance(x, int) or str(x).isdigit()}
    parts = list((evid or {}).get("parts") or [])
    read_on = (evid or {}).get("read_on") or ""
    rows = []
    for _start, blok in pretenziyni(text):
        vyvedeni = set()
        for line in blok:
            vyvedeni |= _vyvedene(line)
        for line in blok:
            for val, raw, kinets in chysla_ryadka(line):
                if not sudyme(line, val, raw, kinets):
                    continue
                row = {"tverdzhennya": line.strip()[:200], "chyslo": val,
                       "napysano": raw, "dzherelo": "", "fragment": "",
                       "data": "", "rozrakhunok": "", "stan": NIZVIDKY}
                if val in vyvedeni or val in own:
                    row["stan"] = ROZRAKHUNOK
                    row["rozrakhunok"] = (line.strip()[:200] if val in vyvedeni
                                          else "рахується з умов самого документа")
                    rows.append(row)
                    continue
                for ch in parts:
                    if val in ch["chysla"]:
                        row["stan"] = DZHERELO
                        row["dzherelo"] = ch["name"] or ch["kind"]
                        row["vyd"] = ch["kind"]
                        row["fragment"] = ch["chysla"][val]
                        row["data"] = read_on
                        d = DATA_RE.search(ch["chysla"][val])
                        if d:
                            row["data_dzherela"] = d.group(0)
                        break
                rows.append(row)
    return rows


def nazvani_dzherela(text: str) -> list:
    """Адреси, якими документ підписує свої числа (лише в претензійних блоках)."""
    out = []
    for _start, blok in pretenziyni(text):
        for m in DOMEN.finditer(" ".join(blok)):
            d = m.group(1).lower()
            if d not in out:
                out.append(d)
    return out


def _znahidka(code, human):
    return {"code": code, "human": human}


def _perelik(vals) -> str:
    return ", ".join("%s" % ("{:,}".format(v).replace(",", " ")) for v in vals)


def findings(text: str, evid=None, own=None) -> list:
    """Розбіжності ланцюга — людськими словами, які дослівно їдуть складальнику."""
    rows = trace(text, evid, own)
    if not rows:
        return []
    out = []

    # ⛒ ШЛЯХ НЕ ОГОЛОСИВ СВІДЧЕНЬ. Це не «все гаразд» і не «числа немає в
    # джерелі» — це третій стан, і плутати його з двома іншими не можна.
    if not (evid or {}).get("declared"):
        chuzhi = [r["chyslo"] for r in rows if r["stan"] != ROZRAKHUNOK]
        if chuzhi:
            return [_znahidka(
                "bez_svidchen",
                "Документ посилається на зовнішні числа (%s), але цей шлях не "
                "оголосив, що саме платформа читала, — простежити їх нічим. "
                "Або назви джерело, яке платформа справді відкрила, або прибери "
                "число і напиши якісно, без цифри." % _perelik(chuzhi[:6]))]
        return []

    nema = [r for r in rows if r["stan"] == NIZVIDKY]
    if nema:
        prykl = nema[0]
        out.append(_znahidka(
            "slid",
            "Числа %s подано як зовнішні, але жодного з них немає в тому, що "
            "платформа прочитала в цьому прогоні. Клієнт спитає «звідки %s» — і "
            "відповісти буде нічим. Візьми число з джерела, яке справді "
            "відкрито, або прибери його і напиши якісно, без цифри. Рядок: «%s»"
            % (_perelik([r["chyslo"] for r in nema[:6]]),
               _perelik([prykl["chyslo"]]), prykl["tverdzhennya"][:120])))

    chytaly = " ".join((ch.get("name") or "") for ch in
                       ((evid or {}).get("parts") or [])).lower()
    ne_vidkryvaly = [d for d in nazvani_dzherela(text) if d not in chytaly]
    if ne_vidkryvaly:
        out.append(_znahidka(
            "dzherelo_ne_chytaly",
            "Джерело названо (%s), але платформа його НЕ відкривала — це підпис "
            "без підстави, і перевірити його клієнт зможе за хвилину. Назви ті "
            "джерела, які справді прочитано, або прибери посилання."
            % ", ".join(ne_vidkryvaly[:4])))
    return out


def explain(rows) -> str:
    """Ланцюг для людини: твердження → джерело → фрагмент → дата → розрахунок."""
    if not rows:
        return ""
    out = []
    for r in rows:
        out.append("• «%s»" % (r.get("tverdzhennya") or "")[:120])
        out.append("    число: %s" % (r.get("napysano") or r.get("chyslo")))
        if r.get("stan") == ROZRAKHUNOK:
            out.append("    розрахунок: %s" % r.get("rozrakhunok"))
        elif r.get("stan") == DZHERELO:
            out.append("    джерело: %s" % r.get("dzherelo"))
            out.append("    фрагмент: «%s»" % (r.get("fragment") or "")[:140])
            out.append("    прочитано: %s" % r.get("data"))
            if r.get("data_dzherela"):
                out.append("    дата в джерелі: %s" % r["data_dzherela"])
        else:
            out.append("    ⛔ походження не простежено")
    return "\n".join(out)


def korotko(rows) -> str:
    """Один рядок для замовника: скільки чужих чисел простежено і куди."""
    chuzhi = [r for r in (rows or []) if r.get("stan") != ROZRAKHUNOK]
    if not chuzhi:
        return ""
    good = [r for r in chuzhi if r.get("stan") == DZHERELO]
    imena = []
    for r in good:
        d = r.get("dzherelo") or ""
        if d and d not in imena:
            imena.append(d)
    return ("🔎 Зовнішні числа простежено: %d з %d%s"
            % (len(good), len(chuzhi),
               (" (%s; прочитано %s)" % (", ".join(imena[:3]), good[0].get("data")))
               if good else ""))
