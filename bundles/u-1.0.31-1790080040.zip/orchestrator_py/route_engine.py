# -*- coding: utf-8 -*-
"""Детермінований маршрутний двигун через Google Maps Platform.

Замінює OpenRouteService: ORS для нашої мережі виявився недоступним — «read
timeout» саме на розрахунку маршруту (підтверджено наживо 14.07.2026; навіть
сайт maps.openrouteservice.org не будував маршрут з мережі Андрія). Google Maps —
надійний і КОМЕРЦІЙНО дозволений (продукт продається клієнтам). Один ключ
(GOOGLE_MAPS_API_KEY у .env.local) на потрібні сервіси:
  • Geocoding API — назва → координати (і зворотно, для міст уздовж шляху);
  • Routes API (v2:computeRoutes) — РЕАЛЬНА відстань/час/шлях;
  • Places API (searchNearby) — реальні КАФЕ/ЇДАЛЬНІ й ГОТЕЛІ з рейтингами Google
    уздовж траси (АЗС свідомо не наводимо — їхні рейтинги водії й так знають).

Принцип незмінний: точну роботу робить ДВИГУН, а не «пригадування» моделлю.
Публічний інтерфейс (route / format_block / classify / available) — той самий, що
був у ORS-версії, тож executor.py не змінюється. Без ключа/мережі — чесний
{ok: False, note}; ця помилка йде «гучно» в run.json (executor), а не тоне мовчки.
"""
import json
import re
import time
import urllib.request
import urllib.parse
import urllib.error

import config


# ⛒ 623: ДОВІРУ ДО СЕРТИФІКАТА ЗНАЄ ОДИН ПИСАР (netfetch.ssl_context).
# Модуль, що відкриває сокет сам, у клієнта зі старим сховищем коренів ляже
# мовчки — саме це сталось 21.09.2026 з Telegram. Тому кожен вихід питає його.
def _sf_ssl():
    try:
        import netfetch
        return netfetch.ssl_context()
    except Exception:
        return None


_GEOCODE = "https://maps.googleapis.com/maps/api/geocode/json"
_ROUTES = "https://routes.googleapis.com/directions/v2:computeRoutes"
_PLACES = "https://places.googleapis.com/v1/places:searchNearby"

# Зупинки вздовж траси: РІДКО (~3-4 опорні точки) × дві категорії, по кілька закладів.
# Категорії свідомо БЕЗ АЗС (їхні рейтинги водії знають) — лише їжа й ночівля.
_STOP_POINTS = 4          # скільки опорних точок уздовж лінії брати під зупинки
_STOP_PER_CAT = 3         # скільки закладів на точку в кожній категорії
_STOP_RADIUS = 8000       # радіус пошуку навколо точки, метрів (≈ біля траси)
_STOP_MIN_REVIEWS = 5     # відсікаємо шум: заклад з <цього відгуків не показуємо
                          # (рейтинг з 1-2 відгуків ненадійний, не має стояти нагорі)
_STOP_REVIEW_WEIGHT = 50  # «вага довіри» у зваженому рейтингу (скільки відгуків, щоб
                          # довіряти сирій оцінці); більше = сильніше тягне до пріора
_STOP_RATING_PRIOR = 4.0  # пріор (типова пристойна оцінка) для зваженого рейтингу
_STOP_CATS = (
    ("food", ["restaurant", "cafe"]),      # кафе / їдальні
    ("lodging", ["lodging"]),              # готелі / ночівля
)
_STOP_LABEL = {"food": "Кафе та їдальні", "lodging": "Готелі та ночівля"}

# Таймаути й повтори. Повторюємо ЛИШЕ на тимчасових збоях (таймаут / мережа /
# 5xx / 429). На 4xx (поганий ключ, вимкнений сервіс) повтор не допоможе.
_TIMEOUT = 30
_RETRIES = 2          # усього до 3 спроб
_RETRY_PAUSE = 1.5    # базова пауза між спробами (× номер спроби), секунд

# ДОРОЖНІЙ транспорт (укр/англ) → travelMode Google Routes.
_MODES = {
    "car": "DRIVE", "auto": "DRIVE", "авто": "DRIVE", "машина": "DRIVE",
    "автомобіль": "DRIVE", "автівка": "DRIVE",
    "мото": "TWO_WHEELER", "moto": "TWO_WHEELER", "мотоцикл": "TWO_WHEELER",
    "байк": "TWO_WHEELER", "motorcycle": "TWO_WHEELER", "скутер": "TWO_WHEELER",
    "bike": "BICYCLE", "вело": "BICYCLE", "велосипед": "BICYCLE",
    "cycling": "BICYCLE", "bicycle": "BICYCLE",
    "foot": "WALK", "пішки": "WALK", "walking": "WALK", "пішком": "WALK", "хода": "WALK",
}

# Людські підписи режимів (для блоку контексту агента).
_MODE_LABEL = {"DRIVE": "авто", "TWO_WHEELER": "мото", "BICYCLE": "велосипед", "WALK": "пішки"}

# НЕ-дорожні способи: дорожній двигун їх не будує — чесно у веб-пошук (розклади/рейси).
_NON_ROAD = (
    "авіа", "літак", "літаком", "plane", "flight", "flights", "самоліт", "переліт",
    "потяг", "поїзд", "поїздом", "потягом", "train", "залізни", "електричк",
    "автобус", "автобусом", "bus", "маршрутк",
    "громадськ", "public transport", "паром", "ferry", "теплохід", "корабл",
)


def _key() -> str:
    return (config.ENV.get("GOOGLE_MAPS_API_KEY") or "").strip()


def available() -> bool:
    """Чи налаштований маршрутний двигун (є ключ Google)."""
    return bool(_key())


def _is_transient(e) -> bool:
    """Чи варто повторювати запит: так — на таймаут/мережу/перевантаження сервера."""
    if isinstance(e, TimeoutError):
        return True
    if isinstance(e, urllib.error.HTTPError):
        return e.code in (429, 500, 502, 503, 504)
    if isinstance(e, urllib.error.URLError):
        return True
    return False


def _http(req, timeout: int = _TIMEOUT) -> dict:
    """urlopen → read → json із повторами на ТИМЧАСОВИХ збоях. Остання помилка
    (після вичерпання повторів) прокидається далі — щоб причина була видима."""
    last = None
    for attempt in range(_RETRIES + 1):
        try:
            with urllib.request.urlopen(req, timeout=timeout, context=_sf_ssl()) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:
            last = e
            if attempt < _RETRIES and _is_transient(e):
                time.sleep(_RETRY_PAUSE * (attempt + 1))
                continue
            raise
    raise last  # недосяжно


def _get(url: str, params: dict, timeout: int = _TIMEOUT) -> dict:
    req = urllib.request.Request(url + "?" + urllib.parse.urlencode(params),
                                 headers={"User-Agent": "SensFlow-Route/1.0"})
    return _http(req, timeout)


def travel_mode(transport: str) -> str:
    return _MODES.get((transport or "car").lower().strip(), "DRIVE")


# Сумісність зі старим інтерфейсом (деякий код міг звати profile_for).
def profile_for(transport: str) -> str:
    return travel_mode(transport)


_WORD_RE = re.compile(r"[A-Za-zА-Яа-яЁёІіЇїЄєҐґ\']+")


def _words(text: str):
    return _WORD_RE.findall((text or "").lower())


def _hits(text: str, roots) -> bool:
    """Чи є в тексті СЛОВО, яке починається з одного з коренів.

    ⛒⛒⛒ 12.09.2026, ЖИВИЙ ЗАПИТ: «автопоїзд» платформа вважала НЕ дорожнім
    транспортом — бо перевірка шукала ПІДРЯДОК, а всередині сидить «поїзд». Так
    само «мікроавтобус» ловився на «автобус». На цілком нормальному слові
    двигун відмовлявся будувати маршрут і радив шукати розклад рейсів.
    Це той самий клас, що `.env.local.BACKUP_*` і «Бекапи коду»: правило
    дивилось на БУКВИ, а не на слово. Словоформи («поїздом», «автобусом»)
    ловляться початком слова, складені слова — ні."""
    words = _words(text)
    low = (text or "").lower()
    for root in roots:
        r = root.strip().lower()
        if not r:
            continue
        if " " in r:                       # стала фраза («public transport»)
            if r in low:
                return True
            continue
        if any(w.startswith(r) for w in words):
            return True
    return False


def classify(transport: str):
    """Класифікує спосіб пересування:
      ("road", travel_mode)   — дорожній: будує двигун Google;
      ("non_road", label)     — авіа/потяг/автобус тощо: чесний веб-пошук, не двигун.
    Дефолт (нічого не впізнано) — дорожній авто (DRIVE)."""
    t = (transport or "").lower().strip()
    if _hits(t, _NON_ROAD):
        return ("non_road", t or "невідомий спосіб")
    for key, mode in _MODES.items():
        if _hits(t, (key,)):
            return ("road", mode)
    return ("road", "DRIVE")


def geocode(place: str):
    """Назва населеного пункту → (lon, lat, label) або None. Google Geocoding, UA/укр."""
    key = _key()
    if not key or not (place or "").strip():
        return None
    try:
        d = _get(_GEOCODE, {"address": place, "key": key, "language": "uk", "region": "ua"})
    except Exception:
        return None
    if d.get("status") != "OK" or not d.get("results"):
        return None
    r = d["results"][0]
    loc = r["geometry"]["location"]
    return (loc["lng"], loc["lat"], r.get("formatted_address") or place)


def reverse(lon, lat):
    """Координати → назва населеного пункту (locality) або None. Google зворотний геокодинг."""
    key = _key()
    if not key:
        return None
    try:
        d = _get(_GEOCODE, {"latlng": f"{lat},{lon}", "key": key, "language": "uk",
                            "result_type": "locality|administrative_area_level_2"})
    except Exception:
        return None
    if d.get("status") != "OK" or not d.get("results"):
        return None
    for res in d["results"]:
        for c in res.get("address_components", []):
            types = c.get("types", [])
            if "locality" in types or "administrative_area_level_2" in types:
                return c.get("long_name")
    return None


def _decode_polyline(s: str):
    """Розкодовує Google encoded polyline у список (lon, lat)."""
    coords, idx, lat, lng, L = [], 0, 0, 0, len(s)
    while idx < L:
        shift, result = 0, 0
        while True:
            b = ord(s[idx]) - 63
            idx += 1
            result |= (b & 0x1f) << shift
            shift += 5
            if b < 0x20:
                break
        lat += ~(result >> 1) if (result & 1) else (result >> 1)
        shift, result = 0, 0
        while True:
            b = ord(s[idx]) - 63
            idx += 1
            result |= (b & 0x1f) << shift
            shift += 5
            if b < 0x20:
                break
        lng += ~(result >> 1) if (result & 1) else (result >> 1)
        coords.append((lng / 1e5, lat / 1e5))
    return coords


def _sample(coords, n=8):
    """~n рівномірних проміжних точок геометрії (без самих кінців)."""
    if not coords or len(coords) <= 2:
        return []
    step = len(coords) / (n + 1)
    idxs = sorted(set(int(step * (i + 1)) for i in range(n)))
    return [coords[i] for i in idxs if 0 < i < len(coords) - 1]


def _nearby(lon, lat, included_types, radius=_STOP_RADIUS, per=_STOP_PER_CAT):
    """Реальні заклади потрібних типів навколо точки (Google Places New: searchNearby).
    Повертає (список, note): note=None якщо ок; note=коротка причина, якщо API впав
    (напр. сервіс вимкнено / поганий ключ) — щоб «гучний фейл» дійшов у run.json, а не
    тонув. Беремо ЛИШЕ заклади з рейтингом (обіцянка «реальні рейтинги»)."""
    key = _key()
    if not key:
        return [], "немає GOOGLE_MAPS_API_KEY"
    body = {
        "includedTypes": included_types,
        "maxResultCount": per,
        "rankPreference": "POPULARITY",
        "languageCode": "uk",
        "regionCode": "UA",
        "locationRestriction": {
            "circle": {"center": {"latitude": lat, "longitude": lon}, "radius": radius}
        },
    }
    headers = {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": key,
        "X-Goog-FieldMask": ("places.displayName,places.rating,"
                             "places.userRatingCount,places.primaryTypeDisplayName"),
        "User-Agent": "SensFlow-Route/1.0",
    }
    req = urllib.request.Request(_PLACES, data=json.dumps(body).encode("utf-8"), headers=headers)
    try:
        d = _http(req)
    except urllib.error.HTTPError as e:
        try:
            msg = e.read().decode("utf-8")[:160]
        except Exception:
            msg = str(e)[:160]
        return [], f"HTTP {e.code} {msg}"
    except Exception as e:
        return [], f"{type(e).__name__} {str(e)[:120]}"
    out = []
    for p in (d.get("places") or []):
        nm = ((p.get("displayName") or {}).get("text") or "").strip()
        rating = p.get("rating")
        if not nm or rating is None:   # без назви/рейтингу — пропускаємо
            continue
        out.append({
            "name": nm,
            "rating": rating,
            "reviews": p.get("userRatingCount") or 0,
            "kind": ((p.get("primaryTypeDisplayName") or {}).get("text") or "").strip(),
        })
    return out, None


def _weighted_score(it):
    """Зважений рейтинг (IMDB-стиль): тягне заклади з малим числом відгуків до пріора,
    щоб «5★ з 1 відгуку» не стояло вище за «4.6★ з 3750». score =
    v/(v+m)·R + m/(v+m)·C, де v=відгуки, R=рейтинг, m=вага довіри, C=пріор."""
    v = it.get("reviews") or 0
    R = it.get("rating") or 0
    m = _STOP_REVIEW_WEIGHT
    return (v / (v + m)) * R + (m / (v + m)) * _STOP_RATING_PRIOR


def places_along(pts):
    """Уздовж заданих опорних точок траси — реальні кафе/їдальні й готелі з рейтингами
    Google. pts — список (lon, lat). Повертає (stops, note):
      stops = {"food": [...], "lodging": [...]}  (кожен заклад: name/rating/reviews/kind/town)
      note  = None якщо жодного збою; інакше — перша причина (для run.json/чесного блоку).
    Дублі в межах категорії прибираємо за назвою; шум (мало відгуків) відсікаємо;
    готелі-ресторани не дублюємо між food/lodging; сортуємо за ЗВАЖЕНИМ рейтингом.
    Місто-зона береться зворотним геокодингом опорної точки."""
    buckets = {cat: [] for cat, _ in _STOP_CATS}
    seen = {cat: set() for cat, _ in _STOP_CATS}
    note = None
    for (lon, lat) in (pts or []):
        town = reverse(lon, lat)
        for cat, types in _STOP_CATS:
            items, err = _nearby(lon, lat, types)
            if err and note is None:
                note = err
            for it in items:
                low = it["name"].lower()
                if low in seen[cat]:
                    continue
                seen[cat].add(low)
                it["town"] = town
                buckets[cat].append(it)
    # Шум геть: заклади з надто малою кількістю відгуків (ненадійний рейтинг).
    for cat in buckets:
        buckets[cat] = [it for it in buckets[cat]
                        if (it.get("reviews") or 0) >= _STOP_MIN_REVIEWS]
    # Без дублів між категоріями: готель-ресторан лишаємо серед готелів, прибираємо
    # з «кафе» (ночівля — специфічніша ознака закладу).
    lodging_names = {it["name"].lower() for it in buckets.get("lodging", [])}
    if "food" in buckets:
        buckets["food"] = [it for it in buckets["food"]
                           if it["name"].lower() not in lodging_names]
    # Сортування за ЗВАЖЕНИМ рейтингом (число відгуків має значення), тоді сирий рейтинг.
    for cat in buckets:
        buckets[cat].sort(key=lambda x: (_weighted_score(x), x.get("rating") or 0),
                          reverse=True)
    return buckets, note


def route(start: str, end: str, transport: str = "car", waypoints=None,
          optimize: bool = False, geo_cache=None,
          order_scope: str = "engine_partial") -> dict:
    """Реальний оптимальний маршрут start→(через waypoints)→end через Google Routes.
    waypoints — список назв проміжних пунктів у порядку. Повертає {ok, ...} або
    {ok:False, note}. Не-дорожній транспорт (авіа/потяг/громадський) двигун не будує.

    ⭐⭐⭐ optimize=True — «ВИЗНАЧ ЧЕРГУ». Живий запит 12.09.2026: розвантажити в
    трьох містах за один рейс і визначити чергу об'їзду. Доти двигун віз точки в
    тому порядку, в якому їх назвала людина, і цей порядок видавався за
    оптимальний. Черга об'їзду — задача з реальними відстанями, і рахує її
    двигун: ми просимо `optimizeWaypointOrder` і переставляємо точки за його
    відповіддю. Модель тут не голосує.

    ⛒ 574. `order_scope` — ЧЕСНЕ ІМʼЯ ТОГО, ЩО САМЕ ВПОРЯДКОВАНО. Google уміє
    переставляти лише ПРОМІЖНІ точки: фініш прибитий цвяхом. Тому звичайний
    виклик (кінець назвала людина) дає найбільше `engine_partial` — і блок для
    агента так і скаже. `engine_full` має право поставити лише той, хто подбав
    про фініш окремо (див. route_delivery).

    `geo_cache` — спільний словник назва → координати. Перебір фінішів кличе
    route() кілька разів на ті самі пункти; без кеша ми платили б за той самий
    геокодинг стільки ж разів."""
    mode, tmode = classify(transport)
    if mode == "non_road":
        return {"ok": False, "mode": "non_road", "transport": tmode,
                "note": (f"спосіб «{tmode}» — не дорожній маршрут (авіа/потяг/автобус/"
                         "громадський). Дорожній двигун його не будує: сполучення й розклад "
                         "треба шукати у мережі та чесно вказувати джерело.")}
    key = _key()
    if not key:
        return {"ok": False, "note": "маршрутний двигун не налаштований (немає GOOGLE_MAPS_API_KEY у .env.local)"}
    # 1) Геокодимо всі пункти (щоб мати координати й гарні підписи, і зловити «не знайдено»).
    names = [start] + [w for w in (waypoints or []) if (w or "").strip()] + [end]
    cache = geo_cache if isinstance(geo_cache, dict) else None
    geo = []
    for nm in names:
        g = cache.get(nm) if cache is not None else None
        if g is None:
            g = geocode(nm)
            if not g:
                return {"ok": False, "note": f"не вдалося знайти пункт: «{nm}» (Google Geocoding)"}
            if cache is not None:
                cache[nm] = g
        geo.append(g)
    # 2) Будуємо маршрут (Routes API v2:computeRoutes).
    body = {
        "origin": {"location": {"latLng": {"latitude": geo[0][1], "longitude": geo[0][0]}}},
        "destination": {"location": {"latLng": {"latitude": geo[-1][1], "longitude": geo[-1][0]}}},
        "travelMode": tmode,
        "polylineQuality": "OVERVIEW",
    }
    inter = geo[1:-1]
    if inter:
        body["intermediates"] = [{"location": {"latLng": {"latitude": g[1], "longitude": g[0]}}}
                                 for g in inter]
        if optimize:
            body["optimizeWaypointOrder"] = True
    fields = ("routes.distanceMeters,routes.duration,"
              "routes.legs.distanceMeters,routes.legs.duration,"
              "routes.polyline.encodedPolyline")
    if optimize and inter:
        fields += ",routes.optimizedIntermediateWaypointIndex"
    headers = {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": key,
        "X-Goog-FieldMask": fields,
        "User-Agent": "SensFlow-Route/1.0",
    }
    req = urllib.request.Request(_ROUTES, data=json.dumps(body).encode("utf-8"), headers=headers)
    try:
        d = _http(req)
    except urllib.error.HTTPError as e:
        try:
            msg = e.read().decode("utf-8")[:220]
        except Exception:
            msg = str(e)[:220]
        return {"ok": False, "note": f"двигун недоступний: HTTP {e.code} {msg}"}
    except Exception as e:
        return {"ok": False, "note": f"двигун недоступний: {type(e).__name__} {str(e)[:160]}"}
    # 3) Розбираємо відповідь.
    routes = d.get("routes") or []
    if not routes:
        return {"ok": False, "note": f"двигун не повернув маршрут: {json.dumps(d)[:200]}"}
    r0 = routes[0]
    # ⛒ ЧЕРГА ОБ'ЇЗДУ — ВІДПОВІДЬ ДВИГУНА. Переставляємо точки ДО того, як
    # складати плечі: інакше підписи плечей лишились би від людського порядку,
    # і документ показав би правильні числа під неправильними назвами.
    order_idx = r0.get("optimizedIntermediateWaypointIndex")
    optimized = False
    if optimize and isinstance(order_idx, list) and len(order_idx) == len(geo) - 2:
        try:
            mid = [geo[1:-1][i] for i in order_idx]
            geo = [geo[0]] + mid + [geo[-1]]
            optimized = True
        except Exception:
            optimized = False
    dist_km = round(r0.get("distanceMeters", 0) / 1000, 1)
    dur_raw = str(r0.get("duration", "0s"))
    try:
        dur_h = round(int(dur_raw.rstrip("s")) / 3600, 2)
    except Exception:
        dur_h = 0
    # РОЗБИВКА ПО ПЛЕЧАХ: реальні відстань/час КОЖНОГО відрізка між заданими точками
    # (Звідки→Через1→…→Куди). Google уже їх дав — забираємо як ЄДИНЕ джерело правди,
    # щоб агент не ділив загальну цифру сам (це була вигадка). Плечі > 1 лише коли є
    # проміжні точки; підписи беремо з geo (гарні назви пунктів у порядку).
    legs = []
    labels = [g[2] for g in geo]
    for i, lg in enumerate(r0.get("legs") or []):
        lk = round(lg.get("distanceMeters", 0) / 1000, 1)
        lraw = str(lg.get("duration", "0s"))
        try:
            lh = round(int(lraw.rstrip("s")) / 3600, 2)
        except Exception:
            lh = 0
        legs.append({
            "from": labels[i] if i < len(labels) else "?",
            "to": labels[i + 1] if i + 1 < len(labels) else "?",
            "distance_km": lk, "duration_h": lh,
        })
    # Міста + реальні зупинки вздовж маршруту — по вибіркових точках полілінії.
    # Міста: зворотний геокодинг ~8 точок. Зупинки (кафе/готелі з рейтингами): РІДКО,
    # ~_STOP_POINTS опорних точок через Places. stops_note — «гучний фейл» для run.json.
    towns = []
    stops = {cat: [] for cat, _ in _STOP_CATS}
    stops_note = None
    enc = (r0.get("polyline") or {}).get("encodedPolyline")
    if enc:
        try:
            pts = _decode_polyline(enc)
            for lon, lat in _sample(pts, 8):
                t = reverse(lon, lat)
                if t and t not in towns:
                    towns.append(t)
            stops, stops_note = places_along(_sample(pts, _STOP_POINTS))
        except Exception as e:
            if stops_note is None:
                stops_note = f"{type(e).__name__} {str(e)[:120]}"
    return {"ok": True, "start": geo[0][2], "end": geo[-1][2], "transport": tmode,
            "via": [g[2] for g in geo[1:-1]],
            # повна черга руху людськими назвами — саме вона йде в документ
            "order": [g[2] for g in geo],
            "order_optimized": optimized,
            # ⛒ 574: чим саме є цей порядок. «engine_partial» — двигун переставив
            # ПРОМІЖНІ точки, а фініш заданий ззовні; «engine_full» — впорядковано
            # ВСІ точки розвантаження (кільцевий рейс або перебір фінішів).
            "order_source": (order_scope if optimized else "human"),
            "distance_km": dist_km, "duration_h": dur_h,
            "legs": legs,
            "towns_along": towns, "stops": stops, "stops_note": stops_note, "roads": []}



# ⛒ 574. Стеля перебору фінішів: скільки прорахунків двигуна дозволено спалити на
# пошук найвигіднішої ОСТАННЬОЇ точки. Перебір коштує грошей на кожен виклик, а
# виграш від нього швидко спадає. Понад стелю фініш беремо як названий, і ЧЕСНО
# кажемо, що впорядковано лише середину, — півроботи під вивіскою цілої гірше за
# чесну півроботу.
MAX_FINISH_TRIES = 5


def route_delivery(start: str, drops, transport: str = "car",
                   own_vehicle: bool = True) -> dict:
    """⭐⭐⭐ РОЗВІЗНИЙ РЕЙС: база і кілька точок розвантаження, порядок не заданий.

    Друга модель світу платформи. Перша — подорож «звідки → куди, через що»; у ній
    фініш називає людина. Тут людина називає ТОЧКИ ДОСТАВКИ, і жодна з них не
    привілейована. Доки такої моделі не було, розбирач мусив одну з точок
    призначити кінцем — а Google оптимізує лише ПРОМІЖНІ точки, фініш прибитий
    цвяхом. Виходило, що останню точку ставила МОДЕЛЬ, а в документ ішов рядок
    «чергу об'їзду визначив двигун». Половина роботи під вивіскою цілої.

    ⭐ Два випадки, і в кожному фініш має чесне походження (доменна поправка
    власника, 12.09.2026):

      • own_vehicle=True — СВІЙ транспорт: рейс кільцевий, машина вертається на
        базу. Фініш = місце завантаження, отже ВСІ точки розвантаження стають
        проміжними, і двигун упорядковує їх усі за ОДИН прорахунок. Дешево і
        повно. Пробіг назад — реальні гроші, і він у розрахунку є.

      • own_vehicle=False — НАЙМАНИЙ транспорт: куди їхати після останнього
        розвантаження, вирішує власник машини, тож кінець справді вільний.
        Двигун перебирає кожну точку як кандидата на останню (до MAX_FINISH_TRIES
        прорахунків) і бере найдешевший обхід ЦІЛКОМ.

    Модель не голосує ніде: вона лише називає пункти й каже, чий транспорт.
    """
    pts = [d.strip() for d in (drops or []) if isinstance(d, str) and d.strip()]
    if not (start or "").strip() or not pts:
        return {"ok": False, "note": "розвізний рейс без бази або без точок розвантаження"}
    cache = {}                      # один геокодинг на пункт, а не на кожен перебір

    # ── СВІЙ ТРАНСПОРТ: коло. Один виклик, усі точки — проміжні.
    if own_vehicle:
        r = route(start, start, transport, pts, optimize=len(pts) > 1,
                  geo_cache=cache, order_scope="engine_full")
        if r.get("ok"):
            r["return_to_base"] = True
            r["drops_count"] = len(pts)
            r["finish_tried"] = 0
        return r

    # ── НАЙМАНИЙ ТРАНСПОРТ: кінець вільний.
    if len(pts) == 1:
        r = route(start, pts[0], transport, [], geo_cache=cache)
        if r.get("ok"):
            r["return_to_base"] = False
            r["drops_count"] = 1
            r["finish_tried"] = 0
        return r

    if len(pts) > MAX_FINISH_TRIES:
        # Перебір не по кишені: фініш беремо як названий, середину впорядковуємо,
        # і в блоці це названо частковим — без слова «чергу визначив двигун».
        r = route(start, pts[-1], transport, pts[:-1], optimize=True,
                  geo_cache=cache, order_scope="engine_partial")
        if r.get("ok"):
            r["return_to_base"] = False
            r["drops_count"] = len(pts)
            r["finish_tried"] = 0
            r["finish_note"] = ("точок розвантаження %d — більше за стелю перебору %d; "
                                "останньою взято названу замовником"
                                % (len(pts), MAX_FINISH_TRIES))
        return r

    best, last_bad = None, None
    for i, fin in enumerate(pts):
        rest = [p for j, p in enumerate(pts) if j != i]
        r = route(start, fin, transport, rest, optimize=len(rest) > 1,
                  geo_cache=cache, order_scope="engine_full")
        if not r.get("ok"):
            last_bad = r
            continue
        if best is None or (r.get("distance_km") or 0) < (best.get("distance_km") or 0):
            best = r
    if best is None:
        return last_bad or {"ok": False, "note": "двигун не побудував жодного варіанта обходу"}
    best["return_to_base"] = False
    best["drops_count"] = len(pts)
    best["finish_tried"] = len(pts)
    # ⛒ Два пункти — це вибір фінішу без перестановки середини: порядок усе одно
    # визначений двигуном ЦІЛКОМ, бо середини просто немає.
    best["order_source"] = "engine_full"
    return best


def _fmt_legs(r: dict) -> str:
    """Секція «РОЗБИВКА ПО ПЛЕЧАХ»: реальні відстань/час кожного відрізка з Google.
    Показуємо лише коли плечей більше одного (є проміжні точки); одне плече = вся
    траса, окрема розбивка не потрібна."""
    legs = r.get("legs") or []
    if len(legs) <= 1:
        return ""
    lines = ["\n## РОЗБИВКА ПО ПЛЕЧАХ (реальні відрізки з Google — ЄДИНЕ джерело правди)\n"
             "Відстань і час КОЖНОГО відрізка бери ЛИШЕ звідси. НЕ дроби маршрут на "
             "дрібніші шматки з власними цифрами — таких даних немає.\n"]
    for lg in legs:
        h = int(lg["duration_h"])
        m = round((lg["duration_h"] - h) * 60)
        lines.append(f"  - {lg['from']} → {lg['to']}: {lg['distance_km']} км, ~{h} год {m} хв")
    return "\n".join(lines) + "\n"


def _fmt_stops(r: dict) -> str:
    """Секція «РЕАЛЬНІ ЗУПИНКИ» для блоку агента: кафе/їдальні й готелі з рейтингами
    Google — ЄДИНЕ джерело правди про заклади. Порожньо / збій Places → чесно, без вигадок."""
    stops = r.get("stops") or {}
    note = r.get("stops_note")
    lines, any_found = [], False
    for cat, _types in _STOP_CATS:
        items = stops.get(cat) or []
        if not items:
            continue
        any_found = True
        lines.append(f"**{_STOP_LABEL.get(cat, cat)}:**")
        for it in items:
            rv = f", {it['reviews']} відгуків" if it.get("reviews") else ""
            tw = f" — {it['town']}" if it.get("town") else ""
            kind = f" ({it['kind']})" if it.get("kind") else ""
            lines.append(f"  - {it['name']}{kind}: {it['rating']}★{rv}{tw}")
    head = ("\n## РЕАЛЬНІ ЗУПИНКИ — кафе, їдальні й готелі (рейтинги Google — ЄДИНЕ джерело правди)\n"
            "Заклади й рейтинги бери ЛИШЕ з цього переліку; НЕ вигадуй назв, «зірок» і "
            "кількості відгуків. АЗС тут свідомо немає — за потреби заправку підкажи "
            "загально, без вигаданого рейтингу.\n")
    if any_found:
        return head + "\n".join(lines) + "\n"
    if note:
        return (head + f"Реальні заклади принести НЕ вдалося (причина: {note}). "
                "НЕ вигадуй кафе/готелі й рейтинги — чесно зазнач, що перевірених "
                "закладів уздовж маршруту немає.\n")
    return (head + "Уздовж маршруту рейтингових кафе/готелів не знайдено. "
            "НЕ вигадуй заклади — так і зазнач.\n")



def _fmt_order(r: dict) -> str:
    """⛒ 574. ОДИН ПИСАР РЯДКА ПРО ЧЕРГУ ОБ'ЇЗДУ — і він не каже більше, ніж
    зроблено. Google уміє переставляти лише ПРОМІЖНІ точки, тому «чергу визначив
    двигун» має право звучати тільки там, де впорядковано ВСІ точки розвантаження:
    кільцевий рейс своєю машиною або перебір фінішів для найманої. Там, де кінець
    назвала людина, так і сказано — інакше документ везе замовнику впевненість
    поверх напівправди."""
    if not r.get("order_optimized") and r.get("order_source") != "engine_full":
        return ""
    order = " → ".join(r.get("order") or [])
    if r.get("order_source") == "engine_full":
        line = ("- ⛒ ЧЕРГУ ОБ'ЇЗДУ ВИЗНАЧИВ ДВИГУН за реальними відстанями: %s\n"
                "  Саме цей порядок іде в документ. Не переставляй його «як логічніше».\n"
                % order)
        if r.get("return_to_base"):
            line += ("  Рейс кільцевий: машина вертається на базу, і зворотний пробіг "
                     "уже всередині цих кілометрів.\n")
        return line
    line = ("- ⛒ Порядок ПРОМІЖНИХ точок визначив двигун за реальними відстанями: %s\n"
            "  Кінцевий пункт заданий замовником і НЕ переставлявся — тобто впорядкована\n"
            "  середина маршруту, а не весь обхід. Так і пиши в документі.\n" % order)
    if r.get("finish_note"):
        line += "  Причина: %s.\n" % r["finish_note"]
    return line



def _fmt_mileage(r: dict) -> str:
    """⛒ 575. ОСТАТОЧНИЙ ПРОБІГ РЕЙСУ — І ЗАБОРОНА ЙОГО ПЕРЕРАХОВУВАТИ.

    🩸 12.09.2026, Шепетівка → Запоріжжя: двигун дав 848,6 км, у документ пішло
    1 697,2 — агент помножив на два «бо транспорт свій, рейс кільцевий» і дописав
    зворотний порожній пробіг, якого двигун не рахував. Рейс подорожчав на 19
    тисяч гривень; при цьому час у дорозі лишився в один бік — документ сам собі
    суперечив.

    ⛒ КЛАС: правило «відстань лише з двигуна» трималось на тому, що взяти її
    більше НІЗВІДКИ. Щойно в методиці з'явилось правило, з якого кілометри можна
    вивести самому, — воно й спрацювало. Тому заборона стоїть тут, у самому
    блоці, поруч із числом: не в дусі тексту, а в даних."""
    km = r.get("distance_km")
    if not km:
        return ""
    if r.get("return_to_base"):
        return ("\n## ⛒ ПРОБІГ РЕЙСУ — ОСТАТОЧНИЙ\n"
                "%s км. Рейс кільцевий: повернення на базу ВЖЕ ВСЕРЕДИНІ цього числа.\n"
                "Не додавай зворотного плеча вдруге, не множ це число ні на що — "
                "подвоювати пробіг ЗАБОРОНЕНО.\n" % km)
    return ("\n## ⛒ ПРОБІГ РЕЙСУ — ОСТАТОЧНИЙ\n"
            "%s км — це весь шлях, який порахував двигун, від пункту завантаження "
            "до пункту розвантаження.\n"
            "Повернення порожняком двигун НЕ рахував і в це число воно НЕ входить. "
            "Якщо замовникові потрібне повернення — це окреме плече, і кілометри до "
            "нього мусить дати двигун, а не ти.\n"
            "Не множ це число на два і не додавай до нього своїх кілометрів — "
            "подвоювати пробіг ЗАБОРОНЕНО.\n" % km)


def format_block(r: dict) -> str:
    """Готовий блок для контексту агента (ЄДИНЕ джерело правди про шлях)."""
    if r.get("mode") == "non_road":
        return ("## СПОСІБ ПЕРЕСУВАННЯ — НЕ ДОРОЖНІЙ (двигун не будує)\n"
                f"{r.get('note')}\n"
                "Знайди реальні сполучення (рейси/розклад) у мережі, наведи джерела й час; "
                "НЕ вигадуй номери рейсів, ціни чи розклад із памʼяті. Якщо даних немає — так і скажи.")
    if not r.get("ok"):
        return ("## РЕАЛЬНИЙ МАРШРУТ — НЕ ПОБУДОВАНО\n"
                f"Причина: {r.get('note')}. НЕ вигадуй маршрут із памʼяті; чесно зазнач, "
                "що маршрутний двигун недоступний, і попроси уточнити пункти.")
    hours = int(r["duration_h"])
    mins = round((r["duration_h"] - hours) * 60)
    tlabel = _MODE_LABEL.get(r.get("transport"), r.get("transport"))
    return ("## РЕАЛЬНИЙ МАРШРУТ (з маршрутного двигуна Google — ЄДИНЕ джерело правди про шлях)\n"
            "Відстань, час і перелік міст бери ЛИШЕ звідси. НЕ додумуй інших міст "
            "і не «випрямляй» шлях через відоміші міста — це реальний оптимальний маршрут.\n\n"
            f"- Звідки: {r['start']}\n"
            + (f"- Через (проміжні точки, у цьому порядку): {', '.join(r['via'])}\n" if r.get('via') else "")
            + _fmt_order(r)
            + (f"- Куди: повернення на базу ({r['end']}) — це реальний пробіг, "
               "він у розрахунку рейсу\n" if r.get("return_to_base")
               else f"- Куди: {r['end']}\n")
            + 
            f"- Транспорт: {tlabel}\n"
            f"- Відстань: {r['distance_km']} км\n"
            f"- Час у дорозі: ~{hours} год {mins} хв\n"
            f"- Міста вздовж маршруту (зони пошуку зупинок): {', '.join(r['towns_along']) or '—'}\n"
            + _fmt_mileage(r)
            + _fmt_legs(r)
            + _fmt_stops(r))
