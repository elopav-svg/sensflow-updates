# -*- coding: utf-8 -*-
"""entity.py — ТОТОЖНІСТЬ: як річ називається на всю платформу (зміна 169, 13.08.2026).

⭐⭐⭐ КОРІНЬ. Слово Андрія 12.08.2026: «Платформа тоді називається платформою, коли
всі сутності, що на ній представлені, взаємоповʼязані, комунікують між собою, і
ведеться загальний протокол усіх дій.»

Досі кожен домен звав ту саму річ по-своєму: CRM — рядком назви клієнта, Task Desk —
номером задачі, прогін — іменем теки, реєстр — ідентифікатором системи. Тому будь-яка
спроба зʼєднати «цей клієнт → ця задача → цей прогін → ці гроші» була склеюванням за
СХОЖІСТЮ НАЗВ. Рівно цей клас уже коштував нам грошей у зміні 159 (два писарі одного
документа, одружені за першими 32 знаками назви). Робити так із КЛІЄНТАМИ — дорожче.

ЩО РОБИТЬ ЦЕЙ ФАЙЛ:
  • дає ОДНЕ посилання на річ: `party:p0004` · `person:acc_3` · `task:128` ·
    `run:run-2026-08-12T10-40-39` · `system:tender_writer`;
  • вміє прочитати таке посилання назад і сказати людську назву для екрана.

⛔ ЧОГО ЦЕЙ ФАЙЛ НЕ РОБИТЬ — І ЦЕ ГОЛОВНЕ. Він **НІЧОГО НЕ ЗБЕРІГАЄ**. Хто такий
контрагент — знає `parties.py`; хто така людина — `taskdesk_identity`; що це за
задача — `taskdesk_tasks`; що за прогін — `store`; що за система — `registry`.
Другої таблиці клієнтів не заводимо: саме на ДВОХ ПИСАРЯХ ОДНІЄЇ ПРАВДИ ми горіли
найчастіше. Тут лише нормалізація імені й питання до власника домену.

ЗАКРИТИЙ СЛОВНИК ВИДІВ (урок зміни 162). Вид, якого немає у списку нижче, — це
ВІДМОВА З ПРИЧИНОЮ, а не тиха підстановка сусіднього. У 162 словник умінь паспорта
був закритий, слова «пошта» в платформі не існувало — і «читач пошти» мовчки отримав
веб-пошук. Повторювати це на сутностях не будемо.

⚠ ПИТАННЯ ДО ВЛАСНИКА ДОМЕНУ НЕ СМІЄ ЗАВАЛИТИ РОБОТУ. `title()` і `exists()` ніколи
не кидають: домен може бути вимкнений (Task Desk — платний рівень), файл може не
читатись. Тоді відповідь — сама тотожність, а не аварія. Але НЕВІДОМИЙ ВИД — це
завжди відмова: це помилка коду, а не стан машини.
"""

# Власників домену імпортуємо ЛИШЕ всередині функцій: `crm` імпортує `parties`,
# `taskdesk_tasks` — нерв і людей, і будь-який верхній імпорт тут закільцював би
# половину платформи заради одного рядка назви.

KIND_PARTY = "party"      # контрагент із довідника (`parties.py`) — клієнт/постачальник/партнер
KIND_PERSON = "person"    # людина-акаунт платформи (`taskdesk_identity`)
KIND_TASK = "task"        # задача Task Desk (`taskdesk_tasks`)
KIND_RUN = "run"          # прогін системи (`store`, `runs/run-*`)
KIND_SYSTEM = "system"    # система з реєстру (`registry`)
# ⭐ ШОСТИЙ ВИД ЗАВЕДЕНО СВІДОМО (13.08.2026). Проєкт хребта називав пʼять видів,
# але точка врізки «чужі сервіси» лишалась без ГОЛОВНОЇ РЕЧІ: вихід назовні — це не
# прогін і не система, це дотик до Gmail чи Google Calendar. Без свого виду він
# або губився б, або мовчки приписувався сусідній сутності — рівно та біда, від
# якої нас лікувала зміна 162. Власник тотожності — `connector_tools.TOOLS`.
KIND_CONNECTOR = "connector"

# ⭐⭐⭐ СЬОМИЙ ВИД — УГОДА (крок C1, 15.08.2026). Досі угода була не річчю, а
# НАЗВОЮ КАРТКИ в `crm/clients.json` — тому на неї не можна було ні вказати,
# ні звʼязати її, ні написати про неї рядок протоколу. Головна вимога Андрія 14.08
# — перехід у два боки в один клік — для угоди не виконувалась взагалі.
# Власник тотожності — `deals.py` (`crm/deals.json`).
KIND_DEAL = "deal"

# ⭐⭐⭐ ВОСЬМИЙ І ДЕВ’ЯТИЙ ВИДИ — ОРГСТРУКТУРА (зміна 358, 30.08.2026).
# КОРІНЬ. Оргструктура — єдиний домен платформи, який НЕ пише в загальний
# протокол, а веде власний куций слід усередині файла стану. Це не недогляд:
# рядок протоколу вимагає ГОЛОВНОЇ РЕЧІ, а підрозділу як речі в платформі
# не існувало взагалі. Звідси ж і те, чого просив Андрій: «історію змін у компанії»
# ніде не було видно.
# ⛒ ДВА ВИДИ, А НЕ ОДИН, СВІДОМО. Підрозділ — річ зі своєю назвою й
# своєю долею (його ліквідують і відновлюють). А посада чи горизонт належать
# КОМПАНІЇ цілком, і приписати їх якомусь одному підрозділу було б неправдою.
# Власник тотожності обох — `taskdesk_people.py`.
KIND_UNIT = "unit"        # підрозділ компанії (`taskdesk_people`)
KIND_ORG = "org"          # оргструктура як ціле — єдиний номер `org:company`
ORG_COMPANY = "company"   # іншого номера в цього виду немає й не буде

KIND_GOOD = "good"        # товар або послуга з бази клієнта (`goods.py`)
KIND_FIELD = "field"      # оголошене поле картки (`card_fields.py`)

# ⭐⭐⭐ ЗАМОВЛЕННЯ РОЗРОБНИКОВІ (зміна 616, 20.09.2026). Це НЕ угода: угода —
# те, що ми продаємо, а замовлення — те, що ми КУПУЄМО в розробника платформи.
# Приписати його угоді означало б завести в чужій воронці рядок, якого там
# ніколи не було. Власник тотожності — `shop.py`.
KIND_ORDER = "order"

KINDS = (KIND_PARTY, KIND_PERSON, KIND_TASK, KIND_RUN, KIND_SYSTEM, KIND_CONNECTOR,
         KIND_DEAL, KIND_UNIT, KIND_ORG, KIND_GOOD, KIND_FIELD, KIND_ORDER)

KIND_NAMES = {
    KIND_PARTY: "контрагент",
    KIND_PERSON: "людина",
    KIND_TASK: "задача",
    KIND_RUN: "прогін",
    KIND_SYSTEM: "система",
    KIND_CONNECTOR: "чужий сервіс",
    KIND_DEAL: "угода",
    KIND_UNIT: "підрозділ",
    KIND_ORG: "оргструктура",
    KIND_GOOD: "товар або послуга",
    KIND_FIELD: "поле картки",
    KIND_ORDER: "замовлення розробнику",
}

SEP = ":"
MAX_IDENT = 200           # довше — це вже не ідентифікатор, а текст


class EntityError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def check_kind(kind: str) -> str:
    """Вид сутності зі ЗАКРИТОГО словника. Невідомий — відмова."""
    k = _s(kind)
    if k not in KINDS:
        raise EntityError(
            "Невідомий вид сутності «%s». Платформа знає лише: %s. "
            "Новий вид треба спершу завести у словнику `entity.KINDS`, "
            "інакше він мовчки підміниться сусіднім." % (k, ", ".join(KINDS)))
    return k


def ref(kind: str, ident) -> str:
    """Зібрати посилання: ref("party", "p0004") → "party:p0004"."""
    k = check_kind(kind)
    i = _s(ident)
    if not i:
        raise EntityError("Порожній ідентифікатор %s: посилання без номера ні на що "
                          "не вказує." % KIND_NAMES[k])
    if len(i) > MAX_IDENT:
        raise EntityError("Ідентифікатор %s задовгий (%d знаків, межа %d) — це схоже "
                          "на текст, а не на номер." % (KIND_NAMES[k], len(i), MAX_IDENT))
    if "\n" in i or "\r" in i or "\t" in i:
        raise EntityError("Ідентифікатор %s містить перенос рядка або табуляцію — "
                          "такий номер не читається назад." % KIND_NAMES[k])
    return k + SEP + i


def parse(value) -> tuple:
    """Прочитати посилання назад: "party:p0004" → ("party", "p0004").

    Ріжемо по ПЕРШІЙ двокрапці: ідентифікатор системи буває складеним
    («system:job:seo_geo»), і другий розділювач належить уже йому."""
    s = _s(value)
    if not s:
        raise EntityError("Порожнє посилання на сутність.")
    kind, sep, ident = s.partition(SEP)
    if not sep:
        raise EntityError("«%s» не є посиланням на сутність: бракує виду перед "
                          "двокрапкою (напр. «party:p0004»)." % s)
    k = check_kind(kind)
    i = _s(ident)
    if not i:
        raise EntityError("Посилання «%s:» без ідентифікатора ні на що не вказує." % k)
    return k, i


def is_ref(value) -> bool:
    """Чи це коректне посилання. НЕ кидає — для перевірок у чужому коді."""
    try:
        parse(value)
        return True
    except EntityError:
        return False


def kind_of(value) -> str:
    return parse(value)[0]


def ident_of(value) -> str:
    return parse(value)[1]


def norm(value) -> str:
    """Нормалізоване посилання (прибирає пробіли, звіряє вид). Невідоме — відмова."""
    k, i = parse(value)
    return ref(k, i)


# ── Питання до власника домену ───────────────────────────────────────────────
# ⚠ Кожен прохід окремо загорнутий: вимкнений або зламаний домен віддає порожньо,
# а не валить того, хто просто хотів підписати рядок журналу.

def _party_title(pid: str) -> str:
    import parties
    return _s(parties.title(pid))


def _person_title(pid: str) -> str:
    try:
        import taskdesk_people as people
        nm = _s((people.employee(pid) or {}).get("full_name"))
        if nm:
            return nm
    except Exception:
        pass
    # Обліковий запис без картки працівника (власник платформи в полегшеному
    # режимі) — теж людина; тоді її імʼям служить логін.
    try:
        import taskdesk_identity as tdid
        # ⭐ ЗМІНА 374. Власник одноосібного режиму на диску НЕ ЛЕЖИТЬ — і саме
        # тому довідник імен його не знаходив і віддавав службове «owner».
        # Імʼя для нього є, і писар цього імені один — той самий, що вирішує,
        # хто взагалі діє. Питаємо його, а не вигадуємо друге імʼя тут.
        if pid == tdid.OWNER_ID:
            return _s(tdid.owner_actor().get("employee_name")) or pid
        acc = tdid.account(pid) or {}
        emp = _s(acc.get("employee_id"))
        if emp:
            import taskdesk_people as people2
            nm = _s((people2.employee(emp) or {}).get("full_name"))
            if nm:
                return nm
        return _s(acc.get("login"))
    except Exception:
        return ""


def _task_title(tid: str) -> str:
    import taskdesk_tasks
    return _s((taskdesk_tasks.task(tid) or {}).get("title"))


def _system_title(sid: str) -> str:
    import registry
    s = registry.find_system(sid) or {}
    return _s(s.get("title")) or _s(s.get("name"))


def _run_title(rid: str) -> str:
    # У прогону людської назви немає — його імʼя і є його назвою.
    return ""


def _connector_title(cid: str) -> str:
    """Людська назва чужого сервісу — з того ж переліку, з якого його викликають."""
    import connector_tools
    for spec in connector_tools.TOOLS.values():
        if _s(spec.get("connector")) == _s(cid):
            return _s(spec.get("name")).split(" ")[-1] or _s(cid)
    return ""


def _unit_title(uid: str) -> str:
    """Назва підрозділу. Ліквідований теж називає себе: журнал памʼятає його
    вічно, і рядок «ліквідовано підрозділ unit-3fbf…» був би нечитабельним."""
    import taskdesk_people as people
    for u in people.units(include_liquidated=True):
        if _s(u.get("id")) == _s(uid):
            return _s(u.get("name"))
    return ""


def _org_title(ident: str) -> str:
    """В оргструктури як цілого номер один, і назва в неї теж одна."""
    return "компанія" if _s(ident) == ORG_COMPANY else ""


def _deal_title(did: str) -> str:
    """Назва угоди — це ПОЛЕ, а не ключ (крок C1). Саме тому її можна
    перейменувати, і жоден звʼязок від цього не розірветься."""
    import deals
    return _s(deals.title(did))


def _good_title(gid: str) -> str:
    """Назва товару — ПОЛЕ, а не ключ: перейменування не рве жодного звʼязку."""
    import goods
    return _s(goods.title(gid))


def _field_title(fid: str) -> str:
    """Назва поля — ПОЛЕ, а не ключ: перейменування не рве жодного звʼязку."""
    import card_fields
    return _s(card_fields.title(fid))


def _order_title(oid: str) -> str:
    """Назва замовлення — його номер. Власник тотожності — `shop.py`."""
    import shop
    row = shop.get(oid)
    return ("Замовлення № " + _s(row.get("number"))) if row.get("number") else ""


def _order_exists(oid: str) -> bool:
    import shop
    return bool(shop.get(oid))


_TITLE = {
    KIND_ORDER: _order_title,
    KIND_FIELD: _field_title,
    KIND_GOOD: _good_title,
    KIND_PARTY: _party_title,
    KIND_PERSON: _person_title,
    KIND_TASK: _task_title,
    KIND_SYSTEM: _system_title,
    KIND_RUN: _run_title,
    KIND_CONNECTOR: _connector_title,
    KIND_DEAL: _deal_title,
    KIND_UNIT: _unit_title,
    KIND_ORG: _org_title,
}


def title(value) -> str:
    """Людська назва для екрана. Домен мовчить — віддаємо сам ідентифікатор.

    Невідомий ВИД — відмова (це помилка коду). Невідомий ІДЕНТИФІКАТОР — не
    відмова: сутність могла бути видалена, а журнал append-only памʼятає її вічно."""
    k, i = parse(value)
    try:
        nm = _TITLE[k](i)
    except Exception:
        nm = ""
    return nm or i


# ── АДРЕСА ЕКРАНА (крок B3, 14.08.2026) ──────────────────────────────────────
# ⭐⭐⭐ ЯКИЙ ЕКРАН ВІДКРИВАЄ ЯКИЙ ВИД — ЗНАННЯ `entity`, А НЕ КОЖНОГО ЕКРАНА.
# До сьогодні воно було зашите в самій сторінці задачі ('/task?id=' + номер).
# З появою угоди й заявки його довелося б вписувати в КОЖЕН екран окремо — і
# перший же забутий екран показав би назву, яка нікуди не веде. Пряма вимога
# Андрія 14.08: «по назві задачі або угоди в один клік перейти у відповідну
# картку» — це вимога до НАВІГАЦІЇ, а не до даних.
#
# ⛒ ВИДУ БЕЗ ЕКРАНА ВІДПОВІДАЄМО ПОРОЖНІМ РЯДКОМ, А НЕ ВИГАДАНОЮ АДРЕСОЮ.
# У прогону, системи, конектора й людини своєї картки в консолі немає; кнопка
# в нікуди гірша за її відсутність (те саме рішення, що й у B2 про звʼязок,
# який веде на видалену сутність).
_SCREEN = {
    KIND_TASK: "/task?id=%s",     # Task Desk, окрема сторінка
    KIND_PARTY: "/?party=%s",     # консоль → CRM → «Клієнти» → картка
    # ⭐ Саме цей рядок робить угоду клікабельною В КОЖНОМУ переліку звʼязків
    # і в кожному рядку стрічки — без правки жодного екрана (це купив крок B4).
    KIND_DEAL: "/?deal=%s",       # консоль → CRM → воронка → картка угоди
}


def screen(value) -> str:
    """Адреса, за якою відкривається картка цієї сутності («» — екрана немає).

    ⚠ Невідомий вид тут НЕ відмова: підписати рядок журналу і не дати на нього
    посилання — нормальний хід, а падати через це — ні."""
    try:
        k, i = parse(value)
    except Exception:
        return ""
    tpl = _SCREEN.get(k)
    if not tpl or not i:
        return ""
    from urllib.parse import quote
    return tpl % quote(str(i), safe="")


def human(value) -> str:
    """«контрагент Каспер Україна» — для звіту, який читає людина."""
    k, i = parse(value)
    t = title(value)
    return "%s %s" % (KIND_NAMES[k], t if t else i)


def _party_exists(pid: str) -> bool:
    import parties
    return bool(parties.exists(pid))


def _person_exists(pid: str) -> bool:
    try:
        import taskdesk_people as people
        if people.employee(pid):
            return True
    except Exception:
        pass
    import taskdesk_identity as tdid
    return bool(tdid.account(pid))


def _task_exists(tid: str) -> bool:
    # ⚠ 27.08.2026: питаємо ФАЙЛ, а не всю задачу. Повне читання тут коштувало
    # рекурсії (див. `taskdesk_tasks.exists`) і зайвої роботи на кожен звʼязок
    # у кожному переліку.
    import taskdesk_tasks
    return bool(taskdesk_tasks.exists(tid))


def _system_exists(sid: str) -> bool:
    import registry
    return bool(registry.find_system(sid))


def _run_exists(rid: str) -> bool:
    import store
    return store.run_dir(rid).exists()


def _connector_exists(cid: str) -> bool:
    import connector_tools
    return any(_s(sp.get("connector")) == _s(cid)
               for sp in connector_tools.TOOLS.values())


def _unit_exists(uid: str) -> bool:
    """⛒ ЛІКВІДОВАНИЙ ПІДРОЗДІЛ — ЦЕ НЕ ЗНИКЛИЙ. Запису про нього не стирали,
    його дістала дата; тому «чи знає домен цю річ» для нього — ТАК."""
    import taskdesk_people as people
    return any(_s(u.get("id")) == _s(uid)
               for u in people.units(include_liquidated=True))


def _org_exists(ident: str) -> bool:
    return _s(ident) == ORG_COMPANY


def _deal_exists(did: str) -> bool:
    import deals
    return bool(deals.exists(did))


def _why_not(kind, ident, err) -> None:
    """Слід проковтнутого «ні». Сам ніколи не падає: сторож, який валить те, що
    стереже, гірший за відсутнього."""
    try:
        import sys as _sys
        _sys.stderr.write("[сутність] «%s:%s» визнано неіснуючою через помилку "
                          "домену: %s: %s\n"
                          % (kind, ident, type(err).__name__, err))
    except Exception:
        pass


_EXISTS = {
    KIND_ORDER: _order_exists,
    KIND_PARTY: _party_exists,
    KIND_PERSON: _person_exists,
    KIND_TASK: _task_exists,
    KIND_SYSTEM: _system_exists,
    KIND_RUN: _run_exists,
    KIND_CONNECTOR: _connector_exists,
    KIND_DEAL: _deal_exists,
    KIND_UNIT: _unit_exists,
    KIND_ORG: _org_exists,
}


def exists(value) -> bool:
    """Чи власник домену досі знає цю річ. Домен мовчить — False, не аварія.

    ⭐⭐⭐ 01.09.2026. МОВЧАЗНЕ «НІ» ДОРОЖЧЕ ЗА ГУЧНУ ПОМИЛКУ. Доти будь-яка
    біда — впав імпорт домену, побився файл, домен кинув виключення —
    перетворювалась на спокійне `False`, і людина бачила лише `alive: False`
    без жодного сліду причини. Через це ТРИ рідкісні почервоніння підряд
    (`contact_layer_test` 29.08, `relations_test` 30.08 і 01.09) лишились
    непоясненими: сказати «ні» вміли, сказати «чому» — ні.

    ⛒ Поведінка НЕ змінюється: як віддавали `False`, так і віддаємо, бо домен
    справді має право не знати речі. Змінюється одне — тепер причина не зникає.
    """
    k, i = parse(value)
    try:
        return bool(_EXISTS[k](i))
    except Exception as e:
        _why_not(k, i, e)
        return False


# ── ЧИ РІЧ УЖЕ ЗАКІНЧЕНА (зміна 242, 27.08.2026) ─────────────────────────────
# ⭐⭐⭐ НАВІЩО. Звʼязок «блокує» вмів сказати лише «ця робота когось тримає» — і
# жодного слова про те, чи та, що тримає, ЩЕ ЖИВА. Тому картка задачі чесно
# мовчала («чи закрита та задача, звʼязок не знає»), а людина йшла перевіряти
# руками — по одній вкладці на звʼязок. Питання «це вже закінчено?» — питання
# про СУТНІСТЬ, а не про звʼязок: завтра його поставлять про угоду, і другого
# писаря відповіді ми не заводимо.
#
# ⛒ ВИДУ, ЯКИЙ ПРО ЗАКІНЧЕННЯ НІЧОГО НЕ ЗНАЄ, ВІДПОВІДАЄМО «НІ», А НЕ
# ВИГАДУЄМО. «Контрагент закритий» — речення без змісту; мовчазне «так» тут
# погасило б справжню перепону, а це дорожче за зайвий рядок на екрані.
def _task_closed(tid: str) -> bool:
    import taskdesk_tasks
    return bool(taskdesk_tasks.is_closed(tid))


_CLOSED = {
    KIND_TASK: _task_closed,
}


def closed(value) -> bool:
    """Чи ця річ уже закінчилась (зроблена або скасована).

    ⚠ Не знаємо — «ні». Невідомий вид, мертвий домен, зникла сутність: усе це
    не привід оголосити роботу завершеною."""
    try:
        k, i = parse(value)
    except Exception:
        return False
    fn = _CLOSED.get(k)
    if not fn:
        return False
    try:
        return bool(fn(i))
    except Exception:
        return False


# ── Тотожність контрагента за «ручкою» ───────────────────────────────────────
def resolve_party(handle, kind: str = "") -> str:
    """Пошта / телеграм / телефон / ЄДРПОУ → посилання на контрагента (або "").

    ⛔ ВЛАСНОГО ПОШУКУ ТУТ НЕМАЄ І НЕ БУДЕ. Питаємо `parties.find` — єдиного
    писаря тотожності контрагента (зміна 167). Другий пошук за схожістю назв — це
    саме та біда, заради якої писався хребет."""
    try:
        import parties
        pid = _s(parties.find(handle, kind))
    except Exception:
        pid = ""
    return ref(KIND_PARTY, pid) if pid else ""


# ── Тотожність людини ────────────────────────────────────────────────────────
# ⭐ ОДНА ЛЮДИНА — ОДНЕ ІМʼЯ. У платформі людина показується з двох боків: як
# ПРАЦІВНИК оргструктури (`taskdesk_people`, саме його знає Task Desk) і як
# ОБЛІКОВИЙ ЗАПИС (`taskdesk_identity`, саме його знає чат і розклад). Якби
# протокол писав то одне, то друге, історія однієї людини розпалась би навпіл —
# рівно те, від чого ми лікували клієнтську базу в зміні 167.
# ⛒ Канон — ПРАЦІВНИК. Обидві функції нижче названі явно: викликач знає, що саме
# в нього в руках, і НЕ вгадується за виглядом рядка.

def person_of_employee(emp_id) -> str:
    """Працівник оргструктури → посилання на людину."""
    e = _s(emp_id)
    return ref(KIND_PERSON, e) if e else ""


def person_of_account(acc_id) -> str:
    """Обліковий запис → посилання на ту саму людину (через його працівника).

    Запис без картки працівника (власник платформи в полегшеному режимі) —
    це людина, у якої працівника НЕМАЄ; тоді її імʼям лишається сам запис.
    Це не другий писар: другого імені просто не існує."""
    a = _s(acc_id)
    if not a:
        return ""
    try:
        import taskdesk_identity as tdid
        emp = _s((tdid.account(a) or {}).get("employee_id"))
    except Exception:
        emp = ""
    return ref(KIND_PERSON, emp or a)


def person_of_actor(actor) -> str:
    """Актор із каналу (обліковий запис як набір полів) → посилання на людину."""
    if isinstance(actor, dict):
        emp = _s(actor.get("employee_id"))
        if emp:
            return ref(KIND_PERSON, emp)
        a = _s(actor.get("id"))
        return ref(KIND_PERSON, a) if a else ""
    return person_of_account(actor)


def party_of_card(customer: str) -> str:
    """Імʼя картки CRM → посилання на контрагента (або "").

    Картка угоди і контрагент — різні речі (доповнення v2 до проєкту хребта):
    картка приходить і йде, довідник живе роками. Питаємо CRM, який уже вміє
    цей перехід (`crm.party_of`)."""
    try:
        import crm
        pid = _s(crm.party_of(customer))
    except Exception:
        pid = ""
    return ref(KIND_PARTY, pid) if pid else ""
