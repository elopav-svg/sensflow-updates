# -*- coding: utf-8 -*-
"""check_telegram_link.py — ЧИ БАЧИТЬ TELEGRAM САМЕ ПЛАТФОРМА (а не браузер).

Навіщо окремо від браузера: браузер ходить у мережу СВОЇМ шляхом (проксі
Windows, свої сертифікати), а платформа — своїм, через власне вікно назовні
(`netfetch`). Тому «у браузері getMe відповідає» ще не означає, що відповість
python тієї самої машини. Ця перевірка йде РІВНО тим шляхом, яким ходить бот.

Нічого не змінює, нічого не надсилає. Читає токен із .env.local платформи.
"""
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))


def line(t=""):
    print(t, flush=True)


def _show_chain():
        line("")
        line("5. ХТО підписав сертифікат (хто саме втручається в HTTPS):")
        try:
            import socket, ssl, re as _re
            ctx = ssl._create_unverified_context()
            with socket.create_connection(("api.telegram.org", 443), 15) as sock:
                with ctx.wrap_socket(sock, server_hostname="api.telegram.org") as ss:
                    der = ss.getpeercert(binary_form=True) or b""
            names = [w.decode("ascii", "ignore") for w in
                     _re.findall(rb"[ -~]{5,}", der)]
            drop = ("api.telegram.org", "telegram")
            shown = []
            for n in names:
                n = n.strip()
                if len(n) < 5 or n.lower() in drop:
                    continue
                if any(ch.isalpha() for ch in n) and n not in shown:
                    shown.append(n)
            line("   Імена в сертифікаті, який нам віддали:")
            for n in shown[:12]:
                line("     · %s" % n)
            line("")
            line("   Якщо серед них є назва фірми, шлюзу чи антивіруса —")
            line("   це він підміняє сертифікат. Справжній ланцюжок Telegram")
            line("   підписують GlobalSign / DigiCert і нічого стороннього.")
        except Exception as e:
            line("   не вдалося подивитись: %s: %s" % (type(e).__name__, e))



def main():
    line("=" * 66)
    line(" SensFlow — CHECK TELEGRAM LINK")
    line("=" * 66)

    try:
        import config
    except Exception as e:
        line("[X] не читається config: %s" % e)
        return 2

    tok = (config.ENV.get("TELEGRAM_BOT_TOKEN") or "").strip()
    ids = (config.ENV.get("TELEGRAM_ALLOWED_CHAT_IDS") or "").strip()
    line("1. Токен у .env.local: %s" % ("є, %d знаків, починається на %s"
                                        % (len(tok), tok[:10] + "…") if tok else "НЕМАЄ"))
    line("   Дозволені чати (TELEGRAM_ALLOWED_CHAT_IDS): %s" % (ids or "порожньо"))
    if not tok:
        line("")
        line("   Далі перевіряти нема що: без токена бот не працює.")
        return 1

    line("")
    line("2. Провайдер моделі: %s" % getattr(config, "LLM_PROVIDER", "?"))
    if str(getattr(config, "LLM_PROVIDER", "")) == "local":
        line("   ⚠ Режим повної локальної ізоляції: вихід назовні заблоковано,")
        line("     і саме тому Telegram мовчатиме. Це не поломка, це режим.")

    line("")
    line("3. Стук у Telegram ТИМ САМИМ шляхом, що й бот (getMe):")
    try:
        import telegram_bot
        telegram_bot._ctx.token = tok
        res = telegram_bot._api("getMe", {}, timeout=20)
        if res.get("ok"):
            me = res.get("result") or {}
            line("   [v] ВІДПОВІВ: @%s (%s)" % (me.get("username"), me.get("first_name")))
        else:
            line("   [X] Telegram відмовив: %r" % (res,))
            return 1
    except Exception as e:
        line("   [X] НЕ ВИЙШЛО: %s: %s" % (type(e).__name__, e))
        line("")
        line("   --- дослівно ---")
        traceback.print_exc()
        line("   ----------------")
        line("   Це і є причина. Браузер ходить своїм шляхом, python — своїм:")
        line("   найчастіше це проксі Windows, антивірус або фаєрвол,")
        line("   який пускає браузер і не пускає python.")
        _show_chain()
        return 1

    line("")
    line("4. Чи забирає хтось повідомлення (getUpdates):")
    try:
        res = telegram_bot._api("getUpdates", {"timeout": 0, "limit": 5}, timeout=20)
        items = res.get("result") or []
        line("   [v] відповів, повідомлень у черзі: %d" % len(items))
        for u in items[-3:]:
            m = u.get("message") or {}
            ch = (m.get("chat") or {})
            line("       від chat_id=%s (%s): %r"
                 % (ch.get("id"), ch.get("username") or ch.get("first_name"),
                    (m.get("text") or "")[:40]))
        if not items:
            line("       Черга порожня. Або ніхто не писав, або повідомлення")
            line("       вже забрав хтось інший — жива платформа чи ДРУГА її копія.")
    except Exception as e:
        msg = str(e)
        if "409" in msg:
            line("   [i] HTTP 409 — цього бота ЗАРАЗ опитує інший слухач.")
            line("       Якщо платформа запущена — це нормально, це вона сама.")
            line("       Якщо платформа зупинена — десь працює ДРУГА копія")
            line("       або стороння програма з тим самим токеном.")
        else:
            line("   [X] НЕ ВИЙШЛО: %s: %s" % (type(e).__name__, e))

    _show_chain()
    line("")
    line("=" * 66)
    line(" Готово. Рядок [X] вище — це і є причина, дослівно.")
    line("=" * 66)
    return 0


if __name__ == "__main__":
    sys.exit(main())
