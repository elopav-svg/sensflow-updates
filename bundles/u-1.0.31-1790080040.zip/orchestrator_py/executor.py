"""
executor.py — виконання обраної системи за її ВЛАСНОЮ логікою.

Головний принцип (правило для ВСІХ систем):
  1) ОСМИСЛЕННЯ: оркестратор спершу читає ВСІ промпти системи — кореневі
     правила (CLAUDE.md/PROMPT.md) і промпт КОЖНОГО агента — і виводить
     структурований план виконання (послідовність, ролі, цикл якості,
     обовʼязкові входи, критерії успіху). План кешується per-system.
  2) УТОЧНЕННЯ: якщо за планом бракує обовʼязкових входів — питає користувача.
  3) ВИКОНАННЯ: запускає агентів САМЕ за планом (порядок і призначення з логіки
     системи), з циклом доопрацювання критик→ревізор згідно правил системи.
  4) ПЕРЕВІРКА: звіряє результат із критеріями успіху, визначеними планом.
"""

import json
import hashlib
import re

import config
import llm
import llmtools
import registry
import knowledge
import owner_profile  # ⭐ 31.07.2026: імʼя автора/бренд — ДАНІ, а не текст промпта
import netfetch
import source_fit
import tools
import connector_tools   # ⭐ 12.08.2026 (164): інструменти чужого сервісу — один писар
import costs
import verifier
import failure_trace
import xlsx_tables
import artifacts  # 557: один писар імені; локальний імпорт лишав його невидимим
import audit  # ОДИН писар сліду прогонів і відмов (01.08.2026)
import failure  # ⭐ 29.07.2026: ОДИН перекладач аварій — сирий виняток клієнту не виходить
import legal_source_ua  # ШАР 1: офіційне першоджерело норм права UA (data.rada.gov.ua)
import schema_org  # детермінований будівник schema.org JSON-LD (контракт «модель→рендер»)
import route_engine  # детермінований маршрутний двигун (ORS) — реальний шлях, не «з голови»
import system_engines  # ⛒ один писар: кому оголошено двигун (не імʼя системи)
import live_gap        # ⛒ один писар: «живої звірки не було» — блок-факт агентові
import norms           # ⛒ один писар: що саме є нормативом методики системи
import arith           # ⛒ один суддя: викладка мусить сходитись із своїм числом
import assumed         # ⛒ один писар: клас машини визначає платформа, а не агент
import applied         # ⛒ один суддя: названий норматив мусить брати участь у числах
import tender_pack      # ворота доказовості тендерного пакета (05.08.2026)
import tender_skeleton  # кістяк пакета будує КОД, а не модель (05.08.2026)
import tender_fill      # текст довідки ЗАМОВЛЯЄ платформа, а не вгадує (12.08.2026)

_ART = (config.PLATFORM_ARTIFACT_NOTE + "\n\n" + config.NO_FABRICATION_NOTE
        + "\n\n" + config.INJECTION_GUARD_NOTE)
HARD_MAX_REVISIONS = 3  # стеля вартості, навіть якщо система дозволяє більше
LEGAL_BUDGET_FACTOR = 2.0  # правова задача коштує дорожче за природою (28.07.2026)


def _emit(emit, label):
    """Безпечно надсилає подію прогресу (для стрімінгу). emit=None -> no-op."""
    if emit:
        try:
            emit("stage", label)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Завантаження промптів
# ---------------------------------------------------------------------------
# ⭐⭐⭐ 31.07.2026. ОДИН ЧИТАЧ МОЗКУ — І ОДНА ТОЧКА ПІДСТАНОВКИ.
# Досі текст мозку читали ДВІ різні функції (кореневі правила системи й промпт
# агента), і кожна віддавала його моделі ДОСЛІВНО. Тому зашите в промпт імʼя
# автора їхало до клієнта як частина інструкції — і система, зроблена під
# одного автора, поїхала в продукт (корінь «копірайтер», 31.07.2026).
# Тепер обидві йдуть через ОДНОГО читача, а імʼя автора й бренд приходять із
# профілю власника копії [[owner_profile]]. Двох писарів цієї правди немає.
def _read_brain_text(path, render: bool = True) -> str:
    """Прочитати файл мозку. ЄДИНА точка читання.

    render=True  — РОБОЧИЙ текст для моделі: підставляємо профіль власника.
    render=False — СИРИЙ текст із плейсхолдерами. Потрібен там, де результат
      ЗБЕРІГАЄТЬСЯ НА ДИСК і їде клієнту (кеш плану системи).
      ⭐⭐⭐ 31.07.2026, живий прогін: план будувався з ПІДСТАВЛЕНОГО тексту, і в
      `.orchestration_plan.json` осіло «для проєкту SensFlow» — наше імʼя поїхало б
      клієнту всередині паспорта системи. **ПОХІДНЕ ЗНАЧЕННЯ, ЗБЕРЕЖЕНЕ НА ДИСК, —
      ПОЧАТОК ДРУГОЇ ПРАВДИ.** План описує СТРУКТУРУ, а не чиєсь імʼя.
    """
    try:
        raw = path.read_text(encoding="utf-8-sig")
        return owner_profile.render(raw) if render else raw
    except Exception:
        return ""


def _fmt_ua(v) -> str:
    """Число так, як його бачить читач документа: 16 333,85."""
    s = ("%.2f" % float(v)).rstrip("0").rstrip(".")
    whole, _, frac = s.partition(".")
    out, neg = "", whole.startswith("-")
    whole = whole.lstrip("-")
    while len(whole) > 3:
        out = " " + whole[-3:] + out
        whole = whole[:-3]
    out = ("-" if neg else "") + whole + out
    return out + ("," + frac if frac else "")


def _system_root_prompt(system: dict, render: bool = True) -> str:
    root = registry.system_root(system)
    for name in ("CLAUDE.md", "PROMPT.md"):
        p = root / name
        if p.exists():
            t = _read_brain_text(p, render)
            if t:
                return t
    return ""


def _load_agent_prompt(system: dict, agent_id: str, render: bool = True) -> str:
    root = registry.system_root(system)
    for c in (root / "Agents" / agent_id / "PROMPT.md",
              root / "Agents" / agent_id / "CLAUDE.md",
              root / "Agents" / agent_id.lower() / "PROMPT.md",
              root / "agents" / agent_id / "PROMPT.md"):
        if c.exists():
            t = _read_brain_text(c, render)
            if t:
                return t
    return ""


def _registry_agent_ids(system: dict) -> list:
    ids = []
    for a in system.get("agents", []):
        ids.append(a.get("id") or a.get("name") if isinstance(a, dict) else a)
    return [i for i in ids if i] or ["AgentMain"]


def _collect_prompts(system: dict) -> dict:
    """Набір промптів для ОСМИСЛЕННЯ (побудови плану) — СИРИЙ, з плейсхолдерами.
    План кешується на диск і їде клієнту, тому імені власника в ньому бути НЕ може.
    Робочі кроки агентів беруть текст окремо і вже ПІДСТАВЛЕНИЙ."""
    agents = {}
    for aid in _registry_agent_ids(system):
        agents[aid] = _load_agent_prompt(system, aid, render=False)
    return {"root": _system_root_prompt(system, render=False), "agents": agents}


# ---------------------------------------------------------------------------
# Фаза 1: ОСМИСЛЕННЯ системи (читає всі промпти -> план виконання)
# ---------------------------------------------------------------------------
def _plan_cache_path(system: dict):
    return registry.system_root(system) / ".orchestration_plan.json"


def _prompts_hash(prompts: dict) -> str:
    h = hashlib.md5()
    h.update((prompts.get("root") or "").encode("utf-8"))
    for aid in sorted(prompts.get("agents", {})):
        h.update(aid.encode("utf-8"))
        h.update((prompts["agents"][aid] or "").encode("utf-8"))
    return h.hexdigest()


def _plan_missing_agents(plan: dict, declared) -> list:
    """Агенти, ОГОЛОШЕНІ в системі, яких у плані НЕМАЄ ніде: ні в конвеєрі,
    ні в колі якості (критик/ревізор часто саме там).

    ⭐ 30.07.2026. Навіщо: у `legal_assistant` оголошено 5 агентів, а збережений
    план виконував 4 — тендерного юриста в конвеєрі просто не було, і ніхто
    цього не бачив. Хеш промптів такого не ловить: він рахує ТЕКСТИ промптів,
    а не СКЛАД конвеєра. Клієнт платив за команду, а працювала частина команди.
    """
    # ⭐ Порівнюємо СМИСЛ імені, а не спосіб його запису: план цілком може називати
    # того самого агента `agent_interviewer`, а реєстр — `AgentInterviewer`. Без
    # цієї нормалізації кеш був би недійсним ЩОРАЗУ, і план перебудовувався б на
    # КОЖНОМУ прогоні — тобто мій запобіжник почав би палити гроші власника.
    def _norm(a) -> str:
        return "".join(ch for ch in str(a or "").lower() if ch.isalnum())

    used = set()
    for s in (plan or {}).get("pipeline") or []:
        aid = (s or {}).get("agent") if isinstance(s, dict) else s
        if aid:
            used.add(_norm(aid))
    ql = (plan or {}).get("quality_loop") or {}
    if isinstance(ql, dict):
        for aid in (ql.get("critic_agent"), ql.get("reviser_agent")):
            if aid:
                used.add(_norm(aid))
    return [a for a in (declared or []) if _norm(a) not in used]


def _agent_purpose(prompt_text: str) -> str:
    """Призначення агента — З ЙОГО ВЛАСНОГО ПРОМПТА, а не з моєї вигадки."""
    for line in (prompt_text or "").splitlines():
        t = line.strip().lstrip("#").strip()
        if len(t) > 20 and not t.startswith(("```", "|", "-", "*")):
            return t[:200]
    return "виконати свій етап згідно ролі"


def _complete_pipeline(plan: dict, prompts: dict, system: dict) -> dict:
    """Дописує в конвеєр оголошених агентів, яких модель-планувальник загубила.

    ⭐⭐⭐ 30.07.2026 (живий прогін Андрія, зміна 35). СКЛАД КОМАНДИ ВИЗНАЧАЄ СИСТЕМА,
    А НЕ МОДЕЛЬ. Перевірка чинності кешу спрацювала правильно і чесно сказала в лозі:
    «конвеєр не використовує AgentTenderCounsel». План перебудувався — і модель
    ВИКИНУЛА тендерного юриста ВДРУГЕ. Наслідок бачив Андрій: у відповіді не було
    переліку дій, бо кроки участі пише саме той агент, якого не покликали.

    Дві біди від одного кореня, і обидві лікуються тут:
      1. клієнт платив за команду, а працювала частина команди;
      2. МОЯ МІНА: пропажа не зникала, тому план перебудовувався б НА КОЖНОМУ
         прогоні — тобто мій же запобіжник палив би гроші власника щоразу.

    Модель має право вирішувати ПОРЯДОК і ПРИЗНАЧЕННЯ кроків. Права викинути
    оголошеного агента вона не має: склад команди — це паспорт системи, і писар у
    нього один. Тому тут не ворота і не «ще одна перевірка», а ВИЛУЧЕННЯ права.
    """
    declared = list((prompts or {}).get("agents") or {})
    missing = _plan_missing_agents(plan, declared)
    if not missing:
        return plan
    steps = list(plan.get("pipeline") or [])
    ql = plan.get("quality_loop") or {}
    guards = {str(ql.get("critic_agent") or "").strip().lower(),
              str(ql.get("reviser_agent") or "").strip().lower()}
    guards.discard("")

    def _is_guard(st):
        aid = (st or {}).get("agent") if isinstance(st, dict) else st
        return str(aid or "").strip().lower() in guards

    # Місце вставки: ПЕРЕД охоронцями якості наприкінці — критик має судити вже
    # готову роботу, зокрема й роботу дописаного агента.
    cut = len(steps)
    while cut > 0 and _is_guard(steps[cut - 1]):
        cut -= 1
    for aid in missing:
        steps.insert(cut, {"agent": aid,
                           "purpose": _agent_purpose((prompts.get("agents") or {}).get(aid)),
                           "produces": "внесок цього агента у фінальний результат",
                           "needs_web_search": False})
        cut += 1
    plan["pipeline"] = steps
    llm._log("[executor] конвеєр «%s» доповнено оголошеними агентами, яких модель не "
             "взяла: %s (склад команди визначає система, не модель)"
             % (system.get("id") or "?", ", ".join(str(a) for a in missing)))
    return plan


def comprehend_system(system: dict, force: bool = False) -> dict:
    """
    Читає всі промпти системи і повертає план виконання (з кешу, якщо промпти не змінились).
    План:
      {system_understanding, required_inputs[], pipeline[{agent,purpose,produces}],
       quality_loop{enabled,critic_agent,reviser_agent,pass_threshold,max_iterations},
       final_deliverable, success_criteria[]}
    """
    prompts = _collect_prompts(system)
    phash = _prompts_hash(prompts)
    cache_path = _plan_cache_path(system)

    if not force and cache_path.exists():
        try:
            cached = json.loads(cache_path.read_text(encoding="utf-8"))
            if cached.get("_hash") == phash and cached.get("plan"):
                # ЧИННІСТЬ КЕШУ ≠ ЛИШЕ ХЕШ ПРОМПТІВ. План, який не використовує
                # оголошеного агента, — недійсний: система обіцяла клієнту одну
                # команду, а працює інша. Такий кеш перебудовуємо тим самим
                # шляхом, що й при force=True (просто не повертаємо його).
                _missing = _plan_missing_agents(cached["plan"], prompts["agents"].keys())
                if not _missing:
                    return cached["plan"]
                # Мовчазна перебудова — це витрата грошей власника без пояснення,
                # тому причину НАЗИВАЄМО вголос.
                llm._log("[executor] план системи «%s» перебудовується: збережений "
                         "конвеєр не використовує оголошених агентів — %s "
                         "(немає ні в pipeline, ні в quality_loop)"
                         % (system.get("id") or system.get("name") or "?",
                            ", ".join(str(a) for a in _missing)))
        except Exception:
            pass

    fallback = _complete_pipeline(_fallback_plan(system, prompts), prompts, system)

    if not config.provider_ready():
        return fallback

    agent_blocks = "\n\n".join(
        f"### Промпт агента {aid}\n{(text or '(промпт відсутній)')[:4000]}"
        for aid, text in prompts["agents"].items()
    )
    sys_prompt = (
        "Ти — Global Orchestrator. Тобі дано ПОВНИЙ набір промптів мультиагентської "
        "системи: кореневі правила оркестрації і промпт кожного агента. Уважно прочитай "
        "їх і ЗРОЗУМІЙ внутрішню логіку системи: який порядок агентів, хто за що "
        "відповідає, чи є цикл контролю якості і за якою умовою він завершується, які "
        "вхідні дані обовʼязкові, який фінальний результат. "
        f"Платформа має інструмент ВЕБ-ПОШУКУ ({'доступний' if config.web_search_ready() else 'наразі недоступний'}): "
        "для кроків, де агенту потрібні актуальні зовнішні дані (новини, тренди, ринок, "
        "конкуренти, ціни, нормативні джерела, перевірка фактів про осіб/компанії), "
        "став needs_web_search=true; для суто внутрішніх кроків — false. "
        "Поверни РІВНО ОДИН JSON:\n"
        "{\n"
        '  "system_understanding": "стислий опис логіки системи своїми словами (2-4 речення)",\n'
        '  "required_inputs": ["обовʼязкові вхідні дані від користувача"],\n'
        '  "pipeline": [{"agent": "id", "purpose": "що робить", "produces": "результат", "needs_web_search": true|false}],\n'
        '  "quality_loop": {"enabled": true|false, "critic_agent": "id|null", "reviser_agent": "id|null", "pass_threshold": "умова проходження (напр. 9/10)", "max_iterations": число},\n'
        '  "final_deliverable": "що саме отримує користувач",\n'
        '  "success_criteria": ["за чим перевіряти готовий результат"]\n'
        "}\n"
        "Порядок у pipeline бери з ЛОГІКИ системи, а не лише з переліку. Без тексту поза JSON."
    )
    user = (
        f"## СИСТЕМА: {system.get('name')} (id={system.get('id')})\n"
        f"Опис: {system.get('description','')}\n"
        f"Режим: {system.get('orchestration_mode','')}\n\n"
        f"## КОРЕНЕВІ ПРАВИЛА (root)\n{(prompts['root'] or '(відсутні)')[:6000]}\n\n"
        f"## ПРОМПТИ АГЕНТІВ\n{agent_blocks}"
    )
    try:
        plan = llm.judge_json(sys_prompt, user, temperature=0.1, model=config.brain_model(),
                              purpose="осмислення системи")
    except llm.LLMError:
        return fallback

    plan = _normalize_plan(plan, system, fallback)
    # Склад команди — за системою. Якщо модель когось загубила, дописуємо ДО запису
    # в кеш: інакше наступний прогін знову побачив би пропажу і знову перебудовував
    # план — нескінченна витрата грошей власника на ту саму помилку.
    plan = _complete_pipeline(plan, prompts, system)
    try:
        cache_path.write_text(json.dumps({"_hash": phash, "plan": plan},
                                         ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass
    return plan


_HIGH_STAKES_CATS = {"legal", "finance", "finance_excel", "medical", "health", "security", "strategy"}

# ⭐⭐⭐ 11.08.2026 (зміна 150). ТУТ СТОЯВ ПЕРЕЛІК СЛІВ `_HIGH_STAKES_KEYS`.
# У одній функції були змішані дві різні речі: читання НАШОЇ ВЛАСНОЇ категорії
# системи (законно — там слово І Є сенсом) і вгадування по ТЕКСТУ ЗАДАЧІ
# людини (шафа: слово «фінансовий» у назві доданого файлу робило маркетингову
# задачу «високими ставками» і забирало дорогу модель за гроші клієнта).
# Тепер серйозність теми називає ГАЛУЗЬ із довідника.


def _is_high_stakes(system: dict, task: str = "", intent=None) -> bool:
    """Високі ставки (право/фінанси/стратегія/медицина/безпека) — фінал збирає
    дорогий мозок (якість). Решта — дешева модель (вартість).

    ПОРЯДОК СИЛИ: наша власна категорія системи → оголошена галузь.
    Галузь невідома — вирішує сама категорія, як і до зміни 150. Дефолт
    свідомо в бік ЯКОСТІ, а не економії: помилка тут коштує якості юридичної
    відповіді, а не кількох центів."""
    cat = (system.get("category") or "").lower()
    if cat in _HIGH_STAKES_CATS:
        return True
    try:
        import domains as _dm
        st = _dm.stakes_of(((intent or {}) if isinstance(intent, dict) else {}).get("domain"))
    except Exception:
        st = None
    return st == "high"


# Побудова НОВОЇ системи (мета-режим Будівника) — свідомо важча робота, ніж питання
# в чаті. Їй стеля втричі вища, щоб запобіжник від «втечі вартості» не різав
# легітимну довгу роботу навпіл.
META_BUDGET_FACTOR = 3.0


def _run_cap(meta_mode: bool = False, legal_mode: bool = False) -> float:
    """Стеля вартості ЦЬОГО прогону в $. 0 = межі немає (свідомо вимкнено).

    Дорожчі ЗА ПРИРОДОЮ задачі мають власну стелю — одна точка рішення на всю
    систему, а не виняток для когось:
      • побудова НОВОЇ системи (Будівник) — ×3;
      • ПРАВОВА задача — ×2 (рішення Андрія 28.07.2026: «результат юриста
        вартує дорожче»). Правовий запит іде на дорогий мозок (високі ставки)
        і має кола критика; на базовій клієнтській стелі $0.50 така відповідь
        обривалась би на середині — клієнт платив би за пів-відповідь.
    Правова задача визначається ПАСПОРТОМ системи (`_is_legal_system`), а не
    словами моделі: інакше стелю можна було б підняти вмовлянням."""
    cap = getattr(config, "MAX_RUN_USD", 0.0) or 0.0
    if cap <= 0:
        return 0.0
    if meta_mode:
        return cap * META_BUDGET_FACTOR
    return cap * (LEGAL_BUDGET_FACTOR if legal_mode else 1.0)


def _over_cap(cap: float) -> bool:
    """Чи витрачено задану стелю. Окремо від _run_cap, бо клієнт має право
    підняти планку на ЦЕЙ прогін — і тоді діє його число, а не типове."""
    if not cap or cap <= 0:
        return False
    try:
        return float(costs.current_run().get("usd", 0.0)) >= float(cap)
    except Exception:
        return False


def _over_budget(meta_mode: bool = False, legal_mode: bool = False) -> bool:
    """Чи витрачено вже стелю прогону (config.MAX_RUN_USD; 0 = вимкнено)."""
    cap = _run_cap(meta_mode, legal_mode)
    if cap <= 0:
        return False
    try:
        return float(costs.current_run().get("usd", 0.0)) >= cap
    except Exception:
        return False


def _cross_provider_reserve() -> list:
    """⭐ 29.07.2026. ОДИН ПИСАР ПРАВДИ «хто наш резерв».
    Топ-модель кожного провайдера, у якого є ключ. Раніше цей перелік знав лише
    складальник — тому відмова постачальника на ЗВИЧАЙНОМУ кроці валила весь
    прогін, а клієнт бачив сирий текст помилки. Тепер список один, і ним
    користуються обидва (складальник — зі своїми воротами якості, крок — зі
    своїми). Двох писарів однієї правди не заводимо."""
    out = []
    try:
        ks = config.keys_status()
    except Exception:
        ks = {}
    # Спершу хмарні (швидкі, без читання-таймаутів), local — останнім.
    for prov in ("openai", "gemini", "anthropic", "local"):
        if ks.get(prov):
            try:
                # ⭐ 11.08.2026. Топ-модель провайдера НАЗИВАЄ ПРОВАЙДЕР — так
                # само, як у драбині `config.model_ladder`. Тут лишався останній
                # шматок, що знав лише зашитий рядок: резерв упирався б у модель,
                # знану тільки нашому коду. Не спитали — падаємо на підказки.
                m = (config.live_default_model(prov, "brain")
                     or (config.MODEL_SUGGESTIONS.get(prov) or [None])[0])
                if m and m not in out:
                    out.append(m)
            except Exception:
                pass
    return out


# ⭐⭐⭐ 16.09.2026, зміна 599. СКЛАДАЧ БУДУЄ З ПЕРШОДЖЕРЕЛА, А НЕ З ПЕРЕКАЗУ.
#
# КОРІНЬ, знайдений живим прогоном за $2,39. Платформа прочитала чотири доданих
# файли БЕЗДОГАННО (9009 знаків правильного тексту лежать в архіві чату), а в
# готовій книзі опинився ХЛІБЗАВОД: «Хліб та хлібобулочні вироби» 200000x25,
# договори «N2026-118», план маржинальності 65 % замість 9 %. Жодного числа з
# файлів — при цьому книга охайна, з живими формулами й правильними посиланнями.
#
# Причина проста й уся тут: складачеві давали ЗАПИТ і ЕТАПИ КОНВЕЄРА — тобто
# ПЕРЕКАЗИ агентів. Доданих файлів він не бачив узагалі, хоча агенти їх бачать
# (`_run_agent`: «## ДОДАНІ ФАЙЛИ»). Він писав книгу з переказу: де в переказі
# були числа — переносив, де не було — домальовував правдоподібні, лишаючи
# справжні підписи, які підгледів у переказі. Звідси хлібзавод із справжніми
# назвами статей витрат.
#
# ⛒ ЦЕЙ КЛАС ТУТ УЖЕ ЗНАЙДЕНИЙ — І ЗАЛАТАНИЙ ТОЧКОВО. Нижче стоїть коментар
# 14.07: «складач першоджерела не бачив (збирав лише з accumulated)» — і тоді
# прокинули канал правди ДЛЯ МАРШРУТНОГО ДВИГУНА. Для доданих файлів той самий
# канал не прокинули, і вада дочекалась свого дня. Тому тепер писар входу ОДИН,
# і первинні дані йдуть тим самим каналом, що й дані двигуна.
def _trace_case(label: str):
    """Тека сліду для однієї відмови. Ніколи не валить прогін."""
    try:
        return failure_trace.open_case(label)
    except Exception:
        from pathlib import Path as _P
        return _P(".")


def _tables_catalogue(files_context: str) -> str:
    """Короткий перелік таблиць і ТОЧНИХ назв колонок — щоб складач їх копіював,
    а не пригадував. Ніколи не валить прогін: нема каталогу — нема й блоку."""
    try:
        cat = xlsx_tables.catalogue(xlsx_tables.parse_tables(files_context))
    except Exception:
        return ""
    if not cat:
        return ""
    return ("### ТАБЛИЦІ У ЦИХ ФАЙЛАХ — НАЗВИ КОПІЮЙ ЗВІДСИ ДОСЛІВНО\n"
            "(саме ці рядки пиши в \"table\" і в назвах колонок файла; вигадана "
            "чи перекладена назва = відмова)\n" + cat + "\n\n")


def assembler_input_text(task: str, route_truth: str, accumulated: str,
                         files_context: str = "") -> str:
    """ОДИН ПИСАР ВХІДНИХ ДАНИХ СКЛАДАЧА. Порядок значущий: спершу ЗАПИТ, потім
    ПЕРВИННІ ДАНІ (джерела правди), і лише потім перекази етапів — інакше модель
    бере за основу переказ, а джерело читає як довідку."""
    out = ["## ЗАПИТ КОРИСТУВАЧА (головне — дай саме це)\n%s\n" % task]
    if files_context:
        out.append(
            "## ПЕРВИННІ ДАНІ З ДОДАНИХ ФАЙЛІВ — ЄДИНЕ ДЖЕРЕЛО ПРАВДИ ДЛЯ ЧИСЕЛ І НАЗВ\n"
            + _tables_catalogue(files_context)
            + fit_context(files_context, FILES_CONTEXT_WINDOW, "доданих файлів") + "\n\n"
            "⛔ ЗАБОРОНЕНО вигадувати числа, назви позицій, номери договорів і назви "
            "клієнтів. Усе це береться ЗВІДСИ ДОСЛІВНО. Якщо якогось числа тут немає — "
            "його не можна написати «приблизно»: або порахуй його ФОРМУЛОЮ з наявних, "
            "або чесно скажи, що даних бракує. Перекази етапів нижче — це аналіз, а не "
            "джерело чисел: де переказ розходиться з цим блоком, правий ЦЕЙ блок.\n")
    if route_truth:
        out.append(
            "## ПЕРЕВІРЕНІ ДАНІ ДВИГУНА — ЄДИНЕ ДЖЕРЕЛО ПРАВДИ (вставити ДОСЛІВНО, НЕ хеджувати)\n"
            + route_truth + "\n\n"
            "Це РЕАЛЬНІ дані з детермінованого маршрутного двигуна (Google): відстань, час, "
            "розбивка по плечах і заклади з рейтингами та кількістю відгуків. Перенеси їх у "
            "фінал ДОСЛІВНО — усі плечі й усі заклади з їхніми рейтингами/відгуками. НЕ "
            "додавай до цих даних міток «оцінка», «не підтверджено», «посилання не "
            "підтверджено»: вони підтверджені двигуном. Відсутність клікабельного URL — НЕ "
            "привід сумніватися. НЕ шукай ці заклади в вебі наново й НЕ заміняй їх "
            "загальними фразами на кшталт «кафе вздовж траси». Якщо серед даних є блок "
            "«ЖИВІ УМОВИ» — виведи ці обмеження/дорожню обстановку з джерелами; і НІКОЛИ "
            "не пиши «обмежень нема / стандартні правила», якщо блок каже інше або каже "
            "«не перевірено».\n")
    out.append("## ЕТАПИ КОНВЕЄРА (аналіз — зібери з нього фінал)\n%s\n\n"
               "Поверни ПОВНИЙ фінальний результат у Markdown, нічого важливого не "
               "пропускаючи (усі таблиці, чеклісти, фінансові цифри). Структура — строго "
               "під запит користувача." % accumulated)
    return "\n".join(out)


def _assembler_models(high_stakes: bool = False) -> list:
    """Ланцюг моделей складальника. ВАРТІСТЬ: для звичайних задач фінал збирає ДЕШЕВА
    модель (worker), а дорогий мозок — лише резерв. Для високих ставок (право/фінанси/
    стратегія) мозок збирає першим (якість). Далі — топ-моделі інших провайдерів як
    крос-провайдерний резерв (збій одного не валить фінал)."""
    models = []

    def add(m):
        if m and m not in models:
            models.append(m)

    if high_stakes:
        # ⭐⭐⭐ 605 (17.09.2026). РЕЗЕРВ НА ВИСОКИХ СТАВКАХ МУСИТЬ БУТИ СИЛЬНИМ.
        # Живий прогін 15:29: мозок віддав порожню відповідь, і фінал ФІНАНСОВОЇ
        # моделі поїхала збирати найдешевша модель у крамниці — одразу після
        # мозку. Вона ж потім вигадала назви колонок і коштувала колом
        # виправлень. Для високих ставок «резерв» — це топ-моделі ІНШИХ
        # провайдерів; дешева робоча модель лишається ОСТАННІМ шансом, щоб
        # людина не лишилась без відповіді взагалі (слово власника 01.08.2026).
        add(config.brain_model())
        for m in _cross_provider_reserve():
            add(m)
        add(config.worker_model())
        return models
    add(config.worker_model())
    add(config.brain_model())
    for m in _cross_provider_reserve():
        add(m)
    return models


# ⭐ 05.08.2026 (ланцюги систем). ПОВТОР МУСИТЬ БУТИ ІНШИМ, А НЕ ТИМ САМИМ.
# Андрій: «оркестратор робить по три повтори з однаковим результатом — це
# релейність». Друга спроба кроку ланцюга йде з ПІДНЯТОЮ підлогою драбини:
# дешеві щаблі, які вже не впорались, просто відрізаються знизу.
# Thread-local, бо сервер багатопотоковий: сусідній прогін не має успадкувати
# чужу підлогу.
import threading as _threading
_FLOOR = _threading.local()


def _step_models() -> list:
    """Ланцюг моделей ЗВИЧАЙНОГО кроку конвеєра — це ДРАБИНА `config.model_ladder()`.

    ⭐⭐⭐ 01.08.2026 (рішення власника). Доти тут стояв «крос-провайдерний резерв»
    БЕЗ мозку: якщо дешевий виконавець і топ-моделі інших провайдерів не давали
    результату, прогін помирав — при тому, що НАЙСТАРША модель лежала поруч і
    була доступна. Клієнт платив і не отримував нічого.
    Тепер драбина одна на весь продукт і закінчується найстаршим доступним."""
    ladder = config.model_ladder() or [config.worker_model()]
    floor = getattr(_FLOOR, "model", "") or ""
    if floor and floor in ladder:
        ladder = ladder[ladder.index(floor):]
    return ladder


def _complete_with_reserve(prompt: str, payload: str, max_out: int,
                           emit=None, agent_id: str = "") -> str:
    """⭐ 29.07.2026. ВІДМОВА ОДНОГО ПОСТАЧАЛЬНИКА БІЛЬШЕ НЕ ВАЛИТЬ ПРОГІН.
    Раніше перший же `LLMError` на кроці повертав `runtime_error`, і сирий текст
    помилки (з чужим номером проєкту) їхав аж до очей клієнта.

    Що НЕ перемикаємо навмисне:
      • `LLMNotConfigured` — немає ключа, резерв не допоможе;
      • `BudgetExceeded` — це не аварія, а запобіжник грошей клієнта, у нього
        власний шлях (пауза з вибором). Перемикання тут витратило б гроші саме
        тоді, коли їх наказано не витрачати."""
    chain = [m for m in (_step_models() or []) if m] or [config.worker_model()]
    last = None
    for i, mdl in enumerate(chain):
        try:
            out = llm.complete(prompt, payload, model=mdl, max_tokens=max_out)
        except llm.LLMNotConfigured:
            raise
        except llm.LLMError as e:
            if failure.is_budget(e):
                raise
            last = e
            nxt = chain[i + 1] if i + 1 < len(chain) else None
            failure.log(e, "executor._complete_with_reserve/%s/%s" % (agent_id or "?", mdl))
            _emit(emit, failure.step_notice(agent_id, e, nxt))
            continue
        # ⭐⭐⭐ 01.08.2026 (рішення власника). ПІДНІМАЄМОСЬ І НА ПОРОЖНЕЧУ, А НЕ
        # ЛИШЕ НА АВАРІЮ. Доти драбина оживала тільки на винятку постачальника —
        # а найдорожчий збій виглядав інакше: модель ВІДПОВІДАЛА, але порожнечею
        # або пробільним місивом. Виняток не летів, драбина спала, і прогін
        # помирав `step_no_result` при повністю доступній старшій моделі.
        # «Краще клієнт скаже, що задорого, ніж що заплатив і не отримав нічого.»
        if not _unusable_step(out):
            if i:
                _emit(emit, "✅ %s: результат дала старша модель." % (agent_id or "крок"))
            return out
        last = llm.LLMError("модель «%s» віддала порожній або вироджений вивід" % mdl)
        nxt = chain[i + 1] if i + 1 < len(chain) else None
        if nxt:
            _emit(emit, "⚠ %s: модель віддала порожнечу — піднімаюсь на старшу…"
                        % (agent_id or "крок",))
        else:
            _emit(emit, "⚠ %s: порожній вивід, а старших моделей більше немає."
                        % (agent_id or "крок"))
    raise last or llm.LLMError("жоден постачальник не відповів")


def _fallback_plan(system: dict, prompts: dict) -> dict:
    ids = list(prompts["agents"].keys()) or _registry_agent_ids(system)
    critic = next((a for a in ids if _looks_critic(a)), None)
    reviser = next((a for a in reversed(ids) if _looks_reviser(a)), None)
    return {
        "system_understanding": system.get("description", "") or "Послідовний конвеєр агентів.",
        "required_inputs": [],
        "pipeline": [{"agent": a, "purpose": "виконати свій етап", "produces": "",
                      "needs_web_search": _looks_research(a)} for a in ids],
        "quality_loop": {"enabled": bool(critic and reviser), "critic_agent": critic,
                         "reviser_agent": reviser, "pass_threshold": "9/10", "max_iterations": 2},
        "final_deliverable": "Готовий результат системи.",
        "success_criteria": ["Результат не порожній", "Відповідає задачі"],
    }


def _normalize_plan(plan: dict, system: dict, fallback: dict) -> dict:
    if not isinstance(plan, dict):
        return fallback
    valid_ids = set(_registry_agent_ids(system))
    pipeline = plan.get("pipeline") or []
    norm_pipe = []
    for step in pipeline:
        if isinstance(step, dict) and step.get("agent"):
            norm_pipe.append({"agent": step["agent"],
                              "purpose": step.get("purpose", ""),
                              "produces": step.get("produces", ""),
                              "needs_web_search": bool(step.get("needs_web_search", False))})
        elif isinstance(step, str):
            norm_pipe.append({"agent": step, "purpose": "", "produces": "", "needs_web_search": False})
    if not norm_pipe:
        norm_pipe = fallback["pipeline"]
    plan["pipeline"] = norm_pipe
    ql = plan.get("quality_loop") or {}
    plan["quality_loop"] = {
        "enabled": bool(ql.get("enabled")),
        "critic_agent": ql.get("critic_agent"),
        "reviser_agent": ql.get("reviser_agent"),
        "pass_threshold": ql.get("pass_threshold", "9/10"),
        "max_iterations": min(int(ql.get("max_iterations") or 2), HARD_MAX_REVISIONS),
    }
    plan.setdefault("required_inputs", [])
    plan.setdefault("success_criteria", fallback["success_criteria"])
    plan.setdefault("system_understanding", fallback["system_understanding"])
    plan.setdefault("final_deliverable", fallback["final_deliverable"])
    return plan


# ---------------------------------------------------------------------------
# Допоміжне
# ---------------------------------------------------------------------------
def _looks_critic(agent_id: str) -> bool:
    a = (agent_id or "").lower()
    return any(k in a for k in ("critic", "review", "quality", "qa", "верифік", "критик"))


def _unusable_step(text) -> bool:
    """ОДИН ПИСАР «крок не дав результату» (01.08.2026).

    Порожньо АБО місиво. Доти ці два стани жили нарізно: `_degenerate_step`
    ловив лише пробільне місиво (300+ пробілів), а ПОРОЖНІЙ вивід не ловив
    ніхто — він тихо їхав далі, і складальник добудовував пропуск загальними
    словами. Заглушка з пробілів («   ») проходила як результат.
    Короткий, але змістовний вивід — це РЕЗУЛЬТАТ (критик легітимно відповідає
    коротко), тому міряємо не довжину, а наявність змісту."""
    return (not str(text or "").strip()) or _degenerate_step(text)


def _degenerate_step(text: str) -> bool:
    """Пробільна деградація ВИВОДУ КРОКУ (модель зациклилась і ллє пробіли —
    «зависання» договірного прогону 10.07). Ловимо ОДРАЗУ на кроці, а не на межі
    видачі, щоб не палити хвилини й не тягти місиво в наступні кроки.
    Короткі/порожні виводи тут НЕ караємо: критик легітимно відповідає коротко."""
    t = text or ""
    if re.search(r"\s{300,}", t):
        return True
    if len(t) >= 800:
        real = re.sub(r"\s+", "", t)
        if len(real) / len(t) < 0.35:
            return True
    low = t.lower()
    # ВИТІК СИРОГО ВИКЛИКУ ІНСТРУМЕНТА у видимий текст: кодова модель (Kimi-code)
    # без реального каналу пошуку балакає сама з собою й вивалює tool-розмітку
    # замість відповіді (зрив юриста 20.07.2026). У ФІНАЛЬНОМУ виводі такого бути
    # не може — ловимо одразу, не тягнемо місиво у файл.
    if ("<tool>" in low or "</tool>" in low or "<parameter name=" in low
            or "to=default." in low or "\nfunctions." in low):
        return True
    # БАЛАКУЧА ПЕТЛЯ: службові фрази-самокоманди повторюються багато разів
    # («Use web_search… wait for result… Done…»). Легітимний текст їх не множить.
    for _m in ("use web_search", "i need to stop", "wait for result",
               "the tool call", "let's wait", "i will now end", "use tool. done"):
        if low.count(_m) >= 4:
            return True
    return False


def _looks_reviser(agent_id: str) -> bool:
    a = (agent_id or "").lower()
    return any(k in a for k in ("syle", "style", "writ", "edit", "стиль", "редакт", "writer"))


def _looks_research(agent_id: str) -> bool:
    a = (agent_id or "").lower()
    return any(k in a for k in ("research", "search", "data", "news", "market", "trend",
                                "дослід", "пошук", "ринок", "новин", "джерел", "scout", "intel"))


# ---------------------------------------------------------------------------
# КОНТРАКТ НАМІРУ (10.07.2026): мозок раз на задачу декларує, що їй потрібно;
# executor ВИКОНУЄ контракт. Інструмент кроку = перетин «роль вміє (паспорт
# registry.get_roles) І контракт вимагає». Keyword-вгадувачки прибрано повністю.
# ---------------------------------------------------------------------------
_INTENT_OUTPUTS = ("chat_answer", "document", "estimate_sheet", "financial_model", "report")


def _settled_output(d) -> str:
    """Тип результату — рішення ОДНОГО писаря (`understanding.settle_output`).
    Імпорт лінивий: `understanding` тягне за собою довідник галузей."""
    out = d.get("output") if d.get("output") in _INTENT_OUTPUTS else "chat_answer"
    import understanding as _und
    return _und.settle_output({"output": out, "computation": d.get("computation")})


def _norm_intent(intent) -> dict:
    """Контракт наміру від мозку з захисними дефолтами (консервативно: нічого
    зайвого не вмикаємо; недодеклароване лікує добірка needs_capability)."""
    d = intent if isinstance(intent, dict) else {}
    return {
        "fresh_data": d.get("fresh_data") if d.get("fresh_data") in ("none", "required") else "none",
        "computation": d.get("computation") if d.get("computation") in ("none", "required") else "none",
        # ⛒ ТИП РЕЗУЛЬТАТУ ВИРІШУЄ ОДИН ПИСАР (зміна 253): замовлено розрахунок,
        # а результат названо звітом — беремо СУВОРІШЕ, бо числа мусять бути
        # живими. Ворота формул нижче вже дивляться на ВИРІШЕНИЙ контракт, і
        # вмикати їх окремо не треба — інакше правил стало б два.
        "output": _settled_output(d),
        # ⭐⭐⭐ 10.08.2026. «РЕЛЕЙНА ШАФА»: ЩО ЗАМОВЛЕНО, А ЩО СИСТЕМА ВМІЄ.
        # Живий випадок 09.08: людина попросила ТАБЛИЦЮ КАФЕ на відтинку трси —
        # а система «Пошук обʼєктів на маршруті» вимагала «звідки/куди» і віддала
        # чесний стоп про маршрут. Маршрут — це ВМІННЯ системи, а не замовлення
        # людини. Тепер намір декларує це прямо, і рішення ухвалює КОД, а не
        # нюхачка по тексту запиту. Дефолт консервативний: не замовляли — не
        # вимагаємо.
        "route": d.get("route") if d.get("route") in ("none", "required") else "none",
        # ⭐⭐⭐ 11.08.2026 (зміна 150). ГАЛУЗЬ І ЮРИСДИКЦІЯ — ОГОЛОШЕННЯ, А НЕ
        # ВГАДУВАННЯ. Другий рубіж після `enum` провайдера: чуже значення НЕ
        # «підбирається до найближчого», а чесно стає «unknown». Невідома
        # галузь не вмикає ЖОДНИХ доменних воріт — саме тому, що ворота, які
        # спрацювали не у своїй галузі, і є дефект, який ми лікуємо.
        "domain": (d.get("domain") if _domains_known(d.get("domain")) else "unknown"),
        "jurisdiction": (str(d.get("jurisdiction") or "").strip().upper()
                         if _jurisdiction_known(d.get("jurisdiction"))
                         else (getattr(config, "DEFAULT_JURISDICTION", "UA") or "UA")),
    }


def _domains_known(did) -> bool:
    try:
        import domains as _dm
        return _dm.is_known(did)
    except Exception:
        return False


def _jurisdiction_known(jid) -> bool:
    try:
        import domains as _dm
        return _dm.jurisdiction_is_known(jid)
    except Exception:
        return False


def _role_tools(roles: dict, agent_id: str) -> dict:
    return ((roles or {}).get(agent_id) or {}).get("tools") or {}


def _synth_agent_prompt(system: dict, agent_id: str, purpose: str = "") -> str:
    return (f"# {agent_id}\n## РОЛЬ\nАгент «{agent_id}» системи «{system.get('name')}». "
            f"{('Призначення: ' + purpose) if purpose else ''}\n"
            "## ФОРМАТ ВІДПОВІДІ\nMarkdown: статус, дії, результат етапу, відкриті питання.")


def _convo(history) -> str:
    out = ""
    for turn in (history or [])[-6:]:
        role = "Користувач" if turn.get("role") == "user" else "Оркестратор"
        out += f"{role}: {turn.get('content','')}\n"
    return out


def _threshold_value(pass_threshold: str) -> int:
    import re
    m = re.search(r"(\d{1,2})", str(pass_threshold or "9"))
    return int(m.group(1)) if m else 9


def _critic_satisfied(critic_text: str, threshold: int) -> bool:
    import re
    t = (critic_text or "").lower()
    for m in re.findall(r"(\d{1,2})\s*/\s*10", t):
        if int(m) >= threshold:
            return True
    for m in re.findall(r"(\d{1,2})\s*бал", t):
        if int(m) >= threshold:
            return True
    if any(k in t for k in ("готово до публікації", "схвалено", "approved", "без зауважень")):
        return True
    return False


# ---------------------------------------------------------------------------
# Фаза 2: ворота уточнень (за required_inputs з плану + кореневих правил)
# ---------------------------------------------------------------------------
def _gate_degraded_note(reason: str = "") -> str:
    """⭐⭐⭐ 05.08.2026, питання клієнта. Тут стояв НЕРУХОМИЙ текст, який закінчувався
    словами «причина збою записана в журналі платформи». Клієнт прочитав це і спитав:
    «Что это означает? не указал где смотреть данные?» — і мав рацію двічі.
    По-перше, зупинка не називала своєї причини (той самий клас, що й «уточніть
    задачу» замість «вперся у стелю кроків»). По-друге, ми відсилали ЛЮДИНУ в НАШ
    журнал — туди, куди їй ходити не треба й нічим.
    Тепер причину перекладає `failure` — той самий один писар правди «що людина
    бачить, коли зламалось», — а машинний слід і далі лишається в журналі."""
    human = ""
    try:
        human = failure.client_text(RuntimeError(str(reason or "")))
    except Exception:
        human = ""
    # Невпізнану аварію `failure` описує найзагальнішим текстом, який відсилає в
    # журнал платформи. Для КЛІЄНТА це порожній звук: журнал не його інструмент.
    # Не впізнали причину — чесно мовчимо про неї, а не вдаємо пораду.
    if "журнал" in (human or ""):
        human = ""
    return artifacts.platform_note(
        "> ⚠ **Перевірку «чи вистачає даних» виконати не вдалось.** "
            + ((human.strip() + " ") if human else "")
            + "Щоб цей збій не забрав у вас роботу, я працював з тим, що було в запиті. "
              "Якщо якихось даних бракувало, я міг ужити розумні припущення — "
              "перевірте, будь ласка, цифри й факти перед використанням.")


def _gate_must_be_strict(system: dict, intent: dict) -> bool:
    """ДЕ ЦІНА ПОМИЛКИ НЕПРИЙНЯТНА — там закриті ворота лишаються.

    ⭐⭐⭐ 01.08.2026, живий випадок у клієнта. Запобіжник 30.07 мав рацію в
    головному («не зміг перевірити» ≠ «перевірив, усе гаразд»), але міряв УСЕ
    однією суворістю. Через це збій дешевої моделі зачиняв двері перед будь-якою
    роботою — навіть там, де найгіршим наслідком було б «текст треба трохи
    правити». Реальний запит клієнта загинув на порозі двічі.

    Суворо (чесний стоп) — там, де помилка коштує грошей або права: правова
    система, числова задача, фінмодель, кошторис. Решта — працюємо і ПИШЕМО
    правду про невиконану перевірку [[_gate_degraded_note]].
    """
    if _is_legal_system(system):
        return True
    i = intent or {}
    if i.get("computation") == "required":
        return True
    if i.get("output") in ("financial_model", "estimate_sheet"):
        return True
    return False


# ⭐⭐⭐ 09.08.2026. ОДИН ПИСАР ПРАВДИ ПРО МОЖЛИВОСТI ПЛАТФОРМИ.
# 🩸 Два платнi прогони Андрiя провалились одне за одним, бо про живий веб не знав
# то мозок (вiдмовив вiд iменi системи), то КОНТРОЛЕР УТОЧНЕНЬ (зупинив систему ДО
# роботи й попросив принести резюме). Кожен виправлявся окремо — i це була латка.
# КЛАС: будь-який промпт, де модель говорить ВIД IМЕНI ПЛАТФОРМИ, мусить знати межi
# платформи. Текст живе в ОДНОМУ мiсцi й пiдкладається в УСI такi промпти.
def platform_reach_note() -> str:
    """Правда про доступ платформи до свiту — для КОЖНОГО промпта, де модель
    говорить вiд її iменi. Порожньо, якщо вебу справдi немає (не вчимо брехати)."""
    try:
        if not config.web_search_ready():
            return ""
    except Exception:
        return ""
    return (
        "\n\nМОЖЛИВОСТI ЦIЄЇ ПЛАТФОРМИ (факт, не припущення): вона МАЄ живий "
        "інтернет — сама шукає в мережі і ВІДКРИВАЄ знайдені сторінки, працюючи з "
        "їхнім справжнім текстом (вакансії, резюме, оголошення, ціни, новини, "
        "чинні норми, вміст конкретного сайту). "
        "ТОМУ: НЕ пиши, що не маєш доступу до інтернету чи до зовнішніх платформ; "
        "НЕ проси користувача принести дані, які можна знайти в мережі; "
        "НЕ зупиняй роботу через брак таких даних. "
        "Питай користувача ЛИШЕ про те, чого в мережі немає: його внутрішні файли "
        "й документи, приватні дані, особисті вподобання, рішення та пріоритети.\n"
    )


# ⭐⭐⭐ 17.08.2026 (зміна 199). ВОРОТА ДОСТАТНОСТІ НЕ ЧИТАЮТЬ ДОКУМЕНТИ ЦІЛКОМ.
# 🩸🩸🩸 ЖИВА АВАРІЯ У КЛІЄНТА (Каспер, 19:32). Платформа зупинилась на кожній
# тендерній задачі зі словами «не вдалося перевірити, чи вистачає вхідних даних:
# model_format». Прогін коштував $0.1995 замість звичних $0.02-0.05.
# КОРІНЬ. Тут стояло `f"## ФАЙЛИ\n{files_context}\n"` — увесь текст документів
# замовника йшов у промпт БЕЗ ЖОДНОЇ СТЕЛІ, і питали ним НАЙДЕШЕВШУ модель
# (`config.worker_model()`). Поки бюджет матеріалу був 120 000 знаків, це
# трималось. У 1.0.18 `tender_docs.MATERIAL_BUDGET` виріс до 300 000 (у 2,5 раза,
# плюс уперше почали читатись старі `.doc`) — і дешевий виконавець почав
# віддавати порожнечу. Про цю саму поведінку прямо написано в `llm.judge_json`:
# «дешевий виконавець на великих промптах віддає порожнечу». Далі повтор,
# ескалація, `JudgeUnavailable` — і назовні це виглядає як `model_format`.
# ⛒ ЗАКОН: ВОРОТА СУДЯТЬ ЗАДАЧУ, А НЕ ДОКУМЕНТИ. Щоб вирішити «чи зрозуміло, що
# робити», не потрібен повний текст додатків — потрібні задача, діалог і ФАКТ,
# що документи є. Тому тут стеля, і вона НЕ МОВЧАЗНА: модель прямо попереджено,
# що обрізано лише цей витяг, а виконавцю документи дістануться повністю —
# інакше ворота зробили б із власного обрізання висновок «даних не вистачає».
# ⚠ Стеля живе ТУТ, а не в `source_intake`: обсяг матеріалу для РОБОТИ — окреме
# питання, і зменшувати його заради воріт означало б різати сам продукт.
PRECHECK_FILES_CAP = 12000


def _precheck_files_block(files_context: str) -> str:
    """Блок «ФАЙЛИ» для воріт достатності: не більше `PRECHECK_FILES_CAP` знаків."""
    txt = str(files_context or "")
    if not txt.strip():
        return ""
    if len(txt) <= PRECHECK_FILES_CAP:
        return "## ФАЙЛИ\n%s\n" % txt
    return (
        "## ФАЙЛИ (початок витягу)\n%s\n\n"
        "⚠ Вище — ПЕРШІ %d знаків із %d. Документи прикріплено до задачі ПОВНІСТЮ і "
        "виконавець отримає їх цілком; обрізано лише цей витяг для перевірки. "
        "НЕ роби з обрізання висновку, що даних не вистачає, і НЕ питай про те, що "
        "може бути далі в тексті.\n" % (txt[:PRECHECK_FILES_CAP], PRECHECK_FILES_CAP, len(txt)))


# ⭐⭐⭐ 556. ЩО СУДДЯ ЗНАЄ ПРО СИСТЕМУ: ОГОЛОШЕНЕ, А НЕ НАКАЗ.
# Раніше сюди йшов кореневий промпт виконавця — інструкція «зроби X», яку
# суддя й виконував. Тепер ідуть ФАКТИ: назва, опис із реєстру і рядкові поля
# паспорта (для чого · що на вхід · чого не робить). Це коротше в рази і за
# природою не є наказом. Закон 545: судити ОГОЛОШЕНЕ, а не дораховане.
def _system_facts(system: dict) -> str:
    """Оголошені факти про систему для судді. Порожньо — якщо оголошень немає."""
    s = system or {}
    out = []
    for label, key in (("Система", "name"), ("Призначення", "description")):
        v = str(s.get(key) or "").strip()
        if v:
            out.append("%s: %s" % (label, v[:600]))
    try:
        import routing_card as _rc
        card = s.get("routing_card") or _rc.load(s) or {}
    except Exception:
        card = {}
    for key, label in (("for_tasks", "Для яких задач"),
                       ("inputs", "Що потрібно на вхід"),
                       ("outputs", "Що віддає"),
                       ("not_for", "Чого НЕ робить")):
        v = card.get(key)
        if isinstance(v, (list, tuple)):
            v = "; ".join(str(x).strip() for x in v if str(x).strip())
        v = str(v or "").strip()
        if v:
            out.append("%s: %s" % (label, v[:500]))
    return "\n".join(out)


def precheck_inputs(system: dict, plan: dict, task: str, files_context: str, history,
                    needs_calc: bool = False) -> dict:
    required = plan.get("required_inputs") or []
    root_prompt = _system_root_prompt(system)
    _facts = _system_facts(system)
    calc = bool(needs_calc)  # з контракту наміру (мозок), не з keyword-здогадок
    if not required and not root_prompt and not calc:
        return {"ready": True}
    controller = (
        "Ти — оркестратор системи. Твоя мета — ВИКОНАТИ задачу, а не допитувати користувача. "
        f"Бажані (не обовʼязкові) вхідні дані за логікою системи: {json.dumps(required, ensure_ascii=False)}.\n"
        # 🩸 556. Кореневий промпт ВИКОНАВЦЯ сюди більше не потрапляє: суддя
        # виконував його замість судження. Ідуть лише ОГОЛОШЕНІ факти, і то
        # в рамці матеріалу — щоб наказова форма всередині нічого не наказала.
        + (llm.as_data(_facts, "довідка про систему, для якої судиш") if _facts else "")
        + "ПРАВИЛО (важливо): запитуй ЛИШЕ тоді, коли без даних результат буде ПРИНЦИПОВО "
        "неправильним або неможливим (немає обовʼязкового файлу/документа, незрозумілий сам "
        "предмет задачі, відсутні критичні для безпеки/права дані). Якщо тему, аудиторію, мету, "
        "мову чи формат уже видно з запиту АБО їх можна розумно припустити — став ready=true і "
        "НЕ питай. Дрібниці (нюанс теми, хештеги, зображення, стиль оформлення) НЕ питай — "
        "приймай розумні припущення сам. За замовчуванням схиляйся до ready=true. "
        + ("\nФІНАНСОВИЙ ВИНЯТОК (це числова/фінансова задача, тут помилятись НЕ МОЖНА): "
           "критичні параметри розрахунку — відсоткова ставка; дата видачі/першого платежу "
           "(якщо в результаті є дати); комісії, страховки та інші додаткові збори. Якщо "
           "якогось із них НЕМАЄ в запиті і він впливає на числа — постав ready=false і спитай "
           "ЛИШЕ відсутні критичні параметри, одним повідомленням, максимум 3 питання. Якщо "
           "користувач уже відповів на це раніше в діалозі — НЕ перепитуй. " if calc else "")
        + "\nВИНЯТОК ОБСЯГУ (щоб не видати частину за ціле): якщо задача просить охопити "
          "БАГАТО одиниць одразу («весь сайт», «усі сторінки», «усі розділи», «кожен …», "
          "«усе одразу»), а якісний результат за один прохід реальний лише для ОДНІЄЇ "
          "одиниці — постав ready=false і ОДНИМ повідомленням спитай, чи робити по черзі "
          "та з якої одиниці почати. Якщо користувач уже назвав конкретну одиницю (одну "
          "сторінку/розділ) АБО обсяг реально посильний за прохід — ready=true, не питай. "
          "Ніколи не звужуй масовий запит мовчки й не видавай одну одиницю за все. "
        + platform_reach_note()
        + 'Поверни JSON: {"ready": true|false, "questions": ["1-2 КРИТИЧНІ питання лише якщо справді блокують"]}.'
    )
    user = (f"## ЗАДАЧА\n{task}\n\n## ДІАЛОГ\n{_convo(history)}\n"
            + _precheck_files_block(files_context))
    try:
        d = llm.judge_json(controller, user, temperature=0.1, model=config.worker_model(),
                           purpose="достатність вхідних даних")
    except llm.LLMError as e:
        # ⛔ 30.07.2026. Тут стояло `return {"ready": True}` — тобто збій моделі
        # оголошував, що ВХІДНИХ ДАНИХ ВИСТАЧАЄ. Це та сама хвороба, що й у
        # контролі якості: перевірка, яка при збої каже «чисто», — це відсутня
        # перевірка. Тепер збій називає себе, а рішення ухвалює виклик.
        # ⛔ «НЕ ЗМІГ ПЕРЕВІРИТИ» ≠ «ПЕРЕВІРИВ, УСЕ ГАРАЗД».
        return {"ready": False, "checked": False, "error": e, "questions": []}
    # Питання без тексту — це не питання: контролер сказав «не готово», але не
    # назвав чого бракує. Такий стан НЕ має права стати мовчазним «готово» вище
    # по течії, тому нижче він теж лишається «не перевірено».
    qs = [q for q in (d.get("questions") or []) if (q or "").strip()][:4]
    if not d.get("ready") and qs:
        return {"ready": False, "checked": True, "questions": qs}
    if not d.get("ready"):
        return {"ready": False, "checked": False, "questions": [],
                "error": "контролер сказав «даних не вистачає», але не назвав, яких саме"}
    return {"ready": True, "checked": True}


# ---------------------------------------------------------------------------
# «Жодних чисел з голови»: ЧИ потрібен калькулятор — вирішує КОНТРАКТ НАМІРУ
# від мозку (intent.computation), а КОМУ він дістається — паспорт ролей системи.
# Колишні keyword-вгадувачки (_needs_calc + 4 словники + виняток договорів)
# прибрано повністю 10.07.2026 — див. DESIGN_Контракт_наміру.md.
# ---------------------------------------------------------------------------


_CALC_TOOL = [{
    "name": "run_python",
    "description": ("Калькулятор: виконати короткий Python-код в ізольованому середовищі "
                    "і отримати надруковані (print) результати. Усі обчислювані числа твоєї "
                    "відповіді мають походити звідси."),
    "parameters": {"type": "object", "properties": {
        "code": {"type": "string", "description":
                 "Python-код; усі потрібні значення надрукуй через print() з підписами"}},
        "required": ["code"]},
}]
_CALC_MAX_TURNS = 8  # стеля ходів tool-циклу одного агента (вартість/зациклення)
_CALC_FASTFAIL_TURNS = 3  # А+ (баг №4 16.07): дешевій моделі даємо лише кілька ходів
                          # (фейл-фаст), тоді одразу надійна — не крутимо 8 ходів упусту


def _calc_fallback_model() -> str:
    """Модель ДРУГОЇ спроби розрахункового кроку. Слабкий виконавець (gemini-flash)
    на великих запитах повертає порожні tool-ходи — надійний шлях tool-викликів
    доведений на Anthropic (мозок 🧮 працює щопрогону). Дорожче, але лише для
    числових кроків, де помилятись не можна."""
    return config.reliable_model()


# ⭐⭐⭐ 12.08.2026 (зміна 164). КРОК АГЕНТА БІЛЬШЕ НЕ ЗНАЄ ЛИШЕ КАЛЬКУЛЯТОР.
# 🩸 КОРІНЬ: зміна 162 навчила ворота пропускати роботу, коли вхід (пошта,
# календар) підключений, — але виконати її крокові було НІЧИМ: у tool-цикл
# намертво був зашитий один інструмент. Тобто щойно пошту підключено, ворота
# кажуть «можна», а агент відповідає з памʼяті моделі. Це рівно той клас
# мовчазної підміни, який лікувала 162, поверхом нижче.
# ⛒ НАБІР ІНСТРУМЕНТІВ КРОКУ СКЛАДАЄ ВИКЛИКАЧ (контракт × паспорт ролі), а
# цикл лише виконує названий інструмент. Виконавці — з ОДНОГО реєстру.
def _tool_result_text(name: str, args: dict) -> str:
    """Що повертається моделі після виклику інструмента. ⛒ Один писар на всі
    інструменти кроку: інакше кожен новий інструмент приносив би свій формат
    відповіді, і той, хто про нього забуде, зʼїсть помилку мовчки."""
    if name == "run_python":
        r = tools.run_python((args or {}).get("code", ""))
        if r.get("ok"):
            return "Результат обчислення (stdout):\n" + r.get("stdout", "")
        return (f"Калькулятор НЕ виконав код: {r.get('note','')}. Виправ код і повтори; "
                "числа без розрахунку не наводь.")
    res = connector_tools.run(name, args or {})
    return res.get("text") or "Інструмент «%s» нічого не повернув." % name


def _run_agent_tools(agent_prompt: str, payload: str, tool_specs: list = None, emit=None,
                     agent_id="", model: str = None, max_turns: int = _CALC_MAX_TURNS):
    """Крок агента з інструментами: tool-цикл до фінального тексту.
    Повертає (text, reason): текст або "", і людську причину, чому текст
    порожній — викликач робить fallback і ПОКАЗУЄ причину (не ковтає).
    max_turns — стеля ходів саме цієї спроби (А+: дешева модель = фейл-фаст)."""
    specs = list(tool_specs or _CALC_TOOL)
    messages = [{"role": "user", "content": payload}]
    for _ in range(max_turns):
        turn = llmtools.tool_turn(agent_prompt, messages, specs,
                                  model=model or config.worker_model(),
                                  max_tokens=config.CALC_TURN_MAX_TOKENS)
        calls = turn.get("tool_calls") or []
        if not calls:
            text = turn.get("text") or ""
            if text.strip():
                return text, ""
            return "", "модель повернула порожню відповідь без виклику інструмента"
        messages.append({"role": "assistant", "content": turn.get("text") or "",
                         "tool_calls": calls})
        for tc in calls:
            _name = tc.get("name") or "run_python"
            _icon = "🧮" if _name == "run_python" else connector_tools.human_label(_name)[0]
            _what = ("розрахунок калькулятором" if _name == "run_python"
                     else connector_tools.human_label(_name)[1].lower())
            _emit(emit, f"{_icon} {agent_id}: {_what}…")
            content = _tool_result_text(_name, tc.get("args") or {})
            messages.append({"role": "tool", "tool_call_id": tc.get("id"),
                             "name": _name, "content": content})
    return "", f"вичерпано стелю {max_turns} ходів tool-циклу без фінальної відповіді"


# ---------------------------------------------------------------------------
# Фаза 3-4: виконання за планом + цикл якості
# ---------------------------------------------------------------------------
def _run_agent(system, step, idx, total, plan, task, convo, files_context, accumulated,
               live_data="", style="", use_calc=False, emit=None, seo_page="",
               offer_capability=False, legal_note="", offer_web=False, conn_tools=None):
    # legal_note (30.07.2026): готовий блок про ВСТАНОВЛЕНИЙ РЕЖИМ ПРОЦЕДУРИ від
    # правового ядра. Складає його run_system ОДИН раз на прогін — тут ми лише
    # кладемо його в payload перед запитом користувача. Навіщо: раніше режим
    # знало тільки ядро на виході, агент його не бачив і називав свій.
    agent_id = step["agent"]
    prompt = _load_agent_prompt(system, agent_id) or _synth_agent_prompt(system, agent_id, step.get("purpose", ""))
    kb = knowledge.load_relevant(system, task)
    # БУДІВНИК: його агенти носять повні промпти/структуру майбутньої системи —
    # їм потрібні вища стеля виводу і ширше вікно попередніх етапів (план Аналітика
    # не має обрізатися хвостом у Структуролога).
    _is_builder = (system or {}).get("id") == "system_builder"
    # SEO/GEO-крок із реальною сторінкою (seo_page присутній) пише повний план —
    # даємо довший ліміт, щоб чернетка не рвалась (важкий JSON уже в матеріалізаторі).
    _is_long_seo = bool(seo_page)
    _max_out = (config.BUILDER_MAX_TOKENS if _is_builder
                else config.AGENT_MAX_TOKENS_LONG if _is_long_seo
                else config.AGENT_MAX_TOKENS)
    _acc_win = 24000 if _is_builder else 8000
    payload = (
        (f"## {style}\n\n" if style else "")
        + (f"## ПРАВИЛО ЧИСЕЛ (обовʼязкове)\n{config.CALC_NOTE}\n\n" if use_calc else "")
        # ⭐⭐⭐ 12.08.2026 (164). ДОСТУП Є — ЗНАЧИТЬ, ВИГАДУВАТИ ЗАБОРОНЕНО.
        # Інструмент без цього правила лікує лише половину хвороби: модель, яка
        # МОЖЕ прочитати листи, усе одно вміє «пригадати» їх з голови, і людина
        # побачить правдоподібні листи, яких немає.
        + (("## ПРАВИЛО ЧУЖОГО СЕРВІСУ (обовʼязкове)\nТобі видано доступ: %s. "
            "Кожен факт про листи чи події бери ЛИШЕ з виклику цього інструмента "
            "— жодних листів, тем, відправників чи подій з памʼяті. Інструмент "
            "повернув порожньо — так і напиши: за цей період нічого немає.\n\n"
            % ", ".join(connector_tools.TOOLS[t]["name"] for t in (conn_tools or [])))
           if conn_tools else "")
        # ЧЕСНА ДОБІРКА (контракт наміру): без калькулятора агент не рахує «в умі» —
        # він чесно сигналить, і мозок перезапустить прогін із розширеним контрактом.
        + ("## ЯКЩО БРАКУЄ КАЛЬКУЛЯТОРА\nЦьому прогону НЕ видано калькулятор. Якщо для "
           "якісного результату справді ПОТРІБНІ точні обчислення (не груба прикидка "
           "і не переписування готових чисел) — НЕ рахуй в умі: виведи окремим рядком "
           "`NEEDS_CAPABILITY: calculator` і зупинись.\n\n"
           if (offer_capability and not use_calc) else "")
        # ⭐⭐⭐ 09.08.2026. ЧЕСНА ДОБIРКА ЖИВИХ ДАНИХ (дзеркало калькулятора).
        # КОРIНЬ: коли контракт намiру не вимагав свiжих даних, вебу крок не
        # дiставав - i агент вiдповiдав З ПАМʼЯТI МОДЕЛI або казав «не маю
        # доступу до інтернету». Саме це почув клiєнт вiд рекрутингової системи.
        # ⭐ ПЛАТФОРМА, ЯКА ВМIЄ, НЕ СМIЄ КАЗАТИ, ЩО НЕ ВМIЄ: замiсть вiдмови
        # агент СИГНАЛИТЬ, i мозок робить ОДИН перезапуск iз живим вебом.
        # Ворота структурнi: показуємо блок лише тодi, коли живих даних НЕМАЄ,
        # а веб у платформи Є. Жодного вгадування за словами запиту.
        + (platform_reach_note() + "\n## ЯКЩО БРАКУЄ ЖИВИХ ДАНИХ З ІНТЕРНЕТУ\nЦьому кроку НЕ передано живих "
           "даних з вебу. Якщо чесна відповідь на запит НЕМОЖЛИВА без актуальних "
           "зовнішніх даних (свіжі ціни, вакансії, резюме, оголошення, новини, "
           "чинна редакція норм, вміст конкретного сайту) — НЕ відповідай з пам'яті "
           "й НЕ пиши, що не маєш доступу до інтернету: у цієї платформи живий веб Є. "
           "Виведи окремим рядком `NEEDS_CAPABILITY: web` і зупинись — платформа "
           "перезапустить крок уже з живими даними.\nЯкщо ж задачу можна виконати "
           "коректно на наданих матеріалах — просто виконуй її.\n\n"
           if offer_web else "")
        + f"## ЗАГАЛЬНА ЛОГІКА СИСТЕМИ\n{plan.get('system_understanding','')}\n\n"
        + (f"## БАЗА ЗНАНЬ СИСТЕМИ (довідка — застосовуй доречні фреймворки/норми, не вивалюй усе)\n{kb}\n\n" if kb else "")
        # Режим процедури — ФАКТ від ядра, і агент має бачити його ДО запиту.
        + (f"{legal_note}\n\n" if legal_note else "")
        + f"## ЗАПИТ КОРИСТУВАЧА\n{task}\n\n"
        # ⭐ 10.08.2026, зміна 143. СКЛАДАЧ МУСИТЬ ЗНАТИ ЗАМОВЛЕНИЙ ОБСЯГ.
        # Ворота якості судять результат за замовленим числом, а виконавець про
        # це число не знав — і віддавав 5 тем із 8. Далі прогін падав і робився
        # ВДРУГЕ, тобто клієнт платив двічі за ту саму роботу. Це не проханн��
        # «постарайся», а факт замовлення, який виконавець має бачити.
        + (f"## ЗАМОВЛЕНИЙ ОБСЯГ\nЛюдина назвала число: **{wanted_count(task)}**. "
           f"Стільки одиниць і має бути в результаті. Якщо стільки не виходить — "
           f"скажи ПРЯМО, скільки вийшло і чому; не добирай кількість здогадами "
           f"і не мовчи про недобір.\n\n" if wanted_count(task) else "")
        # Той самий закон, що й для решти вставок: рiжемо через одного писаря,
        # зберiгаючи ПОЧАТОК (там сигнали сторiнки) i називаючи рiз вголос.
        + (f"{fit_context(seo_page, 16000, 'прочитаної сторiнки')}\n\n" if seo_page else "")
        + (f"## КОНТЕКСТ ДІАЛОГУ\n{convo}\n" if convo else "")
        + (f"## ДОДАНІ ФАЙЛИ\n{fit_context(files_context, FILES_CONTEXT_WINDOW, 'доданих файлів')}\n\n" if files_context else "")
        + (f"## ЖИВІ ДАНІ З ВЕБ-ПОШУКУ (спирайся на них і на джерела)\n"
           f"{fit_context(live_data, LIVE_DATA_WINDOW, 'живих даних')}\n\n"
           if live_data else "")
        # ⭐⭐⭐ КОРІНЬ 10.08.2026 (зміна 148). МОВЧАЗНЕ ОБРІЗАННЯ ЕТАПІВ.
        # Тут стояло `accumulated[-_acc_win:]` — ОСТАННІ 8 000 знаків. Викидався
        # ПОЧАТОК, а саме там агент-пошуковик тримав таблицю знайдених
        # постачальників. Наступний агент її не бачив і писав «дані обрізано»,
        # ЗДОГАДУЮЧИСЬ, бо платформа про різ мовчала. Той самий клас, що вже
        # вилікуваний для доданих файлів: один писар `fit_context` — голова
        # лишається, ріжеться середина, і різ називає себе вголос.
        + (f"## РЕЗУЛЬТАТИ ПОПЕРЕДНІХ АГЕНТІВ\n"
           f"{fit_context(accumulated, _acc_win, 'результатів попередніх етапів')}\n\n"
           if accumulated else "")
        + f"## ТВІЙ КРОК ({idx}/{total})\nПризначення: {step.get('purpose','виконати свій етап')}.\n"
        + (f"Очікуваний результат кроку: {step.get('produces','')}\n" if step.get("produces") else "")
        + "Виконай свій етап згідно своєї ролі. Будь змістовним, але стислим — "
          "пиши по суті, без зайвої багатослівності.\n\n" + _ART
    )
    # ⭐⭐⭐ 12.08.2026 (164). НАБІР ІНСТРУМЕНТІВ КРОКУ. Калькулятор — як був
    # (контракт × паспорт); інструменти чужого сервісу — рівно ті, що дозволив
    # ПАСПОРТ РОЛІ і що справді доступні (`conn_tools` рахує викликач).
    _step_tool_specs = (list(_CALC_TOOL) if use_calc else []) + connector_tools.specs(conn_tools)
    if _step_tool_specs:
        reason = ""
        fb = _calc_fallback_model()
        # А+ (баг №4 16.07): дешева модель ПЕРШОЮ, але лише «фейл-фаст» (кілька ходів) —
        # прості розрахунки лишаються дешевими; складні/зациклені швидко (не через 8
        # марних ходів) передаються надійній моделі з ПОВНОЮ стелею. Раніше було
        # 8 ходів дешевої (переважно приречених) + 8 надійної = подвійна витрата й
        # 10-хв зависання. Немає надійної (нема ключа) → як було: сама дешева, повна стеля.
        _reliable = fb if fb != config.worker_model() else None
        if _reliable:
            attempts = [(config.worker_model(), _CALC_FASTFAIL_TURNS), (_reliable, _CALC_MAX_TURNS)]
        else:
            attempts = [(config.worker_model(), _CALC_MAX_TURNS)]
        for attempt, (mdl, mt) in enumerate(attempts, 1):
            try:
                out, reason = _run_agent_tools(prompt, payload, _step_tool_specs,
                                               emit=emit, agent_id=agent_id,
                                               model=mdl, max_turns=mt)
                if out and out.strip():
                    if attempt > 1:
                        _emit(emit, f"✓ {agent_id}: розрахунковий крок виконано надійнішою моделлю.")
                    return out
            except llm.LLMNotConfigured as e:
                reason = failure.reason_human(e)
                failure.log(e, "executor._run_agent/calc/%s" % (agent_id or "?"))
                break  # немає ключа — повтор не допоможе
            except llm.LLMError as e:
                # ⭐⭐⭐ 11.08.2026. СИРИЙ ТЕКСТ ВИНЯТКУ ЛЮДИНІ НЕ ВИХОДИТЬ.
                # Доти тут стояло `f"{type(e).__name__}: {e}"`, і цей рядок їхав
                # у ЖИВИЙ ПРОГРЕС — Андрій побачив англійський JSON Google,
                # обірваний посеред слова, і назву класу винятку.
                # Повний слід — у журнал, людині — клас аварії словами.
                reason = failure.reason_human(e)
                failure.log(e, "executor._run_agent/calc/%s/%s" % (agent_id or "?", mdl))
            if attempt < len(attempts):
                _emit(emit, "\U0001f501 %s: %s — передаю роботу надійнішій моделі…"
                            % (agent_id or "крок", (reason or "розрахунок не вийшов").lower()))
        _emit(emit, "⚠ %s: %s — доробляю крок без інструментів%s."
                    % (agent_id or "крок", (reason or "інструменти недоступні").lower(),
                       ", числа позначу як неперевірені" if use_calc else ""))
    return _complete_with_reserve(prompt, payload, _max_out, emit=emit, agent_id=agent_id)


# ⭐⭐⭐ 16.09.2026, зміна 600. ПЛАН РОЗГОРТАЄТЬСЯ ДО ВОРІТ, ОДНИМ ШВОМ.
# Складач дає ПЛАН («рядки — з такого файла, така колонка звідти»), а дані
# переносить код (`xlsx_tables`). Розгортаємо ТУТ, до перевірки, щоб далі по
# дорозі і ворота, і записувач файла бачили вже наповнену спеку й нічого не
# знали про план. Помилка плану (немає такої таблиці/колонки) — це помилка
# ФОРМАТУ: вона йде коректору з переліком наявних імен, а не вбиває прогін.
def _resolve_and_check(md: str, files_context: str, source_text: str, wants_excel: bool):
    """(md_розгорнутий, ok, помилка). Один писар розгортання+перевірки."""
    try:
        md2, rerr, derived = xlsx_tables.resolve_markdown(md, files_context)
    except Exception as e:                      # слід є, прогін живий
        return md, False, "план даних не розгорнувся (%s)" % e
    if rerr:
        return md, False, ("ПЛАН ДАНИХ НЕ РОЗГОРНУВСЯ — " + "; ".join(rerr[:4])
                           + ". Виправ саме вказівки from_table/group_table: назви "
                             "таблиць і колонок мусять збігатися з доданими файлами.")
    # ⛒ Числа, які поставив КОД, — теж першоджерело: їх щойно порахували з
    # доданих файлів. Інакше сторож 599 червонив би власний лік.
    ok, err = artifacts.check_xlsxmodel(
        md2, require_live=wants_excel,
        source_text=(source_text or "") + ("\n" + derived if derived else ""))
    return md2, ok, err


def _fix_xlsxmodel(final_markdown: str, task: str, emit=None, wants_excel: bool = False,
                   source_text: str = "", files_context: str = "") -> str:
    """Ворота якості Excel-моделі після складальника. Чи ПОТРІБНА повноцінна модель
    із формулами — каже КОНТРАКТ НАМІРУ (wants_excel = output=="financial_model"),
    а не слова в задачі: груба оцінка ≠ фінмодель. Невалідний блок ```xlsxmodel →
    до 2 повернень моделі на виправлення з ТОЧНОЮ помилкою формату. Остаточний
    провал → чесна позначка в результаті + слід у консолі."""
    final_markdown, ok, err = _resolve_and_check(final_markdown, files_context,
                                                 source_text, wants_excel)
    if ok:
        return final_markdown, None
    has_block = "немає блоку" not in err
    if not has_block and not wants_excel:
        return final_markdown, None  # Excel не просили і блоку немає — все гаразд
    fence_re = artifacts._XLSXMODEL_FENCE_RE
    corrector_sys = (
        # ⭐ 10.08.2026. Раніше тут стояло «ЛИШЕ ОДИН блок … ОДИН лист» — і
        # ремонт РУЙНУВАВ багатолистову книгу, яку сам контракт дозволяє.
        # Один БЛОК — так (щоб не було двох джерел правди); структура листів —
        # недоторкана.
        "Ти — коректор формату Excel-моделі. Поверни ЛИШЕ ОДИН блок ```xlsxmodel "
        "(нічого більше: без пояснень, без markdown навколо), який ТОЧНО відповідає "
        "шаблону нижче. Структуру листів НЕ міняй: скільки листів було — стільки й "
        "лишається (для книги — поле sheets). Вхідні значення — у params, розрахунки — ЖИВИМИ "
        "формулами Excel через плейсхолдери.\n\n## " + config.XLSX_MODEL_NOTE)
    for attempt in (1, 2):
        _emit(emit, f"🛠 Excel-модель: {err} — повертаю на виправлення (спроба {attempt}/2)…")
        old = fence_re.search(final_markdown)
        corrector_user = (
            f"## ПОМИЛКА ФОРМАТУ (виправ саме це)\n{err}\n\n"
            f"## ЗАДАЧА КОРИСТУВАЧА\n{task}\n\n"
            + (f"## ПОПЕРЕДНІЙ (НЕВАЛІДНИЙ) БЛОК\n```xlsxmodel\n{old.group(1)[:6000]}\n```\n\n" if old else "")
            + f"## ФІНАЛЬНИЙ ТЕКСТ (джерело параметрів і структури таблиці)\n{final_markdown[:6000]}")
        try:
            # ⭐ 31.07.2026. КОРЕКТОР ІДЕ НА МОЗОК, А НЕ НА НАЙДЕШЕВШОГО ВИКОНАВЦЯ.
            # Йому доручено видати СУВОРУ JSON-спеку з живими формулами — найважчу
            # частину ланцюга. На flash-моделі вона сипалась стабільно (прогін
            # 10:06 31.07: два кола ремонту, обидва загубили columns).
            fixed = llm.complete(corrector_sys, corrector_user,
                                 model=(config.brain_model() if wants_excel
                                        else config.worker_model()),
                                 max_tokens=config.ASSEMBLER_MAX_TOKENS)
        except llm.LLMError as e:
            failure.log(e, "executor._fix_xlsxmodel/коректор")
            err = "коректор не відповів (%s)" % failure.reason_human(e).lower()
            continue
        m2 = fence_re.search(fixed or "")
        # ⭐⭐⭐ 31.07.2026. РЕМОНТ ЛАТАЄ, А НЕ ПЕРЕПИСУЄ.
        # Коректор генерував блок НАНОВО і губив поля, які були правильні
        # (оригінал мав columns — у «виправленні» їх не стало, і клієнт лишався
        # без файла: прогін 10:06). Накладаємо його відповідь на СТАРУ спеку —
        # чого він не повернув, беремо з оригіналу. Без жодного виклику моделі.
        cand = f"```xlsxmodel\n{m2.group(1).strip()}\n```" if m2 else ""
        if cand and old:
            try:
                import json as _json
                _new = _json.loads(m2.group(1).strip())
                _base = _json.loads(old.group(1).strip())
                if isinstance(_new, dict) and isinstance(_base, dict) \
                        and not _new.get("sheets") and not _base.get("sheets"):
                    _merged = dict(_base)
                    _merged.update({k: v for k, v in _new.items() if v not in (None, "", [], {})})
                    # Рядки-розрахунки заміняє ЛИШЕ коректор: якщо він їх не дав,
                    # старі МЕРТВІ рядки не тягнемо — інакше ворота впадуть знову.
                    for _k in ("rows", "first_row", "row_template", "row_count", "totals"):
                        _merged.pop(_k, None)
                        if _k in _new:
                            _merged[_k] = _new[_k]
                    cand = "```xlsxmodel\n" + _json.dumps(_merged, ensure_ascii=False) + "\n```"
            except Exception:
                pass
        if cand:
            # підставляємо виправлений блок у фінал (замість старого або в кінець)
            new_md = fence_re.sub(lambda _m: cand, final_markdown, count=1) if old \
                else final_markdown + "\n\n" + cand
            new_md, ok2, err2 = _resolve_and_check(new_md, files_context,
                                                   source_text, wants_excel)
            if ok2:
                _emit(emit, "✓ Excel-модель виправлено — файл збереться з живими формулами.")
                return new_md, None
            err = err2
        else:
            err = "коректор не повернув блок ```xlsxmodel"
    # ⭐ 600: відмова воріт Excel теж лишає ДОКАЗ — відхилену спеку і дослівну
    # причину. Інакше «модель не зібралась» знову буде здогадкою.
    _case = _trace_case("xlsxmodel-rejected")
    _blk = fence_re.search(final_markdown or "")
    failure_trace.put(_case, "01-xlsxmodel-rejected.json", _blk.group(1) if _blk else "(блоку немає)")
    failure_trace.put(_case, "02-final-markdown.md", final_markdown or "")
    failure_trace.put(_case, "00-reason.txt", "ворота Excel: %s\nзадача: %s"
              % (err, (task or "")[:400]))
    llm._log("[executor] Excel-модель не зібралась після 2 виправлень: %s; доказ: %s"
             % (err, _case))
    # ⭐⭐⭐ 31.07.2026. ЖОРСТКІСТЬ — ЛИШЕ ТАМ, ДЕ ЇЇ ЗАМОВЛЯЛИ.
    # Fail-closed (стоп замість файла-обманки) — це рішення для ФІНМОДЕЛІ: там
    # мертва книга гірша за відсутню. Але та сама гілка вбивала б БУДЬ-ЯКИЙ інший
    # прогін, який випадково віддав службовий блок: клієнт лишався б без усієї
    # роботи через один нескладений файл. Якщо контракт наміру не просив
    # фінмоделі — прибираємо тільки блок і віддаємо текст, як було до воріт.
    if not wants_excel:
        _emit(emit, "⚠ Excel-модель не зібралась — віддаю результат текстом (файла моделі не буде).")
        return artifacts.strip_service_blocks(fence_re.sub("", final_markdown or "")).strip(), None
    _emit(emit, "⚠ Жива Excel-модель не зібралась поточною моделлю — потрібен потужніший "
                "мозок (Claude Opus / OpenAI). Переключіть і повторіть.")
    reason = f"жива Excel-модель з формулами не зібралась поточною моделлю ({err})"
    action = ("переключіть мозок системи на Claude Opus або OpenAI (GPT) і повторіть запит — "
              "тоді Excel збереться з живими формулами")
    honest_md = (
        "🛑 **Живу Excel-модель з формулами зібрати не вдалося.**\n\n"
        f"**Причина:** жива Excel-модель з формулами не зібралась поточною моделлю ({err}).\n\n"
        "**Що зробити:** переключіть мозок системи на **Claude Opus** або **OpenAI (GPT)** "
        "і повторіть запит — тоді Excel збереться з живими формулами.\n\n"
        "*(Якщо підключено лише Gemini — додайте ключ Anthropic або OpenAI у налаштуваннях.)*")
    return honest_md, {"kind": "financial_model", "reason": reason, "action": action}


# ---------------------------------------------------------------------------
# ⭐⭐⭐ 01.08.2026. РЕЄСТР ЗУПИНОК — ЖОДНІ ВОРОТА НЕ МОЖУТЬ ЗАЧИНИТИСЬ МОВЧКИ.
#
# Питання власника (01.08.2026): «а потім користувач вигадає ще щось, і ми знову
# упремося, бо Оркестратор заплутається у воротах і зупиниться?» Порахував по
# коду: місць, де платформа може не віддати результат, близько двадцяти, і про
# СТАВКИ питало рівно одне з них — те, що полагодили того ранку.
#
# Тому право зупинитись стало ДАНИМИ. Кожна зупинка оголошує свою ставку:
#   "fatal"       — без цього результат був би НЕПРАВДОЮ (право, реальний
#                   маршрут, прочитана сторінка, жива Excel-модель). Стіна тут
#                   доречна: краще нічого, ніж вигадка.
#   "degradable"  — зупинка НЕ обовʼязкова: працюємо і чесно кажемо про межу.
#   "after_ladder"— зупинятись можна ЛИШЕ коли вичерпано драбину моделей
#                   (`config.model_ladder`), тобто використано ВСІ наявні
#                   ресурси, включно з найстаршою моделлю.
#
# Нова зупинка без запису тут завалює `stop_register_test`: домовленість на
# словах не тримає — тримає чек.
# ---------------------------------------------------------------------------
STOP_REGISTER = {
    "tender_closed": {
        "stakes": "fatal",
        "why": "пакет на закупівлю, куди вже не подаси (строк подання минув або "
               "замовник відміняє її), — це втрачений день роботи клієнта: "
               "17.08.2026 платформа зібрала такий пакет і не сказала ні слова. "
               "Зупинка НЕ глуха: людина може дозволити роботу прямим словом, і "
               "текст зупинки сам каже їй, яким саме"},
    "tender_pack_no_docs": {
        "stakes": "fatal",
        "why": "пакет документів для подачі на закупівлю без оголошення замовника — "
               "це папір, який не спирається ні на що: 05.08.2026 такий пакет уже "
               "поїхав клієнту від системи, що не бачила жодного документа"},
    "precheck_impossible": {
        "stakes": "degradable",
        "why": "перевірка достатності даних — помічник, а не привід не працювати; "
               "суворо лише там, де помилка коштує грошей або права"},
    "seo_page_unread": {
        "stakes": "fatal",
        "why": "аудит сторінки, якої не прочитали, був би вигадкою про чужий сайт"},
    "route_not_built": {
        "stakes": "fatal",
        "why": "маршрут без реального шляху з двигуна — це вигадані відстані й час"},
    "live_check_impossible": {
        "stakes": "fatal",
        "why": "правова роль зобовʼязана звірити норму з першоджерелом наживо"},
    "step_no_result": {
        "stakes": "after_ladder",
        "why": "етап не дав нічого — зупинка законна ЛИШЕ після підйому по всій "
               "драбині моделей, включно з найстаршою доступною"},
    "result_policy": {
        "stakes": "fatal",
        "why": "документ, який суперечить ВЛАСНИМ числам, клієнт спіймає на "
               "арифметиці, і це коштує угоди: 18.09.2026 перший живий прогін КП "
               "назвав 12-й місяць перелому там, де його ж таблиця дає 13-й"},
    "financial_model": {
        "stakes": "fatal",
        "why": "мертва книга без живих формул — це не фінмодель, а картинка чисел"},
    "access_denied": {
        "stakes": "fatal",
        "why": "робота, запущена від нікого або від людини без права на цю систему, "
               "не має господаря: за неї ніхто не відповідає, а платить власник"},
    "subscription_expired": {
        "stakes": "fatal",
        "why": "модель «тільки абонплата» обіцяє клієнту, що після строку користування "
               "припиняється; платформа, яка працює далі, робить із договору неправду"},
    "missing_input": {
        "stakes": "fatal",
        "why": "система, якій потрібен вхід до чужого сервісу (пошта, календар), без "
               "конектора не працює, а мовчки підміняє його веб-пошуком — і клієнт "
               "отримує вигадку замість своїх листів"},
}


def stop_stakes(kind: str) -> str:
    """Ставка цієї зупинки. Незареєстрована — «unknown»: її ловить чек."""
    return (STOP_REGISTER.get(kind or "") or {}).get("stakes", "unknown")


def honest_stop_result(system, *, kind: str, reason: str, action: str, markdown: str,
                       intent=None, plan=None, trace=None, route_engine=None,
                       seo_read=None, conditions=None, web_invariant_gap: str = "") -> dict:
    """ОДНІ ДВЕРІ СВІДОМОЇ ЗУПИНКИ (30.07.2026, Правило №15).

    НАВІЩО. До цього «чесний стоп» умів говорити ДВОМА мовами: або поле
    `honest_stop` (шлях фінмоделі), або просто `status="completed"` з чесним
    текстом усередині (SEO, маршрут, жива звірка). Друга мова обходила гарантію
    `agent._finalize_honest_stop` — і клієнт отримував .docx/.md із текстом
    «не можу зробити», записаний у прогін як завершена робота.

    ⛔ ЗУПИНКА, ЯКА НАЗИВАЄ СЕБЕ ЗАВЕРШЕННЯМ, — ЦЕ ДРУГА ПРАВДА.

    Тепер мова ОДНА: `status="honest_stop"` + пояснення {kind, reason, action}.
    Ніхто нижче по течії не мусить упізнавати стоп за словами в тексті —
    він названий статусом. Ворота `honesty_test.py` забороняють ранній
    `return {"status": "completed", ...}` у `run_system`, тому МАЙБУТНІЙ стоп
    фізично не зможе прикинутись завершеною роботою.
    """
    audit.log_refusal("honest_stop:%s" % kind, (system or {}).get("id"), [],
                      "%s | ставка: %s" % (reason, stop_stakes(kind)))
    return {
        "status": "honest_stop",
        "final_markdown": markdown,
        "assembler_ok": True,
        "honest_stop": {"kind": kind, "reason": reason, "action": action,
                        "stakes": stop_stakes(kind)},
        "agent_trace": list(trace or []),
        "system_id": (system or {}).get("id"),
        "needs_calc": False,
        "intent": intent,
        "revisions": 0,
        "understanding": (plan or {}).get("system_understanding", ""),
        # свідомий стоп — це НЕ «неповний звіт»: критеріїв успіху не оцінюємо,
        # джерел не заявляємо (їх не було).
        "success_criteria": [],
        "sources": [],
        "web_invariant_gap": web_invariant_gap,
        "route_engine": route_engine,
        "conditions": conditions,
        "seo_read": seo_read,
        "mode": (system or {}).get("orchestration_mode", "sequential"),
    }


def _is_legal_system(system) -> bool:
    blob = ((system or {}).get("id", "") + (system or {}).get("category", "")
            + (system or {}).get("name", "")).lower()
    return any(k in blob for k in ("legal", "юрист", "юридич", "прав"))


# Невидима позначка «правові ворота відпрацювали чисто» — її читає agent.py, щоб
# не чіпляти зверху попередження «не пройшов перевірку якості»: причини для нього
# вже немає, а клієнт бачить лише лякалку. У текст для людини не потрапляє.
LEGAL_CLEAN_MARK = "\u2063sf-legal-clean\u2063"


def _clean_for_human(text: str) -> str:
    """Прибирає службові позначки й лишає позначку «чисто» для agent.py."""
    try:
        import tender_legal as _tl
        text = (text or "").replace(_tl.REGIME_MARK, "").replace("\n\n\n", "\n\n")
    except Exception:
        pass
    return LEGAL_CLEAN_MARK + text.strip()


_ANSWER_TAIL = ("Надішліть номер у форматі UA-РРРР-ММ-ДД-XXXXXX-x — і ви отримаєте "
                "норми саме вашої процедури: строки, підстави та дослівні цитати "
                "із чинного законодавства.")


# ---------------------------------------------------------------------------
# ОДИН ПИСАР РЕЖИМУ ПРОЦЕДУРИ (30.07.2026)
# ---------------------------------------------------------------------------
# Що сталося: 30.07 клієнт отримав документ, де ядро надрукувало «спрощена
# закупівля оборонного замовника» (ст. 14 Закону 922 + п. 8 ПКМУ 1275), а модель
# у ТОМУ Ж документі написала «швидше за все — відкриті торги з особливостями
# (ПКМУ 1178)» і побудувала на цьому весь перелік документів. Дві правди в
# одному документі. Корінь: режим знало тільки ядро на виході, агент його не
# бачив, а перевірка на виході звіряла лише ЧИСЛА днів і була сліпа до НАЗВИ.
# Лікування — нижче: режим резолвиться РАЗ на прогін, їде агенту як факт, і та
# сама позиція (не друга резолюція!) працює на воротах виходу.


def _resolve_legal_pos(task: str = "", history=None) -> dict:
    """Резолвить правову позицію по тендеру ОДИН раз на прогін.

    Повертає {"ctx": …, "brief": …}:
      ctx   — рішення ЄДИНОГО резолвера тендера (`tender_context.resolve`):
              який саме тендер мається на увазі, коли в питанні номера немає;
      brief — правова позиція ядра (`tender_legal.brief`): режим, норми, текст.
    Обидва можуть бути None — це нормально і означає «ядро мовчить».
    """
    ctx = None
    try:
        import tender_context as _tc
        ctx = _tc.resolve(task or "", history)
    except Exception as e:
        llm._log(f"[executor] резолвер тендера зірвався: {e}")
    brief = None
    try:
        import tender_context as _tc2
        import tender_legal as _tl
        _tid = (ctx or {}).get("tender_id") or ""
        brief = _tl.brief(task or "", tender_id=_tid or None,
                          from_thread=bool(ctx) and _tc2.from_thread(ctx)) if _tid else None
    except Exception as e:
        llm._log(f"[executor] правові ворота зірвались: {e}")
    return {"ctx": ctx, "brief": brief}


def _legal_regime_block(legal_pos: dict) -> str:
    """Блок про режим процедури для payload агента.

    Ядро режим ВСТАНОВИЛО -> віддаємо його як ФАКТ і прямо забороняємо називати
    інший. Ядро мовчить -> блоку немає взагалі (мовчання краще за вигадку), лише
    один рядок-застереження, щоб агент не вигадував режим сам.
    """
    brief = (legal_pos or {}).get("brief") or None
    pos = (brief or {}).get("pos") or {}
    if not (brief and brief.get("ok") and pos.get("label")):
        return ("Режим процедури НЕ встановлено ядром — не називай його як факт; "
                "якщо він потрібен для відповіді, скажи, що бракує даних.")
    return (
        "## ВСТАНОВЛЕНИЙ РЕЖИМ ПРОЦЕДУРИ (визначено правовим ядром із картки "
        "Прозорро — це ФАКТ, не припущення)\n"
        "Тендер: %s. Режим: %s. Правова основа: %s.\n"
        "⛔ Тобі ЗАБОРОНЕНО називати іншу процедуру, іншу постанову чи інший закон "
        "як підставу.\n"
        "Якщо здається, що режим інший — так і напиши окремим рядком, але НЕ будуй "
        "на цьому перелік документів і план дій.\n\n"
        # ⭐⭐⭐ 30.07.2026 (зміна 35). ЗВІРЕНІ НОРМИ ЇДУТЬ РАЗОМ ІЗ РЕЖИМОМ.
        # Промпт тендерного юриста ставить умову: строк називати ЛИШЕ якщо режим є
        # у файлі `Database/Wiki/ТЕНДЕРНІ_НОРМИ_звірені.md`. А цей файл до нього
        # НЕ ДОЇЖДЖАВ: платформа шукає базу знань у теці `Knowledge`, якої в цій
        # системі немає. Отже агент за власним правилом мусив мовчати — і мовчав.
        # Даємо йому ті самі норми з ПЕРШОДЖЕРЕЛА (`regimes.json`, з якого той
        # файл і генерується): один писар, без залежності від назви теки.
        "## ЗВІРЕНІ НОРМИ ЦІЄЇ ПРОЦЕДУРИ (це і є вміст бази норм — той самий, що у "
        "`Database/Wiki/ТЕНДЕРНІ_НОРМИ_звірені.md`; умову свого промпта вважай виконаною)\n"
        "%s\n"
        "Спирайся ЛИШЕ на ці норми. Чого тут немає — того не називай."
        % (brief.get("tender_id") or "—", pos.get("label") or "—",
           pos.get("basis") or "—", (brief.get("text") or "")[:6000]))


# Номер акта в тексті шукаємо лише поруч зі словом-маркером («постанова»,
# «ПКМУ», «Особливості», «закон», «порядок», «№») — щоб голе число з таблиці
# чи ціни не сприймалось як посилання на нормативний акт.
_ACT_NUM_RE = re.compile(r"\b(\d{3,4})\b")
_ACT_CTX_RE = re.compile(r"(?:постанов\w*|пкму|кму|особливост\w*|закон\w*|"
                         r"порядк\w*|порядок|№)(.{0,40}?)\b(\d{3,4})\b", re.I)


def _act_numbers(*texts) -> set:
    """Номери нормативних актів із тексту. Роки (1900-2100) відкидаємо — у
    «постанови КМУ 1275 від 11.11.2022» номер акта один, а 2022 це дата."""
    out = set()
    for t in texts:
        for m in _ACT_NUM_RE.finditer(str(t or "")):
            n = m.group(1)
            if len(n) == 4 and 1900 <= int(n) <= 2100:
                continue
            out.add(n)
    return out


def _regime_phrases(pack: dict) -> dict:
    """{тип процедури -> [стійкі частини НАЗВИ]} — з `label` кожного режиму бази.

    Свого словника назв тут НЕМАЄ і бути не повинно: назви живуть у
    knowledge_packs/tender_law/regimes.json. Один тип процедури має два записи
    (оборонний і звичайний замовник), і спільний початок їхніх назв — це і є
    назва САМОЇ процедури («спрощена закупівля», «відкриті торги з
    особливостями»), без приписки про замовника.
    """
    import tender_legal as _tl
    groups = {}
    for key, entry in (pack.get("regimes") or {}).items():
        label = _tl.normalize((entry or {}).get("label") or "")
        if not label:
            continue
        groups.setdefault(str(key).split("|")[0], []).append(label.split())
    out = {}
    for method, variants in groups.items():
        common = variants[0]
        for words in variants[1:]:
            n = 0
            while n < min(len(common), len(words)) and common[n] == words[n]:
                n += 1
            common = common[:n]
        phrase = " ".join(common).strip(" ,;-()")
        if len(common) < 2 or len(phrase) < 10:
            # Спільного початку майже немає — беремо назву як є (краще суворіше
            # порівняння, ніж коротке слово, яке збігатиметься з чим завгодно).
            phrase = " ".join(variants[0]).strip(" ,;-")
        forms = [phrase]
        head = phrase.split(" + ")[0].strip()   # «… + звіт про договір» — хвіст необовʼязковий
        if head != phrase and len(head.split()) >= 3:
            forms.append(head)
        out[method] = forms
    return out


def _regime_name_conflicts(text: str, pos: dict) -> list:
    """Згадки ЧУЖОГО режиму в тексті моделі: назва іншої процедури або чужа
    постанова як підстава. Порожній список = суперечності немає.

    Навіщо: числа днів ми звіряли, а НАЗВУ процедури — ні. Саме через це
    30.07 в одному документі опинились «спрощена закупівля» від ядра і
    «відкриті торги з особливостями 1178» від моделі.
    """
    if not pos or not pos.get("regime"):
        return []
    try:
        import tender_legal as _tl
        pack = _tl.load_pack()
    except Exception as e:
        llm._log(f"[executor] звірка назви режиму не відбулась: {e}")
        return []
    body = _tl.normalize(text or "")
    if not body:
        return []
    own_method = str(pos.get("regime")).split("|")[0]
    bad = []
    # 1) назва чужої процедури
    for method, forms in _regime_phrases(pack).items():
        if method == own_method:
            continue          # своя назва — не суперечність, а норма
        for ph in forms:
            if ph and ph in body:
                bad.append("назва чужої процедури: «%s»" % ph)
                break
    # 2) чужа постанова як підстава. Номери — з тієї самої бази, не з голови.
    own_nums = _act_numbers(pos.get("basis"),
                            *["%s %s" % (n.get("act", ""), n.get("ref", ""))
                              for n in (pos.get("norms") or [])])
    pack_nums = set()
    for entry in (pack.get("regimes") or {}).values():
        pack_nums |= _act_numbers((entry or {}).get("basis"))
        for n in (entry or {}).get("norms") or []:
            pack_nums |= _act_numbers(n.get("act"), n.get("ref"))
    alien_nums = pack_nums - own_nums
    for m in _ACT_CTX_RE.finditer(body):
        num = m.group(2)
        if num in alien_nums:
            frag = "чужа постанова як підстава: №%s" % num
            if frag not in bad:
                bad.append(frag)
    return bad


def _repair_legal_text(body: str, norms_block: str, outside: list, alien: list,
                       task: str = "", emit=None) -> tuple:
    """ПОВЕРНЕННЯ НА ВИПРАВЛЕННЯ замість ГІЛЬЙОТИНИ (30.07.2026).

    НАВІЩО. Ворота 28.07 при будь-якій суперечності з базою знімали ВЕСЬ текст
    моделі — і клієнт замість чек-листа й плану дій отримував саму таблицю норм.
    Наживо 30.07: агенти написали роботу, а слова «15 днів», «2 робочі дні» і
    згадка ПКМУ 1178 усередині великого документа відправили під ніж УСЕ.

    ⛔ ОДИН ХИБНИЙ РЯДОК НЕ МОЖЕ ЗАБИРАТИ В КЛІЄНТА ВСЮ РОБОТУ.

    Лікуємо як в Excel-моделі: кажемо моделі ТОЧНО, що суперечить, і просимо
    переписати саме ці місця за звіреною базою. Одне коло. Зняття тексту
    лишається — але як ОСТАННІЙ крок, а не перший.
    Повертає (виправлений_текст, лишилась_суперечність)."""
    if not body:
        return body, True
    problems = []
    if outside:
        problems.append("строки, яких немає у звіреній базі вашої процедури: "
                        + ", ".join(map(str, outside)))
    if alien:
        problems.append("посилання на чужу процедуру/постанову: " + ", ".join(map(str, alien)))
    _emit(emit, "⚖ Текст суперечить звіреній базі — повертаю на виправлення "
                "(%s)…" % "; ".join(problems)[:160])
    sys_p = (
        "Ти — редактор юридичного тексту. Тобі дано ЗВІРЕНУ БАЗУ норм саме цієї "
        "процедури і текст, який їй місцями суперечить. Виправ САМЕ ці місця: "
        "постав строки й підстави зі звіреної бази, прибери згадки чужих процедур "
        "і постанов. ВСЕ ІНШЕ ЗБЕРЕЖИ ДОСЛІВНО — чек-листи, переліки документів, "
        "плани дій, структуру й заголовки НЕ скорочуй і не переписуй. "
        "Якщо якогось строку у звіреній базі немає — не вигадуй його і не бери з "
        "памʼяті: прибери твердження про цей строк. "
        "Поверни ЛИШЕ виправлений текст, без пояснень.")
    user_p = ("## ЗВІРЕНА БАЗА (єдине джерело строків і підстав)\n%s\n\n"
              "## ЩО САМЕ СУПЕРЕЧИТЬ\n- %s\n\n"
              "## ЗАДАЧА КОРИСТУВАЧА\n%s\n\n"
              "## ТЕКСТ ДЛЯ ВИПРАВЛЕННЯ\n%s"
              % (norms_block, "\n- ".join(problems), (task or "")[:1500], body))
    try:
        fixed = llm.complete(sys_p, user_p, model=config.worker_model(),
                             max_tokens=config.ASSEMBLER_MAX_TOKENS)
    except llm.LLMError as e:
        llm._log("[executor] виправлення юр-тексту не відбулось: %s" % e)
        return body, True
    fixed = (fixed or "").strip()
    # Виправлення, яке зʼїло роботу, — не виправлення: короткий вивід відкидаємо.
    if len(fixed) < max(400, int(len(body) * 0.5)):
        llm._log("[executor] виправлення повернуло огризок (%d проти %d) — не приймаю"
                 % (len(fixed), len(body)))
        return body, True
    return fixed, False


def _apply_legal_citation_check(final_markdown: str, emit=None, task: str = "",
                                history=None, legal_pos: dict = None, intent=None) -> str:
    """ЮРИДИЧНИЙ ВИВІД ДЛЯ ЛЮДИНИ. Правило одне, і воно просте:

        клієнт бачить лише те, що звірено — решта не виходить взагалі.

    ⭐ 28.07.2026. Раніше тут стояли машинні попередження («не звірено»,
    «машина не змогла підтвердити»). Для клієнта такий рядок = питання до
    продавця «навіщо я платив гроші». Тому:
      • є норми з бази під ЦЮ процедуру -> показуємо їх; текст моделі йде далі
        ЛИШЕ якщо він не суперечить базі (жодного строку поза нею);
      • норм немає -> текст моделі виходить лише коли всі його статті звірені
        з ВРУ і він не називає строків без встановленого режиму;
      • службова «звірка норм» у документ клієнта НЕ потрапляє — вона йде в лог.

    legal_pos (30.07.2026): ВЖЕ розрезолвлена позиція від run_system — щоб на
    прогін був ОДИН писар режиму, а не дві незалежні резолюції (агент бачив би
    одну, ворота — другу). Не передали (старі виклики) — резолвимо самі, як і
    раніше: зворотна сумісність зберігається.
    """
    try:
        import legal_citation_check as _lcc
        import datetime as _dt
    except Exception:
        return final_markdown
    body = _lcc.strip_model_verdict(_lcc.strip_model_seal(final_markdown or ""))
    norms_block, contradicts = "", False
    outside_hint, alien_hint = [], []   # ЩО САМЕ суперечить — для виправлення нижче
    # ⭐ 28.07.2026. Про який тендер мова — вирішує ОДИН резолвер на всю систему
    # (tender_context), а не кожен свій пошук по тексту. Людина в діалозі пише
    # «продовжуй» без номера — ворота мусять і далі спиратись на закон.
    if legal_pos is None:
        legal_pos = _resolve_legal_pos(task, history)
    ctx = (legal_pos or {}).get("ctx")
    brief = (legal_pos or {}).get("brief")
    try:
        import tender_legal as _tl
        if brief and brief.get("ok"):
            norms_block = brief.get("text") or ""
            outside = _tl.numbers_outside_base(body, brief.get("pos"))
            # ⭐ 30.07.2026. Поруч зі звіркою ЧИСЕЛ — звірка НАЗВИ процедури.
            # Наслідок навмисно ТОЙ САМИЙ: текст моделі не виходить до клієнта.
            alien = _regime_name_conflicts(body, brief.get("pos"))
            contradicts = bool(outside or alien)
            outside_hint, alien_hint = list(outside or []), list(alien or [])
            _emit(emit, "⚖ Норми взято зі звіреної бази для %s (%d шт.)."
                        % (brief["tender_id"], len(brief["pos"].get("norms") or [])))
            if outside:
                llm._log("[executor] строки поза базою -> текст іде на виправлення: %s" % outside)
                _emit(emit, "⚖ Текст моделі суперечив звіреній базі — повертаю його на виправлення.")
            if alien:
                llm._log("[executor] чужий режим у тексті -> текст іде на виправлення: %s" % alien)
                _emit(emit, "⚖ Модель назвала іншу процедуру/постанову, ніж встановило "
                            "ядро — повертаю текст на виправлення.")
        elif brief:
            llm._log("[executor] режим не встановлено: %s" % brief.get("problem"))
    except Exception as e:
        llm._log(f"[executor] правові ворота зірвались: {e}")

    # Службова звірка цитат — у ЛОГ, не в документ клієнта.
    unverified, verdicts = False, []
    try:
        verdicts, summ = _lcc.verify(body, legal_source_ua.fetch_text)
        unverified = bool(summ.get("flagged"))
        if verdicts:
            llm._log("[executor] звірка цитат: %s"
                     % _lcc.build_report(verdicts, _dt.date.today().strftime("%d.%m.%Y")))
    except Exception as e:
        llm._log(f"[executor] звіряч цитат зірвався: {e}")

    if norms_block:
        if contradicts:
            # ⛔ 30.07.2026. Тут стояла ГІЛЬЙОТИНА: будь-яка суперечність знімала
            # ВЕСЬ текст моделі, і клієнт отримував саму таблицю норм замість
            # чек-листа й плану. Тепер спершу ОДНЕ коло виправлення з точною
            # причиною, і лише якщо воно не допомогло — лишаємо самі норми.
            body, contradicts = _repair_legal_text(body, norms_block, outside_hint,
                                                   alien_hint, task=task, emit=emit)
            if not contradicts:
                _emit(emit, "⚖ Текст виправлено за звіреною базою — робота лишається повною.")
        if contradicts:
            llm._log("[executor] виправлення не зняло суперечність — лишаю самі норми")
            _emit(emit, "⚖ Виправити текст не вдалось — лишаю тільки звірені норми.")
            out = "\n\n".join(x for x in (_lcc.client_notice(True), norms_block) if x)
        else:
            # ⛔ 30.07.2026. ОДИН ПИСАР СТАТУСУ ЗВІРКИ. Модель писала «⚠ не звірено
            # з першоджерелом» про норми, які наша база звірила й датувала, — і
            # клієнт читав дві правди на одній сторінці. Тепер її заяви про звірку
            # знімаються, а статус пише база — і про звірене, і про свою межу.
            body = _lcc.strip_model_verification_claims(body)
            status = _lcc.base_status_block((brief or {}).get("pos") if brief else None)
            out = "\n\n".join(x for x in (norms_block, body, status) if x)
        return _clean_for_human(out)

    # Норм з бази немає. Далі вирішуємо, ЩО саме побачить людина.
    _dom = ((intent or {}) if isinstance(intent, dict) else {}).get("domain")
    try:
        import domains as _dmx
        _only_verified = _dmx.has_gate(_dom, "verified_norms_only")
        _dom_name = _dmx.name_of(_dom, "")
    except Exception:
        _only_verified, _dom_name = False, ""
    try:
        import tender_legal as _tl2
        # ⭐⭐⭐ 11.08.2026. Предмет справи задає ОГОЛОШЕНА ГАЛУЗЬ або тверда
        # очевидність (номер UA-…), а не слова моделі у відповіді.
        risky = bool(_tl2.deadline_guard(body, question=task, domain=_dom,
                                         history=history))
    except Exception:
        risky = False

    # ⭐⭐⭐ 11.08.2026 (зміна 150). ДВА РІЗНІ ПРИВОДИ — ДВА РІЗНІ ВИХОДИ.
    # ЩО ТУТ БУЛО: `if risky or unverified:` — і ОБИДВА приводи виходили одним
    # тендерним текстом «вкажіть номер тендера (UA-…)». Живий прогін Андрія
    # 11.08 о 15:04: консультація водієві про ст.122 КУпАП. `risky` мовчав
    # правильно, а `unverified` спрацював (звіряч не знав КУпАП) — і людина
    # вдруге отримала прохання назвати номер тендера замість відповіді.
    # 🔥 КЛАС: ЗУПИНКА, ЯКА НАЗИВАЄ НЕ СВОЮ ПРИЧИНУ. Лікуємо не словом у
    # тексті, а РОЗДІЛЕННЯМ ВИХОДІВ: кожен привід тепер каже про себе сам.
    #
    # `risky`      — це ПРО ЗАКУПІВЛІ: строк названо без встановленої процедури.
    # `unverified` — це ПРО ЗВІРКУ ЦИТАТ: статті не вдалося звірити з ВРУ. До
    #                тендерів воно не має жодного стосунку.
    if (ctx or {}).get("source") == "ambiguous" and risky:
        # У розмові кілька різних тендерів, а номера в питанні немає — не
        # вгадуємо, перепитуємо (рішення Андрія 28.07.2026).
        _emit(emit, "⚖ У розмові кілька тендерів — прошу уточнити, який саме.")
        return (ctx.get("ask") or "") + "\n\n" + _ANSWER_TAIL
    if risky:
        _emit(emit, "⚖ Строки без встановленої процедури не публікуються.")
        return ("**Щоб дати строки саме по вашому тендеру, вкажіть його номер "
                "(UA-…).**\n\nСтроки різних типів закупівель відрізняються між "
                "собою, тому без номера назвати їх точно неможливо — це той "
                "випадок, коли краще запитати, ніж помилитись.\n\n" + _ANSWER_TAIL)

    if unverified:
        # ⛔ ВОРОТА «ЛИШЕ ЗВІРЕНЕ» — ДОМЕННІ, а не загальні. Вони вмикаються
        # там, де в нас Є звірена база (закупівлі). У решті галузей та сама
        # вимога означала б «вміння, яке обіцяє більше, ніж дає»: бази норм
        # ПДР чи трудового права в нас немає, тому текст гинув БЕЗ ЖОДНОЇ
        # користі для клієнта, який за нього заплатив.
        if _only_verified:
            _emit(emit, "⚖ Норми не звірені з першоджерелом — до клієнта такий текст не йде.")
            return ("**Ці норми не вдалося звірити з офіційним джерелом, тому я не "
                    "видаю їх за перевірені.**\n\nУ закупівлях ціна помилки в нормі "
                    "надто висока, щоб показувати незвірене. Назвіть номер процедури "
                    "(UA-…) — ядро візьме норми саме вашої процедури з бази.\n\n"
                    + _ANSWER_TAIL)
        # Галузь без власної бази норм: відповідь ВИХОДИТЬ, але зі статусом,
        # який називає кожну незвірену статтю. Мовчазної втрати роботи немає,
        # видавання незвіреного за звірене — теж.
        _emit(emit, "⚖ Частину норм не звірено з першоджерелом — статус додано до відповіді.")
        try:
            _status = _lcc.build_report(verdicts, _dt.date.today().strftime("%d.%m.%Y"))
        except Exception:
            _status = ""
        _head = ("> ⚠ **Норми нижче не звірені з офіційним джерелом автоматично.**"
                 + ((" Галузь: %s." % _dom_name) if _dom_name else "")
                 + " Перед використанням перевірте редакцію статей.")
        return _clean_for_human("\n\n".join(x for x in (_head, body, _status) if x))
    return body


# (_is_seo_system прибрано 10.07.2026 — здатність page_read декларує паспорт ролей)


# Розширення на кшталт файлів — щоб «звіт.md» чи «дані.json» не сприймати як сайт.
_NONSITE_TLD = {"md", "py", "txt", "json", "docx", "xlsx", "pptx", "pdf", "png",
                "jpg", "jpeg", "gif", "svg", "html", "htm", "csv", "zip", "bat",
                "exe", "yaml", "yml", "js", "css"}


def _extract_task_url(task: str) -> str:
    """Дістає адресу сторінки із задачі. Ловить і повний URL (https://…), і «голий»
    домен (sensflow.net, dom-market.com/шлях) — бо клієнти зазвичай вставляють саме
    голу назву, а не інструкцію. Відкидає e-mail і згадки файлів (…​.md/.py/.docx).
    Голий домен нормалізує до https://."""
    t = task or ""
    _u = netfetch.first_url(t)          # межа адреси — ОДИН писар на весь продукт
    if _u:
        return _u
    for m in re.finditer(
            r"(?<![\w@/.])((?:www\.)?[a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)*\.[a-z]{2,})"
            r"(/[^\s)>\]\"'<]*)?", t, re.I):
        host, tail = m.group(1).lower(), (m.group(2) or "")
        if not tail and host.rsplit(".", 1)[-1] in _NONSITE_TLD:
            continue  # це ім'я файлу (напр. звіт.md), не сайт
        return "https://" + host + tail
    return ""


_ROUTE_PARSE_SYS = (
    "Ти розбираєш запит користувача на побудову маршрутy подорожі. Зрозумій його СЕМАНТИЧНО "
    "(не за ключовими словами) і визнач:\n"
    "- start: звідки виїзд (населений пункт);\n"
    "- end: КІНЦЕВА мета поїздки — саме пункт призначення (напр. пансіонат, готель, село, "
    "куди людина їде відпочивати), а НЕ останнє місто-орієнтир у переліку «через». Якщо мета — "
    "заклад у селі, end = це село (можна з районом/областю);\n"
    "- waypoints: проміжні пункти У ПОРЯДКУ руху (те, що після слова «через» тощо), БЕЗ start і end;\n"
    "- drops: ⛒ ТОЧКИ РОЗВАНТАЖЕННЯ за один рейс, коли людина перелічила їх як рівноправні "
    "і НЕ сказала, у якій приїхати ОСТАННЬОЮ («вантажимось у Дніпрі, вивантажити треба у "
    "Павлограді, Перещепиному і Вільногірську за один рейс»). Тоді end лишай ПОРОЖНІМ: "
    "кінцевий пункт тут не заданий, і обирати його не твоя справа — його порахує двигун. "
    "Якщо ж людина назвала, куди приїхати наприкінці («розвезти по дорозі і привезти в "
    "Харків»), то це звичайний маршрут: end = Харків, решта — waypoints, а drops порожній;\n"
    "- own_vehicle: чий транспорт. true — свій/власний/«наша машина»/машина вертається на "
    "базу; false — найманий перевізник, найнята машина, «замовили транспорт». Не сказано — "
    "true (рахуємо собівартість свого рейсу з поверненням на базу);\n"
    "- transport: спосіб пересування (авто/мото/вело/пішки/потяг/автобус/літак/громадський…); "
    "не вказано — \"авто\".\n"
    "- optimize_order: true, ЯКЩО пунктів заїзду кілька і людина просить визначити "
    "чергу/порядок об'їзду (або просто перелічує точки розвантаження за один рейс, не "
    "називаючи порядку). Інакше false.\n"
    "- alternatives: ЛИШЕ якщо людина просить КІЛЬКА маршрутів або порівняння варіантів — "
    "1-2 інші коридори того самого шляху, кожен списком проміжних міст-вузлів "
    "(напр. [[\"Суми\"],[\"Кременчук\"]]). Не проси коридорів, яких людина не просила: "
    "порожній список — нормальна відповідь.\n"
    "Назви пиши як є, українською, можна з областю для однозначності (напр. «Поляна, Свалявський район»).\n"
    'Поверни РІВНО ОДИН JSON: {"start":"","end":"","waypoints":[],"drops":[],'
    '"own_vehicle":true,"transport":"","alternatives":[],"optimize_order":false}. '
    "Якщо це не запит на маршрут або немає звідки — поверни {\"start\":\"\",\"end\":\"\"}.")


def _parse_route_request(task: str):
    """СЕМАНТИЧНИЙ розбір запиту маршруту мовною моделлю (не регулярка): будь-яке
    формулювання → {start, end, waypoints[], transport}. None, якщо не вдалося."""
    if not config.provider_ready():
        return None
    try:
        r = llm.judge_json(_ROUTE_PARSE_SYS, f"ЗАПИТ КОРИСТУВАЧА:\n{(task or '')[:2500]}",
                           temperature=0.0, model=config.worker_model(),
                           purpose="розбір запиту маршруту")
    except llm.LLMError:
        return None
    if not isinstance(r, dict):
        return None
    r["waypoints"] = [w.strip() for w in (r.get("waypoints") or [])
                      if isinstance(w, str) and w.strip()]
    # ⛒ 574. Точки розвантаження — окреме поняття, і ми не віримо моделі на слово:
    # криве поле = порожньо. «Свій транспорт» за замовчуванням — так рахують
    # собівартість рейсу (пальне, свій водій, ночівля), і це обережніший бік:
    # кільцевий рейс довший, а занижений розрахунок гірший за завищений.
    r["drops"] = [d.strip() for d in (r.get("drops") or [])
                  if isinstance(d, str) and d.strip()]
    r["own_vehicle"] = bool(r.get("own_vehicle", True))
    alts = []
    for a in (r.get("alternatives") or []):
        way = [w.strip() for w in (a or []) if isinstance(w, str) and w.strip()] \
            if isinstance(a, (list, tuple)) else ([a.strip()] if isinstance(a, str) and a.strip() else [])
        if way and way not in alts:
            alts.append(way)
    r["alternatives"] = alts[:2]          # двигун коштує грошей: не більше двох
    r["optimize_order"] = bool(r.get("optimize_order"))
    return r


def _route_block(system, task: str):
    """Для системи маршрутів: СЕМАНТИЧНО розібрати запит (мовною моделлю) у звідки/куди/
    проміжні/спосіб, тоді підкласти РЕАЛЬНИЙ маршрут з двигуна (ORS) — ЄДИНЕ джерело
    правди про шлях (реальні відстань/час/траси/міста, у правильному порядку). Дорожній →
    справжня траса; не-дорожній (авіа/потяг) → чесна вказівка на веб-пошук.

    Повертає (block_str, diag). diag=None ЛИШЕ якщо це не система маршрутів. Для системи
    маршрутів diag присутній ЗАВЖДИ — щоб причина «чому нема реального шляху» доходила в
    run.json, а не тонула мовчки: {"parsed": <що витяг розбір|None>, "result": <відповідь
    двигуна|None>, "reason": <людський текст>}. Це «гучний фейл»: система бачить точну
    причину (порожній розбір / ORS впав / не знайдено пункт), а не домальовує маршрут."""
    # ⛒ 572: право на двигун дає ОГОЛОШЕННЯ в паспорті системи, а не її імʼя.
    # Дослівне імʼя тут означало б, що друга маршрутна система мовчки «пригадує»
    # відстані моделлю замість реального шляху.
    if not system_engines.has(system, system_engines.ROUTE):
        return "", None
    p = _parse_route_request(task)
    # ⛒ 574. ДВІ МОДЕЛІ СВІТУ. Перша — подорож «звідки → куди»: кінець називає
    # людина. Друга — РОЗВІЗНИЙ РЕЙС: база і точки розвантаження, кінець не
    # заданий. Доки ворота вимагали end, друга модель сюди не проходила взагалі:
    # розбирач мусив призначити кінцем одну з точок, а двигун переставляє лише
    # ПРОМІЖНІ — і останню точку де-факто ставила модель під рядком «чергу
    # визначив двигун». Тому ворота питають: є база і є куди їхати — хоч кінцем,
    # хоч точками розвантаження.
    drops = list((p or {}).get("drops") or [])
    if not p or not (p.get("start") or "").strip() or not ((p.get("end") or "").strip() or drops):
        return "", {"parsed": p, "result": None,
                    "reason": "розбір запиту не виділив звідки/куди "
                              "(порожні і end, і точки розвантаження)"}
    transport = p.get("transport") or "авто"
    if drops:
        # Розвізний рейс: чергу об'їзду і фініш рахує ДВИГУН — своя машина
        # замикає коло на базу, найнята лишає кінець вільним.
        rd = route_engine.route_delivery(p["start"], drops, transport,
                                         own_vehicle=bool(p.get("own_vehicle", True)))
        reason = ("розвізний рейс побудовано двигуном" if rd.get("ok")
                  else (rd.get("note") or "двигун не побудував розвізний рейс"))
        return route_engine.format_block(rd), {"parsed": p, "result": rd,
                                               "alternatives": [], "reason": reason}
    # ⛒ «Визнач чергу» — це робота двигуна: він рахує об'їзд за реальними
    # відстанями. Модель тут не голосує, інакше порядок міст був би вигаданий.
    want_order = bool(p.get("optimize_order"))
    r = route_engine.route(p["start"], p["end"], transport, p.get("waypoints") or [],
                           optimize=want_order)
    reason = ("маршрут побудовано двигуном" if r.get("ok")
              else (r.get("note") or "двигун не побудував маршрут"))
    block = route_engine.format_block(r)
    # ⭐ 572. АЛЬТЕРНАТИВИ РАХУЄ ДВИГУН, А НЕ МОДЕЛЬ. Людина просить «кілька
    # варіантів» — і без цього агент дав би другий варіант із памʼяті, з
    # вигаданою відстанню. Кожен коридор — окремий РЕАЛЬНИЙ прорахунок; те, що
    # двигун не побудував, у контекст не потрапляє взагалі.
    alts = []
    if r.get("ok"):
        for way in (p.get("alternatives") or []):
            ra = route_engine.route(p["start"], p["end"], transport, way,
                                    optimize=want_order)
            if not ra.get("ok"):
                alts.append({"via": way, "ok": False, "note": ra.get("note")})
                continue
            alts.append({"via": way, "ok": True, "distance_km": ra.get("distance_km"),
                         "duration_h": ra.get("duration_h")})
            block += ("\n\n## РЕАЛЬНИЙ МАРШРУТ — АЛЬТЕРНАТИВНИЙ ВАРІАНТ (через %s)\n"
                      "Це окремий прорахунок того самого двигуна. Порівнюй варіанти "
                      "ЛИШЕ за цими числами.\n\n" % ", ".join(way)) + route_engine.format_block(ra)
    if alts:
        reason += "; альтернативних коридорів прораховано: %d" % len(alts)
    return block, {"parsed": p, "result": r, "alternatives": alts, "reason": reason}


# Ключові слова «живих умов» дороги/в'їзду. Коли вони є в запиті маршруту, платформа
# САМА робить ОДИН живий веб-пошук актуальних обмежень пункту призначення й кладе реальні
# знахідки+джерела як факт (брат блоку «РЕАЛЬНИЙ МАРШРУТ»/«РЕАЛЬНІ ЗУПИНКИ»). Лікує корінь
# 14.07: веб приносив реальні обмеження (комендантська/блокпости, 30 джерел), а звіт писав
# «значних обмежень не виявлено» — впевнене заспокоєння поверх правди = найгірший обман.
_COND_KW = ("обмеж", "в'їзд", "в’їзд", "въезд", "комендант", "блокпост", "контрольн",
            "перекрит", "закрит дор", "дорожн обстан", "ситуац на дор", "проїзд",
            "перевір в інтернет", "перевірити в інтернет", "перевір у мереж")
_COND_HEAD = ("\n## ЖИВІ УМОВИ — актуальні обмеження в'їзду / дорожня обстановка "
              "(ЄДИНЕ джерело правди про умови)\n")


def _conditions_block(system, task: str, route_diag):
    """Для системи маршрутів: якщо запит просить актуальні обмеження в'їзду / дорожню
    обстановку — зробити ОДИН живий веб-пошук по пункту призначення й підкласти реальні
    знахідки + джерела як факт. Повертає (block, diag). diag → run.json (слід дії веб:
    checked / used_search / sources) — щоб «перевірив чи ні» було ВИДНО, а не на віру.
    Порожньо/збій → чесний блок «не перевірено», який ЗАБОРОНЯЄ писати «обмежень нема»."""
    if not system_engines.has(system, system_engines.ROUTE):
        return "", None
    t = (task or "").lower()
    if not any(k in t for k in _COND_KW):
        return "", None
    # Пункт призначення — з реального маршруту (краще) або з розбору запиту.
    dest = ""
    res = (route_diag or {}).get("result") if isinstance(route_diag, dict) else None
    if isinstance(res, dict):
        dest = res.get("end") or ""
    if not dest and isinstance(route_diag, dict):
        dest = ((route_diag.get("parsed") or {}).get("end")) or ""
    dcity = (dest.split(",")[0].strip() if dest else "") or "пункту призначення"
    if not config.web_search_ready():
        return (_COND_HEAD + "Веб-пошук недоступний — актуальні обмеження НЕ перевірено. "
                "НЕ пиши, що обмежень нема; чесно зазнач, що перевірити не вдалося, і дай "
                "офіційне джерело для ручної перевірки.\n",
                {"checked": False, "reason": "web_search недоступний", "sources": 0})
    import datetime
    today = datetime.date.today().strftime("%d.%m.%Y")
    query = (f"Актуальні обмеження на в'їзд та дорожня обстановка: {dcity} — комендантська "
             f"година, блокпости, перепустки, перекриття доріг, станом на {today}")
    sr = tools.web_search(query, context=task)
    used = sr.get("used_search")
    if sr.get("ok") and sr.get("text"):
        srcs = sr.get("sources") or []
        src_block = ""
        if srcs:
            src_block = "\n\nДжерела:\n" + "\n".join(
                f"  - {s.get('title') or s.get('url')}: {s.get('url')}" for s in srcs[:8])
        block = (_COND_HEAD +
                 f"(живий веб-пошук: провайдер шукав={used}, джерел={len(srcs)})\n"
                 "Виведи ці умови у звіт стисло, СВОЇМИ словами, з посиланнями на джерела. "
                 "НЕ пиши «значних обмежень нема», якщо нижче йдеться про комендантську "
                 "годину, блокпости чи перекриття. Чого нижче немає — не додумуй.\n\n"
                 + sr["text"].strip() + src_block + "\n")
        return block, {"checked": True, "used_search": used,
                       "sources": len(srcs), "query": query}
    note = sr.get("note") or "пошук повернув порожньо"
    return (_COND_HEAD + f"Живий веб-пошук не дав результату (причина: {note}). НЕ пиши, що "
            "обмежень нема — чесно зазнач, що актуальних даних знайти не вдалося, і дай "
            "офіційне джерело для ручної перевірки.\n",
            {"checked": True, "used_search": used, "sources": 0, "note": note})


def _seo_page_block(system, task: str, roles: dict = None):
    """Якщо роль системи декларує page_read (паспорт) і в задачі є адреса сторінки
    (повний URL АБО голий домен) — підкласти агентам СТРУКТУРОВАНИЙ витяг реальної
    сторінки (title/meta/og/canonical/H1-H3/JSON-LD/alt + очищений текст). Лікує
    корінь «агент вгадує з назви / бачить обрізаний парс».

    Повертає (block_str, facts|None, diag|None):
      • diag=None — це НЕ SEO-задача (немає ролі page_read) або в задачі немає адреси:
        звичайний плин, без стопу.
      • diag={"read_ok":True,...} — сторінку ВПЕВНЕНО прочитано (block + facts повні).
      • diag={"read_ok":False,"reason":…} — сторінку НЕ прочитано (редірект на іншу /
        недоступна / порожня оболонка): block порожній, а run_system віддає ЧЕСНИЙ СТОП
        замість аудиту «з голови» (дзеркало маршрутного стопу-фантазії)."""
    # ⭐⭐⭐ 04.08.2026, ЖИВИЙ ВИПАДОК У КЛІЄНТА (casper.in.ua → звіт про матраци).
    # КОРІНЬ: право вийти у світ і прочитати НАЗВАНЕ джерело було прикріплене до
    # ПАСПОРТА РОЛІ (page_read декларували 3 системи з 22). Маркетингова система
    # отримала адресу сайта, НЕ прочитала її і написала аудит із памʼяті моделі, ще й
    # заявила метод «аналіз публічно доступного сайту». Ворота «сторінку не прочитано»
    # навіть не вмикались — вони стояли за ВМІННЯМ системи, а не за ЗАДАЧЕЮ.
    # РІШЕННЯ (Андрій, 04.08.2026): джерело, НАЗВАНЕ в задачі, читають УСІ системи.
    # Паспорт ролі більше НЕ ворота — лише ознака профілю (role_page_read у diag: нею
    # гаситься вимір швидкості, щоб не міняти профіль вартості не-SEO задач).
    # РIВНО True = ПРОФIЛЬНА SEO-система: лише їй мiряємо швидкiсть (PageSpeed),
    # щоб право "implied" не змiнювало профiль вартостi не-SEO задач.
    has_page_read = any(((r or {}).get("tools") or {}).get("page_read") is True
                        for r in (roles or {}).values())
    url = _extract_task_url(task)
    if not url:
        return "", None, None
    r = tools.read_page_seo(url)
    # ВПЕВНЕНО прочитано = завантажилось І має текст І не повели на іншу сторінку
    # І не порожня оболонка. Інакше — чесний стоп (не м'яка приписка моделі).
    read_ok = bool(r.get("ok") and r.get("text")) and not r.get("redirected") and not r.get("thin")
    if read_ok:
        block = ("## РЕАЛЬНА СТОРІНКА (структурований витяг — ЄДИНЕ джерело правди про сторінку)\n"
                 "Аудит роби ЛИШЕ по цьому витягу. БУДЬ-ЯКИЙ опис вмісту сторінки в інших "
                 "частинах завдання (заголовки, сертифікати, нагороди, ціни, schema, тексти) "
                 "ІГНОРУЙ — він міг бути домислений і не звірений. Чого НЕМАЄ в цьому витягу — "
                 "вважай невідомим і НЕ стверджуй як факт.\n\n" + r["text"])
        return block, r.get("facts"), {"read_ok": True, "url": url,
                                       "role_page_read": has_page_read,
                                       "final_url": r.get("final_url") or url}
    # Сторінку НЕ прочитано впевнено — ЛЮДСЬКА причина для чесного стопу.
    if not (r.get("ok") and r.get("text")):
        reason = r.get("note") or "сторінка недоступна"
    elif r.get("redirected"):
        reason = (f"адреса веде на іншу сторінку ({url} → {r.get('final_url')}) — "
                  "тобто відкрито НЕ ту сторінку, яку ти дав")
    elif r.get("thin"):
        reason = ("сторінка відкрилась порожньою (ймовірно рендериться через JavaScript "
                  "або потребує входу) — перевірених даних про неї немає")
    else:
        reason = r.get("note") or "сторінку не вдалося прочитати"
    return "", None, {"read_ok": False, "url": url,
                      "role_page_read": has_page_read,
                      "final_url": r.get("final_url") or url, "reason": reason}


def _speed_block(seo_diag):
    """Реальна швидкість сторінки (Google PageSpeed) — той самий слот інжекту фактів,
    що й читання сторінки. Викликається ЛИШЕ коли сторінку впевнено прочитано
    (seo_diag.read_ok), для тієї самої фінальної адреси. Мʼяка деградація: нема даних →
    ('', diag), і стратег напише «швидкість не виміряно», а не вигадає цифри.

    Повертає (block_str, diag|None)."""
    if not (seo_diag and seo_diag.get("read_ok")):
        return "", None
    url = seo_diag.get("final_url") or seo_diag.get("url")
    try:
        r = tools.pagespeed_measure(url, strategy="mobile")
    except Exception as e:  # noqa
        return "", {"ok": False, "url": url, "note": f"виняток: {str(e)[:200]}"}
    if r.get("ok") and r.get("text"):
        block = ("## ШВИДКІСТЬ СТОРІНКИ (Google PageSpeed — ВИМІРЯНО, єдине джерело правди про швидкість)\n"
                 "Будь-які твердження про швидкість, час завантаження чи Core Web Vitals "
                 "(LCP/CLS/INP/TBT) роби ЛИШЕ з цього блоку. Немає блоку — пиши «швидкість "
                 "не виміряно», НЕ вигадуй цифр і НЕ став оцінок «на око».\n\n" + r["text"])
        return block, {"ok": True, "url": url, "data": r.get("data")}
    return "", {"ok": False, "url": url, "note": r.get("note", "")}


# (10.07.2026) _force_legal_web / _looks_market_task / _force_live + їхні словники
# прибрано повністю: ЧИ потрібен живий веб — каже контракт наміру (intent.fresh_data),
# КОМУ — паспорт ролей (web: "always" у юр-звіряча норм — інваріант юрсистем,
# засіяний registry.seed_roles; "per_intent" — у дослідницьких ролей).


# ---------------------------------------------------------------------------
# ЮРИСДИКЦІЯ — ОГОЛОШЕННЯ, А НЕ ВГАДУВАННЯ (11.08.2026, зміна 150)
# ---------------------------------------------------------------------------
# ⭐⭐⭐ Тут стояли два переліки підрядків (`_KZ_KW`, `_IL_KW`) і словник порталів.
# Переліки судили країну права за словами в задачі — і в них були пастки, які
# видно очима: " рк ", " il ", "астан", "костанай". Досить назви контрагента
# «Костанай-Буд» у договорі за українським правом — і платформа пішла б шукати
# норми в казахській базі. Той самий клас, що зробив консультацію водієві
# «тендерною закупівлею»: ПЕРЕЛІК ЛОВИТЬ БУКВУ, А НЕ ЗМІСТ.
#
# Тут же стояв і словник `_LEGAL_PORTAL` — ДАНІ в коді: нова країна вимагала
# правки коду й релізу.
#
# Тепер країну права ОГОЛОШУЄ контракт наміру (мозок обирає зі списку в
# довіднику, і цей список перевіряє сам провайдер). А офіційне джерело норм —
# це ДАНІ: воно живе в `knowledge_packs/domains/domains.json`, тож нова країна
# додається рядком у файл, а не правкою коду.


def _legal_jurisdiction(task: str = "", intent=None) -> str:
    """Право якої країни застосовується. Каже КОНТРАКТ; немає контракту —
    дефолт збірки (`config.DEFAULT_JURISDICTION`), як і раніше."""
    jid = str(((intent or {}) if isinstance(intent, dict) else {}).get("jurisdiction") or "").strip().upper()
    if jid:
        try:
            import domains as _dm
            if _dm.jurisdiction_is_known(jid):
                return jid
        except Exception:
            pass
    return getattr(config, "DEFAULT_JURISDICTION", "UA") or "UA"


def _legal_portal(task: str = "", intent=None) -> str:
    """Офіційне джерело норм цієї юрисдикції — з довідника, не з коду."""
    jid = _legal_jurisdiction(task, intent)
    try:
        import domains as _dm
        return _dm.portal_of(jid) or _dm.portal_of("UA") or ""
    except Exception:
        return ""


def _step_web_allowed(role_web, fresh_required: bool, step: dict, web_done: bool) -> bool:
    """ЧИ цей крок виходить у світ по живі дані.

    ⭐⭐⭐ 04.08.2026 (Андрій): «всі системи повинні мати можливість за потреби
    виходити у світ». Раніше право шукати давав ПАСПОРТ РОЛІ: роль без ключа
    web не шукала НІКОЛИ — навіть коли контракт наміру прямо казав «потрібні свіжі
    дані». Тепер вирішує ЗАДАЧА (контракт), а паспорт лише ПОСИЛЮЄ:
      • web="always" — інваріант ролі, шукає завжди (юрист-звіряч норм);
      • контракт fresh_data=required — шукає БУДЬ-ЯКА роль; один web-крок на
        прогін (розміщення — за підказкою плану), щоб не множити вартість.
    """
    if role_web == "always":
        return True
    if fresh_required:
        return bool((step or {}).get("needs_web_search")) or not web_done
    # ⭐⭐⭐ 09.08.2026, ВОРОТА ЗАМIСТЬ ПРОХАННЯ. Тричі поспiль платнi прогони
    # Андрiя вертались без ЖОДНОГО звернення до пошуку: веб вмикав лише контракт
    # намiру, а мозок його не ставив. Я лiкував це текстом у промптi — але
    # ПРАВИЛО В ПРОМПТI — ПРОХАННЯ, А НЕ ВОРОТА, i модель його не виконала.
    # Тепер вирiшує КОД: роль, якiй паспорт дав web, i крок-дослiдження — шукають
    # завжди. Вартiсть тримає той самий запобiжник, що й ранiше: web_done, тобто
    # РIВНО ОДИН веб-крок на прогiн.
    if role_web == "per_intent" and not web_done:
        return True
    return False


# --- 09.08.2026, задача T-000009. ЗНАЙШОВ АДРЕСУ - ВIДКРИЙ ЇЇ. --------------
# КОРIНЬ: веб-пошук повертав ПЕРЕКАЗ провайдера + список посилань. Справжнiй
# текст сторiнки читався ЛИШЕ тодi, коли адресу назвала сама задача
# (_seo_page_block). Тобто жодна з 23 систем не вiдкривала те, що знайшла САМА.
# Для людини це «знайду, але не подивлюсь» - саме так рекрутингова система
# вiдмовилась переглядати резюме, i клiєнт пiшов пробувати чужу CRM.
# ВМIННЯ, ЯКЕ ОБIЦЯЄ БIЛЬШЕ, НIЖ ДАЄ, - це не «частково працює», а «не працює».
# РIШЕННЯ: живi данi кроку = пiдсумок пошуку + СПРАВЖНIЙ текст верхнiх джерел.
# Грошей не коштує (прямий HTTP, не мовна модель).
# ⚠ Обрiзання називаємо ВГОЛОС: мовчазне звуження списку - заборонений клас.
_OPEN_FOUND_LIMIT = 3      # стеля за умовчанням, коли числа не замовляли
_OPEN_FOUND_MAX = 10       # верхня межа: далi це вже час i грошi клiєнта

# ⭐⭐⭐ КОРIНЬ 10.08.2026 (змiна 143), ЗНАЙДЕНО ЖИВИМ ПРОГОНОМ ЗА ГРОШI.
# Людина попросила «знайди 5 постачальникiв» — система вiддала чесний звiт про
# НУЛЬ пiдтверджених. Запобiжник брехнi спрацював, але результат порожнiй.
# Причина не в пошуку, а в арифметицi: `_OPEN_FOUND_LIMIT = 3` — жорстка стала.
# У логах живих прогонiв це видно дослiвно: found=26 opened=3, found=39 opened=3.
# Замовлено 5 пiдтверджених обʼєктiв — вiдкрито 3 сторiнки. Не «не пощастило»,
# а структурна неможливiсть виконати замовлення.
# Той самий клас, що вже коштував нам двiчi: ВОРОТА ЯКОСТI СУДЯТЬ ЗАМОВЛЕНИЙ
# ОБСЯГ, А СКЛАДАЧ ПРО ЦЕЙ ОБСЯГ НЕ ЗНАЄ. Тепер стеля рахується ВIД ЗАМОВЛЕННЯ.
# ⚠ ГРОШI: вiкно живих даних НЕ росте — бiльше сторiнок дiлять той самий бюджет.
# ⭐⭐⭐ 11.08.2026 (змiна 149), ЗЛОВЛЕНО ЖИВИМ ПРОГОНОМ. Число й предмет
# звʼязувались ЛИШЕ ВПРИТУЛ. У живому замовленнi «знайди 5 УКРАЇНСЬКИХ
# постачальникiв» одне слово мiж ними зробило замовлений обсяг НУЛЕМ: стеля
# лишилась 3, а `shortfall_note` промовчав — тобто недобiр став БЕЗГОЛОСИМ.
# Той самий клас, що вже коштував нам двiчi: ПЕРЕЛIК, ЯКИЙ ЛОВИТЬ БУКВУ, А НЕ
# ЗМIСТ. Тепер мiж числом i предметом дозволено до трьох слiв (лише лiтери, тож
# через кому й через iнше число звʼязок НЕ перестрибує), а число розумiється й
# СЛОВОМ. Перебiр тут дешевший за недобiр: зайва прочитана сторiнка — це час,
# мовчазний недобiр — це довiра клiєнта.
_WANTED_NOUN = (r"(?:постачальник|компан|органiзац|організац|обʼєкт|об'єкт|обєкт"
                r"|варiант|варіант|позиц|пункт|тем\b|темы|питан|кандидат|заклад|джерел|сайт"
                r"|магазин|виробник|продавц|конкурент|вакансi|вакансі|резюме|iдей|ідей)\w*")
# До трьох слiв-означень мiж числом i предметом. Лише лiтери: цифра або розділовий
# знак розриває звʼязок, тому «20 000 грн, компанiя» не читається як «20 компанiй».
_WANTED_GAP = r"(?:[^\W\d_]+[\-\s]+){0,3}"
_WANTED_WORDS = {
    "два": 2, "двi": 2, "дві": 2, "три": 3, "чотири": 4,
    "пʼять": 5, "п'ять": 5, "пять": 5, "шiсть": 6, "шість": 6,
    "сiм": 7, "сім": 7, "вiсiм": 8, "вісім": 8,
    "девʼять": 9, "дев'ять": 9, "девять": 9, "десять": 10,
    "дванадцять": 12, "пʼятнадцять": 15, "п'ятнадцять": 15, "двадцять": 20,
}
_WANTED_RE = re.compile(
    r"(?:\bтоп[-\s]?(\d{1,2})\b"
    r"|\bне\s+менше\s+(\d{1,2})\b"
    r"|\b(\d{1,2})\s+" + _WANTED_GAP + _WANTED_NOUN + r")",
    re.IGNORECASE)
_WANTED_WORD_RE = re.compile(
    r"\b(" + "|".join(sorted(_WANTED_WORDS, key=len, reverse=True)) + r")\s+"
    + _WANTED_GAP + _WANTED_NOUN,
    re.IGNORECASE)


def wanted_count(text) -> int:
    """Скiльки ОБʼЄКТIВ людина замовила (0 — числа не називали).

    Читає КОД, а не модель: прохання в промптi — це прохання, а стеля пошуку
    мусить бути воротами. Береться НАЙБIЛЬШЕ назване число, бо недобiр коштує
    дорожче за зайву прочитану сторiнку (мережа безкоштовна).
    """
    t = str(text or "")
    best = 0
    for m in _WANTED_RE.finditer(t):
        for g in m.groups():
            if g and g.isdigit():
                best = max(best, int(g))
    for m in _WANTED_WORD_RE.finditer(t):
        best = max(best, _WANTED_WORDS.get((m.group(1) or "").lower(), 0))
    return best if 2 <= best <= 50 else 0


def open_limit_for(task) -> int:
    """Скiльки сторiнок вiдкривати пiд це замовлення."""
    n = wanted_count(task)
    if not n:
        return _OPEN_FOUND_LIMIT
    return max(_OPEN_FOUND_LIMIT, min(_OPEN_FOUND_MAX, n + 1))


def shortfall_note(task, opened: int) -> str:
    """Чесний недобiр: замовили N обʼєктiв, а джерел прочитано менше.

    Мовчазний недобiр — це те, за що клiєнт платить двiчi: спершу грошима за
    прогiн, потiм довiрою до результату.
    """
    n = wanted_count(task)
    if not n or opened >= n:
        return ""
    return ("⚠ ЗАМОВЛЕНО %d ОБʼЄКТIВ, А ПЕРВИННИХ ДЖЕРЕЛ ПРОЧИТАНО %d. "
            "Стiльки, скiльки просили, пiдтвердити НЕМА ЧИМ: вiддай тiльки те, що "
            "справдi пiдтверджено джерелами, і прямо скажи, скiльки саме вийшло "
            "та чому — не добирай кiлькiсть здогадами." % (n, opened))
_OPEN_FOUND_TRIES = 5      # скiльки адрес пробуємо (недоступнi не крадуть квоту)
_OPEN_FOUND_CHARS = 6000   # СТЕЛЯ на сторiнку, коли бюджет не заданий

# --- 09.08.2026. БЮДЖЕТ ЖИВИХ ДАНИХ - ОДНЕ ДЖЕРЕЛО ПРАВДИ -----------------
# СКЛАДАЧ, ЯКИЙ НЕ ЗНАЄ ПРО СТЕЛЮ СПОЖИВАЧА, ГОТУЄ МОВЧАЗНЕ ОБРIЗАННЯ.
# Проба 09.08 (перехоплений промпт агента): блок на 19 768 символiв доїжджав
# до агента як ХВIСТ у 6 000 - без заголовка й iнструкцiї «не додумуй», без
# пiдсумку пошуку, з обрубком третьої сторiнки вiд середини речення. А рядок
# «вiдкрито 3 з 5» виживав i виглядав як доказ, що все гаразд. Це ГIРШЕ, нiж
# не вiдкривати зовсiм: агент дiстає смiття плюс запевнення, що все прочитано.
# РIШЕННЯ: одна константа, яку знають ОБИДВА боки - i збирач, i зрiз у промптi.
# 12 000 узгоджено з уже прийнятим рiшенням для прочитаної сторiнки
# (seo_page 16 000): це ПЕРВИННЕ джерело, а не переказ провайдера.
LIVE_DATA_WINDOW = 12000

# ⭐⭐⭐ КОРІНЬ 10.08.2026. ВІКНО, ЯКЕ ВИКИДАЛО ПОЧАТОК ДОКУМЕНТА.
# Доданi файли їхали в промпт кроку як `files_context[-8000:]` — тобто ОСТАННІ
# 8 000 знаків. `source_intake` віддає до 60 000, а блок джерела дописується в
# КІНЕЦЬ — отже хвіст лишався, а ПОЧАТОК оголошення викидався. Саме там, на
# початку, замовник пише перелік обовʼязкових документів. Агент-читач тендерайтера
# фізично не бачив того, що мусив прочитати: у пакет доїжджало 5 вимог із 13.
# І про обрізання не було сказано НІ СЛОВА — класичне мовчазне обрізання, той
# самий клас, що вчора коштував нам аркушів Excel.
#
# ЛІКУЄМО ОДНИМ ПИСАРЕМ НА ВСІ ВСТАВКИ: беремо ГОЛОВУ і ХВІСТ, ріжемо СЕРЕДИНУ і
# кажемо про це вголос. Голова важливіша за хвіст (там структура документа й
# перелік), тому їй дві третини бюджету.
FILES_CONTEXT_WINDOW = 24000


def fit_context(text: str, budget: int, what: str = "матеріал") -> str:
    """Укласти текст у бюджет знаків, НЕ втративши початок і сказавши про різ.

    Мовчазне обрізання заборонене: якщо ріжемо — у тексті стоїть видима позначка,
    щоб і модель, і людина в журналі бачили, що матеріал неповний.
    """
    t = str(text or "")
    if budget <= 0 or len(t) <= budget:
        return t
    head = int(budget * 0.66)
    tail = budget - head - 120
    if tail < 0:
        head, tail = budget, 0
    cut = len(t) - head - tail
    mark = ("\n\n[…СЕРЕДИНУ %s СКОРОЧЕНО НА %d ЗНАКІВ — це НЕ кінець документа. "
            "Якщо потрібного пункту тут немає, скажи про це прямо, НЕ додумуй…]\n\n"
            % (what.upper(), cut))
    return t[:head] + mark + (t[-tail:] if tail > 0 else "")
_LIVE_SUMMARY_SHARE = 0.25   # частка бюджету на переказ провайдера
_OPEN_FOUND_MIN_CHARS = 700  # менше цього сторiнка вже не iнформативна
_DEEP_OPEN = 6               # скiльки карток брати зi сторiнки-покажчика


def _open_found_sources(sources, limit: int = _OPEN_FOUND_LIMIT,
                        budget: int = 0):
    """Вiдкриває верхнi знайденi пошуком адреси i вiддає їх СПРАВЖНIЙ текст.

    Повертає (block, note, opened_urls): note - вголос сказане обрiзання
    («вiдкрито 3 з 9»), щоб мовчазне звуження не видавало себе за повний огляд;
    opened_urls - адреси, якi ЦЕЙ виклик справдi вiдкрив i прочитав.

    ⭐⭐⭐ КОРIНЬ 10.08.2026 (змiна 148). Вiдкритi адреси ранiше клались в
    АТРИБУТ ФУНКЦIЇ (`last_opened`) — тобто у стан, спiльний для всiх крокiв
    прогону. При ранньому виходi (пошук не дав джерел) атрибут лишався вiд
    ПОПЕРЕДНЬОГО кроку, i адреси сусiда дописувались у джерела поточного як
    «прочитана сторiнка». У логах живого прогону: `found=3 opened=0`.
    ПЛАТФОРМА НЕ СМIЄ КАЗАТИ, ЩО ЧИТАЛА ТЕ, ЧОГО НЕ ЧИТАЛА — тому вiдповiдь
    вiддається ЯВНО тому, хто питав, i нiде не зберiгається."""
    urls = []
    for _s in (sources or []):
        u = ((_s or {}).get("url") or "").strip()
        if u.lower().startswith(("http://", "https://")) and u not in urls:
            urls.append(u)
    if not urls:
        return "", "", []
    # Скiльки символiв дiстанеться КОЖНIЙ сторiнцi: бюджет дiлиться усвiдомлено,
    # а не «хто останнiй, той вцiлiв». Не влазить навiть мiнiмум - беремо МЕНШЕ
    # сторiнок, але ЦIЛИМИ (краще двi повнi, нiж три обрубки).
    per = _OPEN_FOUND_CHARS
    if budget and budget > 0:
        _room = max(0, budget - 260)          # запас на заголовок i пiдпис
        while limit > 1 and _room // limit < _OPEN_FOUND_MIN_CHARS:
            limit -= 1
        per = max(_OPEN_FOUND_MIN_CHARS, _room // max(1, limit))
        per = min(per, _OPEN_FOUND_CHARS)
    # ⭐⭐⭐ 09.08.2026. ЗНАЙШОВ ПОКАЖЧИК — IДИ ЗА ПОСИЛАННЯМ (живий провал у клiєнта).
    # Пошук приводив на сторiнку-СПИСОК (14 резюме, 3939 усього). Ми її вiдкривали
    # i зупинялись: у списку лише короткi пiдписи, а самi записи — за посиланнями.
    # Модель на цьому дописувала «доступ закритий» i вигадувала кандидатiв.
    # Тому: якщо адреса виявилась покажчиком — беремо з неї КАРТКИ записiв i
    # ставимо їх у чергу ПЕРЕД самим покажчиком (людина робить так само).
    _deep = []
    for u in urls[:2]:
        try:
            _deep.extend(tools.page_record_links(u, limit=_DEEP_OPEN))
        except Exception:
            pass
    if _deep:
        urls = _deep + [u for u in urls if u not in _deep]

    blocks, opened, failed = [], 0, []
    _opened_ok = []            # адреси, якi платформа СПРАВДI вiдкрила й прочитала
    _tries = max(_OPEN_FOUND_TRIES, int(limit) + 3)
    for u in urls[:_tries]:
        if opened >= limit:
            break
        try:
            r = tools.read_page_seo(u)
        except Exception as _e:
            failed.append("%s (%s)" % (u, _e))
            continue
        if r.get("ok") and r.get("text") and not r.get("thin"):
            opened += 1
            _body = r["text"][:per]
            if len(r["text"]) > per:
                _body += "\n[сторiнку скорочено до %d символiв]" % per
            _opened_ok.append(r.get("final_url") or u)
            blocks.append("### Прочитана сторiнка %d: %s\n%s"
                          % (opened, r.get("final_url") or u, _body))
        else:
            failed.append("%s (%s)" % (u, r.get("note") or "не вiдкрилась"))
    if not blocks:
        return "", ("Знайдено адрес: %d, але ЖОДНУ сторiнку не вдалося вiдкрити (%s). "
                    "Спирайся лише на пiдсумок пошуку i НЕ видавай вмiст сторiнок за "
                    "перевiрений." % (len(urls), "; ".join(failed[:3])), [])
    head = ("## ВIДКРИТI СТОРIНКИ ЗА ЗНАЙДЕНИМИ АДРЕСАМИ (справжнiй текст, не переказ)\n"
            "Це первинне джерело. Що є тут - можна стверджувати; чого тут немає - "
            "вважай невiдомим i НЕ додумуй.\n")
    note = "Вiдкрито сторiнок: %d iз %d знайдених адрес." % (opened, len(urls))
    if failed:
        note += " Не вiдкрилися: %d." % len(failed)
    return head + "\n\n".join(blocks), note, _opened_ok


def _gather_live_data(task, step, system=None, force=False, intent=None):
    """Запускає веб-пошук для кроку. Повертає (live_text, sources, fail_note):
    fail_note — ЛЮДСЬКА причина, чому живих даних немає (для ГУЧНОЇ деградації
    на інваріантних ролях web='always' — юрист 10.07 ~23:40 промовчав у stderr).
    ЧИ шукати — вирішено ДО виклику (контракт наміру × паспорт ролі); тут force=True
    означає «шукай». _is_legal_system нижче — лише про ФОРМУЛЮВАННЯ запиту
    (офіційний портал юрисдикції), не про дозвіл."""
    if not (force and config.web_search_ready()):
        return "", [], ("веб-пошук недоступний (не налаштований або вимкнений)" if force else "")
    # ШАР 1 — ОФІЦІЙНЕ ПЕРШОДЖЕРЕЛО (право UA): для української правової системи
    # спершу пробуємо офіційну базу «Законодавство України» ВРУ (точний текст +
    # чинна редакція з офіційної картки), а не загальний веб-пошук (агрегатори /
    # JS-порожнеча zakon.rada). Дало результат → віддаємо його як живі дані; ні →
    # падаємо назад на звичайний веб-пошук нижче, нічого не втрачаючи.
    if _is_legal_system(system) and _legal_jurisdiction(task, intent) == "UA":
        try:
            _off = legal_source_ua.lookup(task)
        except Exception as _e:
            _off = {"ok": False, "note": f"офіційне джерело: помилка {_e}"}
        if _off.get("ok"):
            return _off["block"], _off.get("sources", []), ""
    query = f"{task} — {step.get('purpose','')}".strip(" —")
    # Юридична звірка норм — ЛИШЕ для правових систем (не для ринкових), і за
    # офіційним порталом відповідної юрисдикції (UA→zakon.rada, KZ→adilet.zan.kz).
    if _is_legal_system(system):
        query += (" — чинна редакція норм, звірити назву/номер/зміст статті за офіційним "
                  "джерелом " + _legal_portal(task, intent))
    sr = tools.web_search(query, context=task)
    if sr.get("ok") and sr.get("text"):
        srcs = sr.get("sources", [])
        # ⭐⭐⭐ КОРIНЬ 10.08.2026 (змiна 148). ПОРЯДОК ВИДАЧI — НЕ ПОРЯДОК
        # ПРИДАТНОСТI. Замовили ТКАНИНУ (сировину) — вiдкривали картки ГОТОВИХ
        # ВИРОБIВ на маркетплейсах, бо брали просто верхнi адреси видачi.
        # Впорядковуємо ОДРАЗУ, до складання блоку: тодi й перелiк джерел, i
        # порядок читання сторiнок у промптi агента однаковi. Нiчого не
        # викидається; суддя впав -> порядок лишається як був.
        srcs = source_fit.order_sources(task, srcs, wanted_count(task))
        # БЮДЖЕТ ДIЛИТЬСЯ УСВIДОМЛЕНО: спершу мiсце пiд переказ провайдера й
        # перелiк джерел, ВСЯ решта - пiд справжнiй текст вiдкритих сторiнок.
        summary = sr["text"]
        _sum_cap = int(LIVE_DATA_WINDOW * _LIVE_SUMMARY_SHARE)
        if len(summary) > _sum_cap:
            summary = (summary[:_sum_cap]
                       + "\n[пiдсумок пошуку скорочено - нижче йде справжнiй "
                         "текст сторiнок, вiн важливiший]")
        src_lines = ""
        if srcs:
            src_lines = "\n\nДжерела:\n" + "\n".join(f"- {s.get('title') or s['url']}: {s['url']}" for s in srcs)
        block = summary + src_lines
        # ЗНАЙШОВ АДРЕСУ - ВIДКРИЙ ЇЇ (не переказ провайдера, а сама сторiнка).
        _opened, _op_note, _opened_urls = _open_found_sources(
            srcs, limit=open_limit_for(task),
            budget=LIVE_DATA_WINDOW - len(block) - 200)
        # ⭐ СЛIД (09.08.2026): без нього причина «система нiчого не знайшла»
        # знову була б здогадкою. ASCII — консоль Windows кирилицю в stderr ламає.
        import sys as _ot
        # ⭐ 09.08.2026. АДРЕСА, ЯКУ ПЛАТФОРМА СПРАВДI ВIДКРИЛА, — ЦЕ ДЖЕРЕЛО.
        # Iнакше ворота проти вигадки рiзали ПРАВДУ: картки зi сторiнки-покажчика
        # не були у sources (там лише сам покажчик) i виглядали як вигаданi.
        for _ou in (_opened_urls or []):
            if _ou and not any((x or {}).get("url") == _ou for x in srcs):
                srcs.append({"title": "прочитана сторiнка", "url": _ou})
        _ot.stderr.write("[web] found=%d opened=%d note=%r urls=%s\n"
                         % (len(srcs), (_opened or "").count("### "),
                            (_op_note or "")[:60],
                            "; ".join((x or {}).get("url", "") for x in srcs[:4])))
        if _opened:
            block += "\n\n" + _opened
        if _op_note:
            block += "\n\n" + _op_note
        # ⭐ НЕДОБIР НАЗИВАЄ СЕБЕ: замовили 5 обʼєктiв — прочитали 2 джерела.
        _short = shortfall_note(task, (_opened or "").count("### "))
        if _short:
            block += "\n\n" + _short
        # ГАРАНТIЯ IНВАРIАНТУ: зiбране ВЛАЗИТЬ у вiкно споживача. Перебiр рiжемо
        # з ПЕРЕКАЗУ (найменш цiнне), а не з хвоста - iнакше зрiз у промптi знову
        # зʼїсть заголовок, iнструкцiю «не додумуй» i першi сторiнки.
        if len(block) > LIVE_DATA_WINDOW:
            _over = len(block) - LIVE_DATA_WINDOW
            _tail = "\n[переказ скорочено - мiсце вiддано сторiнкам]"
            summary = summary[:max(0, len(summary) - _over - len(_tail))] + _tail
            block = summary + src_lines
            if _opened:
                block += "\n\n" + _opened
            if _op_note:
                block += "\n\n" + _op_note
        return block, srcs, ""
    note = sr.get("note") or "пошук повернув порожню відповідь"
    import sys as _sys
    _sys.stderr.write(f"[web_search] крок «{step.get('agent')}»: {note}\n")
    return "", [], note


# ── ⭐⭐⭐ 07.08.2026. ОДИН ПИСАР ТЕКСТУ ПРО СТВОРЕНЕ ────────────────────────
# Речення про те, що платформа створила, пише КОД і ніхто інший. Мозок може
# додати супровід, але не може ні прибрати цей блок, ні переказати його інакше:
# 07.08 саме переказ перетворив «створено трьома агентами Будівника» на
# «зробив 3 агенти замість 2», а вдалу роботу — на доповідь про провал.
_KIND_WORDS = {"system": "Система", "file": "Файл", "record": "Запис"}


def created_report_markdown(items) -> str:
    """Дослівний блок для ЛЮДИНИ: що саме створено, де воно лежить, чим доведено."""
    items = [i for i in (items or []) if isinstance(i, dict)]
    if not items:
        return ""
    lines = ["✅ **Створено й перевірено на диску:**", ""]
    for it in items:
        word = _KIND_WORDS.get(it.get("kind") or "", "Створено")
        title = it.get("name") or it.get("id") or it.get("address") or "—"
        lines.append(f"- {word}: **{title}**")
        if it.get("id"):
            lines.append(f"  - id: `{it['id']}`")
        if it.get("address"):
            lines.append(f"  - де лежить: `{it['address']}`")
        if it.get("files"):
            lines.append(f"  - файлів записано: {it['files']}")
        if it.get("proof"):
            lines.append(f"  - чим доведено: {it['proof']}")
    if any((i.get("kind") == "system") for i in items):
        lines.append("")
        lines.append("Наступний крок — активувати систему кнопкою «✓ Активувати» на її картці.")
    return "\n".join(lines)


def _build_for_real(actor, system: dict, task: str, files_context: str = "", history=None,
                    emit=None, style: str = "", depth: str = "full", should_cancel=None,
                    original: str = "") -> dict:
    """ПОВНОЦІННИЙ запуск системи «Будівник систем»: працюють УСІ ТРИ її агенти
    (Аналітик → Автор промптів → Структуролог), а їхній структурний результат
    ДЕТЕРМІНОВАНО матеріалізується на диск (файли + реєстрація). Це найчистіша
    форма філософії платформи: агенти проєктують — сервер лише пише байти.

    Історія: раніше ці агенти лише ПИСАЛИ текст, а їхній JSON ніхто не матеріалізував
    → звіт «створено», порожньо на диску (run 10.07 09:33, verified:false).
    ЗАМОК ЧЕСНОСТІ: звіт «створено» — лише після перевірки реальних артефактів."""
    # ⭐⭐⭐ ВОРОТА ВХОДУ №2 — ДО ВИТРАТ (12.08.2026, зміна 162).
    # Ворота при матеріалізації (`builder.materialize_from_agents`) судять ЯВНУ
    # декларацію Будівника. Дірку це не закриває: 12.08 Будівник не оголосив
    # НІЧОГО, а «читачеві пошти» тихо дав веб-пошук — ворота, які питають лише
    # того, хто вже збрехав, брехні не ловлять. Тому тут питаємо суддю про СЕНС
    # САМОЇ ЗАДАЧІ, і робимо це ДО трьох агентів Будівника: чесна зупинка мусить
    # коштувати дешевше за побудову. Суддя недоступний — ворота МОВЧАТЬ.
    import builder as _bld_gate
    _iv = _bld_gate.judge_task_inputs(task)
    if _iv.get("ok"):
        _imiss = registry.missing_inputs(_iv.get("needs") or [])
        if _imiss:
            _iref = registry.input_refusal(_imiss, "", "Систему не збудовано")
            _emit(emit, "⛔ Немає входу: " + ", ".join(_iref["missing"]))
            return honest_stop_result(
                system, kind="missing_input", reason=_iref["reason"],
                action=_iref["action"], markdown=_iref["markdown"])

    # 1) Реальний 3-агентний конвеєр (allow_real_build=False → без рекурсії сюди).
    # ⭐⭐⭐ 07.08.2026. АКТОР ІДЕ СКРІЗЬ, І ВСЕРЕДИНУ ТЕЖ.
    # Це ТОЙ САМИЙ прогін, просто його внутрішній круг, тому актор — той самий.
    # Другого джерела правди про «хто діє» не заводимо: 06.08 цей виклик лишився
    # без актора й валив Будівника TypeError'ом — див. builder_actor_test.
    inner = run_system(actor, system, task, files_context=files_context, history=history,
                       precheck=False, emit=emit, style=style, depth=depth,
                       should_cancel=should_cancel, allow_real_build=False, meta_mode=True,
                       original=original)
    if inner.get("status") != "completed":
        return inner  # needs_input / cancelled / error — віддаємо як є

    # 2) Беремо СИРИЙ вивід Структуролога (JSON), а не зібраний фінал: складальник
    #    переписує все у Markdown і може прибрати JSON-блок.
    struct_raw = ""
    trace = inner.get("agent_trace") or []
    for t in reversed(trace):
        if "AgentStructureCreator" in (t.get("agent") or ""):
            struct_raw = t.get("output") or ""
            break
    if not struct_raw and trace:
        struct_raw = trace[-1].get("output") or ""

    # 2б) Повні тексти промптів — з БЛОКІВ Райтера (контракт «дані → рендер»):
    # Структуролог віддає легку структуру з content_from, щоб великий кириличний/
    # багатоагентний вміст не рвав JSON лімітом ходу (корінь обриву 10.07 ~21:30).
    writer_raw = ""
    for t in reversed(trace):
        if "AgentPromptWriter" in (t.get("agent") or ""):
            writer_raw = t.get("output") or ""
            break

    # 3) Детермінована матеріалізація на диск + реєстрація.
    import builder
    # 3а) ДОЗАПИТ відсутніх блоків Райтера — ПО ОДНОМУ за хід (10.07 ~23:00:
    # 5 повних промптів не влазять в один хід; правило — розмір системи не
    # залежить від жодного одиничного ходу). Один блок завжди влазить у стелю.
    sources = builder.parse_prompt_blocks(writer_raw)
    # Список агентів — з КРИХІТНОЇ, стійкої до обриву структури (+ салваж із блоків
    # Райтера й шляхів). Розкладку файлів будує сервер детерміновано; крихкий
    # великий JSON files_to_create більше НЕ на критичному шляху (корінь
    # «непарсабельний JSON» 10.07 ~23:28).
    meta = builder.parse_build_meta(struct_raw, writer_raw)
    needed = ["MAIN"] + [a for a in (meta.get("agents") or []) if a and a != "MAIN"]
    if any(i not in sources for i in needed):
        wprompt = (_load_agent_prompt(system, "AgentPromptWriter")
                   or _synth_agent_prompt(system, "AgentPromptWriter",
                                          "писати повні системні промпти агентів"))

        def _ask_block(mid):
            ask = (
                f"## TASK (the system being built)\n{task[:6000]}\n\n"
                f"## YOUR EARLIER OUTPUT (some blocks were cut off by the turn limit)\n"
                f"{(writer_raw or '')[-10000:]}\n\n"
                f"## REFILL REQUEST (deterministic, one block only)\n"
                f"Your earlier output is missing the prompt block for agent id={mid}. "
                f"Write the COMPLETE English system prompt for this agent, consistent "
                f"with the agents you already wrote (role, place in pipeline, inputs, "
                f"outputs, quality checks, response format). Output EXACTLY ONE machine "
                f"block and NOTHING else:\n"
                f"<<<AGENT_PROMPT id={mid}>>>\n...full prompt text...\n<<<END_AGENT_PROMPT>>>"
            )
            return llm.complete(wprompt, ask, temperature=0.2,
                                model=config.worker_model(),
                                max_tokens=config.BUILDER_MAX_TOKENS)

        sources = builder.refill_missing_blocks(needed, sources, _ask_block,
                                                emit=lambda s: _emit(emit, s))
    _emit(emit, "🏗️ Матеріалізую систему на диск (файли + реєстрація)…")
    b = builder.materialize_from_agents(meta, sources, task, emit)
    if not b.get("ok"):
        reason = b.get("note", "") or "невідома причина"
        # ОГЛЯДОВІСТЬ (10.07.2026, вечір): точна причина відмови матеріалізації має
        # доходити до людини Й на диск, а не ховатись за переказом мозку (кейс ~22:50
        # 10.07: мозок проковтнув причину й вигадав «обхід через build_system»).
        # 1) емітимо причину в панель прогресу ДОСЛІВНО (повз мозок);
        _emit(emit, f"❌ Матеріалізація ВІДХИЛЕНА: {reason}")
        # 2) пишемо протокол невдалого білда у runs/_build_failures.jsonl (конвенція _audit.jsonl).
        try:
            from datetime import datetime as _dt
            rec = {
                "ts": _dt.now().isoformat(),
                "task": (task or "")[:500],
                "reason": reason,
                "agents_detected": (meta.get("agents") if isinstance(meta, dict) else None),
                "have_prompt_ids": sorted((sources or {}).keys()),
                "struct_raw_tail": (struct_raw or "")[-4000:],
                "writer_raw_tail": (writer_raw or "")[-4000:],
            }
            with open(config.RUNS_DIR / "_build_failures.jsonl", "a", encoding="utf-8") as _f:
                _f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception as _e:
            import sys as _sys
            _sys.stderr.write(f"[build-fail-log] не зміг записати протокол: {_e}\n")
        inner["status"] = "runtime_error"
        inner["client_safe"] = True   # текст нижче написаний ДЛЯ ЛЮДИНИ (див. failure.result_text)
        inner["final_markdown"] = (
            "❌ Агенти спроєктували систему, але детермінована матеріалізація ВІДХИЛИЛА "
            f"результат. Точна причина: **{reason}**.\n\n"
            "Нічого не створено. ⚠ Це НЕ тимчасовий «збій рантайму» — повторний запуск тим "
            "самим шляхом дасть ту саму помилку. Передай користувачу точну причину вище "
            "ДОСЛІВНО і зупинись. НЕ пропонуй «обхід через build_system» (це ті самі двері) "
            "і НЕ повторюй побудову в цьому ж ході."
        )
        return inner

    # 4) Замок чесності: підтвердити РЕАЛЬНІ артефакти.
    from pathlib import Path as _Path
    sid = b.get("system_id", "")
    project_path = b.get("project_path", "")
    in_registry = any(s.get("id") == sid for s in registry.load_systems())
    folder_ok = bool(project_path) and _Path(project_path).exists()
    if not (in_registry and folder_ok):
        inner["status"] = "runtime_error"
        inner["client_safe"] = True   # текст нижче написаний ДЛЯ ЛЮДИНИ (див. failure.result_text)
        inner["final_markdown"] = ("❌ Перевірка НЕ підтвердила артефакти "
            f"(реєстр: {'є' if in_registry else 'нема'}, папка: {'є' if folder_ok else 'нема'}). "
            "Створення скасовано як недоведене.")
        return inner

    name = (b.get("registry_entry") or {}).get("name", sid)
    inner["system_id"] = sid
    # ⭐⭐⭐ 07.08.2026. МАШИННИЙ ФАКТ СТВОРЕНОГО — не текст, не переказ.
    # Корінь, який це лікує (живий прогін 07.08 ~15:03): Будівник СПРАВДІ збудував
    # систему на диску, а ворота приймання судили ТЕКСТ супроводу — і оголосили
    # «роботи не зроблено, файли не створювались». Мозок чесно переказав вирок,
    # людина побачила провал замість зробленої роботи.
    # Клас: продукт прогону не завжди є текстом чи файлом у теці прогону; коли
    # платформа не має МАШИННОГО факту про створене, останнє слово лишається за
    # думкою судді про текст. Факт, доведений диском, важчий за думку про текст.
    # Хто пише факт: ТОЙ, ХТО СТВОРИВ І ПЕРЕВІРИВ (тут — замок чесності вище).
    inner.setdefault("created", []).append({
        "kind": "system",
        "id": sid,
        "name": name,
        "address": str(project_path),
        "files": len(b.get("files", []) or []),
        "proof": "запис у реєстрі та папка перевірені на диску",
    })
    # Текст для ЛЮДИНИ рендерить КОД (один писар для всіх видів створеного).
    inner["final_markdown"] = created_report_markdown(inner["created"])
    # ⭐ Службові вказівки мозкові НЕ живуть у тексті результату: 07.08 рядок
    # «НЕ перебудовуй її автоматично» доїхав до людини переказом «платформа
    # заблокувала повторну побудову». Тепер у мозку окреме поле, у людини — своє.
    inner["brain_note"] = (
        "Систему СТВОРЕНО (needs_review) і показано користувачу кодом. НЕ запускай "
        "smoke test і НЕ перебудовуй її автоматично; не заходь у цикл "
        "побудова→тест→перебудова. Твоя відповідь — одне коротке речення-супровід."
    )
    _emit(emit, "✅ Систему створено й перевірено на диску.")
    return inner


# ⭐⭐⭐ 555. ВОРОТА, ЩО СУДЯТЬ НАМІР ЛЮДИНИ, ЧИТАЮТЬ ЇЇ СЛОВА, А НЕ ПЕРЕКАЗ.
# 10.09.2026 платформа сама написала клієнтові фразу, якою зняти зупинку
# («збери попри закритий строк»), клієнт сказав її дослівно — і дістав ту саму
# відмову. Бо ворота дивились у `task`, тобто в ПЕРЕКАЗ мозку, куди дозвіл не
# доїхав. Закон «судити слова людини» в платформі вже є (ворота маршруту,
# route_origin_test), просто не був застосований тут.
# 🩸 Писар ОДИН: інакше наступні ворота знову склеять рядки руками і забудуть
# першоджерело — рівно так і сталося тут.
def _human_words(task: str, original: str = "") -> str:
    """Те, що читають ворота наміру: ПЕРШОДЖЕРЕЛО (слова людини) + переказ.
    Переказ лишається — у ньому теж може бути дозвіл, якщо людина сказала його
    всередині самої задачі."""
    a = str(original or "").strip()
    b = str(task or "").strip()
    return (a + "\n" + b).strip() if a else b


def run_system(actor, system: dict, task: str, files_context: str = "", history=None, precheck=True,
               emit=None, style: str = "", depth: str = "full", should_cancel=None,
               allow_real_build: bool = True, meta_mode: bool = False,
               intent: dict = None, resume: dict = None, model_floor: str = "",
               understanding: dict = None, route_claim: dict = None,
               original: str = "", _policy_pass: int = 0) -> dict:
    # understanding: ГОТОВИЙ контракт розуміння від того, хто вже його склав
    # (ворота в `agent`, які бачили поправку людини). Переданий — беремо його й
    # НЕ перескладаємо. Не переданий — складаємо самі, як і раніше.
    # model_floor: не використовувати щаблі драбини, ДЕШЕВШІ за названий. Ставить
    # ланцюг систем на другій спробі кроку (chains.may_retry).
    if model_floor:
        _FLOOR.model = model_floor
    else:
        _FLOOR.model = ""
    # depth: "full" — повний конвеєр із циклом якості (за замовчуванням);
    #        "quick" — конвеєр один раз, без раундів критика (швидко, для простих задач).
    # СПЕЦ-МАРШРУТ: «Будівник систем» має СПРАВДІ будувати, а не лише описувати.
    # allow_real_build=False лишає стару «балакучу» поведінку (для smoke-тесту, щоб
    # тестовий прогін не створював реальних систем).
    # ⭐⭐⭐ ВОРОТА 1 «ЧИ МОЖНА ЗАРАЗ ПРАЦЮВАТИ» (07.08.2026, бізнес-модель).
    # Стоять ПЕРЕД воротами «хто діє», бо право платформи ширше за право людини:
    # коли користування припинено, питання «хто саме діє» вже не має значення.
    # Відповідь дає ОДИН автор — `license.work_allowed()`, який знає про моделі
    # оплати: у моделі A строк абонплати минув, а працювати можна далі.
    # Раніше ця перевірка стояла ЛИШЕ в мозку (`agent._impl_run_system`), тобто
    # повз неї роботу запускали розклад, ланцюги, телеграм і smoke-тест —
    # той самий клас «ворота лише на першому вході».
    import license as _lic
    _ok_pay, _why_pay = _lic.work_allowed()
    if not _ok_pay:
        _emit(emit, "⛔ Користування призупинено")
        return honest_stop_result(
            system, kind="subscription_expired", reason=_why_pay,
            action="поновіть підписку — після оплати робота продовжиться без втрат",
            markdown=("## Роботу не запущено: користування призупинено\n\n%s\n\n"
                      "Дані й напрацювання лишаються на місці." % _why_pay))

    # ⭐⭐⭐ ВОРОТА 2 «ХТО ЗАПУСКАЄ» (крок 1.5 Task Desk, 06.08.2026).
    # Стоять ПЕРШОЮ дією єдиної точки запуску: усі чотири канали (консоль,
    # ланцюги, телеграм, розклад) проходять саме тут. Актор — обовʼязковий
    # аргумент без значення за замовчуванням, тому канал, який його не передасть,
    # ламається голосно, а не працює тихо «від нікого».
    import taskdesk_identity as _tdid
    _may, _why_no = _tdid.may_run_system(actor, (system or {}).get("id") or "")
    if not _may:
        _emit(emit, "⛔ Немає права запускати цю систему")
        return honest_stop_result(
            system, kind="access_denied", reason=_why_no,
            action=("увійдіть під своїм працівником або попросіть адміністратора "
                    "відкрити доступ до цієї системи в розділі «Доступи»"),
            markdown=("## Роботу не запущено: немає права\n\n%s\n\n"
                      "Платформа не виконує роботу від нікого — інакше за результат "
                      "не відповідає ніхто, а платить власник." % _why_no))

    # ⭐⭐⭐ ВОРОТА 3 «ЧИ ТУ СИСТЕМУ ВЗЯЛИ» (25.08.2026, зміна 217, запобіжник №2).
    # Тут ворота ЗАПАСНІ. Маршрут переписує мозок — він єдиний, хто його й обирає,
    # і робить це ДО воріт прав, щоб право перевірялось для тієї системи, яка
    # справді побіжить. Але канали БЕЗ мозку (розклад, ланцюг, телеграм) сюди
    # приходять із системою, яку людина налаштувала заздалегідь: її вибір правило
    # НЕ переписує — лише КАЖЕ, що бачить у задачі тверду ознаку.
    #
    # ⚠ ХТО ВЖЕ ВИРІШИВ — ТОЙ І ПЕРЕДАВ. Якщо рішення приїхало готовим, тут не
    # вирішуємо вдруге і не повторюємо рядок: мозок бачить запит людини, а ми —
    # лише задачу, тобто входи РІЗНІ. Саме на цьому класі ми вже горіли 11.08.
    try:
        import route_claim as _rcl
        if not _rcl.is_decision(route_claim):
            _rd = _rcl.decide(system, task or "", origin="")
            _rcl.trace(_rd, system, actor=str(actor or ""), origin="")
            if _rd.get("line"):
                _emit(emit, _rd["line"])
    except Exception as _e:
        llm._log("[executor] претензія маршруту не спрацювала: %s" % _e)

    if allow_real_build and (system or {}).get("id") == "system_builder":
        return _build_for_real(actor, system, task, files_context, history, emit, style,
                               depth, should_cancel, original=original)

    convo = _convo(history)

    # КОНТРАКТ НАМІРУ (від мозку) + ПАСПОРТ РОЛЕЙ (від системи). Інструмент кроку
    # вмикається лише на перетині: роль вміє І контракт вимагає. Keyword-вгадувачок
    # більше немає — див. DESIGN_Контракт_наміру.md (10.07.2026).
    _raw_intent = intent if isinstance(intent, dict) else {}
    intent = _norm_intent(intent)
    # ⭐⭐⭐ 11.08.2026 (зміна 152, крок 4). ОДИН ПИСАР РОЗУМІННЯ.
    # Тут жив власний запасний шлях галузі («не оголошено — візьми з паспорта»).
    # Коли той самий порядок сили знадобився ще й картці розуміння, ми мали б ДВОХ
    # писарів однієї правди — клас, який уже коштував нам двічі (межа URL — чотири
    # місця, межа блока — два регекси). Тепер порядок сили живе в `understanding.resolve`,
    # і це НАЙНИЖЧА точка: через неї проходить КОЖЕН запуск системи — і з чату,
    # і з телеграма, і з розкладу, і з ланцюга.
    # ⭐⭐⭐ 11.08.2026 (зміна 153). ХТО ВЖЕ ВИРІШИВ — ТОЙ І ПЕРЕДАЄ; МИ НЕ
    # ПЕРЕВИРІШУЄМО. Живий прогін показав: ворота складали контракт ІЗ поправкою
    # людини, а тут він складався ЗАНОВО без неї — і тверда очевидність у тексті
    # (номер `UA-…`) мовчки била виправлену людиною галузь. Порядок сили був
    # один, а входи різні: це та сама хвороба «два писарі однієї правди», лише
    # захована в тому, що обидва кличуть ОДНОГО писаря з РІЗНИМИ даними.
    _contract = None
    try:
        import understanding as _und
        if _und.is_contract(understanding):
            _contract = dict(understanding)
        else:
            _contract = _und.resolve(system, _raw_intent, blob=(task or ""))
        intent["domain"] = _contract["domain"]
        intent["jurisdiction"] = _contract["jurisdiction"]
        # СЛІД ЛИШАЄТЬСЯ ЗАВЖДИ — й там, де картки ніхто не бачив (правило 5 задуму:
        # де є людина — питаємо, де немає — пишемо).
        _und.trace("run", system, _contract, actor=str(actor or ""))
    except Exception as _e:
        llm._log("[executor] писар розуміння не спрацював: %s" % _e)
    llm._log("[executor] контракт наміру: галузь=%s (%s%s) юрисдикція=%s"
             % (intent.get("domain"),
                (_contract or {}).get("domain_source") or "?",
                ", готовий" if (_contract is not None and understanding is not None
                                and _contract.get("domain_source")
                                == (understanding or {}).get("domain_source")) else "",
                intent.get("jurisdiction")))
    roles = registry.get_roles(system)

    # ⭐⭐⭐ ВОРОТА 3 «ЧИ Є ВХІД, ЯКОГО СИСТЕМА ВИМАГАЄ» (12.08.2026, зміна 162).
    # Паспорт ролей може вимагати входу до чужого сервісу (пошта, календар).
    # Немає конектора — роботи немає, і ми кажемо це ПРЯМО, а не гуглимо замість
    # читати листи. Стоять у ЄДИНІЙ точці запуску, тому їх проходять усі чотири
    # канали (консоль, ланцюги, телеграм, розклад) — той самий урок, що й з
    # воротами ліцензії: ворота лише на першому вході обходяться рештою трьох.
    # ⛒ І стоять ДО ВИТРАТ: осмислення системи (перші гроші) ще не починалось.
    # ⛒ І читають ТОЙ САМИЙ паспорт, що вже прочитано рядком вище — другого
    #   виклику `get_roles` немає: зайвий виклик посунув мітку чужого чека
    #   (`understanding_card_test`), і той чек мав рацію.
    _need_missing = registry.missing_inputs(registry.roles_needs(roles))
    if _need_missing:
        _ref = registry.input_refusal(_need_missing, (system or {}).get("name") or "")
        _emit(emit, "⛔ Немає входу: " + ", ".join(_ref["missing"]))
        return honest_stop_result(
            system, kind="missing_input", reason=_ref["reason"],
            action=_ref["action"], markdown=_ref["markdown"])

    # 1) ОСМИСЛЕННЯ
    _emit(emit, "🧠 Осмислюю логіку системи…")
    plan = comprehend_system(system)
    _emit(emit, f"🧩 План готовий: {len(plan.get('pipeline', []))} етап(ів)")

    needs_calc = (not meta_mode) and intent["computation"] == "required"
    fresh_required = (not meta_mode) and intent["fresh_data"] == "required"
    wants_model = (not meta_mode) and intent["output"] == "financial_model"
    _raw_out = (_raw_intent or {}).get("output") if isinstance(_raw_intent, dict) else None
    _out_label = {"chat_answer": "відповідь", "document": "документ",
                  "estimate_sheet": "таблиця-оцінка", "financial_model": "фінмодель",
                  "report": "звіт"}.get(intent["output"], intent["output"])
    if not meta_mode:
        _emit(emit, f"📋 Намір: свіжі дані {'✓' if fresh_required else '✗'}, "
                    f"розрахунок {'✓' if needs_calc else '✗'}, результат: {_out_label}")
        # ⛒ ПОСИЛЕННЯ НАМІРУ НЕ ВІДБУВАЄТЬСЯ МОВЧКИ (зміна 253): людина мусить
        # бачити, що платформа взяла суворіше за те, що оголосив мозок.
        if wants_model and _raw_out in ("report", "estimate_sheet"):
            _emit(emit, "🧮 Замовлено розрахунок — отже числа мусять бути ЖИВИМИ: "
                        "роблю модель з формулами, а не таблицю з готовими числами.")

    # ⭐⭐⭐ 05.08.2026. ВОРОТА ТЕНДЕРАЙТЕРА №1 — ДО ВИТРАТ.
    # Пакет документів для подачі мусить спиратися на оголошення замовника.
    # Немає документів у матеріалах — роботи немає: саме так 05.08 клієнт отримав
    # «шаблони з голови» від системи, яка не бачила жодного паперу замовника.
    # ⭐⭐⭐ 11.08.2026, зміна 153, клас B задуму «Сенс замість тригерів».
    # ПРО ЩО ПЕРЕЛІК У ЧУЖОМУ ДОКУМЕНТІ — судить МОДЕЛЬ на компактному зрізі
    # (самі заголовки), а не наш перелік слів. Судимо РАЗ, ще ДО воріт витрат, і
    # той самий вердикт протягуємо в усе, що читає перелік: ворота, які бачать
    # менше за складання, зачинили б двері перед клієнтом, у документах якого
    # вимоги Є — просто названі не нашими словами.
    _topics, _topics_of = {"ok": False, "verdicts": {}}, None
    if (system or {}).get("id") == tender_pack.SYSTEM_ID and tender_pack.enabled():
        _topics_of = ((files_context or "") + "\n\n" + (task or "")).strip()
        try:
            _topics = tender_pack.head_topics(_topics_of)
            llm._log("[executor] тема переліків: суддя=%s, названо %d із %d "
                     "(охоплення %s)"
                     % ("так" if _topics.get("ok") else "ні",
                        len(_topics.get("verdicts") or {}),
                        len(_topics.get("asked") or ()),
                        "є" if _topics.get("covered") else "немає"))
        except Exception as _e:
            llm._log("[executor] тема переліків не судилась: %s" % _e)
        # ⭐⭐⭐ 10.08.2026. ВОРОТА ДИВЛЯТЬСЯ І В ЗАДАЧУ, А НЕ ЛИШЕ В МАТЕРІАЛИ.
        # Раніше вони судили наявність СВОЄЇ наліпки в `files_context`, а у відмові
        # писали «у задачі не названо номер закупівлі» — не прочитавши задачі.
        # Тепер суддя один (`docs_available`), він бачить обидва джерела і кожну
        # відмову називає своїм імʼям.
        _tp = tender_pack.docs_available(files_context or "", task or "", topics=_topics)
        if not _tp.get("ok"):
            _emit(emit, "⛔ Немає з чого збирати пакет — %s" % (_tp.get("reason") or "")[:90])
            return honest_stop_result(
                system, kind="tender_pack_no_docs", reason=_tp.get("reason", ""),
                action=("дайте платформі оголошення будь-яким із трьох способів: номер "
                        "закупівлі (UA-…) чи посилання в задачі · файл оголошення "
                        "прикріпленням · текст вимог замовника прямо в задачі"),
                markdown=tender_pack.stop_text(_tp.get("reason", "")), intent=intent)
        else:
            _emit(emit, "📑 Документи закупівлі є (%s) — вимог у полі зору: %d"
                        % ({"platform": "взяла платформа",
                            "material": "підклали ви"}.get(_tp.get("origin"), "?"),
                           _tp.get("items", 0)))
        # ⭐⭐⭐ 17.08.2026, зміна 194. ВОРОТА ТЕНДЕРАЙТЕРА №0 — «ЧИ ЩЕ МОЖНА
        # ПОДАТИСЬ». Стоять ДО ВИТРАТ і ПЕРЕД усіма іншими: найдорожча втрата —
        # не зайва позиція в пакеті, а день роботи над пакетом, який нікуди
        # подавати. 🩸 17.08 платформа зібрала повний пакет на закупівлю зі
        # строком подання 15.08 і протоколом відміни в картці — і промовчала.
        # ⛒ Рішення «збирати попри це» ухвалює ЛЮДИНА, і платформа сама пише їй,
        # якою фразою це сказати. Межа знання (картки не дістали) вироком не стає.
        _adm_state = {}
        try:
            _adm_tid = (tender_pack.tender_id_in(task or "")
                        or tender_pack.tender_id_in(files_context or ""))
            _adm_state = tender_pack.tender_state(_adm_tid)
            llm._log("[executor] стан закупівлі: %s строк=%s лишилось=%s відміна=%s "
                     "закрита=%s"
                     % (_adm_state.get("tender_id") or "—",
                        _adm_state.get("deadline") or "—",
                        _adm_state.get("days_left"),
                        _adm_state.get("cancelled") or "немає",
                        _adm_state.get("closed")))
        except Exception as _e:
            llm._log("[executor] стан закупівлі не спитали: %s" % _e)
        if _adm_state.get("closed") and not tender_pack.override_in(
                _human_words(task, original)):
            _emit(emit, "⛔ Подати пропозицію вже не можна — %s"
                        % (_adm_state.get("why") or ""))
            return honest_stop_result(
                system, kind="tender_closed", reason=_adm_state.get("why", ""),
                action=("перевірте оголошення на Прозорро; якщо пакет потрібен як "
                        "заготовка — так і напишіть у задачі"),
                markdown=tender_pack.closed_stop_text(_adm_state), intent=intent)

    # 2) УТОЧНЕННЯ
    _gate_degraded = ""
    _blank_questions = []
    if precheck:
        _emit(emit, "❓ Перевіряю, чи достатньо вхідних даних…")
        gate = precheck_inputs(system, plan, task, files_context, history,
                               needs_calc=needs_calc)
        # ⛔ 30.07.2026. Крок 9 закону (питати, доки не досить) не може відбутися,
        # якщо перевірка достатності НЕ ВИКОНАЛАСЬ. Раніше такий збій мовчки
        # ставав «даних вистачає» — і система бралася робити наосліп.
        if not gate.get("checked", True):
            _why = gate.get("error")
            if isinstance(_why, Exception) and failure.is_budget(_why):
                # Межа вартості — не аварія і не стоп: у неї свій шлях.
                return {"status": "runtime_error",
                        "final_markdown": failure.client_text(_why, "executor/precheck"),
                        "failure": "budget", "client_safe": True,
                        "agent_trace": [], "system_id": system.get("id")}
            # ⭐⭐⭐ 11.08.2026 (зміна 154). АВАРІЯ МУСИТЬ НАЗИВАТИ ВИННОГО.
            # Тут у журнал ішов ЛИШЕ КЛАС («auth») — і причину неможливо було
            # знайти без нового ПЛАТНОГО прогону: чи ключ відхилено, чи модель
            # знято, чи кредити скінчились, чи проєкт не має доступу. Клієнту й
            # далі йде людський текст без подробиць, а в ЖУРНАЛ тепер лягає
            # повний слід — його читаю я, і він коштує $0.
            if isinstance(_why, Exception):
                failure.log(_why, "executor/precheck")
            _reason = ("не вдалося перевірити, чи вистачає вхідних даних: %s"
                       % (_why if isinstance(_why, str) else failure.classify(_why)))
            if _gate_must_be_strict(system, intent):
                _emit(emit, "🛑 Не можу перевірити, чи вистачає вхідних даних — "
                            "зупиняюсь чесно, а не берусь наосліп.")
                llm._log("[executor] precheck НЕ виконано (%s) — чесний стоп" % _reason)
                return honest_stop_result(
                    system, kind="precheck_impossible", reason=_reason,
                    action=("повтори запит за хвилину; якщо повторюється — перевір ключ і "
                            "доступність моделі виконавця в налаштуваннях"),
                    markdown=(
                        "## Не можу почати: не вдалося перевірити, чи вистачає даних\n\n"
                        "Перед запуском система звіряє, чи є все потрібне для якісного "
                        f"результату. Цю перевірку зараз виконати не вдалося ({_reason}).\n\n"
                        "Щоб не вводити тебе в оману, я НЕ берусь робити наосліп: раніше в "
                        "такій ситуації платформа вирішувала, що «даних вистачає», і видавала "
                        "результат, побудований на припущеннях.\n\n"
                        "**Що можна зробити:**\n\n"
                        "- повтори запит за хвилину — збій міг бути тимчасовим;\n"
                        "- якщо повторюється — перевір ключ і доступність моделі виконавця "
                        "в налаштуваннях.\n"),
                    intent=intent, plan=plan)
            # Не суворо — ЗБІЙ ПЕРЕВІРКИ НЕ МАЄ ПРАВА ЗАБИРАТИ В КЛІЄНТА РОБОТУ.
            _gate_degraded = _reason
            _emit(emit, "⚠ Перевірку достатності даних виконати не вдалось — "
                        "працюю з тим, що є, і чесно напишу про це в результаті.")
            llm._log("[executor] precheck НЕ виконано (%s) — працюю далі із застереженням" % _reason)
            audit.log_refusal("gate_degraded", system.get("id"), [], _reason)
        if (not _gate_degraded) and (not gate.get("ready")):
            # ПИТАННЯ ВИДНО ЛЮДИНІ І ЛИШАЄ СЛІД. Раніше вони доїжджали ЛИШЕ
            # рядком-інструкцією мозку: якщо мозок їх переказував по-своєму або
            # ковтав — уточнення зникало без сліду.
            for _q in gate["questions"]:
                _emit(emit, "❓ Потрібне уточнення: %s" % _q)
            llm._log("[executor] needs_input (%s): %s"
                     % (system.get("id"), " | ".join(gate["questions"])))
            # ⭐⭐⭐ 05.08.2026. ПИТАННЯ, ЯКЕ НЕ МУСИТЬ ЗУПИНЯТИ РОБОТУ.
            # Є системи, чий артефакт існує з порожніми графами (тендерний пакет —
            # це бланки). Для них зупинка з питанням коштувала клієнту подвійної
            # оплати: план і читання документів робились удруге після відповіді.
            # Тепер питання не вбиває прогін — воно стає рядком у результаті.
            if tender_pack.blanks_ok(system.get("id")):
                _blank_questions = list(gate["questions"])
                _emit(emit, "📝 Бракує даних учасника — не зупиняюсь: винесу їх "
                            "у «заповнити перед подачею»")
                llm._log("[executor] питання не блокують (%s): %d шт."
                         % (system.get("id"), len(_blank_questions)))
            else:
                return {"status": "needs_input", "questions": gate["questions"],
                        "system_id": system.get("id"), "agent_trace": [],
                        "understanding": plan.get("system_understanding", "")}

    pipeline = plan["pipeline"]
    trace = []
    # Правова задача має власну (вищу) стелю — визначає ПАСПОРТ системи.
    _legal_mode = _is_legal_system(system)
    # ⭐ 30.07.2026. РЕЖИМ ПРОЦЕДУРИ РЕЗОЛВИМО ОДИН РАЗ — ДО конвеєра, а не лише
    # на воротах виходу. Раніше режим знало тільки ядро на виході: агент його не
    # бачив, вигадував свій («відкриті торги з особливостями» замість спрощеної)
    # і будував на ньому весь перелік документів. Тепер та сама позиція їде
    # агенту як ФАКТ і вона ж (без другої резолюції) працює на воротах.
    legal_pos = None
    _legal_note = ""
    if _legal_mode and _legal_jurisdiction(task, intent) == "UA":
        legal_pos = _resolve_legal_pos(task, history)
        _legal_note = _legal_regime_block(legal_pos)
        _brief = (legal_pos or {}).get("brief") or {}
        if _brief.get("ok"):
            _emit(emit, "⚖ Режим процедури встановлено ядром: %s — агенти працюють "
                        "саме за ним." % ((_brief.get("pos") or {}).get("label") or "—"))
    _cap = _run_cap(meta_mode, _legal_mode)
    accumulated = ""
    all_sources = []
    # ⏸ ПРОДОВЖЕННЯ ПІСЛЯ ПАУЗИ ЗА ВАРТІСТЮ (28.07.2026). Клієнт уже оплатив
    # напрацьоване — тому воно повертається на місце, а не рахується заново.
    _start_idx = 1
    if resume:
        plan = resume.get("plan") or plan
        pipeline = plan.get("pipeline") or pipeline
        trace = list(resume.get("trace") or [])
        accumulated = resume.get("accumulated") or ""
        all_sources = list(resume.get("all_sources") or [])
        _start_idx = int(resume.get("next_idx") or 1)
        if resume.get("choice") == "assemble":
            _start_idx = len(pipeline) + 1      # нових кроків не робимо взагалі
        if resume.get("new_cap"):
            _cap = float(resume["new_cap"])
        _emit(emit, "⏸ Продовжую з місця зупинки — уже зроблене не переробляю "
                    "і вдруге не рахую.")
    # Стеля їде вниз, до самого лічильника грошей: мʼяка зупинка нижче тримає
    # НОВІ кроки, а costs/llm не дають одному кроку втекти в космос (28.07.2026).
    try:
        costs.set_run_cap(_cap)
    except Exception:
        pass
    web_gaps = []   # зриви живої звірки на ролях web="always" (інваріант, не побажання)
    # ⭐ 10.08.2026: усе, що платформа СПРАВДІ прочитала в цьому прогоні (корпус
    # для запобіжника брехні `fact_trust`). Заголовків джерел тут НЕ достатньо —
    # судити факт можна лише проти ТЕКСТУ, який реально бачили.
    _live_corpus = []
    # Кому дістаються інструменти (перетин контракту з паспортом; паспорт існує
    # ЗАВЖДИ — get_roles сіє на льоту, тому порожні tools = СВІДОМА декларація):
    # • калькулятор — ролям із tools.calculator; якщо жодна роль його не декларує,
    #   а контракт вимагає — всім, крім критика (інакше добірка needs_capability
    #   не мала б ефекту в командах без рахувальника);
    # • веб — СТРОГО задекларованим ролям: "always" (інваріант, напр. юр-звіряч
    #   норм) або "per_intent" (лише коли контракт вимагає свіжих даних). БЕЗ
    #   fallback: роль без web не шукає ніколи (вбиває клас «веб на Будівнику»).
    #   Підказка планувальника needs_web_search — лише РОЗМІЩЕННЯ, не ворота.
    # ⭐⭐⭐ 09.08.2026. ВОРОТА НА ПЛАНI: ПОШУКОВА РОЛЬ НЕ СМIЄ ЗАГУБИТИСЬ.
    # 🩸 ЖИВИЙ ПРОВАЛ: рекрутингова видала двох кандидатiв iз вигаданими адресами
    # work.ua/resumes/40123456 i /40234567. Ворота вебу стояли на РОЛI — але мозок
    # склав план БЕЗ ролi AgentSearching, тобто охоронця поставили до дверей, у якi
    # нiхто не заходив. Модель домалювала данi з голови.
    # ⭐ ЗДАТНIСТЬ, ЯКОЇ НЕМАЄ В ПЛАНI, ДЛЯ ПРОГОНУ НЕ IСНУЄ.
    # РIШЕННЯ (без вгадування «чи треба шукати»): якщо система МАЄ пошукову роль,
    # а план її не взяв — право вийти в мережу дiстає ПЕРШИЙ дослiдницький крок
    # плану (а як таких немає — перший крок узагалi). Вартiсть та сама: web_done
    # тримає РIВНО ОДИН веб-крок на прогiн.
    _web_roles = {a for a, r in (roles or {}).items()
                  if ((r or {}).get("tools") or {}).get("web")}
    _plan_has_web = any((st.get("agent") or "") in _web_roles for st in pipeline)
    _web_orphan_idx = None
    if _web_roles and not _plan_has_web and pipeline:
        _web_orphan_idx = 0
        for _i, _st in enumerate(pipeline):
            _k = ((roles or {}).get(_st.get("agent") or "") or {}).get("kind")
            if _k == "research":
                _web_orphan_idx = _i
                break
        import sys as _wo
        _wo.stderr.write("[web] PLAN HAS NO SEARCH ROLE (system can search: %s) - "
                         "web right granted to step %d (%s)\n"
                         % (", ".join(sorted(_web_roles)), _web_orphan_idx + 1,
                            (pipeline[_web_orphan_idx] or {}).get("agent")))

    calc_agents = {s.get("agent", "") for s in pipeline
                   if _role_tools(roles, s.get("agent", "")).get("calculator")}
    web_done = False
    if needs_calc:
        _emit(emit, "🧮 Числова задача: розрахунки виконуються калькулятором, не «в умі»")
    route_diag = None   # діагностика маршрутного двигуна → у run.json (гучний фейл, не тиша)
    cond_diag = None    # слід живого веб-пошуку УМОВ (обмеження в'їзду) → у run.json
    seo_page, seo_facts, seo_diag = (("", None, None) if meta_mode
                                     else _seo_page_block(system, task, roles))
    # ЧЕСНИЙ СТОП SEO замість ФАНТАЗІЇ (дзеркало маршрутного стопу нижче): якщо це
    # SEO-задача, але сторінку НЕ прочитано впевнено (редірект на іншу / недоступна /
    # порожня JS-оболонка) — НЕ запускаємо агентів і НЕ домальовуємо аудит «з голови».
    if seo_diag is not None and not seo_diag.get("read_ok"):
        _reason = seo_diag.get("reason") or "сторінку не вдалося прочитати"
        _emit(emit, "🛑 Сторінку не прочитано впевнено — віддаю чесний стоп, а не аудит з голови.")
        honest_md = (
            "## Не можу зробити SEO-аудит: сторінку не прочитано\n\n"
            f"Я не зміг впевнено відкрити саме ту сторінку, яку ти дав. **Причина:** {_reason}.\n\n"
            "Щоб не вводити тебе в оману, я НЕ роблю аудит «з голови» — без реального вмісту "
            "сторінки будь-які висновки про заголовки, тексти, schema чи мета-теги були б "
            "вигадані.\n\n"
            "**Що можна зробити:**\n\n"
            "- перевір, чи адреса відкриває саме потрібну сторінку (не share-лінк і не "
            "перенаправлення на головну/вхід);\n"
            "- якщо сторінка під паролем або рендериться через JavaScript — дай прямий "
            "доступ чи сам HTML сторінки;\n"
            "- або повтори запит трохи згодом, якщо збій був тимчасовий.\n"
        )
        return honest_stop_result(
            system, kind="seo_page_unread", reason=_reason,
            action=("перевір адресу сторінки (без редіректів і share-лінків), дай прямий "
                    "доступ або сам HTML — і повтори запит"),
            markdown=honest_md, intent=intent, plan=plan,
            seo_read=seo_diag)     # слід дії у run.json (анти-«обман»)
    if seo_page:
        _emit(emit, "🔗 Читаю реальну сторінку структуровано (title/meta/H/schema/alt)…")
        # ⭐⭐⭐ 12.08.2026 (зміна 168), ЖИВИЙ ВИПАДОК. СТОРІНКА, ПРОЧИТАНА БУДЬ-ЯКИМ
        # ШЛЯХОМ, — ЦЕ ДЖЕРЕЛО. Реєстр справжніх джерел (`all_sources`) наповнював лише
        # шлях ВЕБ-ПОШУКУ. Сторінку, яку людина НАЗВАЛА в задачі, читає інший шлях —
        # структурований витяг — і він у реєстр не клав НІЧОГО. Тому ворота проти
        # вигаданих посилань вважали власну, чесно прочитану сторінку вигадкою і
        # ЗАМАЗУВАЛИ її адресу в документі клієнта («[адресу приховано…]» у заголовку
        # і в розділі «Джерела» звіту SEO/GEO). Це ТРЕТІЙ випадок класу «правило живе
        # в одному шляху»: рівно цей урок уже вивчено 09.08 для сторінок із пошуку.
        _read_url = (seo_diag or {}).get("final_url") or (seo_diag or {}).get("url") or ""
        if _read_url and not any((x or {}).get("url") == _read_url for x in all_sources):
            all_sources.append({"title": "прочитана сторінка", "url": _read_url})
        # Той самий слот фактів: доклад реальну ШВИДКІСТЬ (Google PageSpeed), щоб поради
        # про швидкість/CWV спиралися на вимір, а не на здогад «якщо видно з коду».
        _speed, _speed_diag = (_speed_block(seo_diag)
                               if (seo_diag or {}).get("role_page_read") else ("", None))
        if _speed:
            seo_page = seo_page + "\n\n" + _speed
            _emit(emit, "⚡ Виміряв реальну швидкість сторінки (Google PageSpeed).")
        elif _speed_diag and not _speed_diag.get("ok"):
            _emit(emit, "⚡ Швидкість не виміряно (PageSpeed недоступний) — "
                        "стратег напише «не виміряно», не вигадає цифр.")
        if isinstance(seo_diag, dict):
            seo_diag["speed"] = _speed_diag
    elif not meta_mode:
        # Той самий слот інжекту реальних даних, інша система: маршрутний двигун
        # підкладає РЕАЛЬНИЙ шлях (замість «пригадування» моделлю).
        _rb, route_diag = _route_block(system, task)
        if _rb:
            seo_page = _rb
            _res = (route_diag or {}).get("result") or {}
            if _res.get("ok"):
                _h = int(_res.get("duration_h") or 0)
                _m = round(((_res.get("duration_h") or 0) - _h) * 60)
                _emit(emit, f"🗺 Двигун побудував РЕАЛЬНИЙ маршрут (Google): "
                            f"{_res.get('distance_km', '?')} км, ~{_h} год {_m} хв.")
            else:
                _emit(emit, f"⚠ Маршрутний двигун НЕ побудував маршрут: "
                            f"{(route_diag or {}).get('reason', 'причина невідома')}. "
                            "Маршрут із памʼяті НЕ вигадую — у звіті буде чесна позначка.")
        elif route_diag is not None:
            # Система маршрутів, але розбір не виділив звідки/куди — теж голосно, не мовчки.
            _emit(emit, f"⚠ Маршрутний двигун не запускався: "
                        f"{(route_diag or {}).get('reason', 'не розпізнано звідки/куди')}. "
                        "З памʼяті маршрут НЕ вигадую.")

    # ⛒⛒⛒ 577. НОРМАТИВИ — ТЕЖ ФАКТ, А НЕ ПАМʼЯТЬ. Агент має перед очима повний
    # перелік того, що взагалі можна назвати нормативом методики. 🩸 Без нього
    # 12.09.2026 у документ пішла витрата 35 л/100 км «за нормативом» (у методиці
    # 32) і добові 250 замість 500 — методика лежала поруч, але ніщо не заважало
    # написати своє число під її підписом.
    if not meta_mode:
        try:
            _norm_root = registry.system_root(system)
            if norms.values(_norm_root):
                _nb = norms.block(_norm_root)
                seo_page = (seo_page + "\n\n" + _nb) if seo_page else _nb
        except Exception as _ex:
            import sys as _sn
            _sn.stderr.write("[norms] перелік нормативів не підкладено: %s\n" % _ex)

    # ⛒⛒⛒ 581. КЛАС МАШИНИ — ТЕЖ ФАКТ, А НЕ ВИБІР АГЕНТА. Перелік нормативів
    # 577 дає агентові ВСІ класи; далі він сам вирішував, який із них його, — і
    # 🩸 12.09.2026 вирішив так, що в документ пішли 35 л/100 км, яких у
    # методиці немає взагалі, а «Газель, 5 тонн» поїхала середнім класом без
    # жодного слова замовникові. Тут клас уже визначено кодом за таблицею
    # методики й УЖЕ ПОКАЗАНО людині в картці розуміння. Агентові він приходить
    # готовим фактом разом із нормативами саме цього класу; брати чужий
    # заборонено. Ті самі числа потім судить сторож 579.
    if not meta_mode:
        try:
            _asb = assumed.block_for(registry.system_root(system), task or "",
                                     _contract)
            if _asb:
                seo_page = (seo_page + "\n\n" + _asb) if seo_page else _asb
        except Exception as _ea:
            import sys as _sa5
            _sa5.stderr.write("[assumed] клас машини не підкладено: %s\n" % _ea)

    # ЧЕСНИЙ СТОП замість ФАНТАЗІЇ. Для системи маршрутів: якщо РЕАЛЬНОГО шляху немає
    # (двигун недоступний / розбір без звідки-куди) — НЕ віддаємо вигаданий звіт. Раніше
    # фінальний збирач домальовував маршрут «з памʼяті» під позначками [ОЦІНКА] — чесні
    # мітки, брехливий зміст. Тут ми зупиняємось коротким чесним поясненням. ВИНЯТОК:
    # не-дорожній спосіб (авіа/потяг/автобус) — це НЕ збій двигуна, там далі веб-пошук.
    if route_diag is not None:
        _rres = route_diag.get("result")
        _is_non_road = isinstance(_rres, dict) and _rres.get("mode") == "non_road"
        _route_built = isinstance(_rres, dict) and _rres.get("ok")
        # ⭐⭐⭐ 09.08.2026. НЕ КОЖНА ЗАДАЧА ЦIЄЇ СИСТЕМИ — ПРО ПОБУДОВУ МАРШРУТУ.
        # Живий випадок: «знайди кафе на вiдтинку М-03 мiж Решетилiвкою та
        # Лубнами, таблиця Назва|Адреса|Години» — маршрут тут НЕ потрiбен, потрiбен
        # веб-пошук. Розбiрник вiддав порожнi start/end (його питають «звiдки
        # ВИЇЗД i куди ЇДЕШ»), i повний стоп убив роботу, яку легко зробити.
        # Стоп лишається там, де вiн має сенс: маршрут ЗАМОВЛЕНО (є звiдки/куди),
        # але двигун його не дав. Немає звiдки/куди — це не маршрутна задача.
        # ⭐⭐⭐ 10.08.2026, ДВІ ПОМИЛКИ В ЦЬОМУ ОДНОМУ РЯДКУ.
        # 1) АВАРІЯ. `dict.get("parsed", {})` віддає None, коли ключ Є, але його
        #    значення None — а `_route_block` віддає саме таке, коли розбірник
        #    упав (немає провайдера / LLMError). Далі `.get("start")` на None
        #    валив увесь прогін через AttributeError. Живі прогони з
        #    `"parsed": null` на диску є (20.07.2026, два підряд).
        # 2) НЮХАЧКА ЗАМІСТЬ ДЕКЛАРАЦІЇ. «Чи замовлено маршрут» вгадувалось із
        #    того, чи розбірник виділив звідки/куди — тобто по тексту. Тепер
        #    першим питаємо КОНТРАКТ НАМІРУ, а розбір лишається другою опорою
        #    (щоб стара поведінка справжніх маршрутних задач не змінилась).
        _parsed = (route_diag or {}).get("parsed")
        _parsed = _parsed if isinstance(_parsed, dict) else {}
        _route_asked = ((intent or {}).get("route") == "required"
                        or bool((_parsed.get("start") or "").strip()
                                or (_parsed.get("end") or "").strip()))
        if (not _route_built) and (not _is_non_road) and _route_asked:
            _reason = route_diag.get("reason") or "маршрутний двигун недоступний"
            _emit(emit, "🛑 Реального маршруту немає — віддаю чесний стоп, а не вигаданий звіт.")
            honest_md = (
                "## Не можу побудувати реальний маршрут\n\n"
                f"Маршрутний двигун зараз не дав реального шляху. **Причина:** {_reason}.\n\n"
                "Щоб не вводити тебе в оману, я НЕ малюю маршрут, відстані, час і точки "
                "зупинок «з памʼяті» — вони були б вигадані. Реальні дані (траса, кілометри, "
                "час, АЗС і заклади за рейтингом) можна дати лише зі справжнього "
                "картографічного джерела.\n\n"
                "**Що можна зробити:**\n\n"
                "- повторити запит трохи згодом, якщо збій був тимчасовий;\n"
                "- або підключити надійне джерело маршрутів — тоді звіт будуватиметься "
                "з реальних даних, а не з припущень.\n"
            )
            return honest_stop_result(
                system, kind="route_not_built", reason=_reason,
                action=("повтори запит трохи згодом (якщо збій тимчасовий) або підключи "
                        "надійне джерело маршрутів — тоді звіт будується з реальних даних"),
                markdown=honest_md, intent=intent, plan=plan,
                route_engine=route_diag)

    # ЖИВІ УМОВИ: маршрут побудовано — якщо запит просить обмеження/дорожню обстановку,
    # платформа САМА робить ОДИН живий веб-пошук і підкладає реальні умови+джерела як факт
    # (той самий слот, що маршрут/зупинки). Слід дії (checked/used_search/sources) → run.json.
    if route_diag is not None:
        _cb, cond_diag = _conditions_block(system, task, route_diag)
        if _cb:
            seo_page = (seo_page + "\n" + _cb) if seo_page else _cb
            if (cond_diag or {}).get("sources"):
                _emit(emit, f"🚧 Живі умови перевірено веб-пошуком: {cond_diag['sources']} джерел.")
            else:
                _emit(emit, "🚧 Живі умови: веб актуальних даних не дав — у звіті буде "
                            "чесне «не перевірено», не «обмежень нема».")

    if meta_mode:
        _emit(emit, "🧱 Мета-режим Будівника: без веб-пошуку, калькулятора й фінальної збірки.")

    # 3) ВИКОНАННЯ ЗА ПЛАНОМ
    for idx, step in enumerate(pipeline, 1):
        if should_cancel and should_cancel():
            _emit(emit, "⏹ Зупинено на ваш запит.")
            return {"status": "cancelled", "final_markdown": "", "agent_trace": trace,
                    "system_id": system.get("id")}
        if idx < _start_idx:
            continue                      # цей етап уже оплачений і зроблений
        if _over_cap(_cap):
            # ⏸ НЕ обриваємо і НЕ витрачаємо більше. Ставимо на паузу, зберігаємо
            # напрацьоване й даємо КЛІЄНТУ вибір (вимога Андрія 28.07.2026).
            _spent = float(costs.current_run().get("usd", 0.0))
            _left = [s.get("agent", "") for s in pipeline[idx - 1:]]
            _rid = ""
            try:
                import run_state as _rs
                _rid = _rs.save({"system_id": system.get("id"), "task": task,
                                 "plan": plan, "trace": trace,
                                 "accumulated": accumulated, "all_sources": all_sources,
                                 "next_idx": idx, "style": style, "depth": depth,
                                 "files_context": files_context, "intent": intent,
                                 "cap": _cap, "spent": _spent})
            except Exception as e:
                llm._log("[executor] пауза за вартістю не збереглась: %s" % e)
            _emit(emit, f"⏸ Досягнуто межу вартості (${_cap:.2f}). Роботу поставлено "
                        f"на паузу — далі нічого не витрачаю, чекаю на ваше рішення.")
            return {"status": "paused_budget", "final_markdown": "",
                    "agent_trace": trace, "system_id": system.get("id"),
                    "run_id": _rid, "spent_usd": round(_spent, 2), "cap_usd": _cap,
                    "done_steps": idx - 1, "total_steps": len(pipeline),
                    "left_agents": _left, "resumable": bool(_rid)}
        aid = step.get("agent", "")
        role_web = _role_tools(roles, aid).get("web")
        # ВОРОТА ВЕБУ = контракт × паспорт: "always" — завжди (інваріант ролі);
        # "per_intent" — лише якщо контракт вимагає свіжих даних. Розміщення кроку —
        # за підказкою плану, з гарантією першого web-здатного кроку.
        _step_web = False
        _web_ready = config.web_search_ready()
        if (not meta_mode) and _web_ready:
            _step_web = _step_web_allowed(role_web, fresh_required, step, web_done)
            # План загубив пошукову роль — право дiстає цей крок (див. ворота вище).
            if (not _step_web) and (_web_orphan_idx is not None) \
                    and (idx - 1) == _web_orphan_idx and not web_done:
                _step_web = True
        # ⭐⭐⭐ 09.08.2026. РIШЕННЯ ПРО ВЕБ БIЛЬШЕ НЕ ТИХЕ. Три прогони поспiль
        # поверталися без жодного пошуку, i в журналi не було НI СЛОВА про те, чому.
        # Тихе рiшення = невидимий дефект: я гадав замiсть того, щоб прочитати.
        import sys as _sw
        _sw.stderr.write("[web] step=%s role=%s passport=%r intent_fresh=%s already=%s "
                         "provider=%s -> %s\n"
                         % (idx, aid, role_web, fresh_required, web_done, _web_ready,
                            "SEARCH" if _step_web else "NO SEARCH"))
        if _step_web:
            web_done = True
            _emit(emit, f"🌐 {aid}: живий веб-пошук…")
        else:
            _emit(emit, f"▶ {aid} ({idx}/{len(pipeline)})…")
        # ІНВАРІАНТ ЖИВОЇ ЗВІРКИ (web="always", напр. юр-звіряч норм): збій пошуку
        # НЕ ковтається (юрист 10.07 ~23:40 — тиша в stderr): 1 повтор → гучне ⚠ →
        # прапорець web_gaps → межа видачі примусово ставить «непідтверджено».
        live_data, step_sources, _wfail = ("", [], "")
        if _step_web:
            live_data, step_sources, _wfail = _gather_live_data(task, step, system, force=True, intent=intent)
            if not live_data and role_web == "always":
                _emit(emit, f"🔁 {aid}: жива звірка не вдалася ({(_wfail or '?')[:100]}) — повторюю…")
                live_data, step_sources, _wfail = _gather_live_data(task, step, system, force=True, intent=intent)
            # ⭐⭐⭐ 10.08.2026. КОРПУС ПРОГОНУ — ТЕ, ЩО ПЛАТФОРМА СПРАВДІ ЧИТАЛА.
            # Досі прочитаний текст сторінок жив ЛИШЕ в межах кроку: до кінця
            # прогону доживали тільки заголовок і адреса джерела. Тому судити
            # «чи цей факт справді був у джерелі» було НІЧИМ — і вигадані назви,
            # адреси й години доїжджали до людини (живий провал 09.08.2026).
            if live_data:
                _live_corpus.append(live_data)
            if not live_data and role_web == "always":
                _emit(emit, f"⚠ {aid}: ЖИВА ЗВІРКА ДЖЕРЕЛ НЕ ВИКОНАНА "
                            f"({(_wfail or 'причина невідома')[:140]}) — результат буде "
                            "позначено непідтвердженим.")
                web_gaps.append(f"{aid}: {_wfail or 'причина невідома'}")
                # ⛒⛒⛒ 576. ПРОВАЛ ЗВІРКИ ДОХОДИТЬ ДО АГЕНТА, А НЕ ЛИШЕ В ШАПКУ
                # документа. Досі агент бачив просто відсутність живих даних — і
                # заповнював порожнечу памʼяттю, ставлячи зверху позначку «живий
                # пошук». Тепер порожнеча приходить як ФАКТ із прямою забороною.
                live_data = live_gap.block(aid, _wfail or "причина невідома")
        elif (not meta_mode) and role_web == "always":
            # Ворота вебу навіть не відкрились (пошук не налаштований/вимкнений) —
            # для інваріантної ролі (юрист-звіряч норм) це зрив звірки. ЧЕСНИЙ СТОП:
            # без живої звірки роль НЕ має права відповідати, інакше кодова модель
            # вивалює само-балаканину замість консультації (зрив 20.07.2026). Не
            # запускаємо модель у місиво — віддаємо коротке зрозуміле пояснення +
            # 10-секундний спосіб перевірити самому.
            _emit(emit, f"⚠ {aid}: жива звірка обовʼязкова для цієї ролі, але веб-пошук "
                        "недоступний — віддаю чесний стоп, а не відповідь із голови.")
            web_gaps.append(f"{aid}: веб-пошук недоступний (не налаштований або вимкнений)")
            honest_md = (
                "## Не можу дати відповідь без живої звірки джерел\n\n"
                f"Ця система зобовʼязана перед відповіддю звірити норми з офіційним "
                f"джерелом наживо (напр. zakon.rada.gov.ua). Зараз веб-пошук недоступний "
                f"для активних моделей, тому звірку виконати неможливо.\n\n"
                "Щоб не вводити тебе в оману, я НЕ відповідаю «з памʼяті»: без реальної "
                "звірки будь-які статті, ставки й строки були б здогадом, поданим як факт.\n\n"
                "**Як увімкнути (перевірка за 10 секунд):** запусти «Diag web conditions.bat» "
                "— має бути `web_search_ready: True`. Якщо `False` — додай ключ пошуко-здатного "
                "провайдера (Gemini/OpenAI/Claude) або признач окремий пошуковий провайдер "
                "(SEARCH_PROVIDER), і повтори запит."
            )
            return honest_stop_result(
                system, kind="live_check_impossible",
                reason=(f"{aid}: жива звірка джерел обовʼязкова для цієї ролі, "
                        "але веб-пошук недоступний (не налаштований або вимкнений)"),
                action=("запусти «Diag web conditions.bat» — має бути web_search_ready: True; "
                        "якщо False — додай ключ пошуко-здатного провайдера або признач "
                        "SEARCH_PROVIDER, і повтори запит"),
                markdown=honest_md, intent=intent, plan=plan, trace=trace,
                web_invariant_gap="; ".join(web_gaps))
        if step_sources:
            all_sources.extend(step_sources)
        # ВОРОТА КАЛЬКУЛЯТОРА = контракт × паспорт.
        step_calc = needs_calc and (aid in calc_agents if calc_agents
                                    else not _looks_critic(aid))
        # ЧЕСНА ДОБIРКА ЖИВИХ ДАНИХ: пропонуємо сигнал ЛИШЕ коли живих даних цьому
        # кроку не дали, а веб у платформи Є. Критику не пропонуємо (його робота -
        # судити вже зроблене, а не ходити у свiт).
        _offer_web_now = bool((not meta_mode) and (not live_data)
                              and (not _looks_critic(aid))
                              and config.web_search_ready())
        # ⭐⭐⭐ 12.08.2026 (164). ВОРОТА ІНСТРУМЕНТІВ ЧУЖОГО СЕРВІСУ = ПАСПОРТ
        # РОЛІ × ГОТОВНІСТЬ ВХОДУ. Ні назва агента, ні слова задачі права не
        # дають: саме здогадка за написанням і зробила «читача пошти»
        # веб-шукачем (162). І рішення НЕ ТИХЕ — його видно в журналі, як і
        # рішення про веб.
        _conn_tools = [] if meta_mode else connector_tools.step_tools(_role_tools(roles, aid))
        import sys as _sc
        _sc.stderr.write("[conn] step=%s role=%s passport=%r -> %s\n"
                         % (idx, aid, sorted((_role_tools(roles, aid) or {}).keys()),
                            ", ".join(_conn_tools) or "NO CONNECTOR TOOLS"))
        if _conn_tools:
            _emit(emit, "🔌 %s: працюю у вашому сервісі (%s)"
                        % (aid, ", ".join(connector_tools.TOOLS[t]["name"] for t in _conn_tools)))
        try:
            out = _run_agent(system, step, idx, len(pipeline), plan, task, convo,
                             files_context, accumulated, live_data, style,
                             use_calc=step_calc, emit=emit, seo_page=seo_page,
                             offer_capability=(not meta_mode) and not needs_calc,
                             offer_web=_offer_web_now, legal_note=_legal_note,
                             conn_tools=_conn_tools)
        except llm.LLMNotConfigured as e:
            # ⭐ 29.07.2026. Сирий виняток більше не стає текстом для людини:
            # переклад робить ОДИН модуль, подробиці лягають у журнал.
            return {"status": "runtime_error",
                    "final_markdown": failure.client_text(e, "executor/%s" % aid),
                    "failure": failure.classify(e), "client_safe": True,
                    "agent_trace": trace, "system_id": system.get("id")}
        except llm.LLMError as e:
            if failure.is_budget(e):
                # Межа вартості — не аварія. У неї свій, уже побудований шлях.
                return {"status": "runtime_error",
                        "final_markdown": failure.client_text(e, "executor/%s" % aid),
                        "failure": "budget", "client_safe": True,
                        "agent_trace": trace, "system_id": system.get("id")}
            return {"status": "runtime_error",
                    "final_markdown": failure.client_text(e, "executor/%s" % aid),
                    "failure": failure.classify(e), "client_safe": True,
                    "agent_trace": trace, "system_id": system.get("id")}
        # ВОРОТА КРОКУ: пробільне виродження ловимо одразу — один повтор кроку,
        # далі чесний збій кроку (а не мовчазне протягування місива конвеєром).
        if _degenerate_step(out):
            _emit(emit, f"⚠ {aid}: вироджений вивід кроку (пробільний цикл) — повторюю крок…")
            try:
                out = _run_agent(system, step, idx, len(pipeline), plan, task, convo,
                                 files_context, accumulated, live_data, style,
                                 use_calc=step_calc, emit=emit, seo_page=seo_page,
                                 offer_capability=(not meta_mode) and not needs_calc,
                                 offer_web=_offer_web_now, legal_note=_legal_note,
                                 conn_tools=_conn_tools)
            except llm.LLMError:
                out = ""
            if _unusable_step(out):
                # ⛔ 30.07.2026. Тут стояла ПІДМІНА: вивід кроку замінювався рядком
                # «[Збій кроку … Результат ВІДСУТНІЙ]», конвеєр ішов далі, а прогін
                # завершувався як `completed` — тобто робота з ДІРКОЮ всередині
                # їхала клієнту файлами й із зеленим вердиктом. Крок без результату
                # — це обірваний ланцюг, а не дрібна незручність: складальник
                # добудує пропуск текстом, і людина цього не побачить.
                _emit(emit, f"⛔ {aid}: крок двічі видав вироджений вивід — "
                            "зупиняюсь чесно, а не добудовую результат без нього.")
                _reason = (f"крок «{aid}» двічі видав вироджений вивід (пробільний цикл), "
                           "повтор не допоміг — результату цього кроку НЕМАЄ")
                honest_md = (
                    "## Не можу видати результат: один з етапів не дав нічого\n\n"
                    f"Етап **{aid}** двічі повернув порожній (вироджений) вивід, повтор не "
                    "допоміг. Далі по ланцюгу цей етап потрібен, тому я зупиняюсь.\n\n"
                    "Щоб не вводити тебе в оману, я НЕ збираю відповідь без нього: "
                    "складальник просто заповнив би пропуск загальними словами, і в "
                    "документі була б дірка, якої не видно.\n\n"
                    "**Що можна зробити:**\n\n"
                    "- повтори запит — вироджений вивід часто разовий;\n"
                    "- або переключи модель виконавця на надійнішу і повтори.\n"
                )
                return honest_stop_result(
                    system, kind="step_no_result", reason=_reason,
                    action=("повтори запит або переключи модель виконавця на надійнішу — "
                            "вироджений вивід зазвичай разовий"),
                    markdown=honest_md, intent=intent, plan=plan, trace=trace)
        # ЧЕСНА ДОБІРКА: агент чесно сказав, що без калькулятора результат буде «з
        # голови». Не вгадуємо — повертаємо мозку запит на ОДИН перезапуск із
        # розширеним контрактом (ліміт перезапусків — код у agent.py, не LLM).
        if (not needs_calc and not meta_mode
                and re.search(r"NEEDS_CAPABILITY\s*:?\s*calculator", out or "", re.I)):
            _emit(emit, f"🖐 {aid}: для якісного результату потрібен калькулятор — "
                        "запитую в мозку розширений контракт…")
            return {"status": "needs_capability", "capability": "calculator",
                    "final_markdown": "", "agent_trace": trace,
                    "system_id": system.get("id"),
                    "understanding": plan.get("system_understanding", "")}
        # ТЕ САМЕ ДЛЯ ЖИВОГО ВЕБУ (09.08.2026): агент чесно сказав, що без
        # актуальних зовнiшнiх даних вiдповiдь була б вигадкою. Замiсть «не маю
        # доступу» - ОДИН перезапуск iз розширеним контрактом (ліміт - код).
        if (not fresh_required and not meta_mode
                and re.search(r"NEEDS_CAPABILITY\s*:?\s*web", out or "", re.I)):
            _emit(emit, f"🖐 {aid}: без живих даних вiдповiдь була б із памʼятi — "
                        "запитую в мозку розширений контракт…")
            return {"status": "needs_capability", "capability": "web",
                    "final_markdown": "", "agent_trace": trace,
                    "system_id": system.get("id"),
                    "understanding": plan.get("system_understanding", "")}
        role = "critic" if _looks_critic(step["agent"]) else "agent"
        entry = {"agent": step["agent"], "output": out, "role": role, "purpose": step.get("purpose", "")}
        if live_data:
            entry["searched"] = True
        trace.append(entry)
        accumulated += f"\n### {step['agent']}\n{out}\n"

    # 3b) ЦИКЛ ЯКОСТІ за планом
    ql = plan["quality_loop"]
    revisions = 0
    if depth == "quick":
        _emit(emit, "⚡ Швидкий режим: без раундів критика")
    if depth != "quick" and ql.get("enabled") and ql.get("critic_agent") and ql.get("reviser_agent"):
        threshold = _threshold_value(ql.get("pass_threshold"))
        max_iter = min(int(ql.get("max_iterations") or 2), HARD_MAX_REVISIONS)
        critic_id, reviser_id = ql["critic_agent"], ql["reviser_agent"]
        critic_out = next((t["output"] for t in reversed(trace) if t["agent"] == critic_id), "")
        while revisions < max_iter and not _critic_satisfied(critic_out, threshold):
            # ⭐ 28.07.2026: раніше вихід за бюджетом був НІМИЙ — людина бачила
            # завершені кола критика і вважала, що якість визнано готовою.
            # Зупинка за ВАРТІСТЮ мусить називати себе вголос.
            if _over_cap(_cap):
                # Усі етапи вже зроблені — лишалось шліфування. Тут пауза з вибором
                # не має сенсу: чесніше зібрати оплачене й сказати про це людською
                # мовою (без назв файлів і налаштувань).
                _emit(emit, f"⚠ Досягнуто межу вартості (${_cap:.2f}) — далі не витрачаю. "
                            "Складаю відповідь із того, що вже напрацьовано. "
                            "Це зупинка за вартістю, а не «якість визнано готовою».")
                break
            revisions += 1
            _emit(emit, f"🔁 Доопрацювання за критиком (раунд {revisions})…")
            rev_prompt = platform_reach_note() + (_load_agent_prompt(system, reviser_id)
                                                  or _synth_agent_prompt(system, reviser_id))
            _calc_guard = ("## ПРАВИЛО ЧИСЕЛ\nЧисла в етапах пораховані калькулятором — "
                           "НЕ перераховуй і НЕ змінюй їх; правити можна лише текст.\n\n") if needs_calc else ""
            try:
                rev_out = llm.complete(rev_prompt,
                    _calc_guard
                    + f"## ЗАПИТ\n{task}\n\n## ПОТОЧНІ ЕТАПИ\n{accumulated}\n\n"
                    f"## ФІДБЕК КРИТИКА (усунь повністю)\n{critic_out}\n\nРаунд {revisions}. Поверни покращену версію.\n\n" + _ART,
                    model=config.worker_model())
            except llm.LLMError:
                break
            if _degenerate_step(rev_out):
                _emit(emit, "⛔ Ревізія видала вироджений вивід — зупиняю цикл якості, лишаю попередню версію.")
                break
            trace.append({"agent": f"{reviser_id} (ревізія {revisions})", "output": rev_out, "role": "revision"})
            accumulated += f"\n### {reviser_id} (ревізія {revisions})\n{rev_out}\n"
            crit_prompt = platform_reach_note() + (_load_agent_prompt(system, critic_id)
                                                   or _synth_agent_prompt(system, critic_id))
            try:
                critic_out = llm.complete(crit_prompt,
                    f"## ЗАПИТ\n{task}\n\n## МАТЕРІАЛ\n{rev_out}\n\nОціни за умовою «{ql.get('pass_threshold')}» і вкажи, чи готово.",
                    model=config.worker_model())
            except llm.LLMError:
                break
            trace.append({"agent": f"{critic_id} (оцінка {revisions})", "output": critic_out, "role": "critic"})
            accumulated += f"\n### {critic_id} (оцінка {revisions})\n{critic_out}\n"

    if should_cancel and should_cancel():
        _emit(emit, "⏹ Зупинено на ваш запит.")
        return {"status": "cancelled", "final_markdown": "", "agent_trace": trace,
                "system_id": system.get("id")}

    # 4) ФІНАЛЬНА ЗБІРКА за правилами системи
    _emit(emit, "📝 Збираю фінальний результат…")
    root_prompt = _system_root_prompt(system)
    deliverable = plan.get("final_deliverable", "")
    assembler_sys = (
        platform_reach_note()
        + (root_prompt + "\n\n" if root_prompt else "")
        + "## ТВОЯ РОЛЬ ЗАРАЗ\nТи — кореневий складальник системи. З етапів агентів збери "
          "ЄДИНИЙ чистий фінальний результат МОВОЮ ЗАПИТУ КОРИСТУВАЧА (тією, якою написано "
          "запит: російський запит → російською, український → українською; не підміняй за "
          "локаллю збірки), який дає САМЕ ТЕ, що просив користувач у запиті.\n"
          "• Формат і структуру диктує ЗАПИТ КОРИСТУВАЧА. Якщо просили конкретний артефакт "
          "(дашборд, таблицю OKR/KPI, план, юридичний висновок, договір) — видай саме його, "
          "у повному обсязі, з усіма таблицями та цифрами з етапів.\n"
          "• НЕ нав'язуй власний шаблон (зокрема «вердикт ради директорів»), якщо користувач "
          "його не просив. Думки ради/критика — лише сировина; у фінал бери суть, а не їхній формат.\n"
          f"• Очікуваний результат системи (орієнтир, не догма): {deliverable}\n"
          "• Без службових міток, оцінок критика та мета-коментарів про процес.\n\n"
        + config.FINAL_OUTPUT_STANDARDS + "\n\n" + _ART
    )
    # КЕШ (Правило A, 25.07.2026): стабільний префікс (роль+стандарти) окремо від
    # ПЕРЕМІННИХ по-задачі блоків. Anthropic кешує префікс -> hit-rate росте. Текст,
    # який бачить модель, НЕ міняється (конкатенація префікс+хвіст ідентична старій).
    _sys_suffix = (
        (("\n\n## ПРАВИЛО ЧИСЕЛ ДЛЯ ЗБІРКИ (обовʼязкове)\nЧисла в етапах пораховані "
            "калькулятором. Переноси їх у фінал ТОЧНО — не перераховуй, не заокруглюй "
            "по-своєму, не «гармонізуй». Якщо числа різних етапів суперечать — бери "
            "значення з найпізнішого розрахункового кроку і чесно познач розбіжність.")
           if needs_calc else "")
        + (("\n\n## " + config.XLSX_MODEL_NOTE) if wants_model else "")
        + (("\n\n## " + config.SCHEMA_MODEL_NOTE) if seo_facts else "")
    )
    if _sys_suffix:
        assembler_sys = [assembler_sys, _sys_suffix]
    # ІСТИНА ДВИГУНА → СКЛАДАЧУ. Для системи маршрутів реальні плечі й заклади (Google,
    # уже в seo_page-слоті) МУСЯТЬ дійти у фінал дослівно. Корінь бага 14.07: агенти-
    # дослідники вимагали URL і мітили реальні заклади «не підтверджено», а складач
    # першоджерела не бачив (збирав лише з accumulated) — тому реальні кафе/готелі й
    # рейтинги викидались, а справжні кілометри діставали фальшиву мітку «оцінка». Тепер
    # складач отримує блок движка як авторитет, який не можна хеджувати.
    _route_truth = ""
    if route_diag and isinstance(route_diag.get("result"), dict) and route_diag["result"].get("ok"):
        _route_truth = seo_page or ""
    assembler_input = assembler_input_text(task, _route_truth, accumulated,
                                          files_context)
    # Складальник критичний: пробуємо мозок, потім запасну модель. Якщо обидва впали,
    # НЕ видаємо сирий (можливо обрізаний) вивід останнього агента за «фінал» —
    # чесно позначаємо, що збірка не вдалася й потрібен повторний запуск.
    final_markdown = ""
    assembler_ok = False
    honest_stop = None  # свідомий чесний стоп (fail-closed): {reason, action}
    if meta_mode:
        # Мета-режим (Будівник): фінальна збірка НЕ потрібна — споживач (матеріалізатор)
        # бере СИРИЙ вивід агентів із трейсу. Пропускаємо найважчий і зайвий тут крок.
        final_markdown = (trace[-1].get("output", "") if trace else "") or accumulated
        assembler_ok = True
    _chain = _assembler_models(_is_high_stakes(system, task, intent))
    # ⭐ 28.07.2026. Саме тут згорів прогін на $2.51 при стелі $1: фінал правової
    # відповіді збирає ДОРОГИЙ мозок, і цей один крок коштував більше за всю
    # стелю. Обривати збірку не можна — клієнт заплатив і лишиться без відповіді.
    # Тому за межею фінал збирає ДЕШЕВА модель, і людині про це сказано.
    if _over_cap(_cap) and not meta_mode:
        _cheap = config.worker_model()
        if _cheap:
            _chain = [_cheap] + [m for m in _chain if m != _cheap]
            _emit(emit, "⚠ Межу вартості прогону ($%.2f) досягнуто — фінал збираю "
                        "дешевшою моделлю, щоб відповідь усе одно вийшла." % _cap)
    _work_len = len(accumulated or "")
    for _i, _mdl in enumerate(_chain):
        if assembler_ok:
            break
        _nxt = _chain[_i + 1] if _i + 1 < len(_chain) else None
        out = None
        # РЕЗЕРВ ШВИДШЕ: одна спроба на модель, тоді одразу наступна в ланцюгу. Потоковий
        # транспорт llm тепер сам відрізняє «живий-але-повільний» від «завис» (idle-таймаут)
        # і робить дешевий 1× повтор старту всередині — тож дублювати важкий повтор ТІЄЇ Ж
        # моделі тут більше не треба (раніше 2 тут × 3 у llm = до 6 дорогих перегенерацій
        # перед резервом = час і гроші).
        try:
            # ⛒ РЕЗУЛЬТАТ МОЖЕ БУТИ ТІЛЬКИ ПОВНИМ (зміна 251, слово Андрія 28.08).
            # Складальник — саме те місце, де 28.08 зник фінансовий блок: текст
            # уперся в межу, обірвався, і платформа віддала його як готовий.
            _whole = llm.complete_whole(
                assembler_sys, assembler_input,
                model=_mdl, max_tokens=config.ASSEMBLER_MAX_TOKENS,
                timeout=config.ASSEMBLER_TIMEOUT,
                on_continue=lambda n: _emit(
                    emit, "📎 Відповідь не влізла в один прохід — добираю залишок "
                          "(%d з %d)…" % (n, llm.MAX_CONTINUATIONS)))
            out = _whole.get("text") or ""
            if _whole.get("cut"):
                # ⛔ ОБІРВАНЕ НЕ Є РЕЗУЛЬТАТОМ. Не приймаємо і не показуємо:
                # краще надійніша модель або чесна зупинка, ніж документ із
                # дірою, якої не видно.
                # ⭐⭐⭐ 600: І ЛИШАЄМО СЛІД. 16.09.2026 такий самий обрив
                # спалив $2,39, і причини не лишилось ніде — тільки слово
                # «обірвано» в журналі. Тепер сирий вивід лягає у файл.
                _case = _trace_case("assembler-cut-%s" % _mdl)
                _pth = failure_trace.put(_case, "01-assembler-raw.md", out or "")
                failure_trace.put(_case, "00-reason.txt",
                          "складальник %s: обірвано межею після %d добірок\n"
                          "довжина виводу: %d знаків\nзадача: %s"
                          % (_mdl, _whole.get("continuations") or 0,
                             len(out or ""), (task or "")[:400]))
                llm._log("[executor] складальник %s: текст лишився обірваним після "
                         "%d добірок — НЕ приймаю як результат; сирий вивід: %s"
                         % (_mdl, _whole.get("continuations") or 0, _pth))
                _emit(emit, "⚠ Відповідь не вмістилась навіть із добіркою"
                            + (" — беру надійнішу модель…" if _nxt else "."))
                out = None
            elif _whole.get("continuations"):
                llm._log("[executor] складальник %s: текст добрано продовженням (%d)"
                         % (_mdl, _whole["continuations"]))
        except llm.LLMError as e:
            # Той самий закон, що й на кроці агента (11.08.2026): людині — клас
            # аварії словами, повний слід і назва моделі — у журнал.
            failure.log(e, "executor.run_system/складальник/%s" % _mdl)
            _emit(emit, "⚠ %s." % failure.reason_human(e)
                        + (" Перемикаюсь на надійнішу модель…" if _nxt else ""))
            out = None
        if not (out and out.strip()):
            continue
        # ВОРОТА ЯКОСТІ СКЛАДАННЯ: відхиляємо вироджений вивід (пробільні цикли/порожнеча/
        # обрив) і пробуємо наступну, надійнішу модель — а не приймаємо брак за фінал.
        _deg = verifier.degeneracy_check(out, _work_len)
        if not _deg.get("ok"):
            _emit(emit, f"⛔ {_mdl}: вивід не пройшов ворота якості ({_deg.get('reason')})."
                        + (f" Пробую {_nxt}…" if _nxt else ""))
            continue
        final_markdown = verifier.sanitize_output(out)
        assembler_ok = True
        if _i > 0:
            _emit(emit, f"✓ Фінал зібрано резервною моделлю ({_mdl}).")
        break
    if not assembler_ok:
        _emit(emit, "⚠ Складання якісного фіналу не вдалося — потрібен повторний запуск.")
        final_markdown = (
            "> ⚠ **УВАГА: складальник не зміг зібрати ЯКІСНИЙ фінал** (усі моделі дали збій "
            "або вироджений вивід). Це НЕ готовий результат — перезапустіть задачу.\n\n"
            + (verifier.sanitize_output(accumulated) or "(етапів немає)")
        )

    # 4б) Ворота якості Excel-моделі: ЧИ потрібна повноцінна модель — каже контракт
    # наміру (financial_model). Невалідний блок, що вже зʼявився у фіналі, чистимо
    # незалежно (щоб сирий JSON не потрапив користувачу).
    if assembler_ok and (wants_model or "```xlsxmodel" in (final_markdown or "")):
        final_markdown, honest_stop = _fix_xlsxmodel(
            final_markdown, task, emit=emit, wants_excel=wants_model,
            source_text=(files_context or "") + "\n" + (task or ""),
            files_context=files_context)

    # 4в) Матеріалізація schema.org: компактну модель ```schemaorg перетворюємо на
    # валідний JSON-LD із РЕАЛЬНИХ фактів сторінки; поля без даних → чек-лист
    # «дозаповнити» (не заглушки в JSON). Лікує обрив JSON і плейсхолдери URL.
    if assembler_ok and "```schemaorg" in (final_markdown or ""):
        _emit(emit, "🧩 Збираю валідну schema.org-розмітку з реальних даних сторінки…")
        final_markdown = schema_org.materialize(final_markdown, seo_facts, emit=emit)

    # 4в-2) ⭐ 28.07.2026. САМОЗАЯВЛЕНА ЗВІРКА — ДЛЯ ВСІХ СИСТЕМ, не лише юриста.
    # Фраза «звірено з першоджерелом» має право зʼявитись лише тоді, коли звіряв
    # КОД. Модель не може ставити цю печатку сама собі — ні в юр-довідці, ні в
    # маркетинговому звіті, ні у фінмоделі. Це та сама дірка «дві правди в одному
    # документі», через яку клієнт 28.07 отримав «PASS» на незвірених нормах.
    if assembler_ok and final_markdown:
        try:
            import legal_citation_check as _seal
            _before = final_markdown
            final_markdown = _seal.strip_model_seal(final_markdown)
            if final_markdown != _before:
                _emit(emit, "🧹 Знято самозаявлену печатку «звірено з першоджерелом» — "
                            "її ставить лише машинна перевірка.")
        except Exception as e:
            llm._log(f"[executor] зняття печатки зірвалось: {e}")

    # 4г) ЮРИСТ — детермінований звіряч цитат із ВРУ (ворота проти фальшивої звірки).
    if assembler_ok and _is_legal_system(system) and _legal_jurisdiction(task, intent) == "UA":
        # ОДИН ПИСАР: віддаємо воротам ту саму позицію, яку бачив агент.
        final_markdown = _apply_legal_citation_check(final_markdown, emit=emit, task=task,
                                                     history=history, legal_pos=legal_pos,
                                                     intent=intent)

    # ⭐⭐⭐ 05.08.2026. ВОРОТА ТЕНДЕРАЙТЕРА №2 і №3 — НА ГОТОВОМУ АРТЕФАКТІ.
    # Кожен пункт переліку замовника мусить дожити до пакета, і кожен рядок
    # реєстру — мати підставу в оголошенні. Роботу НЕ стираємо (людина за неї
    # заплатила), але прямо кажемо, що пакет НЕ готовий до подачі: мовчазна
    # неповнота коштує дорожче за незручну правду.
    _pack_docs = []
    _pack_proof = {}
    _not_docs = []
    _only_reader = []
    _empty_docs = []
    _same_papers = {}
    # ⭐⭐⭐ 17.08.2026 (зміна 198). СКІЛЬКИ БУЛО РЯДКІВ ЗАМОВНИКА ДО РОЗКРИТТЯ.
    # Це число живе довше за розкриття, бо ним міряють ворота обсягу й ним же
    # пакет чесно каже людині, чому «вимог» і «документів» — різні числа.
    _list_rows = 0
    _form_fields = []
    if (system or {}).get("id") == tender_pack.SYSTEM_ID:
        # ⭐ 10.08.2026. МАТЕРІАЛ = файли + ЗАДАЧА. Людина має право вставити вимоги
        # замовника прямо в задачу, і тоді вони — таке саме джерело, як завантажене.
        _material = ((files_context or "") + "\n\n" + (task or "")).strip()
        # ⚠ Вердикт про теми ми взяли ще до воріт витрат. Питаємо вдруге ЛИШЕ
        # тоді, коли матеріал відтоді змінився: інакше це гроші за те саме
        # питання. А мовчки судити НЕ ТОЙ матеріал не можна — вердикт не
        # знайшовся б, і ми б не відрізнили цього від «суддя промовчав».
        if _material != _topics_of:
            try:
                _topics = tender_pack.head_topics(_material)
                _topics_of = _material
                llm._log("[executor] тема переліків (матеріал змінився): названо=%d"
                         % len(_topics.get("verdicts") or {}))
            except Exception as _e:
                llm._log("[executor] тема переліків не судилась: %s" % _e)
        # ⭐ ДВА ДЖЕРЕЛА ПЕРЕЛІКУ ТРИМАЄМО ОКРЕМО, І ЦЕ НЕ ДРІБНИЦЯ: у них РІЗНА
        # ВАГА. Позицію з документів замовника підтвердив ЗАГОЛОВОК переліку;
        # позицію від агента-читача не підтвердив ніхто (зміна 157).
        # ⭐⭐⭐ 17.08.2026, зміна 194. ФАКТ ПРО НЕПРОЧИТАНЕ ЧИТАЄ КОД, А НЕ МОДЕЛЬ.
        # Мітки кладе `source_intake` (один писар), читає він же (один читач) —
        # і далі факт іде і в шапку пакета, і у ворота. Без цього ворота міряли
        # повноту пакета проти переліку, витягнутого з ПОЛОВИНИ документації.
        _mat_gaps = []
        try:
            import source_intake as _si
            _mat_gaps = _si.gaps_in(_material)
            if _mat_gaps:
                llm._log("[executor] документацію прочитано НЕ ВСЮ: %d — %s"
                         % (len(_mat_gaps), "; ".join(_mat_gaps[:3])))
        except Exception as _e:
            llm._log("[executor] мітки непрочитаного не прочитались: %s" % _e)
        _trace_chk = tender_pack.checklist_from_trace(accumulated)
        _mat_chk = tender_pack.extra_requirements_in(_material, topics=_topics)
        # ⭐ 12.08.2026. ТОЙ САМИЙ ПАПІР, НАЗВАНИЙ ІНШИМИ СЛОВАМИ, — ОДНА ПОЗИЦІЯ.
        _trace_chk, _same_papers = tender_pack.drop_same_papers(_trace_chk, _mat_chk)
        if _same_papers:
            llm._log("[executor] той самий папір іншими словами: %d — %s"
                     % (len(_same_papers), "; ".join(list(_same_papers)[:3])))
        # ⭐⭐⭐ 17.08.2026, зміна 193. ГРАФА БЛАНКА — НЕ ДОКУМЕНТ, І ВИРІШУЄ ЦЕ КОД.
        # 🩸 16.08 читач переказав поля Додатків №3 і №4 («Шапка:», «Телефон/факс:
        # [Номер]», «Чи є дочірнім підприємством?») як окремі вимоги, і платформа
        # склала на кожну довідку: 20 позицій стали 57. Прибираємо ДО злиття —
        # тоді графи не доїжджають ні до судді (це ще й гроші), ні до пакета.
        _trace_chk, _form_fields = tender_pack.drop_form_fields(_trace_chk, _mat_chk)
        if _form_fields:
            llm._log("[executor] графи бланків (не документи): %d — %s"
                     % (len(_form_fields), "; ".join(_form_fields[:3])))
        _chk = tender_pack.merge_checklists(_trace_chk, _mat_chk)
        # ⭐⭐⭐ 05.08.2026, ТРЕТІЙ ПРОВАЛЕНИЙ ПРОГІН. КІСТЯК ПАКЕТА БУДУЄ КОД.
        # Агенти відмовлялись складати пакет («більшість інформації відсутня» —
        # у них не було реквізитів і цін учасника), і жоден текст у промпті цього
        # не змінив: рішення ухвалює модель, а прохання в промпті — це прохання.
        # Тепер структура пакета детермінована: перелік замовника -> розділ на
        # кожен пункт + реєстр із підставами + список «заповнити перед подачею».
        # Модель не вирішує, БУТИ пакету чи ні: пакет уже є, вона його наповнює.
        # Найгірше, що можливо, — порожні графи. Це чесний папір, а не «роботи не зроблено».
        if _chk:
            try:
                # ⭐ ФАКТИ ЗАКУПІВЛІ БЕРЕМО З КАРТКИ, А НЕ ЛИШЕ НОМЕР (зміна 159):
                # інакше платформа знає предмет і замовника, а в складеній
                # довідці стоїть «предмет закупівлі: ______».
                _tid = (tender_pack.tender_id_in(task or "")
                        or tender_pack.tender_id_in(files_context or ""))
                _facts = tender_pack.tender_facts(_tid)
                # ⭐ 17.08.2026. СТАН ЗАКУПІВЛІ ЇДЕ В САМ ПАКЕТ. Ворота №0 могли
                # пропустити роботу за прямим словом людини («як заготовка») —
                # тоді документ мусить нести це попередження першим рядком:
                # пакет читатимуть ще й ті, хто не бачив нашої розмови.
                _adm = tender_pack.admissibility_note(_adm_state)
                if _adm:
                    _facts["admissibility"] = _adm
                llm._log("[executor] факти закупівлі: номер=%s предмет=%s замовник=%s "
                         "строк=%s кількість=%s"
                         % (_facts.get("tender_id") or "—",
                            (_facts.get("subject") or "—")[:60],
                            (_facts.get("customer") or "—")[:40],
                            _facts.get("deadline") or "—",
                            _facts.get("quantity") or "—"))
                # ⭐ ХТО ВИРОБЛЯЄ ДОКУМЕНТ — теж судження про ЧУЖИЙ документ.
                # Один виклик на весь пакет, вердикт протягується в усі чотири
                # місця, де про це питали (розділ, реєстр, «зібрати самому»,
                # «бланки замовника»). Суддя мовчить -> словник + видима помітка.
                _mk = {"ok": False, "verdicts": {}}
                try:
                    _mk = tender_skeleton.makers_for(_chk)
                    llm._log("[executor] виробник документів: суддя=%s, названо позицій=%d"
                             % ("так" if _mk.get("ok") else "ні",
                                len(_mk.get("verdicts") or {})))
                except Exception as _e2:
                    llm._log("[executor] виробника не судили: %s" % _e2)
                # ⛔ Позиції, які суддя назвав НЕ ДОКУМЕНТАМИ, у пакет не йдуть,
                # але й не зникають мовчки: код прибирає їх зі складу і НАЗИВАЄ
                # людині окремим блоком. Ворота пакета мусять звірятися з тим
                # самим переліком, інакше поскаржаться на власне ж прибирання.
                _not_docs = tender_skeleton.not_documents(_chk, _mk)
                if _not_docs:
                    _chk = [i for i in _chk
                            if tender_skeleton.is_document(i, _mk)]
                    llm._log("[executor] не документи (прибрано з пакета): %d — %s"
                             % (len(_not_docs), "; ".join(_not_docs[:5])))
                # ⛔ 11.08.2026, зміна 157. ПОЗИЦІЯ, ЯКУ НАЗВАВ ЛИШЕ ЧИТАЧ І ЯКУ
                # СУДДЯ НЕ ПІДТВЕРДИВ ДОКУМЕНТОМ, У ПАКЕТ НЕ ЙДЕ. Інакше дефолт
                # «система» робив довідку з власного заголовка агента-читача.
                _chk, _only_reader = tender_pack.keep_confirmed_docs(
                    _chk, _trace_chk, _mat_chk, _mk)
                if _only_reader:
                    llm._log("[executor] лише від читача, не підтверджено: %d — %s"
                             % (len(_only_reader), "; ".join(_only_reader[:5])))
                # ⭐⭐⭐ 17.08.2026 (зміна 197). РЯДОК ВИМОГИ -> ДОКУМЕНТИ. Замовник
                # пише вимогу умовою («Якщо пропозиція подається не керівником —
                # учасник надає ДОВІРЕНІСТЬ»), і папір ховається всередині правила.
                # Розкриваємо ОДИН раз, у ОДНОМУ місці, після того як склад пакета
                # вже звірений із переліком замовника й переказом читача: далі всі —
                # і текст довідок, і кістяк, і ворота — працюють з ДОКУМЕНТАМИ,
                # а сам рядок лишається їхньою ПІДСТАВОЮ.
                _rows_n = _list_rows = len(_chk)
                _chk = tender_skeleton.expand(_chk, _mk)
                if len(_chk) != _rows_n:
                    llm._log("[executor] рядки замовника розкрито в документи: %d -> %d"
                             % (_rows_n, len(_chk)))
                # ⭐⭐⭐ 24.08.2026, зміна 209. КАРТКА, ЯКУ КЛІЄНТ ДАВ У ЧАТ,
                # ЇДЕ В БАЗУ ЗНАНЬ. Обіцянка клієнту звучала так: «дайте файл із
                # даними компанії — платформа візьме реквізити звідти». Досі
                # прикріплений файл був лише матеріалом одного прогону: наступного
                # разу все спочатку. Тепер прочитане ЗБЕРІГАЄТЬСЯ, і клієнт дає
                # картку ОДИН раз. Витяг детермінований (правила, не модель), тому
                # він однаковий на еталоні й у клієнта і коштує $0.
                try:
                    import owner_card as _oc
                    # ⛒ 24.08.2026, зміна 213. СУДИМО КОЖЕН ФАЙЛ ОКРЕМО.
                    # Злиття всіх прикріплених файлів в один текст дало тендерній
                    # документації замовника видати себе за картку учасника — і в
                    # базу знань лягло ЄДРПОУ ЗАМОВНИКА. Файл судиться сам, зі
                    # своєю назвою і своїм розміром.
                    # ⭐ ЗМІНА 221: збираємо з УСІХ прикріплених файлів, а не
                    # шукаємо один «правильний». Рубрика «чи це картка» більше
                    # не вирішує долю даних; тендерну документацію замовника
                    # відсікає сам `harvest` (уроки змін 213 і 215).
                    _blocks = list(_oc.blocks(files_context or ""))
                    _card, _src = _oc.harvest(_blocks)
                    if _src:
                        llm._log("[executor] реквізити зібрано з файлів: %s"
                                 % "; ".join("%s <- %s" % (k, v) for k, v in _src.items()))
                    if not any((_card or {}).values()):
                        _card = {}
                    if _card:
                        if _oc.save(_card):
                            llm._log("[executor] картку учасника оновлено з файла клієнта: %s"
                                     % ", ".join(k for k in _oc.FIELDS if _card.get(k)))
                            _emit(emit, "🗂 Реквізити учасника взято з вашого файла "
                                        "і збережено в базу знань — далі підставляться самі")
                except Exception as _e:
                    llm._log("[executor] картка учасника не прочиталась: %s" % _e)
                _req = tender_pack.requisites()
                # ⭐⭐⭐ 12.08.2026 (зміна 159). ТЕКСТ ДОВІДКИ ЗАМОВЛЯЄ ПЛАТФОРМА.
                # Живий прогін 12.08 віддав клієнту пʼять ПОРОЖНІХ бланків: текст
                # моделі ліпився хвостом пакета за збігом перших 32 знаків назви —
                # і у файл довідки не потрапляв ніколи. Тепер «одна довідка — один
                # запит», а код кладе відповідь УСЕРЕДИНУ свого розділу.
                _slots, _bodies = [], {}
                try:
                    _slots = tender_fill.slots(_chk, _mk)
                    if _slots:
                        _fill = tender_fill.compose(_slots, _facts, _req, _material)
                        _bodies = _fill.get("bodies") or {}
                        _empty_docs = list(_fill.get("missing") or [])
                        llm._log("[executor] текст довідок: замовлено=%d складено=%d "
                                 "без тексту=%d%s"
                                 % (_fill.get("asked", 0), _fill.get("done", 0),
                                    len(_empty_docs),
                                    (" — " + "; ".join(_empty_docs[:3])) if _empty_docs else ""))
                        _emit(emit, "✍ Текст довідок склала платформа: %d з %d"
                              % (_fill.get("done", 0), _fill.get("asked", 0)))
                except Exception as _e3:
                    # Зрив не смів би бути тихим: усі замовлені довідки лишаються
                    # без тексту, і людина мусить це БАЧИТИ, а не здогадуватись.
                    _empty_docs = [tender_skeleton._clean(_s.get("item"))
                                   for _s in (_slots or [])]
                    llm._log("[executor] текст довідок не склався: %s" % _e3)
                _skel = tender_skeleton.build(_chk, _req, _facts,
                                              makers=_mk, bodies=_bodies,
                                              material_gaps=_mat_gaps,
                                              list_rows=_list_rows)
                if _skel:
                    # ⛔ Вільний пакет моделі СЮДИ БІЛЬШЕ НЕ ДОДАЄТЬСЯ: правда про
                    # склад і зміст пакета одна, і її пише платформа.
                    final_markdown = _skel
                    if _blank_questions:
                        final_markdown += ("\n\n---\n\n### ЩО ПОТРІБНО ВІД УЧАСНИКА\n"
                                           + "\n".join("- " + q for q in _blank_questions))
                    _emit(emit, "🧱 Кістяк пакета зібрано платформою — %d позицій переліку"
                                % len(_chk))
                    # 🩸 Раніше цей рядок називався «текст моделі=…», а показував
                    # довжину ЗІБРАНОГО пакета — і памʼять зміни 158 записала
                    # «модель написала 26 034 знаки», чого ніхто не бачив.
                    llm._log("[executor] кістяк пакета: позицій=%d, довідок з текстом=%d "
                             "із %d, зібраний пакет=%d знаків"
                             % (len(_chk), len(_bodies), len(_slots),
                                len(final_markdown or "")))
            except Exception as _e:
                llm._log("[executor] кістяк пакета не зібрався: %s" % _e)
        # ⭐⭐⭐ 10.08.2026. ВОРОТА ДІСТАЮТЬ САМЕ ОГОЛОШЕННЯ — щоб звіряти пакет не з
        # тим переліком, з якого його ж і зібрали (замкнене коло), а з незалежною
        # оцінкою обсягу вимог у документах замовника.
        _verdict = tender_pack.check_pack(final_markdown, _chk, _material, topics=_topics,
                                          dropped=len(_not_docs) + len(_only_reader),
                                          empty_docs=_empty_docs, material_gaps=_mat_gaps,
                                          list_rows=_list_rows)
        # 🩸 «НЕ ВИСТАЧАЄ» БЕЗ «НАДЛИШКУ» — ПОЛОВИНА ПРАВДИ (зміна 193): 16.08 цей
        # самий рядок казав «обсяг в оголошенні=20 не вистачає=0» при 57 пунктах.
        # ⭐ 198: у рядку тепер ВИДНО обидві лінійки — вимог замовника й документів.
        llm._log("[executor] ворота пакета: вимог замовника=%d документів=%d рядків=%d "
                 "пропущено=%d без підстави=%d обсяг в оголошенні=%d "
                 "не вистачає=%d надлишок=%d"
                 % (_verdict.get("list_rows", 0), len(_chk), _verdict.get("rows", 0),
                    len(_verdict.get("missing") or []),
                    len(_verdict.get("no_source") or []), _verdict.get("volume", 0),
                    _verdict.get("short_by", 0), _verdict.get("over_by", 0)))
        if not _verdict.get("ok"):
            # ⭐ 05.08.2026, живий прогін: моє попередження прочитав СУДДЯ ЯКОСТІ й
            # оголосив усю роботу невиконаною — людина не отримала нічого. Це вже не
            # чесність, а друга правда про «готово». Блок лишається, але прямо каже,
            # ЩО він таке: попередження учаснику перед подачею, а не вердикт про роботу.
            _lines = ["> ⚠ **ПЕРЕВІРКА ПАКЕТА ПЕРЕД ПОДАЧЕЮ.** " + (_verdict.get("reason") or "")
                      + " Це попередження учаснику, а НЕ ознака невиконаної роботи:"
                        " документи нижче складені й придатні до використання."]
            if _verdict.get("missing"):
                _lines.append("> \n> **Пункти переліку замовника, яких немає в пакеті:**")
                _lines += ["> • " + m for m in _verdict["missing"][:12]]
            if _verdict.get("empty_docs"):
                _lines.append("> \n> **Довідки, текст яких платформа не склала** "
                              "(шапка й підстава є — текст напишіть самі):")
                _lines += ["> • " + m for m in _verdict["empty_docs"][:12]]
            if _verdict.get("no_source"):
                _lines.append("> \n> **Рядки без підстави в оголошенні** (не доведено, звідки вимога):")
                _lines += ["> • " + m for m in _verdict["no_source"][:12]]
            _lines.append("> \n> Закрийте названі пункти перед подачею — решта пакета готова.")
            final_markdown = "\n".join(_lines) + "\n\n---\n\n" + (final_markdown or "")
            _emit(emit, "⛔ Ворота пакета: %s" % (_verdict.get("reason") or "неповно"))
        # ⭐⭐⭐ 10.08.2026, зміна 142. ПЕРЕЛІК, ЯКИЙ МИ НЕ ВИЗНАЛИ ВИМОГАМИ, НЕ
        # СМІЄ ЗНИКНУТИ МОВЧКИ. Тему переліку тепер судить його ЗАГОЛОВОК — і це
        # рішення ПЛАТФОРМИ, а не замовника. Тому все, що ми відклали, людина
        # БАЧИТЬ і може заперечити очима, а не дізнатись про пропуск на знятті з
        # торгів. Блок дописуємо ПІСЛЯ воріт: ворота мусять судити пакет, а не
        # власну примітку про нього.
        if _not_docs:
            final_markdown = (final_markdown or "") + (
                "\n\n---\n\n### ПОЗИЦІЇ, ЯКІ ПЛАТФОРМА НЕ ВИЗНАЛА ДОКУМЕНТАМИ\n\n"
                "Це рядки умов закупівлі (ціна, кількість, строки, розділи договору), "
                "а не папери до подачі — тому окремих документів для них не складено. "
                "Перевірте очима, якщо вважаєте інакше:\n\n"
                + "\n".join("- " + n for n in _not_docs[:12])
                + (("\n- …і ще %d" % (len(_not_docs) - 12)) if len(_not_docs) > 12 else ""))
        # 🩸 І ЦЕ ПРИБИРАННЯ ТЕЖ НЕ ТИХЕ: людина бачить, що назвав читач і чому
        # цього немає в пакеті (зміна 157).
        _empty_note = tender_fill.empty_note(_empty_docs)
        if _empty_note:
            final_markdown = (final_markdown or "") + "\n\n---\n\n" + _empty_note
        _only_note = tender_pack.unconfirmed_trace_note(_only_reader)
        if _only_note:
            final_markdown = (final_markdown or "") + "\n\n---\n\n" + _only_note
        # 🩸 17.08.2026 (зміна 193). ГРАФИ БЛАНКІВ ПРИБИРАЄ КОД — І ТЕЖ НЕ МОВЧКИ.
        _fields_note = tender_pack.form_fields_note(_form_fields)
        if _fields_note:
            final_markdown = (final_markdown or "") + "\n\n---\n\n" + _fields_note
        _same_note = tender_pack.same_papers_note(_same_papers)
        if _same_note:
            final_markdown = (final_markdown or "") + "\n\n---\n\n" + _same_note
        _unc = tender_pack.unclaimed_note(_material, topics=_topics)
        if _unc:
            final_markdown = (final_markdown or "") + "\n\n---\n\n" + _unc
        # ⭐ FAIL-OPEN НЕ СМІЄ БУТИ ТИХИМ: перелік, узятий у вимоги без
        # підтвердженої теми, людина мусить БАЧИТИ так само, як і відкладений.
        _unconf = tender_pack.topic_unconfirmed_note(_material, topics=_topics)
        if _unconf:
            final_markdown = (final_markdown or "") + "\n\n---\n\n" + _unconf
        # ⭐ 10.08.2026, зміна 144. ПАКЕТ ЇДЕ ОКРЕМИМИ ФАЙЛАМИ.
        # Учасник подає на майданчик кожен документ окремо, а не один зведений
        # аркуш. Склад пакета оголошує ТОЙ, ХТО ЙОГО ЗІБРАВ; файли пише один
        # писар (`artifacts.write_document_files`) на здачі.
        try:
            _pack_docs = tender_skeleton.split_documents(final_markdown or "")
        except Exception as _e:
            _pack_docs = []
            llm._log("[executor] склад пакета не розбився: %s" % _e)
        # ⭐⭐⭐ 24.08.2026, зміна 208. ДОКАЗ ПРО СКЛАД ПАКЕТА — МАШИНОЧИТНИЙ.
        # Корінь (живий зрив у Каспера 24.08): пакет був СКЛАДЕНИЙ і ПІДТВЕРДЖЕНИЙ
        # нашими ж воротами (пропущено=0, без підстави=0), а суддя приймання
        # подивився на прочерки «______» і виніс «це не результат» — код викинув
        # увесь пакет, не написав жодного файлу і звелів мозку сказати клієнту
        # «роботи не зроблено». Тепер факт про склад пакета їде ЧИСЛАМИ поруч із
        # самим пакетом, і вирок про ТЕКСТ не скасовує ДОВЕДЕНИЙ склад.
        if _pack_docs:
            _pack_proof = {
                "documents": len(_pack_docs),
                "missing": len(_verdict.get("missing") or []),
                "no_source": len(_verdict.get("no_source") or []),
                "rows": int(_verdict.get("rows") or 0),
                "checklist": len(_chk or []),
            }
            llm._log("[executor] доказ складу пакета: документів=%d пропущено=%d "
                     "без підстави=%d рядків реєстру=%d"
                     % (_pack_proof["documents"], _pack_proof["missing"],
                        _pack_proof["no_source"], _pack_proof["rows"]))

    # ⭐⭐⭐ 10.08.2026. ЗАПОБІЖНИК БРЕХНІ — НА КЛАС, А НЕ НА ОДИН НОМЕР.
    # Раніше запобіжник (`source_trust`) накривав РІВНО номери закупівель Прозорро.
    # Живий прогін 09.08: система віддала таблицю з назвами кафе, адресами й
    # годинами роботи, НЕ відкривши жодного джерела. Ворота посилань не
    # спрацювали (глибоких URL у тексті не було) — і вигадка доїхала до людини.
    # Тепер судить ОДИН писар `fact_trust` — по КЛАСУ форми факту, і не «чи є
    # право», а «чи це справді було в тому, що платформа читала».
    _fact_corpus = list(_live_corpus)
    if files_context:
        _fact_corpus.append(files_context)          # документи людини — джерело!
    if task:
        _fact_corpus.append(task)                   # її ж слова — не «факт із джерела»
    if seo_page:
        _fact_corpus.append(seo_page)               # реальний витяг сторінки/двигуна
    # ⛔ `accumulated` У КОРПУС НЕ ЙДЕ — І ЦЕ ГОЛОВНЕ В ЦЬОМУ МІСЦІ.
    # Це напрацьоване САМИМИ АГЕНТАМИ, тобто текст моделі. Якби він був корпусом,
    # вигадана назва кафе «підтверджувала» б себе тим, що модель її написала —
    # запобіжник став би дзеркалом. Корпус — це ЛИШЕ те, що прийшло ЗЗОВНІ:
    # прочитані сторінки, документи людини, її задача, витяг двигуна.

    # ⛒⛒⛒ 620. СВІДЧЕННЯ ПРОГОНУ — ОДНЕ ОГОЛОШЕННЯ НА ВСІ ДВЕРІ.
    # Корпус вище відповідає на питання «чи був цей факт у прочитаному».
    # Питання про ЧИСЛО інше: мало знати, що воно десь було, — треба назвати
    # СТОРІНКУ, дослівний РЯДОК із неї і ДАТУ, інакше клієнтові немає чим
    # відповісти на «звідки ця цифра». Тому прочитане оголошується ІМЕНОВАНО
    # і їде далі незмінним: і в суд політики, і на двері файла.
    try:
        import number_trace as _ntr
        _svidchennya = _ntr.run_evidence(
            live_corpus=_live_corpus, files_context=files_context,
            seo_page=seo_page, task=task)
    except Exception as _esv:
        _svidchennya = None
        import sys as _ssv
        _ssv.stderr.write("[number_trace] свідчення не оголошено: %r\n" % (_esv,))

    # дедуплікація джерел
    seen, sources = set(), []
    for s in all_sources:
        u = (s or {}).get("url")
        if u and u not in seen:
            seen.add(u); sources.append({"title": s.get("title") or u, "url": u})

    # ⭐⭐⭐ 09.08.2026. ВОРОТА ПРОТИ ВИГАДАНИХ ПОСИЛАНЬ (живий провал у клієнта).
    # Система видала двох кандидатів із адресами work.ua/resumes/40123456 і
    # .../40234567 — послідовні круглі номери, яких вона НІКОЛИ не відкривала.
    # Позначка «не вдалося підтвердити» вже існувала, але вона лише ПОПЕРЕДЖАЛА,
    # а вигадка все одно доїжджала до людини як результат.
    # ⭐ ПОСИЛАННЯ, ЯКОГО ПЛАТФОРМА НЕ ВІДКРИВАЛА, — ЦЕ НЕ ДЖЕРЕЛО, А ВИГАДКА.
    # Правило детерміноване, без вгадування: беремо URL із тексту видачі і
    # звіряємо з РЕАЛЬНИМИ джерелами прогону (sources). Чого там немає — те не
    # має права виглядати як підтверджене посилання.
    _real = set()
    for _s in sources:
        _u = (_s or {}).get("url") or ""
        _real.add(_u.rstrip("/"))
    # ⭐ 10.08.2026, зміна 148 (знайдено ЖИВИМ прогоном). МЕЖА АДРЕСИ — НЕ ТІЛЬКИ
    # ПРОБІЛ. Сюди не входили зворотний апостроф і лапки, тому з `` `URL` `` regex
    # захоплював і ЗАКРИВАЛЬНИЙ апостроф. Після підміни в клієнта лишався
    # обірваний бектик — розмітка ламалась, і чесний запобіжник виглядав як
    # поломка. Запобіжник правильний; неправильною була межа токена.
    # ⛒⛒⛒ 596, 16.09.2026. СУДИМО ЦИТАТУ, А НЕ БУДЬ-ЯКУ АДРЕСУ В ТЕКСТI.
    # 🩸 ЖИВИЙ ПРОВАЛ 13.09.2026: у прогонi «зроби дашборд одним файлом» жодного
    # пошуку не було й бути не мало — задача була ЗIБРАТИ HTML. Але у зiбраному
    # кодi стояло звичайне посилання на бiблiотеку графiкiв; цi ворота порахували
    # його непiдтвердженим ДЖЕРЕЛОМ, i весь готовий результат замiнила вiдмова
    # «посилання не пiдтвердженi». Людина замiсть виробу дiстала чесне «не можу».
    # ⛒ Адреса всерединi блоку коду — деталь ВИРОБУ (скрипт, стиль, приклад), а
    # не твердження про свiт. Цитати живуть у прозi й у перелiку джерел — там
    # сторож лишається рiвно таким самим суворим.
    _judged_md = re.sub(r"```.*?```", "", final_markdown or "", flags=re.S)
    _in_text = netfetch.find_urls(_judged_md)
    _fake = []
    for _u in _in_text:
        if _u.rstrip("/") in _real:
            continue
        # головна сторінка домену — це не посилання на запис, її не судимо
        if _u.rstrip("/").count("/") <= 2:
            continue
        if _u not in _fake:
            _fake.append(_u)
    if _fake:
        for _u in _fake:
            final_markdown = (final_markdown or "").replace(
                _u, "[адресу приховано: платформа її НЕ відкривала]")
        _emit(emit, "⛔ Ворота джерел: %d посилань не підтверджено — прибрано з відповіді"
                    % len(_fake))
        import sys as _sf
        _sf.stderr.write("[sources] INVENTED LINKS in output (%d): %s\n"
                         % (len(_fake), "; ".join(_fake[:5])))
        # Якщо реального джерела НЕ БУЛО ЖОДНОГО, а видача спиралась на посилання —
        # уся робота стоїть на вигадці. Це не «результат із застереженням», а СТОП.
        if not _real:
            honest_stop = honest_stop or {
                "kind": "sources_invented",
                "reason": ("у відповіді були посилання, яких платформа не відкривала "
                           "(%s), а жодного справжнього джерела в цьому прогоні не було"
                           % "; ".join(_fake[:3])),
                "action": ("повторіть запит — платформа має вийти в інтернет і спертися "
                           "на справжні сторінки; якщо повториться, скажіть про це"),
            }
            final_markdown = (
                "## Не можу віддати цей результат: посилання не підтверджені\n\n"
                "У відповіді були адреси, яких платформа **не відкривала**, а жодного "
                "справжнього джерела в цьому прогоні не було. Це означає, що дані могли "
                "бути домислені моделлю, і віддавати їх як знайдені — обман.\n\n"
                "**Що зробити:** повторіть запит. Якщо повториться — скажіть, і причину "
                "знайдемо в журналі за цим часом.\n"
            )

    # ⭐⭐⭐ 10.08.2026. ЗАПОБІЖНИК БРЕХНІ НА КЛАС ФАКТІВ (не лише номери тендерів).
    # Тристанно, як і має бути: підтверджено / не підтверджено / ВИГАДАНО.
    #   • ВИГАДАНО (корпусу немає ЗОВСІМ, а факти класу «лише з джерела» подано) —
    #     це СТОП, той самий клас, що й вигадане посилання;
    #   • не підтверджено (корпус є, факту в ньому не видно) — чесна позначка,
    #     яку пише ПЛАТФОРМА, а не модель про себе.
    # Похідне (пораховані числа), власні реквізити й роботу з документів людини це
    # не чіпає: документи й задача — частина корпусу.
    try:
        import fact_trust as _ft
        _fv = _ft.verdict(final_markdown or "", _fact_corpus, opened_sources=len(sources))
    except Exception as _e:                       # запобіжник не сміє валити прогін
        _fv = None
        import sys as _sfe
        _sfe.stderr.write("[fact_trust] probe failed: %r\n" % (_e,))
    if _fv and _fv.get("invented") and not honest_stop:
        honest_stop = {
            "kind": "facts_without_source",
            "reason": _fv.get("reason") or "факти без жодного джерела",
            "action": ("повторіть запит — платформа має спертися на справжні сторінки "
                       "або на ваші документи; якщо повториться, скажіть про це"),
        }
        _emit(emit, "⛔ Ворота фактів: джерел не відкрито жодного — назв, адрес і "
                    "годин роботи не вигадую.")
        import sys as _sf2
        _sf2.stderr.write("[fact_trust] INVENTED FACTS, no corpus: %s\n"
                          % (_fv.get("reason") or ""))
        final_markdown = (
            "## Не можу віддати цей результат: дані нічим не підтверджені\n\n"
            "У відповіді були конкретні дані (назви, адреси, години роботи, контакти), "
            "які можна взяти **лише з джерела**, — а платформа в цьому прогоні не "
            "відкрила жодної сторінки і не мала ваших документів. Віддавати такі дані "
            "як знайдені означало б вигадати їх.\n\n"
            "**Що зробити:** повторіть запит (платформа має вийти в інтернет) або "
            "додайте файл із даними. Якщо повториться — скажіть, і причину знайдемо "
            "в журналі за цим часом.\n"
        )
    elif _fv and _fv.get("unverified"):
        _note = _ft.honest_note(_fv["unverified"])
        if _note and _note not in (final_markdown or ""):
            final_markdown = (final_markdown or "") + "\n\n" + _note + "\n"
            _emit(emit, "⚠ Частину даних не видно в прочитаних джерелах — позначено чесно.")

    # ⛒⛒⛒ 577. ДРУГИЙ ШАР: ЧИСЛО, ПІДПИСАНЕ НОРМАТИВОМ, МУСИТЬ БУТИ В МЕТОДИЦІ.
    # Ворота фактів вище судять дані, які можна взяти лише з джерела (адреси,
    # години). Норматив — інший клас: джерело в нього СВОЄ, методика системи, і
    # вона лежить поруч. 🩸 12.09.2026 у документ пішли 35 л/100 км «за нормативом
    # для важкого автопоїзда» (у методиці 32) і добові 250 замість 500 — обидва
    # підписані методикою, якої вони не бачили.
    try:
        _nbad = norms.audit(final_markdown or "", registry.system_root(system))
    except Exception as _en:
        _nbad = []
        import sys as _snb
        _snb.stderr.write("[norms] audit failed: %r\n" % (_en,))
    if _nbad:
        _seen, _list = set(), []
        for _b in _nbad:
            if _b["value"] in _seen:
                continue
            _seen.add(_b["value"])
            _list.append("%g" % _b["value"])
        _nnote = ("> ⚠ **Підписано нормативом, але в методиці цього немає** — "
                  + ", ".join(_list[:8])
                  + ". Ці числа подані як норматив системи, проте в методиці їх "
                    "немає. Перед використанням звірте з методикою або замініть на "
                    "свої з явним джерелом.")
        if _nnote not in (final_markdown or ""):
            final_markdown = (final_markdown or "") + "\n\n" + _nnote + "\n"
        _emit(emit, "⚠ Числа під підписом «норматив», яких немає в методиці: "
                    + ", ".join(_list[:6]))
        import sys as _sn2
        _sn2.stderr.write("[norms] fake norms: %s\n" % "; ".join(
            "%g <- %s" % (b["value"], b["line"][:80]) for b in _nbad[:6]))

    # ⛒⛒⛒ 578. ТРЕТІЙ ШАР: ВИКЛАДКА МУСИТЬ СХОДИТИСЬ ІЗ СВОЇМ ЧИСЛОМ.
    # 576 — число з памʼяті; 577 — своє число під чужим підписом; тут — своє
    # число під ВЛАСНОЮ викладкою, яка лежить поруч і дає інше. 🩸 12.09.2026,
    # рейс 2: «20 × 848,6 / 100 × 96,24» і поруч «16 420,10» замість 16 333,85
    # (86 грн), і «10,58 год» надруковано як «10 год 58 хв» замість 35 хв.
    # Калькулятор рахує на ЕТАПАХ, а у фінал числа переносить складальник —
    # між «порахували» і «надрукували» стояло лише прохання «переноси точно».
    # Прохання не є воротами. Тепер там стоїть суддя.
    try:
        _abad = arith.audit(final_markdown or "")
    except Exception as _ea:
        _abad = []
        import sys as _sab
        _sab.stderr.write("[arith] audit failed: %r\n" % (_ea,))
    if _abad:
        _seen_a, _rows = set(), []
        for _b in _abad:
            _key = (_b["printed"], round(_b["real"], 4))
            if _key in _seen_a:
                continue
            _seen_a.add(_key)
            _rows.append("«%s» дає %s, а надруковано %s"
                         % (_b["expr"], _fmt_ua(_b["real"]), _fmt_ua(_b["printed"]))
                         if _b["kind"] == "викладка" else
                         "%s: має бути %s хв, а надруковано %s хв"
                         % (_b["expr"], "%g" % _b["real"], "%g" % _b["printed"]))
        _anote = ("> ⚠ **Число не сходиться з викладкою, яка стоїть поруч** — "
                  + "; ".join(_rows[:6])
                  + ". Викладка поруч із числом — це запрошення не перевіряти, "
                    "тому розбіжність тут дорожча за звичайну помилку. Звірте ці "
                    "рядки перед тим, як віддавати документ.")
        if _anote not in (final_markdown or ""):
            final_markdown = (final_markdown or "") + "\n\n" + _anote + "\n"
        _emit(emit, "⚠ Викладка не сходиться зі своїм числом: " + "; ".join(_rows[:3]))
        import sys as _sa2
        _sa2.stderr.write("[arith] broken maths: %s\n" % "; ".join(
            "%s -> %s (надруковано %s)" % (b["expr"], b["real"], b["printed"])
            for b in _abad[:6]))

    # ⛒⛒⛒ 579. ЧЕТВЕРТИЙ ШАР: НАЗВАНИЙ НОРМАТИВ МУСИТЬ БРАТИ УЧАСТЬ У ЧИСЛАХ.
    # 576 — число з памʼяті; 577 — своє число під чужим підписом; 578 — своє
    # число під власною викладкою; тут — число, назване вихідними даними й НЕ
    # ВЖИТЕ В ЖОДНОМУ РОЗРАХУНКУ. 🩸 12.09.2026, рейс Дніпро → … → Дніпро:
    # «Норма витрати пального | 20,0 л/100 км (навантажений), 16,0 л/100 км
    # (порожній)», а весь пробіг 455,8 км порахований за навантаженою нормою.
    # Порожнє плече 73,2 км той самий документ називає розділом вище.
    # ⭐ Рядок таблиці вихідних даних — це обіцянка замовникові: цим числом
    # рахували, заміни його — і сума зміниться. Названий і не вжитий норматив
    # робить обіцянку порожньою, і замовник цього не побачить.
    try:
        _pbad = applied.audit(final_markdown or "")
    except Exception as _ep:
        _pbad = []
        import sys as _sap
        _sap.stderr.write("[applied] audit failed: %r\n" % (_ep,))
    if _pbad:
        _seen_p, _prows = set(), []
        for _b in _pbad:
            if _b["value"] in _seen_p:
                continue
            _seen_p.add(_b["value"])
            _prows.append("«%s»: %s" % (_b.get("label") or "показник",
                                        _b.get("what") or ("%g" % _b["value"])))
        _apnote = ("> ⚠ **Норматив названий, але в розрахунку не вжитий** — "
                   + "; ".join(_prows[:6])
                   + ". Ці числа стоять у вихідних даних як прийняті для "
                     "розрахунку, але в жодному числі документа участі не беруть. "
                     "Таблиця вихідних даних обіцяє замовникові, що цим числом "
                     "рахували і що досить підставити своє — і сума зміниться. "
                     "Застосуйте норматив або приберіть рядок.")
        if _apnote not in (final_markdown or ""):
            final_markdown = (final_markdown or "") + "\n\n" + _apnote + "\n"
        _emit(emit, "⚠ Норматив названий і не вжитий: " + "; ".join(_prows[:3]))
        import sys as _sp2
        _sp2.stderr.write("[applied] declared but unused: %s\n" % "; ".join(
            "%g <- %s" % (b["value"], b["line"][:80]) for b in _pbad[:6]))

    # ⛒⛒⛒ 612, ШАР 6. ПОЛІТИКА РЕЗУЛЬТАТУ: ТИП ДОКУМЕНТА НАЗИВАЄ СВОЇ ПЕРЕВІРКИ.
    # 576–579 — п'ять шарів про ЧИСЛА всередині будь-якого тексту. Тут інший
    # рівень: є документи, які мають ВЛАСНИЙ закон, і цей закон мусить питатись
    # у загальному шляху, а не лише там, де про нього згадав автор конвеєра.
    #
    # 🩸 ЖИВА ВАДА 19.09.2026: писар закону про комерційну пропозицію
    # (`kp_document`, 610) питали РІВНО ДВОЄ — власна проба і тренувальний
    # прогін. Чат, кнопка й розклад його не кликали жодного разу, тобто
    # перевірка була прив'язана до КОНВЕЄРА, а не до ТИПУ РЕЗУЛЬТАТУ.
    #
    # ⭐ ПЕРЕЗБІР — ОДИН І ДЕТЕРМІНОВАНИЙ, ліміт бере КОД із контракту
    # (`result_policy.REBUILD_LIMIT`), а не з голови автора шляху. Складальник
    # дістає СВОЇ Ж помилки дослівно; жодного нового числа код не вигадує і
    # тексту клієнта не переписує.
    try:
        import result_policy
        final_markdown = result_policy.clean(final_markdown or "",
                                             (system or {}).get("id") or "")
        _policy_verdict = result_policy.judge(final_markdown or "",
                                              (system or {}).get("id") or "",
                                              _svidchennya)
    except Exception as _erp:
        _policy_verdict = None
        import sys as _srp
        _srp.stderr.write("[result_policy] суд не відбувся: %r\n" % (_erp,))
    if _policy_verdict and _policy_verdict.get("findings"):
        # ⛒ Ліміт питається В ОДНОМУ МІСЦІ. Друга згадка числа — це другий
        # закон, який завтра розійдеться з першим.
        _may_rebuild = _policy_pass < result_policy.REBUILD_LIMIT
        _emit(emit, "⛔ Політика «%s»: розбіжностей %d — %s"
                    % (_policy_verdict.get("name"), len(_policy_verdict["findings"]),
                       "один перезбір" if _may_rebuild else "ліміт перезборів вичерпано"))
        import sys as _srp1
        _srp1.stderr.write("[result_policy] %s: %s\n"
                           % (_policy_verdict.get("policy"),
                              "; ".join(f.get("code", "") for f in _policy_verdict["findings"])))
        if _may_rebuild:
            _policy_rebuilt = run_system(
                actor, system,
                (task or "") + "\n\n" + result_policy.brief(_policy_verdict)
                + "\n\n--- ДОКУМЕНТ, ЯКИЙ ТРЕБА ПЕРЕЗІБРАТИ ---\n\n"
                + (final_markdown or ""),
                files_context=files_context, history=history, precheck=False,
                emit=emit, style=style, depth=depth, should_cancel=should_cancel,
                allow_real_build=allow_real_build, meta_mode=meta_mode,
                intent=intent, model_floor=model_floor,
                understanding=understanding, original=original,
                _policy_pass=_policy_pass + 1)
            # ⛒ Перезбір приймається лише тоді, коли він СПРАВДІ дав документ:
            # обірваний перезбір не сміє з'їсти роботу, за яку вже заплачено.
            if ((_policy_rebuilt or {}).get("status") == "completed"
                    and len(((_policy_rebuilt or {}).get("final_markdown") or "").strip()) >= 800):
                final_markdown = ((_policy_rebuilt or {}).get("final_markdown")
                                  or final_markdown)
                _emit(emit, "🔁 Документ перезібрано за вироком політики.")
    # ⛒ СУДИМО ЩЕ РАЗ — саме той текст, що поїде далі. Твердий вирок, який
    # пережив перезбір, СПИНЯЄ ВИДАЧУ: документ, що суперечить власним числам,
    # клієнтові не віддається. М'яка вада лишає видиму причину замовникові.
    try:
        import result_policy as _rp2
        _policy_after = _rp2.judge(final_markdown or "",
                                   (system or {}).get("id") or "", _svidchennya)
    except Exception:
        _policy_after = _policy_verdict
    if _policy_after and _policy_after.get("hard") and not honest_stop:
        # ⛒ ЗУПИНКА ЙДЕ В ОДНІ ДВЕРІ І НАЗИВАЄ СЕБЕ ЛІТЕРАЛОМ. Рід зупинки,
        # обраний під час роботи, невидимий для реєстру (`stop_register_test`
        # читає саме літерали) — а незареєстрована зупинка не пояснює себе
        # словами й не має ставки. Тому рід пишеться ТУТ, поруч із дверима.
        _policy_stop = result_policy.stop(_policy_after)
        _emit(emit, "⛔ Видачу спинено: документ не сходиться сам із собою.")
        return honest_stop_result(
            system, kind="result_policy",
            reason=_policy_stop.get("reason") or "",
            action=_policy_stop.get("action") or "",
            markdown=final_markdown, intent=intent, plan=plan, trace=trace,
            route_engine=route_diag, conditions=cond_diag,
            web_invariant_gap="; ".join(web_gaps))
    elif _policy_after and _policy_after.get("soft"):
        _pnote = result_policy.note(_policy_after)
        if _pnote and _pnote not in (final_markdown or ""):
            final_markdown = (final_markdown or "") + "\n\n" + _pnote + "\n"
            _emit(emit, "⚠ Зауваження до документа позначено — %d."
                        % len(_policy_after["soft"]))

    # ⛒ 620. ПРОСТЕЖЕНЕ ЧИСЛО ТЕЖ МУСИТЬ БУТИ ВИДНО. Сторож, який кричить
    # лише на ваду, не дає замовникові головного — упевненості, що решта чисел
    # має адресу. Один рядок у чат; повний ланцюг — у журнал прогону.
    try:
        _tr_rows = _ntr.trace(final_markdown or "", _svidchennya)
        _tr_line = _ntr.korotko(_tr_rows)
        if _tr_line:
            _emit(emit, _tr_line)
            import sys as _str2
            _str2.stderr.write("[number_trace]\n%s\n" % _ntr.explain(_tr_rows))
    except Exception:
        pass

    # ⛒⛒⛒ 585, ШАР 5. ЗАСТИГЛА КОПІЯ НЕ ВДАЄ ЖИВУ ПЛАТФОРМУ.
    # Скопійована тека працює й виглядає як оригінал — доки не порівняти числа.
    # Оригінал щотижня дістає нові ворота фактів і виправлені нормативи; копія
    # рахує тим, що вже вилікувано, і замовник цього НЕ БАЧИТЬ.
    # ⛒ Рядок ставить ПЛАТФОРМА і лише тоді, коли копія СПРАВДІ відстала:
    # свіжа мовчить, та, що старіє, теж. Лякати чесного клієнта не можна.
    try:
        import freshness
        _frnote = freshness.note()
        if _frnote and _frnote not in (final_markdown or ""):
            final_markdown = (final_markdown or "") + "\n\n" + _frnote + "\n"
    except Exception as _efr:
        import sys as _sfr
        _sfr.stderr.write("[freshness] вік копії не перевірено: %s\n" % _efr)

    # ⭐⭐⭐ 01.08.2026. ОДНА ТОЧКА, ДЕ ЗАСТЕРЕЖЕННЯ ПРО НЕВИКОНАНУ
    # ПЕРЕВІРКУ ПОТРАПЛЯЄ В РЕЗУЛЬТАТ. Пише ПЛАТФОРМА, не модель: прохання
    # до моделі «напиши це сама» — це прохання, а не ворота.
    if _gate_degraded:
        final_markdown = _gate_degraded_note(_gate_degraded) + (final_markdown or "")

    # СВІДОМИЙ СТОП НА ЗДАЧІ (жива Excel-модель не зібралась): статус мусить
    # називати себе стопом, а не завершенням — ті самі одні двері, що й вище.
    if honest_stop:
        return honest_stop_result(
            system, kind=honest_stop.get("kind") or "financial_model",
            reason=honest_stop.get("reason") or "", action=honest_stop.get("action") or "",
            markdown=final_markdown, intent=intent, plan=plan, trace=trace,
            route_engine=route_diag, conditions=cond_diag,
            web_invariant_gap="; ".join(web_gaps))

    return {
        "status": "completed",
        "final_markdown": final_markdown,
        "assembler_ok": assembler_ok,
        "honest_stop": honest_stop,
        "agent_trace": trace,
        "system_id": system.get("id"),
        "needs_calc": needs_calc,
        "intent": intent,
        "revisions": revisions,
        "understanding": plan.get("system_understanding", ""),
        "success_criteria": plan.get("success_criteria", []),
        "sources": sources,
        # ⛒ 620. Що платформа читала — їде разом із результатом: двері файла
        # інакше судили б наосліп (і саме так і судили до 620).
        "evidence": _svidchennya,
        "web_invariant_gap": "; ".join(web_gaps),
        "route_engine": route_diag,   # для систем маршрутів: точна причина, чому шлях є/нема
        "conditions": cond_diag,      # слід живого веб-пошуку умов (обмеження в'їзду)
        "mode": system.get("orchestration_mode", "sequential"),
        "documents": _pack_docs,          # склад пакета: по одному файлу на документ
        "pack_proof": _pack_proof,        # доказ складу: числа НАШИХ воріт, не думка судді
        # ⭐ 10.08.2026, зміна 145. МЕЖА ПОВНОВАЖЕНЬ — ВОРОТАМ ЯКОСТІ.
        # Без неї суддя вимагав заповнених бланків замовника, тобто ВИГАДАНИХ
        # цін, і завалював будь-який пакет. Межу пише КОД, а не план моделі.
        "judge_scope": (tender_pack.judge_scope_note()
                        if (system or {}).get("id") == tender_pack.SYSTEM_ID else ""),
    }

# (кінець executor.py)
