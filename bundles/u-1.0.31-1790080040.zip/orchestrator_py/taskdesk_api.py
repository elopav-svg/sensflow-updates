# -*- coding: utf-8 -*-
"""
taskdesk_api.py — ТОНКИЙ ШАР МІЖ КОНСОЛЛЮ І ЯДРОМ TASK DESK (крок 1.4).

`server.py` лишається транспортом: він приймає запит, питає ворота «хто це» і
віддає сюди. Уся логіка дій живе тут, в ОДНІЙ таблиці дій. Так новий екран не
може винайти собі власний шлях повз перевірки — таблиця одна.

ТРИ ПЕРЕВІРКИ, ЯКІ ПРОХОДИТЬ КОЖНА ДІЯ:
  1. **вимикач роботи** — поки Task Desk не ввімкнений, тут не працює нічого;
  2. **адміністратор** — оргструктуру й доступи веде лише він;
  3. **дія з таблиці** — невідома назва дії не виконується, а називається.
Відмова завжди має причину словами: тиха відмова = вимкнені ворота.
"""

import features
import clock                       # ОДИН ПИСАР ЧАСУ на весь продукт
import entity                      # спільне ІМʼЯ людини й речі
import protocol                    # спільний ЖУРНАЛ усіх дій
import taskdesk_identity as identity
import taskdesk_intake as intake   # розбір одного рядка: хто · коли · що
import taskdesk_links as tlinks    # словник і формулювання звʼязків (зміна 172)
import taskdesk_mirror as mirror   # ОДИН читач журналу подій (зміна 379)
import taskdesk_ai as ai
import taskdesk_export as export
import taskdesk_fields as fields
import taskdesk_people as people
import taskdesk_worktypes as worktypes
import taskdesk_prefs as prefs
import taskdesk_roles as roles
import taskdesk_org_chart as org_chart
import taskdesk_tasks as tasks
import taskdesk_telegram as mouth

WORK_ID = "taskdesk"


class ApiError(Exception):
    def __init__(self, message, status=400, code="taskdesk_error"):
        Exception.__init__(self, message)
        self.status = status
        self.code = code


def enabled() -> bool:
    """ЄДИНА відповідь «чи Task Desk увімкнений». Поки робота не завершена, вона
    їде клієнту вимкненою — це вимога воріт складу релізу."""
    return features.enabled(WORK_ID)


def _require_enabled():
    if not enabled():
        raise ApiError("Task Desk у цій збірці вимкнений.", 403, "taskdesk_off")


def _require_admin(actor):
    """Оргструктуру й доступи веде адміністратор.

    Поки вхід не вимагається (одноосібний клієнт, як Каспер сьогодні), господар
    машини і є адміністратор — так само, як у решті консолі. Щойно людей стає
    двоє, вхід обовʼязковий, і тут уже потрібен саме адміністратор."""
    if not identity.login_required():
        return
    if not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    if not actor.get("is_admin"):
        raise ApiError("Ці налаштування веде адміністратор.", 403, "admin_only")


# ---------------------------------------------------------------------------
# ЧИТАННЯ
# ---------------------------------------------------------------------------
def people_state(actor) -> dict:
    """⭐ РІШЕННЯ АНДРІЯ 08.08.2026: розділ «Люди» — це ДОВІДНИК компанії, а не
    панель адміністратора. Колега має знайти телефон колеги, не питаючи нікого.

    Тому дивляться ВСІ, а от ВЕДЕ структуру адміністратор. Різниця не в тому,
    що показати, а в тому, що можна: інструменти й службовий журнал змін їдуть
    лише адміністратору. Екран їх не ховає «про всяк випадок» — він їх просто
    не отримує, і намалювати кнопку, якої немає, не може."""
    _require_enabled()
    # ⭐ «Відкрито всім працівникам» не означає «відкрито нікому»: коли вхід
    # обовʼязковий, довідник компанії бачить лише впізнана людина.
    if identity.login_required() and not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    adm = _is_admin(actor)
    st = people.load()
    # ⛒ Підрозділи їдуть УСІ — так само, як і працівники разом зі звільненими.
    # Ховає ліквідованих сам екран, за тією ж галочкою; а списки ВИБОРУ беруть
    # `people.units()`, який ліквідованих не віддає.
    out = {"units": st["units"], "positions": st["positions"],
           "employees": st["employees"],
           # ⭐ Горизонти бачать УСІ (це видимий орієнтир структури), а веде їх
           # адміністратор — як і всю оргструктуру на цьому екрані.
           "horizons": st["horizons"], "horizon_numbers": list(people.HORIZON_NUMBERS),
           "unreadable_reason": st.get("unreadable_reason", ""),
           # ⭐ Один писар «хто я тут» — екран не здогадується за виглядом даних.
           "rights": {"is_admin": adm, "me": _me(actor),
                      "may_manage": adm,
                      # ⭐ Ліквідація — рішення власника, а не адміністратора.
                      # Один писар цієї відповіді: екран не здогадується сам.
                      "may_liquidate": _may_liquidate(actor),
                      # ⛒ Кнопка в нікуди гірша за її відсутність: екран питає,
                      # а не вгадує, чи відкриється історія цій людині.
                      "may_see_history": _may_see_history(actor),
                      # ⛒ Те саме питання про дзеркало — і та сама відповідь,
                      # що й у воротах дії: другої тут не заводимо.
                      "may_see_mirror": _may_see_mirror(actor)}}
    if adm:
        out["audit"] = st["audit"][-30:]
    return out


def _may_liquidate(actor) -> bool:
    """Чи МОЖНА цій людині ліквідувати підрозділ — та сама умова, що й у
    воротах дії. Друга відповідь у другому місці розійшлася б із першою."""
    try:
        _require_top_manager(actor)
        return True
    except ApiError:
        return False


# ── ІСТОРІЯ ЗМІН КОМПАНІЇ (зміна 364, 30.08.2026) ───────────────────────────
# ⭐ ТРИ ЧЕСНІ ВІДПОВІДІ НА «ХТО ЦЕ ЗРОБИВ», І ЖОДНОЇ ЗАЙВОЇ (зміна 375).
# Четвертого («господар платформи») тут був: живий прогін показав, що продукт
# його не народжує — ворота консолі завжди називають того, хто діє, а в
# одноосібному режимі це ВЛАСНИК, і в рядку стоїть саме його імʼя.
WHO_UNKNOWN = "unknown"          # старий запис: автора тоді не вели
WHO_SYSTEM = "system"            # зроблено НЕ через екран: обслуговування, автоматика
WHO_PERSON = "person"            # названа людина (у одноосібному режимі — Власник)

WHO_WORDS = {
    WHO_UNKNOWN: "невідомо — запис зроблено до того, як платформа почала "
                 "запамʼятовувати автора",
    WHO_SYSTEM: "сама платформа, не через екран",
}

HISTORY_PAGE = 100               # скільки рядків віддаємо за раз
HISTORY_PAGE_MAX = 500


def _may_see_history(actor) -> bool:
    """Чи МОЖНА цій людині дивитись історію компанії. Одна відповідь на це
    питання — саме тут; екран її лише питає."""
    if _is_admin(actor):
        return True
    return _may_liquidate(actor)


def _require_history_reader(actor):
    if _may_see_history(actor):
        return
    if identity.login_required() and not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    raise ApiError("Історію змін компанії дивляться старший керівник і "
                   "адміністратор.", 403, "not_allowed")


def _who_of(row: dict) -> tuple:
    """(вид автора, підпис) для рядка протоколу. ОДИН писар цієї відповіді."""
    who = str(row.get("actor") or "").strip()
    if who:
        # ⛒ Імʼя дістаємо в `entity` — єдиного писаря людських назв. Другий
        # словник імен розійшовся б із першим уже наступного місяця.
        try:
            return WHO_PERSON, (entity.title(who) or who)
        except Exception:
            return WHO_PERSON, who
    # Імені немає — і вигадувати його не можна. Через екран зміна без автора
    # не проходить: ворота консолі завжди кажуть, хто діє. Отже, це зміна
    # ПОЗА екраном, і саме так ми її й називаємо.
    return WHO_SYSTEM, WHO_WORDS[WHO_SYSTEM]


def _history_rows() -> list:
    """УСЯ історія компанії, свіжіше — зверху. Два джерела, дві ЕПОХИ, а не два
    писарі: старий список заморожений і більше не росте (зміна 361)."""
    out = []
    seq = 0
    for r in protocol.read():
        if str(r.get("action") or "") not in protocol.ORG_ACTIONS:
            continue
        seq += 1
        kind, words = _who_of(r)
        subj = str(r.get("subject") or "")
        try:
            about_what = entity.human(subj) if subj else ""
        except Exception:
            about_what = subj
        out.append({
            "seq": seq,
            "at": str(r.get("at") or ""),
            "what": str(r.get("note") or "")
                    or protocol.ACTIONS.get(str(r.get("action")), ""),
            "action": str(r.get("action") or ""),
            "action_name": protocol.ACTIONS.get(str(r.get("action")), ""),
            "about": about_what,
            "who_kind": kind, "who": words,
        })
    for a in people.legacy_audit():
        out.append({
            # ⛒ Старий, заморожений слід порядку запису не має і вже не матиме.
            # Він увесь із давнішої епохи, тому нуль тут нічого не переставляє.
            "seq": 0,
            "at": str(a.get("at") or ""), "what": str(a.get("what") or ""),
            "action": "", "action_name": "", "about": "",
            "who_kind": WHO_UNKNOWN, "who": WHO_WORDS[WHO_UNKNOWN],
        })
    # ⭐ ДРУГИЙ КЛЮЧ — ПОРЯДОК ЗАПИСУ. Час у продукті з точністю до секунди, а
    # людина за секунду встигає зробити кілька змін поспіль. Без другого ключа
    # такі рядки лягали б у зворотному порядку до всього іншого списку.
    out.sort(key=lambda r: (r["at"], r["seq"]), reverse=True)
    for r in out:
        r.pop("seq", None)
    return out


def history_state(actor, query: str = "", since: str = "", until: str = "",
                  limit: int = HISTORY_PAGE, offset: int = 0) -> dict:
    """ЩО БАЧИТЬ ЛЮДИНА НА ЕКРАНІ ІСТОРІЇ ЗМІН КОМПАНІЇ.

    ⚠ ЧЕСНА МЕЖА: журнал читається цілком на кожен запит. За три тижні роботи
    платформи він важить 150 КБ — тобто років на десять запасу; коли впреться,
    лікуватимемо читанням із кінця, а не стелею на записи."""
    _require_enabled()
    _require_history_reader(actor)
    rows = _history_rows()
    total_all = len(rows)
    q = str(query or "").strip().lower()
    d1, d2 = str(since or "").strip()[:10], str(until or "").strip()[:10]
    if d1:
        rows = [r for r in rows if r["at"][:10] >= d1]
    if d2:
        rows = [r for r in rows if r["at"][:10] <= d2]
    if q:
        rows = [r for r in rows
                if q in r["what"].lower() or q in r["who"].lower()
                or q in r["about"].lower()]
    try:
        lim = max(1, min(int(limit or HISTORY_PAGE), HISTORY_PAGE_MAX))
    except Exception:
        lim = HISTORY_PAGE
    try:
        off = max(0, int(offset or 0))
    except Exception:
        off = 0
    return {"rows": rows[off:off + lim], "found": len(rows), "total": total_all,
            "offset": off, "limit": lim,
            "query": str(query or ""), "since": d1, "until": d2,
            "rights": {"may_see": True, "is_admin": _is_admin(actor)}}


# ── ДЗЕРКАЛО КЕРІВНИКА (зміна 388, 30.08.2026) ──────────────────────────────
# ⚖ Слово Андрія 30.08: дзеркало — ОКРЕМА ПЛАТНА позиція, показники — як у
# розділі 5 записки. Числа рахує ОДИН читач `taskdesk_mirror`; тут — лише
# питання «кому це видно».
MIRROR_DAYS = (7, 30, 90)


def _may_see_mirror(actor) -> bool:
    """Чи МОЖНА цій людині дивитись дзеркало. Одна відповідь — саме тут.

    ⛒ Рахуємо з ДЕРЕВА: дзеркало показує роботу підлеглих, отже дивиться той,
    у кого підлеглі є. Адміністратор бачить компанію."""
    if _is_admin(actor):
        return True
    me = _me(actor)
    if not me:
        return False
    try:
        return bool(people.subordinates_of(me))
    except Exception:
        return False


def _require_mirror_reader(actor):
    if _may_see_mirror(actor):
        return
    if identity.login_required() and not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    raise ApiError("Дзеркало показує роботу підлеглих — його дивляться "
                   "керівники й адміністратор. У вас підлеглих немає.",
                   403, "not_allowed")


def mirror_state(actor, days=0) -> dict:
    """ЩО БАЧИТЬ КЕРІВНИК У ДЗЕРКАЛІ.

    ⚠ Тут навмисно НЕМАЄ знеособлення: воно живе в читачі, і назовні їде інший
    зріз. Цей екран лишається ВДОМА, дані з нього нікуди не йдуть."""
    _require_enabled()
    _require_mirror_reader(actor)
    try:
        d = int(days or 0)
    except Exception:
        d = 0
    if d not in MIRROR_DAYS:
        d = MIRROR_DAYS[1]
    out = mirror.named(_me(actor), _is_admin(actor), d)
    out["days_options"] = list(MIRROR_DAYS)
    out["rights"] = {"may_see": True, "is_admin": _is_admin(actor)}
    return out


def _fold_list(raw) -> list:
    """Перелік гілок з адреси: «e1,e2,e3». Чужого сюди не проходить — усе, чого
    немає серед працівників, малювальник далі й сам відкине, але межу довжини
    ставимо тут: адреса не сміє бути важелем навантаження на сервер."""
    if not raw:
        return []
    parts = [p.strip() for p in str(raw).replace(" ", ",").split(",")]
    return [p for p in parts if p][:_FOLD_MAX]


_FOLD_MAX = 400   # стільки гілок людина фізично не натисне; далі — не наш клієнт


def structure_state(actor, fold=None, open_=None) -> dict:
    """ЩО БАЧИТЬ ЛЮДИНА НА ЕКРАНІ СТРУКТУРИ КОМПАНІЇ.

    ⚖ Рішення Андрія 30.08.2026: дивляться УСІ працівники — кожен має бачити,
    до кого йти з питанням і хто з ним нарівні. Веде структуру адміністратор,
    і саме тому екран каже, КУДИ йти по зміни, а не малює кнопок, яких у
    людини немає.

    ⛒ Розкладку рахує малювальник на сервері; екран лише малює."""
    _require_enabled()
    if identity.login_required() and not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    st = people.load()
    return {"chart": org_chart.layout(fold=_fold_list(fold),
                                      open_=_fold_list(open_)),
            # Легенда горизонтів: номер і колір, більше в горизонта нічого
            # немає — назв у них немає свідомо.
            "horizons": st["horizons"],
            "unreadable_reason": st.get("unreadable_reason", ""),
            "rights": {"is_admin": _is_admin(actor), "may_manage": _is_admin(actor)}}


def employee_card(actor, emp_id: str) -> dict:
    """Картку ЧИТАЄ кожен працівник — це довідник компанії (рішення Андрія
    08.08.2026). А от ПРАВИТИ можна лише те, що дозволяє `people.card_rights()`:
    свої контакти — сама людина, місце в компанії — адміністратор."""
    _require_enabled()
    adm = _is_admin(actor)
    me = _me(actor)
    emp_id = str(emp_id or "").strip()
    card = people.card(emp_id)
    if not card:
        raise ApiError("Такого працівника немає.", 404, "not_found")
    # ⭐ Права їдуть РАЗОМ із карткою: екран малює лише те, що людині належить.
    # Кнопка, яка відмовить, бреше не менше за її відсутність.
    card["rights"] = people.card_rights(me, emp_id, adm)
    # ⭐ СТАН КАНАЛУ ЇДЕ РАЗОМ ІЗ КАРТКОЮ, як і права: екран не здогадується,
    # підключений телеграм чи ні, і не малює кнопку, за якою нічого немає.
    card["telegram"] = _telegram_state(emp_id)
    # ⭐ Список людей для вибору делегата їде лише тому, хто справді може
    # заводити відсутність. Порожній вибір під забороненою дією — та сама
    # кнопка, що відмовить.
    if card["rights"].get("absence"):
        card["people"] = [{"id": e["id"], "name": e.get("full_name") or e["id"]}
                          for e in people.employees() if e["id"] != emp_id]
    if adm:
        card["units"] = [{"id": u["id"], "name": u.get("name") or u["id"]}
                         for u in people.units()]
        card["positions"] = [{"id": p["id"], "name": p.get("name") or p["id"]}
                             for p in people.positions()]
        # Вибрати можна лише ЗАВЕДЕНИЙ горизонт: список порожній, поки жодному
        # номеру не дали кольору — і кнопки, за якою нічого немає, не буде.
        card["horizons"] = [dict(h) for h in people.load()["horizons"]]
    return card


def _acc_of(emp_id: str) -> dict:
    """Обліковий запис працівника. Немає запису — немає й каналу: бот упізнає
    людину лише через вхід у платформу."""
    acc = identity.account_of_employee(str(emp_id or "").strip())
    if acc is None:
        raise ApiError("У цього працівника немає облікового запису, тож "
                       "підключати телеграм нема до чого. Це заводить адміністратор "
                       "у розділі «Доступи».", 400, "no_account")
    return acc


def _telegram_state(emp_id: str) -> dict:
    """Чи є в людини канал і чи взагалі є куди підключатись.

    ⭐ `available` — це чесність екрана: якщо в клієнта не заведений бот задач
    (закритий контур або просто ще не завели), кнопки не буде взагалі, а не
    буде кнопки, яка відмовить."""
    import taskdesk_telegram as mouth
    out = {"available": mouth.enabled(), "bot": mouth.bot_username(),
           "linked": False, "code": "", "expires_at": "", "has_account": False}
    acc = identity.account_of_employee(str(emp_id or "").strip())
    if acc is None:
        return out
    out["has_account"] = True
    out.update(identity.telegram_state(acc["id"]))
    return out


def roles_state(actor) -> dict:
    """ЩО БАЧИТЬ АДМІНІСТРАТОР НА ЕКРАНІ ПРАВ.

    ⛒ «Яка роль у людини НАСПРАВДІ» рахує сервер (`role_of`), а не сторінка:
    правило «особисте → підрозділ деревом угору → за замовчуванням» мусить мати
    одного писаря, інакше екран через місяць показуватиме своє."""
    _require_enabled()
    _require_admin(actor)
    m = roles.matrix()
    m["units"] = [{"id": u["id"], "name": u.get("name", ""),
                   "parent_id": u.get("parent_id", "")} for u in people.units()]
    m["employees"] = [{"id": e["id"], "name": e.get("full_name", ""),
                       "unit_id": e.get("unit_id", "")} for e in people.employees()]
    m["effective"] = {e["id"]: (roles.role_of(e["id"]) or {}).get("id", "")
                      for e in people.employees()}
    return m


def worktypes_state(actor) -> dict:
    """ЩО БАЧИТЬ АДМІНІСТРАТОР НА ЕКРАНІ ТИПІВ РОБОТИ.

    ⛒ Побитий файл довідника не ховається: причина їде на екран словами, бо
    інакше людина побачить порожній список і вирішить, що її роботу стерли."""
    _require_enabled()
    _require_admin(actor)
    st = worktypes.load()
    return {"types": st["types"],
            "unreadable_reason": st.get("unreadable_reason", ""),
            "advised_points": worktypes.ADVISED_POINTS}


def accounts_state(actor) -> dict:
    _require_enabled()
    _require_admin(actor)
    import registry
    try:
        systems = [{"id": s.get("id"), "name": s.get("name") or s.get("id")}
                   for s in (registry.load_systems() or [])]
    except Exception:
        systems = []
    return {"accounts": identity.accounts(),
            "employees": people.employees(),
            "systems": systems,
            "login_required": identity.login_required(),
            "light_mode": identity.light_mode()}


def photo_set(actor, emp_id: str, data_url: str) -> dict:
    """Фото приходить із браузера рядком «data:image/png;base64,...».
    Розбираємо його ТУТ, а ядро отримує вже байти — воно не мусить знати про веб."""
    _require_enabled()
    rights = people.card_rights(_me(actor), emp_id, _is_admin(actor))
    if not rights["photo"]:
        raise ApiError("Фото ставить сама людина або адміністратор.", 403, "not_allowed")
    raw_b64 = str(data_url or "")
    if "," in raw_b64:
        raw_b64 = raw_b64.split(",", 1)[1]
    import base64
    try:
        raw = base64.b64decode(raw_b64, validate=True)
    except Exception:
        raise ApiError("Файл не прочитався — спробуйте інший.", 400, "bad_photo")
    try:
        return {"ok": True, "result": people.set_photo(emp_id, raw)}
    except people.PeopleError as e:
        raise ApiError(str(e), 400, "refused")


def photo_get(actor, emp_id: str) -> tuple:
    _require_enabled()
    _require_admin(actor)
    raw, mime = people.photo_bytes(emp_id)
    if not raw:
        raise ApiError("Фото немає.", 404, "no_photo")
    return raw, mime


# ---------------------------------------------------------------------------
# ЗАДАЧІ. Тут інші ворота, ніж в оргструктурі: задачі веде НЕ адміністратор,
# а сам працівник. Тому питаємо не «чи ти адмін», а «хто ти» — і далі все
# вирішує ОДНА функція видимості з `taskdesk_tasks`.
# ---------------------------------------------------------------------------
def _is_admin(actor) -> bool:
    """⭐ ОДНА відповідь «чи ця людина адміністратор» — та сама умова, що й у
    `_require_admin`: поки вхід не вимагається, господар машини і є адміністратор.
    Друга відповідь у другому місці розійшлася б із першою."""
    return identity.is_admin(actor)


def _me(actor) -> str:
    """Хто дивиться. ОДНА відповідь; порожньо — коли людина не впізнана."""
    return str((actor or {}).get("employee_id") or "").strip()


def _require_actor(actor):
    """ХТО ДІЄ — і якщо ніхто, то СКАЗАТИ, ЩО РОБИТИ, а не просто «ні».

    ⭐⭐⭐ 24.08.2026. Тут був глухий кут для щойно відкритого клієнта: у
    порожній платформі актор — ВЛАСНИК без картки працівника, і екран задач
    казав йому «Увійдіть під своїм працівником». Увійти нема під ким: людей ще
    не заводили. «Порожньо» і «не впізнано» — РІЗНІ стани, і плутати їх
    означає посилати людину не туди.
    """
    if not actor:
        raise ApiError("Не видно, хто ви. Увійдіть під своїм працівником.",
                       401, "login_required")
    emp = str(actor.get("employee_id") or "").strip()
    if not emp:
        st = people.setup_state("")
        raise ApiError(st["hint"], 409, st["code"])
    return emp


SCOPE_NAMES = {"all": "усі видимі", "mine": "мої", "i_set": "я поставив",
               "overdue": "протерміновані"}


def _desk(actor, scope, show_closed, flt=None, use_saved=True, query="",
          show_archive=False):
    """ОДИН збирач того, що людина бачить на екрані задач. І список, і дошка, і
    вивантаження виходять ЗВІДСИ — тому файл не може розійтися з екраном."""
    me = _require_actor(actor)
    my = prefs.load(me)
    flt = my["filter"] if (flt is None and use_saved) else (flt or {})
    ctx = fields.context()
    try:
        # ⭐⭐⭐ ОДНІ ВОРОТА НА ОБИДВА ЗВУЖЕННЯ: спершу фільтр, потім пошук — і
        # обидва всередині ОДНОГО `narrow`. Тому перевірка `board()` «фільтр не
        # має права додавати задач» накриває й пошук: другого шляху до списку
        # немає фізично, а не за домовленістю.
        data = tasks.board(me, scope=scope, show_closed=show_closed,
                           show_archive=show_archive,
                           narrow=lambda lst: fields.search_narrow(
                               fields.apply_filter(lst, flt, ctx), query, ctx))
    except fields.FieldError as e:
        raise ApiError(str(e), 400, "bad_filter")
    except tasks.TaskError as e:
        raise ApiError(str(e), 400, "refused")
    flat = [t for c in data["columns"] for t in c["tasks"]]
    # ⭐ НАЗВУ ПРОЄКТУ РАХУЄ ОДИН ПИСАР — той самий, що пише її в картку, у
    # фільтр і у файл. Сторінка не збирає назву сама зі свого переліку: там
    # немає ні видалених проєктів, ні чужих, і дошка мовчала б там, де має
    # сказати «проєкт видалено».
    for _t in flat:
        _t["project_name"] = tasks.project_name(_t.get("project_id") or "")
    # ⭐⭐⭐ ПОРЯДОК РАХУЄТЬСЯ ОДИН РАЗ І НА ВСЕ: список, дошка і xlsx не мають
    # права розійтися. Тому сортувальник кличеться РІВНО ТУТ, а колонки дошки
    # лише переставляються за вже порахованим порядком.
    srt = my.get("sort") or {}
    if srt.get("field"):
        try:
            flat = fields.sort_rows(flat, srt["field"], srt.get("desc"), ctx)
        except fields.FieldError as e:
            raise ApiError(str(e), 400, "bad_sort")
        order = {t["id"]: i for i, t in enumerate(flat)}
        for c in data["columns"]:
            c["tasks"].sort(key=lambda t: order[t["id"]])
    return me, my, ctx, flt, data, flat


def board_state(actor, scope: str = "all", show_closed: bool = False,
                flt=None, query: str = "", fresh: bool = False,
                show_archive: bool = False) -> dict:
    _require_enabled()
    # ⭐ Набір за замовчуванням ставиться ЛИШЕ на вході на екран (`fresh`),
    # а не на кожен запит: інакше він скидав би фільтр людині під руками
    # щоразу, коли вона щось шукає.
    if fresh:
        try:
            prefs.apply_default(_require_actor(actor))
        except prefs.PrefsError:
            pass
    me, my, ctx, flt, data, flat = _desk(actor, scope, show_closed, flt,
                                        query=query, show_archive=show_archive)
    # Екран каже людині, що архів існує і скільки в ньому лежить.
    data["archive_total"] = tasks.archive_count()
    data["archive_on"] = bool(show_archive)
    cols = my["columns"]
    data["me"] = {"id": me, "name": people.employee(me).get("full_name", "")}
    data["people"] = [{"id": e["id"], "name": e.get("full_name", "")}
                      for e in people.employees()]
    # ⭐ Панель створення теж має вибрати тип роботи — з того самого списку.
    data["worktypes"] = [{"id": w["id"], "name": w["name"]}
                         for w in worktypes.types()]
    # ⭐ І проєкти — тим самим шляхом. Перелік рівно той, який людині НАЛЕЖИТЬ:
    # право рахує Task Desk по дереву компанії, а не сторінка своїм «якщо».
    data["projects"] = tasks.projects_for(me, _is_admin(actor))
    # ⭐ Рядки списку рахує РЕЄСТР, а не сторінка: інакше екран став би другим
    # форматувальником і розійшовся б із файлом xlsx.
    data["fields"] = fields.catalogue()
    data["columns_all"] = [f["id"] for f in fields.FIELDS]
    data["columns_used"] = cols
    data["heads"] = [fields.field(c)["label"] for c in cols]
    data["rows"] = [{"id": t["id"], "overdue": bool(t["overdue"]),
                     "cells": fields.row(t, cols, ctx)} for t in flat]
    # ⭐ Кожна картка несе СВОЇ права — з тієї самої таблиці, що й картка задачі.
    # Без цього перетягування мишею вирішувало б саме, куди можна кинути, і
    # стало б другим писарем прав.
    adm = _is_admin(actor)
    for t in flat:
        t["may"] = tasks.rights(t, me, adm)
    data["filter"] = flt
    data["filter_options"] = fields.options(flat, ctx)
    data["views"] = [{"id": v["id"], "name": v["name"]} for v in my["views"]]
    data["view_id"] = my["view_id"]
    # ⭐ ПОШУК — ТРЕТЄ ПИТАННЯ ЕКРАНА, і він НЕ ЗБЕРІГАЄТЬСЯ в налаштуваннях:
    # «де та задача про оплату» — питання на півхвилини, а не вигляд списку.
    # Але екран мусить КАЗАТИ, що він звужений — тому запит йде назад.
    data["query"] = str(query or "")
    data["search_hint"] = fields.SEARCH_HINT
    # ⭐ Готові набори рахує ОДИН писар наборів, а не сторінка: інакше
    # екран знав би імена полів від себе й розійшовся б із реєстром.
    data["presets"] = prefs.presets(me)
    data["sort"] = my.get("sort") or {"field": "", "desc": False}
    data["default_view_id"] = my.get("default_view_id") or ""
    # ⭐ ВЛАДА НЕ СМІЄ БУТИ ТИХОЮ, а правда про вигляд — теж влада: екран каже,
    # чиї зараз колонки — свої чи компанійські, і хто задав компанійські.
    data["is_admin"] = adm
    data["view_own"] = bool(my.get("columns_own") or my.get("sort_own"))
    data["company"] = prefs.company()
    return data


def task_state(actor, tid: str) -> dict:
    _require_enabled()
    me = _require_actor(actor)
    if tid not in tasks.visible_ids(me):
        raise ApiError("Цієї задачі вам не видно.", 403, "not_visible")
    # ⭐ `incoming=True` — картка ЄДИНЕ місце, де потрібні ще й ті, хто вказує НА
    # цю задачу. Зворотний бік ніде не зберігається, тому його рахують саме тут.
    t = tasks.task(tid, incoming=True)
    names = {e["id"]: e.get("full_name", "") for e in people.employees(True)}
    t["my_role"] = tasks.role_of(t, me)
    # ⭐ Кнопки малюються з ЦЬОГО, а не з власних «якщо» на сторінці: інакше
    # екран став би другим писарем прав і розійшовся б із кодом дії.
    t["may"] = tasks.rights(t, me, _is_admin(actor))
    t["reach"] = mouth.reach(t, me)
    t["names"] = names
    t["me"] = {"id": me, "name": names.get(me, "")}
    t["people"] = [{"id": e["id"], "name": e.get("full_name", "")}
                   for e in people.employees()]
    # ⭐ Вибір типу роботи їде РАЗОМ із карткою, як і люди: другий шлях по ті
    # самі дані означав би, що екран колись покаже не той список.
    t["worktypes"] = [{"id": w["id"], "name": w["name"]}
                      for w in worktypes.types()]
    # ⭐ ПРОЄКТИ ЇДУТЬ РАЗОМ ІЗ КАРТКОЮ, як люди й типи роботи. Другий шлях по ті
    # самі дані означав би, що екран колись покаже не той перелік. І перелік тут
    # рівно той, який людині НАЛЕЖИТЬ: право рахує Task Desk по дереву компанії,
    # а не екран за своїм «якщо».
    t["projects"] = tasks.projects_for(me, _is_admin(actor))
    t["project_name"] = tasks.project_name(t.get("project_id") or "")
    _add_links(t, me)
    return t


# ---------------------------------------------------------------------------
# ЗВʼЯЗКИ ЗАДАЧІ ДЛЯ ЕКРАНА (зміна 172)
# ---------------------------------------------------------------------------
LINK_TARGETS_MAX = 300      # ⚠ мовчазних обрізань не буває: скільки не влізло — скажемо


def _add_links(t: dict, me: str) -> None:
    """Що показати в блоці «Звʼязки» і з чого людині вибирати.

    ⭐ ФОРМУЛЮВАННЯ БЕРЕМО В `taskdesk_links`, а не складаємо на сторінці:
    інакше екран став би другим писарем слів і розійшовся б із телеграмом."""
    t["links_view"] = tlinks.decorate(t.get("links") or [])
    t["links_in_view"] = tlinks.decorate(t.get("links_in") or [], back=True)
    t["link_rels"] = [{"id": r, "name": tlinks.REL_NAMES[r],
                       "tasks_only": r in tlinks.TASK_ONLY} for r in tlinks.RELS]

    mine = tasks.visible_tasks(me)
    rows = [{"ref": "task:%s" % x["id"], "id": x["id"], "title": x["title"]}
            for x in mine if x["id"] != t["id"]]
    note = ""
    if len(rows) > LINK_TARGETS_MAX:
        note = ("показано перші %d задач із %d — решту знайдіть за номером"
                % (LINK_TARGETS_MAX, len(rows)))
        rows = rows[:LINK_TARGETS_MAX]
    parties = []
    try:
        import parties as _pt
        for x in _pt.all_parties():
            parties.append({"ref": "party:%s" % x["id"], "id": x["id"],
                            "title": x.get("name") or x["id"]})
    except Exception as ex:
        note = (note + " · " if note else "") + "довідник контрагентів не прочитався: %s" % ex
    t["link_targets"] = {"tasks": rows, "parties": parties, "note": note}


def _result(me, d, adm: bool = False) -> dict:
    """Позначити наявний коментар результатом — і звірити його з критерієм."""
    tid = d.get("id") or ""
    cid = d.get("comment_id") or ""
    body = ""
    try:
        for c in (tasks.task(tid).get("feed") or []):
            if c["id"] == cid:
                body = c.get("text") or ""
                break
    except tasks.TaskError:
        body = ""
    m, note = _match_for(tid, body)
    t = tasks.mark_result(tid, me, cid, adm, match=m)
    if note:
        t = dict(t)
        t["ai_note"] = note
    return t


def _match_for(tid: str, result_text: str):
    """Звірка результату з критерієм приймання — або порожньо й причина словами.

    ⛔ Мозок тут НІЧОГО не вирішує: він кладе поруч «що просили · що здали ·
    чого не видно». Приймає людина."""
    if not ai.enabled():
        return {}, ""
    try:
        t = tasks.task(tid)
    except tasks.TaskError:
        return {}, ""
    crit = t.get("acceptance") or ""
    if not crit:
        return {}, ""          # звіряти нема з чим — і це не помилка
    try:
        return ai.compare_result_soon(crit, result_text)
    except Exception as e:
        return {}, str(e)


def _comment(me, d, adm: bool = False) -> dict:
    """Коментар зберігається ЗАВЖДИ. Мозок читає його ПІСЛЯ і лише пропонує.

    Якщо мозок не відповів — коментар від цього не пропадає, але й мовчати про
    це не можна: екран скаже вголос. Тиха невдача = вимкнені ворота."""
    tid = d.get("id") or ""
    text = d.get("text") or ""
    as_result = bool(d.get("as_result"))
    # ⛒ ЗВІРКА РАХУЄТЬСЯ ДО ЗАПИСУ Й ЛЯГАЄ В ТОЙ САМИЙ ЗАПИС. Порахувати її
    # після означало б другий запис у ту саму задачу — і другого писаря того
    # самого файла. Не встиг мозок — результат однаково здано, звірки просто
    # немає, і екран скаже про це вголос.
    m, m_note = _match_for(tid, text) if as_result else ({}, "")
    t = tasks.comment(tid, me, text, as_result, adm, match=m)
    if m_note:
        t = dict(t)
        t["ai_note"] = m_note
        return t
    if not ai.enabled() or not ai.might_hold_a_date(d.get("text") or ""):
        return t
    cid = ""
    for c in reversed(t.get("feed") or []):
        if c["kind"] == "comment":
            cid = c["id"]
            break
    found, note = ai.read_comment_soon(t.get("title", ""), d.get("text") or "")
    if note:
        t = dict(t)
        t["ai_note"] = note
        return t
    if not found:
        return t
    try:
        t = tasks.add_proposal(tid, found["kind"], found["date"], found.get("why", ""),
                               found.get("quote", ""), cid)
        t = dict(t)
        t["ai_note"] = "ok"
    except tasks.TaskError as e:
        t = dict(t)
        t["ai_note"] = str(e)
    return t


def _quick_add(me, d, adm=False) -> dict:
    """⭐⭐⭐ ОДИН РЯДОК → ЗАДАЧА (зміна 223, 26.08.2026).

    КОРІНЬ, ЗАРАДИ ЯКОГО ЦЕ ІСНУЄ. Задачники вмирають не від поганих воріт, а
    від того, що поставити задачу довше, ніж написати в чат. Тут — один рядок.

    ⛒ ПОРЯДОК НАВМИСНИЙ: спершу РОЗБІР (безкоштовно, кодом), потім СТВОРЕННЯ
    (усі наявні ворота прав і SoD, бо йдемо через ту саму `tasks.create`), і
    лише ПОТІМ мозок. Задача вже на диску, коли він тільки починає думати.

    🩸 ГРОШІ. Мозок кличемо ЛИШЕ для задачі ІНШІЙ людині — рішення Андрія
    26.08.2026. Нагадування собі критерію приймання не потребує.
    """
    line = (d.get("line") or d.get("text") or "").strip()
    if not line:
        raise tasks.TaskError("Порожній рядок — задачі з нього не вийде.")
    parsed = intake.parse(line, people.employees(), clock.now()[:10],
                          tasks.find_due_in)
    if not parsed["title"]:
        raise tasks.TaskError(
            "; ".join(parsed["unclear"]) or "У рядку немає самої задачі.")
    t = tasks.create(me, parsed["title"], parsed["assignee_id"],
                     parsed["due_at"], source="quick")
    out = dict(t)
    out["said"] = parsed["said"]
    out["unclear"] = list(parsed["unclear"])

    # ⛒ ВОРОТА ВХОДУ. Безкоштовна половина вже порахована в самій задачі
    # (`unready_why`). Платна половина — лише пропозиція формулювання, і лише
    # там, де є за що платити.
    if not (out.get("for_other") and not out.get("acceptance")):
        return out
    try:
        found, note = ai.propose_acceptance_soon(t.get("title", ""),
                                                 t.get("description", ""))
    except Exception as e:
        out["ai_note"] = str(e)
        return out
    if note:
        out["ai_note"] = note
        return out
    if not found:
        return out
    try:
        out = dict(tasks.add_proposal(t["id"], tasks.PROPOSAL_ACCEPT, "",
                                      found.get("why", ""), "", "",
                                      found["acceptance"]))
        out["said"] = parsed["said"]
        out["unclear"] = list(parsed["unclear"])
        out["ai_note"] = "ok"
    except tasks.TaskError as e:
        out["ai_note"] = str(e)
    return out


# ⭐ Третій аргумент `adm` — прапорець адміністратора. Він іде ЗВЕРХУ, з шару
# облікових записів, бо в самій задачі адміністратора може не бути взагалі.
TASK_ACTIONS = {
    "create": lambda me, d, adm: tasks.create(
        me, d.get("title") or "", d.get("assignee_id") or "", d.get("due_at") or "",
        d.get("description") or "", d.get("coassignee_ids") or [],
        d.get("watcher_ids") or [], d.get("checklist") or [],
        verifier_id=d.get("verifier_id") or "",
        worktype_id=d.get("worktype_id") or "",
        project_id=d.get("project_id") or ""),
    "comment": lambda me, d, adm: _comment(me, d, adm),
    "result": lambda me, d, adm: _result(me, d, adm),
    # ⭐ «Перевірив, годиться» — окрема дія, а не стадія: незгода їде вже
    # наявним шляхом «На доопрацювання».
    "verify": lambda me, d, adm: tasks.verify(d.get("id") or "", me, adm),
    "stage": lambda me, d, adm: tasks.set_stage(d.get("id") or "", me,
                                                d.get("stage") or "", adm),
    "delegate": lambda me, d, adm: tasks.delegate(d.get("id") or "", me,
                                                  d.get("assignee_id") or "", adm),
    "refuse": lambda me, d, adm: tasks.refuse(d.get("id") or "", me,
                                              d.get("reason") or "", adm),
    "check": lambda me, d, adm: tasks.check_item(d.get("id") or "", me,
                                                 d.get("item_id") or "",
                                                 bool(d.get("done")), adm),
    # ⭐ СТАНДАРТ ГОТОВНОСТІ (зміна 225) — окрема дія, а не «ще один пункт
    # плану»: чек-лист каже ЯК робити, стандарт — ЗА ЧИМ приймемо.
    "dod": lambda me, d, adm: tasks.check_dod(d.get("id") or "", me,
                                              d.get("point_id") or "",
                                              bool(d.get("done")), adm),
    "proposal": lambda me, d, adm: tasks.resolve_proposal(
        d.get("id") or "", me, d.get("proposal_id") or "",
        bool(d.get("accept")), adm),
    # ⭐ ЗВʼЯЗОК — ТАКА САМА ДІЯ, ЯК РЕШТА: іде тим самим єдиним входом, під тими
    # самими правами (`ACT_EDIT`), і лишає слід у стрічці, нерві й протоколі.
    "link": lambda me, d, adm: tasks.link(d.get("id") or "", me, d.get("ref") or "",
                                          d.get("rel") or "", adm),
    "unlink": lambda me, d, adm: tasks.unlink(d.get("id") or "", me, d.get("ref") or "",
                                              d.get("rel") or "", adm),
    "update": lambda me, d, adm: tasks.update(d.get("id") or "", me, adm,
                                              **{k: v for k, v in d.items()
                                                 if k in ("title", "description", "due_at",
                                                          "coassignee_ids", "watcher_ids",
                                                          "verifier_id", "acceptance",
                                                          "worktype_id", "project_id")}),
    # ⭐ ОДИН РЯДОК — ТА САМА ДІЯ, ЩО Й РЕШТА: єдиний вхід, ті самі права,
    # той самий слід. Другого шляху завести задачу в продукті немає.
    "quick_add": lambda me, d, adm: _quick_add(me, d, adm),
}


def run_task_action(actor, data: dict) -> dict:
    """ЄДИНИЙ вхід усіх дій над задачами — щоб новий екран не винайшов свій шлях
    повз перевірки. Невідома дія не виконується, а називається."""
    _require_enabled()
    me = _require_actor(actor)
    name = str((data or {}).get("action") or "").strip()
    fn = TASK_ACTIONS.get(name)
    if fn is None:
        raise ApiError("Невідома дія «%s». Відомі: %s"
                       % (name, ", ".join(sorted(TASK_ACTIONS))), 400, "unknown_action")
    try:
        res = fn(me, data or {}, _is_admin(actor))
    except tasks.TaskError as e:
        raise ApiError(str(e), 400, "refused")
    except people.PeopleError as e:
        raise ApiError(str(e), 400, "refused")
    out = {"ok": True, "result": res}
    # ⭐⭐⭐ ПРАВДА ПРО ТИШУ ЇДЕ З КОЖНОЮ ДІЄЮ, а не лише зі створенням: людина
    # має знати, хто про її крок дізнається, коли б вона його не зробила.
    # Порахувати це має ОДИН писар (`mouth.reach`), інакше екран створення й
    # картка задачі казали б різне.
    if isinstance(res, dict) and res.get("id") and res.get("stage"):
        try:
            out["reach"] = mouth.reach(res, me)
        except Exception as e:
            # Тиша про тишу — рівно те, що ми тут і лікуємо.
            out["reach"] = {"note": "Не вдалося порахувати, кому це піде: %s" % e}
    return out


# ---------------------------------------------------------------------------
# ДІЇ — ОДНА ТАБЛИЦЯ НА ВСЮ КОНСОЛЬ
# ---------------------------------------------------------------------------
def _d(data, *names):
    return [(data.get(n) or "") for n in names]


PEOPLE_ACTIONS = {
    "unit_add": lambda d: people.add_unit(*_d(d, "name", "parent_id", "head_employee_id")),
    "unit_parent": lambda d: people.set_unit_parent(*_d(d, "unit_id", "parent_id")),
    "unit_head": lambda d: people.set_unit_head(*_d(d, "unit_id", "head_employee_id")),
    # ⭐ ЛІКВІДАЦІЯ (зміна 350). Дочірні підрозділи не гинуть: `children_to`
    # каже, кому вони переходять; порожньо — батьківському.
    "unit_liquidate": lambda d: people.liquidate_unit(d.get("unit_id") or "",
                                                      d.get("children_to") or ""),
    "unit_restore": lambda d: people.restore_unit(d.get("unit_id") or ""),
    # ⭐ ГОРИЗОНТИ (зміна 302): вісім готових місць. «Завести» горизонт означає
    # дати номеру КОЛІР; порожній колір звільняє місце, і писар відмовиться,
    # якщо на ньому ще хтось стоїть.
    "horizon_color": lambda d: people.set_horizon_color(*_d(d, "number", "color")),
    "unit_horizon": lambda d: people.set_unit_horizon(*_d(d, "unit_id", "number")),
    "position_add": lambda d: people.add_position(d.get("name") or ""),
    # ⭐⭐⭐ 626е (22.09.2026): ВИПРАВЛЕННЯ ІМЕНІ — КНОПКОЮ, А НЕ ПРАВКОЮ ФАЙЛА.
    # Нові дії йдуть ТИМИ САМИМИ воротами (таблиця «people» — адмінська), а не
    # другим замком поруч.
    "unit_rename": lambda d: people.rename_unit(d.get("id") or d.get("unit_id") or "",
                                                d.get("name") or ""),
    "position_rename": lambda d: people.rename_position(
        d.get("id") or d.get("position_id") or "", d.get("name") or ""),
    "position_archive": lambda d: people.archive_position(
        d.get("id") or d.get("position_id") or ""),
    "position_restore": lambda d: people.restore_position(
        d.get("id") or d.get("position_id") or ""),
    "employee_add": lambda d: people.add_employee(
        d.get("full_name") or "", d.get("unit_id") or "", d.get("position_id") or "",
        d.get("email") or "", d.get("telegram_id") or "", d.get("birthday") or "",
        d.get("phone_mobile") or "", d.get("phone_work") or ""),
    "employee_update": lambda d: people.update_employee(
        d.get("id") or "", **{k: v for k, v in d.items()
                              if k in ("full_name", "unit_id", "position_id", "email",
                                       "telegram_id", "birthday", "phone_mobile",
                                       "phone_work", "horizon_id")}),
    "employee_dismiss": lambda d: people.dismiss_employee(d.get("id") or "",
                                                          d.get("reason") or ""),
    # ⭐ ЗАМІЩЕННЯ НА ЧАС ВІДСУТНОСТІ (зміна 224). Іде тим самим єдиним входом,
    # що й решта дій над карткою, — другого шляху завести відсутність немає.
    "absence_set": lambda d: people.set_absence(
        d.get("id") or "", d.get("from") or "", d.get("to") or "",
        d.get("delegate_id") or "", d.get("reason") or ""),
    "absence_clear": lambda d: people.clear_absence(d.get("id") or "",
                                                    d.get("absence_id") or ""),
    "employee_restore": lambda d: people.restore_employee(d.get("id") or ""),
    # ⭐ КАНАЛ ПІДКЛЮЧАЄ САМА ЛЮДИНА. Номер чату не знає ні вона, ні
    # адміністратор — його знає лише телеграм. Тому екран видає РАЗОВИЙ КОД,
    # а звʼязує код із чатом бот.
    "telegram_code": lambda d: identity.link_code(_acc_of(d.get("id") or "")["id"]),
    "telegram_unlink": lambda d: identity.unlink_telegram(_acc_of(d.get("id") or "")["id"]),
}

# ⭐ ТИПИ РОБОТИ — ПРАВИЛО КОМПАНІЇ, А НЕ ОСОБИСТА НАСТРОЙКА, тому веде їх
# адміністратор (за замовчуванням таблиці). 🩸 Заготовок від нас немає: клієнт
# складає стандарт сам (рішення Андрія 26.08.2026).
WORKTYPE_ACTIONS = {
    "type_add": lambda d: worktypes.add_type(d.get("name") or "",
                                             d.get("points") or []),
    "type_update": lambda d: worktypes.update_type(
        d.get("id") or "",
        name=d.get("name") if "name" in d else None,
        points=d.get("points") if "points" in d else None),
    "type_active": lambda d: worktypes.set_active(d.get("id") or "",
                                                  bool(d.get("active"))),
}


ACCESS_ACTIONS = {
    "account_add": lambda d: identity.create_account(
        d.get("login") or "", d.get("password") or "", d.get("employee_id") or "",
        bool(d.get("is_admin"))),
    "password": lambda d: identity.set_password(d.get("id") or "", d.get("password") or ""),
    "active": lambda d: identity.set_active(d.get("id") or "", bool(d.get("active"))),
    "layers": lambda d: identity.set_layers(d.get("id") or "", d.get("layers") or []),
    "orchestrator": lambda d: identity.set_orchestrator_access(
        d.get("id") or "", d.get("mode") or "", d.get("systems") or []),
    # ⭐⭐⭐ 588 (16.09.2026): РІВЕНЬ І ПРИБИРАННЯ ЗАПИСУ — КНОПКАМИ, А НЕ
    # ПРАВКОЮ ФАЙЛА. Доти в цій таблиці були пароль, вмикання, шари й
    # оркестратор, а рівень адміністратора задавався ЛИШЕ при народженні
    # запису. Разом із правилом «один працівник — один запис» це робило
    # помилку в рівні невиправною: 15.09.2026 у Каспера довелось правити
    # `accounts.json` руками. Нові дії йдуть ТИМИ САМИМИ воротами (таблиця
    # `access` — адмінська), а не другим замком поруч.
    "is_admin": lambda d: identity.set_admin(d.get("id") or "",
                                             bool(d.get("is_admin"))),
    "account_remove": lambda d: identity.remove_account(d.get("id") or ""),
}


# ⭐ РЕЄСТР ТАБЛИЦЬ ДІЙ — одне місце, де перелічені ВСІ таблиці Task Desk.
# Нова таблиця, не вписана сюди, не має входу з сервера; чек 1.4 звіряє реєстр
# із тим, що насправді оголошено у файлі, — тому «таблиця повз реєстр» не живе.
# ---------------------------------------------------------------------------
# НАЛАШТУВАННЯ ЕКРАНА Й ВИВАНТАЖЕННЯ. Ворота тут ті самі, що в задачах: це веде
# САМА ЛЮДИНА, не адміністратор. Тому окремий вхід `run_prefs_action`, а не
# спільний із оргструктурою.
# ---------------------------------------------------------------------------
def _export(actor, d) -> dict:
    scope = str(d.get("scope") or "all")
    show_closed = bool(d.get("closed"))
    show_archive = bool(d.get("archive"))
    # ⭐ ЩО НА ЕКРАНІ, ТЕ Й У ФАЙЛІ: пошук йде в вивантаження тим самим
    # шляхом, що й у список. Інакше людина шукала б одне, а вивантажувала інше.
    query = str(d.get("q") or "")
    me, my, ctx, flt, data, flat = _desk(actor, scope, show_closed,
                                        d.get("filter"),
                                        use_saved=d.get("filter") is None,
                                        query=query, show_archive=show_archive)
    who = people.employee(me).get("full_name", "")
    try:
        res = export.build(flat, my["columns"], ctx, who_name=who, flt=flt,
                           scope_name=SCOPE_NAMES.get(scope, scope), query=query)
    except export.ExportError as e:
        raise ApiError(str(e), 400, "no_excel")
    if d.get("open", True):
        try:
            import support_report          # ОДИН писар «відкрити провідник»
            res["opened"] = support_report.open_folder(res["path"])
        except Exception:
            res["opened"] = False
    return res


PREFS_ACTIONS = {
    "columns": lambda me, d: prefs.set_columns(me, d.get("columns") or []),
    "filter": lambda me, d: prefs.set_filter(me, d.get("filter") or {},
                                             d.get("view_id") or ""),
    "view_save": lambda me, d: prefs.save_view(me, d.get("name") or "",
                                               d.get("filter") or {},
                                               d.get("columns"),
                                               d.get("view_id") or ""),
    "view_delete": lambda me, d: prefs.delete_view(me, d.get("view_id") or ""),
    "view_use": lambda me, d: prefs.use_view(me, d.get("view_id") or ""),
    "view_default": lambda me, d: prefs.set_default_view(me, d.get("view_id") or ""),
    "sort": lambda me, d: prefs.set_sort(me, d.get("field") or "", d.get("desc")),
    "view_reset": lambda me, d: prefs.reset_view(me),
    "company_set": lambda me, d: prefs.set_company(me, d.get("columns"),
                                                   d.get("sort")),
}


# ⭐ ОДИН ПЕРЕЛІК ДІЙ, ЯКІ ВЕДЕ АДМІНІСТРАТОР. Решта в цій таблиці — це те, що
# людина робить СОБІ. Змішати їх означало б віддати вигляд компанії будь-кому.
PREFS_ADMIN_ONLY = ("company_set",)


def run_prefs_action(actor, data: dict) -> dict:
    """ЄДИНИЙ вхід налаштувань екрана й вивантаження."""
    _require_enabled()
    me = _require_actor(actor)
    name = str((data or {}).get("action") or "").strip()
    if name in PREFS_ADMIN_ONLY:
        _require_admin(actor)
    if name == "export":                    # не налаштування, а дія над списком
        return {"ok": True, "result": _export(actor, data or {})}
    fn = PREFS_ACTIONS.get(name)
    if fn is None:
        raise ApiError("Невідома дія «%s». Відомі: %s"
                       % (name, ", ".join(sorted(list(PREFS_ACTIONS) + ["export"]))),
                       400, "unknown_action")
    try:
        return {"ok": True, "result": fn(me, data or {})}
    except prefs.PrefsError as e:
        raise ApiError(str(e), 400, "refused")
    except fields.FieldError as e:
        raise ApiError(str(e), 400, "refused")


# ⭐⭐⭐ ЕТАП 2 (24.08.2026). ПРАВА КРУТЯТЬСЯ РУКАМИ, А НЕ З КОДУ.
# Матриця «роль × дозвіл» зʼявилась зміною 205, але міняти її можна було лише
# правкою файла. Екран ходить через ТІ САМІ двері (`run_action`), тому ворота
# адміністратора не треба писати вдруге — вони вже стоять на вході.
ROLES_ACTIONS = {
    "role_add": lambda d: roles.add_role(d.get("name") or "",
                                         d.get("copy_from") or ""),
    "perm": lambda d: roles.set_perm(d.get("role_id") or "", d.get("perm") or "",
                                     bool(d.get("on"))),
    "assign": lambda d: roles.assign_to(d.get("kind") or "",
                                        d.get("target_id") or "",
                                        d.get("role_id") or ""),
}


ACTION_TABLES = {
    "roles": ROLES_ACTIONS,       # права — веде адміністратор
    "people": PEOPLE_ACTIONS,     # оргструктура — веде адміністратор
    "access": ACCESS_ACTIONS,     # доступи — веде адміністратор
    "worktypes": WORKTYPE_ACTIONS,  # типи робіт і стандарт — веде адміністратор
    "tasks": TASK_ACTIONS,        # задачі — веде сам працівник (інші ворота)
    "prefs": PREFS_ACTIONS,       # вигляд списку й вивантаження — теж сам працівник
}


# ⭐⭐⭐ ХТО МОЖЕ ЯКУ ДІЮ. Доти тут стояло глухе «все веде адміністратор», і
# рішення «людина править свої дані» просто не мало куди лягти. Тепер правило
# живе ОДНІЄЮ таблицею, як `ACTION_ROLES` у задачах: що не названо — адміністратор.
WHO_ADMIN = "admin"
# ⭐ Ліквідація підрозділу — не адміністрування, а рішення власника.
WHO_TOP = "top_manager"
WHO_SELF_OR_ADMIN = "self_or_admin"

WHO_MY_CARD = "my_card"
# ⭐ Відсутність — не поле картки. Її заводить сама людина, ЇЇ КЕРІВНИК або
# адміністратор: людина може зникнути раптово і вже нічого не ввести.
WHO_ABSENCE = "absence"

ACTION_WHO = {
    "people": {"employee_update": WHO_SELF_OR_ADMIN,
               "unit_liquidate": WHO_TOP,
               "unit_restore": WHO_TOP,
               "absence_set": WHO_ABSENCE,
               "absence_clear": WHO_ABSENCE,
               # Своя картка цілком: тут не поле правлять, а вмикають канал.
               "telegram_code": WHO_MY_CARD,
               "telegram_unlink": WHO_MY_CARD},
}


def top_manager_id() -> str:
    """ХТО СТАРШИЙ КЕРІВНИК КОМПАНІЇ — обчислено з дерева, а не записано.

    Це той, під ким стоїть УСЯ компанія: сам без керівника, і кожен інший
    працівник через ланцюг керівників доходить саме до нього. Якщо таких
    немає або їх кілька — порожньо, і той, хто питає, мусить сказати про це
    словами, а не вгадати."""
    emps = [e for e in people.employees() if not e.get("broken")]
    if not emps:
        return ""
    tops = [e for e in emps if not _s_id(e.get("manager_id"))]
    # ⛒ Тут перевіряється лише те, що вершина ВЗАГАЛІ Є. Скільки їх — питає не
    # це правило, а досяжність нижче: якщо вершин дві, хтось із людей не дійде
    # до обраної, і відповіді не буде. Два сторожі на одне правило — це нуль.
    if not tops:
        return ""
    top = tops[0]["id"]
    by_id = {e["id"]: e for e in emps}
    for e in emps:
        cur, seen = e["id"], set()
        while cur and cur not in seen:
            if cur == top:
                break
            seen.add(cur)
            cur = _s_id(by_id.get(cur, {}).get("manager_id"))
        else:
            return ""
        if cur != top:
            return ""
    return top


def _s_id(v) -> str:
    return str(v or "").strip()


def _require_top_manager(actor):
    """Ліквідувати підрозділ може лише старший керівник компанії."""
    # Поки вхід не вимагається, розрізняти нікого: господар машини і є власник.
    if not identity.login_required():
        _require_admin(actor)
        return
    me = _me(actor)
    if not me:
        raise ApiError("Увійдіть під своїм працівником: ліквідувати підрозділ "
                       "може лише старший керівник компанії.", 401, "login_required")
    top = top_manager_id()
    if not top:
        raise ApiError(
            "Платформа не може визначити старшого керівника компанії: у "
            "структурі більше ніж одна вершина або вона порожня. Спершу "
            "зведіть структуру до одного керівника нагорі — тоді ліквідація "
            "підрозділу стане доступною йому.", 400, "no_top_manager")
    if me != top:
        raise ApiError("Рішення про ліквідацію підрозділу приймає лише старший "
                       "керівник компанії.", 403, "not_top_manager")


def _guard_my_card(actor, data: dict):
    """Дія над СВОЄЮ карткою (не над полем). Адміністратор може й над чужою:
    він видає код людині, яка ще не має доступу до екрана, і знімає канал
    звільненому."""
    emp_id = str((data or {}).get("id") or "").strip()
    if not emp_id:
        raise ApiError("Не сказано, чия це картка.", 400, "no_id")
    if _is_admin(actor):
        return
    if not people.card_rights(_me(actor), emp_id, False).get("is_self"):
        raise ApiError("Телеграм людина підключає у своїй картці — чужу картку "
                       "змінює адміністратор.", 403, "not_allowed")


def _guard_absence(actor, data: dict):
    """Відсутність заводить сама людина, її керівник або адміністратор.
    Відповідь на це питання рахує ОДИН писар — `people.card_rights`, той самий,
    з якого екран малює блок. Інакше зʼявилась би кнопка, яка відмовить."""
    emp_id = str((data or {}).get("id") or "").strip()
    if not emp_id:
        raise ApiError("Не сказано, чию відсутність заводити.", 400, "no_id")
    if not people.card_rights(_me(actor), emp_id,
                              _is_admin(actor)).get("absence"):
        raise ApiError("Відсутність заводить сама людина, її керівник або "
                       "адміністратор.", 403, "not_allowed")


def _guard_card_fields(actor, data: dict):
    """Людина править СВОЄ, адміністратор — усе. Поле не за правом — відмова, яка
    називає, хто б це зміг."""
    emp_id = str((data or {}).get("id") or "").strip()
    if not emp_id:
        raise ApiError("Не сказано, чию картку правити.", 400, "no_id")
    rights = people.card_rights(_me(actor), emp_id, _is_admin(actor))
    asked = [k for k in (data or {}) if k not in ("action", "id")]
    if not asked:
        raise ApiError("Не сказано, що саме змінити.", 400, "no_fields")
    # ⭐ Відмова називає ПРИЧИНУ і того, хто б це зміг. Дві причини — різні:
    # «це не твоя картка» і «це поле не твоє» плутати не можна, бо людина
    # шукатиме зовсім не там. (`.capitalize()` тут теж не місце: «ПІБ» він
    # перетворював на «Піб» — знайдено живим прогоном 08.08.2026.)
    for f in asked:
        if f not in rights["fields"]:
            what = people.FIELD_NAMES.get(f, f)
            if not rights["is_self"]:
                raise ApiError(
                    "Це картка іншої людини: свої дані вона міняє сама, "
                    "а решту — адміністратор.", 403, "not_allowed")
            raise ApiError("У своїй картці %s змінює %s."
                           % (what, people.who_may_edit(f)), 403, "not_allowed")


def run_action(actor, table: str, data: dict) -> dict:
    """ЄДИНИЙ вхід для всіх дій обох екранів."""
    _require_enabled()
    actions = ACTION_TABLES.get(table)
    if actions is None:
        raise ApiError("Невідомий розділ «%s»." % table, 404, "unknown_table")
    name = str((data or {}).get("action") or "").strip()
    fn = actions.get(name)
    if fn is None:
        raise ApiError("Невідома дія «%s». Відомі: %s"
                       % (name, ", ".join(sorted(actions))), 400, "unknown_action")
    who = ACTION_WHO.get(table, {}).get(name, WHO_ADMIN)
    if who == WHO_ADMIN:
        _require_admin(actor)
    elif who == WHO_TOP:
        _require_top_manager(actor)
    elif who == WHO_MY_CARD:
        _guard_my_card(actor, data or {})
    elif who == WHO_ABSENCE:
        _guard_absence(actor, data or {})
    else:
        _guard_card_fields(actor, data or {})
    # ⭐⭐⭐ ХТО ДІЄ — КАЖУТЬ ДВЕРІ, А НЕ КОЖНА ДІЯ ОКРЕМО (зміна 363, 30.08.2026).
    # Джерело кладемо теж: за ним журнал відрізняє «людина за екраном, вхід не
    # вимагається» від «зробила сама платформа». Без нього обидва випадки
    # виглядали б однаково безіменними, і екран мусив би вгадувати.
    # ⛒ Саме `step`, а не `bind`: сервер багатопотоковий і тримає зʼєднання, тож
    # прив'язка мусить померти разом із запитом.
    with protocol.step(actor=entity.person_of_actor(actor), source="ui"):
        try:
            result = fn(data or {})
        except (people.PeopleError, identity.IdentityError, roles.RoleError,
                worktypes.WorkTypeError) as e:
            # Відмова судді повноважень доходить до людини ТИМИ САМИМИ словами.
            raise ApiError(str(e), 400, "refused")
    return {"ok": True, "result": result}
