# -*- coding: utf-8 -*-
"""ОДИН ПИСАР (зміна 504, 04.09.2026) — щоб двоє людей не затирали одне одного.

НАВІЩО. 04.09.2026 замір `concurrency_probe.py` показав: коли 10 людей
одночасно створюють картки, з 50 у базі опиняється 28, а ШІСТЬ карток дістають
відповідь «збережено» і зникають. Помилка на екрані дратує — людина повторить.
Картка, яку система підтвердила і мовчки викинула, не повертається ніколи.

КОРІНЬ БУВ ПОДВІЙНИЙ:
  1. `_save` писав у СПІЛЬНИЙ тимчасовий файл `<база>.json.tmp`. Двоє одночасно:
     обидва створили той самий tmp, перший перейменував — файл зник, другий
     упав `FileNotFoundError` -> 500.
  2. Кожна зміна — це «прочитав УСЮ базу -> змінив -> записав УСЮ базу», і ніхто
     нікого не чекав. Навіть без падіння другий тихо затирав першого.

ЧОМУ ОДИН ЗАМОК НА ВСЮ БАЗУ, А НЕ ПО ЗАМКУ НА ФАЙЛ. Замок на файл здається
тоншим, але `crm.ensure_client` чіпає і клієнтів, і контрагентів — двоє потоків
узяли б ті самі два замки в різному порядку і стали б навіки. Один замок на всі
записи стану робить це неможливим ЗА ПОБУДОВОЮ. Ціна мізерна: запис у наші
файли — це одиниці мілісекунд, а ЧИТАННЯ замок не чіпає взагалі (заміряно:
10 користувачів, 87 запитів/с).

ДВА РІВНІ:
  - у ПРОЦЕСІ (`_STATE_LOCK`) — головний. Сервер один процес, потік на запит,
    саме тут стикаються живі користувачі.
  - у ФАЙЛІ (`.one_writer.lock`) — для СТОРОННІХ процесів: `crm_debt.py`,
    патчі, скрипти обслуговування пишуть у ту саму базу збоку.

🩸 ПОКИНУТИЙ ЗАМОК НЕ МАЄ ВБИТИ ПЛАТФОРМУ. Якщо процес упав і не прибрав за
собою — файловий замок віддається за віком (`STALE_SECONDS`), а не тримає базу
вічно. І сам файловий замок — «за можливості»: якщо його не вдалось поставити,
працюємо на замку в процесі, бо втратити ЖИВОГО користувача гірше.
"""
import json
import os
import tempfile
import threading
import time
from contextlib import contextmanager
from pathlib import Path

# ── Один писар у межах процесу ───────────────────────────────────────────────
# RLock, а не Lock: мутатор може викликати інший мутатор (crm -> parties), і
# власний потік не повинен заблокувати сам себе.
_STATE_LOCK = threading.RLock()

# 🩸 ГЛИБИНА ВХОДЖЕННЯ В ЦЬОМУ ПОТОЦІ. Замок у процесі реентерабельний сам по
# собі, а ФАЙЛОВИЙ — НІ: мутатор, що викликав мутатора, ставав у чергу САМ ЗА
# СОБОЮ і вішав потік на `WAIT_SECONDS`. Спіймав це власний чек 04.09.2026.
# Тому файловий замок бере ЛИШЕ найзовнішній вхід.
_depth = threading.local()

LOCK_NAME = ".one_writer.lock"
STALE_SECONDS = 60.0      # старший за це — вважаємо покинутим
WAIT_SECONDS = 20.0       # скільки чекаємо чужий процес
_POLL = 0.02

# ⭐⭐⭐ 563. СКІЛЬКИ ТЕРПИМО ЧУЖОГО ЧИТАЧА ПІД ЧАС ПІДМІНИ ФАЙЛА.
# Windows відпускає файл за мілісекунди. Дві секунди — це вже не читач, а щось
# застрягле, і про таке треба сказати ВГОЛОС, а не чекати вічно: платформа, що
# мовчки висне, гірша за платформу, що чесно скаржиться.
REPLACE_PATIENCE = 2.0

# ⭐⭐⭐ 563б. СКІЛЬКИ ТЕРПИМО ЧУЖУ ПІДМІНУ, КОЛИ САМІ ЧИТАЄМО.
# Той самий закон з другого боку і та сама людська межа: читач, що чекає вічно,
# — це платформа, яка висне мовчки.
READ_PATIENCE = 2.0


def _state_dir() -> Path:
    """Тека стану БЕРЕТЬСЯ В МОМЕНТ ВИКЛИКУ, а не при імпорті: пісочниці
    (`SENSFLOW_STATE_DIR`) підміняють її вже після того, як модуль завантажено."""
    try:
        import config
        return Path(config.ENV.get("SENSFLOW_STATE_DIR") or config.STATE_DIR)
    except Exception:
        return Path(tempfile.gettempdir())


def _take_file_lock():
    """Ексклюзивний файловий замок для СТОРОННІХ процесів. Повертає шлях або None.
    Ніколи не кидає: не вдалось — працюємо на замку в процесі."""
    try:
        d = _state_dir()
        d.mkdir(parents=True, exist_ok=True)
        p = d / LOCK_NAME
    except Exception:
        return None
    deadline = time.time() + WAIT_SECONDS
    while True:
        try:
            fd = os.open(str(p), os.O_CREAT | os.O_EXCL | os.O_RDWR)
            try:
                os.write(fd, str(os.getpid()).encode("ascii"))
            finally:
                os.close(fd)
            return p
        except FileExistsError:
            # Чужий тримає. Але чи живий він?
            try:
                age = time.time() - os.path.getmtime(str(p))
            except Exception:
                age = 0.0
            if age > STALE_SECONDS:
                try:
                    os.unlink(str(p))      # покинутий — забираємо
                    continue
                except Exception:
                    return None
            if time.time() > deadline:
                return None                # не дочекались — не тримаємо живого
            time.sleep(_POLL)
        except Exception:
            return None


def _drop_file_lock(p):
    if not p:
        return
    try:
        os.unlink(str(p))
    except Exception:
        pass


@contextmanager
def hold():
    """ОДИН ПИСАР. Бере на себе ВЕСЬ цикл «прочитав -> змінив -> записав».

    Саме цикл, а не лише запис: замок тільки на записі не рятує — другий устигне
    прочитати старе між чужим читанням і чужим записом.

    🩸 Вкладеність дозволена: файловий замок бере лише НАЙЗОВНІШНІЙ вхід."""
    with _STATE_LOCK:
        was = getattr(_depth, "n", 0)
        _depth.n = was + 1
        fl = _take_file_lock() if was == 0 else None
        try:
            yield
        finally:
            _depth.n = was
            _drop_file_lock(fl)


def guard(path_attr: str = ""):
    """Декоратор для функції, що ЗМІНЮЄ базу. Один рядок над функцією — тіло не
    чіпаємо (`path_attr` лишається для читабельності: він називає, ЧИЮ базу
    функція пише)."""
    def deco(fn):
        def wrapper(*a, **kw):
            with hold():
                return fn(*a, **kw)
        wrapper.__name__ = getattr(fn, "__name__", "wrapper")
        wrapper.__doc__ = fn.__doc__
        wrapper.__dict__.update(getattr(fn, "__dict__", {}))
        wrapper.__wrapped__ = fn
        wrapper.one_writer_guarded = True
        wrapper.one_writer_base = path_attr
        return wrapper
    return deco


def replace_with_patience(tmp, path, patience: float = REPLACE_PATIENCE) -> int:
    """⭐⭐⭐ ОДИН ПИСАР ПРАВДИ «ЯК МИ ПІДМІНЯЄМО ФАЙЛ». Повертає число спроб.

    🩸 ЖИВИЙ ВИПАДОК 11.09.2026. На Linux `os.replace` підміняє файл навіть тоді,
    коли його читають. На Windows — НІ: доки читач тримає файл відкритим, підміна
    відбивається `PermissionError [WinError 5]`. Проба на бойовій машині: підміна
    під читачем — 9 збоїв із 10.

    ⛒ Тому підміна — не безвідмовна дія, а дія, ЩО МАЄ ПРАВО ВІДБИТИСЬ. Ми
    повторюємо її, поки читач відпустить. Читач тримає файл мілісекунди, тож
    майже завжди вистачає другої спроби.

    🩸 ТЕРПІННЯ МАЄ МЕЖУ. Нескінченне очікування перетворило б тиху втрату зміни
    на тихе зависання — це не лік, а інша хвороба. Вичерпали межу — кажемо
    вголос і називаємо файл.
    """
    tmp, path = str(tmp), str(path)
    deadline = time.monotonic() + max(0.0, float(patience))
    wait, tries = 0.001, 0
    while True:
        tries += 1
        try:
            os.replace(tmp, path)
            return tries
        except PermissionError as ex:
            if time.monotonic() >= deadline:
                raise PermissionError(
                    "Файл «%s» не вдалося підмінити за %.1f с (%d спроб(и)): "
                    "його тримає відкритим хтось інший." % (path, patience, tries)
                ) from ex
            time.sleep(wait)
            wait = min(wait * 2, 0.05)


def read_text(path, patience: float = READ_PATIENCE,
              encoding: str = "utf-8") -> str:
    """⭐⭐⭐ ОДИН ПИСАР ПРАВДИ «ЯК МИ ЧИТАЄМО ФАЙЛ, ЯКИЙ МОЖУТЬ ПІДМІНЯТИ».

    🩸 ДРУГА ПОЛОВИНА ЛІКУ 563. Підміну ми навчились дотискати — і лишили голим
    читача. На Windows відбивають ОБИДВА боки: не лише підміна під читачем, а й
    читання в мить підміни (файл позначено на знищення). Полікувати один бік
    дверей — це півзакону, а півзакон ламається саме там, де його не доробили.

    ⛒ Читання — не безвідмовна дія. Повторюємо, поки писар відпустить.
    🩸 Терпіння МАЄ МЕЖУ — ту саму, людську. Вичерпали — кажемо ВГОЛОС і
    називаємо файл, а не повертаємо порожнечу, яку приймуть за «даних немає».

    ⛒ ЧУЖУ БІДУ НЕ КОВТАЄМО: немає файла, немає теки, побитий текст — це
    ВІДПОВІДЬ, а не зайнятість. Такі помилки летять одразу.
    """
    p = str(path)
    deadline = time.monotonic() + max(0.0, float(patience))
    wait, tries = 0.001, 0
    while True:
        tries += 1
        try:
            with open(p, "r", encoding=encoding) as fh:
                return fh.read()
        except PermissionError as ex:
            if time.monotonic() >= deadline:
                raise PermissionError(
                    "Файл «%s» не вдалося прочитати за %.1f с (%d спроб(и)): "
                    "його саме зараз підміняє хтось інший." % (p, patience, tries)
                ) from ex
            time.sleep(wait)
            wait = min(wait * 2, 0.05)


_NOT_ASKED = object()


def read_json(path, default=_NOT_ASKED, patience: float = READ_PATIENCE):
    """Те саме для JSON — з однією поблажкою, і то НА ЗАМОВЛЕННЯ.

    ⛒ «ФАЙЛ ЗАЙНЯТИЙ» НІКОЛИ НЕ ВІДДАЄТЬСЯ ЯК ПОРОЖНЕЧА. Порожнеча на зайнятий
    файл означає, що наступний запис затре ЖИВУ базу — та сама тиха втрата, лише
    з іншого боку дверей. Зайнятість летить СКАРГОЮ.

    ⛒ «Файла немає» — чесна відповідь, але вирішує той, хто кличе: не назвав
    `default` — помилка летить, як і при звичайному читанні, і старі ловці
    працюють, як працювали.
    """
    try:
        raw = read_text(path, patience=patience)
    except (FileNotFoundError, NotADirectoryError, IsADirectoryError):
        if default is _NOT_ASKED:
            raise
        return default
    return json.loads(raw)


def write_json(path, data, indent: int = 2) -> None:
    """АТОМАРНИЙ ЗАПИС ІЗ ВЛАСНИМ тимчасовим файлом.

    🩸 Спільний `<файл>.tmp` був другою половиною біди: двоє писали в один і той
    самий tmp, перший його перейменовував, другий падав на порожньому місці.
    `mkstemp` дає КОЖНОМУ писарю свій, у ТІЙ САМІЙ теці (інакше `os.replace`
    через межу диска не атомарний)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(data, ensure_ascii=False, indent=indent)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent),
                               prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(raw)
            fh.flush()
            os.fsync(fh.fileno())
        replace_with_patience(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        raise


def write_text(path, text: str) -> None:
    """Те саме для не-JSON (той самий клас біди, та сама лікарня)."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent),
                               prefix=path.name + ".", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        replace_with_patience(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except Exception:
            pass
        raise
