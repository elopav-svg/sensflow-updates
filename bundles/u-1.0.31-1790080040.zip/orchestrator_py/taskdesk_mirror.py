# -*- coding: utf-8 -*-
"""
taskdesk_mirror.py — ОДИН ЧИТАЧ ЖУРНАЛУ: ДЗЕРКАЛО КЕРІВНИКА І РОЗДІЛ ЗВІТУ.

Записка: DESIGN_Звіт_розробнику_і_Дзеркало_керівника.md (29.08.2026).
Слово Андрія 30.08.2026: читач замість лічильників · перелік показників як є ·
дзеркало — ОКРЕМА ПЛАТНА ПОЗИЦІЯ.

КЛАС ПРОБЛЕМИ. Продукт щодня пише факти про власну роботу — і не має нікого,
хто перетворює їх на картину. Той самий клас уже був у журналу подій до появи
зведення: журнал, якого ніхто не читає, — нуль.

ТОЧКА РІШЕННЯ. Одна — цей файл. Він і тільки він рахує підсумки. Нових
лічильників поруч із журналом не заводимо: другий рахунок розійшовся б із
першим на першому ж збої.

УСІ КАНАЛИ. Екран дзеркала (вдома, з іменами), розділ у звіті розробнику
(назовні, без імен) і будь-який майбутній вивіз питають ЦЕЙ модуль.

ЧИ ПРОТЕЧЕ МАЙБУТНІЙ КАНАЛ. Тут головна небезпека: обидва зрізи їдять один
журнал, але один лишається вдома з іменами, а другий їде назовні. Якби
знеособлення жило в каналі, перший же новий канал повіз би імена. Тому
ЗНЕОСОБЛЕННЯ ЖИВЕ ТУТ: `anon()` — єдиний зріз, який узагалі можна кудись
віддати, і в його виводі не існує ні ідентифікатора людини, ні назви задачі,
ні вільного тексту. `named()` віддає імена і питає право по ДЕРЕВУ компанії,
а не по галочці [[project_unit_liquidation]].

⭐ ВЛАСНИЙ РОТ ПРОТИ ПРИБИРАННЯ. `taskdesk_events.prune()` викидає події, які
забрали ВСІ роти. Дзеркало, що читає місяці, одного дня прокинулось би з
порожнім журналом і показало керівникові нуль замість роботи. Тому воно
реєструється СВОЇМ ротом і веде власний підсумковий файл: у ньому лежать
ЧИСЛА, а не події, — він не росте разом із журналом.

⚠ ЧОГО ТУТ НЕМАЄ І ЧОМУ. «Чим користуються: дошка, список, пошук, фільтр,
вивіз» і «скільки разів людина натрапила на порожній екран» — цього в журналі
НЕМАЄ: там лежать лише події ЗАДАЧ. Це не забуте поле, а нові двері (запис
натискань людини), і вони не відчиняються без прямого слова Андрія.

⚠ МЕЖА, ЯКУ КАЖЕМО КЕРІВНИКОВІ ВГОЛОС: дзеркало міряє роботу В СИСТЕМІ. Хто
працює повз систему — тут невидимий, і нуль у нього означає «не бачу», а не
«не працює».
"""

import json
import sys

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import taskdesk_events as events
import taskdesk_people as people
import taskdesk_tasks as tasks
import one_writer

DESK_DIR = config.STATE_DIR / "taskdesk"

# ⛒ ДРУГИЙ ЗАМОК: чек, завантажений не через файл, не сміє працювати по
# бойовому стану — тут живі люди й задачі.
config.refuse_live_state_for_checks(__name__)

TOTALS = DESK_DIR / "mirror_totals.json"
SINK = "mirror"           # імʼя нашого рота в журналі подій
REASONS_KEEP = 200        # причини відмов — лише останні; це слова, не числа
DEFAULT_DAYS = 30
NOBODY = "-"              # подію народив сторож, а не людина

# Види, які в підсумках рахуються окремим іменем, хоч і не є видами події.
COUNT_REWORK = "rework"   # результат зʼявився ВДРУГЕ — робота вернулась
COUNT_CLOSED = "closed"   # задача доїхала до закритої стадії


class MirrorError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


# ---------------------------------------------------------------------------
# ПІДСУМКОВИЙ ФАЙЛ: день × людина × вид. Чисел небагато, подій — скільки завгодно.
# ---------------------------------------------------------------------------
def _empty() -> dict:
    return {"version": 1, "days": {}, "tasks": {}, "reasons": []}


def _load() -> dict:
    try:
        d = one_writer.read_json(TOTALS)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        return _empty()
    if not isinstance(d, dict) or not isinstance(d.get("days"), dict):
        return _empty()
    if not isinstance(d.get("tasks"), dict):
        d["tasks"] = {}
    if not isinstance(d.get("reasons"), list):
        d["reasons"] = []
    d.setdefault("version", 1)
    return d


def _save(state: dict) -> None:
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(TOTALS, state)


def fold(rows, state=None) -> dict:
    """ЧИСТЕ згортання подій у підсумки: ні диска, ні годинника.

    ⭐ Саме тому чек може прогнати його на СПРАВЖНІХ подіях із журналу, а не на
    вигаданому наборі полів [[feedback_stand_must_mirror_real_path]]."""
    st = state if state is not None else _empty()
    for e in rows or []:
        kind = str(e.get("kind") or "")
        if kind not in events.KINDS_ALL:
            continue
        day = str(e.get("at") or "")[:10]
        if len(day) != 10:
            continue
        who = str(e.get("actor_id") or "").strip() or NOBODY
        tid = str(e.get("task_id") or "").strip()
        led = st["tasks"].setdefault(tid, {"r": 0, "v": 0}) if tid else None
        bucket = st["days"].setdefault(day, {}).setdefault(who, {})
        bucket[kind] = int(bucket.get(kind) or 0) + 1
        if kind == events.KIND_STAGE:
            # «Закрито» — це СТАДІЯ, а не окремий вид події. Судимо тут, за
            # переліком закритих стадій самого Task Desk: якби це рахував звіт,
            # він мусив би завести власне уявлення про те, що таке «закрито».
            if str((e.get("details") or {}).get("stage") or "") in tasks.STAGES_CLOSED:
                bucket[COUNT_CLOSED] = int(bucket.get(COUNT_CLOSED) or 0) + 1
        if kind == events.KIND_RESULT and led is not None:
            led["r"] = int(led.get("r") or 0) + 1
            if led["r"] > 1:
                # Результат удруге по тій самій задачі: з першого разу не пройшло.
                bucket[COUNT_REWORK] = int(bucket.get(COUNT_REWORK) or 0) + 1
        elif kind == events.KIND_VERIFIED and led is not None:
            led["v"] = int(led.get("v") or 0) + 1
            if not led.get("vday"):
                # Судимо ПЕРШУ перевірку: скільки результатів їй передувало.
                led["vday"] = day
                led["fp"] = bool(int(led.get("r") or 0) <= 1)
        elif kind == events.KIND_REFUSED:
            st["reasons"].append(
                {"day": day, "who": who, "task_id": tid,
                 "reason": str((e.get("details") or {}).get("reason") or "")[:300]})
            del st["reasons"][:-REASONS_KEEP]
    return st


# ---------------------------------------------------------------------------
# ЗАБІР ПОДІЙ. Дзеркало — СВІЙ рот: доки воно не забрало подію, прибирання її
# не чіпає (див. `taskdesk_events.prune`).
# ---------------------------------------------------------------------------
def ingest(limit: int = 5000) -> dict:
    """Забрати з журналу все нове й скласти в підсумки.

    ⭐ Рот реєструється З ПОЧАТКУ (`from_now=False`), а не з «зараз»: боту
    історія не потрібна, а дзеркалу вона і є матеріалом."""
    events.register(SINK, from_now=False)
    st = _load()
    taken = 0
    # ⭐ ДОЇДАЄМО ДО КІНЦЯ, а не одну пачку. Інакше екран після довгої перерви
    # показав би ЧАСТИНУ роботи й нічого про це не сказав.
    while True:
        was = events.cursor(SINK)
        rows = events.pending(SINK, limit=max(1, int(limit)))
        if not rows:
            break
        fold(rows, st)
        _save(st)
        # Курсор рухається ЛИШЕ після того, як підсумки лягли на диск: інакше
        # падіння між двома рядками зʼїло б події назавжди.
        events.ack(SINK, max(int(r.get("id") or 0) for r in rows))
        taken += len(rows)
        # ⛒ ВИХІД ПО ПОСТУПУ, А НЕ ПО ЗАЛИШКУ. Якщо курсор не зрушив, наступна
        # пачка буде та сама — і читач крутився б вічно, а екран керівника
        # просто не відкрився б. Зупиняємось і КАЖЕМО про це.
        if events.cursor(SINK) <= was:
            sys.stderr.write("[дзеркало] курсор не зрушив на події %d — "
                             "припиняю забір, підсумки неповні\n" % was)
            break
    return {"taken": taken, "cursor": events.cursor(SINK),
            "days": len(st["days"]), "tasks": len(st["tasks"])}


def _window(days: int) -> list:
    """Перелік днів вікна, від сьогодні назад."""
    import datetime as _dt
    n = max(1, int(days or DEFAULT_DAYS))
    try:
        d0 = _dt.date.fromisoformat(clock.now()[:10])
    except Exception:
        return []
    return [(d0 - _dt.timedelta(days=i)).isoformat() for i in range(n)]


def _counts(state: dict, window) -> dict:
    """{людина: {вид: скільки}} за вікно."""
    out = {}
    for day in window:
        for who, kinds in (state["days"].get(day) or {}).items():
            box = out.setdefault(who, {})
            for k, n in (kinds or {}).items():
                box[k] = int(box.get(k) or 0) + int(n or 0)
    return out


def _first_pass(state: dict, window) -> dict:
    """Скільки роботи пройшло з першого разу. Судимо ПЕРШУ перевірку задачі й
    ставимо її в той день, коли вона сталась."""
    ws = set(window)
    total = ok = 0
    for led in (state.get("tasks") or {}).values():
        if str((led or {}).get("vday") or "") in ws:
            total += 1
            ok += 1 if led.get("fp") else 0
    return {"verified": total, "first_time": ok,
            "percent": (int(round(ok * 100.0 / total)) if total else None)}


def _live(rows=None) -> dict:
    """Черга і кинуте — це СТАН, а не історія, тому питаємо живі задачі.

    ⛒ Мірку «задача стоїть» рахує сам Task Desk (`stuck`, зміна 240). Другого
    судді цього правила ми не заводимо: два писарі одного правила — нуль
    писарів."""
    rows = tasks.load_all(include_closed=False) if rows is None else rows
    by_person, by_stage = {}, {}
    for t in rows:
        who = str(t.get("assignee_id") or "").strip() or NOBODY
        p = by_person.setdefault(who, {"open": 0, "stuck": 0, "overdue": 0,
                                       "awaiting_verify": 0})
        st = str(t.get("stage") or "")
        s = by_stage.setdefault(st, {"open": 0, "stuck": 0})
        p["open"] += 1
        s["open"] += 1
        if t.get("stuck"):
            p["stuck"] += 1
            s["stuck"] += 1
        if t.get("overdue"):
            p["overdue"] += 1
        if t.get("awaiting_verify"):
            p["awaiting_verify"] += 1
    # ⛒ Порядок черги — ТОЙ САМИЙ, що в Task Desk, а не випадковий порядок
    # словника: людина читає стадії зліва направо так, як звикла їх бачити.
    ordered = {}
    for st_id in tasks.STAGES_ALL:
        if st_id in by_stage:
            ordered[st_id] = by_stage[st_id]
    for st_id, box in by_stage.items():
        ordered.setdefault(st_id, box)
    return {"by_person": by_person, "by_stage": ordered, "open": len(rows),
            "tempo_days": int((tasks.tempo(rows) or {}).get("days") or 0)}


# ---------------------------------------------------------------------------
# ХТО ЩО БАЧИТЬ. Право рахується з ДЕРЕВА компанії, а не з галочки: галочку
# забувають зняти, а дерево не застаріває [[project_unit_liquidation]].
# ---------------------------------------------------------------------------
def scope_of(viewer_id: str, is_admin: bool = False) -> list:
    """Кого цей глядач має право бачити у дзеркалі: себе і всіх, для кого він
    керівник на будь-якому рівні. Адміністратор бачить компанію."""
    viewer_id = str(viewer_id or "").strip()
    if is_admin:
        return [e["id"] for e in people.employees(True)]
    if not viewer_id:
        raise MirrorError("Дзеркало не показують без імені глядача.")
    if not people.employee(viewer_id):
        raise MirrorError("Такого працівника немає: %s" % viewer_id)
    return [viewer_id] + list(people.subordinates_of(viewer_id))


def _person_row(emp_id: str, cnt: dict, live: dict) -> dict:
    """Один рядок дзеркала — БЕЗ імені. Імʼя доклеює `named()`; так той самий
    рядок годиться і для знеособленого зрізу."""
    c = dict(cnt or {})
    l = dict(live or {})
    return {
        "open": int(l.get("open") or 0),
        "stuck": int(l.get("stuck") or 0),
        "overdue": int(l.get("overdue") or 0),
        "awaiting_verify": int(l.get("awaiting_verify") or 0),
        "created": int(c.get(events.KIND_CREATED) or 0),
        "results": int(c.get(events.KIND_RESULT) or 0),
        "rework": int(c.get(COUNT_REWORK) or 0),
        "verified": int(c.get(events.KIND_VERIFIED) or 0),
        "refused": int(c.get(events.KIND_REFUSED) or 0),
        "comments": int(c.get(events.KIND_COMMENT) or 0),
        "closed": int(c.get(COUNT_CLOSED) or 0),
        "stage_moves": int(c.get(events.KIND_STAGE) or 0),
        "events": sum(int(v or 0) for k, v in c.items()
                      if k not in (COUNT_REWORK, COUNT_CLOSED)),
    }


def since_day(state: dict = None) -> str:
    """З якого дня взагалі є матеріал. Керівник має бачити цю межу очима:
    журнал починається з дня, коли його ввімкнули."""
    st = state if state is not None else _load()
    days = sorted((st.get("days") or {}).keys())
    return days[0] if days else ""


def named(viewer_id: str, is_admin: bool = False, days: int = DEFAULT_DAYS,
          take: bool = True) -> dict:
    """ІМЕННИЙ зріз — лише для екрана вдома. Назовні його не віддають ніколи.

    ⚠ Межа, яку екран мусить сказати вголос: тут видно роботу В СИСТЕМІ."""
    if take:
        ingest()
    st = _load()
    win = _window(days)
    cnt = _counts(st, win)
    live = _live()
    mine = scope_of(viewer_id, is_admin)
    rows = []
    for eid in mine:
        emp = people.employee(eid) or {}
        row = _person_row(eid, cnt.get(eid), (live["by_person"] or {}).get(eid))
        row["id"] = eid
        row["name"] = emp.get("full_name") or eid
        row["silent"] = bool(row["events"] == 0)
        rows.append(row)
    rows.sort(key=lambda r: (-r["open"], -r["events"], r["name"]))
    seen = set(mine)
    reasons = [r for r in (st.get("reasons") or [])
               if r.get("day") in set(win) and r.get("who") in seen]
    return {
        "days": len(win), "since": since_day(st),
        "people": rows,
        "by_stage": live["by_stage"],
        # ⭐ Назви стадій приходять із ЄДИНОГО словника Task Desk: другий
        # словник назв на екрані розійшовся б із першим уже наступного місяця.
        "stage_names": dict(tasks.STAGE_NAMES),
        "tempo_days": live["tempo_days"],
        "open_total": live["open"],
        "first_pass": _first_pass(st, win),
        "refusals": list(reversed(reasons)),
        # ⛒ Дати в текст НЕ склеюємо: день лежить окремо (`since`) машинним
        # виглядом, а по-людськи його пише екран — там, де вже живе єдиний
        # перекладач дат. Інакше у продукті зʼявився б другий формат дати.
        "limits": [
            "Дзеркало міряє роботу в системі: хто працює повз неї — тут невидимий.",
            "Журнал починається з дня, коли його ввімкнули.",
        ],
    }


def anon(days: int = DEFAULT_DAYS, take: bool = True) -> dict:
    """ЗНЕОСОБЛЕНИЙ зріз — ЄДИНИЙ, який узагалі можна віддати назовні.

    ⭐ Тут немає ні ідентифікатора людини, ні назви задачі, ні вільного тексту.
    Люди — «людина 1, людина 2»: для правок продукту досить знати, що працює
    двоє, а не хто вони. Причини відмов лишаються ВДОМА: це слова людей."""
    if take:
        ingest()
    st = _load()
    win = _window(days)
    cnt = _counts(st, win)
    live = _live()
    who = sorted(set(list(cnt.keys()) + list((live["by_person"] or {}).keys())))
    rows = []
    for n, eid in enumerate(who, 1):
        row = _person_row(eid, cnt.get(eid), (live["by_person"] or {}).get(eid))
        row["label"] = "людина %d" % n
        rows.append(row)
    by_stage = {}
    for stage, box in (live["by_stage"] or {}).items():
        by_stage[str(stage)] = {"open": int(box.get("open") or 0),
                                "stuck": int(box.get("stuck") or 0)}
    total = {}
    for box in cnt.values():
        for k, v in (box or {}).items():
            total[k] = int(total.get(k) or 0) + int(v or 0)
    return {
        "days": len(win), "people": len(rows), "rows": rows,
        "by_stage": by_stage, "open_total": live["open"],
        "tempo_days": live["tempo_days"],
        "events": total,
        "refusals": int(total.get(events.KIND_REFUSED) or 0),
        "first_pass": _first_pass(st, win),
    }


def snapshot() -> dict:
    """Стан читача одним поглядом — для консолі й для чеків."""
    st = _load()
    return {"file": str(TOTALS), "exists": TOTALS.exists(),
            "days": len(st.get("days") or {}), "tasks": len(st.get("tasks") or {}),
            "reasons": len(st.get("reasons") or []),
            "cursor": events.cursor(SINK), "since": since_day(st)}
