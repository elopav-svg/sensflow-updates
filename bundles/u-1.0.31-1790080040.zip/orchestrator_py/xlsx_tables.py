# -*- coding: utf-8 -*-
"""xlsx_tables.py — ⭐⭐⭐ ДАНІ ПЕРЕНОСИТЬ КОД, А НЕ МОДЕЛЬ (зміна 600).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ — спільний корінь трьох вад 16.09.2026:

    посилання вели не туди      -> модель ВГАДУВАЛА адресу          (лік 598)
    дані виявились вигаданими   -> модель ПЕРЕПИСУВАЛА числа з голови (лік 599)
    складач учетверо вперся
    в межу довжини              -> модель НЕСЛА В СОБІ всю таблицю

598 і 599 — сторожі: вони ловлять наслідок. Корінь один і той самий: МОВНУ
МОДЕЛЬ ЗМУСИЛИ ПЕРЕНОСИТИ ДАНІ. Мовна модель даних не переносить — вона
переносить НАМІР. Дані переносить код.

⭐ РІШЕННЯ: модель пише ПЛАН («аркуш «Виробництво» — це рядки з файла
Виробництво_серпень_2026.xlsx, колонка «Кількість» звідти, «Сума» — формула»),
а цей модуль ДЕТЕРМІНОВАНО наповнює спеку справжніми числами з доданих файлів.
Тоді вигадати число нема де, промахнутись адресою нема де, а план короткий —
і в межу довжини впиратись нічим.

⛒ ДЖЕРЕЛО — ТОЙ САМИЙ ТЕКСТ, ЩО БАЧИТЬ МОДЕЛЬ (`filetext.build_files_context`):
«## Файл: …», «# Аркуш: …», рядки через « | ». Один текст на двох — інакше
модель планує по одному, а код наповнює з іншого.

🩸 З ОБРІЗАНОГО ДЖЕРЕЛА НЕ ЗВОДИМО НІКОЛИ. `filetext` ріже великі файли і чесно
ставить мітку «…[обрізано». Звести 124 рядки з 80 — це тихо неправильне число,
тобто рівно той клас, який ми лікуємо. Тому — відмова з причиною.
"""
import json
import re

_FILE_RE = re.compile(r"^##\s*Файл:\s*(.+?)\s*$", re.M)
_SHEET_RE = re.compile(r"^#\s*Аркуш:\s*(.+?)\s*$", re.M)
_CUT_MARKS = ("…[обрізано", "...[обрізано", "[обрізано")


def _cell(v: str):
    """Клітинка тексту -> число, якщо воно ЦІЛКОМ число; інакше текст як є."""
    t = (v or "").strip()
    if not t:
        return ""
    t2 = t.replace(" ", "").replace(" ", "").replace("'", "")
    if re.match(r"^-?\d+$", t2):
        try:
            return int(t2)
        except Exception:
            return t
    if re.match(r"^-?\d+[.,]\d+$", t2):
        try:
            return float(t2.replace(",", "."))
        except Exception:
            return t
    return t


def _split_row(line: str) -> list:
    return [c.strip() for c in line.split("|")]


def parse_tables(files_context: str) -> dict:
    """Текст доданих файлів -> {ключ: таблиця}.

    Таблиця: {"file","sheet","columns":[...],"rows":[[...]],"truncated":bool}
    Ключів у кожної таблиці кілька (імʼя файла, імʼя аркуша, «файл#аркуш») —
    щоб план міг назвати її так, як людині природно."""
    out = {}
    text = str(files_context or "")
    if not text.strip():
        return out
    # Ріжемо на файли; усе до першого «## Файл:» ігноруємо.
    marks = list(_FILE_RE.finditer(text))
    blocks = []
    if not marks:
        blocks = [("(без імені)", text)]
    else:
        for i, m in enumerate(marks):
            end = marks[i + 1].start() if i + 1 < len(marks) else len(text)
            blocks.append((m.group(1), text[m.end():end]))

    for fname, body in blocks:
        smarks = list(_SHEET_RE.finditer(body))
        sheets = []
        if not smarks:
            sheets = [("", body)]
        else:
            for i, m in enumerate(smarks):
                end = smarks[i + 1].start() if i + 1 < len(smarks) else len(body)
                sheets.append((m.group(1), body[m.end():end]))
        for sname, sbody in sheets:
            tbl = _one_table(fname, sname, sbody)
            if not tbl:
                continue
            for key in (sname, fname, "%s#%s" % (fname, sname)):
                if key and key not in out:
                    out[key] = tbl
    return out


def _one_table(fname: str, sname: str, body: str):
    """Одна таблиця з тексту аркуша: шапка + рядки тієї самої ширини."""
    truncated = any(mk in body for mk in _CUT_MARKS)
    lines = [ln for ln in body.splitlines() if "|" in ln]
    hdr_i, header = None, None
    for i, ln in enumerate(lines):
        cells = _split_row(ln)
        # ⛒ ШАПКА — ПЕРШИЙ РЯДОК, ДЕ ЗАПОВНЕНІ ВСІ КЛІТИНКИ. Саме так
        # відсікаються службові заголовки згори («ТОВ «…» | | | | |»), через
        # які шапкою ставав рядок назви підприємства, і вся таблиця з'їжджала.
        if len(cells) >= 2 and all(c.strip() for c in cells):
            hdr_i, header = i, [c.strip() for c in cells]
            break
    if header is None:
        return None
    width = len(header)
    rows = []
    for ln in lines[hdr_i + 1:]:
        cells = _split_row(ln)
        if len(cells) != width:
            continue
        if not any(c.strip() for c in cells):
            continue
        rows.append([_cell(c) for c in cells])
    if not rows:
        return None
    return {"file": fname, "sheet": sname, "columns": header,
            "rows": rows, "truncated": truncated}


def catalogue(tables: dict) -> str:
    """⭐⭐⭐ КАТАЛОГ ТАБЛИЦЬ ДЛЯ СКЛАДАЧА (17.09.2026, зміна 602).

    КОРІНЬ, знайдений живим прогоном: план розгортатись відмовився, бо модель
    написала колонку «Стаття» замість «Найменування продукції» і «Номер
    договору» замість «Contract». Вона не вигадувала зловмисно — вона
    ПРИГАДУВАЛА імена, вишукуючи їх у 9000 знаків тексту файлів. Це той самий
    клас, що й вигадані числа, тільки в іменах: мовну модель знову змусили
    ПЕРЕНОСИТИ дані, хай і короткі.

    ⭐ Лік той самий: не змушувати пригадувати. Код уже розібрав таблиці — хай
    він і подасть точні імена одним коротким переліком, який лишається
    СКОПІЮВАТИ. Каталог коштує кількасот знаків і знімає цілий клас відмов."""
    seen, lines = set(), []
    for v in (tables or {}).values():
        if id(v) in seen:
            continue
        seen.add(id(v))
        name = "%s#%s" % (v.get("file"), v.get("sheet")) if v.get("sheet") else v.get("file")
        cols = " | ".join("«%s»" % c for c in (v.get("columns") or []))
        lines.append("• «%s» — рядків даних: %d\n  колонки: %s%s"
                     % (name, len(v.get("rows") or []), cols,
                        "\n  ⚠ ТАБЛИЦЯ ОБРІЗАНА при читанні — зводити підсумки з неї не можна"
                        if v.get("truncated") else ""))
    return "\n".join(lines)


def _norm(s) -> str:
    return re.sub(r"\s+", " ", str(s or "")).strip().lower()


def find_table(tables: dict, name: str):
    """Таблиця за імʼям: точно, без огляду на регістр, далі — за входженням."""
    if not tables:
        return None
    want = _norm(name)
    if not want:
        return None
    for k, v in tables.items():
        if _norm(k) == want:
            return v
    for k, v in tables.items():
        if want in _norm(k) or _norm(k) in want:
            return v
    return None


def _table_names(tables: dict) -> str:
    seen, names = set(), []
    for v in (tables or {}).values():
        key = id(v)
        if key in seen:
            continue
        seen.add(key)
        names.append("%s#%s" % (v.get("file"), v.get("sheet")) if v.get("sheet") else v.get("file"))
    return ", ".join(names) or "(жодної)"


def _letters(s) -> str:
    """Імʼя без розділових знаків і пробілів — щоб «, грн» і «(грн)» не важили."""
    return "".join(ch for ch in _norm(s) if ch.isalnum())


def _col_index(tbl, name):
    """⭐⭐⭐ ІМʼЯ КОЛОНКИ: ДОПУСК НА ВІДМІНОК, АЛЕ ЛИШЕ ОДНОЗНАЧНИЙ ЗБІГ (602б).

    КОРІНЬ, знайдений живим прогоном 17.09.2026: модель узяла імена з каталогу,
    але написала «План маржинальнІСТЬ, %» замість «План маржинальнОСТІ, %».
    Одна літера, звичайний український відмінок — і вся книга не зібралась.

    ⛒ Строгість, яка рятує від ВИГАДКИ, не сміє валити на ГРАМАТИЦІ. Але й
    вгадувати не можна: якщо під опис підходять дві колонки — це вже здогад.
    Тому правило одне: приймаємо тільки збіг, який ОДИН. Два кандидати —
    відмова з переліком наявних імен, як і раніше."""
    want = _norm(name)
    if not want:
        return -1
    cols = [_norm(c) for c in tbl["columns"]]
    if want in cols:
        return cols.index(want)
    # 2) одне ім'я міститься в іншому — і такий кандидат ОДИН
    cand = [i for i, c in enumerate(cols) if want in c or c in want]
    if len(cand) == 1:
        return cand[0]
    # 3) те саме без розділових знаків
    lw = _letters(name)
    lcols = [_letters(c) for c in tbl["columns"]]
    if lw and lw in lcols and lcols.count(lw) == 1:
        return lcols.index(lw)
    cand = [i for i, c in enumerate(lcols) if lw and (lw in c or c in lw)]
    if len(cand) == 1:
        return cand[0]
    # ⛒ ДВА І БІЛЬШЕ ВХОДЖЕНЬ — ЦЕ ДВОЗНАЧНІСТЬ ЗА ВИЗНАЧЕННЯМ. «за од., грн»
    # однаково сидить і в «Ціна за од., грн», і в «Собівартість за од., грн».
    # Тут не можна вибирати «схожіше»: вибір між двома однаково законними
    # тлумаченнями — це здогад, а здогад у фінансах і є та сама вада. Відмова
    # з переліком: складач допише слово й піде далі.
    if len(cand) > 1:
        return -1
    # 4) відмінок і одруки: схожість рядків, але лише якщо переможець ОДИН
    #    і відрив від наступного помітний (інакше це вгадування).
    import difflib
    if not lw:
        return -1
    score = sorted(((difflib.SequenceMatcher(None, lw, c).ratio(), i)
                    for i, c in enumerate(lcols)), reverse=True)
    # ⛒ «Однозначний» — це НЕ «дуже схожий», а «схожий НАБАГАТО більше за решту».
    # «кількости» проти «Кількість» дає 0,78 — для порогу схожості замало, але
    # наступний кандидат має 0,21: відрив утричі, сумніву немає. А ось вигадана
    # «Обсяг реалізації» ні до чого не підходить і близько — і буде відмова.
    if score and score[0][0] >= 0.70 and (len(score) == 1 or score[0][0] - score[1][0] >= 0.20):
        return score[0][1]
    return -1


def _match_where(tbl, row, where) -> bool:
    if not where:
        return True
    for col, cond in where.items():
        i = _col_index(tbl, col)
        if i < 0:
            return False
        val = row[i]
        if isinstance(cond, dict):
            if cond.get("not_empty") and str(val).strip() == "":
                return False
            if cond.get("empty") and str(val).strip() != "":
                return False
        else:
            if _norm(val) != _norm(cond):
                return False
    return True


def resolve(spec, tables: dict, derived: list = None):
    """План -> спека з реальними рядками. Повертає (спека, [помилки]).

    ⛒ 600. `derived` — сюди складаються ВСІ числа, які поставив САМ КОД
    (перенесені з файла і пораховані групуванням). Це не косметика: ворота 599
    судять «чи є число в першоджерелі», а сума 124 щоденних рядків у
    першоджерелі, звісно, не стоїть — її щойно порахував код. Без цього переліку
    власний сторож червонив би власний лік, і ми б отримали рівно ту хибну
    тривогу, через яку 16.09 згоріли два прогони."""
    errs = []
    if derived is None:
        derived = []
    if not isinstance(spec, dict):
        return spec, ["спека не є обʼєктом"]
    sheets = spec.get("sheets") or [spec]
    for sh in sheets:
        if not isinstance(sh, dict):
            continue
        _resolve_params(sh, tables, errs, derived)
        # ⛒ ОДИН АРКУШ — КІЛЬКА ДЖЕРЕЛ РЯДКІВ. Справжній фінансовий аркуш майже
        # завжди складений із двох блоків: номенклатура + загальновиробничі,
        # точки мережі + постійні витрати. Якби джерело було одне, складач мусив
        # би або ламати книгу на зайві аркуші, або дописувати другий блок
        # РУКАМИ — тобто повертатись рівно до тієї вади, яку ми лікуємо.
        blocks = sh.get("blocks")
        if isinstance(blocks, list) and blocks:
            rows = []
            for b in blocks:
                if not isinstance(b, dict):
                    continue
                tmp = {"sheet": sh.get("sheet"), "columns": sh.get("columns")}
                if b.get("group_table") or b.get("by"):
                    tmp["group_table"] = b.get("group_table") or b
                    _resolve_group(tmp, tables, errs, derived)
                else:
                    tmp["from_table"] = b.get("from_table") or b
                    _resolve_from(tmp, tables, errs, derived)
                rows.extend(tmp.get("rows") or [])
            if rows:
                sh["rows"] = rows
            sh.pop("blocks", None)
        elif sh.get("from_table"):
            _resolve_from(sh, tables, errs, derived)
        elif sh.get("group_table"):
            _resolve_group(sh, tables, errs, derived)
    return spec, errs


def _need_table(sh, spot, tables, errs, need_whole=False):
    name = (spot or {}).get("table")
    tbl = find_table(tables, name)
    if not tbl:
        errs.append("аркуш «%s»: таблиці «%s» немає серед доданих файлів. Є: %s"
                    % (sh.get("sheet") or "?", name, _table_names(tables)))
        return None
    if need_whole and tbl.get("truncated"):
        errs.append("аркуш «%s»: таблиця «%s» ОБРІЗАНА при читанні файла — зводити "
                    "з неї підсумки не можна (сума вийде тиха й неправильна). "
                    "Потрібен менший файл або вивантаження без зайвих рядків."
                    % (sh.get("sheet") or "?", name))
        return None
    return tbl


def _resolve_from(sh, tables, errs, derived=None):
    spot = sh.get("from_table") or {}
    tbl = _need_table(sh, spot, tables, errs)
    if not tbl:
        return
    cols = sh.get("columns") or []
    cmap = spot.get("map") or {}
    formulas = spot.get("formulas") or {}
    where = spot.get("where") or {}
    idx = {}
    for tgt, src in cmap.items():
        i = _col_index(tbl, src)
        if i < 0:
            errs.append("аркуш «%s»: у таблиці «%s» немає колонки «%s». Є: %s"
                        % (sh.get("sheet") or "?", spot.get("table"), src,
                           ", ".join(tbl["columns"])))
            return
        idx[_norm(tgt)] = i
    for col in where:
        if _col_index(tbl, col) < 0:
            errs.append("аркуш «%s»: відбір за колонкою «%s», якої в таблиці «%s» немає. Є: %s"
                        % (sh.get("sheet") or "?", col, spot.get("table"),
                           ", ".join(tbl["columns"])))
            return
    rows = []
    for r in tbl["rows"]:
        if not _match_where(tbl, r, where):
            continue
        out = []
        for c in cols:
            k = _norm(c)
            if k in idx:
                out.append(r[idx[k]])
            elif c in formulas:
                out.append(formulas[c])
            else:
                f = next((v for kk, v in formulas.items() if _norm(kk) == k), None)
                out.append(f if f is not None else "")
        rows.append(out)
    if not rows:
        errs.append("аркуш «%s»: з таблиці «%s» не відібрано жодного рядка "
                    "(перевір відбір where)" % (sh.get("sheet") or "?", spot.get("table")))
        return
    sh["rows"] = rows
    _note(derived, rows)
    sh.pop("from_table", None)


def _resolve_group(sh, tables, errs, derived=None):
    spot = sh.get("group_table") or {}
    tbl = _need_table(sh, spot, tables, errs, need_whole=True)
    if not tbl:
        return
    by = spot.get("by")
    bi = _col_index(tbl, by)
    if bi < 0:
        errs.append("аркуш «%s»: групування за колонкою «%s», якої в таблиці «%s» немає. Є: %s"
                    % (sh.get("sheet") or "?", by, spot.get("table"),
                       ", ".join(tbl["columns"])))
        return
    sums = spot.get("sum") or {}
    sidx = {}
    for tgt, src in sums.items():
        i = _col_index(tbl, src)
        if i < 0:
            errs.append("аркуш «%s»: у таблиці «%s» немає колонки «%s». Є: %s"
                        % (sh.get("sheet") or "?", spot.get("table"), src,
                           ", ".join(tbl["columns"])))
            return
        sidx[_norm(tgt)] = i
    where = spot.get("where") or {}
    order, acc = [], {}
    for r in tbl["rows"]:
        if not _match_where(tbl, r, where):
            continue
        key = r[bi]
        if key not in acc:
            acc[key] = {}
            order.append(key)
        for k, i in sidx.items():
            v = r[i]
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                acc[key][k] = acc[key].get(k, 0) + v
    if not order:
        errs.append("аркуш «%s»: групувати нема що — з таблиці «%s» не відібрано рядків"
                    % (sh.get("sheet") or "?", spot.get("table")))
        return
    cols = sh.get("columns") or []
    formulas = spot.get("formulas") or {}
    rows = []
    for key in order:
        out = []
        for ci, c in enumerate(cols):
            k = _norm(c)
            if ci == 0:
                out.append(key)
            elif k in sidx:
                v = acc[key].get(k, 0)
                out.append(round(v, 6) if isinstance(v, float) else v)
            else:
                f = next((v for kk, v in formulas.items() if _norm(kk) == k), None)
                out.append(f if f is not None else "")
        rows.append(out)
    sh["rows"] = rows
    _note(derived, rows)
    sh.pop("group_table", None)


def _resolve_params(sh, tables, errs, derived=None):
    params = sh.get("params")
    if not isinstance(params, list):
        return
    for p in params:
        if not isinstance(p, dict) or not p.get("from_table"):
            continue
        spot = p.get("from_table") or {}
        tbl = find_table(tables, spot.get("table"))
        if not tbl:
            errs.append("параметр «%s»: таблиці «%s» немає серед доданих файлів. Є: %s"
                        % (p.get("name"), spot.get("table"), _table_names(tables)))
            continue
        take = spot.get("take")
        ti = _col_index(tbl, take)
        if ti < 0:
            errs.append("параметр «%s»: у таблиці «%s» немає колонки «%s». Є: %s"
                        % (p.get("name"), spot.get("table"), take, ", ".join(tbl["columns"])))
            continue
        where = spot.get("where") or {}
        val = None
        for r in tbl["rows"]:
            if _match_where(tbl, r, where):
                val = r[ti]
                break
        if val is None:
            errs.append("параметр «%s»: у таблиці «%s» немає рядка за умовою %s"
                        % (p.get("name"), spot.get("table"), where))
            continue
        # «9 %» у файлі -> 0,09 у книзі: відсоткова колонка показує ЧАСТКУ.
        if spot.get("percent") and isinstance(val, (int, float)) and not isinstance(val, bool):
            val = val / 100.0
        p["value"] = val
        _note(derived, [[val]])
        p.pop("from_table", None)


def _note(derived, rows) -> None:
    """Запамʼятати числа, які поставив КОД (для воріт 599)."""
    if derived is None:
        return
    for r in rows or []:
        for v in (r or []):
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                derived.append(v)


def derived_text(values) -> str:
    """Числа, поставлені кодом, як текст-джерело для воріт.

    🩸 РОЗДІЛЯЄМО ПЕРЕВЕДЕННЯМ РЯДКА, А НЕ ПРОБІЛОМ. У числах українською пробіл —
    це роздільник тисяч («41 812 497»), тому читач чисел навмисно дозволяє пробіл
    усередині числа. Через це «2885510 46500», написані через пробіл, злипались в
    одне число, і сторож 599 не знаходив жодного з них — тобто червонив власний
    лік. Знайдено на наскрізній пробі, до живого прогону."""
    out = []
    for v in values or []:
        out.append(("%d" % int(v)) if float(v).is_integer() else ("%.6f" % v).rstrip("0").rstrip("."))
    return "\n".join(out)


_FENCE_RE = re.compile(r"(```+[ \t]*xlsxmodel[ \t]*\r?\n)(.*?)(```+)", re.S | re.I)


def resolve_markdown(md: str, files_context: str):
    """Розгортає план ПРЯМО У ТЕКСТІ відповіді складача.

    Повертає (md, [помилки], текст_чисел_поставлених_кодом).

    Один шов: далі по дорозі і ворота, і записувач файла бачать уже наповнену
    спеку — тобто ніхто не мусить знати про план окремо."""
    if not md or "xlsxmodel" not in md:
        return md, [], ""
    m = _FENCE_RE.search(md)
    if not m:
        return md, [], ""
    raw = (m.group(2) or "").strip()
    if ("from_table" not in raw and "group_table" not in raw
            and "\"blocks\"" not in raw):
        return md, [], ""       # звичайна спека — нічого не робимо
    tables = parse_tables(files_context)
    try:
        spec = json.loads(raw)
    except Exception as e:
        return md, ["план не читається як JSON (%s)" % e], ""
    if not tables:
        return md, ["план просить брати дані з доданих файлів, але жодної таблиці "
                    "у файлах не знайдено"], ""
    _derived = []
    spec, errs = resolve(spec, tables, _derived)
    if errs:
        return md, errs, ""
    body = json.dumps(spec, ensure_ascii=False)
    return (md[:m.start()] + m.group(1) + body + "\n" + m.group(3) + md[m.end():],
            [], derived_text(_derived))
