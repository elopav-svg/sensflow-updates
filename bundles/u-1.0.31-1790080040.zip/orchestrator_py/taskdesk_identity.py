# -*- coding: utf-8 -*-
"""
taskdesk_identity.py — ШАР «ХТО ЦЕ»: облікові записи, паролі, сесії, доступи.

Крок 1.2 етапу 1 (проєкт: «Аудити та стратегії\\TaskDesk_етап1_детальний_проєкт_06.08.2026.md»).

⭐⭐⭐ НАВІЩО ЦЕ ВЗАГАЛІ. Донині платформа була одноосібна: `license.role()` віддавав
`admin` кому завгодно, тобто будь-хто міг усе. Рішення Андрія 06.08.2026 — чесний
шлях: логін, пароль і сесія ОКРЕМИМ ШАРОМ, у якого решта продукту лише питає
«хто це». Це і є прямий шлях до мультикористувацької платформи.

ДВА РІЗНІ ПОНЯТТЯ, ЯКІ ТУТ СВІДОМО НЕ ЗМІШАНІ:
  • **обліковий запис** — вхід у платформу (логін, пароль, сесія);
  • **працівник** — людина в оргструктурі (`taskdesk_people`).
Звʼязок один-до-одного. Джерело правди про ЛЮДИНУ одне — оргструктура; тут лежить
тільки те, що стосується входу. Тому звільнення працівника САМО відрізає доступ:
другої дії робити не треба й забути про неї неможливо.

ДОСТУПИ (рішення Андрія 24, 06.08.2026):
  • **шари** — за замовчуванням у нового запису лише `taskdesk`;
  • **оркестратор** — `none` (нічого) · `systems` (перелік id) · `all` (уся платформа);
    за замовчуванням `none`.
Ці ж доступи потім роздаватимуть нові шари (CRM, месенджер) — консоль одна.

ПАРОЛІ: у файлі лежить ЛИШЕ хеш і сіль (PBKDF2-HMAC-SHA256, стандартна бібліотека —
щоб працювало в закритому контурі без жодної сторонньої залежності).

ЧЕСНА МЕЖА ЦЬОГО КРОКУ: тут немає обмеження частоти спроб входу і немає
відновлення пароля — це кроки 1.3 і 1.6 (локальний батник на машині власника).
"""

import hashlib
import json
import secrets
import uuid
from datetime import datetime, timedelta

import clock
import config
import taskdesk_people as people
import taskdesk_link_codes as link_codes   # разові коди підключення чату
import one_writer
import seats

DESK_DIR = config.STATE_DIR / "taskdesk"

# ⛒ ДРУГИЙ ЗАМОК (27.08.2026): чек, завантажений не через файл, не сміє
# працювати по бойовому стану — тут лежать живі люди, ролі й задачі.
config.refuse_live_state_for_checks(__name__)
ACCOUNTS_JSON = DESK_DIR / "accounts.json"
SESSIONS_JSON = DESK_DIR / "sessions.json"

AUDIT_KEEP = 200
MIN_PASSWORD = 8
SESSION_TTL_HOURS = 12
PBKDF2_ROUNDS = 200_000

# Доступ до оркестратора
ORCH_NONE, ORCH_SYSTEMS, ORCH_ALL = "none", "systems", "all"
ORCH_MODES = (ORCH_NONE, ORCH_SYSTEMS, ORCH_ALL)

LAYER_TASKDESK = "taskdesk"
DEFAULT_LAYERS = (LAYER_TASKDESK,)

# Похідне: ніколи не лежить на диску.
DERIVED_ACC = ("employee_name", "employee_active", "broken", "broken_reason", "can_login")


class IdentityError(Exception):
    """Відмова, названа людськими словами."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def light_mode() -> bool:
    """ЛЕГКИЙ РЕЖИМ (вибір себе зі списку без пароля) — це ПЕРЕМИКАЧ того самого
    шару, а не друга гілка коду. За замовчуванням вимкнений: мовчазний вхід без
    пароля мусить бути свідомим рішенням власника, а не станом за замовчуванням."""
    return _s(config.ENV.get("TASKDESK_LIGHT_LOGIN")) == "1"


# ---------------------------------------------------------------------------
# Паролі
# ---------------------------------------------------------------------------
def _hash(password: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", (password or "").encode("utf-8"),
                               bytes.fromhex(salt), PBKDF2_ROUNDS).hex()


def _new_salt() -> str:
    return secrets.token_hex(16)


# ---------------------------------------------------------------------------
# ОДИН НОРМАЛІЗАТОР
# ---------------------------------------------------------------------------
def _normalize_acc(raw) -> dict:
    if not isinstance(raw, dict):
        raw = {}
    accounts = []
    for a in (raw.get("accounts") or []):
        if not isinstance(a, dict):
            continue
        orch = a.get("orchestrator") or {}
        mode = _s(orch.get("mode")) or ORCH_NONE
        if mode not in ORCH_MODES:
            mode = ORCH_NONE
        accounts.append({
            "id": _s(a.get("id")) or ("acc-" + uuid.uuid4().hex[:8]),
            "login": _s(a.get("login")).lower(),
            "salt": _s(a.get("salt")),
            "pwd_hash": _s(a.get("pwd_hash")),
            "employee_id": _s(a.get("employee_id")),
            "is_admin": bool(a.get("is_admin")),
            "active": bool(a.get("active", True)),
            "layers": sorted({_s(x) for x in (a.get("layers") or DEFAULT_LAYERS) if _s(x)}),
            "orchestrator": {"mode": mode,
                             "systems": sorted({_s(x) for x in (orch.get("systems") or []) if _s(x)})},
            "created_at": _s(a.get("created_at")),
            "password_changed_at": _s(a.get("password_changed_at")),
            # Привʼязка каналу: телеграм-чат, з якого ця людина діє (ворота 4).
            "telegram_chat_id": _s(a.get("telegram_chat_id")),
        })
    # Похідне: хто ця людина в оргструктурі і чи може вона взагалі заходити.
    for a in accounts:
        emp = people.employee(a["employee_id"]) if a["employee_id"] else None
        reasons = []
        if not a["login"]:
            reasons.append("немає логіна")
        if not a["pwd_hash"] and not light_mode():
            reasons.append("пароль не заданий")
        if not emp:
            reasons.append("працівника «%s» немає в оргструктурі" % a["employee_id"])
        a["employee_name"] = _s(emp.get("full_name")) if emp else ""
        a["employee_active"] = bool(emp and emp["active"])
        a["broken"] = bool(reasons)
        a["broken_reason"] = "; ".join(reasons)
        a["can_login"] = bool(a["active"] and a["employee_active"] and not reasons)
    return {"accounts": accounts,
            "audit": [x for x in (raw.get("audit") or []) if isinstance(x, dict)]}


def _strip_derived(state: dict) -> dict:
    out = {"accounts": [], "audit": list(state.get("audit") or [])}
    for a in state.get("accounts") or []:
        out["accounts"].append({k: v for k, v in a.items() if k not in DERIVED_ACC})
    return out


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ / ОДИН ПИСАР — облікові записи
# ---------------------------------------------------------------------------
def load() -> dict:
    """ЄДИНИЙ ЧИТАЧ облікових записів."""
    if not ACCOUNTS_JSON.exists():
        st = _normalize_acc({})
        st["unreadable_reason"] = ""
        return st
    try:
        raw = one_writer.read_json(ACCOUNTS_JSON)
        st = _normalize_acc(raw if isinstance(raw, dict) else {})
        st["unreadable_reason"] = ("" if isinstance(raw, dict)
                                   else "у файлі не записи, а %s" % type(raw).__name__)
        return st
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception as e:
        st = _normalize_acc({})
        st["unreadable_reason"] = "файл не читається: %s" % type(e).__name__
        return st


def save(state: dict, reason: str) -> dict:
    """ЄДИНЕ місце, де облікові записи лягають на диск. FAIL-CLOSED над побитим файлом."""
    if not _s(reason):
        raise IdentityError("зміна без причини не пишеться: журнал доступів мусить "
                            "лишатись читабельним")
    on_disk = load()
    if on_disk.get("unreadable_reason"):
        raise IdentityError("файл облікових записів не читається (%s) — писати поверх "
                            "заборонено" % on_disk["unreadable_reason"])
    st = _normalize_acc(state)
    disk = _strip_derived(st)
    disk["audit"] = list(disk.get("audit") or [])
    disk["audit"].append({"at": clock.now(), "what": _s(reason)[:300]})
    disk["audit"] = disk["audit"][-AUDIT_KEEP:]
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(ACCOUNTS_JSON, disk)
    out = _normalize_acc(disk)
    out["unreadable_reason"] = ""
    return out


def accounts() -> list:
    return load()["accounts"]


def account(acc_id: str) -> dict:
    for a in load()["accounts"]:
        if a["id"] == _s(acc_id):
            return a
    return None


def account_by_login(login: str) -> dict:
    lg = _s(login).lower()
    for a in load()["accounts"]:
        if a["login"] == lg:
            return a
    return None


def account_of_employee(emp_id: str) -> dict:
    for a in load()["accounts"]:
        if a["employee_id"] == _s(emp_id):
            return a
    return None


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ / ОДИН ПИСАР — сесії
# ---------------------------------------------------------------------------
def _load_sessions() -> list:
    """ЄДИНИЙ ЧИТАЧ сесій. Побитий файл не валить вхід — він просто порожній."""
    if not SESSIONS_JSON.exists():
        return []
    try:
        raw = one_writer.read_json(SESSIONS_JSON)
        return [s for s in (raw.get("sessions") or []) if isinstance(s, dict)]
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        return []


def _save_sessions(sessions: list):
    """ЄДИНЕ місце, де сесії лягають на диск. Сесії живуть у файлі, а не в памʼяті:
    перезапуск сервера (а він у нас після кожного оновлення) не мусить викидати
    всіх працівників із системи."""
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(SESSIONS_JSON, {"sessions": sessions})


def _now_dt() -> datetime:
    return datetime.fromisoformat(clock.now())


# ---------------------------------------------------------------------------
# Заведення й зміна облікових записів
# ---------------------------------------------------------------------------
@one_writer.guard("ACCOUNTS_JSON")
def create_account(login: str, password: str, employee_id: str,
                   is_admin: bool = False) -> dict:
    st = load()
    login = _s(login).lower()
    emp_id = _s(employee_id)
    if not login:
        raise IdentityError("обліковий запис без логіна не заводиться")
    if any(a["login"] == login for a in st["accounts"]):
        raise IdentityError("логін «%s» уже зайнятий" % login)
    emp = people.employee(emp_id)
    if not emp:
        raise IdentityError("працівника «%s» немає в оргструктурі — обліковий запис "
                            "заводиться лише на працівника" % emp_id)
    if not emp["active"]:
        raise IdentityError("працівник «%s» звільнений — вхід йому не заводиться"
                            % emp["full_name"])
    if any(a["employee_id"] == emp_id for a in st["accounts"]):
        raise IdentityError("у працівника «%s» уже є обліковий запис (один до одного)"
                            % emp["full_name"])
    if not light_mode() and len(_s(password)) < MIN_PASSWORD:
        raise IdentityError("пароль коротший за %d знаків — так вхід не захищений"
                            % MIN_PASSWORD)
    salt = _new_salt()
    rec = {"id": "acc-" + uuid.uuid4().hex[:8], "login": login, "salt": salt,
           "pwd_hash": _hash(password, salt) if _s(password) else "",
           "employee_id": emp_id, "is_admin": bool(is_admin), "active": True,
           # ⭐ Замовчування, яке назвав Андрій: лише Task Desk і жодного
           # оркестратора, поки доступ не надали явно.
           "layers": list(DEFAULT_LAYERS),
           "orchestrator": {"mode": ORCH_NONE, "systems": []},
           "created_at": clock.now(), "password_changed_at": clock.now()}
    st["accounts"].append(rec)
    save(st, "заведено обліковий запис «%s» для «%s»" % (login, emp["full_name"]))
    return account(rec["id"])


def bootstrap_admin(login: str, password: str, employee_id: str) -> dict:
    """Перший запуск: адміністратор заводиться лише тоді, коли записів ЩЕ НЕМАЄ.
    Інакше це був би чорний хід повз консоль доступів."""
    if load()["accounts"]:
        raise IdentityError("адміністратор уже є — нові записи заводяться в консолі "
                            "доступів, а не цим шляхом")
    acc = create_account(login, password, employee_id, is_admin=True)
    return set_orchestrator_access(acc["id"], ORCH_ALL)


@one_writer.guard("ACCOUNTS_JSON")
def set_password(acc_id: str, password: str) -> dict:
    st = load()
    by_id = {a["id"]: a for a in st["accounts"]}
    acc_id = _s(acc_id)
    if acc_id not in by_id:
        raise IdentityError("облікового запису «%s» немає" % acc_id)
    if len(_s(password)) < MIN_PASSWORD:
        raise IdentityError("пароль коротший за %d знаків" % MIN_PASSWORD)
    salt = _new_salt()
    by_id[acc_id]["salt"] = salt
    by_id[acc_id]["pwd_hash"] = _hash(password, salt)
    by_id[acc_id]["password_changed_at"] = clock.now()
    save(st, "змінено пароль запису «%s»" % by_id[acc_id]["login"])
    # Зміна пароля обриває чужі сесії цього запису: інакше вкрадений токен
    # переживав би заміну пароля.
    _save_sessions([s for s in _load_sessions() if s.get("account_id") != acc_id])
    return account(acc_id)


@one_writer.guard("ACCOUNTS_JSON")
def set_active(acc_id: str, active: bool) -> dict:
    st = load()
    by_id = {a["id"]: a for a in st["accounts"]}
    acc_id = _s(acc_id)
    if acc_id not in by_id:
        raise IdentityError("облікового запису «%s» немає" % acc_id)
    by_id[acc_id]["active"] = bool(active)
    save(st, ("розблоковано " if active else "заблоковано ") + "запис «%s»"
         % by_id[acc_id]["login"])
    if not active:
        _save_sessions([s for s in _load_sessions() if s.get("account_id") != acc_id])
    return account(acc_id)


def _admins_left(st, without_id: str = "", lowering: str = "") -> int:
    """Скільки адміністраторів лишиться, якщо прибрати цей запис або зняти рівень.

    ⛒ НАВІЩО. Платформа без жодного адміністратора — це та сама пастка, з якої
    ми виходимо: рівні роздає адміністратор, і якщо останній зняв його сам із
    себе, повернути права не може вже НІХТО, крім правки файла руками."""
    n = 0
    for a in st["accounts"]:
        if a["id"] == _s(without_id) or a["id"] == _s(lowering):
            continue
        if a["is_admin"] and a["active"]:
            n += 1
    return n


@one_writer.guard("ACCOUNTS_JSON")
def set_admin(acc_id: str, is_admin: bool) -> dict:
    """⭐⭐⭐ 588: РІВЕНЬ МІНЯЄТЬСЯ ПІСЛЯ СТВОРЕННЯ ЗАПИСУ.

    Доти рівень адміністратора можна було задати ЛИШЕ при народженні запису:
    у консолі доступів були пароль, вмикання, шари й оркестратор — і жодного
    писаря рівня. Разом із правилом «один працівник — один запис» це означало,
    що помилку в рівні не виправити взагалі нічим, крім правки `accounts.json`
    руками. 15.09.2026 у Каспера саме так і довелось зробити.

    Діє ОДРАЗУ: наступний запит уже судять по-новому, без перезапуску служби."""
    st = load()
    by_id = {a["id"]: a for a in st["accounts"]}
    acc_id = _s(acc_id)
    if acc_id not in by_id:
        raise IdentityError("облікового запису «%s» немає" % acc_id)
    want = bool(is_admin)
    acc = by_id[acc_id]
    if acc["is_admin"] and not want and _admins_left(st, lowering=acc_id) < 1:
        raise IdentityError(
            "це останній адміністратор — знявши з нього рівень, права не зможе "
            "повернути вже ніхто. Спершу зробіть адміністратором когось іншого")
    acc["is_admin"] = want
    save(st, ("надано" if want else "знято") + " рівень адміністратора запису «%s»"
         % acc["login"])
    return account(acc_id)


@one_writer.guard("ACCOUNTS_JSON")
def remove_account(acc_id: str) -> dict:
    """⭐⭐⭐ 588: ЗАПИС ПРИБИРАЄТЬСЯ. Правило «один працівник — один запис»
    охороняє від двійників, але без прибирання воно ставало пасткою: заведений
    не тому працівникові або з чужим рівнем запис лишався назавжди.

    ⛒ Прибираємо САМ ЗАПИС, а не працівника: оргструктура — інша сутність і
    живе своїм життям. Сесії цього запису обриваються тут-таки, інакше
    прибраний зміг би доробити зміну з відкритої вкладки."""
    st = load()
    by_id = {a["id"]: a for a in st["accounts"]}
    acc_id = _s(acc_id)
    if acc_id not in by_id:
        raise IdentityError("облікового запису «%s» немає" % acc_id)
    acc = by_id[acc_id]
    if acc["is_admin"] and _admins_left(st, without_id=acc_id) < 1:
        raise IdentityError(
            "це останній адміністратор — прибравши його, керувати доступами не "
            "зможе вже ніхто. Спершу зробіть адміністратором когось іншого")
    st["accounts"] = [a for a in st["accounts"] if a["id"] != acc_id]
    save(st, "прибрано обліковий запис «%s»" % acc["login"])
    _save_sessions([x for x in _load_sessions() if x.get("account_id") != acc_id])
    return {"removed": acc_id, "login": acc["login"]}


@one_writer.guard("ACCOUNTS_JSON")
def set_layers(acc_id: str, layers) -> dict:
    st = load()
    by_id = {a["id"]: a for a in st["accounts"]}
    acc_id = _s(acc_id)
    if acc_id not in by_id:
        raise IdentityError("облікового запису «%s» немає" % acc_id)
    by_id[acc_id]["layers"] = sorted({_s(x) for x in (layers or []) if _s(x)})
    save(st, "змінено шари доступу запису «%s»" % by_id[acc_id]["login"])
    return account(acc_id)


@one_writer.guard("ACCOUNTS_JSON")
def set_orchestrator_access(acc_id: str, mode: str, systems=None) -> dict:
    """Доступ до оркестратора: нічого · перелік систем · уся платформа."""
    st = load()
    by_id = {a["id"]: a for a in st["accounts"]}
    acc_id, mode = _s(acc_id), _s(mode)
    if acc_id not in by_id:
        raise IdentityError("облікового запису «%s» немає" % acc_id)
    if mode not in ORCH_MODES:
        raise IdentityError("невідомий рівень доступу «%s»: буває %s"
                            % (mode, ", ".join(ORCH_MODES)))
    ids = sorted({_s(x) for x in (systems or []) if _s(x)})
    if mode == ORCH_SYSTEMS and not ids:
        raise IdentityError("режим «перелік систем» без жодної системи — це те саме, "
                            "що «нічого»; назвіть системи або оберіть «нічого»")
    by_id[acc_id]["orchestrator"] = {"mode": mode,
                                     "systems": ids if mode == ORCH_SYSTEMS else []}
    save(st, "змінено доступ до оркестратора для «%s»" % by_id[acc_id]["login"])
    return account(acc_id)


# ---------------------------------------------------------------------------
# Вхід, вихід, сесія
# ---------------------------------------------------------------------------
_DENY_LOGIN = "логін або пароль не підходять"


def login(login_name: str, password: str) -> str:
    """Вхід за паролем. Повертає токен сесії.

    Відмова НЕ каже, що саме не так: інакше чужа людина дізнається, які логіни
    існують. Причина лягає в журнал, а не в очі тому, хто стукає."""
    acc = account_by_login(login_name)
    if not acc or not acc["can_login"] or not acc["salt"] or not acc["pwd_hash"]:
        raise IdentityError(_DENY_LOGIN)
    if not secrets.compare_digest(_hash(password, acc["salt"]), acc["pwd_hash"]):
        raise IdentityError(_DENY_LOGIN)
    return _open_session(acc["id"])


def login_light(acc_id: str) -> str:
    """ЛЕГКИЙ РЕЖИМ: вибір себе зі списку без пароля. Працює ЛИШЕ коли власник
    свідомо ввімкнув перемикач; інакше — відмова з причиною."""
    if not light_mode():
        raise IdentityError("вхід без пароля вимкнений: увімкніть легкий режим "
                            "(TASKDESK_LIGHT_LOGIN=1), якщо довіряєте своїй мережі")
    acc = account(acc_id)
    if not acc or not acc["can_login"]:
        raise IdentityError("цей обліковий запис не може зайти")
    return _open_session(acc["id"])


def _accounts_of(sessions) -> list:
    """ХТО ЦЕ, а не СКІЛЬКИ ВІКОНЕЦЬ. Одна людина може сидіти на робочому
    компʼютері й на телефоні — це дві сесії й ОДИН працівник. Лічильник, що
    рахує токени, збрехав би клієнту вдвічі саме тоді, коли на нього дивляться."""
    out = []
    for s in (sessions or []):
        a = _s(s.get("account_id"))
        if a and a not in out:
            out.append(a)
    return out


def active_accounts() -> list:
    """Хто зараз у системі: працівники з живими сесіями. Єдина відповідь на
    питання «скільки нас» — щоб екран, лічильник і консоль не рахували кожен
    по-своєму."""
    now = clock.now()
    live = [s for s in _load_sessions() if _s(s.get("expires_at")) > now]
    return _accounts_of(live)


@one_writer.guard("SESSIONS_JSON")
def _open_session(acc_id: str) -> str:
    token = secrets.token_urlsafe(32)
    now = _now_dt()
    sessions = [s for s in _load_sessions()
                if _s(s.get("expires_at")) > now.isoformat(timespec="seconds")]
    sessions.append({"token": token, "account_id": acc_id,
                     "created_at": now.isoformat(timespec="seconds"),
                     "expires_at": (now + timedelta(hours=SESSION_TTL_HOURS)
                                    ).isoformat(timespec="seconds")})
    _save_sessions(sessions)
    seats.note(_accounts_of(sessions))
    return token


@one_writer.guard("SESSIONS_JSON")
def logout(token: str):
    left = [s for s in _load_sessions() if s.get("token") != _s(token)]
    _save_sessions(left)
    seats.note(_accounts_of(left))


def actor(token: str) -> dict:
    """ХТО ЦЕ. Єдина відповідь на питання «від чийого імені йде дія».

    Порожньо — значить НЕ ВІДОМО, і це завжди відмова, ніколи не «адмін за
    замовчуванням». Звільнення працівника відрізає доступ саме тут: правда про
    людину живе в оргструктурі, а не другою копією в записі входу."""
    tok = _s(token)
    if not tok:
        return None
    now = clock.now()
    for s in _load_sessions():
        if s.get("token") != tok:
            continue
        if _s(s.get("expires_at")) <= now:
            return None
        acc = account(_s(s.get("account_id")))
        if not acc or not acc["can_login"]:
            return None
        return acc
    return None


# ---------------------------------------------------------------------------
# ⭐ ВОРОТА 1: «ХТО ЦЕ» НА ВХОДІ В КОНСОЛЬ (крок 1.3)
# ---------------------------------------------------------------------------
COOKIE_NAME = "sf_session"

# Білий список: що віддається БЕЗ входу. Сторінки (html, js, css) — завжди:
# вони самі й покажуть екран входу. Із запитів даних — лише ці.
PUBLIC_API = (
    "/api/health",
    "/api/version",
    "/api/taskdesk/login",
    "/api/taskdesk/logout",
    "/api/taskdesk/whoami",
    "/api/taskdesk/light_list",
)


def login_required() -> bool:
    """Чи вимагати вхід узагалі.

    ⭐ РІШЕННЯ 06.08.2026: у одноосібного клієнта (Каспер) вхід НЕ вмикається
    сам по собі — ламати живу роботу посеред тендеру не можна. Він зʼявляється
    тоді, коли зʼявився ДРУГИЙ обліковий запис, тобто коли компанія справді
    стала багатокористувацькою. Власник може ввімкнути його й раніше рядком
    TASKDESK_LOGIN=1."""
    if _s(config.ENV.get("TASKDESK_LOGIN")) == "1":
        return True
    return len([a for a in load()["accounts"] if a["can_login"]]) >= 2


def token_from_cookies(cookie_header: str) -> str:
    for part in _s(cookie_header).split(";"):
        name, _, value = part.strip().partition("=")
        if name.strip() == COOKIE_NAME:
            return value.strip()
    return ""


def cookie_header(token: str, ttl_hours: int = SESSION_TTL_HOURS) -> str:
    """Кука сесії. HttpOnly — щоб її не міг прочитати жоден скрипт у сторінці."""
    return ("%s=%s; Path=/; HttpOnly; SameSite=Lax; Max-Age=%d"
            % (COOKIE_NAME, _s(token), int(ttl_hours) * 3600))


def clear_cookie_header() -> str:
    return "%s=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0" % COOKIE_NAME


def web_gate(path: str, cookie_header_value: str) -> tuple:
    """ЄДИНЕ місце, яке вирішує, пускати запит у консоль чи ні.

    Повертає (пускати, актор, причина відмови словами). Викликається РІВНО
    один раз на початку `do_GET` і `do_POST` — не в кожному з ~60 обробників,
    інакше новий обробник забуде спитати, і ворота протечуть саме там."""
    p = _s(path)
    who = actor(token_from_cookies(cookie_header_value))
    if not p.startswith("/api/"):
        return True, who, ""              # сторінки й статика — завжди
    if p in PUBLIC_API:
        return True, who, ""
    if not login_required():
        return True, who, ""              # одноосібний режим: як і було
    if not who:
        return False, None, ("увійдіть під своїм працівником: платформа не виконує "
                             "роботу від нікого")
    return True, who, ""


# ---------------------------------------------------------------------------
def is_admin(acc: dict = None) -> bool:
    """⭐⭐⭐ ОДНА ВІДПОВІДЬ «ЧИ ЦЕ АДМІНІСТРАТОР» НА ВСІ КАНАЛИ.

    Доти її давав лише екран (`taskdesk_api._is_admin`), а рот не знав про
    адміністратора нічого. Поки адмінський шар був ВУЗЬКИЙ, це нікому не
    заважало. Щойно адміністратор дістав ПОВНІ права (рішення Андрія
    09.08.2026), друга відповідь у другому місці означала б, що на екрані
    кнопка є, а в телефоні її немає — тобто платформа бреше в одному з двох.

    ⚠ Поки вхід не вимагається (один обліковий запис), господар машини і Є
    адміністратор — та сама умова, що в `_require_admin`."""
    if not login_required():
        return True
    return bool((acc or {}).get("is_admin"))


def is_creator(acc: dict = None) -> bool:
    """⭐⭐⭐ ОДНА ВІДПОВІДЬ «ЧИ ЦЕ ТВОРЕЦЬ» (зміна 521, 06.09.2026).

    Творець — власник продукту, і він один. Це НЕ рівень у продукті:
    імʼя Творця живе в налаштуваннях НАШОЇ збірки (`SENSFLOW_CREATOR`),
    а клієнтський .env.local складальник пише з нуля — там Творця нема
    ким бути, і другий замок (`config.LICENSE_ADMIN`) тримає окремо.

    ⚠ Поки вхід не вимагається (один обліковий запис), господар машини
    і Є Творець — та сама умова, що в `is_admin`: цей замок НІКОГО не
    виштовхує з його ж системи."""
    if not login_required():
        return True
    login = _s((acc or {}).get("login")).lower()
    return bool(login) and login == _s(config.CREATOR_LOGIN).lower()


# ⭐⭐⭐ ВОРОТА ДОСТУПУ: ЄДИНА ФУНКЦІЯ, ЯКОЮ КОРИСТУЮТЬСЯ ВСІ КАНАЛИ
# ---------------------------------------------------------------------------
def may_use_layer(acc: dict, layer: str) -> tuple:
    if not acc:
        return False, "невідомо, хто діє — вхід не виконано"
    if acc.get("is_admin"):
        return True, ""
    if _s(layer) in (acc.get("layers") or []):
        return True, ""
    return False, "у вас немає доступу до розділу «%s»" % layer


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ОДИН ВІДПОВІДАЧ НА ПИТАННЯ «ХТО ДІЄ» (крок 1.5, 06.08.2026)
# ---------------------------------------------------------------------------
# НАВІЩО. Ворота 1.3 стояли лише на вході в консоль, а роботу запускають ЧОТИРИ
# канали: консоль, ланцюги, телеграм і розклад. Якби кожен канал сам вирішував,
# кого вважати актором, ми б завели чотирьох писарів однієї правди — і той, хто
# завтра забуде спитати, стане дірою. Тому питання «хто діє» має РІВНО одну
# відповідь, і живе вона тут.
OWNER_ID = "owner"


def owner_actor() -> dict:
    """ВЛАСНИК — актор одноосібного режиму. Не лежить на диску й не заводиться
    руками: це та сама людина, що поставила платформу собі.

    ⚠ ЄДИНЕ місце, де ворота пропускають роботу без входу. Свідомо: у клієнта з
    одним обліковим записом (Каспер) вхід не ввімкнений, і ламати йому живу
    роботу посеред тендеру ми не будемо."""
    return {"id": OWNER_ID, "login": OWNER_ID, "employee_id": "",
            "employee_name": "Власник", "is_admin": True, "active": True,
            "can_login": True, "broken": False, "broken_reason": "",
            "layers": list(DEFAULT_LAYERS),
            "orchestrator": {"mode": ORCH_ALL, "systems": []},
            "implicit": True}


def _taskdesk_on() -> bool:
    """Чи ввімкнена робота Task Desk у ЦІЙ збірці (вимикач складу релізу)."""
    try:
        import features
        return bool(features.enabled("taskdesk"))
    except Exception:
        return False


def resolve_actor(session_actor: dict = None) -> dict:
    """ХТО ДІЄ. Повертає обліковий запис або None (=нікому не дозволено).

    Порядок відповіді один для всіх каналів:
      1. є жива сесія — діє ця людина;
      2. Task Desk у збірці вимкнений — діє ВЛАСНИК (робота клієнта як була);
      3. вхід не вимагається (один обліковий запис) — діє той єдиний запис,
         а якщо записів ще немає — ВЛАСНИК;
      4. інакше — None: платформа не виконує роботу від нікого."""
    if session_actor:
        return session_actor
    if not _taskdesk_on():
        return owner_actor()
    if login_required():
        return None
    live = [a for a in accounts() if a.get("can_login")]
    return live[0] if len(live) == 1 else owner_actor()


def account_by_telegram(chat_id) -> dict:
    """Обліковий запис, привʼязаний до телеграм-чату (ворота 4). Немає привʼязки
    — немає актора: здогадуватись за імʼям у профілі ми не будемо."""
    cid = _s(chat_id)
    if not cid:
        return None
    for a in accounts():
        if a.get("telegram_chat_id") == cid and a.get("can_login"):
            return a
    return None


@one_writer.guard("ACCOUNTS_JSON")
def set_telegram(acc_id: str, chat_id) -> dict:
    """Привʼязати телеграм-чат до облікового запису (одна людина — один чат)."""
    cid = _s(chat_id)
    state = load()
    target = None
    for a in state["accounts"]:
        if a["id"] == _s(acc_id):
            target = a
        elif cid and a.get("telegram_chat_id") == cid:
            a["telegram_chat_id"] = ""      # чат не може діяти від двох людей
    if target is None:
        return None
    target["telegram_chat_id"] = cid
    save(state, "привʼязка телеграма: %s" % (cid or "знято"))
    return account(_s(acc_id))


# ---------------------------------------------------------------------------
# ПІДКЛЮЧЕННЯ ЧАТУ РАЗОВИМ КОДОМ (рішення Андрія 08.08.2026)
#
# ⭐⭐⭐ НОМЕР ЧАТУ ЗНАЄ ЛИШЕ ТЕЛЕГРАМ. Його не бачить ні сама людина, ні
# адміністратор — він народжується в мить, коли людина пише боту. Тому план
# «адміністратор впише номер руками» був нездійсненний: вписувати нема звідки.
# Екран може видати РАЗОВИЙ КОД, а звʼязати код із чатом — робота бота.
# Так у привʼязки лишається ОДИН писар, і це саме той, хто знає правду.
#
# ⚠ САМІ КОДИ ЖИВУТЬ У `taskdesk_link_codes` — окремим файлом. Тут їм не
# місце: у цьому шарі на диск пишуть рівно два місця (записи й сесії), і
# третій писар зламав би цей закон (спіймав `taskdesk_identity_test`).
# ⚠ Поле «телеграм» у картці працівника (`people.telegram_id`) — це КОНТАКТ,
# як телефон. Воно НЕ привʼязка і ніколи нею не було.
# ---------------------------------------------------------------------------
def link_code(acc_id: str) -> dict:
    """Видати разовий код підключення. Право діяти перевіряємо ТУТ — квиток
    про це не знає й знати не мусить."""
    acc = account(acc_id)
    if acc is None:
        raise IdentityError("Такого облікового запису немає.")
    if not acc.get("can_login"):
        raise IdentityError("Цей обліковий запис не може діяти: %s"
                            % (acc.get("broken_reason") or "вхід вимкнено"))
    return link_codes.issue(acc["id"])


def link_by_code(code, chat_id) -> dict:
    """Привʼязати чат за разовим кодом. Кличе ЛИШЕ бот — тільки він знає номер
    чату. Код одноразовий: використаний гасне в тій самій дії."""
    cid = _s(chat_id)
    if not cid:
        raise IdentityError("Немає номера чату — привʼязувати нема до чого.")
    try:
        acc_id = link_codes.take(code)
    except link_codes.CodeError as e:
        raise IdentityError(str(e))
    acc = account(acc_id)
    if acc is None or not acc.get("can_login"):
        raise IdentityError("Обліковий запис, для якого видано код, більше не діє.")
    return set_telegram(acc["id"], cid)


def unlink_telegram(acc_id: str) -> dict:
    """Відключити чат. Окрема дія, бо ввімкнути й не вміти вимкнути — те, що
    вбиває продукт."""
    if account(acc_id) is None:
        raise IdentityError("Такого облікового запису немає.")
    link_codes.drop_for(_s(acc_id))
    return set_telegram(acc_id, "")


def telegram_state(acc_id: str) -> dict:
    """Стан каналу очима екрана: підключено чи ні і чи є живий код."""
    acc = account(acc_id)
    if acc is None:
        return {"linked": False, "code": "", "expires_at": "",
                "ttl_minutes": link_codes.TTL_MIN}
    out = {"linked": bool(_s(acc.get("telegram_chat_id")))}
    out.update(link_codes.live_for(acc["id"]))
    return out


def actor_for_automation(owner_account_id: str) -> tuple:
    """ХТО ДІЄ ЗА РОЗКЛАДОМ (ворота 3). -> (актор, примітка в журнал).

    ⭐ РІШЕННЯ 06.08.2026: задача, створена ДО появи власників, не зупиняється —
    вона їде від власника з позначкою в журналі. Тихо вимкнути людині
    автоматизації посеред тендеру гірше, ніж рядок у логу."""
    oid = _s(owner_account_id)
    if oid and oid != OWNER_ID:
        acc = account(oid)
        if acc and acc.get("can_login"):
            return acc, ""
        return None, ("власник задачі («%s») більше не може діяти: запис "
                      "заблокований, зламаний або працівника звільнено" % oid)
    who = resolve_actor(None)
    if who is None:
        return None, ("задача не має власника, а в компанії вже кілька облікових "
                      "записів — невідомо, від кого її виконувати")
    note = "" if oid else "задача без власника — виконано від власника платформи"
    return who, note


def may_run_system(acc: dict, system_id: str) -> tuple:
    """Чи має ця людина право запустити цю систему.

    Повертає (можна, причина словами). Причина потрібна завжди: тиха відмова —
    це вимкнені ворота, які ніхто не помітить.
    ⚠ Ця функція НЕ здогадується. Немає актора — немає доступу."""
    sid = _s(system_id)
    if not acc:
        return False, ("невідомо, хто діє: платформа не виконує роботу від нікого — "
                       "увійдіть під своїм працівником")
    if not acc.get("can_login"):
        return False, "цей обліковий запис заблокований або працівника звільнено"
    if acc.get("is_admin"):
        return True, ""
    orch = acc.get("orchestrator") or {}
    mode = _s(orch.get("mode")) or ORCH_NONE
    if mode == ORCH_ALL:
        return True, ""
    if mode == ORCH_SYSTEMS and sid in (orch.get("systems") or []):
        return True, ""
    if mode == ORCH_SYSTEMS:
        return False, ("у вас немає доступу до системи «%s»; доступні: %s"
                       % (sid, ", ".join(orch.get("systems") or []) or "жодної"))
    return False, ("у вас немає доступу до систем платформи — поки що ви працюєте "
                   "лише в Task Desk")
