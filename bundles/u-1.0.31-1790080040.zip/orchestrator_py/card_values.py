# -*- coding: utf-8 -*-
"""card_values.py — ЗНАЧЕННЯ ОГОЛОШЕНИХ ПОЛІВ (зміна 453, 02.09.2026).

Будову карток оголошує `card_fields`; тут лежить те, що люди в ці поля ЗАНЕСЛИ.

⛒ ЧОМУ ОКРЕМО ВІД САМОЇ КАРТКИ. Структуру угоди, задачі й контрагента читає
багато коду. Дописати туди чужі поля означало б зачепити всіх читачів одразу
заради речі, яка їх не стосується. Значення живуть своїм файлом і звертаються до
сутності її СПІЛЬНИМ імʼям (`deal:d0001`) — тим самим, яким її звуть протокол і
реєстр звʼязків.

⛒ ФОРМА ЗБЕРІГАННЯ ОДНА НА ВСІ ПОЛЯ: значення — це ЗАВЖДИ список. Одиничне поле
тримає список із одного. Два різні способи зберігати одну річ (то рядок, то
список) означали б, що кожен читач мусить вгадувати, який саме випадок йому
трапився. Назовні `value()` віддає одне значення для одиничного поля і список
для множинного — вгадувати не треба нікому.

⛒ ПОРОЖНЄ НЕ ЗБЕРІГАЄТЬСЯ. Прибрати значення = стерти запис, а не покласти
порожній рядок. Тоді «поле не заповнене» скрізь виглядає однаково.

⛒ НЕДІЮЧЕ ПОЛЕ НЕ СТИРАЄ ЗАНЕСЕНОГО. Поле вивели з роботи — значення лишились;
`card()` їх не показує, але поверніть поле — і вони на місці. Стерти дані людей
через галочку в будові було б найдорожчою з можливих послуг.

⚠ НАЗВАНА МЕЖА: тут не перевіряється, чи існує сама сутність (чи є така угода).
Це знає той, хто відкрив картку, — тобто ДВЕРІ. Журнал же append-only памʼятає й
видалені сутності, тому сувора вимога «існує зараз» була б неправдою про минуле.

⛒ ФАЙЛ У ПОЛІ — ЦЕ КЛЮЧ, А НЕ ІМʼЯ (зміна 530). Тип «файл» приймає ключ файла
у сховищі (`file_store`), бо імена повторюються, а ключ один. Людське імʼя
привозить сховище — тут воно не зберігається вдруге, інакше розійшлося б із
тим, що лежить на диску. Відкріплення НЕ видаляє файл: він лишається лежати,
і глибину зберігання вирішує адміністратор.
"""
import json
import one_writer

import card_fields
import clock
import config
import entity
import file_store
import protocol

config.refuse_live_state_for_checks(__name__)

DIR = config.STATE_DIR / "state"
VALUES_JSON = DIR / "card_values.json"


class ValueError_(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


CardValueError = ValueError_


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _load() -> dict:
    try:
        d = one_writer.read_json(VALUES_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("values", {})
    return d


def _save(d: dict) -> None:
    VALUES_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(VALUES_JSON, d)


# ── ФАЙЛИ (зміна 530) ───────────────────────────────────────────────────────
# ⛒ У полі типу «файл» лежить НЕ імʼя файла, а його КЛЮЧ у сховищі. Імена
# повторюються (дві угоди легко матимуть «Специфікація.pdf»), а ключ один.
# Людське імʼя привозить сховище — тут його не зберігають удруге, інакше воно
# розійшлося б із тим, що лежить на диску.
def _file_row(fid) -> dict:
    got = file_store.info(_s(fid))
    if not got:
        return {"id": _s(fid), "name": "файл невідомий платформі",
                "present": False, "size_text": ""}
    return {"id": got["id"], "name": got.get("name") or "",
            "present": bool(got.get("present")),
            "size_text": got.get("size_text") or ""}


def _file_said(fid) -> str:
    got = file_store.info(_s(fid))
    return (got.get("name") or _s(fid)) if got else _s(fid)


# ── ПЕРЕВІРКИ ───────────────────────────────────────────────────────────────
def check_ref(ref) -> tuple:
    """Спільне імʼя сутності → (рід, номер). Картка не з переліку — відмова."""
    try:
        kind, ident = entity.parse(_s(ref))
    except Exception as ex:
        raise ValueError_("Не розібрати, чия це картка: %s" % ex)
    if kind not in card_fields.CARDS:
        raise ValueError_("Картку «%s» не можна розширювати." % entity.KIND_NAMES[kind])
    return kind, ident


def _field_for(ref, fid: str) -> dict:
    kind, _ = check_ref(ref)
    f = card_fields.get(_s(fid))
    if not f:
        raise ValueError_("Поля %s немає в будові карток." % (_s(fid) or "«»"))
    if _s(f.get("card")) != kind:
        raise ValueError_("Поле «%s» оголошене в картці «%s», а не «%s»."
                          % (_s(f.get("name")),
                             entity.KIND_NAMES[_s(f.get("card"))],
                             entity.KIND_NAMES[kind]))
    return f


def _one(f: dict, v, ctx_ref: str = "") -> str:
    """Перевірити ОДНЕ значення за типом поля. Повертає те, що ляже на диск."""
    t = _s(f.get("type"))
    nm = _s(f.get("name"))
    s = _s(v)
    if t == card_fields.T_YESNO:
        if isinstance(v, bool):
            return v
        low = s.casefold()
        if low in ("так", "yes", "1", "true"):
            return True
        if low in ("ні", "no", "0", "false"):
            return False
        raise ValueError_("Поле «%s» приймає лише «так» або «ні», а не «%s»." % (nm, s))
    if not s:
        raise ValueError_("Порожнє значення не зберігається. Щоб прибрати — "
                          "прибери поле «%s» явно." % nm)
    if t == card_fields.T_FILE:
        # ⛒ 530: приймаємо КЛЮЧ файла у сховищі, а не будь-який рядок. Тихо
        # прийняти невідомий ключ означало б показати людині поле, за яким
        # немає нічого.
        if file_store.info(s) is None:
            raise ValueError_("Поле «%s» приймає файли, а такого файла платформа "
                              "не приймала. Спершу завантажте файл, а тоді "
                              "прикріпіть його." % nm)
        return s
    if t == card_fields.T_NUMBER:
        # ⛒ Платформа НІЧОГО НЕ РАХУЄ (рішення Андрія 02.09) — тому число
        # зберігається таким, як його ввела людина. Але перевірити, що це
        # СПРАВДІ число, треба: інакше оголошений тип нічого не означає.
        probe = s.replace(" ", "").replace("\u00a0", "").replace(",", ".")
        try:
            float(probe)
        except Exception:
            raise ValueError_("Поле «%s» числове, а «%s» — не число." % (nm, s))
        return s
    if t == card_fields.T_DATE:
        # ⛒ Формат дати на диску ОДИН на всю платформу: РРРР-ММ-ДД.
        # Людині її показують як ДД.ММ.РРРР — це справа екрана, не сховища.
        p = s.split("-")
        ok = (len(p) == 3 and len(p[0]) == 4
              and all(x.isdigit() for x in p)
              and 1 <= int(p[1]) <= 12 and 1 <= int(p[2]) <= 31)
        if not ok:
            raise ValueError_("Поле «%s» — дата у вигляді РРРР-ММ-ДД, а не «%s»."
                              % (nm, s))
        return s
    if t == card_fields.T_LIST:
        # ⭐⭐⭐ 593: У ЗАЛЕЖНОГО СПИСКУ ДОЗВОЛЕНЕ ЗАЛЕЖИТЬ ВІД БАТЬКА в ЦІЙ
        # картці. Питаємо одного писаря (`allowed_for`), а не тримаємо тут
        # другого переліку: другий розійшовся б із першим на першій же правці.
        parent = _s(f.get(card_fields.F_PARENT))
        if parent:
            pv = _s(value(ctx_ref, parent)) if ctx_ref else ""
            allowed = card_fields.allowed_for(f.get("id"), pv)
            if not pv:
                raise ValueError_(
                    "Спершу виберіть «%s» — від нього залежить, що можна "
                    "вибрати в полі «%s»."
                    % (card_fields.title(parent), nm))
            if s not in allowed:
                raise ValueError_(
                    "При «%s» поле «%s» приймає лише: %s. «%s» там немає."
                    % (pv, nm, ", ".join(allowed) or "(нічого — перелік ще не "
                       "наповнено)", s))
            return s
        allowed = list(f.get("choices") or [])
        if s not in allowed:
            raise ValueError_("Поле «%s» приймає лише: %s. «%s» там немає."
                              % (nm, ", ".join(allowed), s))
        return s
    return s


def _check(f: dict, value, ctx_ref: str = "") -> list:
    """Значення → список, як воно ляже на диск. Судить множинність."""
    many = bool(f.get("many"))
    nm = _s(f.get("name"))
    if isinstance(value, (list, tuple)):
        if not many:
            raise ValueError_("Поле «%s» приймає ОДНЕ значення, а дали %d. "
                              "Щоб приймало кілька — увімкни множинність у будові."
                              % (nm, len(value)))
        out = [_one(f, v, ctx_ref) for v in value]
        seen, uniq = set(), []
        for v in out:
            key = v if isinstance(v, bool) else _s(v).casefold()
            if key in seen:
                raise ValueError_("Значення «%s» у полі «%s» двічі." % (v, nm))
            seen.add(key)
            uniq.append(v)
        if not uniq:
            raise ValueError_("Порожній перелік не зберігається. Щоб прибрати — "
                              "прибери поле «%s» явно." % nm)
        return uniq
    return [_one(f, value, ctx_ref)]


# ── ЧИТАННЯ ─────────────────────────────────────────────────────────────────
def raw(ref) -> dict:
    """Усе занесене в цю картку, ВКЛЮЧНО з полями, які вже не діють."""
    return dict(_load()["values"].get(_s(ref)) or {})


def value(ref, fid):
    """Значення поля: одне для одиничного, список для множинного, None — немає."""
    f = card_fields.get(_s(fid))
    if not f:
        return None
    got = raw(ref).get(_s(fid))
    if got is None:
        return None
    return list(got) if bool(f.get("many")) else (got[0] if got else None)


def card(ref) -> list:
    """⭐ КАРТКА ОЧИМА ЕКРАНА: діючі поля цієї картки в порядку, із значеннями.

    Поле без значення лишається в переліку, але його `value` порожній — екран
    сам вирішує, показати порожнє поле для заповнення чи сховати."""
    kind, _ = check_ref(ref)
    got = raw(ref)
    out = []
    for f in card_fields.layout(kind):
        row = dict(f)
        # ⭐ 593: екран не рахує дозволене сам — інакше консоль і телеграм
        # показали б різні переліки того самого поля.
        if _s(f.get(card_fields.F_PARENT)):
            row["choices"] = card_fields.allowed_for(
                f["id"], _s(value(ref, _s(f.get(card_fields.F_PARENT)))))
        vals = got.get(f["id"])
        row["value"] = (list(vals) if bool(f.get("many"))
                        else (vals[0] if vals else None)) if vals else None
        row["filled"] = vals is not None
        # ⛒ НАЗВУ ТИПУ ЛЮДСЬКОЮ МОВОЮ ДАЄ ПИСАР, А НЕ ЕКРАН. Словник типів,
        # зашитий у розмітці, розійшовся б із цим на першому ж новому типі.
        row["type_name"] = card_fields.TYPE_NAMES.get(_s(f.get("type")), "")
        # ⛒ 530: у полі лежить ключ, а екранові потрібне ІМʼЯ і правда про
        # те, чи файл ще на диску. Другого запиту заради цього не робимо.
        if _s(f.get("type")) == card_fields.T_FILE and vals:
            row["files"] = [_file_row(v) for v in vals]
        out.append(row)
    return out


def filled(ref) -> list:
    """Лише те, що справді заповнене (і поле діє) — для стислого показу."""
    return [x for x in card(ref) if x["filled"]]


def values_of_field(fid) -> dict:
    """⭐ 594: ЯКЕ ЗНАЧЕННЯ ЦЬОГО ПОЛЯ В КОЖНІЙ КАРТЦІ — за ОДНЕ читання.

    ⛒ Поіменне питання про кожну угоду перетворило б відкриття воронки на
    сотню читань файла. Форма відповіді: {посилання: значення або перелік}."""
    key = _s(fid)
    f = card_fields.get(key)
    many = bool((f or {}).get("many"))
    out = {}
    for ref, box in (_load()["values"] or {}).items():
        got = (box or {}).get(key)
        if got is None:
            continue
        out[_s(ref)] = list(got) if many else (got[0] if got else None)
    return out


def is_choice_used(fid, choice) -> bool:
    """Чи лежить це значення списку хоч у чиїйсь картці."""
    key, want = _s(fid), _s(choice)
    for vals in _load()["values"].values():
        for v in (vals.get(key) or []):
            if _s(v) == want:
                return True
    return False


def file_usage() -> dict:
    """⭐ 532: ДЕ ПРИКРІПЛЕНИЙ КОЖЕН ФАЙЛ. Ключ файла → перелік карток і полів.

    ⛒ Сирота — це файл, якого ТУТ НЕМАЄ. Рушій сховища про картки не знає і
    знати не мусить (його межа названа вголос у `file_store`), тому звіряє їх
    саме цей писар — той, у кого значення й лежать.

    ⛒ Рахуємо і значення НЕДІЮЧИХ полів: поле вивели з роботи, а файл під ним
    лишився прикріпленим. Назвати такий файл сиротою означало б порадити
    адміністраторові прибрати те, що комусь ще знадобиться."""
    out = {}
    for ref, box in (_load()["values"] or {}).items():
        for fid, vals in (box or {}).items():
            f = card_fields.get(_s(fid))
            if not f or _s(f.get("type")) != card_fields.T_FILE:
                continue
            for v in (vals or []):
                out.setdefault(_s(v), []).append({"ref": _s(ref),
                                                  "field": _s(f.get("name"))})
    return out


def used_by(fid) -> int:
    """У скількох картках заповнене це поле."""
    key = _s(fid)
    return sum(1 for vals in _load()["values"].values() if vals.get(key))


# ── ЗАПИС ───────────────────────────────────────────────────────────────────
@one_writer.guard("VALUES_JSON")
def set_value(ref, fid, value_in) -> dict:
    """Занести значення. Порожнє не приймається — для цього є `clear`."""
    r, key = _s(ref), _s(fid)
    f = _field_for(r, key)
    vals = _check(f, value_in, ctx_ref=r)
    d = _load()
    box = dict(d["values"].get(r) or {})
    box[key] = vals
    d["values"][r] = box
    _save(d)
    # ⛒ 530: у сліді має стояти те, що людина впізнає, — імʼя файла, а не ключ.
    if _s(f.get("type")) == card_fields.T_FILE:
        said = ", ".join(_file_said(v) for v in vals)
    else:
        said = ", ".join("так" if v is True else "ні" if v is False else _s(v)
                         for v in vals)
    try:
        protocol.write(protocol.A_CARD_FILLED, r,
                       about=[card_fields.ref(key)],
                       note="«%s» → %s" % (_s(f.get("name")), said))
    except Exception:
        pass
    # ⭐⭐⭐ 593: ЗМІНИВ БАТЬКА — ДИТИНА, ЩО БІЛЬШЕ НЕ ПІДХОДИТЬ, ПРИБИРАЄТЬСЯ.
    # ⛒ І платформа КАЖЕ, що саме прибрала. Лишити суперечливе значення лежати
    # означало б показувати в картці категорію, якої в новому напрямі немає;
    # прибрати мовчки — гірше: людина дізнається про втрату випадково.
    cleared = []
    try:
        for ch in card_fields.children_of(key):
            got = value(r, ch["id"])
            if got is None:
                continue
            ok = card_fields.allowed_for(ch["id"], _s(vals[0] if vals else ""))
            keep = [x for x in (got if isinstance(got, list) else [got])
                    if _s(x) in ok]
            if keep == (got if isinstance(got, list) else [got]):
                continue
            if keep:
                set_value(r, ch["id"], keep if bool(ch.get("many")) else keep[0])
            else:
                clear(r, ch["id"])
            cleared.append({"field": ch["id"], "name": _s(ch.get("name")),
                            "was": got})
    except Exception:
        pass
    return {"ref": r, "field": key, "value": value(r, key), "cleared": cleared}


@one_writer.guard("VALUES_JSON")
def clear(ref, fid) -> bool:
    """Прибрати значення. Прибирати те, чого немає, — відмова СЛОВАМИ."""
    r, key = _s(ref), _s(fid)
    f = _field_for(r, key)
    d = _load()
    box = dict(d["values"].get(r) or {})
    if key not in box:
        raise ValueError_("У цій картці поле «%s» і так не заповнене."
                          % _s(f.get("name")))
    del box[key]
    if box:
        d["values"][r] = box
    else:
        d["values"].pop(r, None)
    _save(d)
    try:
        protocol.write(protocol.A_CARD_CLEARED, r,
                       about=[card_fields.ref(key)],
                       note="«%s» прибрано" % _s(f.get("name")))
    except Exception:
        pass
    return True
