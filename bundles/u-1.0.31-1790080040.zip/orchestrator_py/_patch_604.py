# -*- coding: utf-8 -*-
from pathlib import Path
P = Path("artifacts.py")
raw = P.read_bytes().decode("utf-8")


def rep(old, new, tag):
    global raw
    crlf = "\r\n" in raw
    o = old.replace("\n", "\r\n") if crlf else old
    n = new.replace("\n", "\r\n") if crlf else new
    assert raw.count(o) == 1, "%s: якорів %d" % (tag, raw.count(o))
    raw = raw.replace(o, n)


# 1. одиниці зводить ОДИН писар — на виході рендер-ядра, а не в кожного читача
rep(
'''        _render_model_sheet(ws, s, regions=regions, sheet_name=names[idx])
    return wb, regions''',
'''        _render_model_sheet(ws, s, regions=regions, sheet_name=names[idx])
    # ⭐⭐⭐ 604. ОДИНИЦІ ЗВОДИТЬ ОДИН ПИСАР, І САМЕ ТУТ — на виході рендер-ядра,
    # через яке проходять і збірка файла, і перевірка `check_xlsxmodel`. Доти
    # одиницю вирішували ЛОКАЛЬНО: формат — регуляркою по заголовку, «чи вже
    # помножено» — регуляркою по тексту формули. Текст формули не може знати
    # одиниці клітинки, на яку вказує, тому «=Параметри!$B$4» з числом 9
    # показувалось як 900 %, а «=E4-I4» у п.п. давало −8,9 замість −1,55.
    try:
        import xlsx_units
        xlsx_units.normalize(wb, regions)
    except Exception as _e:
        try:
            import llm as _llm
            _llm._log("[artifacts] писар одиниць не спрацював: %s" % _e)
        except Exception:
            pass
    return wb, regions''',
"1")

# 2. ворота одиниць — у ЄДИНОМУ переліку воріт книги
rep(
'''    out.append(("series", list(series_break_errors(wb, regions) or [])))
    return out''',
'''    out.append(("series", list(series_break_errors(wb, regions) or [])))
    # ⭐ 604: змішана одиниця відсотка — така сама неправда в готовій книзі, як
    # обірваний аркуш чи мертва формула, тому вона стоїть у тому самому переліку.
    try:
        import xlsx_units
        out.append(("units", list(xlsx_units.unit_errors(wb, regions) or [])))
    except Exception:
        out.append(("units", []))
    return out''',
"2")

P.write_bytes(raw.encode("utf-8"))
print("604 внесено в artifacts.py")
