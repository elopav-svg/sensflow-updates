/* ═══════════════════════════════════════════════════════════════════════════
   SensFlow — ВІКНО «МОЗОК ПЛАТФОРМИ». Зміна 481, 04.09.2026.

   НАВІЩО ЦЕЙ ФАЙЛ ІСНУЄ.
   Слово Андрія 03.09: «я не побачив, де налаштовується мозок. Це повинно бути
   видимим для користувача». 04.09 він же спіймав мене на півмірі: кнопка
   «Змінити моделі» на домашній ВЕЛА В ЧАТ — тобто керування знову ховалось на
   іншому екрані. Вибір мозку мусить відкриватись ТАМ, ДЕ НАТИСНУЛИ.

   ⛒ І САМЕ ТОМУ ЦЕ ОКРЕМИЙ ФАЙЛ, А НЕ ДРУГА ПАНЕЛЬ НА ДОМАШНІЙ.
   Форма вибору моделей — одна на весь продукт. Дві копії розійшлись би за
   тиждень: одна знала б про Kimi, друга ні; одна вміла б Стелс, друга ні.
   Стан моделей і далі знає ОДИН писар — сервер (`/api/llm/config`); це вікно
   лише показує його і просить змінити.

   ЯК КОРИСТУВАТИСЬ ЗІ СТОРІНКИ:
       <script src="/brain_panel.js"></script>
       ... onclick="SFBrain.open()"
   Після успішної зміни вікно кидає подію `sf-brain-changed` з новим станом —
   кожен екран сам вирішує, що перемалювати. Вікно не знає про екрани нічого.
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  var SUG = { openai: [], anthropic: [], gemini: [] };
  /* Ранги моделей дає СЕРВЕР (`model_ranks`), а не таблиця імен у коді:
     інакше кожна нова модель провайдера лишалась би без підказки. */
  var RANKS = {};
  var BUILT = false;

  function T(k, v) { return (window.t ? window.t(k, v) : k); }
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function el(id) { return document.getElementById(id); }

  async function api(url, body) {
    var opt = body ? {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    } : undefined;
    var r = await fetch(url, opt);
    return await r.json();
  }

  /* ── РОЗМІТКА. Малюється один раз і живе прихованою. ───────────────────── */
  function build() {
    if (BUILT) return;
    BUILT = true;

    var css = document.createElement('style');
    css.id = 'sfBrainCss';
    /* ⛒ ЖОДНОГО КОЛЬОРУ ПОВЗ ПАЛІТРУ: усе через ролі з ui/theme.css, тому
       вікно однакове й у темній, і в світлій темі, на будь-якому екрані. */
    css.textContent = [
      '#sfBrainOv{position:fixed;inset:0;z-index:9000;background:var(--overlay);',
      '  display:none;align-items:flex-start;justify-content:center;padding:24px;overflow:auto}',
      '#sfBrainOv.on{display:flex}',
      '#sfBrainWin{width:100%;max-width:520px;background:var(--panel);border:1px solid var(--line);',
      '  border-radius:14px;box-shadow:var(--shadow-modal);color:var(--txt);',
      '  font-family:"Segoe UI",system-ui,sans-serif;margin:auto}',
      '#sfBrainWin .bh{display:flex;align-items:center;gap:10px;padding:14px 16px;',
      '  border-bottom:1px solid var(--line)}',
      '#sfBrainWin .bh h2{margin:0;font-size:15px;font-weight:700}',
      '#sfBrainWin .bx{margin-left:auto;min-width:44px;min-height:44px;border:none;background:none;',
      '  color:var(--muted);cursor:pointer;border-radius:9px;display:grid;place-items:center}',
      '#sfBrainWin .bx:hover{background:var(--panel2);color:var(--txt)}',
      '#sfBrainWin .bb{padding:14px 16px;display:flex;flex-direction:column;gap:12px}',
      '#sfBrainWin .box{padding:11px 12px;border-radius:9px;border:1px solid var(--line);',
      '  background:var(--panel2)}',
      '#sfBrainWin .row{display:flex;align-items:center;gap:9px}',
      '#sfBrainWin .row .g{flex:1;min-width:0}',
      '#sfBrainWin .ttl{font-weight:700;font-size:12.5px}',
      '#sfBrainWin .sub{font-size:11px;color:var(--muted)}',
      '#sfBrainWin .note{font-size:10.5px;color:var(--muted);margin-top:7px;line-height:1.45}',
      '#sfBrainWin label{display:flex;flex-direction:column;gap:4px;font-size:11px;color:var(--muted)}',
      '#sfBrainWin select,#sfBrainWin input{background:var(--bg);border:1px solid var(--line);',
      '  border-radius:7px;color:var(--txt);padding:9px;font-size:12.5px;font-family:inherit;min-height:40px}',
      '#sfBrainWin .role{font-size:11px;font-weight:700;color:var(--accent);letter-spacing:.3px;margin-top:2px}',
      '#sfBrainWin .btn{min-height:44px;padding:0 14px;border-radius:9px;border:1px solid var(--line);',
      '  background:var(--panel);color:var(--txt);font-size:13px;font-weight:600;cursor:pointer;',
      '  font-family:inherit;white-space:nowrap}',
      '#sfBrainWin .btn:hover{border-color:var(--accent)}',
      '#sfBrainWin .btn.main{background:var(--sh-teal-deep);color:var(--sh-on-teal);border-color:var(--sh-teal-deep)}',
      '#sfBrainWin .btn[disabled]{opacity:.6;cursor:default}',
      '#sfBrainWin .msg{font-size:11px;color:var(--muted);min-height:14px;line-height:1.4}',
      '#sfBrainWin .msg.ok{color:var(--ok)} #sfBrainWin .msg.err{color:var(--err)}',
      '@media (max-width:640px){#sfBrainOv{padding:0}#sfBrainWin{max-width:none;border-radius:0;min-height:100%}}'
    ].join('\n');
    document.head.appendChild(css);

    var ov = document.createElement('div');
    ov.id = 'sfBrainOv';
    ov.innerHTML = [
      '<div id="sfBrainWin" role="dialog" aria-modal="true">',
      '  <div class="bh"><h2 id="sfBrainTitle"></h2>',
      '    <button class="bx" id="sfBrainClose" type="button">',
      '  <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
      '</button></div>',
      '  <div class="bb">',
      '    <div class="box" id="sfStealthBox">',
      '      <div class="row"><span class="g"><span class="ttl" id="sfStealthTtl"></span>',
      '        <br><span class="sub" id="sfStealthState"></span></span>',
      '        <button class="btn" id="sfStealthBtn" type="button" data-on="0"></button></div>',
      '      <div id="sfStealthForm" style="display:none;margin-top:9px;display:none">',
      '        <label><span id="sfStealthBaseLbl"></span><input id="sfStealthBase" type="text"',
      '          placeholder="http://localhost:11434/v1"></label>',
      '        <label style="margin-top:6px"><span id="sfStealthModelLbl"></span>',
      '          <input id="sfStealthModel" type="text" placeholder="llama3.1:8b"></label>',
      '        <div class="note" id="sfStealthNote"></div>',
      '      </div>',
      '      <div class="msg" id="sfStealthMsg"></div>',
      '    </div>',
      '    <div class="box" id="sfDemoBox">',
      '      <div class="row"><span class="g"><span class="ttl" id="sfDemoTtl"></span>',
      '        <br><span class="sub" id="sfDemoState"></span></span>',
      '        <button class="btn" id="sfDemoBtn" type="button" data-on="0"></button></div>',
      '      <div class="note" id="sfDemoNote"></div>',
      '      <div class="msg" id="sfDemoMsg"></div>',
      '    </div>',
      '    <div class="role" id="sfBrainRole"></div>',
      '    <label><span id="sfBrainProvLbl"></span><select id="sfBrainProv"></select></label>',
      '    <label><span id="sfBrainModelLbl"></span><select id="sfBrainModel"></select></label>',
      '    <div class="role" id="sfWorkerRole"></div>',
      '    <label><span id="sfWorkerProvLbl"></span><select id="sfWorkerProv"></select></label>',
      '    <label><span id="sfWorkerModelLbl"></span><select id="sfWorkerModel"></select></label>',
      '    <button class="btn main" id="sfBrainApply" type="button"></button>',
      '    <div class="msg" id="sfBrainMsg"></div>',
      '    <div class="note" id="sfBrainHint"></div>',
      '  </div>',
      '</div>'
    ].join('\n');
    document.body.appendChild(ov);

    ov.addEventListener('click', function (e) { if (e.target === ov) close(); });
    el('sfBrainClose').onclick = close;
    el('sfStealthBtn').onclick = toggleStealth;
    el('sfDemoBtn').onclick = toggleDemo;
    el('sfBrainApply').onclick = apply;
    el('sfBrainProv').onchange = function () { onProv('brain'); };
    el('sfWorkerProv').onchange = function () { onProv('worker'); };
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && ov.classList.contains('on')) close();
    });
    words();
  }

  /* Написи беруться зі словника — того самого, що й уся консоль. */
  function words() {
    el('sfBrainTitle').textContent = T('home_brain');
    el('sfBrainClose').setAttribute('aria-label', T('brain_close'));
    el('sfBrainClose').title = T('brain_close');
    el('sfStealthTtl').textContent = T('stealth_title');
    el('sfStealthBaseLbl').textContent = T('stealth_local_server');
    el('sfStealthModelLbl').textContent = T('label_model');
    el('sfStealthNote').textContent = T('stealth_note');
    el('sfDemoTtl').textContent = T('demo_title');
    el('sfDemoNote').textContent = T('demo_note');
    el('sfBrainRole').textContent = T('llm_brain_role');
    el('sfWorkerRole').textContent = T('llm_worker_role');
    el('sfBrainProvLbl').textContent = T('label_provider');
    el('sfWorkerProvLbl').textContent = T('label_provider');
    el('sfBrainModelLbl').textContent = T('label_model');
    el('sfWorkerModelLbl').textContent = T('label_model');
    el('sfBrainApply').textContent = T('btn_apply');
    el('sfBrainHint').textContent = T('llm_hint');
  }

  function fillProv(id, cur) {
    var have = [['anthropic', 'Anthropic (Claude)'], ['openai', 'OpenAI'], ['gemini', 'Gemini (Google)']];
    /* Kimi зʼявляється ЛИШЕ коли сервер надіслав його моделі — так само, як у
       консолі: у клієнтських збірках цього провайдера немає. */
    if (SUG.moonshot && SUG.moonshot.length) have.push(['moonshot', 'Kimi (Moonshot)']);
    el(id).innerHTML = have.map(function (p) {
      return '<option value="' + p[0] + '"' + (p[0] === cur ? ' selected' : '') + '>' + esc(p[1]) + '</option>';
    }).join('');
    if (cur) el(id).value = cur;
  }

  /* Підказка береться за РАНГОМ, який дав сервер, а не за іменем моделі.
     0 = родини не знаємо: тоді про ціну не кажемо НІЧОГО (11.08.2026 «ранг 2
     за замовчуванням» підписав найдорожчу модель словом «дешевша»). */
  function hint(m) {
    var K = { 3: 'hint_rank3', 2: 'hint_rank2', 1: 'hint_rank1', 0: 'hint_new' };
    var r = RANKS[m];
    var k = K[(r === undefined || r === null) ? 0 : r];
    return k ? T(k) : '';
  }

  function fillModels(id, arr, cur) {
    arr = (arr || []).slice();
    if (cur && arr.indexOf(cur) === -1) arr.unshift(cur);
    el(id).innerHTML = arr.map(function (m) {
      return '<option value="' + esc(m) + '"' + (m === cur ? ' selected' : '') + '>'
        + esc(m) + esc(hint(m) || '') + '</option>';
    }).join('');
    if (cur) el(id).value = cur;
  }

  function onProv(role) {
    var p = el(role === 'brain' ? 'sfBrainProv' : 'sfWorkerProv').value;
    var list = SUG[p] || [];
    fillModels(role === 'brain' ? 'sfBrainModel' : 'sfWorkerModel', list, list[0] || '');
  }

  function stealthState(c) {
    var on = !!(c && c.stealth);
    var btn = el('sfStealthBtn');
    btn.setAttribute('data-on', on ? '1' : '0');
    btn.textContent = on ? T('btn_disable') : T('btn_enable');
    el('sfStealthState').textContent = on ? T('stealth_active') : T('stealth_off_state');
    el('sfStealthBox').style.borderColor = on ? 'var(--mint2)' : 'var(--line)';
    if (c && c.local_base) el('sfStealthBase').value = c.local_base;
    if (on && c && c.brain_model) el('sfStealthModel').value = c.brain_model;
    if (on) el('sfStealthForm').style.display = 'none';
  }

  function demoState(on, c) {
    var btn = el('sfDemoBtn');
    btn.setAttribute('data-on', on ? '1' : '0');
    btn.textContent = on ? T('btn_disable') : T('btn_enable');
    el('sfDemoState').textContent = on
      ? (T('state_on') + ' · ' + ((c && c.brain_model) || '')) : T('state_off');
  }

  async function toggleStealth() {
    var btn = el('sfStealthBtn'), msg = el('sfStealthMsg'), form = el('sfStealthForm');
    var on = btn.getAttribute('data-on') === '1';
    msg.className = 'msg';
    try {
      if (!on) {
        var base = (el('sfStealthBase').value || '').trim();
        var model = (el('sfStealthModel').value || '').trim();
        if (form.style.display === 'none' && !base && !model) {
          form.style.display = 'block';
          msg.textContent = T('stealth_specify');
          return;
        }
        btn.disabled = true;
        msg.textContent = T('stealth_enabling');
        var body = { on: true };
        if (base) body.base_url = base;
        if (model) body.model = model;
        var c = await api('/api/llm/stealth', body);
        stealthState(c);
        if (c.stealth) {
          var warn = (c.ping && !c.ping.ok) ? T('stealth_no_resp', { msg: c.ping.message }) : '';
          msg.className = 'msg ' + ((c.ping && c.ping.ok) ? 'ok' : 'err');
          msg.textContent = T('stealth_on_ok', { model: (c.brain_model || '') }) + warn;
        } else {
          msg.className = 'msg err';
          msg.textContent = T('stealth_need_addr');
          form.style.display = 'block';
        }
        changed(c);
      } else {
        btn.disabled = true;
        msg.textContent = T('checking');
        var c2 = await api('/api/llm/stealth', { on: false });
        stealthState(c2);
        msg.className = 'msg ok';
        msg.textContent = '';
        changed(c2);
      }
    } catch (e) {
      msg.className = 'msg err';
      msg.textContent = T('error_prefix') + e;
    }
    btn.disabled = false;
  }

  async function toggleDemo() {
    var btn = el('sfDemoBtn'), msg = el('sfDemoMsg');
    var on = btn.getAttribute('data-on') !== '1';
    btn.disabled = true;
    msg.className = 'msg';
    msg.textContent = on ? T('demo_enabling') : T('demo_returning');
    try {
      var c = await api('/api/llm/demo', { on: on });
      if (c.error) {
        msg.className = 'msg err';
        msg.textContent = (c.message || T('demo_no_cloud'));
      } else {
        demoState(!!c.demo, c);
        msg.className = 'msg ok';
        msg.textContent = c.demo
          ? (T('demo_prefix') + (c.brain_model || '') + ' / ' + (c.worker_model || ''))
          : T('demo_restored');
        changed(c);
      }
    } catch (e) {
      msg.className = 'msg err';
      msg.textContent = T('error_prefix') + e;
    }
    btn.disabled = false;
  }

  async function apply() {
    var msg = el('sfBrainMsg'), btn = el('sfBrainApply');
    btn.disabled = true;
    msg.className = 'msg';
    msg.textContent = T('llm_applying');
    try {
      var c = await api('/api/llm/config', {
        brain: el('sfBrainModel').value.trim(),
        worker: el('sfWorkerModel').value.trim()
      });
      if (!c.ready) {
        msg.className = 'msg err';
        msg.textContent = T('llm_no_key');
      } else {
        var mix = c.brain_provider !== c.worker_provider ? T('llm_mixed') : '';
        var ws = c.web_search ? '' : T('llm_web_off');
        msg.className = 'msg ok';
        msg.textContent = T('llm_brain_label') + ' ' + c.brain_provider + '/' + c.brain_model
          + ' · ' + T('llm_worker_label') + ' ' + c.worker_provider + '/' + c.worker_model + mix + ws;
        if (c.brain_advisory) {
          msg.className = 'msg err';
          msg.textContent = c.brain_advisory;
        }
        changed(c);
        setTimeout(close, 1400);
      }
    } catch (e) {
      msg.className = 'msg err';
      msg.textContent = T('error_prefix') + e;
    }
    btn.disabled = false;
  }

  /* Вікно не знає про екрани нічого: воно лише каже «стан змінився».
     Хто що перемальовує — вирішує сам екран. */
  function changed(c) {
    try { window.dispatchEvent(new CustomEvent('sf-brain-changed', { detail: c })); } catch (e) {}
  }

  async function open() {
    build();
    words();
    el('sfBrainOv').classList.add('on');
    var msg = el('sfBrainMsg');
    msg.className = 'msg';
    msg.textContent = T('checking');
    try {
      var c = await api('/api/llm/config');
      SUG = c.suggestions || SUG;
      RANKS = c.model_ranks || RANKS;
      var bp = c.brain_provider || 'anthropic', wp = c.worker_provider || 'anthropic';
      fillProv('sfBrainProv', bp);
      fillProv('sfWorkerProv', wp);
      fillModels('sfBrainModel', SUG[bp] || [], c.brain_model || '');
      fillModels('sfWorkerModel', SUG[wp] || [], c.worker_model || '');
      stealthState(c);
      demoState(!!c.demo, c);
      msg.textContent = '';
    } catch (e) {
      msg.className = 'msg err';
      msg.textContent = T('error_prefix') + e;
    }
  }

  function close() {
    var ov = el('sfBrainOv');
    if (ov) ov.classList.remove('on');
  }

  window.SFBrain = { open: open, close: close };
})();
