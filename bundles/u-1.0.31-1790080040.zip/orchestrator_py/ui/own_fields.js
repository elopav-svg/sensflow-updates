/* ui/own_fields.js -- СПІЛЬНИЙ МАЛЯР ВЛАСНИХ ПОЛІВ КОМПАНІЇ.
   Зміна 527, 06.09.2026.

   ЧОМУ ВІН ОДИН. Зміна 526 дала власним полям місце в картці угоди й
   контрагента, але малюнок був зшитий із CRM і в чужому екрані жити не вмів.
   Другий такий самий малюнок на екрані задачі розійшовся б із першим на
   першій же правці. Тому малюнок тут один на всі екрани платформи.

   ⛒ МАЛЯР НІЧОГО НЕ ВИРІШУЄ САМ. Перелік полів, їхній порядок, тип, підказку
   й назву типу людською мовою привозить сервер. Маляр лише малює введення під
   тип, несе слова відмови туди, де людина натиснула, і стукає в ті самі
   універсальні двері /api/cards/value_set і /api/cards/value_clear, які
   однаково приймають угоду, контрагента, задачу й товар.

   ⛒ ОДЯГ ПРИНОСИТЬ ГОСПОДАР. CRM і Task Desk одягнені по-різному, тому класи
   кнопок і стиль поля введення передає той, хто монтує. Малюнок один,
   одяг -- місцевий.

   ⛒ ПРАВО ЗАПОВНЮВАТИ ЗБІГАЄТЬСЯ З ПРАВОМ ПРАВИТИ. Хто правити не може, той
   бачить занесене словами -- без полів введення й без кнопок, які нікуди не
   ведуть. */
var OwnFields = (function(){
  var ST = null;

  function esc(s){
    return (s==null?'':String(s)).replace(/[&<>"]/g, function(m){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[m]; });
  }
  function jsq(s){
    return String(s==null?'':s).replace(/\\/g,'\\\\').replace(/'/g,"\\'");
  }

  /* Господар екрана каже, ЧИЮ картку малюємо, чим її одягти й що зробити
     після збереження. Більше маляр нічого не питає. */
  function mount(o){
    ST = {
      ref:   o.ref || '',
      rows:  o.rows || [],
      can:   (o.can !== false),
      inp:   o.inp || '',
      btn:   o.btn || '',
      accent: o.accent || o.btn || '',
      wrap:  o.wrap || '',
      head:  o.head || 'h4',
      slot:  o.slot || '',
      msgId: o.msgId || 'ownFieldsMsg',
      after: o.after || null
    };
    return ST;
  }
  function rows(){ return ST ? ST.rows : []; }
  function field(fid){
    var r = rows();
    for(var i=0;i<r.length;i++) if(r[i].id===fid) return r[i];
    return null;
  }
  function say(t, bad){
    if(!ST) return;
    var m = document.getElementById(ST.msgId);
    if(!m) return;
    m.textContent = t || '';
    m.style.color = bad ? 'var(--bad)' : 'var(--muted)';
  }

  /* Що людина ввела -- у тій формі, яку чекають двері. */
  function readValue(f){
    if(f.type==='list' && f.many){
      var out=[], boxes=document.querySelectorAll('[data-own="'+f.id+'"]');
      for(var i=0;i<boxes.length;i++) if(boxes[i].checked) out.push(boxes[i].value);
      return out;
    }
    var el = document.getElementById('own_'+f.id);
    if(!el) return null;
    if(f.type==='yesno' && !f.many) return el.value===''?'':(el.value==='yes');
    if(f.many) return el.value.split('\n').map(function(s){ return s.trim(); })
                              .filter(function(s){ return s!==''; });
    return el.value;
  }

  /* Показ занесеного тому, хто цю картку правити не може. */
  function shownValue(f){
    var v = f.value;
    if(v===null || v===undefined || v==='' || (Array.isArray(v) && !v.length))
      return '<span style="opacity:.7">не заповнено</span>';
    /* ⛒ 531: хто правити не може — бачить імена й може ЗАБРАТИ файл (право
       бачити картку = право бачити прикріплене), але кнопок не бачить. */
    if(f.type==='file'){
      var gg = f.files || [];
      if(!gg.length) return '<span style="opacity:.7">не заповнено</span>';
      var out = [];
      for(var q=0;q<gg.length;q++){
        out.push(gg[q].present
          ? ('<a href="/api/files/get?id='+esc(gg[q].id)+'">'+esc(gg[q].name)+'</a>')
          : (esc(gg[q].name)+' <span style="color:var(--bad);font-size:11px">'
             +'немає у сховищі</span>'));
      }
      return out.join(', ');
    }
    if(f.type==='yesno' && !f.many) return (v===true) ? 'так' : 'ні';
    if(Array.isArray(v)) return esc(v.join(', '));
    return esc(v);
  }

  function inputHtml(f){
    var v = f.value, id = 'own_'+esc(f.id);
    var st = ST.inp ? (' style="'+ST.inp+'"') : '';
    var sst = ST.inp ? (' style="'+ST.inp+';cursor:pointer"') : '';
    /* ⭐⭐⭐ 531: ФАЙЛ У ПОЛІ. Маляр не вигадує свого шляху: кладе файл у ті
       самі двері /api/files/upload, а прикріплює тим самим value_set, що й
       будь-яке інше поле. Ключ файла людині не показуємо — вона мислить
       іменем. */
    if(f.type==='file'){
      var got = f.files || [], hh = '';
      if(got.length){
        hh += '<div style="display:flex;flex-direction:column;gap:5px;margin-bottom:6px">';
        for(var k=0;k<got.length;k++){
          var g = got[k];
          hh += '<div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:12.5px">'
             + (g.present
                ? ('<a href="/api/files/get?id='+esc(g.id)+'" style="font-weight:600">'
                   +esc(g.name)+'</a><span style="font-size:11px;color:var(--muted)">'
                   +esc(g.size_text||'')+'</span>')
                : ('<span style="font-weight:600">'+esc(g.name)+'</span>'
                   +'<span style="font-size:11px;color:var(--bad)">немає у сховищі — '
                   +'файл прибрали з теки поза платформою</span>'))
             + '<button type="button" class="'+ST.btn+'" style="flex:none;font-size:11px" '
             + 'onclick="OwnFields.detach(\''+jsq(f.id)+'\',\''+jsq(g.id)+'\')">Відкріпити</button>'
             + '</div>';
        }
        hh += '</div>';
      }
      hh += '<input type="file" id="ownfile_'+esc(f.id)+'" style="display:none"'
          + (f.many?' multiple':'')
          + ' onchange="OwnFields.upload(\''+jsq(f.id)+'\')">'
          + '<button type="button" class="'+ST.accent+'" style="flex:none" '
          + 'onclick="OwnFields.pick(\''+jsq(f.id)+'\')">'
          + ((got.length && !f.many) ? 'Замінити файл' : 'Додати файл')+'</button>'
          + '<div style="font-size:11px;color:var(--muted);margin-top:5px">'
          + 'До 100 МБ на файл. Файли лежать на цій машині. Відкріплення не '
          + 'видаляє файл зі сховища.</div>';
      return hh;
    }
    if(f.type==='list' && f.many){
      var ch=f.choices||[], got=v||[], h='<div style="display:flex;flex-wrap:wrap;gap:10px">';
      for(var i=0;i<ch.length;i++){
        h+='<label style="font-size:12.5px;display:flex;align-items:center;gap:5px;cursor:pointer">'
          +'<input type="checkbox" data-own="'+esc(f.id)+'" value="'+esc(ch[i])+'"'
          +(got.indexOf(ch[i])>=0?' checked':'')+'> '+esc(ch[i])+'</label>';
      }
      return h+'</div>';
    }
    if(f.type==='list'){
      var o='<option value="">-- не вибрано --</option>', cc=f.choices||[];
      for(var j=0;j<cc.length;j++){
        o+='<option value="'+esc(cc[j])+'"'+(cc[j]===v?' selected':'')+'>'+esc(cc[j])+'</option>';
      }
      return '<select id="'+id+'"'+sst+'>'+o+'</select>';
    }
    if(f.type==='yesno' && !f.many){
      return '<select id="'+id+'"'+sst+'>'
        +'<option value="">-- не вибрано --</option>'
        +'<option value="yes"'+(v===true?' selected':'')+'>так</option>'
        +'<option value="no"'+(v===false?' selected':'')+'>ні</option></select>';
    }
    if(f.many){
      return '<textarea id="'+id+'"'+st+' rows="3" '
        +'placeholder="по одному значенню в рядок">'+esc((v||[]).join('\n'))+'</textarea>';
    }
    if(f.type==='date'){
      return '<input id="'+id+'" type="date" value="'+esc(v||'')+'"'+st+'>';
    }
    return '<input id="'+id+'" value="'+esc(v==null?'':v)+'"'+st+' '
      +'placeholder="'+(f.type==='number'?'число':'')+'">';
  }

  function html(){
    var r = rows();
    /* ⛒ ПОЛІВ НЕМАЄ -- БЛОКУ НЕМАЄ: кнопка в нікуди гірша за її відсутність. */
    if(!r.length) return '';
    var H = ST.head;
    var h = (ST.wrap ? ('<div class="'+ST.wrap+'" style="margin-top:0">') : '<div>')
      +'<'+H+'>Власні поля</'+H+'>'
      +'<div style="font-size:11.5px;color:var(--muted);line-height:1.5;margin-bottom:8px">'
      +'Ці поля завела ваша компанія у «Будові карток». Заповнює їх той, хто веде '
      +'цей запис; змінювати саму будову має право лише адміністратор системи.</div>';
    for(var i=0;i<r.length;i++){
      var f = r[i];
      h+='<div style="border:1px solid var(--line);border-radius:8px;padding:9px 10px;margin-bottom:8px">'
        +'<div style="display:flex;align-items:baseline;gap:7px;flex-wrap:wrap;margin-bottom:5px">'
        +'<span style="font-size:12.5px;font-weight:600">'+esc(f.name)+'</span>'
        +'<span style="font-size:11px;color:var(--muted)">'+esc(f.type_name||f.type)
        +(f.many?' · множинне':'')+'</span></div>'
        +(f.hint?('<div style="font-size:11.5px;color:var(--muted);margin-bottom:5px">'+esc(f.hint)+'</div>'):'');
      if(!ST.can){
        h+='<div style="font-size:12.5px">'+shownValue(f)+'</div>';
      }else{
        h+=inputHtml(f);
        if(f.type!=='file'){
          h+='<div style="display:flex;gap:8px;margin-top:6px">'
            +'<button type="button" class="'+ST.accent+'" style="flex:none" '
            +'onclick="OwnFields.set(\''+jsq(f.id)+'\')">Зберегти</button>'
            +(f.filled?('<button type="button" class="'+ST.btn+'" style="flex:none" '
              +'onclick="OwnFields.clear(\''+jsq(f.id)+'\')">Прибрати</button>'):'')
            +'</div>';
        }
      }
      h+='</div>';
    }
    return h+'<div id="'+esc(ST.msgId)+'" style="font-size:12px;color:var(--muted);'
      +'min-height:16px"></div></div>';
  }

  async function post(door, body, okMsg){
    try{
      var r = await fetch('/api/cards/'+door, {method:'POST',
        headers:{'Content-Type':'application/json'}, body:JSON.stringify(body)});
      var d = await r.json();
      if(!r.ok || d.error){ say(d.error || 'Не вдалося зберегти', true); return null; }
      /* Свіжий перелік привозять самі двері -- другого читання не робимо. */
      ST.rows = d.fields || [];
      if(ST.slot){
        var s = document.getElementById(ST.slot);
        if(s) s.innerHTML = html();
      }
      if(ST.after) await ST.after(ST.rows);
      say(okMsg);
      return d;
    }catch(e){ say('Не вдалося зберегти: '+(e.message||e), true); return null; }
  }

  /* ⭐ 531: файл кладеться ОДРАЗУ, а не по кнопці «Зберегти»: людина обрала
     файл — вона вже вирішила. Спершу файл їде у сховище, і лише потім його
     КЛЮЧ прикріплюється до поля тим самим value_set. */
  function pick(fid){
    var el = document.getElementById('ownfile_'+fid);
    if(el) el.click();
  }

  async function upload(fid){
    var f = field(fid);
    if(!f){ say('Поля вже немає в будові карток -- оновіть сторінку.', true); return; }
    var el = document.getElementById('ownfile_'+fid);
    var list = el ? el.files : null;
    if(!list || !list.length) return;
    var ids = [];
    for(var i=0;i<list.length;i++){
      var fl = list[i];
      say('Кладу «'+fl.name+'» у сховище...');
      try{
        var r = await fetch('/api/files/upload', {method:'POST',
          headers:{'Content-Type':'application/octet-stream',
                   'X-File-Name':encodeURIComponent(fl.name)}, body: fl});
        var d = await r.json();
        if(!r.ok || d.error){
          say(d.error || 'Файл не збережено', true);
          if(el) el.value = '';
          return;
        }
        ids.push(d.file.id);
      }catch(e){
        say('Файл не збережено: '+(e.message||e), true);
        if(el) el.value = '';
        return;
      }
    }
    if(el) el.value = '';
    var val;
    if(f.many){ val = (f.value||[]).slice().concat(ids); }
    else { val = ids[ids.length-1]; }
    await post('value_set', {ref:ST.ref, field:fid, value:val},
               (ids.length>1 ? 'Файли прикріплено' : 'Файл прикріплено')
               +' до поля «'+f.name+'»');
  }

  /* ⛒ ВІДКРІПИТИ -- НЕ ВИДАЛИТИ. Файл лишається у сховищі; глибину зберігання
     вирішує адміністратор, і саме це людині й кажемо. */
  async function detach(fid, fileId){
    var f = field(fid);
    if(!f){ say('Поля вже немає в будові карток -- оновіть сторінку.', true); return; }
    var left = [];
    if(f.many){
      var have = f.value || [];
      for(var i=0;i<have.length;i++) if(have[i]!==fileId) left.push(have[i]);
    }
    var slova = 'Файл відкріплено -- сам файл лишився у сховищі';
    if(f.many && left.length){
      await post('value_set', {ref:ST.ref, field:fid, value:left}, slova);
    }else{
      await post('value_clear', {ref:ST.ref, field:fid}, slova);
    }
  }

  async function set(fid){
    var f = field(fid);
    if(!f){ say('Поля вже немає в будові карток -- оновіть сторінку.', true); return; }
    var v = readValue(f);
    var empty = (v===null) || (v==='') || (Array.isArray(v) && !v.length);
    if(empty){
      say('Поле «'+f.name+'» порожнє. Щоб прибрати вже занесене, є кнопка «Прибрати».', true);
      return;
    }
    await post('value_set', {ref:ST.ref, field:fid, value:v},
               'Поле «'+f.name+'» збережено');
  }

  async function clear(fid){
    var f = field(fid);
    if(!f){ say('Поля вже немає в будові карток -- оновіть сторінку.', true); return; }
    await post('value_clear', {ref:ST.ref, field:fid},
               'Поле «'+f.name+'» прибрано');
  }

  return {mount:mount, html:html, set:set, clear:clear, say:say,
          pick:pick, upload:upload, detach:detach,
          readValue:readValue, field:field, rows:rows, esc:esc, jsq:jsq};
})();
