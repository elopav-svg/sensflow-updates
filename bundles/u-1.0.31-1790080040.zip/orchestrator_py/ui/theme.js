/* ═══════════════════════════════════════════════════════════════════════════
   SensFlow — ПЕРЕМИКАЧ ТЕМИ. Зміна 184, 15.08.2026.

   ЧОМУ ЦЕ ОКРЕМИЙ ФАЙЛ, А НЕ ПʼЯТЬ ОДНАКОВИХ ШМАТКІВ У ПʼЯТЬОХ СТОРІНКАХ:
   вибір теми — одна правда на людину, а не на екран. Якщо кожна сторінка
   памʼятає свій вибір, людина відкриє ключі API й отримає темне вікно посеред
   світлої роботи. Тому і сховище одне (`localStorage`), і код один.

   ⚠ ЦЕЙ ФАЙЛ ПІДКЛЮЧАЄТЬСЯ В <head>, ДО ТІЛА СТОРІНКИ. Інакше сторінка встигне
   намалюватись темною і аж тоді побіліти — спалах в очі на кожному відкритті.
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';
  var KEY = 'sf_theme';          // 'light' | 'dark'
  var DEF = 'dark';              // за замовчуванням лишається темна

  function read() {
    try { var v = window.localStorage.getItem(KEY); return (v === 'light' || v === 'dark') ? v : DEF; }
    catch (e) { return DEF; }    // приватний режим / заборонене сховище — не падаємо
  }
  function apply(v) { document.documentElement.setAttribute('data-theme', v); }
  function save(v) { try { window.localStorage.setItem(KEY, v); } catch (e) {} }

  apply(read());                 // ⭐ до першого пікселя, не після

  function label(cur) { return cur === 'light' ? 'Темна тема' : 'Світла тема'; }

  function paint(el, cur) {
    // Підпис каже, ЩО СТАНЕТЬСЯ від натискання, а не як зараз: кнопка, яка
    // називає поточний стан, змушує гадати, що вона зробить.
    el.textContent = label(cur);
    el.setAttribute('aria-label', label(cur));
    el.setAttribute('title', label(cur));
  }

  function toggle() {
    var next = read() === 'light' ? 'dark' : 'light';
    apply(next); save(next);
    var el = document.getElementById('sfThemeSwitch');
    if (el) paint(el, next);
    try { window.dispatchEvent(new CustomEvent('sf-theme', { detail: next })); } catch (e) {}
    return next;
  }

  function mount() {
    var el = document.getElementById('sfThemeSwitch');
    if (!el) {
      // Сторінка не приготувала місця. Розмір 44px не випадковий: менше — не
      // влучиш пальцем на планшеті.
      el = document.createElement('button');
      el.id = 'sfThemeSwitch';
      el.type = 'button';
      var look = 'min-height:44px;padding:11px 14px;border-radius:10px;cursor:pointer;' +
        'font:inherit;font-size:12.5px;background:var(--panel2);' +
        'border:1px solid var(--line);color:var(--txt)';
      /* 🩸 ЗНАЙДЕНО ОКОМ 28.08.2026 НА ЖИВОМУ ЕКРАНІ: плаваюча кнопка в правому
         ВЕРХНЬОМУ куті лягала ПОВЕРХ шапки Task Desk і накривала «До консолі» —
         вихід із розділу просто не натискався. Так було на ВСІХ восьми екранах.
         ⛒ ЗАПАСНИЙ ВАРІАНТ НЕ СМІЄ НІЧОГО НАКРИВАТИ: якщо в екрана є шапка —
         кнопка стає В НЕЇ, у ряд із рештою. Вішаємо на `header`, а не в `nav`:
         деякі екрани перемальовують `nav.innerHTML` і змели б кнопку. */
      var head = document.querySelector('header');
      if (head) {
        el.style.cssText = look + ';margin-left:8px';
        head.appendChild(el);
      } else {
        /* Шапки немає — плаваємо, але в НИЖНЬОМУ куті: верхній зайнятий скрізь. */
        el.style.cssText = 'position:fixed;bottom:12px;right:12px;z-index:99999;' + look;
        document.body.appendChild(el);
      }
    }
    paint(el, read());
    el.addEventListener('click', function (ev) { ev.preventDefault(); toggle(); });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mount);
  } else { mount(); }

  window.sfTheme = { get: read, set: function (v) { apply(v); save(v); }, toggle: toggle };
})();
