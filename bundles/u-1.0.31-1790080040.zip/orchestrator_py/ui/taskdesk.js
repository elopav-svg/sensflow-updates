// taskdesk.js — спільні помічники екранів Task Desk.
// Один писар звертань до сервера: кожен екран питає однаково, і помилка
// показується людині словами, а не мовчки зникає в консолі браузера.
/* ⭐⭐⭐ 525: ВІДПОВІДЬ МУСИТЬ ДОЇХАТИ ДО ОКА.
   Корінь 06.09.2026: людина заповнила форму ВНИЗУ сторінки й натиснула
   «Додати». Сторінка чесно намалювала відповідь — у смузі ВГОРІ, за межами
   того, що видно. Виглядало, ніби кнопка мертва.
   Тому: коли місце для відповіді зараз не в полі зору, та сама відповідь
   показується приліпленою смугою. А коли сервер каже «увійдіть» — у смузі
   стоїть КНОПКА входу: там потрібна не звістка, а шлях. */
function tdFloat(text, withLogin){
  if(!text) return;
  var id = 'td-float-say';
  var box = document.getElementById(id);
  if(!box){
    box = document.createElement('div');
    box.id = id;
    box.setAttribute('role', 'alert');
    box.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:9999;'
      + 'display:flex;gap:12px;align-items:center;justify-content:center;'
      + 'flex-wrap:wrap;padding:12px 16px;font-size:14px;line-height:1.4;'
      + 'background:var(--panel,#1b1f2a);color:var(--txt,#e8ecf4);'
      + 'border-bottom:1px solid var(--line,#2a3040);'
      + 'box-shadow:0 6px 20px rgba(0,0,0,.35)';
    document.body.appendChild(box);
  }
  box.innerHTML = '';
  var t = document.createElement('span');
  t.textContent = text;
  box.appendChild(t);
  if(withLogin){
    var a = document.createElement('a');
    a.href = '/login';
    a.textContent = 'Увійти';
    a.style.cssText = 'background:var(--accent,#3aa0ff);color:var(--on-accent,#08111f);'
      + 'border-radius:7px;padding:6px 14px;font-weight:600;text-decoration:none';
    box.appendChild(a);
  }
  var x = document.createElement('button');
  x.type = 'button';
  x.textContent = 'Закрити';
  x.style.cssText = 'background:transparent;color:var(--muted,#9aa4b8);'
    + 'border:1px solid var(--line,#2a3040);border-radius:7px;padding:6px 12px;cursor:pointer';
  x.onclick = function(){ box.remove(); };
  box.appendChild(x);
}

/* Чи видно зараз місце, куди екран пише відповідь. Не видно — відповідь піде
   ще й приліпленою смугою. */
function tdInView(el){
  if(!el || !el.getBoundingClientRect) return false;
  if(el.offsetParent === null) return false;
  var r = el.getBoundingClientRect();
  var h = window.innerHeight || document.documentElement.clientHeight;
  return r.top < h && r.bottom > 0;
}

async function tdApi(path, data){
  const opt = data === undefined
    ? {method:'GET'}
    : {method:'POST', headers:{'Content-Type':'application/json'},
       body: JSON.stringify(data)};
  const r = await fetch(path, opt);
  let body = {};
  try { body = await r.json(); } catch(e) { body = {}; }
  if(!r.ok){
    const msg = body.message || body.error || ('Помилка ' + r.status);
    // ⭐ 24.08.2026. Код відмови мусить доїхати до екрана: «ще не налаштовано»
    // лікується інакше, ніж «немає прав», і сторінка має право це розрізняти.
    const err = new Error(msg);
    err.code = body.error || '';
    err.status = r.status;
    /* ⭐ 525: «УВІЙДІТЬ» — ЦЕ НЕ ЗВИЧАЙНА ПОМИЛКА СТОРІНКИ, А СТАН ЛЮДИНИ.
       Вона могла відкрити екран тоді, коли вхід ще не вимагався (другий
       обліковий запис зʼявився пізніше). Мовчазна відмова тут читається як
       «кнопка не працює», тому смуга зі шляхом на вхід — обовʼязкова. */
    if(err.code === 'login_required'){ tdFloat(msg, true); }
    throw err;
  }
  return body;
}
function tdEsc(s){
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}
function tdSay(id, text, ok){
  const el = document.getElementById(id);
  if(!el) return;
  el.textContent = text || '';
  el.className = ok ? 'td-ok' : 'td-err';
  /* ⭐ 525: якщо місце для відповіді зараз не видно — та сама відповідь іде
     приліпленою смугою. Інакше екран «мовчить» рівно тоді, коли людина
     щойно щось натиснула внизу довгої сторінки. */
  if(text && !tdInView(el)){ tdFloat(text, false); }
}
// Дата людині — DD.MM.YYYY (у файлі вона машинна, YYYY-MM-DD).
function tdDate(iso){
  const s = String(iso || '');
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? (m[3] + '.' + m[2] + '.' + m[1]) : '';
}
// Дата ВІД людини — ДД.ММ.РРРР — назад у машинну YYYY-MM-DD. Порожньо, якщо
// набране не є справжньою датою: мовчазна підстановка «схожого» дня зробила б
// відбір брехливим. Це друга половина того самого правила, що й tdDate.
function tdIsoFromHuman(s){
  const m = String(s || '').trim().match(/^(\d{1,2})[.\-/](\d{1,2})[.\-/](\d{4})$/);
  if(!m){ return ''; }
  const d = Number(m[1]), mo = Number(m[2]), y = Number(m[3]);
  const dt = new Date(Date.UTC(y, mo - 1, d));
  if(dt.getUTCFullYear() !== y || dt.getUTCMonth() !== mo - 1 || dt.getUTCDate() !== d){
    return '';                       // 31.02 — це не дата, а помилка набору
  }
  return m[3] + '-' + ('0' + mo).slice(-2) + '-' + ('0' + d).slice(-2);
}
function tdWhen(iso){
  const s = String(iso || '');
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}:\d{2})/);
  return m ? (m[3] + '.' + m[2] + '.' + m[1] + ' ' + m[4]) : '';
}

// ── НАБІРНИЙ ВИБІР ЛЮДИНИ — ОДИН ПИСАР НА ВЕСЬ TASK DESK ───────────────────
// Чому свій, а не <input list=…>: випадайку <datalist> малює БРАУЗЕР, а не ми.
// Її не можна ні оформити, ні показати «скільки варіантів лишилось», ні
// перевірити чеком, що вона взагалі відкрилась. Екран, якого не бачить ні
// людина, ні ворота, — це не наш екран.
var TD_PICK_MAX = 12;                 // скільки варіантів показуємо за раз

function tdFold(s){                   // одна нормалізація на всіх
  return String(s === null || s === undefined ? '' : s).toLowerCase().replace(/\s+/g, ' ').trim();
}

// Звуження — ЄДИНЕ місце, де вирішується «що підходить під набране».
// Головне правило: збіг із ПОЧАТКОМ слова. Людина набирає перші літери
// прізвища, і саме їх чекає побачити.
// Збіг усередині слова — ДРУГА ЛІНІЯ, і лише коли за початком не знайшлось
// НІКОГО. Інакше «Ко» тягнуло б за собою всіх «-енків» (Петриченко,
// Сидоренко, Ткаченко…), і набір літер майже не звужував би список —
// а це рівно те, заради чого він існує.
function tdPickMatch(people, query){
  const q = tdFold(query);
  if(!q) return people.slice();
  const head = [], inside = [];
  people.forEach(function(p){
    const label = tdFold(p.label);
    if(label.split(' ').some(function(w){ return w.indexOf(q) === 0; })) head.push(p);
    else if(label.indexOf(q) >= 0) inside.push(p);
  });
  return head.length ? head : inside;
}

function tdPicker(box, opts){
  opts = opts || {};
  const many = opts.mode === 'many';
  const uid = box.id || ('pick-' + Math.random().toString(36).slice(2));
  const self = {mode: opts.mode || 'one', people: [], one: '', list: [],
                exclude: function(){ return []; }, onChange: null};

  box.classList.add('td-pick');
  box.innerHTML =
    '<input class="td-pick-in" type="text" autocomplete="off" role="combobox"' +
    ' aria-autocomplete="list" aria-expanded="false" aria-controls="' + uid + '-list"' +
    ' placeholder="' + tdEsc(opts.placeholder || 'почніть набирати прізвище') + '">' +
    '<div class="td-pick-drop" id="' + uid + '-list" role="listbox" hidden></div>' +
    (many ? '<div class="td-picked"></div>' : '');
  const inp = box.querySelector('.td-pick-in');
  const drop = box.querySelector('.td-pick-drop');
  const chips = box.querySelector('.td-picked');
  if(opts.labelledBy) inp.setAttribute('aria-labelledby', opts.labelledBy);
  let open = false, active = -1, shown = [];

  function labels(){                  // однофамільці отримують номер — ТУТ, один раз
    const seen = {};
    self.people.forEach(function(p){ seen[p.name] = (seen[p.name] || 0) + 1; });
    return self.people.map(function(p){
      return {id: p.id, name: p.name,
              label: seen[p.name] > 1 ? (p.name + ' (' + p.id + ')') : p.name};
    });
  }
  function nameOf(id){
    const f = labels().filter(function(p){ return p.id === id; })[0];
    return f ? f.label : id;
  }
  function taken(){
    const out = (self.exclude() || []).slice();
    if(many) self.list.forEach(function(id){ out.push(id); });
    return out;
  }
  function candidates(){
    const off = taken();
    return tdPickMatch(labels().filter(function(p){ return off.indexOf(p.id) < 0; }), inp.value);
  }
  function drawChips(){
    if(!chips) return;
    chips.innerHTML = self.list.map(function(id){
      return '<span class="p">' + tdEsc(nameOf(id)) +
        '<button type="button" title="прибрати" data-drop="' + tdEsc(id) + '">×</button></span>';
    }).join('');
  }
  function close(){
    open = false; active = -1; drop.hidden = true;
    inp.setAttribute('aria-expanded', 'false');
    inp.removeAttribute('aria-activedescendant');
  }
  function draw(){
    const all = candidates();
    shown = all.slice(0, TD_PICK_MAX);
    if(!shown.length){
      // Зупинка мусить називати СВОЮ причину: «нікого не знайшов» і «усіх уже
      // додано» — це різні речі, і людина мусить бачити, яка з них сталася.
      const nobodyLeft = !inp.value.trim() && taken().length;
      drop.innerHTML = '<div class="td-pick-note">' +
        (nobodyLeft ? 'усіх, кого можна, вже додано'
                    : ('нікого не знайшов' +
                       (inp.value ? ' на «' + tdEsc(inp.value) + '»' : ''))) + '</div>';
    } else {
      drop.innerHTML = shown.map(function(p, i){
        return '<div class="td-pick-opt" role="option" id="' + uid + '-o' + i +
          '" data-id="' + tdEsc(p.id) + '"' + (i === active ? ' aria-selected="true"' : '') +
          '>' + tdEsc(p.label) + '</div>';
      }).join('') +
      (all.length > shown.length
        ? '<div class="td-pick-note">показано ' + shown.length + ' з ' + all.length +
          ' — наберіть ще літеру</div>'
        : '<div class="td-pick-note">варіантів: ' + all.length + '</div>');
    }
    drop.hidden = false; open = true;
    inp.setAttribute('aria-expanded', 'true');
    if(active >= 0) inp.setAttribute('aria-activedescendant', uid + '-o' + active);
    else inp.removeAttribute('aria-activedescendant');
  }
  function choose(id){
    if(!id) return;
    if(many){
      if(self.list.indexOf(id) < 0) self.list.push(id);
      inp.value = ''; drawChips(); draw();
    } else {
      self.one = id; inp.value = nameOf(id); close();
    }
    if(self.onChange) self.onChange();
  }

  inp.addEventListener('focus', function(){ active = -1; draw(); });
  inp.addEventListener('input', function(){
    if(!many) self.one = '';
    active = -1; draw();
    if(self.onChange) self.onChange();
  });
  inp.addEventListener('keydown', function(e){
    if(e.key === 'ArrowDown' || e.key === 'ArrowUp'){
      e.preventDefault();
      if(!open){ draw(); return; }
      if(!shown.length) return;
      active = e.key === 'ArrowDown'
        ? (active + 1 >= shown.length ? 0 : active + 1)
        : (active - 1 < 0 ? shown.length - 1 : active - 1);
      draw();
      return;
    }
    if(e.key === 'Enter'){
      e.preventDefault();
      if(shown.length) choose(shown[active >= 0 ? active : 0].id);
      return;
    }
    if(e.key === 'Escape'){ close(); return; }
    if(e.key === 'Tab'){ close(); }
  });
  drop.addEventListener('mousedown', function(e){
    const o = e.target.closest('.td-pick-opt');
    if(!o) return;
    e.preventDefault();
    choose(o.dataset.id);
  });
  if(chips) chips.addEventListener('click', function(e){
    const b = e.target.closest('button[data-drop]');
    if(!b) return;
    const i = self.list.indexOf(b.dataset.drop);
    if(i >= 0) self.list.splice(i, 1);
    drawChips();
    if(self.onChange) self.onChange();
  });
  document.addEventListener('mousedown', function(e){ if(!box.contains(e.target)) close(); });

  self.setPeople = function(list){
    self.people = (list || []).slice();
    if(!many && self.one) inp.value = nameOf(self.one);
    drawChips();
    return self;
  };
  self.setExclude = function(fn){ self.exclude = fn || function(){ return []; }; return self; };
  self.get = function(){ return many ? self.list.slice() : self.one; };
  self.set = function(v){
    if(many){ self.list = (v || []).slice(); drawChips(); }
    else { self.one = v || ''; inp.value = v ? nameOf(v) : ''; }
    return self;
  };
  self.clear = function(){ return self.set(many ? [] : ''); };
  // Текст, якого людина набрала, але нікого не вибрала — щоб сказати про це словами.
  self.stray = function(){ return (!many && !self.one && inp.value.trim()) ? inp.value.trim() : ''; };
  self.input = inp;
  return self;
}
