/* ═══════════════════════════════════════════════════════════════════════════
   SensFlow — ВИХІД ДОДОМУ НА КОЖНОМУ ЕКРАНІ. Зміна 500, 04.09.2026.

   🩸 ЩО ЗНАЙШОВ АНДРІЙ 04.09, пройшовши платформу очима:
   «З СРМу немає кнопки виходу на домашню сторінку… З Задач вихід позначений як
   "До консолі"… Кнопки повернення на домашню немає [на майстрі налаштування]…
   Немає кнопки повернення в екрані налаштування Телеграм».

   Тобто оболонка була рівно на двох екранах із шістнадцяти. Лікувати це
   шістнадцятьма правками не можна: сімнадцятий екран знову зʼявиться без
   виходу. Тому вихід ставить ОДИН файл, який підключають усі сторінки.

   ЩО ВІН РОБИТЬ:
     · знаходить шапку сторінки (`header`), а якщо її немає — робить смугу;
     · ставить у неї ПЕРШИМ знак SensFlow із написом «На домашню» (адреса «/»);
     · якщо на сторінці вже є посилання на «/» (підписане «консоль» чи
       «До консолі» — вчорашня правда, коли коренем був чат), ПЕРЕРОБЛЯЄ його
       на той самий знак, а не додає другий;
     · нічого не робить там, де вихід уже стоїть як слід (домашня, консоль).

   ⛒ Кольору тут немає — лише ролі з ui/theme.css (сторож палітри стежить).
   ═══════════════════════════════════════════════════════════════════════════ */
(function () {
  'use strict';

  var MARK = '<svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" role="img"'
    + ' aria-label="SensFlow"><defs><linearGradient id="sfshell" gradientUnits="userSpaceOnUse"'
    + ' x1="13" y1="88" x2="86" y2="20"><stop offset="0" style="stop-color:var(--logo-1)"/>'
    + '<stop offset="0.16" style="stop-color:var(--logo-2)"/>'
    + '<stop offset="0.40" style="stop-color:var(--logo-3)"/>'
    + '<stop offset="0.60" style="stop-color:var(--logo-3)"/>'
    + '<stop offset="0.84" style="stop-color:var(--logo-2)"/>'
    + '<stop offset="1" style="stop-color:var(--logo-1)"/></linearGradient></defs>'
    + '<path fill="url(#sfshell)" d="M 60.07 52.9 L 31.01 31.98 L 40.01 24.47 L 69.19 24.47'
    + ' L 69.19 8 L 89.24 18.03 L 69.19 28.05 L 69.19 11.58 L 35.35 11.58 L 9.98 32.72'
    + ' L 52.53 63.36 Z"/><path fill="url(#sfshell)" d="M 42.41 37.51 L 71.28 59.16'
    + ' L 68.85 61.99 L 24.15 66.32 L 10.98 84.42 L 21.41 92 L 31.16 78.59 L 75.26 74.32'
    + ' L 90.02 57.1 L 50.14 27.19 Z"/></svg>';

  function T(k, d) {
    try { return (window.t ? window.t(k) : d) || d; } catch (e) { return d; }
  }

  function css() {
    if (document.getElementById('sfHomeCss')) return;
    var s = document.createElement('style');
    s.id = 'sfHomeCss';
    s.textContent = [
      '.sf-home{display:inline-flex;align-items:center;gap:8px;min-height:44px;padding:0 10px;',
      '  border-radius:9px;color:var(--txt);text-decoration:none;font-size:13.5px;font-weight:600}',
      '.sf-home:hover{background:var(--panel2)}',
      '.sf-home .sf-mk{width:22px;height:22px;flex:none;display:block}',
      '.sf-home .sf-mk svg{width:100%;height:100%;display:block}',
      '.sf-strip{position:fixed;top:0;left:0;right:0;z-index:9500;display:flex;',
      '  align-items:center;gap:10px;padding:6px 14px;border-bottom:1px solid var(--line);',
      '  background:var(--panel)}',
      '.sf-strip .sf-right{margin-left:auto;display:flex;align-items:center;gap:8px}',
      '.sf-login{display:inline-flex;align-items:center;gap:8px;min-height:36px;padding:0 14px;',
      '  border-radius:9px;text-decoration:none;font-size:13.5px;font-weight:600;',
      '  background:var(--accent);color:var(--on-accent-ink);border:0}',
      '.sf-login:hover{filter:brightness(1.08)}',
      '.sf-login-note{font-size:12.5px;color:var(--faint)}',
      '.sf-who{display:inline-flex;align-items:center;gap:8px;font-size:13px;color:var(--faint)}',
      '.sf-who b{color:var(--txt);font-weight:600}',
      '.sf-out{display:inline-flex;align-items:center;min-height:32px;padding:0 12px;',
      '  border-radius:8px;text-decoration:none;font-size:13px;font-weight:600;',
      '  color:var(--txt);border:1px solid var(--line);background:transparent;cursor:pointer}',
      '.sf-out:hover{background:var(--panel2)}'
    ].join('\n');
    document.head.appendChild(s);
  }

  function make() {
    var a = document.createElement('a');
    a.className = 'sf-home';
    a.href = '/';
    a.title = T('home_go', 'На домашню');
    a.innerHTML = '<span class="sf-mk">' + MARK + '</span><span class="sf-home-txt">'
      + T('home_go', 'На домашню') + '</span>';
    return a;
  }

  function already(scope) {
    /* Вихід уже стоїть як слід — нічого не чіпаємо (домашня, консоль). */
    return !!scope.querySelector('.sf-home, .home[href="/"], .homelink[href="/"], .sh-home');
  }

  function reuse(old) {
    /* Було посилання на «/» під старим іменем («консоль», «До консолі»):
       коли коренем був чат, це була правда. Тепер корінь — домашня, тому
       той самий вхід ПЕРЕРОБЛЯЄМО, а не лишаємо поруч із новим. */
    var a = make();
    old.parentNode.replaceChild(a, old);
    return a;
  }

  function mount() {
    css();
    var head = document.querySelector('header');
    if (head && already(head)) return;

    var old = null;
    var links = document.querySelectorAll('a[href="/"], a[href="/index.html"]');
    for (var i = 0; i < links.length; i++) {
      if (!links[i].closest('.sf-home')) { old = links[i]; break; }
    }

    if (head) {
      if (old && head.contains(old)) { reuse(old); return; }
      if (old) old.parentNode.removeChild(old);
      head.insertBefore(make(), head.firstChild);
      return;
    }

    /* Шапки немає (майстер налаштування, Telegram, генератор ключів): робимо
       смугу ЗГОРИ. Саме через її відсутність кнопка теми там плавала над
       вмістом і накривала кнопку внизу — тепер їй теж є куди стати.
       🩸 502: старе посилання лежало в ПІДВАЛІ сторінки, і переробка його
       «на місці» ховала вихід за межі екрана. Вихід іде вгору завжди, а
       підвальне посилання прибираємо, щоб не було двох. */
    if (old) old.parentNode.removeChild(old);
    var strip = document.createElement('header');
    strip.className = 'sf-strip';
    strip.appendChild(make());
    var right = document.createElement('div');
    right.className = 'sf-right';
    strip.appendChild(right);
    document.body.insertBefore(strip, document.body.firstChild);
    /* Смуга прибита до верху — тілу треба відступ, інакше вона накриє початок
       сторінки (та сама вада, що й у плаваючої кнопки теми). */
    var pad = function () {
      try {
        document.body.style.paddingTop = strip.getBoundingClientRect().height + 'px';
      } catch (e) {}
    };
    pad();
    window.addEventListener('resize', pad);
    /* І забираємо в смугу те, що інакше плаває над вмістом. Порядок
       завантаження файлів більше не має значення: хто б не встиг першим,
       кнопка опиниться тут. */
    var grab = function () {
      ['sfThemeSwitch', 'langSelect'].forEach(function (id) {
        var el = document.getElementById(id);
        if (!el || right.contains(el)) return;
        var box = (el.id === 'langSelect' && el.parentNode
                   && el.parentNode.children.length === 1) ? el.parentNode : el;
        try { box.style.position = 'static'; box.style.bottom = ''; box.style.right = ''; }
        catch (e) {}
        right.appendChild(box);
      });
      pad();
    };
    grab();
    setTimeout(grab, 120);
    setTimeout(grab, 600);
  }

  /* ── 513: «УВІЙТИ» ТАМ, ДЕ ЛЮДИНУ НЕ ВПІЗНАЛИ ──────────────────────────
     Екран входу існує і працює. Але екран, до якого немає шляху, — це екран,
     якого немає: 05.09.2026 власник платформи відкрив домашню, побачив, що
     розділ його налаштувань зник, і не знайшов жодної кнопки «Увійти».
     Смуга — один файл на весь продукт, тому вхід стає на КОЖНОМУ екрані. ── */
  function loginLink() {
    if (/^\/login(\/|$)/.test(location.pathname)) return;   // на вході входу не треба
    if (document.querySelector('.sf-login')) return;
    var req = null;
    try { req = fetch('/api/taskdesk/whoami', {credentials: 'same-origin'}); }
    catch (e) { return; }
    req.then(function (r) { return r.ok ? r.json() : null; }).then(function (w) {
      if (!w || !w.enabled) return;
      /* Показуємо ТІЛЬКИ коли вхід справді вимагається і платформа нікого не
         впізнала. Якщо `me` є — людина працює, і кнопка була б шумом. */
      /* 514: ЛЮДИНА ВЖЕ УВІЙШЛА — показуємо, ХТО працює, і даємо вийти.
         Без цього передати машину колезі не можна було нічим: двері
         `/api/taskdesk/logout` існували, а кнопки до них не було ніде. */
      if (w.me && w.login_required) { whoBar(w); return; }
      if (!w.login_required || w.me) return;
      var strip = document.querySelector('.sf-strip .sf-right');
      var host = strip || document.querySelector('header');
      if (!host) return;
      var note = document.createElement('span');
      note.className = 'sf-login-note';
      note.textContent = T('shell_login_hint', 'платформа не знає, хто ви');
      var a = document.createElement('a');
      a.className = 'sf-login';
      a.href = '/login';
      a.textContent = T('shell_login', 'Увійти');
      if (strip) { host.appendChild(note); host.appendChild(a); }
      else {
        var box = document.createElement('span');
        box.style.cssText = 'margin-left:auto;display:inline-flex;'
          + 'align-items:center;gap:10px';
        box.appendChild(note);
        box.appendChild(a);
        host.appendChild(box);
      }
    })["catch"](function () {});
  }

  /* 514: «хто працює» і вихід. Стоїть поруч зі входом, бо це одна відповідь
     на одне питання — у якому стані зараз людина перед екраном. */
  function whoBar(w) {
    var strip = document.querySelector('.sf-strip .sf-right');
    var host = strip || document.querySelector('header');
    if (!host || document.querySelector('.sf-who')) return;

    var who = document.createElement('span');
    who.className = 'sf-who';
    var nm = document.createElement('b');
    nm.textContent = (w.me && w.me.name) || '';
    who.appendChild(nm);

    var out = document.createElement('button');
    out.type = 'button';
    out.className = 'sf-out';
    out.textContent = T('shell_logout', 'Вийти');
    out.title = T('shell_logout_title', 'Вийти й дати увійти іншому');
    out.onclick = function () {
      out.disabled = true;
      fetch('/api/taskdesk/logout', {method: 'POST', credentials: 'same-origin'})
        .then(function () { location.href = '/login'; })
        ["catch"](function () { out.disabled = false; });
    };

    if (strip) { host.appendChild(who); host.appendChild(out); }
    else {
      var box = document.createElement('span');
      box.style.cssText = 'margin-left:auto;display:inline-flex;'
        + 'align-items:center;gap:10px';
      box.appendChild(who);
      box.appendChild(out);
      host.appendChild(box);
    }
  }

  function boot() {
    mount();
    loginLink();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
