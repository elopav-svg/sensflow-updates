# -*- coding: utf-8 -*-
"""connector_owner.py — ЧИЙ ЦЕ КОНЕКТОР (зміна 617, 20.09.2026).

⭐⭐⭐ КОРІНЬ. Шлях токена не мав виміру «чий»:

    config.CONNECTORS_DIR / ("%s.token.json" % connector_id)

Конектор був властивістю ПЛАТФОРМИ. У компанії з пʼятьма менеджерами це
означає одну скриньку на всіх: менеджер А читає листи менеджера Б, а
платформа діє в акаунті власника руками будь-кого. Це не незручність, а
витік.

🩸 КЛАС: **РЕСУРС БЕЗ ВЛАСНИКА.** Платформа вже лікувала його двічі —
`entity_scope` («чий це клієнт») і права на задачі. Тут він лишився в
найдорожчому місці: не в тому, ЩО видно, а в тому, ВІД ЧИЙОГО ІМЕНІ
платформа виходить у чужий сервіс.

⛒ РІВЕНЬ ОГОЛОШУЄТЬСЯ, А НЕ ВИЗНАЧАЄТЬСЯ ТИМ, ХТО ПЕРШИЙ НАТИСНУВ.
Частина конекторів за природою особисті (скринька, календар людини),
частина — компанійські (спільний Drive, репозиторій, робочий чат). Мовчазне
«чий» тут і є та сама вигадка замість даних.

⛒ ОСОБИСТИМ НЕ СМІЄ БУТИ КОНЕКТОР БЕЗ ДВЕРЕЙ. Якщо платформа не вміє взяти
згоду від імені людини (немає рядка в `connector_oauth.DOORS`), то оголосити
такий конектор особистим означає пообіцяти кнопку, якої немає, — і залишити
людину без робочого інструмента назавжди. Це судить проба, а не звичай.

⛒ «НЕ ЗНАЮ, ХТО ДІЄ» — ЦЕ ВІДМОВА, А НЕ СПІЛЬНА СКРИНЬКА. Доки платформою
користується один господар (Каспер до появи других входів), безіменна дія
законна і йде старим спільним шляхом — його робота не змінюється ні на байт.
Щойно входів стало двоє, безіменна дія більше нічого не відмикає: інакше
поломка імені тихо повертала б рівно той витік, від якого ми лікувались.

⛒ ХТО ДІЄ — ПИТАЄМО ОДНОГО ПИСАРЯ. Імʼя вже їде в контексті роботи
(`protocol.bind(actor=...)`, зміни 171 і 542), і кладуть його ВСІ чотири
канали: консоль, розклад, телеграм, задачі. Другого писаря тієї самої правди
ми не заводимо — два рано чи пізно розійдуться.

Жодних зовнішніх залежностей.
"""

LEVEL_PERSONAL = "personal"
LEVEL_COMPANY = "company"

# ⛒ ОДНЕ МІСЦЕ, ДЕ НАЗВАНО РІВЕНЬ КОЖНОГО ПРИВАТНОГО КОНЕКТОРА.
# Новий конектор = новий рядок ТУТ; проба не пустить конектор без рівня.
LEVELS = {
    "google_mail": LEVEL_PERSONAL,       # скринька людини
    "google_calendar": LEVEL_PERSONAL,   # календар людини
    "google_drive": LEVEL_COMPANY,       # спільне сховище компанії
    "github": LEVEL_COMPANY,             # репозиторій компанії
    "slack": LEVEL_COMPANY,              # робочий чат компанії
    "telegram": LEVEL_COMPANY,           # канал компанії (особисте звʼязування
                                         # людини з ботом живе в її обліковці)
}

LEVEL_NAMES = {
    LEVEL_PERSONAL: "особистий конектор працівника",
    LEVEL_COMPANY: "спільний конектор компанії",
}


def _s(v) -> str:
    return "" if v is None else str(v).strip()


# ─────────────────────────────── РІВЕНЬ ───────────────────────────────────
def level(connector_id: str) -> str:
    """ОСОБИСТИЙ чи КОМПАНІЙСЬКИЙ. Невідомий конектор — особистий (найвужче):
    мовчання не сміє зробити чужу скриньку спільною."""
    lvl = LEVELS.get(_s(connector_id))
    return lvl if lvl in (LEVEL_PERSONAL, LEVEL_COMPANY) else LEVEL_PERSONAL


def personal(connector_id: str) -> bool:
    return level(connector_id) == LEVEL_PERSONAL


def level_name(connector_id: str) -> str:
    return LEVEL_NAMES.get(level(connector_id), LEVEL_NAMES[LEVEL_PERSONAL])


# ───────────────────────────── ХТО ДІЄ ЗАРАЗ ──────────────────────────────
def acting() -> str:
    """Номер ПРАЦІВНИКА, від чийого імені платформа діє в цю мить. "" = імені
    немає (господар машини, кухня, службовий хід).

    ⛒ Джерело одне — контекст роботи, який кладе сервер і решта каналів.
    Там лежить посилання на людину; воно вказує на працівника тоді й лише
    тоді, коли за дією стоїть працівник, а не неявний власник машини
    (`taskdesk_identity.OWNER_ID`) чи обліковий запис без працівника."""
    try:
        import protocol
        ref = _s(protocol.context().get("actor"))
    except Exception:
        return ""
    if not ref:
        return ""
    try:
        import entity
        if entity.kind_of(ref) != entity.KIND_PERSON:
            return ""
        ident = _s(entity.ident_of(ref))
    except Exception:
        return ""
    if not ident:
        return ""
    try:
        import taskdesk_identity as tdid
        if ident == tdid.OWNER_ID:
            return ""                    # неявний власник одноосібної збірки
        if tdid.account(ident):
            return ""                    # обліковий запис без працівника
    except Exception:
        pass
    return ident


def multi_user() -> bool:
    """ЧИ ПЛАТФОРМА ВЗАГАЛІ РОЗРІЗНЯЄ ЛЮДЕЙ. Поломка = «так» (найсуворіше).

    ⛒ ПИТАЄМО НЕ КІЛЬКІСТЬ ЗАПИСІВ, А ТОГО САМОГО ВІДПОВІДАЧА «ХТО ДІЄ».
    Порахувати рядки в `accounts.json` означало б завести другого писаря тієї
    самої правди — і він розійшовся б з першим рівно там, де боляче: у збірці
    з вимкненим Task Desk записи лежать, а платформа одноосібна, і кожна дія
    в ній законно безіменна. Відповідь одна: платформа розрізняє людей тоді й
    лише тоді, коли БЕЗ СЕСІЇ вона відмовляється діяти взагалі."""
    try:
        import taskdesk_identity as tdid
        return tdid.resolve_actor(None) is None
    except Exception:
        return True


def name_of(emp_id: str) -> str:
    """Людське імʼя працівника — щоб відмова називала, кого саме бракує."""
    emp = _s(emp_id)
    if not emp:
        return ""
    try:
        import taskdesk_people as people
        return _s((people.employee(emp) or {}).get("full_name"))
    except Exception:
        return ""


# ──────────────────────────── ОДИН СУДДЯ «ЧИЙ» ────────────────────────────
def conn_name(connector_id: str) -> str:
    """Людська назва конектора — щоб відмова називала ВХІД, а не номер."""
    cid = _s(connector_id)
    try:
        import registry
        for c in registry.PRIVATE_CONNECTORS:
            if _s(c.get("id")) == cid:
                return _s(c.get("name")) or cid
    except Exception:
        pass
    return cid


def no_actor_why(connector_id: str = "") -> str:
    return ("Невідомо, від чийого імені діяти: конектор «%s» належить людині, а "
            "не платформі. Увійдіть своїм працівником і підключіть його собі."
            % conn_name(connector_id))


NO_ACTOR_WHY = no_actor_why("")


def owner_of(connector_id: str):
    """ЄДИНА ВІДПОВІДЬ «ЧИЙ ЦЕ ТОКЕН». → (власник, чесна відмова).

    Порожня відмова означає, що питання вирішене; порожній власник при
    порожній відмові — це СПІЛЬНИЙ файл (компанійський конектор або
    одноосібна збірка), тобто той самий шлях, що був до зміни 617."""
    if not personal(connector_id):
        return "", ""
    emp = acting()
    if emp:
        return emp, ""
    if not multi_user():
        return "", ""
    return "", no_actor_why(connector_id)


def absent_why(connector_id: str, owner: str = None) -> str:
    """ЧОМУ КОНЕКТОРА НЕМАЄ — словами і з іменем, а не «не підключено»."""
    what = conn_name(connector_id)
    if not personal(connector_id):
        return "Конектор «%s» не підключено." % what
    who = _s(owner) if owner is not None else acting()
    if not who:
        return "Конектор «%s» не підключено." % what
    nm = name_of(who)
    return ("У вас%s не підключено конектор «%s». Натисніть «Підключити» на його "
            "картці: згоду ви даєте у своєму акаунті, і чужих скриньок платформа "
            "не бачить." % ((" («%s»)" % nm) if nm else "", what))
