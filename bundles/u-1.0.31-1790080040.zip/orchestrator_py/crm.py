"""
crm.py — local-first CRM / сервіс-центр SensFlow (Фаза 3 дизайну
DESIGN_Оновлення_та_Сервіс-центр.md).

ПРИЗНАЧЕННЯ: тримає картки клієнтів — джерело правди для публікації оновлень
(per-client секрет, ліцензія, версія, застосовані оновлення, історія взаємодії).

БЕЗПЕКА — критично:
  • Файл `crm/clients.json` містить СЕКРЕТИ всіх клієнтів і живе ЛИШЕ в адмінській
    збірці. Він НІКОЛИ не входить у клієнтські пакети: лежить у корені платформи
    (поза orchestrator_py), тож make_client_build його не копіює.
  • Майстер-секрет (LICENSE_SIGNING_SECRET адміна) у клієнтські збірки більше не
    потрапляє — кожен клієнт має власний секрет, згенерований тут.

Лише stdlib. Запис атомарний (через .tmp + replace).
"""

import json
import one_writer
import re
import hashlib
import secrets as _secrets
from datetime import datetime, timedelta, date
from pathlib import Path

import config
import parties          # ДОВІДНИК КОНТРАГЕНТІВ — один писар тотожності
import entity           # спільне імʼя сутності на всю платформу
import protocol         # ЗАГАЛЬНИЙ журнал усіх дій (хребет, 13.08.2026)


def _to_protocol(customer: str, action: str, note: str = "",
                 outcome: str = protocol.OUT_OK, source: str = "") -> None:
    """ТОЧКА ВРІЗКИ №3 — КЛІЄНТИ (хребет, 13.08.2026).

    ⭐ У протокол їде НОМЕР КОНТРАГЕНТА, а не імʼя картки. Саме заради цього
    заводився довідник у зміні 167: назва змінюється (ФОП став ТОВ), номер — ні,
    а журнал append-only переписати назад неможливо. Картка без номера контрагента
    (ще не пройшла `ensure_parties()`) у протокол не потрапляє — краще прогалина,
    ніж запис, привʼязаний до рядка назви.

    ⚠ Ніколи не кидає: історія клієнта вже на диску, і журнал не має права
    завалити роботу продавця."""
    try:
        ref = entity.party_of_card(customer)
        if not ref:
            return
        # Контрагент став відомим — гроші цього прогону тепер знайдуть, до кого
        # їх прикласти (звʼязок живе в протоколі, а не копіюється в картку).
        protocol.bind(party=ref)
        protocol.write(action, ref, outcome=outcome, note=note, source=source)
    except Exception:
        pass

# Сховище живе в корені платформи, поза рушієм. ⛒ 417: САМЕ ПО СОБІ це
# нічого не гарантувало — суддя складу вважав теку придатною до відправки
# клієнту. Боронить її ОГОЛОШЕННЯ живим станом у `state_files`, а не адреса.
# ⛒ 418: адресу більше не обчислюємо тут — питаємо єдиного власника.
CRM_DIR = config.CRM_DIR
CLIENTS_JSON = CRM_DIR / "clients.json"

# ── Воронка (канбан) ─────────────────────────────────────────────────────────
# ⭐⭐⭐ КРОК C1 (15.08.2026): ПРОДАЖ ПЕРЕЇХАВ В УГОДУ. Стадія, суми, наступна дія
# й бейдж уваги більше НЕ живуть у картці клієнта — вони належать сутності
# `deal:d0001` (`deals.py`). Тут лишились ТІ САМІ ІМЕНА, але це ПОСИЛАННЯ на
# один перелік: два переліки стадій розійшлись би на першій же правці.
# ⛒ Картка клієнта лишається карткою ЛІЦЕНЗІЇ Й КАНАЛУ ОНОВЛЕНЬ (рішення Р3).
import deals

STAGES = deals.STAGES
DEFAULT_STAGE = deals.DEFAULT_STAGE
STAGE_ARCHIVE = deals.STAGE_ARCHIVE
STAGE_ACTIVE = deals.STAGE_ACTIVE
STAGE_PILOT = deals.STAGE_PILOT
STAGE_PROB = deals.STAGE_PROB
EXPIRY_SOON_DAYS = 7  # за скільки днів до кінця ліцензії бити на сполох


def _num(s) -> float:
    """Число з рядка суми. ⭐ ОДИН ПИСАР АРИФМЕТИКИ — `deals.num` (крок C1):
    дашборд і воронка не сміють рахувати гроші двома різними способами."""
    return deals.num(s)


def _is_overdue(date_str: str) -> bool:
    """True, якщо дата (YYYY-MM-DD) у минулому відносно сьогодні."""
    try:
        return bool(date_str) and date.fromisoformat(str(date_str)[:10]) < date.today()
    except Exception:
        return False


def _expiry_soon(expiry: str) -> bool:
    """True, якщо термін (YYYY-MM-DD) спливає протягом EXPIRY_SOON_DAYS або вже минув."""
    try:
        if not expiry:
            return False
        return date.fromisoformat(str(expiry)[:10]) <= (date.today() + timedelta(days=EXPIRY_SOON_DAYS))
    except Exception:
        return False


def _due_reason(c: dict) -> str:
    """Чому КАРТКА КЛІЄНТА потребує уваги (порожньо = не потребує).

    ⭐ КРОК C1: протермінована дія переїхала в угоду (`deals.due_reason`), бо це
    продажний факт. Тут лишився рівно один привід — ЛІЦЕНЗІЯ СПЛИВАЄ. Це техніка,
    і вона мусить бути видною навіть тоді, коли живої угоди немає взагалі."""
    if c.get("license_key") and _expiry_soon(c.get("expiry")):
        return "Ліцензія спливає: " + str(c.get("expiry") or "")
    return ""


def cust_hash(name: str) -> str:
    """Хеш імені клієнта (16 hex) — той самий, що в URL маніфесту publish_update.py."""
    return hashlib.sha256((name or "anon").encode("utf-8")).hexdigest()[:16]


def new_secret() -> str:
    """Випадковий per-client секрет підпису (URL-safe, ~256 біт)."""
    return _secrets.token_urlsafe(32)


# ⭐⭐⭐ 05.08.2026. ДВА ПИСАРІ ЧАСУ В ОДНІЙ КАРТЦІ.
# Записи в CRM робить не лише сервер на машині власника: частина подій лягає з
# інших процесів, чий системний годинник стоїть на UTC. Через це в історії
# клієнта запис «о 15:18» опинявся ПІСЛЯ запису «о 18:08», і журнал, який ми
# самі й ведемо, ставав нечитабельним. Причина не в тому, ХТО пише, а в тому,
# що час брався з годинника машини. Тепер джерело одне: київський час,
# порахований явно, незалежно від того, де виконується код.
# ⭐ 06.08.2026. Сам розрахунок переїхав у `clock.py` — ОДИН ПИСАР ЧАСУ на весь
# продукт (Task Desk заводить свої журнали і мусить брати час звідти ж, інакше
# писарів знову стане двоє). Тут лишається звичне імʼя, яким користується решта
# CRM, і стала для запасного шляху.
import clock

_KYIV_OFFSET_HOURS = clock.KYIV_OFFSET_HOURS


def _now() -> str:
    """Час подій CRM — завжди київський, з якої б машини не прийшов запис."""
    return clock.now()


def _norm(customer: str) -> str:
    return (customer or "").strip()


# ── Низькорівневе сховище ────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(CLIENTS_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("clients", {})
    return d


def _save(d: dict) -> None:
    CRM_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(CLIENTS_JSON, d)


def _blank_card(customer: str) -> dict:
    return {
        "customer": customer,
        # ⭐ Номер контрагента в довіднику (`parties.py`). Картка — це УГОДА і
        # ЛІЦЕНЗІЯ; хто цей контрагент насправді — знає довідник. Порожньо буває
        # лише у карток, які ще не пройшли `ensure_parties()`.
        "party_id": "",
        # Латинське (ASCII) імʼя для терміналу/збирача й чистих імен файлів.
        # Порожнє = використовуємо повне імʼя (стара поведінка).
        "name_en": "",
        "secret": new_secret(),
        "license_key": "",
        "edition": "",
        "expiry": "",
        "role": "admin",
        "version": "",
        "applied": [],
        "notes": "",
        # ⛔ ПРОФІЛЮ, ОСІБ, ДОСЬЄ, КАНАЛІВ І ІСТОРІЇ ТУТ НЕМАЄ (крок B1): це
        # базовий шар, він живе на КОНТАКТІ (`parties.py`).
        # ⛔ СТАДІЇ, СУМ, НАСТУПНОЇ ДІЇ, БЕЙДЖА УВАГИ Й АРХІВУ ТУТ ТЕЖ БІЛЬШЕ
        # НЕМАЄ (крок C1, 15.08.2026): це ПРОДАЖ, він живе в УГОДІ (`deals.py`).
        # Картка — це ЛІЦЕНЗІЯ, КАНАЛ ОНОВЛЕНЬ і НАБІР СИСТЕМ клієнта.
        "created": _now(),
        "updated": _now(),
    }


# Поля профілю організації (для UI-форми). ⭐ Перелік живе в ДОВІДНИКУ — тут лише
# те саме імʼя, щоб старі читачі `crm.PROFILE_FIELDS` не зламались (крок B1).
PROFILE_FIELDS = list(parties.PROFILE_FIELDS)


# ── БАЗОВИЙ ШАР ПІД КАРТКОЮ (крок B1, 14.08.2026) ────────────────────────────
# ⭐⭐⭐ Картка-угода більше не зберігає нічого про саму людину. Профіль, особи,
# досьє, канали й історія спілкування лежать на КОНТАКТІ. Тут — лише перехід
# «імʼя картки → номер контакта» і тонкі виклики до нього.
def _pid_for(customer: str) -> str:
    """Номер контакта під карткою. Немає — заводимо: картка вже існує, отже
    рішення людини завести цього контрагента вже прийняте (див. `_ensure_party_for`)."""
    pid = party_of(customer)
    if pid:
        return pid
    try:
        return _ensure_party_for(customer, source="картка", strict=False) or ""
    except Exception:
        return ""


def _hist(customer: str, kind: str, note: str = "", action: str = "") -> None:
    """Тонкий виклик до ЄДИНОГО писаря історії — прецедент `agent._refusal_log`.

    ⚠ Помилку НЕ ковтаємо. Протокол — тінь роботи, і його аварія не має права
    завалити продавця; а історія спілкування — САМІ ДАНІ клієнта, і мовчки
    втратити її гірше, ніж голосно впасти."""
    pid = _pid_for(customer)
    if not pid:
        raise parties.PartyError(
            "Картка «%s» не привʼязана до контакта — історію нікуди записати." % customer)
    parties.add_history(pid, kind, note, action=action)


def contact_view(customer: str) -> dict:
    """Увесь базовий шар картки одним читанням (профіль, особи, досьє, історія)."""
    return parties.contact_view(party_of(customer))


def channels_of(customer: str) -> dict:
    """Канали звʼязку картки. ⚠ ПОХІДНЕ від ручок контакта, не окреме сховище."""
    return parties.contact_view(party_of(customer))["channels"]


def history_of(customer: str) -> list:
    """Історія спілкування з контактом під цією карткою."""
    return parties.contact_view(party_of(customer))["history"]


# ── Публічне API ─────────────────────────────────────────────────────────────
def get_client(customer: str) -> dict:
    """Повна картка клієнта (із секретом) або None."""
    return _load()["clients"].get(_norm(customer))


def get_secret(customer: str) -> str:
    """Per-client секрет підпису. Порожньо, якщо картки немає."""
    return (get_client(customer) or {}).get("secret", "")


def resolve(handle: str) -> str:
    """Повертає КЛЮЧ (повне імʼя) картки за повним іменем АБО за латинським
    `name_en` — без урахування регістру. Дає змогу запускати збірку коротким
    ASCII-іменем (напр. «Smolyar») і потрапляти в ту саму картку без дублів.
    Порожньо, якщо нічого не знайдено."""
    h = _norm(handle)
    if not h:
        return ""
    clients = _load()["clients"]
    if h in clients:                      # точний збіг за повним іменем
        return h
    hl = h.lower()
    for name, c in clients.items():       # збіг за латинським іменем
        ne = str(c.get("name_en") or "").strip().lower()
        if ne and ne == hl:
            return name
    for name in clients:                  # запасний: повне імʼя без регістру
        if name.lower() == hl:
            return name
    return ""


def _sale_of_card(c: dict) -> dict:
    """⭐ КРОК C1: продажний бік картки — ПОХІДНИЙ від угод її контрагента.

    ⛒ «Архівна картка» більше не поле, а ФАКТ: немає жодної живої угоди — значить,
    активного продажу немає. Саме так на диску виглядала правда й до переїзду
    (5 живих карток мали живі угоди, 18 архівних — не мали жодної), тому екран
    Сервіс-центру після переїзду показує рівно те саме.
    ⛒ СТАДІЮ показуємо, ЛИШЕ коли жива угода одна. Дві угоди на одному рядку не
    складаються в одну стадію, і вгадувати «головну» ми не будемо."""
    pid = _s_pid(c)
    live = deals.live_deals_of_party(pid) if pid else []
    stage = live[0]["stage"] if len(live) == 1 else ""
    return {
        # ⚠ ІМʼЯ ПОЛЯ — ЧИСЛО, А НЕ ПЕРЕЛІК. Перше написання звалось `deals`, і в
        # `card_public` воно затирало САМ ПЕРЕЛІК угод числом (спіймано чеком).
        "deals_total": len(deals.deals_of_party(pid)) if pid else 0,
        "live_deals": len(live),
        "stage": stage,
        "attention": sum(int(x.get("attention") or 0) for x in live),
        "archived": not live,
    }


def _s_pid(c: dict) -> str:
    return str((c or {}).get("party_id") or "").strip()


def list_clients(archived: bool = False) -> list:
    """Короткий список карток для UI — БЕЗ секретів. archived=False → активні,
    True → архів. ⭐ Ознака архіву ПОХІДНА від угод (крок C1)."""
    d = _load()
    out = []
    for name, c in sorted(d["clients"].items(), key=lambda kv: kv[0].lower()):
        sale = _sale_of_card(c)
        if bool(sale["archived"]) != bool(archived):
            continue
        row = {
            "customer": name,
            "edition": c.get("edition", ""),
            "expiry": c.get("expiry", ""),
            "version": c.get("version", ""),
            "applied": len(c.get("applied", []) or []),
            "history": len(parties.history(c.get("party_id") or "")),
            "notes": c.get("notes", ""),
            "updated": c.get("updated", ""),
            "has_secret": bool(c.get("secret")),
            # ⚠ Ліцензія, що спливає, мусить бути видною навіть без угоди.
            "due": bool(_due_reason(c)),
            "due_reason": _due_reason(c),
        }
        row.update(sale)
        out.append(row)
    return out


def counts() -> dict:
    """Кількість активних та архівних карток (для заголовків UI).
    ⭐ КРОК C1: активна картка = та, у контрагента якої є ЖИВА угода."""
    d = _load()
    act = sum(1 for c in d["clients"].values() if not _sale_of_card(c)["archived"])
    total = len(d["clients"])
    return {"active": act, "archived": total - act, "total": total}


# ⛔ `set_archived`, `set_stage`, `set_attention`, `set_deal`, `set_next_action`,
# `mark_action_done` ПРИБРАНІ З CRM (крок C1, 15.08.2026) — разом із самими
# полями. Це не «прибрали кнопку»: писар переїхав у `deals.py`, і другого входу
# до тих самих даних не лишилось. Перехідного двоєвладдя не буває: рівно на
# ньому ми горіли в B1 і B5.
# ⭐ Замість них — ОДИН чесний шлях для ТЕХНІЧНОЇ дії, яка раніше мовчки рухала
# гроші у воронці.

def stage_after_build(customer: str, stage: str, why: str = "") -> dict:
    """⭐⭐⭐ РІШЕННЯ Р5: ЗБІРКА ПАКЕТА БІЛЬШЕ НЕ ВГАДУЄ СТАДІЮ ПРОДАЖУ.

    До 15.08 `make_client_build` смикав `crm.set_stage(...)`: технічна дія
    (зібрали клієнту пакет) мовчки рухала ГРОШІ у воронці — просто тому, що
    ліцензія й продаж лежали в одній картці.

    ⛒ Тепер стадію рухаємо, ЛИШЕ коли в контрагента РІВНО ОДНА жива угода: тоді
    іншого адресата не існує. При нулі або кількох НЕ ВГАДУЄМО — і мовчки не
    проходимо повз: лишаємо видимий слід у протоколі й в історії контакту.

    Повертає {"moved": bool, "deal": id, "reason": текст}."""
    name = _norm(customer)
    c = get_client(name)
    if not c:
        return {"moved": False, "deal": "", "reason": "картки «%s» немає" % name}
    pid = _s_pid(c)
    live = deals.live_deals_of_party(pid) if pid else []
    note = why or ("збірка пакета: %s" % stage)
    if len(live) == 1:
        did = live[0]["id"]
        try:
            deals.set_stage(did, stage, source="system")
            return {"moved": True, "deal": did, "reason": ""}
        except Exception as ex:
            reason = "стадію не змінено: %s" % ex
    else:
        reason = ("у контрагента %s живих угод — %d, а не одна: технічна дія не "
                  "вгадує, якій з них рухати стадію" % (pid or "?", len(live)))
    # ⛒ Видимий слід замість тихого пропуску: і в журналі платформи, і в історії
    # спілкування, яку читає людина.
    protocol.write(protocol.A_DEAL_STAGE,
                   entity.ref(entity.KIND_PARTY, pid) if pid else "party:?",
                   outcome="%s: %s" % (protocol.OUT_REFUSED, reason), note=note)
    try:
        _hist(name, "build", "%s — %s" % (note, reason))
    except Exception:
        pass
    return {"moved": False, "deal": "", "reason": reason}


def board() -> dict:
    """Канбан-зріз. ⭐ КРОК C1: рахує УГОДИ, а не картки.

    ⛒ Різниця не косметична: до переїзду у воронці лежали 23 картки, з них
    11 — тестувальники CosmetoCard, які нічого не купували. Імʼя функції лишилось
    тим самим, щоб екран не переписувати двічі, а правда тепер одна — `deals`."""
    return deals.board()


def pipeline() -> dict:
    """Зведення воронки для дашборда — по УГОДАХ (крок C1)."""
    return deals.pipeline()


def card_public(customer: str) -> dict:
    """Картка для UI без секрету (секрет ніколи не віддаємо у фронтенд).
    Бекфіл профілю/контактів для старих карток, щоб UI завжди мав структуру."""
    c = get_client(customer)
    if not c:
        return None
    pub = {k: v for k, v in c.items() if k != "secret"}
    pub["has_secret"] = bool(c.get("secret"))
    pub["name_en"] = pub.get("name_en") or ""  # бекфіл для старих карток
    # ⭐⭐⭐ КРОК B1: форма картки для екрана НЕ ЗМІНИЛАСЬ — змінилось, звідки
    # беруться дані. Профіль, особи, досьє, канали й історія приходять з КОНТАКТА,
    # тому дві угоди того самого контрагента показують одну й ту саму людину й
    # одну спільну історію (до 14.08 у Бориса Мамліна вона була розділена 7 + 4).
    pub.update(parties.contact_view(str(c.get("party_id") or "")))
    # ⭐⭐⭐ КРОК C1: «Угоди» в картці контакту — ПОХІДНЕ від реєстру звʼязків
    # (точно як «Контактні особи» в B5). Другого сховища не зʼявляється, і саме
    # тому повторний продаж тому самому клієнту більше не вимагає вигадувати
    # другу назву картки.
    pid = str(c.get("party_id") or "")
    pub.update(_sale_of_card(c))
    pub["deals"] = deals.tiles_of_party(pid) if pid else []
    pub["due_reason"] = _due_reason(c)
    # Набір систем: НЕМАЄ ключа = не названий (увесь продукт). Порожній список —
    # це вже сказане слово. Тому саме тут бекфілу НЕ робимо: він стер би різницю.
    return pub


@one_writer.guard("CLIENTS_JSON")
def set_systems(customer: str, systems) -> dict:
    """⭐⭐⭐ 07.08.2026, ЕТАП 4. ЩО САМЕ КУПИВ КЛІЄНТ — пише КАРТКА, і тільки вона.

    `systems=None` знімає поле зовсім: «набір не названий» = увесь продукт (саме
    так стоїть у Каспера, і його збірка від цієї правки не змінюється).
    Список — це сказане слово; порожній список = платформа без систем.
    ⚠ Тут ми лише ЗБЕРІГАЄМО. Чи сходиться набір із продуктом — судить ОДИН
    суддя, `make_client_build.client_systems()`; двох суддів однієї правди не
    заводимо (цей клас коштував нам 05-07.08 найдорожче)."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    if systems is None:
        c.pop("systems", None)
    else:
        c["systems"] = sorted({str(x).strip() for x in systems if str(x).strip()})
    c["updated"] = _now()
    _save(d)
    return c


def set_dossier(customer: str, text: str) -> dict:
    """Замінює «Додаткову інформацію про клієнта». ⭐ Досьє — про КОНТАКТ."""
    if not get_client(customer):
        return None
    parties.set_dossier(_pid_for(customer), text or "")
    return get_client(customer)


def append_dossier(customer: str, text: str) -> dict:
    """Дописує блок у «Додаткову інформацію» з міткою дати (для авто-доповнення)."""
    if not get_client(customer):
        return None
    block = "[" + _now() + "] " + (text or "").strip()
    parties.append_dossier(_pid_for(customer), block)
    return get_client(customer)


# ⛔ `set_deal`, `set_next_action`, `mark_action_done` ПРИБРАНІ (крок C1):
# суми, наступна дія і бейдж уваги — це УГОДА. Їхній писар — `deals.set_amount`,
# `deals.set_next_action`, `deals.mark_action_done`.


def set_profile(customer: str, profile: dict) -> dict:
    """Оновлює профіль (лише відомі поля). ⭐ Профіль — про КОНТАКТ, не про угоду.
    Синхронізацію пошти й телефону з ручками робить сам довідник."""
    if not get_client(customer):
        return None
    known = {k: v for k, v in dict(profile or {}).items() if k in PROFILE_FIELDS}
    parties.set_profile(_pid_for(customer), known)
    return get_client(customer)


def add_contact(customer: str, contact: dict) -> dict:
    """Додає повʼязану особу (імʼя/роль/телефон/пошта/нотатка) — на КОНТАКТ."""
    c = get_client(customer)
    if not c:
        return None
    if not str((contact or {}).get("name") or "").strip():
        return c                      # без імені не додаємо (стара поведінка)
    parties.add_contact(_pid_for(customer), contact)
    return get_client(customer)


def remove_contact(customer: str, index: int) -> dict:
    """Видаляє повʼязану особу за номером у переліку — на КОНТАКТІ."""
    c = get_client(customer)
    if not c:
        return None
    try:
        parties.remove_contact(_pid_for(customer), index)
    except parties.PartyError:
        return c                      # немає такої особи — стара поведінка мовчазна
    return get_client(customer)


class DealFieldMoved(ValueError):
    """Продажне поле спробували записати в картку клієнта (крок C1)."""


@one_writer.guard("CLIENTS_JSON")
def ensure_client(customer: str, **fields) -> dict:
    """Створює картку (з новим секретом) або оновлює наявну заданими полями.
    Секрет НІКОЛИ не перезаписується наявний. Повертає повну картку."""
    customer = _norm(customer)
    if not customer:
        raise ValueError("порожнє ім'я клієнта")
    d = _load()
    c = d["clients"].get(customer)
    if not c:
        c = _blank_card(customer)
        d["clients"][customer] = c
    # ⛔ КРОК B1: profile / contacts / dossier / channels / last_inbound тут БІЛЬШЕ
    # НЕМАЄ — це базовий шар, його писар `parties.py` (crm.set_profile,
    # crm.add_contact, crm.set_dossier, crm.link_email/link_telegram).
    allowed = {"name_en", "license_key", "edition", "expiry", "role", "version", "notes",
               # ⭐ 04.08.2026: звертання до людини живе в КАРТЦІ, а не в коді розсилки.
               # Інакше імʼя клієнта має двох писарів: CRM і рядок у скрипті.
               "salutation"}
    # ⛒ КРОК C1: продажне поле в картці клієнта — ВІДМОВА СЛОВАМИ, а не тихе
    # ігнорування. Мовчки проковтнути `stage=...` означало б, що викликач думає,
    # ніби стадію збережено, а її немає ніде.
    moved = {"stage", "attention", "deal", "next_action", "archived"}
    bad = sorted(moved & set(fields))
    if bad:
        raise DealFieldMoved(
            "Поле(я) %s більше не належать картці клієнта: продаж переїхав в УГОДУ "
            "(`deals.py`, крок C1). Картка — це ліцензія, канал оновлень і набір "
            "систем. Заведіть або відкрийте угоду цього контрагента."
            % ", ".join("«%s»" % b for b in bad))
    for k, v in fields.items():
        if k in allowed and v is not None:
            c[k] = v
    if not c.get("secret"):
        c["secret"] = new_secret()
    c["updated"] = _now()
    _save(d)
    return c


def add_history(customer: str, kind: str, note: str = "") -> dict:
    """Додає запис в історію спілкування. ⭐ Історія живе на КОНТАКТІ (крок B1)."""
    if not get_client(customer):
        return None
    _hist(customer, kind, note)
    return get_client(customer)


@one_writer.guard("CLIENTS_JSON")
def record_update(customer: str, version: str, update_id: str) -> dict:
    """Фіксує направлене клієнту оновлення (версія + id + запис в історію)."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    if update_id and update_id not in (c.get("applied") or []):
        c.setdefault("applied", []).append(update_id)
    if version:
        c["version"] = version
    c["updated"] = _now()
    _save(d)
    # ⭐ Що поїхало клієнту — факт УГОДИ (лишається в картці), а розмова про це —
    # подія СПІЛКУВАННЯ (їде на контакт разом зі своєю дією в протоколі).
    _hist(customer, "update", f"{version} ({update_id})", action=protocol.A_PARTY_UPDATE)
    return get_client(customer)


def set_notes(customer: str, notes: str) -> dict:
    """Оновлює нотатки картки (створює картку, якщо немає)."""
    return ensure_client(customer, notes=notes or "")


@one_writer.guard("CLIENTS_JSON")
def delete_client(customer: str) -> bool:
    d = _load()
    if _norm(customer) in d["clients"]:
        del d["clients"][_norm(customer)]
        _save(d)
        return True
    return False


# ── Фаза 4: інбаунд-сигнал (зіставлення вхідних повідомлень із карткою) ───────
# Коли клієнт пише в Telegram або на пошту — знаходимо його картку за каналом
# і піднімаємо позначку «потребує уваги». Якщо картки немає — вхідне не губиться
# (для пошти створюється «Новий клієнт», для Telegram — лягає в чергу inbox).

def _emails_of(c: dict) -> set:
    """Усі відомі адреси картки.

    ⭐ КРОК B1: адреси живуть на КОНТАКТІ — питаємо насамперед його.
    ⚠ Але СТАРА картка, яка ще не пройшла міграцію (або яку міграція свідомо не
    чіпала через розбіжність), тримає адресу в собі — і саме з неї довідник
    вперше й дізнається, кого впізнавати. Прибрати цей бік означало б, що
    непереїхала картка мовчки перестає знаходитись за поштою."""
    out = set(parties.emails(str(c.get("party_id") or "")))
    e = ((c.get("profile") or {}).get("email") or "").strip().lower()
    if e:
        out.add(e)
    for ct in (c.get("contacts") or []):
        e = (ct.get("email") or "").strip().lower()
        if e:
            out.add(e)
    e = ((c.get("channels") or {}).get("email") or "").strip().lower()
    if e:
        out.add(e)
    return out


# ── Тотожність контрагента: питаємо ДОВІДНИК, а не рядок назви ───────────────
# ⭐⭐⭐ 12.08.2026 (зміна 167). Хто цей контрагент — знає `parties.py`. Тут лише
# перехід «номер контрагента → картка угоди». Запасний прохід по картках лишений
# для тих, що ще не пройшли `ensure_parties()`: без нього стара картка мовчки
# перестала б знаходитись, а мовчазна втрата клієнта дорожча за зайвий цикл.


def party_of(customer: str) -> str:
    """Номер контрагента в довіднику за іменем картки (порожньо, якщо не привʼязано)."""
    c = _load()["clients"].get(_norm(customer)) or {}
    return str(c.get("party_id") or "").strip()


def card_of_party(pid: str) -> str:
    """Імʼя картки за номером контрагента (порожньо, якщо картки ще немає)."""
    pid = str(pid or "").strip()
    if not pid:
        return ""
    for name, c in _load()["clients"].items():
        if str(c.get("party_id") or "").strip() == pid:
            return name
    return ""


def _by_handle(kind: str, value) -> str:
    """Картка за ручкою контрагента (пошта/телеграм) через довідник."""
    pid = parties.find(value, kind)
    return card_of_party(pid) if pid else ""


def find_by_email(email: str) -> str:
    """Імʼя клієнта за адресою пошти. Спершу довідник, тоді запасний прохід."""
    email = (email or "").strip().lower()
    if not email:
        return ""
    name = _by_handle(parties.H_EMAIL, email)
    if name:
        return name
    for name, c in _load()["clients"].items():
        if email in _emails_of(c):
            return name
    return ""


def find_by_telegram(chat_id) -> str:
    """Імʼя клієнта за привʼязаним Telegram chat_id. Спершу довідник."""
    cid = str(chat_id or "").strip()
    if not cid:
        return ""
    name = _by_handle(parties.H_TG_ID, cid)
    if name:
        return name
    # ⭐ Запасний прохід питає КОНТАКТ під карткою (крок B1): у самій картці
    # каналів більше немає — інакше цей прохід мовчки перестав би щось знаходити,
    # а мовчазна втрата клієнта дорожча за зайвий цикл.
    for name, c in _load()["clients"].items():
        if parties.channels(str(c.get("party_id") or "")).get("telegram_id") == cid:
            return name
    return ""


def find_by_telegram_user(username: str) -> str:
    """Імʼя клієнта за Telegram-юзернеймом (@user) або порожньо."""
    u = (username or "").strip().lstrip("@").lower()
    if not u:
        return ""
    name = _by_handle(parties.H_TG_USER, u)
    if name:
        return name
    for name, c in _load()["clients"].items():
        cu = parties.channels(str(c.get("party_id") or "")).get("telegram_user") or ""
        if cu and cu == u:
            return name
    return ""



@one_writer.guard("CLIENTS_JSON")
def set_party(customer: str, pid: str) -> dict:
    """Привʼязати картку до контрагента в довіднику (кнопка менеджера, міграція).
    Чужого номера не вигадуємо: контрагент мусить існувати."""
    pid = str(pid or "").strip()
    if not parties.exists(pid):
        raise parties.PartyError("Контрагента %s немає в довіднику." % (pid or "«»"))
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    c["party_id"] = pid
    c["updated"] = _now()
    _save(d)
    return c


def _card_handles(c: dict) -> dict:
    """Ручки, які вже лежать у картці, — у вигляді, зрозумілому довіднику."""
    ch = c.get("channels") or {}
    h = {parties.H_EMAIL: sorted(_emails_of(c))}
    tg = str(ch.get("telegram_id") or "").strip()
    if tg:
        h[parties.H_TG_ID] = [tg]
    tgu = str(ch.get("telegram_user") or "").strip()
    if tgu:
        h[parties.H_TG_USER] = [tgu]
    ph = str((c.get("profile") or {}).get("phone") or "").strip()
    if ph:
        h[parties.H_PHONE] = [ph]
    return h


@one_writer.guard("CLIENTS_JSON")
def _ensure_party_for(customer: str, kind: str = parties.KIND_UNKNOWN,
                      roles=None, source: str = "card", strict: bool = True) -> str:
    """Гарантує, що в картки є контрагент у довіднику; повертає його номер.

    ⭐ Картка вже існує — отже, людина колись свідомо завела цього контрагента.
    Тому тут заведення в довідник ДОЗВОЛЕНЕ: це переведення наявного рішення,
    а не створення нового з невідомого листа."""
    name = _norm(customer)
    d = _load()
    c = d["clients"].get(name)
    if not c:
        return ""
    pid = str(c.get("party_id") or "").strip()
    if pid and parties.exists(pid):
        return pid
    handles = _card_handles(c)
    pid = ""
    for hk, values in handles.items():                 # може, довідник його вже знає
        for v in values:
            pid = parties.find(v, hk)
            if pid:
                break
        if pid:
            break
    if not pid:
        try:
            pid = parties.create(name, kind=kind, roles=roles or [parties.ROLE_CLIENT],
                                 handles=handles, source=source)["id"]
        except parties.PartyError:
            if strict:
                raise
            # Ручка вже чужа: картку не втрачаємо, але й дубля ручки не робимо.
            pid = parties.create(name, kind=kind, roles=roles or [parties.ROLE_CLIENT],
                                 handles=None, source=source + ":конфлікт ручок")["id"]
    c["party_id"] = pid
    c["updated"] = _now()
    _save(d)
    return pid


def ensure_parties() -> dict:
    """Переведення наявних карток у довідник контрагентів (одноразово, ідемпотентно).

    Нічого не видаляє і не переносить: картка лишається на місці, у неї лише
    зʼявляється номер контрагента. Конфлікти ручок не ховає — повертає переліком."""
    report = {"cards": 0, "already": 0, "linked": 0, "conflicts": []}
    for name in list(_load()["clients"].keys()):
        report["cards"] += 1
        if party_of(name):
            report["already"] += 1
            continue
        before = parties.count()["all"]
        try:
            pid = _ensure_party_for(name, source="міграція карток", strict=False)
        except Exception as ex:                        # аварія не має спиняти решту
            report["conflicts"].append("%s: %s" % (name, ex))
            continue
        if pid:
            report["linked"] += 1
            if parties.count()["all"] == before:
                report["conflicts"].append("%s: приєднано до наявного контрагента %s"
                                           % (name, pid))
    return report


def sync_handle(customer: str, kind: str, value) -> str:
    """ОДИН шлях, яким адреса/телеграм потрапляє в тотожність контрагента.
    Кличуть його і привʼязка каналу, і редагування профілю — щоб довідник не
    відставав від картки (правило, яке живе в одному шляху, — наш найдорожчий клас)."""
    v = str(value or "").strip()
    if not v:
        return ""
    pid = _ensure_party_for(customer)
    if not pid:
        return ""
    parties.add_handle(pid, kind, v)
    return pid

def link_telegram(customer: str, chat_id=None, username: str = "") -> dict:
    """Привʼязує Telegram до контакта під карткою (щоб вхідні зіставлялись).

    ⭐ КРОК B1: канал більше не дублюється в картці. `channels` у картці й
    `handles` у довіднику були ДВОМА писарями одного факту — лишився один."""
    if not get_client(customer):
        return None
    if chat_id is not None and str(chat_id).strip():
        sync_handle(customer, parties.H_TG_ID, chat_id)
    if username:
        sync_handle(customer, parties.H_TG_USER, username)
    return get_client(customer)


def link_email(customer: str, email: str) -> dict:
    """Привʼязує адресу пошти до контакта під карткою."""
    if not get_client(customer):
        return None
    sync_handle(customer, parties.H_EMAIL, email)
    return get_client(customer)


@one_writer.guard("CLIENTS_JSON")
def note_inbound(customer: str, channel: str, preview: str = "", subject: str = "",
                 to: str = "", cc: str = "") -> dict:
    """Реєструє вхідне повідомлення від клієнта: +1 до позначки «уваги», запис в історію,
    оновлення часу останнього вхідного. Це і є сигнал, що спалахує бейдж на канбані."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    c["updated"] = _now()
    _save(d)
    pid = _pid_for(customer)
    # ⭐⭐⭐ КРОК C2 (15.08.2026): «у яку угоду лягло вхідне» вирішує ОДИН писар —
    # `deal_mail.route`. Раніше рішення жило прямо тут; після появи адреси угоди
    # в темі листа писарів стало б ДВА: цей рахував би «рівно одна жива угода»,
    # а C2 читав би токен — і бейдж уваги стрибав би вдвічі.
    # ⛔ Вгадування тут немає й не буде: якщо адреси немає, а живих угод кілька —
    # лист іде в чергу «Рознести» й чекає на один клік людини.
    # ⛒ МОВЧАТИ НЕ МОЖНА (той самий урок, що й у `inbound.promote`): якщо
    # маршрутизація впала, лист не ліг ні в угоду, ні в чергу — він просто
    # зник. Ловимо, щоб не зламати приймання, але лишаємо ГУЧНИЙ слід.
    try:
        import deal_mail
        # ⭐ 618: «кому» їде до писаря разом із темою — саме там живе
        # відповідь на питання «чий це лист».
        deal_mail.route(pid, channel, subject=subject, preview=preview,
                        to=to, cc=cc)
    except Exception as _ex:
        protocol.write(protocol.A_DEAL_MAIL_PARKED, parties.ref(pid),
                       outcome=protocol.OUT_FAILED,
                       note="вхідне не рознесено: %s" % _ex)
    if not pid:
        raise parties.PartyError(
            "Картка «%s» не привʼязана до контакта — вхідне нікуди записати." % customer)
    parties.note_inbound(pid, channel, preview)
    return get_client(customer)


# ── Черга незіставлених вхідних (немає картки) ───────────────────────────────
INBOX_JSON = CRM_DIR / "_inbound_inbox.json"


def _inbox_load() -> list:
    try:
        v = one_writer.read_json(INBOX_JSON)
        return v if isinstance(v, list) else []
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        return []


def _inbox_save(items: list) -> None:
    CRM_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(INBOX_JSON, items)


def record_unmatched(channel: str, identity: str, name: str = "", preview: str = "") -> dict:
    """Вхідне від невідомого (немає картки) — щоб не загубилось. Власник у консолі
    може створити/привʼязати картку. Дублікати за (channel, identity) обʼєднуються."""
    items = _inbox_load()
    ident = str(identity or "").strip()
    snippet = " ".join((preview or "").split())[:200]
    for it in items:
        if it.get("channel") == channel and str(it.get("identity")) == ident:
            it["count"] = int(it.get("count", 1)) + 1
            it["last_seen"] = _now()
            if name:
                it["name"] = name
            if snippet:
                it["preview"] = snippet
            _inbox_save(items)
            return it
    rec = {"channel": channel, "identity": ident, "name": (name or "").strip(),
           "preview": snippet, "count": 1, "first_seen": _now(), "last_seen": _now()}
    items.append(rec)
    _inbox_save(items)
    return rec


def inbox() -> list:
    """Незіставлені вхідні (для UI: вхідні без картки)."""
    return _inbox_load()


def clear_inbox(channel: str, identity: str) -> bool:
    """Прибирає елемент черги (після привʼязки/створення картки)."""
    items = _inbox_load()
    ident = str(identity or "").strip()
    kept = [it for it in items if not (it.get("channel") == channel and str(it.get("identity")) == ident)]
    if len(kept) != len(items):
        _inbox_save(kept)
        return True
    return False
