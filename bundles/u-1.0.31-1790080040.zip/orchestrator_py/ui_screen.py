# -*- coding: utf-8 -*-
"""ui_screen.py -- ОДИН ПИСАР АДРЕСИ ЕКРАНА (зміна 439, 02.09.2026).

🩸 ЧОМУ ЦЕЙ ФАЙЛ Є. Десять чеків знали консоль за адресою `ui/index.html`.
Щойно екран CRM переїхав у спільний файл (зміна 436) -- усі десять
почервоніли, дивлячись у порожнє місце. Адреса, повторена в десяти файлах,
це десять писарів однієї правди.

Тепер писар один. Чек питає «покажи консоль», а не «відкрий файл», і
наступний переїзд екрана коштує ОДНУ правку тут.
"""
import pathlib

HERE = pathlib.Path(__file__).resolve().parent
UI = HERE / "ui"

# Із чого складається консоль ОЧИМА ЧЕКА: чохол (сторінка) плюс усе, що вона
# монтує в себе. Порядок значення не має -- чеки шукають у тексті.
CONSOLE_PARTS = ("index.html", "crm_core.js", "crm_core.css")


def console_text() -> str:
    """Консоль як ОДИН текст: сторінка плюс спільні файли, які вона підключає."""
    out = []
    for name in CONSOLE_PARTS:
        p = UI / name
        if p.exists():
            out.append("/* === ui/%s === */\n" % name)
            out.append(p.read_text(encoding="utf-8"))
    return "\n".join(out)


def own_fields_text() -> str:
    """Спільний маляр власних полів — один на CRM і на екран задачі (527)."""
    p = UI / "own_fields.js"
    return p.read_text(encoding="utf-8") if p.exists() else ""


def task_screen_text() -> str:
    """Екран однієї задачі як текст — коли чек судить саме його."""
    p = UI / "taskdesk_task.html"
    return p.read_text(encoding="utf-8") if p.exists() else ""


def crm_screen_text() -> str:
    """Лише спільний екран CRM -- коли чек судить саме його, а не всю консоль."""
    p = UI / "crm_core.js"
    return p.read_text(encoding="utf-8") if p.exists() else ""
