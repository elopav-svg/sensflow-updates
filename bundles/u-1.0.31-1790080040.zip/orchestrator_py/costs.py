"""
costs.py — оцінка вартості LLM-викликів за токенами (для показу в консолі)
та ЄДИНИЙ лічильник грошей, на якому тримаються всі стелі вартості.

Це ОЦІНКА, а не фактура: рахуємо за прайс-таблицею моделей × токени з відповідей
API (usage). Точні витрати — на сторінці білінгу провайдера. Ціни орієнтовні
(≈ 06.2026) і легко редагуються нижче.

⭐⭐⭐ 29.07.2026 (зміна 26). КОРІНЬ, ЯКИЙ ТУТ ВИЛІКУВАНО.
Раніше прогін відкривав ВИКЛИКАЧ (`engine.handle_message`), і рівно один. Тому
кожен інший вхід у платну роботу — автоматизації за розкладом, мозок підтримки,
сторож тендерів, розбір стилю — народжувався БЕЗ лічильника. А далі все мовчало:
`record()` при відсутньому прогоні просто нічого не писав, `spent_usd()` казав
«0», і мʼяка пауза в executor та аварійна межа в `llm._budget_stop()` бачили нуль
і відповідали «все гаразд». Клієнт міг створити автоматизацію й платити без межі.

ЛІКИ (три шари, кожен закриває свій клас):
  1. `run_scope()` — пара «відкрив–закрив» стала ОДНІЄЮ річчю. Забути половину
     пари більше не можна: `with costs.run_scope(...)` або є, або його немає.
  2. `ensure_run()` — сітка під усім: канал, який забули загорнути, не лишається
     без стелі. Прогін відкривається САМ, з базовою стелею, і канал НАЗИВАЄТЬСЯ
     в журналі. Безпечний стан — стан за замовчуванням, а не той, який треба
     свідомо ввімкнути [[project_run_cost_control]].
  3. ДЕННИЙ лічильник автоматизацій — стеля на прогін не рятує від 30 прогонів
     на добу. Гроші додаються в добовий рахунок ТАМ, ДЕ ВИТРАЧАЮТЬСЯ (`record`),
     а не в кінці прогону: інакше один прогін-утікач проскочив би денну межу
     цілком. Рахунок лежить у `config.STATE_DIR` і переживає перезапуск.
Рішення Андрія 29.07.2026: денна межа стосується ЛИШЕ безпілотних спрацювань за
розкладом. Питання людини в чаті (і ручний запуск на її команду) нею не
блокуються ніколи — інакше клієнт вранці впреться в стіну через нічну задачу.
"""
import json
import threading
from datetime import datetime

# ⭐⭐⭐ ЦІНИ $ ЗА 1 МЛН ТОКЕНІВ: (вхідні, вихідні).
# 🩸 БРАТИ ЛИШЕ З ОФІЦІЙНОЇ СТОРІНКИ ПРОВАЙДЕРА. Сторонні агрегатори і власна
# памʼять — не джерело: 09.09.2026 три ціни тут виявились неправильними саме
# тому, що їх колись вписали «за схожістю», а не звірили.
#   claude-opus-4-8 стояв 15/75 (це ціна Opus 4.1) замість 5/25 — завищення ВТРИЧІ;
#   claude-haiku-4-5 стояв 0.80/4 (ціна Haiku 3.5) замість 1/5;
#   gemini-3.6-flash стояв 1.50/7.50 — це ціна з 01.01.2027, а не чинна.
# ⛒ НЕПРАВИЛЬНА ЦІНА ГІРША ЗА ВІДСУТНЮ: відсутню платформа називає вголос
# (зміна 539), а неправильна тихо бреше і в рахунку, і в стелі.
PRICES_CHECKED = "09.09.2026"   # коли востаннє звіряли з офіційними сторінками
PRICES = {
    # ── Anthropic · platform.claude.com/docs/en/about-claude/pricing ──────
    "claude-opus-5": (5.0, 25.0),
    "claude-opus-4-8": (5.0, 25.0),
    "claude-sonnet-5": (2.0, 10.0),            # $2/$10 стало стандартною ціною
    "claude-sonnet-4-6": (3.0, 15.0),
    "claude-sonnet-4-5": (3.0, 15.0),
    "claude-haiku-4-5": (1.0, 5.0),
    # ── OpenAI · developers.openai.com/api/docs/pricing ───────────────────
    "gpt-4.1": (2.0, 8.0),
    "gpt-4o": (2.50, 10.0),
    # ── Google · ai.google.dev/gemini-api/docs/pricing ────────────────────
    "gemini-2.5-pro": (1.25, 10.0),            # ціна для запитів до 200k токенів
    # ⚠ 3.6-flash: 0.75/3.75 діє ДО 31.12.2026, з 01.01.2027 буде 1.50/7.50.
    # 🩸 Ціна з датою зміни — це хвіст: після Нового року рахунок занизиться
    # удвічі й ніхто про це не дізнається. Звірити прайс на початку січня.
    "gemini-3.6-flash": (0.75, 3.75),
    "gemini-3.5-flash-lite": (0.30, 2.50),     # типовий виконавець
    "gemini-2.5-flash": (0.30, 2.50),
    # ⛔ KIMI/MOONSHOT свідомо ВІДСУТНІЙ: офіційна сторінка чисел не віддала,
    # а ціна зі стороннього сайту — це вигадка з чужим підписом. Невідома
    # модель чесно спиняє безпілотну роботу (зміна 539).
}

_lock = threading.Lock()
_session = {"in": 0, "out": 0, "usd": 0.0, "calls": 0}
_local = threading.local()  # поточний прогін (per-request)

# Рід прогону. Від нього залежить ОДНЕ: чи йдуть гроші в добовий рахунок.
KIND_CHAT = "chat"                # людина за кермом: чат, ручний запуск на команду
KIND_AUTOMATION = "automation"    # безпілотне спрацювання за розкладом

# Прогін «без господаря» (канал, який забули загорнути в run_scope) не може жити
# вічно: інакше він накопичував би витрати в довгому потоці й зрештою заблокував
# би канал назавжди. Через цей час рахунок такого прогону починається заново.
ORPHAN_TTL_SEC = 900

_day_lock = threading.Lock()
_day = None      # {"date": "YYYY-MM-DD", "usd": float, "runs": int} — кеш добового рахунку


def _now():
    return datetime.now()


def _lookup(model: str):
    """ОДИН пошук ціни на дві відповіді: скільки коштує і чи ми це взагалі
    знаємо. Другий такий самий пошук поруч розійшовся б із цим на першій же
    новій моделі."""
    m = (model or "").lower()
    if m in PRICES:
        return PRICES[m]
    for k, v in PRICES.items():            # часткове співпадіння (версії/дати в назві)
        if k.lower() in m or m.startswith(k.lower()):
            return v
    return None


def is_free_local(model: str) -> bool:
    """Чи це ЛОКАЛЬНА модель, яка крутиться на залізі клієнта.

    ⛒ Питаємо ТОГО, ХТО ЗА ЦЕ ВІДПОВІДАЄ (`config.provider_for_model`), а не
    власний список імен: імена локальних моделей довільні (llama3.2, qwen2.5…),
    і другий список розійшовся б із рештою платформи назавтра."""
    try:
        import config
        return bool(model) and config.provider_for_model(model) == "local"
    except Exception:
        return False


def price_known(model: str) -> bool:
    """Чи знаємо ціну цієї моделі. ⭐⭐⭐ 09.09.2026, зміна 539: НУЛЬ І «НЕ ЗНАЮ»
    БІЛЬШЕ НЕ ОДНЕ ЧИСЛО. Доти стеля бачила нуль і читала його як чесну
    дешевизну — а в `.env.local` стояла модель мозку, якої в прайсі немає.

    ⛒ 539c: ЛОКАЛЬНА МОДЕЛЬ — ЦЕ ЧЕСНИЙ НУЛЬ, А НЕ НЕЗНАННЯ. Вона працює на
    машині клієнта і провайдеру не коштує нічого; спиняти через неї безпілотну
    роботу означало б покарати саме за той спосіб, який ми продаємо як
    найдешевший і найприватніший."""
    return is_free_local(model) or _lookup(model) is not None


def _price(model: str):
    """Скільки коштує мільйон токенів. Невідома модель — (0, 0): МИ НЕ
    ВГАДУЄМО ЦІН. ⛒ Але той, хто стереже гроші, мусить питати `price_known`,
    а не читати цей нуль як факт."""
    got = _lookup(model)
    return got if got is not None else (0.0, 0.0)


# ─────────────────────────── ДОБОВИЙ РАХУНОК АВТОМАТИЗАЦІЙ ───────────────────────────
# Лежить у config.STATE_DIR — тобто йде за перемикачем стану разом з усім іншим
# і НЕ смітить у бойові теки під час чеків [[project_state_isolation]].

def _day_path():
    import config
    d = config.STATE_DIR / "state"
    d.mkdir(parents=True, exist_ok=True)
    return d / "automation_day.json"


def _day_load() -> dict:
    """Прочитати добовий рахунок із диска (переживає перезапуск сервера)."""
    today = _now().strftime("%Y-%m-%d")
    try:
        rec = json.loads(_day_path().read_text(encoding="utf-8"))
        if str(rec.get("date")) == today:
            return {"date": today, "usd": float(rec.get("usd") or 0.0),
                    "runs": int(rec.get("runs") or 0),
                    # 539: скільки разів автоматизація сьогодні крутила модель
                    # БЕЗ ВІДОМОЇ ЦІНИ і які саме це моделі. Старий файл цих
                    # полів не має — читаємо мʼяко, як і решту.
                    "unknown": int(rec.get("unknown") or 0),
                    "models": list(rec.get("models") or [])}
    except Exception:
        pass
    return {"date": today, "usd": 0.0, "runs": 0, "unknown": 0, "models": []}


def _day_get() -> dict:
    """Поточний добовий рахунок. Сам перегортає добу на новій даті."""
    global _day
    today = _now().strftime("%Y-%m-%d")
    if _day is None or _day.get("date") != today:
        _day = _day_load()
        if _day.get("date") != today:
            _day = {"date": today, "usd": 0.0, "runs": 0, "unknown": 0, "models": []}
    _day.setdefault("unknown", 0)
    _day.setdefault("models", [])
    return _day


def _day_save():
    try:
        _day_path().write_text(json.dumps(_day, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass    # диск недоступний — межа лишається чинною в памʼяті цього процесу


def day_spent_usd() -> float:
    """Скільки автоматизації витратили СЬОГОДНІ, $."""
    with _day_lock:
        return float(_day_get().get("usd", 0.0) or 0.0)


def day_cap() -> float:
    """Денна стеля автоматизацій, $ (0 = межі немає, свідомо вимкнено)."""
    import config
    try:
        return float(getattr(config, "MAX_DAY_USD", 0.0) or 0.0)
    except Exception:
        return 0.0


def unknown_today() -> list:
    """Моделі БЕЗ ВІДОМОЇ ЦІНИ, якими автоматизація працювала сьогодні."""
    with _day_lock:
        return list(_day_get().get("models") or [])


def over_day_cap() -> bool:
    """Чи спиняємо безпілотні автоматизації. Чат людини цього не питає.

    ⭐⭐⭐ 539: ДВІ ПРИЧИНИ, А НЕ ОДНА. Друга — «сьогодні працювали моделлю,
    ціни якої ми не знаємо». Це FAIL-CLOSED: невідома ціна означає «межу
    порахувати неможливо», а не «безкоштовно». Дозволити безпілотну роботу з
    непорахованими грошима — це і є та сама діра, заради якої стелю ставили."""
    cap = day_cap()
    if cap > 0 and day_spent_usd() >= cap:
        return True
    return bool(unknown_today())


def day_block_reason() -> str:
    """ЧОМУ спинено — ОДНИМ ПИСАРЕМ на всю платформу, людською мовою.

    🩸 Доти цей текст був ТРИЧІ скопійований (engine, llm, scheduler) і всюди
    казав «витрачено $X при межі $Y». З появою другої причини всі три збрехали б
    однаково: показали б «витрачено $0.00 при межі $5.00» і виглядали б як
    поломка. Причина мусить мати одного автора."""
    unknown = unknown_today()
    if unknown:
        return ("Автоматизації зупинено, бо платформа НЕ ЗНАЄ ЦІНИ моделі, якою "
                "сьогодні працювала: %s. Порахувати денну межу неможливо, тому "
                "безпілотну роботу спинено — це запобіжник ваших грошей, а не "
                "поломка. Впишіть ціну цієї моделі в PRICES (файл costs.py) або "
                "вкажіть у .env.local модель, ціна якої вже відома."
                % ", ".join(unknown))
    return ("Автоматизації зупинено за денною межею вартості: за добу витрачено "
            "$%.2f при межі $%.2f. Це не поломка — це запобіжник ваших грошей. "
            "Завтра задача запрацює знову; підняти межу можна рядком MAX_DAY_USD "
            "у файлі .env.local." % (day_spent_usd(), day_cap()))


def day_report() -> dict:
    """Для журналу й UI: скільки витрачено за добу, яка межа, скільки лишилось."""
    with _day_lock:
        cur = dict(_day_get())
    cap = day_cap()
    cur["cap"] = cap
    cur["left"] = max(0.0, cap - float(cur.get("usd", 0.0))) if cap > 0 else None
    # 539: причина зупинки їде РАЗОМ із числами — інакше екран показав би
    # «витрачено $0.00» і людина шукала б поломку там, де її немає.
    cur["unknown_models"] = list(cur.get("models") or [])
    cur["blocked"] = over_day_cap()
    cur["reason"] = day_block_reason() if cur["blocked"] else ""
    return cur


def _day_add_unknown(model: str):
    """Записати, що сьогодні працювали моделлю без відомої ціни (539).

    ⛒ Пишемо ЛИШЕ для безпілотних спрацювань — рівно там, де діє денна межа.
    Чат людини цього не викликає, бо його денна межа й так не блокує."""
    cur = getattr(_local, "run", None)
    if cur is None or cur.get("kind") != KIND_AUTOMATION:
        return
    name = (model or "").strip() or "без назви"
    with _day_lock:
        d = _day_get()
        d["unknown"] = int(d.get("unknown") or 0) + 1
        if name not in (d.get("models") or []):
            d.setdefault("models", []).append(name)
        _day_save()


def _day_add(usd: float):
    with _day_lock:
        cur = _day_get()
        cur["usd"] = float(cur.get("usd", 0.0)) + float(usd or 0.0)
        _day_save()


def _day_add_run():
    with _day_lock:
        cur = _day_get()
        cur["runs"] = int(cur.get("runs", 0)) + 1
        _day_save()


def day_reset():
    """Скинути добовий рахунок (для чеків і для ручного втручання)."""
    global _day
    with _day_lock:
        _day = {"date": _now().strftime("%Y-%m-%d"), "usd": 0.0, "runs": 0}
        _day_save()


def record(model: str, in_tok, out_tok):
    """Записати споживання одного виклику в сесію, поточний прогін і — якщо це
    безпілотна автоматизація — у ДОБОВИЙ рахунок.

    ⭐ Добові гроші додаються САМЕ ТУТ, а не в кінці прогону. Інакше один
    прогін-утікач витратив би денну межу цілком і лише потім про неї дізнався."""
    try:
        in_tok = int(in_tok or 0)
        out_tok = int(out_tok or 0)
    except Exception:
        return
    pi, po = _price(model)
    usd = in_tok / 1e6 * pi + out_tok / 1e6 * po
    # ⭐⭐⭐ 539: ЦІНУ, ЯКОЇ МИ НЕ ЗНАЄМО, ЗАПИСУЄМО ЯК НЕВІДОМУ, А НЕ ЯК НУЛЬ.
    # Інакше найдорожчий виклик додає до добового рахунку рівно нічого, і
    # запобіжник грошей мовчить саме тоді, коли він найпотрібніший.
    if not price_known(model):
        _day_add_unknown(model)
    with _lock:
        _session["in"] += in_tok
        _session["out"] += out_tok
        _session["usd"] += usd
        _session["calls"] += 1
    cur = getattr(_local, "run", None)
    if cur is not None:
        cur["in"] += in_tok
        cur["out"] += out_tok
        cur["usd"] += usd
        cur["calls"] += 1
        if cur.get("kind") == KIND_AUTOMATION:
            _day_add(usd)


def start_run(channel: str = "chat", kind: str = KIND_CHAT):
    """Почати облік нового прогону (скидає лічильник поточного запиту).

    channel — хто саме прийшов по гроші; потрапляє в журнал, коли канал забули
    загорнути. kind — KIND_CHAT (людина за кермом) або KIND_AUTOMATION
    (безпілотне спрацювання; лише його гроші йдуть у добовий рахунок)."""
    _local.run = {"in": 0, "out": 0, "usd": 0.0, "calls": 0,
                  "channel": str(channel or "?"), "kind": str(kind or KIND_CHAT),
                  "owned": True, "opened_at": _now().timestamp()}
    _local.cap = 0.0  # стелю ставить executor під конкретний прогін; стара не тягнеться
    _open_protocol(channel, fresh=True)
    if kind == KIND_AUTOMATION:
        _day_add_run()


def _open_protocol(channel, fresh: bool = False) -> None:
    """ПОЧАТОК КРОКУ РОБОТИ для загального протоколу (хребет, 13.08.2026).

    ⭐ «ЗВІДКИ БЕРЕТЬСЯ РОБОТА» — питання №1, заради якого протокол і затівався.
    Відповідь на нього знає рівно той, хто відкриває крок: канал. Якби кожен писар
    називав джерело сам, більшість рядків лишились би без нього (перевірено очима
    на першому ж звіті: 5 рядків із 9 казали «не вказано»). Тому джерело кроку
    ставиться ОДИН раз тут, а явно назване джерело окремої дії (канал вхідного
    листа) його перебиває — бо воно точніше.

    ⚠ `fresh` — новий крок починається з чистого контексту: недобитий контекст
    попереднього кроку приписав би цю роботу не тому клієнту."""
    try:
        import protocol
        if fresh:
            # ⛒ 542: НЕ `clear()`. Новий КРОК роботи забуває крок, але людину,
            # яку назвав канал на вході запиту, не чіпає: інакше кожен хід чату
            # починався б із того, що платформа забула, хто прийшов.
            protocol.new_step()
        protocol.bind(source=str(channel or ""))
    except Exception:
        pass


def end_run() -> dict:
    """Завершити прогін і повернути його підсумок."""
    cur = getattr(_local, "run", None)
    _local.run = None
    _local.cap = 0.0
    _to_protocol(cur)
    return dict(cur) if cur else {"in": 0, "out": 0, "usd": 0.0, "calls": 0}


def _to_protocol(cur) -> None:
    """ТОЧКА ВРІЗКИ №5 — ГРОШІ (хребет, 13.08.2026).

    ⭐ ЦІНА КЛАДЕТЬСЯ ПОРУЧ ІЗ РЕЗУЛЬТАТОМ, А НЕ В ОКРЕМИЙ КОШИК. Лічильник грошей
    не знає ні клієнта, ні задачі — і не мусить: якби він дописував їх собі у файл,
    це була б чергова копія однієї правди. Замість цього він питає, над чим
    платформа щойно працювала (контекст протоколу, який наповнили `audit`, Task
    Desk і CRM у цьому ж потоці), і кладе ціну до того самого прогону.

    ⚠ ЧЕСНА МЕЖА: якщо прикласти ціну НІ ДО ЧОГО (звичайна відповідь у чаті, де
    жодна система не запускалась), рядок НЕ пишеться — вигадувати сутність заради
    красивої суми ми не будемо. Повний рахунок грошей веде сам `costs`
    (`day_report`, `session`); протокол відповідає за ЗВʼЯЗОК, а не за касу.

    ⚠ Контекст чиститься тут же: інакше «поточна задача» протекла б у наступний
    прогін і журнал почав би приписувати роботу не тому клієнту."""
    try:
        import protocol
    except Exception:
        return
    try:
        usd = round(float((cur or {}).get("usd") or 0.0), 6)
        ctx = protocol.context()
        seen = protocol.runs_seen()
        anchor = ctx.get("run") or ctx.get("task") or ctx.get("party")
        if cur and usd > 0 and anchor:
            note = "викликів: %d" % int(cur.get("calls") or 0)
            if len(seen) > 1:
                # ⛒ Не даємо прочитати суму як ціну ОДНОГО прогону: крок роботи
                # запустив кілька систем, і ціна тут — за весь крок.
                note += "; ціна за крок цілком, прогонів у ньому: %d" % len(seen)
            protocol.write(protocol.A_MONEY_SPENT, anchor,
                           about=seen,
                           cost_usd=usd,
                           source=str(cur.get("channel") or ""),
                           note=note)
    except Exception:
        pass
    finally:
        try:
            # ⛒ 542: крок скінчився — забули КРОК, а не людину. Запит іще триває,
            # і те, що напишеться після прогону, мусить лишитись іменним.
            protocol.new_step()
        except Exception:
            pass


class run_scope:
    """⭐ ПАРА «ВІДКРИВ–ЗАКРИВ» ОДНІЄЮ РІЧЧЮ.

    Раніше це були два окремі рядки в різних кінцях функції — і саме тому в
    автоматизаціях забули перший. Тепер забути половину пари неможливо:

        with costs.run_scope("автоматизація", costs.KIND_AUTOMATION):
            ...

    Вкладення безпечне: якщо прогін уже відкритий, внутрішній `with` його НЕ
    перезаводить і НЕ закриває (інакше зовнішній лічильник обнулився б посеред
    роботи). Підсумок прогону доступний як `scope.result` після виходу."""

    def __init__(self, channel: str = "chat", kind: str = KIND_CHAT):
        self.channel = channel
        self.kind = kind
        self.result = {"in": 0, "out": 0, "usd": 0.0, "calls": 0}
        self._owner = False

    def __enter__(self):
        cur = getattr(_local, "run", None)
        # Прогін «без господаря» (його завів ensure_run) господаря отримує тут.
        if cur is None or not cur.get("owned"):
            start_run(self.channel, self.kind)
            self._owner = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if self._owner:
            self.result = end_run()
        return False    # виняток не ковтаємо: обрив за вартістю мусить бути видно


def ensure_run(channel: str = "?") -> bool:
    """СІТКА ПІД УСІМ: канал, який забули загорнути в run_scope, не лишається без
    лічильника й без стелі. Повертає True, якщо прогін довелося заводити самому.

    Чому не «впасти з помилкою»: fail-closed тут зупинив би живий канал у клієнта
    через мою недодивку. Тому безпечна поведінка — завести прогін із БАЗОВОЮ
    стелею і НАЗВАТИ канал у журналі, щоб недодивка була видна одразу. Ворота, які
    ловлять це до збірки, стоять окремо (`automation_cost_test`)."""
    cur = getattr(_local, "run", None)
    if cur is not None:
        if cur.get("owned"):
            return False
        # безгосподарний прогін не живе вічно — інакше він накопичував би витрати
        # в довгому потоці й зрештою заблокував би канал назавжди
        if (_now().timestamp() - float(cur.get("opened_at") or 0)) < ORPHAN_TTL_SEC:
            return False
    _local.run = {"in": 0, "out": 0, "usd": 0.0, "calls": 0,
                  "channel": str(channel or "?"), "kind": KIND_CHAT,
                  "owned": False, "opened_at": _now().timestamp()}
    import config
    _local.cap = float(getattr(config, "MAX_RUN_USD", 0.0) or 0.0)
    # Канал без лічильника — теж крок роботи: у протоколі він мусить назвати себе,
    # інакше «звідки береться робота» мовчатиме саме там, де ми недодивились.
    _open_protocol(channel, fresh=True)
    # Журнал сервера — це його stdout (`run_log.start("server")` у `server.main()`),
    # тому голос тут — звичайний print: рядок сам ляже в logs\server_*.log.
    try:
        print("[costs] КАНАЛ БЕЗ ЛІЧИЛЬНИКА: %s — заведено прогін зі стелею $%.2f"
              % (channel, _local.cap), flush=True)
    except Exception:
        pass
    return True


def current_kind() -> str:
    cur = getattr(_local, "run", None)
    return str((cur or {}).get("kind") or KIND_CHAT)


def set_run_cap(usd):
    """Стеля ЦЬОГО прогону в $ (0 = вимкнено). Ставить executor на початку прогону.

    ⭐ 28.07.2026. Раніше стеля жила ЛИШЕ в executor і перевірялась МІЖ кроками —
    тому один дорогий крок (фінальна збірка на дорогому мозку) вивіз прогін на
    $2.51 при стелі $1.00, і жодна перевірка не встигла спрацювати. Стеля мусить
    бути там, де ВИТРАЧАЮТЬСЯ гроші, тобто поруч із лічильником."""
    _local.cap = float(usd or 0.0)


def run_cap() -> float:
    return float(getattr(_local, "cap", 0.0) or 0.0)


def spent_usd() -> float:
    return float(current_run().get("usd", 0.0) or 0.0)


def over_hard_cap(factor=2.0) -> bool:
    """АВАРІЙНА межа: жоден окремий виклик не має права вивезти прогін далі, ніж
    удвічі за стелю. Це не заміна мʼякій зупинці (вона зупиняє НОВІ кроки), а
    останній запобіжник проти втечі вартості всередині одного кроку."""
    cap = run_cap()
    return cap > 0 and spent_usd() >= cap * factor


def current_run() -> dict:
    """Поточний (незавершений) прогін — для бюджетного запобіжника, БЕЗ скидання."""
    cur = getattr(_local, "run", None)
    return dict(cur) if cur else {"in": 0, "out": 0, "usd": 0.0, "calls": 0}


def session() -> dict:
    with _lock:
        return dict(_session)
