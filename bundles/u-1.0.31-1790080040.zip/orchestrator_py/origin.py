# -*- coding: utf-8 -*-
"""origin.py — ⛒ ПОХОДЖЕННЯ ДОКУМЕНТА (шар 4 захисту від тиражування,
13.09.2026).

⛒⛒⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ НАПЕРЕД: **ВІДБИТОК СТАВИТЬ КОЖЕН ПИСАР ОКРЕМО.**

Документи виходять із платформи шістьма різними виходами. Правило «не забудьте
поставити позначку» протримається рівно до сьомого виходу — і документ піде до
замовника без походження, МОВЧКИ. Саме так у цій платформі вже ламались сторож
547 і ворота цілісності 549. Тому тут один писар, а сторож
(`origin_test.py`, секція 7) червоніє на будь-якому збереженні, що його не
спитало: поставити відбиток неможливо забути.

НАВІЩО (рішення власника 13.09.2026, шар 4). Замовник другої угоди — корпорація
з власними науковцями. Проти інженера не тримає нічого «назавжди»; тримає те,
що походження документа доводиться за секунду. Це не технічний замок — це
доказ під авторське свідоцтво, яке вже є.

⛒ САМ КЛЮЧ ЛІЦЕНЗІЇ В ДОКУМЕНТ НЕ ЙДЕ. Ключ — секрет клієнта, а документ їде
далі, до третіх рук. Кладемо НЕЗВОРОТНИЙ слід ключа: його досить, щоб звірити
документ із виданою ліцензією, і замало, щоб нею скористатись.

⛒ ДЕ САМЕ ЛЕЖИТЬ. У штатному місці пакета OOXML — `docProps/custom.xml`,
тобто «додаткові властивості документа». Word, Excel і PowerPoint зберігають їх
при перезбереженні і не показують у тілі документа: замовникові воно не муляє,
а відкривається за секунду.

⛒ ЧЕСНА МЕЖА, ЯКУ ТРЕБА ЗНАТИ ВЛАСНИКОВІ. Це слід, а не замок. Свідоме
«Інспектування документа» в Word додаткові властивості вичищає. Проти
недбалого копіювання й проти питання «звідки це у вас» — працює; проти
інженера, який цілеспрямовано чистить метадані, — ні, і жодне інше місце в
пакеті тут не допоможе. Саме тому шар 4 у плані стоїть поруч із шарами 3 і 5,
а не замість них.
"""
import hashlib
import io
import re
import zipfile
from datetime import date
from pathlib import Path

import config

# Штатні імена пакета OOXML. Не наші вигадки — так їх пише сам Office.
_CUSTOM = "docProps/custom.xml"
_CT = "[Content_Types].xml"
_RELS = "_rels/.rels"
_CT_TYPE = ("application/vnd.openxmlformats-officedocument."
            "custom-properties+xml")
_REL_TYPE = ("http://schemas.openxmlformats.org/officeDocument/2006/"
             "relationships/custom-properties")
_FMTID = "{D5CDD505-2E9C-101B-9397-08002B2CF9AE}"

NAME = "SensFlow"
HOLDERS = (".docx", ".xlsx", ".pptx")

_XML = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
        '<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/'
        '2006/custom-properties" xmlns:vt="http://schemas.openxmlformats.org/'
        'officeDocument/2006/docPropsVTypes">'
        '<property fmtid="%s" pid="2" name="%s"><vt:lpwstr>%%s</vt:lpwstr>'
        '</property></Properties>' % (_FMTID, NAME))

TRIAL = "пробний період"


def _esc(s: str) -> str:
    return (str(s).replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;"))


def _trace(key: str) -> str:
    """Незворотний слід ключа: звірити можна, скористатись — ні."""
    if not key:
        return ""
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


def mark() -> str:
    """Мітка походження цієї збірки й цієї ліцензії.

    Порожньою не буває: документ без походження гірший за документ із чесним
    «пробний період»."""
    try:
        import license as _lic
        st = _lic.parse(config.LICENSE_KEY) if config.LICENSE_KEY else {}
    except Exception:
        st = {}
    customer = str(st.get("customer") or "").strip() or TRIAL
    edition = str(st.get("edition") or "").strip() or "-"
    return "|".join([NAME, customer, _trace(config.LICENSE_KEY or ""),
                     edition, str(config.APP_VERSION),
                     date.today().isoformat()])


def parse_mark(raw: str) -> dict:
    """Розібрати мітку назад. Порожньо — це не наша мітка."""
    parts = str(raw or "").split("|")
    if len(parts) != 6 or parts[0] != NAME:
        return {}
    return {"customer": parts[1], "trace": parts[2], "edition": parts[3],
            "version": parts[4], "date": parts[5], "raw": raw}


def holds(path) -> bool:
    """Чи тримає цей формат відбиток. ⛒ Кажемо прямо, а не мовчимо: .md, .csv
    і .html його не тримають, і власник мусить це знати, а не здогадуватись."""
    return Path(path).suffix.lower() in HOLDERS


def _sub_ct(ct: str) -> str:
    if _CUSTOM in ct:
        return ct
    tag = '<Override PartName="/%s" ContentType="%s"/>' % (_CUSTOM, _CT_TYPE)
    return ct.replace("</Types>", tag + "</Types>")


def _sub_rels(rels: str) -> str:
    if _CUSTOM in rels:
        return rels
    ids = [int(m) for m in re.findall(r'Id="rId(\d+)"', rels)] or [0]
    tag = ('<Relationship Id="rId%d" Type="%s" Target="/%s"/>'
           % (max(ids) + 100, _REL_TYPE, _CUSTOM))
    return rels.replace("</Relationships>", tag + "</Relationships>")


LAST_ERROR = ""


def _fail_reason(path, ex) -> str:
    """⛒ НЕВДАЧА НАЗИВАЄ СЕБЕ. Пишемо в журнал платформи і лишаємо останню
    причину доступною — щоб наступний прогін не був здогадом."""
    global LAST_ERROR
    LAST_ERROR = "%s: %s: %s" % (Path(path).name, type(ex).__name__, ex)
    try:
        import llm
        llm._log("[origin] відбиток не поставлено — %s" % LAST_ERROR)
    except Exception:
        import sys
        sys.stderr.write("[origin] відбиток не поставлено — %s\n" % LAST_ERROR)
    return LAST_ERROR


def stamp(path) -> bool:
    """Вшити походження в готовий документ. False — формат його не тримає.

    ⛒ Пишемо через тимчасовий файл і підміну: обірваний запис не сміє лишити
    замовникові понівечений документ замість цілого."""
    p = Path(path)
    if not holds(p) or not p.is_file():
        return False
    try:
        with zipfile.ZipFile(p) as z:
            names = z.namelist()
            if _CT not in names or _RELS not in names:
                return False
            items = [(i, z.read(i.filename)) for i in z.infolist()]
    except Exception:
        return False

    body = (_XML % _esc(mark())).encode("utf-8")
    # 🩸 13.09.2026, ДРУГИЙ ЖИВИЙ КЛІК ВЛАСНИКА. Тут стояв `tempfile.mkstemp`, і
    # він віддає ДВА значення — шлях і ВІДКРИТИЙ файловий дескриптор. Я брав
    # лише шлях, а дескриптор лишався відкритим назавжди. На Linux це нікому не
    # заважає, на Windows відкритий дескриптор ТРИМАЄ файл — і підміна
    # відбивається, скільки її не повторюй. Штамп не ставав, а писар мовчав.
    # ⛒ Лік не в тому, щоб «не забути закрити»: ми взагалі не заводимо ручки,
    # яку можна забути закрити. Пакет збирається В ПАМʼЯТІ, потім лягає в
    # сусідній файл звичайним записом (ручка закривається сама), і лише тоді
    # підміняється рідним писарем платформи.
    buf = io.BytesIO()
    tmp = p.with_name(p.name + ".sf_origin_tmp")
    try:
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as out:
            for info, data in items:
                n = info.filename
                if n == _CUSTOM:
                    continue                      # ⛒ старий відбиток не дублюємо
                if n == _CT:
                    data = _sub_ct(data.decode("utf-8")).encode("utf-8")
                elif n == _RELS:
                    data = _sub_rels(data.decode("utf-8")).encode("utf-8")
                out.writestr(info, data)
            out.writestr(_CUSTOM, body)
        with open(tmp, "wb") as fh:
            fh.write(buf.getvalue())
        # 🩸 13.09.2026, ЖИВИЙ КЛІК ВЛАСНИКА. Тут стояв `shutil.move`, і на
        # Linux він файл перезаписував, а на Windows — НІ: підміна наявного
        # файла відбивалась, штамп не ставав, і `stamp` чесно казав «не вдалося».
        # У дзеркалі (Linux) проба була зелена, у власника (Windows) — червона.
        # ⛒ КЛАС: підміна файла — це НЕ дія, яку кожен пише як уміє. У платформи
        # є ОДИН писар правди «як ми підміняємо файл» (`one_writer`), і він уже
        # лікує і різницю ОС, і терпіння до читача, який тримає файл відкритим
        # (антивірус, індексатор, сам Word). Ходимо до нього, а не вигадуємо.
        import one_writer
        one_writer.replace_with_patience(tmp, p)
        return True
    except Exception as ex:
        # 🩸 ТУТ ПИСАР МОВЧАВ. Виняток ковтався, `stamp` повертав False, і
        # причини не знав НІХТО — ні я, ні власник. Через це другий клік пішов
        # наосліп. ⛒ Мовчазна невдача — це окрема вада, а не дрібниця: вона
        # робить сліпим і того, хто лікує.
        _fail_reason(p, ex)
        try:
            if tmp.exists():
                tmp.unlink()
        except Exception:
            pass
        return False


def read(path) -> dict:
    """Походження документа. Порожньо — відбитка немає.

    ⛒ Нічого не вигадуємо: «немає» означає немає, а не «мабуть наш»."""
    p = Path(path)
    if not holds(p) or not p.is_file():
        return {}
    try:
        with zipfile.ZipFile(p) as z:
            if _CUSTOM not in z.namelist():
                return {}
            xml = z.read(_CUSTOM).decode("utf-8", "replace")
    except Exception:
        return {}
    m = re.search(r'name="%s"[^>]*>\s*<vt:lpwstr>(.*?)</vt:lpwstr>'
                  % re.escape(NAME), xml, re.S)
    if not m:
        return {}
    return parse_mark(m.group(1).replace("&amp;", "&").replace("&lt;", "<")
                      .replace("&gt;", ">"))
