# -*- coding: utf-8 -*-
"""ВОРОТА ОБІЦЯНКИ — запобіжник №4 (зміна 220).

⭐ Мета: обіцянка, яку клієнт прочитав у нашому документі, мусить мати чек, що
доводить її ДОРОГОЮ КЛІЄНТА. Обіцянка без чека в документ не потрапляє.

🩸 ВОРОТА СУДЯТЬ САМ ДОКУМЕНТ, ЩО ПОЇДЕ КЛІЄНТУ, а не його план і не наш намір:
на вхід іде той самий `.docx`, який ляже клієнтові в пошту. Перевіряти план
означало б перевіряти себе — а перевіряти треба артефакт.

🩸 ЧОГО ЦЕЙ МОДУЛЬ НЕ РОБИТЬ: не судить текст за словами. Ніяких переліків
«обіцяльних» слів («гарантуємо», «завжди», «автоматично») — це релейна шафа,
яка лікує сьогоднішню лексику й сліпа до завтрашньої. Судимо РЕЄСТР: кожен
абзац документа названий рукою, і сказано, чим він покритий.

Дві половини воріт (урок зміни 216):
  · абзац у документі, якого немає в реєстрі, або чия обіцянка не покрита → СТОП;
  · обіцянка, яку клієнт УЖЕ отримав, перестала проходити чек → СТОП,
    навіть якщо абзац прибрали з нової редакції. Прибрати абзац не скасовує
    обіцянки, що лежить у клієнта на столі.
"""

from __future__ import annotations

import html
import json
import re
import unicodedata
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
REGISTRY_PATH = HERE / "client_promises.json"

# Види записів у реєстрі.
KIND_PROMISE = "promise"   # твердження про те, що платформа вміє
KIND_NUMBER = "number"     # твердження, всередині якого стоїть ЧИСЛО
KIND_PROSE = "prose"       # заголовок / рамка / ввічливість — обіцянки немає

STATE_COVERED = "covered"
STATE_PENDING = "pending"


# ---------------------------------------------------------------- документ ---

def read_paragraphs(doc_path) -> list:
    """Абзаци документа так, як їх побачить клієнт.

    `.docx` читаємо без сторонніх бібліотек: це zip, усередині якого
    `word/document.xml`. Абзац у Word — це `<w:p>`, і абзаци всередині таблиць
    теж `<w:p>`, тому перелік систем із таблиці сюди потрапляє так само."""
    p = Path(doc_path)
    if p.suffix.lower() == ".docx":
        with zipfile.ZipFile(p) as z:
            xml = z.read("word/document.xml").decode("utf-8")
        xml = re.sub(r"</w:p>", "\n", xml)
        text = re.sub(r"<[^>]+>", "", xml)
        text = html.unescape(text)
    else:
        text = p.read_text(encoding="utf-8")
    return [ln.strip() for ln in text.split("\n") if ln.strip()]


def norm(s: str) -> str:
    """Зводимо абзац до вигляду, у якому його можна ПОРІВНЯТИ з якорем.

    ⚠ Навмисно НЕ зводимо різні слова до однакових: правка тексту обіцянки
    мусить розірвати збіг із якорем і зупинити ворота. Прибираємо лише те, що
    Word ставить сам і що людина не бачить: нерозривні пробіли, різні тире й
    лапки, подвійні пробіли."""
    s = unicodedata.normalize("NFKC", str(s))
    s = s.replace(" ", " ").replace("​", "")
    s = s.replace("‑", "-").replace("–", "-").replace("—", "-")
    s = s.replace("­", "")
    s = re.sub(r"[«»„“”\"']", "", s)
    s = re.sub(r"\s+", " ", s)
    return s.strip().lower()


# ------------------------------------------------------------------ реєстр ---

def load_registry(path=None) -> dict:
    """Реєстр обіцянок. Пишеться РУКОЮ і живе поруч із кодом.

    🩸 Урок зміни 217: паспорт, складений моделлю, — не місце для запобіжника.
    Тому машинне поле кладемо туди, що пишемо рукою, а не в прозу документа."""
    p = Path(path or REGISTRY_PATH)
    data = json.loads(p.read_text(encoding="utf-8"))
    return data


def registry_index(data: dict) -> dict:
    """Якір (нормалізований текст) → запис реєстру."""
    out = {}
    for item in data.get("promises", []):
        out[norm(item.get("text", ""))] = item
    return out


# ---------------------------------------------------- машинні числа ---------

def product_systems_count(build_root=None) -> int:
    """Скільки систем клієнт РЕАЛЬНО отримує.

    Якщо дали зібрану теку клієнта — рахуємо теки систем У НІЙ (це і є дорога
    клієнта). Якщо ні — беремо перелік продукту з писаря бандла: один писар на
    обидва шляхи, тому число не може розійтись саме з собою."""
    if build_root:
        d = Path(build_root) / "generated_systems"
        if d.is_dir():
            return len([x for x in d.iterdir() if x.is_dir()])
    import make_client_build
    return len(make_client_build.PRODUCT_SYSTEMS)


#: Джерела машинних чисел. Ключ називається в реєстрі полем `number_source`.
NUMBER_SOURCES = {
    "product_systems": product_systems_count,
}


def machine_number(source: str, build_root=None):
    fn = NUMBER_SOURCES.get(source)
    if fn is None:
        return None
    return fn(build_root)


def _numbers_in(text: str) -> set:
    return set(re.findall(r"\d+", text))


# ------------------------------------------------------------------ ворота ---

def judge(doc_path, registry=None, build_root=None, check_results=None) -> dict:
    """Присуд по документу, що поїде клієнту.

    `check_results` — {імʼя чека: True/False}, як їх повернув прогін ДОРОГОЮ
    КЛІЄНТА. Коли їх не дали, ворота не вдають, ніби чеки зелені: обіцянка,
    чек якої не проганявся, вважається НЕДОВЕДЕНОЮ."""
    data = registry if isinstance(registry, dict) else load_registry(registry)
    index = registry_index(data)
    results = dict(check_results or {})
    problems = []

    paragraphs = read_paragraphs(doc_path)
    seen = set()

    for raw in paragraphs:
        key = norm(raw)
        item = index.get(key)
        if item is None:
            problems.append({
                "rule": "abzats_poza_reyestrom",
                "text": raw,
                "why": "абзац документа не названий у реєстрі обіцянок — "
                       "ми не знаємо, чим він покритий",
            })
            continue
        seen.add(item.get("id"))
        kind = item.get("kind")
        if kind == KIND_PROSE:
            continue

        if item.get("state") != STATE_COVERED:
            problems.append({
                "rule": "obitsyanka_bez_cheka",
                "text": raw,
                "why": "обіцянка стоїть у реєстрі як «%s» — чека, що доводив би "
                       "її дорогою клієнта, немає" % item.get("state"),
            })
            continue

        check = item.get("check") or ""
        if not check:
            problems.append({
                "rule": "pokryta_bez_imeni_cheka",
                "text": raw,
                "why": "обіцянка названа покритою, але імені чека немає — "
                       "покриття без чека це слово, а не доказ",
            })
            continue

        if results.get(check) is not True:
            problems.append({
                "rule": "chek_ne_zelenyy",
                "text": raw,
                "why": "чек «%s» не дав зеленого присуду дорогою клієнта" % check,
            })
            continue

        if kind == KIND_NUMBER:
            source = item.get("number_source") or ""
            value = machine_number(source, build_root)
            if value is None:
                problems.append({
                    "rule": "chyslo_bez_dzherela",
                    "text": raw,
                    "why": "у тексті стоїть число, а машинного джерела для нього "
                           "немає — таке число зівʼяне мовчки",
                })
            elif str(value) not in _numbers_in(raw):
                problems.append({
                    "rule": "chyslo_zivyalo",
                    "text": raw,
                    "why": "машина каже %s, а в тексті цього числа немає" % value,
                })

    # ⭐ ДРУГА ПОЛОВИНА ВОРІТ. Обіцянку, що вже в клієнта на руках, не скасовує
    # ані прибраний абзац, ані нова редакція документа.
    for item in data.get("promises", []):
        if not item.get("shipped"):
            continue
        if item.get("kind") == KIND_PROSE:
            continue
        check = item.get("check") or ""
        if item.get("state") == STATE_COVERED and results.get(check) is True:
            continue
        problems.append({
            "rule": "vidana_obitsyanka_ne_trymayet",
            "text": item.get("text", ""),
            "why": "цю обіцянку клієнт УЖЕ отримав, а сьогодні вона не доведена "
                   "дорогою клієнта",
        })

    return {
        "ok": not problems,
        "problems": problems,
        "paragraphs": len(paragraphs),
        "known": len(seen),
        "doc": str(doc_path),
    }


def format_verdict(verdict: dict) -> str:
    lines = []
    if verdict["ok"]:
        lines.append("ВОРОТА ОБІЦЯНКИ: PASS — %d абзаців, усі покриті"
                     % verdict["paragraphs"])
        return "\n".join(lines)
    lines.append("ВОРОТА ОБІЦЯНКИ: STOP — %d причин на %d абзаців"
                 % (len(verdict["problems"]), verdict["paragraphs"]))
    for p in verdict["problems"]:
        head = p["text"][:90] + ("…" if len(p["text"]) > 90 else "")
        lines.append("  [%s] %s" % (p["rule"], head))
        lines.append("      %s" % p["why"])
    return "\n".join(lines)


if __name__ == "__main__":
    import sys
    doc = sys.argv[1] if len(sys.argv) > 1 else ""
    if not doc:
        print("вкажіть документ, що поїде клієнту")
        raise SystemExit(2)
    v = judge(doc)
    print(format_verdict(v))
    raise SystemExit(0 if v["ok"] else 1)
