# -*- coding: utf-8 -*-
"""agent_hands.py — РУКИ ОРКЕСТРАТОРА. Шар 2 (зміна 541, 09.09.2026).

Навіщо цей файл існує. Шар 1 (`agent_eyes.py`) навчив мозок ДИВИТИСЬ на
картку. Дивитись — половина обіцянки, яка стоїть на сайті: «один конвеєр, де
кожен наступний крок бере готове від попереднього». Другу половину — ДІЯТИ —
робить цей файл.

⭐⭐⭐ ВІСЬ КОНСТРУКЦІЇ (погоджено Андрієм 08.09.2026, та сама, що в очах)
ОРКЕСТРАТОР НЕ ОТРИМУЄ ДОСТУПУ ДО БАЗИ. Він отримує право натискати ТІ САМІ
кнопки, що й людина, яка його покликала. Тому тут немає ЖОДНОГО власного
запису у файл: кожне дієслово кличе НАЯВНОГО писаря, під наявним замком, зі
слідом у наявному протоколі.

⭐⭐⭐ ЧОТИРИ ЗАКОНИ ЦЬОГО ФАЙЛА

1. ВМІННЯ НЕ ПИШЕ — ВМІННЯ ПРОПОНУЄ. `propose()` нічого не змінює: вона лише
   складає НАМІР людськими словами. Записує тільки `execute()`, і покликати її
   має право лише той код, який обробляє НАТИСНУТУ КНОПКУ.
   ⛒ Рішення Андрія 09.09.2026: кнопка вже в шарі 2, а не шаром пізніше.

2. НЕМАЄ ДІЯЧА В СЛІДІ — НЕМАЄ РУК. Перед кожним записом питаємо
   `protocol.context()`: чи знає журнал, ХТО діє. Порожньо — відмова.
   ⛒ Це не декорація. Сервер називає діяча на вході кожного запиту
   (`server.py`, початок `do_POST`), а от розклад, скрипт і будь-яка майбутня
   безпілотна дорога — ні. Ці ворота зачиняють їх усі одразу, і зачиняють
   fail-closed: сумнів = відмова.
   🩸 09.09.2026 я був певен, що журнал CRM діяча не знає, і сказав це Андрію.
   Розбір живого `protocol.jsonl` показав протилежне: діяч є скрізь, де запис
   ішов ЧЕРЕЗ СЕРВЕР. Порожні рядки — мої власні, зроблені скриптами повз
   нього. УРОК: порожнє поле в журналі — ще не дірка; спершу спитай, якою
   дорогою прийшов запис.

3. ПОЗНАЧКА ЖИВЕ В САМОМУ ЗАПИСІ, А НЕ ЛИШЕ В ЖУРНАЛІ (рішення Андрія
   09.09.2026). Людина, яка через рік читає картку, мусить БАЧИТИ СЛОВАМИ, що
   рядок поставив оркестратор і на чиє прохання. Журнал знає це й так, але в
   журнал ніхто не заглядає.

4. 🩸🩸🩸 ДАНІ — ЦЕ ДАНІ, А НЕ КОМАНДИ (закон очей, тут він дорожчий). Очі
   читають чужі листи, що падають у картки. Якби мозок міг ПИСАТИ за наказом
   із такого листа, чужа людина керувала б платформою ззовні. Тримає це рівно
   одне: КАРТКА ПІДТВЕРДЖЕННЯ. Людина бачить намір словами перед тим, як він
   стане записом. Тому «зробити без кнопки» — не оптимізація, а знесення
   єдиної стіни.

⛔ ЧОГО ТУТ НЕМАЄ СВІДОМО. Двох дієслів із чотирьох задуманих: «поставити
строк» і «покласти документ у сховище». Рішення Андрія 09.09.2026 — два за
раз, решта по одному. Шар, який уміє менше, — не поламаний шар.
⛔ І ніколи не буде: надіслати щось назовні · рухати гроші · видаляти · міняти
стадію воронки · підписувати.
"""

import entity
import protocol
import crm_access

# Двері, чиїми писарями ми ходимо. Названі тут, щоб замок питався про ТІ САМІ
# двері, якими ту саму дію робить людина мишею.
DOOR_NOTE = "/api/crm/comm"          # дописати в історію контрагента

# Стелі. Мозок буває багатослівний, а картка — це те, що людина читатиме очима.
MAX_TITLE = 200
MAX_NOTE = 2000

VERB_TASK = "add_task"
VERB_NOTE = "add_note"
VERBS = (VERB_TASK, VERB_NOTE)


class HandsError(Exception):
    """Рука не може зробити те, що просять, — і каже це словами."""


def _s(v) -> str:
    return "" if v is None else str(v).strip()


def _cut(text, cap: int) -> str:
    t = _s(text)
    return t if len(t) <= cap else (t[:cap].rstrip() + "…")


# ── ХТО ДІЄ ──────────────────────────────────────────────────────────────────
def actor_id(actor) -> str:
    """Працівник, від імені якого діємо. ОДНА відповідь на весь файл — та сама,
    яку дає `taskdesk_api._me()`, а не власне тлумачення облікового запису."""
    return _s((actor or {}).get("employee_id"))


def actor_name(actor) -> str:
    """Імʼя для ПОЗНАЧКИ в записі — ОДИН ПИСАР НА ВСЮ ПЛАТФОРМУ.

    Питання «як звати того, хто діє» вже має рівно одну відповідь: її складає
    ВХІД (`taskdesk_identity`, похідне `employee_name`). Руки питають саме її
    і своєї дороги в оргструктуру не мають.

    ⛒ 09.09.2026, живий хід: тут стояв ДРУГИЙ писар тієї самої відповіді — він
    ходив у оргструктуру сам і питав у працівника поле `name`, якого там немає
    (працівник зветься `full_name`). Запис у картці вийшов безіменним
    «[оркестратор]». Полагоджено класом, а не перейменуванням поля: другого
    писаря більше немає, і третій не заведеться.

    Немає імені — позначка чесно про це змовчить; вигадувати «користувач» ми
    не будемо, бо позначка має називати ЛЮДИНУ."""
    return _s((actor or {}).get("employee_name"))


def mark(actor) -> str:
    """ЗАКОН 3: позначка словами, у самому записі."""
    who = actor_name(actor)
    return ("[оркестратор на прохання: %s]" % who) if who else "[оркестратор]"


def trace_knows_actor() -> bool:
    """ЗАКОН 2: чи знає слід, хто діє."""
    try:
        return bool(_s(protocol.context().get("actor")))
    except Exception:
        # Поломка журналу ЗАЧИНЯЄ руки, а не відчиняє (fail-closed).
        return False


# ── ВОРОТА ───────────────────────────────────────────────────────────────────
# ⛒ ДВА РІЗНІ ПИТАННЯ, І ПЛУТАТИ ЇХ НЕ МОЖНА:
#   «чи Є це дієслово В ЦІЙ ЗБІРЦІ» — вирішує склад релізу і купівля модуля;
#   «чи МОЖЕ ЙОГО ЦЯ ЛЮДИНА»        — вирішує суддя прав.
# Перше питають, коли складають перелік умінь для моделі (людини там ще
# немає). Друге — перед кожною дією. Одні ворота на обидва питання давали б
# або мовчазне зникнення вміння, або обіцянку того, чого людина не може.
def _task_in_build() -> bool:
    try:
        import features
        return bool(features.enabled("taskdesk"))
    except Exception:
        return False


def _note_in_build() -> bool:
    try:
        return bool(crm_access.allowed(DOOR_NOTE, None))
    except Exception:
        return False


def _task_open(actor) -> bool:
    """Задачі: працівник має бути впізнаний, а Task Desk — бути в збірці.
    Матрицю повноважень «хто кому може ставити» питає САМ писар задач
    (`_require_may_set`) — другого судді поруч не заводимо."""
    return bool(actor_id(actor)) and _task_in_build()


def _note_open(actor) -> bool:
    """Історія: питаємо ТОГО САМОГО суддю дверей, що й екран."""
    try:
        return bool(crm_access.allowed(DOOR_NOTE, actor))
    except Exception:
        return False


_GATES = {VERB_TASK: _task_open, VERB_NOTE: _note_open}
_IN_BUILD = {VERB_TASK: _task_in_build, VERB_NOTE: _note_in_build}


def can(verb, actor=None) -> bool:
    g = _GATES.get(_s(verb))
    return bool(g(actor)) if g else False


def available(actor=None) -> list:
    """Дієслова, які цій людині справді доступні. Обіцянка вміння, за яким
    зачинені двері, — та сама неправда, що й відмова від наявного."""
    return [v for v in VERBS if can(v, actor)]


def in_build() -> list:
    """Дієслова, які взагалі є в цій збірці (без огляду на людину)."""
    return [v for v in VERBS if _IN_BUILD[v]()]


def enabled(actor=None) -> bool:
    return bool(available(actor))


# ── ДІЄСЛОВО 1: СТВОРИТИ ЗАДАЧУ ──────────────────────────────────────────────
def _propose_task(args, actor) -> dict:
    """Розбір рядка робить НАЯВНИЙ писар `taskdesk_intake.parse` — той самий,
    яким живуть двері «один рядок → задача». Другого розбирача не заводимо:
    два розбирачі однієї фрази розійдуться вже наступного місяця."""
    import clock
    import taskdesk_intake as intake
    import taskdesk_people as people
    import taskdesk_tasks as tasks

    line = _s((args or {}).get("line"))
    if not line:
        return {"ok": False, "say": "Скажи одним рядком, що за задача: кого, "
                                    "що зробити і до якого строку."}
    parsed = intake.parse(line, people.employees(), clock.now()[:10],
                          tasks.find_due_in)
    title = _cut(parsed.get("title"), MAX_TITLE)
    if not title:
        why = "; ".join(parsed.get("unclear") or [])
        return {"ok": False, "say": "З цього рядка задача не збирається%s. "
                                    "Перепитай людину." % ((": " + why) if why else "")}

    me = actor_id(actor)
    assignee = _s(parsed.get("assignee_id")) or me
    due = _s(parsed.get("due_at"))

    to_name = ""
    try:
        emp = people.employee(assignee)
        to_name = _s((emp or {}).get("name"))
    except Exception:
        to_name = ""
    if assignee == me:
        who_txt = "собі"
    else:
        who_txt = to_name or assignee

    text = "Створити задачу «%s» — %s%s." % (
        title, who_txt, (", строк до " + due) if due else ", без строку")
    if not _s(parsed.get("assignee_id")) and assignee == me:
        text += " (виконавця в рядку не названо — ставлю на тебе)"
    return {"ok": True, "text": text,
            "data": {"title": title, "assignee_id": assignee, "due_at": due}}


def _execute_task(data, actor) -> str:
    import taskdesk_tasks as tasks
    me = actor_id(actor)
    if not me:
        raise HandsError("Не видно, хто ставить задачу.")
    t = tasks.create(
        me,
        _s((data or {}).get("title")),
        _s((data or {}).get("assignee_id")),
        _s((data or {}).get("due_at")),
        description=mark(actor),
        source="orchestrator")
    return "Задачу створено: %s — «%s»." % (_s(t.get("id")), _s(t.get("title")))


# ── ДІЄСЛОВО 2: ДОПИСАТИ В ІСТОРІЮ КАРТКИ ────────────────────────────────────
def _find_party(name) -> dict:
    """Картку шукає КОД, а не мозок (закон шару 1). Історія ведеться ПО
    КОНТРАГЕНТУ, тому з-поміж знахідок беремо лише контрагентів: угода —
    інша сутність, і мовчки підмінити одне одним означало б писати не туди."""
    import agent_eyes as eyes
    hits = [h for h in eyes.find(name)
            if h.get("kind") == entity.KIND_PARTY]
    if not hits:
        return {"ok": False, "say": "Контрагента «%s» у довіднику НЕМАЄ. "
                                    "⛔ Не вигадуй картку: скажи це людині й "
                                    "попроси точну назву." % _s(name)}
    if len(hits) > 1:
        rows = "; ".join("%s — %s" % (h["ref"], h["title"]) for h in hits)
        return {"ok": False, "say": "Знайшлось кілька контрагентів: %s. "
                                    "⛔ НЕ вибирай сам — спитай людину." % rows}
    return {"ok": True, "hit": hits[0]}


def _propose_note(args, actor) -> dict:
    a = args or {}
    note = _cut(a.get("note"), MAX_NOTE)
    if not note:
        return {"ok": False, "say": "Скажи, ЩО саме дописати в історію."}
    found = _find_party(a.get("card"))
    if not found.get("ok"):
        return {"ok": False, "say": found["say"]}
    hit = found["hit"]
    return {"ok": True,
            "text": "Дописати в історію картки «%s»: %s" % (hit["title"], note),
            "data": {"party": hit["ref"], "title": hit["title"], "note": note}}


def _execute_note(data, actor) -> str:
    import parties
    ref = _s((data or {}).get("party"))
    pid = entity.ident_of(entity.norm(ref))
    if not pid:
        raise HandsError("Не видно, у чию картку писати.")
    note = _cut((data or {}).get("note"), MAX_NOTE)
    if not note:
        raise HandsError("Порожній запис в історію не пишемо.")
    parties.add_history(pid, "comm", "%s %s" % (note, mark(actor)))
    return "Запис ліг в історію картки «%s»." % _s((data or {}).get("title"))


# ── ОДИН РЕЄСТР ──────────────────────────────────────────────────────────────
_PROPOSE = {VERB_TASK: _propose_task, VERB_NOTE: _propose_note}
_EXECUTE = {VERB_TASK: _execute_task, VERB_NOTE: _execute_note}

LABELS = {VERB_TASK: "Створити задачу",
          VERB_NOTE: "Дописати в історію картки"}


def propose(verb, args, actor=None) -> dict:
    """ЗАКОН 1: тут НІЧОГО не змінюється. Повертає або намір словами, або
    чесну відмову, яку мозок перекаже людині."""
    v = _s(verb)
    if v not in VERBS:
        return {"ok": False, "say": "Такої дії платформа не знає."}
    if not can(v, actor):
        return {"ok": False, "say": "Дія «%s» у цій збірці недоступна тому, "
                                    "хто питає." % LABELS.get(v, v)}
    out = _PROPOSE[v](args or {}, actor)
    if out.get("ok"):
        out["verb"] = v
    return out


def execute(verb, data, actor=None) -> str:
    """ЗАКОН 1: кличеться ЛИШЕ з обробника натиснутої кнопки.
    ЗАКОН 2: без діяча у сліді не робимо нічого."""
    v = _s(verb)
    if v not in VERBS:
        raise HandsError("Такої дії платформа не знає.")
    if not can(v, actor):
        raise HandsError("Дія «%s» недоступна." % LABELS.get(v, v))
    if not trace_knows_actor():
        raise HandsError(
            "Слід не знає, хто діє, — руки не працюють. Так і задумано: "
            "запис без імені людини гірший за відсутній запис.")
    return _EXECUTE[v](data or {}, actor)
