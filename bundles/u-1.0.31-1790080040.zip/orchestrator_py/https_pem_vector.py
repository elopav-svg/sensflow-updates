# -*- coding: utf-8 -*-
"""https_pem_vector.py — ЕТАЛОН ДЛЯ ПЕРЕКЛАДАЧА ЧИСЕЛ У PEM (19.09.2026).

⛒ ЩО ЦЕ. Перевірка «наш перекладач чисел дає те саме, що openssl» залежала від
того, чи стоїть openssl НА ЦІЙ МАШИНІ. На машині власника його немає, і чек
чесно казав «не перевірено» — тобто був ПОСТІЙНО ЧЕРВОНИЙ. Перевірка, якої
не можна провести, доказом не є (урок 609).

⛒ ЛІК КЛАСУ: еталон приносимо з собою. Нижче — ключ, ЗГЕНЕРОВАНИЙ САМЕ ДЛЯ
ЦІЄЇ ПЕРЕВІРКИ 19.09.2026 разом із його PEM від справжнього openssl 3.0.2.
Тепер порівняння робиться скрізь і без жодної сторонньої програми.

🩸 ЦЕ НЕ СЕКРЕТ І НЕ КЛЮЧ ПЛАТФОРМИ. Одноразовий 1024-бітний ключ, створений у
тимчасовій теці й нікуди більше не застосований: ні сервер, ні офіс, ні клієнт
його не знають. Замінювати його не треба; якщо колись знадобиться новий —
згенерувати `openssl genrsa -traditional 1024` і перезняти обидва поля разом.
"""

# Дев'ять чисел ключа у base64 — рівно в тому порядку, як їх читає перекладач.
NUMS = {
    "ver": "AA==",
    "n": "AL6lrvn7EfQHJVtWTdbK0/pw1SO5IoIIp8tqG4riUeC6L9X/mx4gAhjpa3uOiPv3m2mmr+dgajz4OYueyiFnx/oGGntY2JBOneXuMi3QllT7n7c6Tp/9pMQX5KTYbrUJe14ocIgur7rnhT7DDfW5dTfMAtUU6fKHcYo1qnBJKJnv",
    "e": "AQAB",
    "d": "L9doB3dH1BMO/tKzidkwRMKX2fUVgcgmQ1eHPdz5awmOA4e3J2Ik5Jd+z2y/V2uVZnfb4JZDUrV/y1e3pZZjih2pNBzOc2is7kRUlxJZWm+F+yyHbedgfI7BpFTlqHOHoMdIluD1qyR5plXNN4DMkggoKss7M9puMrKN2QwdywE=",
    "p": "ANzzqR2A7q/iunJBnSgxqQ0rGyEhjNLeqQ0gxEGsVmofYXtsfmTOYsJww1tX5bPLq5Qof4vJlcFtZpLRU4Rlgq8=",
    "q": "ANzjbG3sYKkntpApi9lLmRU1ZosEYNxIlOe9AuNgMFdxVsIaI7qOAHlvl+ZNOF6DLhAn/n/ZXTcObSidWENFLME=",
    "dp": "AINdCorUARTpQ9hyUjF3dP6zRinofIVShEed15EEGUx248oxsuPUILtht4QzOgovaQ9pFIvTigm6NWXMtk7c21k=",
    "dq": "WbGvseMuTQHnTBrSwuXDv6zzerfIbSq77G3/4jyI5LkNNbxPjc1ju+vojogEv7wc1EqpOVkWVOjywm9CC+7nAQ==",
    "iq": "Lq13vJdiR1t6I4n+fZtOtGzkTHbTu7YFNM3ih+0CTze8iUs7dgBvLMUL+ERokw0WahfxMgZVOrpaVkObyVbEYw=="
}

# Те, що на цих числах друкує openssl 3.0.2 (`rsa -traditional`), дослівно.
PEM = '-----BEGIN RSA PRIVATE KEY-----\nMIICXAIBAAKBgQC+pa75+xH0ByVbVk3WytP6cNUjuSKCCKfLahuK4lHgui/V/5se\nIAIY6Wt7joj795tppq/nYGo8+DmLnsohZ8f6Bhp7WNiQTp3l7jIt0JZU+5+3Ok6f\n/aTEF+Sk2G61CXteKHCILq+654U+ww31uXU3zALVFOnyh3GKNapwSSiZ7wIDAQAB\nAoGAL9doB3dH1BMO/tKzidkwRMKX2fUVgcgmQ1eHPdz5awmOA4e3J2Ik5Jd+z2y/\nV2uVZnfb4JZDUrV/y1e3pZZjih2pNBzOc2is7kRUlxJZWm+F+yyHbedgfI7BpFTl\nqHOHoMdIluD1qyR5plXNN4DMkggoKss7M9puMrKN2QwdywECQQDc86kdgO6v4rpy\nQZ0oMakNKxshIYzS3qkNIMRBrFZqH2F7bH5kzmLCcMNbV+Wzy6uUKH+LyZXBbWaS\n0VOEZYKvAkEA3ONsbexgqSe2kCmL2UuZFTVmiwRg3EiU570C42AwV3FWwhojuo4A\neW+X5k04XoMuECf+f9ldNw5tKJ1YQ0UswQJBAINdCorUARTpQ9hyUjF3dP6zRino\nfIVShEed15EEGUx248oxsuPUILtht4QzOgovaQ9pFIvTigm6NWXMtk7c21kCQFmx\nr7HjLk0B50wa0sLlw7+s83q3yG0qu+xt/+I8iOS5DTW8T43NY7vr6I6IBL+8HNRK\nqTlZFlTo8sJvQgvu5wECQC6td7yXYkdbeiOJ/n2bTrRs5Ex207u2BTTN4oftAk83\nvIlLO3YAbyzFC/hEaJMNFmoX8TIGVTq6WlZDm8lWxGM=\n-----END RSA PRIVATE KEY-----\n'
