# -*- coding: utf-8 -*-
"""ЧЕКИ ДОРОГОЮ КЛІЄНТА — запобіжник №4 (зміна 220).

🩸 Тут доводяться обіцянки з клієнтського документа. Правило одне і жорстке:
чек бачить ЛИШЕ зібрану теку клієнта. Не нашу теку, не наш реєстр, не наші
налаштування.

Чому так, а не «домовились дивитись у бандл». 24.08.2026 у Каспера не поїхала
місячна робота, а 42 чеки пакета були зелені: вони починались ПІСЛЯ розвилки і
підпирались нашим деревом. Домовленість не втримала. Тому тут стоїть КЛІТКА НА
ШЛЯХИ: аудит-гак Python не дає жодному чеку прочитати файл із нашої теки.
Чек, який зазирнув додому, не «трохи схитрував» — він падає.

Три умови дороги клієнта:
  · його тека   — клітка нижче;
  · його машина — присуд виносить `_CHECK PROMISES.bat` на Windows Андрія;
  · порожній стан — `precondition_empty_state`: якщо в теці клієнта їде наш
    живий стан, недовіра поширюється на ВСІ чеки, тому вони червоніють гуртом.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

PLATFORM_ROOT = Path(__file__).resolve().parent.parent


class JailBreak(RuntimeError):
    """Чек спробував прочитати щось поза текою клієнта."""


def install_jail(build_root, our_root=None):
    """Клітка на шляхи. Ставиться ПІСЛЯ імпортів і вже не знімається.

    Забороняємо ЧИТАННЯ й перелік вмісту в нашій теці. Запис лишаємо: журнал
    прогону пишеться в наші логи, і це не спосіб підперти чек."""
    br = os.path.realpath(str(build_root))
    orr = os.path.realpath(str(our_root or PLATFORM_ROOT))

    def _outside(p) -> bool:
        if not isinstance(p, (str, bytes, os.PathLike)):
            return False
        try:
            rp = os.path.realpath(os.fspath(p))
        except Exception:
            return False
        if rp == br or rp.startswith(br + os.sep):
            return False          # тека клієнта — можна
        return rp == orr or rp.startswith(orr + os.sep)   # наша тека — не можна

    def hook(event, args):
        if event == "open":
            path, mode = args[0], (args[1] or "")
            if any(c in str(mode) for c in "wax+"):
                return
            if _outside(path):
                raise JailBreak("чек зазирнув у нашу теку: %s" % path)
        elif event in ("os.listdir", "os.scandir"):
            if args and _outside(args[0]):
                raise JailBreak("чек перелічує нашу теку: %s" % args[0])

    sys.addaudithook(hook)


# ------------------------------------------------------- умова дороги --------

#: Що не сміє їхати в теці клієнта. Судимо ФОРМУ імені, а не перелік файлів.
OUR_TOOL_MARKS = ("_test.py", "_probe.py", "selfcheck", "_OUT.txt")
#: Теки, у яких осідає ПРАЦЯ: у клієнта вони мусять бути порожні.
MUST_BE_EMPTY = ("orchestrator_py/runs", "orchestrator_py/logs",
                 "orchestrator_py/projects", "output")

# ⚠ `.sf_state.json` СЮДИ НЕ ВХОДИТЬ, і це не недогляд. Це паспорт системи
# (назва, стан, тригери, ролі), і він їде клієнту СВІДОМО — так вирішено
# 07.08.2026 у `SYSTEM_ROOT_NAMES`. Ворота не сміють оголошувати свідоме
# рішення дефектом. Те, що цей паспорт переписується під час роботи й може
# розійтися з реєстром, — окремий борг, і лікувати його треба звіркою з
# реєстром, а не забороною возити паспорт.


def precondition_empty_state(build_root) -> tuple:
    """Порожній стан. Клієнт відкриває платформу з нуля, а не з нашої праці."""
    root = Path(build_root)
    bad = []
    for p in root.rglob("*"):
        if p.is_file() and any(m in p.name for m in OUR_TOOL_MARKS):
            bad.append(str(p.relative_to(root)) + " — наш інструмент")
    for rel in MUST_BE_EMPTY:
        d = root / rel
        if d.is_dir() and any(d.iterdir()):
            bad.append(rel + " — не порожня, у клієнта там має бути чисто")
    return (not bad), bad


# ------------------------------------------------------------- чеки ---------

def _systems(build_root) -> set:
    d = Path(build_root) / "generated_systems"
    if not d.is_dir():
        return set()
    return {x.name for x in d.iterdir() if x.is_dir()}


def _need(build_root, ids) -> tuple:
    have = _systems(build_root)
    missing = sorted(set(ids) - have)
    return (not missing), ["немає системи: " + m for m in missing]


def promise_systems_count(build_root, expect=None) -> tuple:
    """p013 — «у типовий набір входить N систем». Рахуємо в ТЕЦІ КЛІЄНТА."""
    have = _systems(build_root)
    if expect is None:
        return bool(have), ([] if have else ["у теці клієнта немає жодної системи"])
    ok = len(have) == int(expect)
    return ok, ([] if ok else ["у продукті %s систем, у теці клієнта %d"
                               % (expect, len(have))])


def promise_systems_finance(build_root, expect=None) -> tuple:
    """p017 — стратегія і фінанси."""
    return _need(build_root, [
        "biznes_analityka_audyt_i_optymizatsiya_protsesiv",
        "excel_financial_modeling", "diy_operations_excel", "founder_dashboard"])


def promise_systems_legal(build_root, expect=None) -> tuple:
    """p019 — юрист-асистент ІЗ БІБЛІОТЕКОЮ ШАБЛОНІВ і генератор інструкцій.

    Бібліотека шаблонів — теж обіцянка, тому перевіряємо, що тека шаблонів у
    клієнта не порожня, а не лише що система на місці."""
    ok, bad = _need(build_root, ["legal_assistant", "instructions_profiles_duties"])
    if ok:
        tpl = Path(build_root) / "generated_systems" / "legal_assistant" / "Database" / "Templates"
        if not tpl.is_dir() or not any(tpl.iterdir()):
            ok, bad = False, ["бібліотека шаблонів договорів у клієнта порожня"]
    return ok, bad


def promise_systems_marketing(build_root, expect=None) -> tuple:
    """p021 — маркетинг і продажі."""
    return _need(build_root, [
        "copywriter", "marketing_content", "seo_geo_strateg", "marketing_dashboard",
        "konkurentnyy_heartbeat_monitorynh_i_zvitnist"])


def promise_systems_hr(build_root, expect=None) -> tuple:
    """p023 — персонал."""
    return _need(build_root, ["recruiting", "hr_dashboard_analytics"])


def promise_systems_operations(build_root, expect=None) -> tuple:
    """p025 — операції."""
    return _need(build_root, ["software_development", "product_search",
                              "route_object_search"])


#: Реєстр чеків. Імена збігаються з полем `check` у `client_promises.json`.
CHECKS = {
    "promise_systems_count": promise_systems_count,
    "promise_systems_finance": promise_systems_finance,
    "promise_systems_legal": promise_systems_legal,
    "promise_systems_marketing": promise_systems_marketing,
    "promise_systems_hr": promise_systems_hr,
    "promise_systems_operations": promise_systems_operations,
}


def run(build_root, expect_systems=None, jail=True, our_root=None) -> dict:
    """Прогін усіх чеків дорогою клієнта.

    ⚠ `expect_systems` рахується ЗЗОВНІ клітки (це наше число з писаря бандла) і
    передається сюди значенням — інакше чек мусив би читати нашу теку."""
    build_root = Path(build_root)
    if jail:
        install_jail(build_root, our_root)

    ok_state, state_bad = precondition_empty_state(build_root)
    results, details = {}, {}
    for name, fn in CHECKS.items():
        if not ok_state:
            results[name] = False
            details[name] = ["порожній стан не доведено — чекам вірити не можна"]
            continue
        try:
            ok, bad = fn(build_root, expect_systems)
        except JailBreak as e:
            ok, bad = False, ["КЛІТКА: " + str(e)]
        except Exception as e:
            ok, bad = False, ["чек упав: %s: %s" % (type(e).__name__, e)]
        results[name] = bool(ok)
        details[name] = bad
    return {
        "build_root": str(build_root),
        "empty_state": ok_state,
        "empty_state_bad": state_bad,
        "results": results,
        "details": details,
        "ok": ok_state and all(results.values()),
    }


def format_run(r: dict) -> str:
    lines = ["ЧЕКИ ДОРОГОЮ КЛІЄНТА: %s" % r["build_root"]]
    if r["empty_state"]:
        lines.append("  PASS  порожній стан: у теці клієнта немає нашого сліду")
    else:
        lines.append("  STOP  порожній стан НЕ доведено:")
        for b in r["empty_state_bad"][:12]:
            lines.append("        " + b)
        if len(r["empty_state_bad"]) > 12:
            lines.append("        ... ще %d" % (len(r["empty_state_bad"]) - 12))
    for name, ok in r["results"].items():
        lines.append("  %s  %s" % ("PASS" if ok else "STOP", name))
        for b in r["details"].get(name, [])[:4]:
            lines.append("        " + b)
    return "\n".join(lines)


# ⭐ ОКРЕМИЙ ПРОЦЕС — І ЦЕ НЕ ДРІБНИЦЯ. Клітка ставиться назавжди в тому процесі,
# де стала. Тому чеки живуть у СВОЄМУ процесі: ворота, яким треба прочитати наш
# документ, лишаються зовні й у клітку не потрапляють. Інакше довелося б робити
# для воріт виняток — а виняток у клітці означає, що клітки немає.
if __name__ == "__main__":
    import argparse
    import json as _json

    ap = argparse.ArgumentParser(description="Чеки дорогою клієнта")
    ap.add_argument("build_root")
    ap.add_argument("--expect-systems", type=int, default=None)
    ap.add_argument("--our-root", default="")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args()
    res = run(a.build_root, a.expect_systems, jail=True,
              our_root=(a.our_root or None))
    print(_json.dumps(res, ensure_ascii=False) if a.json else format_run(res))
    sys.exit(0 if res["ok"] else 1)
