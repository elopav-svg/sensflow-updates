# -*- coding: utf-8 -*-
"""
tender_watch_run.py — ЖИВИЙ ОБХІД СТОРОЖА З РЕАЛЬНОЮ ВІДПРАВКОЮ.

На відміну від tender_watch_probe.py (який нічого не шле), цей запуск робить
те саме, що робитиме сторож щодня: знаходить, відсіює вже надіслане, збирає
текст через ворота й НАДСИЛАЄ його в Telegram власнику.

Потрібен інтернет і налаштований TELEGRAM_BOT_TOKEN — ганяти на машині Андрія.
Запуск: python tender_watch_run.py  (або Run tender watch LIVE.bat)
"""
import sys

import tender_watch as TW


def main():
    print("=" * 72)
    print("ZHYVYY OBKHID STOROZHA (z realnoyu vidpravkoyu v Telegram)")
    print("=" * 72)
    sys.stdout.flush()

    try:
        import telegram_access
        owners = telegram_access.owner_ids()
    except Exception:
        owners = []
    print("  adresaty (vlasnyk): %s" % (owners or "NEMAYE - perevirte TELEGRAM_ALLOWED_CHAT_IDS"))
    print("  vzhe nadsylalos ranishe: %d tenderiv" % len(TW.already_sent()))
    print()
    sys.stdout.flush()

    r = TW.run()

    s = r["summary"]
    if s:
        print("  ZNAYDENO: unikalnyh %s | dubliv prybrano %s | vidsiyano %s"
              % (s.get("unique"), s.get("duplicates"), s.get("dropped")))
        if not s.get("complete", True):
            print("  UVAHA: obkhid NEPOVNYY - chastyna dzherela ne vidpovila.")
    print("  NOVYH (shche ne nadsylalys): %d" % len(r["new"]))
    print("  STATUS: %s" % r["status"])
    if r["reason"]:
        print("  %s" % r["reason"])
    print()
    sys.stdout.flush()

    if r["text"]:
        print("=" * 72)
        print("TEKST, YAKYY PISHOV U TELEGRAM:")
        print("=" * 72)
        print(r["text"])
        print("=" * 72)

    d = r.get("delivery") or {}
    if d:
        # ⛒ 626а: той самий писар, що й на екрані клієнта. Двох правд про
        # доставку в продукті немає.
        try:
            import delivery_report as _dr
            print("  DOSTAVKA: " + (_dr.render(d) or "-"))
        except Exception:
            print("  DOSTAVKA: dishlo -> %s | ne dishlo -> %s"
                  % (d.get("sent_to"), d.get("failed") or "-"))

    if r["status"] == "sent":
        print("REZULTAT: nadislano. Perevirte Telegram - povidomlennya vzhe tam.")
        return 0
    if r["status"] in ("nothing_new", "nothing_open"):
        print("REZULTAT: nadsylaty nichoho - i tse CHESNA vidpovid, a ne zbiy.")
        return 0
    print("REZULTAT: NE nadislano. Prychyna vyshche.")
    return 1


if __name__ == "__main__":
    import run_log; run_log.start('tender_watch_run')  # вивід прогону лягає у logs\ — читаю сам, без скрінів
    sys.exit(main())
