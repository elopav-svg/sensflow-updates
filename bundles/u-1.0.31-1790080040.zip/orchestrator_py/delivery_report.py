# -*- coding: utf-8 -*-
"""delivery_report.py — ОДИН ПИСАР ПРАВДИ ПРО ДОСТАВКУ (626а, 22.09.2026).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ. Робота, що надсилає щось людям, звітувала словом
«надіслано». Кому саме дійшло — знав відправник, кому не дійшло і чому — знав
телеграм, а до екрана доїжджало одне слово. 22.09.2026 у ТОВ «КАСПЕР УКРАЇНА»
сторож тендерів сказав `sent`, а з трьох адресатів лист отримав один.

⭐ РІШЕННЯ. Правду про доставку складає ОДИН писар — цей файл, — і вкладає її
в запис прогону ДОШКА ЗАДАЧ (`scheduler._run_one`), а не кожна робота власноруч.
Робота лише віддає факт (`delivery`), як його бачив відправник. Тому робота,
дописана завтра, дістає поіменний звіт безкоштовно, а забути про нього нікому:
забувати ніде.

⛒ ІМʼЯ, А НЕ НОМЕР. Номер чату (`508423675`) людині не каже нічого. Тому
адресат називається так, як його знає компанія: імʼя працівника з картки, якщо
чат привʼязаний; підпис зі списку доступу, якщо ні; і лише тоді сам номер.
Номер лишається В ДУЖКАХ завжди — саме за ним адміністратор шукає чат.

⛒ FAIL-OPEN НА ІМЕНАХ, FAIL-CLOSED НА ФАКТІ. Поломка довідника імен не має
права зʼїсти звіт: тоді адресат називається номером. А от факту доставки писар
не вигадує ніколи — немає факту, немає рядка.
"""


def _sid(v) -> str:
    return ("" if v is None else str(v)).strip()


def who(chat_id) -> str:
    """Як звати того, хто сидить у цьому чаті. -> «Прізвище (номер)» або «(номер)»."""
    cid = _sid(chat_id)
    if not cid:
        return ""
    name = ""
    try:
        import taskdesk_identity as _id
        acc = _id.account_by_telegram(cid)
        if acc:
            name = _sid(acc.get("employee_name")) or _sid(acc.get("login"))
    except Exception:
        name = ""
    if not name:
        try:
            import telegram_access as _ta
            for a in (_ta.snapshot().get("allowed") or []):
                if _sid(a.get("id")) == cid:
                    name = _sid(a.get("label"))
                    break
        except Exception:
            name = ""
    return ("%s (%s)" % (name, cid)) if name else cid


def _reason_for(delivery, cid) -> str:
    reasons = (delivery or {}).get("reasons") or {}
    if isinstance(reasons, dict):
        for k, v in reasons.items():
            if _sid(k) == _sid(cid) and _sid(v):
                return _sid(v)
    return _sid((delivery or {}).get("reason")) or "причину телеграм не назвав"


def render(delivery) -> str:
    """Правда про доставку людськими словами. Немає доставки — немає рядка."""
    if not isinstance(delivery, dict):
        return ""
    sent = list(delivery.get("sent_to") or [])
    failed = list(delivery.get("failed") or [])
    if not sent and not failed:
        # Робота нічого не розсилала (або розсилати не було кому) — і тоді
        # причина, якщо вона названа, і є весь звіт.
        why = _sid(delivery.get("reason"))
        return ("Доставка: %s" % why) if why else ""
    parts = []
    if sent:
        parts.append("Дійшло: " + ", ".join(who(c) for c in sent) + ".")
    else:
        parts.append("Не дійшло НІКОМУ.")
    if failed:
        parts.append("НЕ дійшло: "
                     + "; ".join("%s — %s" % (who(c), _reason_for(delivery, c))
                                 for c in failed) + ".")
    return " ".join(parts)


def append_to(summary, delivery) -> str:
    """Підсумок роботи + правда про доставку. Один шов на всю платформу."""
    said = _sid(summary)
    line = render(delivery)
    if not line:
        return said
    return (said + " " + line).strip() if said else line
