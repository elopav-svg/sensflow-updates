# -*- coding: utf-8 -*-
"""
tender_watch.py — ОБХІД СТОРОЖА (27.07.2026).

Один обхід = профіль продукції -> пошук у Прозоро -> зведення без дублів
-> ПАМ'ЯТЬ (лишити тільки нове) -> ворота складача -> відправка людині.

ЧОМУ ПАМ'ЯТЬ ТУТ, А НЕ У ВІДПРАВНИКА.
    Без пам'яті сторож щодня слав би той самий список. Після другого такого
    сповіщення людина перестає їх читати — і тоді пропускає САМЕ те, заради
    чого все будувалось. Пам'ять живе в обході, бо і сторож, і майбутній
    розвідник, і ручний запуск мають користуватись однією.

ЧОМУ ПОЗНАЧКА «НАДІСЛАНО» СТАВИТЬСЯ ЛИШЕ ПІСЛЯ УСПІШНОЇ ВІДПРАВКИ.
    Якщо позначити наперед, а відправка впаде (немає мережі, збій токена) —
    тендер зникне назавжди: удруге його вже не покажуть, а людина його не
    бачила. Тому спершу факт відправки, тоді запис.

НІЧОГО НЕ ВИГАДУЄ: текст народжується виключно в tender_message.build(),
який звіряє кожен факт із Прозоро й ставить печатку для вартового на виході.
"""
import json
import sys
import time
from datetime import datetime
from pathlib import Path

import tender_profile as TP
import tender_source_ua as TS
import tender_message as TM
import one_writer

try:
    import config
    # ⭐⭐⭐ 01.09.2026. ПИСАР ІДЕ ЗА ПЕРЕМИКАЧЕМ СТАНУ, А НЕ ЗА ТЕКОЮ РУШІЯ.
    # У бою `STATE_DIR == ENGINE_DIR`, тож шлях не змінюється ні на байт.
    _DIR = Path(config.STATE_DIR)
except Exception:
    _DIR = Path(__file__).resolve().parent

_STATE = _DIR / "tender_watch_state.json"
FORGET_AFTER_DAYS = 120        # старі записи не тримаємо вічно
TITLE = "Тендери під вашу продукцію"


# ── пам'ять сторожа ────────────────────────────────────────────────────────
def _load_state() -> dict:
    try:
        d = one_writer.read_json(_STATE)
        if isinstance(d, dict) and isinstance(d.get("sent"), dict):
            return d
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        pass
    return {"sent": {}, "last_run_at": None, "runs": []}


def _save_state(st: dict):
    try:
        cutoff = time.time() - FORGET_AFTER_DAYS * 86400
        st["sent"] = {k: v for k, v in (st.get("sent") or {}).items()
                      if float((v or {}).get("at", 0)) >= cutoff}
        st["runs"] = (st.get("runs") or [])[-30:]
        _STATE.parent.mkdir(parents=True, exist_ok=True)
        one_writer.write_json(_STATE, st)
    except Exception as e:
        sys.stderr.write("[watch] state save: %s\n" % e)


def already_sent(state=None) -> set:
    st = state if state is not None else _load_state()
    return set((st.get("sent") or {}).keys())


def forget_all():
    """Тільки для тестів / свідомого скидання пам'яті."""
    _save_state({"sent": {}, "last_run_at": None, "runs": []})


def forget_last_run() -> dict:
    """⭐⭐⭐ 626г (22.09.2026). ЗАБУТИ ПОЗНАЧКУ «НАДІСЛАНО» З ОСТАННЬОЇ РОЗСИЛКИ.

    🩸 ЖИВИЙ ВИПАДОК. У клієнта лист дійшов одному адресату з трьох. Перевірити
    виправлення не було як: сторож те саме вдруге не шле, а стерти позначку з
    консолі неможливо — `forget_all` є в коді, дверей немає. Лишалось чекати
    НОВОГО тендера, щоб дізнатись, чи працює доставка.

    ⛒ ЧОМУ САМЕ ОСТАННЯ РОЗСИЛКА, А НЕ ВСЯ ПАМʼЯТЬ. Скинути все означало б
    завтра вранці надіслати людям десятки давно бачених торгів — і після
    такого листа їх перестають читати взагалі. Забуваємо рівно те, що пішло
    останнім разом, і кажемо, ЩО саме забули.

    -> {ok, forgot, message}"""
    st = _load_state()
    last = None
    for r in reversed(st.get("runs") or []):
        if r.get("ids"):
            last = r
            break
    if not last:
        return {"ok": False, "forgot": [],
                "message": "Немає чого надсилати ще раз: остання розсилка "
                           "порожня або відбулась до цього оновлення."}
    sent = dict(st.get("sent") or {})
    gone = [t for t in (last.get("ids") or []) if t in sent]
    if not gone:
        return {"ok": False, "forgot": [],
                "message": "Позначки останньої розсилки вже немає — надіслати "
                           "ще раз можна буде після наступного прогону."}
    for t in gone:
        sent.pop(t, None)
    st["sent"] = sent
    _save_state(st)
    return {"ok": True, "forgot": gone,
            "message": "Забуто позначку «надіслано» для %d тендер(ів) останньої "
                       "розсилки — наступний прогін надішле їх ще раз." % len(gone)}


# ── відправка ──────────────────────────────────────────────────────────────
def _recipients(chat_ids=None) -> list:
    if chat_ids:
        return list(chat_ids)
    try:
        import telegram_access
        # ⛒ 623в: ОДИН писар адресатів — той самий, що пускає бот.
        return list(telegram_access.digest_ids())
    except Exception:
        return []


def _deliver(text, chat_ids) -> dict:
    """Віддає текст у Telegram. Повертає, кому дійшло, кому ні — і ЧОМУ.

    ⛒⛒⛒ 626а (22.09.2026). Доти тут стояло «так/ні» на кожного адресата, і
    причина недоставки гинула у відправника. 🩸 22.09.2026 у ТОВ «КАСПЕР
    УКРАЇНА» двоє з трьох не отримали листа, бо запускали бота задач, а не
    основного, — і цього не сказав ніхто. Тепер причина їде поруч з адресатом:
    `reasons[chat_id]`."""
    try:
        import telegram_bot
    except Exception as e:
        return {"ok": False, "sent_to": [], "failed": [], "reasons": {},
                "reason": "telegram_bot: %s" % e}
    if not telegram_bot.ready():
        _why = "Telegram-бот не налаштований (немає токена)."
        return {"ok": False, "sent_to": [], "failed": list(chat_ids),
                "reasons": {str(c): _why for c in chat_ids}, "reason": _why}
    sent, failed, reasons = [], [], {}
    for cid in chat_ids:
        r = telegram_bot.send_result(cid, text) or {}
        if r.get("ok"):
            sent.append(cid)
        else:
            failed.append(cid)
            reasons[str(cid)] = (str(r.get("reason") or "").strip()
                                 or "телеграм не прийняв повідомлення")
    return {"ok": bool(sent), "sent_to": sent, "failed": failed,
            "reasons": reasons,
            "reason": "" if sent else "жодному адресату не доставлено"}


# ── головний обхід ─────────────────────────────────────────────────────────
def compose(items, today, title=None):
    """⭐ ЄДИНА точка «знахідки пошуку -> лист клієнту». Сортування + складач.

    ЧОМУ ОКРЕМА ФУНКЦІЯ (Статут №15, знайдено живим прогоном 27.07.2026).
      Кваліфікатор спершу вшили ЛИШЕ в run(). Жива проба
      (`Run tender watch probe.bat`) складала лист сама — і показала 11 тендерів
      підряд, де позиції 8–11 були спортінвентар, канцтовари, запчастини й
      стандарти. Тобто сортування наче було, а в тому каналі, який дивиться
      людина, його не було. Це той самий клас, що вже бив: ворота в одному
      місці з кількох.
      Тепер обидва — і сторож, і проба — ходять сюди. Хто складає лист із
      результатів пошуку повз цю функцію, того валить чек у tender_honesty_test.

    -> {built, qualify, ordered, aside}
    """
    try:
        import tender_qualify as TQ
        q = TQ.sort(items)
        ordered = TQ.order(q)
        aside = [r.get("tender_id") for r in q["not_ours"] if r.get("tender_id")]
        qinfo = {"counts": q["counts"], "complete": q["complete"],
                 "judged_by": q["judged_by"], "fast": q.get("fast"),
                 "asked_model": q.get("asked_model"),
                 "why_incomplete": q.get("why_incomplete"), "summary": TQ.summary(q)}
    except Exception as e:
        # Кваліфікатор упав -> показуємо ВСЕ без сортування. Помилка сортування
        # не має права зробити тендер невидимим.
        ordered, aside = list(items), []
        qinfo = {"error": type(e).__name__,
                 "summary": u"кваліфікатор недоступний — показано все, без сортування"}

    by_id = {r["tender_id"]: r for r in items if r.get("tender_id")}
    built = TM.build([r["tender_id"] for r in ordered], today=today,
                     resolver=lambda t: by_id.get((t or "").strip()),
                     title=title or TITLE, set_aside=aside)
    return {"built": built, "qualify": qinfo, "ordered": ordered, "aside": aside}


def run(chat_ids=None, today=None, dry=False) -> dict:
    """Один обхід сторожа.

    dry=True — усе те саме, але БЕЗ відправки й БЕЗ запису в пам'ять.
    -> {ok, status, new, text, summary, delivery, reason}
       status: sent | nothing_new | nothing_open | honest_stop | not_delivered
    """
    today = today or datetime.now().strftime("%d.%m.%Y")
    state = _load_state()
    out = {"ok": False, "status": "", "new": [], "text": "", "reason": "",
           "summary": {}, "delivery": None, "today": today}

    words = TP.queries()
    if not words:
        out.update(status="honest_stop",
                   reason="Профіль продукції порожній — сторож не знає, що шукати.")
        return out

    res = TS.search_by_profile(words, today)
    out["summary"] = {"words": words, "per_query": res["per_query"],
                      "unique": len(res["items"]), "duplicates": res["duplicates"],
                      "dropped": res["dropped"], "complete": res["complete"]}

    if not res["items"]:
        out.update(ok=True, status="nothing_open",
                   reason="Сьогодні немає жодного тендера, куди ще можна податися."
                          + ("" if res["complete"] else
                             " ⚠ Обхід НЕПОВНИЙ — частина джерела не відповіла."))
        return out

    seen = already_sent(state)
    fresh = [r for r in res["items"] if r.get("tender_id") not in seen]
    out["new"] = [r.get("tender_id") for r in fresh]

    if not fresh:
        out.update(ok=True, status="nothing_new",
                   reason="Нових тендерів немає — усі %d уже надсилались раніше."
                          % len(res["items"]))
        if not dry:
            state["last_run_at"] = datetime.now().isoformat()
            state.setdefault("runs", []).append(
                {"at": state["last_run_at"], "status": "nothing_new",
                 "found": len(res["items"]), "new": 0, "ids": []})
            _save_state(state)
        return out

    got = compose(fresh, today)
    built = got["built"]
    out["qualify"] = got["qualify"]

    if not built["ok"]:
        out.update(status="honest_stop",
                   reason=built["honest_stop"]["reason"] + " " + built["honest_stop"]["action"])
        return out

    out["text"] = built["text"]
    if dry:
        out.update(ok=True, status="dry")
        return out

    targets = _recipients(chat_ids)
    if not targets:
        out.update(status="not_delivered",
                   reason="Немає жодного адресата (TELEGRAM_ALLOWED_CHAT_IDS порожній).")
        return out

    delivery = _deliver(built["text"], targets)
    out["delivery"] = delivery
    now = datetime.now()
    if delivery["ok"]:
        for tid in out["new"]:
            state.setdefault("sent", {})[tid] = {"at": time.time(),
                                                 "date": now.strftime("%d.%m.%Y")}
        out.update(ok=True, status="sent")
    else:
        out.update(status="not_delivered", reason=delivery["reason"])

    state["last_run_at"] = now.isoformat()
    state.setdefault("runs", []).append(
        {"at": state["last_run_at"], "status": out["status"],
         "found": len(res["items"]), "new": len(out["new"]),
         "sent_to": (delivery or {}).get("sent_to", []),
         # ⛒ 626г: слід прогону памʼятає, ЩО САМЕ пішло. Без цього «надіслати
         # ще раз» довелось би робити скиданням УСІЄЇ памʼяті — тобто залити
         # людей десятками давно бачених торгів.
         "ids": list(out["new"]) if out["status"] == "sent" else []})
    _save_state(state)
    return out


def list_active(today=None) -> dict:
    """ПОКАЗАТИ всі активні торги за профілем — робота ТІЛЬКИ НА ЧИТАННЯ.

    ⭐⭐⭐ 30.07.2026 (закон оркестратора, живий прогін Андрія). Сторож і показ —
    це ДВІ РІЗНІ РОБОТИ, і плутати їх не можна:

      • `run()` — сторож: лишає тільки НОВЕ, надсилає в Telegram і ставить
        позначку «надіслано». На питання «покажи список активних торгів» він
        відповідає «нових немає» — і має рацію, бо його питали не про це.
      • `list_active()` — показ: віддає ВЕСЬ список активних торгів за профілем,
        нічого не надсилає і НЕ ЧІПАЄ пам'ять сторожа. Інакше кожен погляд
        людини на список «спалював» би ранкову задачу: о 9:00 вона промовчала б,
        бо все вже «показано».

    Знайдені торги існували й раніше — просто нікуди не виходили назовні:
    `run_job` віддавав лише лічильник «знайдено 7, нових 0». Тому на прохання
    «покажи їх» оркестратор не мав чим відповісти чесно — і почав вигадувати.
    РЕСУРС, ЯКИЙ НЕ ВМІЄ ВІДДАТИ ЗНАЙДЕНЕ, ЗМУШУЄ ВИГАДУВАТИ.

    Складач — ТОЙ САМИЙ `compose()`, що й у сторожа (єдина точка «знахідки ->
    текст людині»; хто складає повз неї, того валить `tender_honesty_test`).

    -> {ok, status, text, new, reason, summary}
       status: listed | nothing_open | honest_stop
    """
    today = today or datetime.now().strftime("%d.%m.%Y")
    out = {"ok": False, "status": "", "text": "", "new": [], "reason": "",
           "summary": {}, "today": today}

    words = TP.queries()
    if not words:
        out.update(status="honest_stop",
                   reason="Профіль продукції порожній — платформа не знає, що шукати. "
                          "Треба спершу назвати товарні групи.")
        return out

    res = TS.search_by_profile(words, today)
    out["summary"] = {"words": words, "per_query": res["per_query"],
                      "unique": len(res["items"]), "duplicates": res["duplicates"],
                      "dropped": res["dropped"], "complete": res["complete"]}

    if not res["items"]:
        out.update(ok=True, status="nothing_open",
                   reason="Сьогодні немає жодного відкритого тендера за нашим профілем."
                          + ("" if res["complete"] else
                             " ⚠ Обхід НЕПОВНИЙ — частина джерела не відповіла."))
        return out

    got = compose(res["items"], today, title="Активні торги за нашим профілем продукції")
    built = got["built"]
    if not built["ok"]:
        out.update(status="honest_stop",
                   reason=built["honest_stop"]["reason"] + " " + built["honest_stop"]["action"])
        return out

    # Кажемо, що з цього людина вже бачила в Telegram, — але пам'ять НЕ чіпаємо.
    seen = already_sent()
    out["new"] = [r.get("tender_id") for r in res["items"]
                  if r.get("tender_id") and r.get("tender_id") not in seen]
    tail = ("\n\nЗ них раніше надсилалось у Telegram: %d, ще не надсилалось: %d."
            % (max(0, len(res["items"]) - len(out["new"])), len(out["new"])))
    if not res["complete"]:
        tail += ("\n⚠ Обхід НЕПОВНИЙ — частина джерела не відповіла, "
                 "список може бути не вичерпним.")
    out.update(ok=True, status="listed", text=built["text"] + tail)
    return out


def list_job(**kwargs) -> dict:
    """Вхід реєстру робіт для ПОКАЗУ списку (без моделі, без відправки)."""
    r = list_active()
    return {"status": "completed" if r["ok"] else "failed",
            "summary": (r["text"] or r["reason"])}


def run_job(**kwargs) -> dict:
    """Точка входу для планувальника (тиха задача, без моделі).

    ⛒ 626а: факт доставки їде ДАЛІ, а не гине тут. Хто з нього складе рядок
    для людини — вирішує дошка задач (`scheduler`), і робить це ОДИН писар
    (`delivery_report`). Робота свою правду лише віддає."""
    r = run()
    return {"status": "completed" if r["ok"] else "failed",
            "summary": "сторож тендерів: %s; знайдено %s, нових %d. %s"
                       % (r["status"], r["summary"].get("unique", "?"),
                          len(r["new"]), r["reason"]),
            "delivery": r.get("delivery")}
