"""
pagespeed.py — вимірювальний прилад швидкості для SEO/GEO-маркетолога.

Навіщо: стратег досі радив по швидкості «якщо видно з коду» — тобто фактично
здогадувався. Цей модуль дає РЕАЛЬНІ цифри від Google PageSpeed Insights (той самий
двигун Lighthouse, що й у інструменті Google): оцінку продуктивності, Core Web Vitals
(LCP/CLS/INP/TBT) у лабораторії, ПОЛЬОВІ дані реальних користувачів Chrome (CrUX),
і головне — перелік «що саме лагодити» з очікуваним виграшем. Стратег більше не
вигадує швидкість — він її ЧИТАЄ.

Приватність/незалежність: звертаємось напряму до відкритого Google-API за конкретною
публічною адресою; жодного стороннього SEO-сервісу.

Ключ БЕЗКОШТОВНИЙ і НЕОБОВʼЯЗКОВИЙ: без ключа API теж працює на малих обсягах (нижча
квота), із ключем — надійніше й більша квота. Ключ береться з config.PAGESPEED_API_KEY.

Філософія деградації (як у page_render/netfetch): НІКОЛИ не кидаємо виняток назовні.
Нема мережі / квота вичерпана / сторінка недоступна Google / несподіваний формат —
повертаємо {ok:False, note:<людська причина>}, і виклик тихо лишається без блоку швидкості
(флагман не падає; стратег напише «швидкість не виміряно», а не вигадає цифри).

Тільки стандартна бібліотека.
"""

import json as _json
import urllib.parse as _uparse
import urllib.request as _urequest
import urllib.error as _uerror


# ⛒ 623: ДОВІРУ ДО СЕРТИФІКАТА ЗНАЄ ОДИН ПИСАР (netfetch.ssl_context).
# Модуль, що відкриває сокет сам, у клієнта зі старим сховищем коренів ляже
# мовчки — саме це сталось 21.09.2026 з Telegram. Тому кожен вихід питає його.
def _sf_ssl():
    try:
        import netfetch
        return netfetch.ssl_context()
    except Exception:
        return None


_API = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed"


# --- пороги оцінок (ті самі, що використовує Lighthouse/Google) --------------

def _score_mark(score100):
    """0..100 → (емодзі, слово). Пороги Google: ≥90 добре, 50..89 середньо, <50 погано."""
    if score100 is None:
        return "⚪", "невідомо"
    if score100 >= 90:
        return "🟢", "добре"
    if score100 >= 50:
        return "🟠", "середньо"
    return "🔴", "погано"


def _lab_mark(kind, val_ms_or_num):
    """Оцінка ЛАБОРАТОРНОЇ метрики за порогами Core Web Vitals. kind у {lcp,cls,tbt,fcp,si}."""
    v = val_ms_or_num
    if v is None:
        return "⚪"
    if kind == "lcp":   # мс
        return "🟢" if v < 2500 else ("🟠" if v <= 4000 else "🔴")
    if kind == "cls":   # безрозмірне
        return "🟢" if v < 0.1 else ("🟠" if v <= 0.25 else "🔴")
    if kind == "tbt":   # мс (проксі до INP у лабораторії)
        return "🟢" if v < 200 else ("🟠" if v <= 600 else "🔴")
    if kind == "fcp":   # мс
        return "🟢" if v < 1800 else ("🟠" if v <= 3000 else "🔴")
    if kind == "si":    # мс (Speed Index)
        return "🟢" if v < 3400 else ("🟠" if v <= 5800 else "🔴")
    return "⚪"


def _field_mark(category):
    """Категорія польових даних CrUX (FAST/AVERAGE/SLOW) → (емодзі, слово-укр)."""
    m = {"FAST": ("🟢", "добре"), "AVERAGE": ("🟠", "середньо"),
         "SLOW": ("🔴", "повільно")}
    return m.get((category or "").upper(), ("⚪", "невідомо"))


def _ms(v):
    """мс → людський рядок «3.1 с» або «210 мс»."""
    if v is None:
        return "—"
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "—"
    if v >= 1000:
        return f"{v/1000:.1f} с"
    return f"{int(round(v))} мс"


def _parse(data: dict, url: str, strategy: str) -> dict:
    """Розкладає JSON PageSpeed v5 у компактний укр. блок. Повертає {ok,text,data,note}.
    Толерантний до відсутніх секцій (польових даних CrUX часто немає на малих сайтах)."""
    lh = (data or {}).get("lighthouseResult") or {}
    cats = lh.get("categories") or {}
    audits = lh.get("audits") or {}

    perf = (cats.get("performance") or {}).get("score")
    seo = (cats.get("seo") or {}).get("score")
    a11y = (cats.get("accessibility") or {}).get("score")
    perf100 = round(perf * 100) if isinstance(perf, (int, float)) else None
    seo100 = round(seo * 100) if isinstance(seo, (int, float)) else None
    a11y100 = round(a11y * 100) if isinstance(a11y, (int, float)) else None

    def _num(aid):
        a = audits.get(aid) or {}
        return a.get("numericValue")

    lcp = _num("largest-contentful-paint")
    cls = _num("cumulative-layout-shift")
    tbt = _num("total-blocking-time")
    fcp = _num("first-contentful-paint")
    si = _num("speed-index")

    strat_ua = "мобільний" if strategy == "mobile" else "десктоп"
    pe, pw = _score_mark(perf100)
    lines = [
        f"== ШВИДКІСТЬ (Google PageSpeed / Lighthouse, {strat_ua}) ==",
        f"URL: {url}",
        f"Оцінка продуктивності: {perf100 if perf100 is not None else '—'}/100 {pe} {pw}",
    ]
    extra = []
    if seo100 is not None:
        extra.append(f"SEO-оцінка: {seo100}/100")
    if a11y100 is not None:
        extra.append(f"Доступність: {a11y100}/100")
    if extra:
        lines.append("Інші оцінки Lighthouse: " + " | ".join(extra))

    lines.append("Core Web Vitals (лабораторні, симуляція мобільного):")
    lines.append(f"  • LCP (поява головного контенту): {_ms(lcp)} {_lab_mark('lcp', lcp)}")
    lines.append(f"  • CLS (стрибки верстки): {cls:.3f} {_lab_mark('cls', cls)}"
                 if isinstance(cls, (int, float)) else "  • CLS (стрибки верстки): — ⚪")
    lines.append(f"  • TBT (блокування, проксі до INP-реакції): {_ms(tbt)} {_lab_mark('tbt', tbt)}")
    lines.append(f"  • FCP (перший контент): {_ms(fcp)} {_lab_mark('fcp', fcp)}  |  "
                 f"Speed Index: {_ms(si)} {_lab_mark('si', si)}")

    # ПОЛЬОВІ дані реальних користувачів (CrUX) — є не завжди (потрібен трафік).
    le = (data or {}).get("loadingExperience") or {}
    le_metrics = le.get("metrics") or {}
    if le_metrics:
        oe, ow = _field_mark(le.get("overall_category"))
        lines.append(f"Поле (реальні користувачі Chrome за 28 днів, CrUX): загалом {oe} {ow}")
        _map = [("LARGEST_CONTENTFUL_PAINT_MS", "LCP", True),
                ("INTERACTION_TO_NEXT_PAINT", "INP", True),
                ("FIRST_INPUT_DELAY_MS", "FID", True),
                ("CUMULATIVE_LAYOUT_SHIFT_SCORE", "CLS", False)]
        cells = []
        for key, label, is_ms in _map:
            m = le_metrics.get(key)
            if not m:
                continue
            cat = m.get("category")
            fe, _fw = _field_mark(cat)
            p = m.get("percentile")
            if is_ms:
                val = _ms(p)
            else:
                # CLS у CrUX приходить як ціле ×100 (напр. 5 == 0.05)
                val = f"{(p/100):.2f}" if isinstance(p, (int, float)) else "—"
            cells.append(f"{label} {val} {fe}")
        if cells:
            lines.append("  • " + "  |  ".join(cells))
    else:
        lines.append("Поле (реальні користувачі, CrUX): даних недостатньо "
                     "(замало трафіку для польової вибірки) — нижче лише лабораторні цифри.")

    # «Що лагодити» — можливості з найбільшим виграшем часу.
    opps = []
    for aid, a in audits.items():
        if not isinstance(a, dict):
            continue
        det = a.get("details") or {}
        if det.get("type") == "opportunity":
            save = a.get("numericValue") or det.get("overallSavingsMs") or 0
            try:
                save = float(save)
            except (TypeError, ValueError):
                save = 0
            if save >= 50:  # виграш < 50 мс — шум, не показуємо
                opps.append((save, a.get("title") or aid, a.get("displayValue") or ""))
    opps.sort(key=lambda x: x[0], reverse=True)
    if opps:
        lines.append("Що лагодити (за найбільшим виграшем швидкості):")
        for i, (save, title, disp) in enumerate(opps[:6], 1):
            tail = f" — виграш ~{_ms(save)}" + (f" ({disp})" if disp else "")
            lines.append(f"  {i}. {title}{tail}")
    else:
        lines.append("Можливостей із суттєвим виграшем швидкості Lighthouse не виявив "
                     "(сторінка вже оптимізована або дані неповні).")

    text = "\n".join(lines)
    facts = {
        "strategy": strategy, "url": url,
        "performance": perf100, "seo": seo100, "accessibility": a11y100,
        "lcp_ms": lcp, "cls": cls, "tbt_ms": tbt, "fcp_ms": fcp, "speed_index_ms": si,
        "field_available": bool(le_metrics),
        "field_overall": le.get("overall_category"),
        "opportunities": [{"title": t, "savings_ms": s, "display": d}
                          for s, t, d in opps[:6]],
    }
    return {"ok": True, "text": text, "data": facts, "note": ""}


def measure(url: str, strategy: str = "mobile", timeout_s: int = 60,
            api_key: str = None) -> dict:
    """Виміряти швидкість публічної сторінки через Google PageSpeed Insights.
    {ok, text, data, note}. НІКОЛИ не кидає виняток — усе через ok/note.

    strategy: 'mobile' (за замовч.) або 'desktop'.
    api_key:  якщо None — береться з config.PAGESPEED_API_KEY (може бути порожнім:
              API працює й без ключа на малих обсягах)."""
    if not (url or "").lower().startswith(("http://", "https://")):
        return {"ok": False, "text": "", "data": None,
                "note": "дозволені лише http/https URL"}
    if api_key is None:
        try:
            import config
            api_key = getattr(config, "PAGESPEED_API_KEY", "") or ""
        except Exception:
            api_key = ""
    params = [("url", url), ("strategy", strategy),
              ("category", "performance"), ("category", "seo"),
              ("category", "accessibility")]
    if api_key:
        params.append(("key", api_key))
    full = _API + "?" + _uparse.urlencode(params)
    try:
        req = _urequest.Request(full, headers={"User-Agent": "AI-Orchestrator/1.0 (SEO speed)"})
        with _urequest.urlopen(req, timeout=timeout_s, context=_sf_ssl()) as resp:
            raw = resp.read(8_000_000)
        data = _json.loads(raw.decode("utf-8", errors="replace"))
    except _uerror.HTTPError as e:
        # Google повертає JSON-помилку з людським message (квота/невалідний ключ/URL).
        msg = ""
        try:
            body = _json.loads(e.read().decode("utf-8", errors="replace"))
            msg = ((body.get("error") or {}).get("message")) or ""
        except Exception:
            pass
        code = e.code
        if code == 429:
            human = "перевищено квоту PageSpeed (429) — додай безкоштовний ключ PAGESPEED_API_KEY або спробуй згодом"
        elif code in (400, 403) and "key" in msg.lower():
            human = f"проблема з ключем PageSpeed ({code}): {msg}"
        elif code == 400:
            human = f"Google не зміг обробити сторінку (400): {msg or 'перевір, що адреса публічно доступна'}"
        else:
            human = f"PageSpeed відповів помилкою {code}: {msg or e.reason}"
        return {"ok": False, "text": "", "data": None, "note": human}
    except _uerror.URLError as e:
        return {"ok": False, "text": "", "data": None,
                "note": f"немає доступу до PageSpeed API: {e.reason}"}
    except Exception as e:  # noqa
        return {"ok": False, "text": "", "data": None,
                "note": f"несподівана помилка PageSpeed: {str(e)[:200]}"}

    try:
        return _parse(data, url, strategy)
    except Exception as e:  # noqa
        return {"ok": False, "text": "", "data": None,
                "note": f"не вдалося розібрати відповідь PageSpeed: {str(e)[:200]}"}


def available() -> bool:
    """Прилад доступний завжди (API працює й без ключа). Для UI/діагностики."""
    return True
