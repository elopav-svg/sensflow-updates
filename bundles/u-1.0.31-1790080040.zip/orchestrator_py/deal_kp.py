# -*- coding: utf-8 -*-
"""deal_kp.py — МІСТОК «КАРТКА УГОДИ → КОМЕРЦІЙНА ПРОПОЗИЦІЯ» (613, 19.09.2026).

⭐⭐⭐ ЩО ЦЕ ТАКЕ ДЛЯ ЛЮДИНИ. Менеджер стоїть у картці угоди й тисне
«Підготувати КП». Платформа бере вхід ІЗ КАРТКИ, пускає конвеєр КП своїм
звичайним продуктовим шляхом і повертає готовий документ У ТУ САМУ КАРТКУ під
номером платформи. Нічого не треба переносити руками.

⭐ РІШЕННЯ ВЛАСНИКА 19.09.2026: КП іде в клієнтську збірку БЕЗ окремої оплати.
Отже прайс живе в даних клієнта, кнопка доступна за звичайним рівнем доступу до
картки, окремого платного рівня немає.

⛒ ТРИ КЛАСИ, ЯКІ ЦЕЙ МОДУЛЬ ЗАКРИВАЄ:

**1. ДВА ПИСАРІ ЦІН.** Прайсовий блок для конвеєра КП складає РІВНО одне
місце — `prais_text` нижче. Другий писар цін означав би дві правди про гроші,
і одна з них колись поїхала б клієнтові.

⛒ ЦІНИ БЕРУТЬСЯ ЗІ ЗНІМКА ДОМОВЛЕНОСТІ (позиції угоди, `deal_items`), а НЕ з
сьогоднішньої картки товару. Той самий закон, що й у 535: ціна, яка завтра
приїде з обліку, не сміє переписати вчорашню домовленість — інакше КП
розійдеться з тим, про що домовлялись. Угода без позицій — чесна відмова, бо
порожній прайс для моделі означає «вигадай числа сам».

**2. ТИХИЙ ПРОВАЛ У КАРТЦІ.** Суддя результату (612) має право спинити видачу.
Зупинка мусить бути ВИДНА СЛОВАМИ — і людині на екрані, і в журналі угоди,
щоб той, хто закрив браузер, побачив, що спроба була і чим скінчилась.
Порожня картка без пояснення — це та сама зупинка, тільки без людини.

**3. ПРАВА.** Кнопка не ширша за рівень доступу: питаємо того самого суддю
видимості (`entity_scope.may_see`), що й решта картки. Двері в сервері стоять
у тому самому переліку, що й причеплення документа.

⛒ ЧОГО ТУТ НЕМАЄ І НЕ БУДЕ. Тут немає ані власного судді документа, ані
власного перезбору: і те, й інше живе в продуктовому шляху
(`executor.run_system` → контракт `result_policy`). Місток, який судив би сам,
став би другим суддею — рівно тією вадою, яку зняла зміна 612.

⛒ КП — ЦЕ НЕ ДОГОВІР. Документ лягає в картку типом «інший документ»:
правило 585 («угода без договору не закривається») міст не обходить.
"""
import config
import deal_documents
import deal_items
import deals
import doc_numbers
import entity
import entity_scope
import protocol

config.refuse_live_state_for_checks(__name__)

SID = "kp_automation_pipeline"

# Тип, яким КП лягає в картку. ⛒ Свідомо НЕ договір.
KP_KIND = deal_documents.KIND_OTHER


class KpBridgeError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнений сторож."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ═════════════════════ ОДИН ПИСАР ПРАЙСУ ДЛЯ КОНВЕЄРА КП ═══════════════════
_TAIL = ("⛒ Інших цін не існує. Чисел, яких тут немає, не вигадувати.\n"
         "⛒ Нічого не множити й не підсумовувати самостійно: платформа цін не "
         "рахує, ціни лежать такими, як їх уклали в угоді.")


def prais_text(rows, seller: str = "", on_date: str = "",
               agreements=(), conditions=()) -> str:
    """ПРАЙСОВИЙ БЛОК ДЛЯ КОНВЕЄРА КП — один на всю платформу.

    `rows` — позиції угоди у формі `deal_items` (знімок домовленості).

    🩸 ПОЗИЦІЯ БЕЗ ЦІНИ НЕ ЗНИКАЄ МОВЧКИ. Викинутий рядок — це рядок, якого
    клієнт не побачить у пропозиції, і ніхто не дізнається чому. Тому вона
    лишається в переліку зі словами «ціни немає».
    """
    head = "ПРАЙС ВИКОНАВЦЯ"
    if _s(seller):
        head += " (%s" % _s(seller)
        head += (", чинний на %s)" % _s(on_date)) if _s(on_date) else ")"
    elif _s(on_date):
        head += " (чинний на %s)" % _s(on_date)
    out = [head + " — рахувати ТІЛЬКИ по ньому.", "", "Склад угоди:"]
    for r in (rows or []):
        snap = dict((r or {}).get("snap") or {})
        name = _s(snap.get("name")) or _s((r or {}).get("name")) or "позиція без назви"
        unit = _s(snap.get("unit"))
        cur = _s(snap.get("currency")) or "грн"
        qty = _s((r or {}).get("qty"))
        price = _s((r or {}).get("price"))
        left = "  " + name
        if qty:
            left += " — %s%s" % (qty, (" " + unit) if unit else "")
        out.append("%s: %s" % (left, ("%s %s" % (price, cur)) if price
                               else "ціни немає — у пропозиції числа не вигадувати"))
    for a in (agreements or []):
        if _s(a):
            out.append("")
            out.append("Домовленість із цим клієнтом (діє): " + _s(a))
    if conditions:
        out.append("")
        out.append("Умови, які треба переказати клієнтові чесно:")
        for c in conditions:
            if _s(c):
                out.append("  " + _s(c))
    out += ["", _TAIL]
    return "\n".join(out) + "\n"


# ═════════════════════════ ВХІД ІЗ КАРТКИ УГОДИ ════════════════════════════
def rows_of_deal(did) -> list:
    """Ціни цієї угоди — ЗНІМКОМ домовленості, а не сьогоднішнім прайсом."""
    return deal_items.items_of(_s(did))


def _client_name(did) -> str:
    pid = deals.client_of(_s(did))
    if not pid:
        return ""
    try:
        return _s(entity.title(entity.ref(entity.KIND_PARTY, pid)))
    except Exception:
        return ""


def task_of_deal(did) -> str:
    """Запит СЛОВАМИ, зібраний із картки. Нічого не вигадуємо: лише те, що в ній є."""
    row = deals.get(_s(did)) or {}
    if not row:
        raise KpBridgeError("Угоди %s немає." % (_s(did) or "«»"))
    klient = _client_name(did)
    lines = ["Підготувати КОМЕРЦІЙНУ ПРОПОЗИЦІЮ за угодою з картки платформи.",
             ""]
    if klient:
        lines.append("Контрагент: %s" % klient)
    lines.append("Угода: %s" % (_s(row.get("name")) or _s(did)))
    if _s(row.get("stage")):
        lines.append("Стадія угоди: %s" % _s(row.get("stage")))
    na = dict(row.get("next_action") or {})
    if _s(na.get("text")):
        lines.append("Наступна дія за карткою: %s%s"
                     % (_s(na.get("text")),
                        (" (до %s)" % _s(na.get("date"))) if _s(na.get("date")) else ""))
    if _s(row.get("note")):
        lines += ["", "Нотатки менеджера в картці:", _s(row.get("note"))]
    lines += ["",
              "Склад і ціни — ТІЛЬКИ з прайсу, доданого до цього запиту.",
              "Дату в документі писати у форматі ДД.ММ.РРРР."]
    return "\n".join(lines)


def input_of_deal(did) -> dict:
    """Повний вхід конвеєра КП, зібраний із картки: задача + прайс."""
    key = _s(did)
    if not deals.exists(key):
        raise KpBridgeError("Угоди %s немає." % (key or "«»"))
    rows = rows_of_deal(key)
    if not rows:
        raise KpBridgeError(
            "В угоді немає позицій, а КП без цін — це числа з голови. "
            "Додайте позиції в угоду (розділ «Позиції»), і кнопка запрацює.")
    return {"task": task_of_deal(key),
            "prais": prais_text(rows, seller=_seller_name(),
                                on_date=doc_numbers.today()),
            "rows": rows}


def _seller_name() -> str:
    """Чиї це ціни — назвою КОРЕНЕВОГО підрозділу оргструктури.

    ⛒ Своєї назви компанії платформа окремо не тримає, і заводити другу тут
    не можна: назва компанії вже названа один раз — у вершині оргструктури.
    ⛒ 616: сам її більше не рахуємо — питаємо ОДНОГО писаря
    (`taskdesk_people.company_name`). Доти той самий обхід дерева жив тут і
    мав би завестись удруге в магазині."""
    try:
        import taskdesk_people as _tp
        return _s(_tp.company_name())
    except Exception:
        return ""


# ═══════════════════════ ДОКУМЕНТ ПОВЕРТАЄТЬСЯ В КАРТКУ ════════════════════
def _say(did, note, outcome):
    """Слід у журналі УГОДИ. Ніколи не валить роботу."""
    try:
        about = []
        pid = deals.client_of(_s(did))
        if pid:
            about.append(entity.ref(entity.KIND_PARTY, pid))
        protocol.write(protocol.A_DEAL_KP, deals.ref(_s(did)), about=about,
                       outcome=outcome, note=note)
    except Exception:
        pass


def _stop(did, words):
    """ОДНІ ДВЕРІ ВІДМОВИ: спершу слід у журнал, потім слова людині."""
    _say(did, "КП з картки не зроблено: " + words, protocol.OUT_REFUSED)
    raise KpBridgeError(words)


def _best_file(arts):
    """Який із зібраних файлів чіпляти до картки. Клієнтові — читабельний."""
    order = (".docx", ".pdf", ".html", ".md")
    for ext in order:
        for a in (arts or []):
            if _s(a.get("filename")).lower().endswith(ext):
                return a
    return (arts or [None])[0]


def prepare(did, by: str = "", emp: str = None) -> dict:
    """Зробити КП з картки угоди і причепити його до неї ж.

    Повертає {"doc": <рядок документа>, "file": <імʼя файла>, "run": <id прогону>}.
    Будь-яка невдача — `KpBridgeError` зі словами, і слід у журналі угоди."""
    key = _s(did)
    if not deals.exists(key):
        raise KpBridgeError("Угоди %s немає." % (key or "«»"))

    # ⛒ ПРАВА. Кнопка не ширша за рівень доступу до самої картки.
    who = entity_scope.viewer() if emp is None else _s(emp)
    if not entity_scope.may_see(who, entity.KIND_DEAL, key):
        raise KpBridgeError(
            "Ця угода вам не видима, тож і КП з неї не готується. "
            "Попросіть відповідального за угоду або свого керівника.")

    vhid = input_of_deal(key)

    # ⛒ ПРОДУКТОВИЙ ШЛЯХ, А НЕ СВІЙ. Тут працює суддя результату 612:
    # чистка форми, один детермінований перезбір і тверда зупинка.
    import executor
    import registry
    import taskdesk_identity

    sysd = registry.find_system(SID)
    if not sysd:
        _stop(key, "Конвеєра КП немає в реєстрі систем (%s) — цій збірці його "
                   "не поставили." % SID)
    res = executor.run_system(taskdesk_identity.resolve_actor(None), sysd,
                              vhid["task"], files_context=vhid["prais"]) or {}

    status = _s(res.get("status"))
    if status == "honest_stop":
        hs = dict(res.get("honest_stop") or {})
        _stop(key, "документ не пройшов перевірку. Причина: %s. Що зробити: %s."
                   % (_s(hs.get("reason")) or "не названа",
                      _s(hs.get("action")) or "подивитись журнал прогону"))
    if status != "completed":
        _stop(key, "конвеєр КП завершився станом «%s» — документа немає."
                   % (status or "невідомо"))

    md = _s(res.get("final_markdown"))
    if not md:
        _stop(key, "конвеєр повернув порожній документ.")

    import artifacts
    import store
    run_id = store.new_run_id(artifacts.result_title(md) or "КП")
    arts = artifacts.write_result_artifacts(run_id, md, task=vhid["task"])
    art = _best_file(arts)
    if not art:
        # ⛒⛒ ТИХИЙ ПРОВАЛ. Писар файла віддав порожньо — це вирок політики
        # результату на дверях файла (612), а не «нічого не сталось».
        _stop(key, "документ зібрано, але писар файла його НЕ написав — його "
                   "спинила політика результату. Причину дослівно видно в "
                   "журналі прогону %s." % run_id)

    try:
        body = open(art["path"], "rb").read()
    except Exception as ex:
        _stop(key, "файл КП не прочитався зі сховища прогону: %s" % ex)

    nazva = "Комерційна пропозиція — %s%s" % (
        _s((deals.get(key) or {}).get("name")) or key,
        "." + _s(art["filename"]).rsplit(".", 1)[-1])
    try:
        doc = deal_documents.add(key, KP_KIND, src=body, name=nazva,
                                 date=doc_numbers.today(), by=_s(by))
    except Exception as ex:
        _stop(key, "документ не причепився до картки: %s" % ex)

    _say(key, "КП причеплено до угоди: " + deal_documents.said(doc),
         protocol.OUT_OK)
    return {"doc": doc, "file": nazva, "run": run_id}
