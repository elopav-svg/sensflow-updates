# -*- coding: utf-8 -*-
"""
scheduler.py — ДОШКА ЗАДАЧ ЗА РОЗКЛАДОМ («Автоматизація»).

⭐⭐⭐ 30.07.2026 (зміна 31, Зміна A закону «одна дошка»). КОРІНЬ, ЯКИЙ ТУТ ВИЛІКУВАНО.

ЗАКОН (Андрій, 30.07.2026): кожна задача, що виконується за розкладом, існує в
ОДНОМУ вигляді і в ОДНОМУ місці. Родів «тиха», «службова», «тестова» не існує.
Запис, який не читається, показується як зламаний — невидимість заборонена.

ЩО БУЛО НЕ ТАК. Правда про задачу не мала ні єдиної форми, ні єдиного входу:
кожен, кому вона була потрібна, сам ходив у теку й ліпив поля, як памʼятав.
Звідси всі пʼять хвороб одразу: список для людини збирала одна функція, а
виконавець читав теку НАПРЯМУ (тому виконував те, чого людина не бачила);
періодичність жила у двох виглядах, і слово «4 години» перетворювалось на
годину; нечитабельний файл мовчки зникав зі світу; гроші чіплялись лише до
однієї з двох гілок запуску; історія прогонів не доходила до людини.

ЛІКИ — ТРИ РЕЧІ, І БІЛЬШЕ НІЯКИХ:
  1. `_normalize()` — ОДНЕ ПРЕДСТАВЛЕННЯ. Будь-який запис (хоч побитий) виходить
     звідси з повним набором полів. Рід задачі (модельна / безмодельна) — це
     ПОЛЕ, а не окреме життя.
  2. `load_all()` — ОДИН ЧИТАЧ. І список для людини, і виконавець беруть звідси.
     Виконавець фізично не може виконати те, чого немає в списку, — бо це той
     самий список. `iterdir` у цьому файлі є РІВНО В ОДНОМУ місці, і чек
     `scheduler_board_test.py` це обчислює деревом коду, а не вірить на слово.
  3. `save()` — ОДИН ПИСАР. Створення, вмикання, розклад, старт і кінець прогону
     проходять через нього й лишають слід в `audit[]`. Тому журнал змін задачі
     дописується в одному місці, а не в десяти — і майбутній Task Desk дістане
     аудит безкоштовно.

СТАТУСИ — ТРИ (рішення Андрія 30.07.2026):
    inactive — неактивна · active — активна · running — в процесі виконання
Зламаність — це не четвертий статус, а ОЗНАКА читабельності запису (`broken` +
`broken_reason`); зламана задача примусово неактивна і не виконується ніколи.

ГРОШІ: будь-яка задача розкладу будь-якого роду виконується всередині ОДНОГО
грошового обліку (`costs.run_scope`, рід `KIND_AUTOMATION`) і рахується в денну
стелю. Безмодельна теж — саме вона й обходила стелю двічі.
"""

import ast
import json
import re
import uuid
from datetime import datetime, timedelta
from pathlib import Path

import config
import costs

# ⭐ 29.07.2026: тека автоматизацій іде за ОДНИМ перемикачем стану рушія
# (config.STATE_DIR). У клієнта й на продакшні це та сама тека, що й була;
# під час чеків вона відводиться вбік, тому тести більше не смітять у бойову.
AUTO_DIR = config.STATE_DIR / "automations"
AUTO_DIR.mkdir(parents=True, exist_ok=True)

# ⭐ 30.07.2026 (Зміна B). Прибрана задача не стирається, а переїжджає сюди.
# Службові теки починаються з «_» і дошкою не читаються НІКОЛИ — це єдине
# дозволене «невидиме» місце, і воно не задача, а архів.
DELETED_DIR_NAME = "_видалені"

# ─────────────────────────────── СТАТУСИ ───────────────────────────────
STATUS_INACTIVE = "inactive"    # вимкнена людиною або зламана
STATUS_ACTIVE = "active"        # чекає свого часу
STATUS_RUNNING = "running"      # саме зараз виконується
STATUSES = (STATUS_INACTIVE, STATUS_ACTIVE, STATUS_RUNNING)

# Прогін, що не закрився (сервер убили посеред роботи), не має права тримати
# задачу «в процесі» вічно. Через цей час вона знову стає активною, а обрив
# чесно записується в історію прогонів.
RUNNING_TTL_SEC = 6 * 3600

# Скільки прогонів і скільки рядків аудиту тримаємо в записі.
RUNS_KEEP = 20
AUDIT_KEEP = 50

# Поля, які ОБЧИСЛЮЮТЬСЯ при читанні й НІКОЛИ не лежать на диску: два писарі
# однієї правди починаються саме з того, що похідне значення десь зберегли.
DERIVED = ("status", "broken", "broken_reason", "last_status", "last_summary",
           "runs_count", "unreadable")


# ---------------------------------------------------------------------------
# Періодичність: слово людини -> секунди. ЧИТАЄМО ЧИСЛО, А НЕ ЛИШЕ ОДИНИЦЮ.
# ---------------------------------------------------------------------------
# ⭐ 30.07.2026. Донині тут читалось слово «годин» і НЕ читалось число перед ним:
# «щогодини», «кожні 4 години» і «кожні 12 годин» усі означали одну годину.
# Людина вибирала 12 годин, а платила за 12 прогонів. Одиниці шукаємо за
# позицією в тексті (перша, що трапилась), число — останнє ПЕРЕД одиницею.
_UNITS = (
    (r"хвил|мін|минут|min", 60),
    (r"годин|год\b|hour|hr\b", 3600),
    (r"доб|дн|ден|day|daily|щоранку|morning", 86400),
    (r"тиж|week|понеділ|monday", 7 * 86400),
    (r"місяц|міс\b|month", 30 * 86400),
)
_NUM_BEFORE = re.compile(r"(\d+)\s*$")


def cadence_to_seconds(cadence: str) -> int:
    """«кожні 4 години» -> 14400. Незрозуміле -> доба (як було). Мінімум — хвилина."""
    c = (cadence or "").lower()
    best = None
    for pattern, unit in _UNITS:
        m = re.search(pattern, c)
        if m and (best is None or m.start() < best[0]):
            best = (m.start(), unit)
    if best is None:
        return 86400
    pos, unit = best
    n = 1
    mn = _NUM_BEFORE.search(c[:pos])
    if mn:
        try:
            n = max(1, int(mn.group(1)))
        except Exception:
            n = 1
    return max(60, n * unit)


# ⭐ 28.07.2026. Доти в консолі був ЛИШЕ вимикач: клієнт міг увімкнути обхід, але
# не міг сказати, ЯК ЧАСТО і КОЛИ. Розклад лишається інтервальним: «наступний
# запуск о X, далі кожні N» — без вигадування календарної магії.
CADENCE_CHOICES = ("щогодини", "кожні 4 години", "кожні 12 годин",
                   "щодня", "щотижня", "щомісяця")


# ---------------------------------------------------------------------------
# ОДНЕ ПРЕДСТАВЛЕННЯ
# ---------------------------------------------------------------------------
def _iso(dt) -> str:
    return dt.isoformat()


def _parse_dt(raw):
    try:
        return datetime.fromisoformat(str(raw))
    except Exception:
        return None


def _normalize(raw: dict, auto_id: str, broken_reason: str = "") -> dict:
    """Сирий запис (хоч побитий) -> повний запис із обчисленим статусом.

    НІКОЛИ не кидає виняток: зламаний запис мусить ДОЇХАТИ до людини зі своєю
    причиною, а не зникнути. Мовчазний `except: continue` — це і є невидимість,
    яку закон забороняє."""
    rec = dict(raw or {})
    broken = bool(broken_reason)

    rec["id"] = str(rec.get("id") or auto_id or "").strip() or str(auto_id)
    if not broken and rec["id"] != auto_id:
        # Запис у теці X називає себе Y — це не дрібниця: саме так задача
        # «переїжджає» й починає жити двома копіями.
        broken, broken_reason = True, ("id у файлі («%s») не збігається з текою («%s»)"
                                       % (rec["id"], auto_id))
        rec["id"] = auto_id

    rec["name"] = str(rec.get("name") or "").strip() or ("Задача %s" % rec["id"])
    rec["cadence"] = str(rec.get("cadence") or "щодня").strip() or "щодня"
    # Число секунд ЗАВЖДИ похідне від слова: два джерела правди про період — це
    # рівно та брехня, через яку «12 годин» означали годину.
    rec["interval_seconds"] = cadence_to_seconds(rec["cadence"])
    rec["kind"] = str(rec.get("kind") or "").strip()
    rec["job"] = str(rec.get("job") or "").strip()
    rec["task"] = str(rec.get("task") or "")
    rec["target_system_id"] = rec.get("target_system_id") or None
    # ⭐ ВЛАСНИК ЗАДАЧІ (крок 1.5, 06.08.2026): від кого платформа виконує цю
    # роботу. Порожньо — задача старша за ворота; тоді її веде власник
    # платформи, і про це є рядок у журналі (`identity.actor_for_automation`).
    rec["owner_account_id"] = str(rec.get("owner_account_id") or "").strip()
    rec["enabled"] = bool(rec.get("enabled", True))
    rec["created_at"] = str(rec.get("created_at") or _iso(datetime.now()))
    rec["last_run_at"] = rec.get("last_run_at") or None
    rec["running_since"] = rec.get("running_since") or None

    runs = rec.get("runs")
    rec["runs"] = [r for r in runs if isinstance(r, dict)] if isinstance(runs, list) else []
    audit = rec.get("audit")
    rec["audit"] = [a for a in audit if isinstance(a, dict)] if isinstance(audit, list) else []

    nxt = _parse_dt(rec.get("next_run_at"))
    if nxt is None:
        if not broken:
            broken, broken_reason = True, "час наступного запуску не читається"
        nxt = datetime.now() + timedelta(seconds=rec["interval_seconds"])
    rec["next_run_at"] = _iso(nxt)

    # Безмодельна задача без назви обходу — це запис, який ніколи не виконається.
    if rec["kind"] == "data_sync" and not rec["job"]:
        broken, broken_reason = True, "безмодельна задача без назви обходу (job)"

    # ── обчислені поля (на диск не йдуть) ──
    rec["broken"] = bool(broken)
    rec["broken_reason"] = str(broken_reason or "")

    started = _parse_dt(rec.get("running_since"))
    if started is not None and (datetime.now() - started).total_seconds() > RUNNING_TTL_SEC:
        started = None      # прогін-зомбі: сервер убили, задача не винна

    if rec["broken"] or not rec["enabled"]:
        rec["status"] = STATUS_INACTIVE
    elif started is not None:
        rec["status"] = STATUS_RUNNING
    else:
        rec["status"] = STATUS_ACTIVE

    last = rec["runs"][-1] if rec["runs"] else {}
    rec["last_status"] = str(last.get("status") or "")
    rec["last_summary"] = str(last.get("summary") or "")
    rec["runs_count"] = len(rec["runs"])
    # Ознака «вміст файлу втрачено для нас»: ставить її ЛИШЕ читач, і лише коли
    # байти на диску не розібрались. Писати поверх такого файлу заборонено —
    # інакше перша ж кнопка затре роботу, яку ще можна врятувати руками.
    rec["unreadable"] = bool(rec.get("unreadable"))
    return rec


def _strip_derived(rec: dict) -> dict:
    out = dict(rec)
    for k in DERIVED:
        out.pop(k, None)
    return out


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ
# ---------------------------------------------------------------------------
def _path(auto_id: str) -> Path:
    return AUTO_DIR / auto_id / "automation.json"


def _read_one(p, auto_id: str) -> dict:
    """ЄДИНЕ місце у продукті, де читається файл задачі розкладу."""
    try:
        raw = json.loads(p.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            return _normalize({"unreadable": True}, auto_id,
                              "у файлі не запис задачі, а %s" % type(raw).__name__)
        return _normalize(raw, auto_id)
    except Exception as e:
        return _normalize({"unreadable": True}, auto_id,
                          "файл не читається: %s" % type(e).__name__)


def load_all() -> list:
    """ЄДИНИЙ ЧИТАЧ ДОШКИ. І людина, і виконавець беруть задачі звідси.

    Повертає ПОВНІ записи, зокрема зламані — зі статусом «неактивна» й причиною."""
    out = []
    if not AUTO_DIR.exists():
        return out
    for d in sorted(AUTO_DIR.iterdir(), reverse=True):
        try:
            if not d.is_dir():
                continue
            # Службова тека (архів прибраних) — не задача й ніколи нею не стане.
            if d.name.startswith("_"):
                continue
            p = d / "automation.json"
            if not p.exists():
                continue
        except Exception:
            continue
        out.append(_read_one(p, d.name))
    return out


def list_automations() -> list:
    """Проєкція дошки для людини. Це та сама дошка, інша лінза — не другий список."""
    out = []
    for rec in load_all():
        out.append({
            "id": rec["id"], "name": rec["name"], "cadence": rec["cadence"],
            "interval_seconds": rec["interval_seconds"],
            "enabled": rec["enabled"],
            "status": rec["status"],
            "broken": rec["broken"], "broken_reason": rec["broken_reason"],
            "kind": rec["kind"], "job": rec["job"],
            "next_run_at": rec["next_run_at"],
            "last_run_at": rec["last_run_at"],
            "last_status": rec["last_status"],
            "last_summary": rec["last_summary"],
            "target_system_id": rec["target_system_id"],
            "runs": rec["runs_count"],
        })
    return out


def get_automation(auto_id: str) -> dict:
    for rec in load_all():
        if rec["id"] == str(auto_id or ""):
            return rec
    return None


# ---------------------------------------------------------------------------
# ОДИН ПИСАР
# ---------------------------------------------------------------------------
def save(record: dict, reason: str = "") -> dict:
    """ЄДИНЕ місце у продукті, де запис задачі розкладу лягає на диск.

    `reason` — людськими словами, ЩО саме змінилось; лягає в `audit[]`. Саме тому
    журнал змін задачі дописується в одному місці, а не в десяти.

    FAIL-CLOSED над чужою роботою: якщо байти на диску НЕ розібрались, писар
    відмовляється писати поверх. Втратити те, що ще можна врятувати руками,
    гірше, ніж лишити задачу зламаною й видимою."""
    if record.get("unreadable"):
        raise ValueError("запис «%s» не читається — писати поверх заборонено, "
                         "поки людина не вирішить його долю" % record.get("id"))
    rec = _normalize(record, str(record.get("id") or ""))
    disk = _strip_derived(rec)
    if reason:
        disk.setdefault("audit", [])
        disk["audit"].append({"at": _iso(datetime.now()), "what": str(reason)[:200]})
        disk["audit"] = disk["audit"][-AUDIT_KEEP:]
    disk["runs"] = list(disk.get("runs") or [])[-RUNS_KEEP:]
    p = _path(disk["id"])
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(disk, ensure_ascii=False, indent=2), encoding="utf-8")
    return _normalize(disk, disk["id"])


# ---------------------------------------------------------------------------
# Створення
# ---------------------------------------------------------------------------
def create_automation(spec: dict, task: str, target_system_id: str = None,
                      owner_account_id: str = "") -> dict:
    auto_id = "auto-" + uuid.uuid4().hex[:8]
    cadence = (spec.get("cadence") or "щодня").strip() or "щодня"
    interval = cadence_to_seconds(cadence)
    now = datetime.now()
    record = {
        "id": auto_id,
        "name": spec.get("name") or "Регулярна задача",
        "cadence": cadence,
        "interval_seconds": interval,
        "trigger": spec.get("trigger", ""),
        "checks": spec.get("checks", []),
        "success_criteria": spec.get("success_criteria", []),
        "human_escalation": spec.get("human_escalation", ""),
        "task": task,
        "target_system_id": target_system_id or spec.get("target_system_or_adapter"),
        # Рід задачі — ПОЛЕ, а не окреме життя: "" = питає модель,
        # "data_sync" = виконує звичайна функція з реєстру data_jobs.
        "kind": (spec.get("kind") or "").strip(),
        "job": (spec.get("job") or "").strip(),
        "owner_account_id": str(owner_account_id or "").strip(),
        "enabled": True,
        "created_at": _iso(now),
        "next_run_at": _iso(now + timedelta(seconds=interval)),
        "last_run_at": None,
        "running_since": None,
        "runs": [],
        "audit": [],
    }
    return save(record, "створено (%s)" % cadence)


def create_data_sync(name: str, job: str, cadence: str = "щодня",
                     owner_account_id: str = "") -> dict:
    """Створює БЕЗМОДЕЛЬНУ регулярну задачу (обхід із реєстру data_jobs).

    Навіщо окрема функція: щоб ніхто не мусив памʼятати, які саме поля роблять
    задачу безмодельною. Одні двері -> одна форма запису."""
    import data_jobs
    if data_jobs.get(job) is None:
        raise ValueError("невідома безмодельна задача «%s»; відомі: %s"
                         % (job, ", ".join(data_jobs.names()) or "жодної")) 
    # ⛒⛒⛒ 624 (21.09.2026). ДРУГА ТАКА САМА ЗАДАЧА — ЦЕ НЕ ДРУГА РОБОТА,
    # А СМІТТЯ. Доти дублікати ловив наш батник (`tender_watch_daily.py`), бо
    # створювати задачі міг лише він. Щойно кнопка «створити» зʼявилась у
    # клієнта, правило мусить жити ТУТ: людина натисне двічі, і обхід ходитиме
    # двічі на добу, надсилаючи те саме.
    for _rec in load_all():
        if _rec.get("kind") == "data_sync" and _rec.get("job") == job:
            if not _rec.get("enabled"):
                set_enabled(_rec["id"], True)
            for _a in list_automations():
                if _a["id"] == _rec["id"]:
                    return _a
    return create_automation(
        {"name": name, "cadence": cadence, "kind": "data_sync", "job": job},
        task="(без моделі: %s)" % job, owner_account_id=owner_account_id)


# ---------------------------------------------------------------------------
# Керування
# ---------------------------------------------------------------------------
def set_enabled(auto_id: str, enabled: bool) -> bool:
    """Вмикає/вимикає задачу.

    ⭐ 28.07.2026. «Увімкнув» не має означати «одразу витратив»: прострочений час
    наступного запуску переставляється на «зараз + період». Клієнт вмикає
    розклад, а не платіж. Хоче раніше — ставить дату руками, поле поруч."""
    rec = get_automation(auto_id)
    if not rec:
        return False
    if rec["unreadable"]:
        # Байти на диску не розібрались: будь-який запис поверх — це втрата.
        return False
    if rec["broken"] and enabled:
        # Зламану задачу вмикати нікуди: вона однаково не виконається, а «увімкнена»
        # на екрані була б брехнею. Вимкнути зламану — можна завжди.
        return False
    rec["enabled"] = bool(enabled)
    if rec["enabled"]:
        due = _parse_dt(rec.get("next_run_at"))
        if due is None or due <= datetime.now():
            rec["next_run_at"] = _iso(datetime.now()
                                      + timedelta(seconds=rec["interval_seconds"]))
    save(rec, "увімкнено" if rec["enabled"] else "вимкнено")
    return True


def set_schedule(auto_id: str, cadence: str = None, next_run_at: str = None) -> dict:
    """Змінює періодичність і/або час наступного запуску. Повертає {ok, ...}."""
    rec = get_automation(auto_id)
    if not rec:
        return {"ok": False, "message": "Задачу не знайдено."}
    if rec["unreadable"]:
        return {"ok": False, "message": "Запис задачі не читається (%s). Розклад їй "
                                        "не змінити — задачу треба видалити або "
                                        "полагодити файл." % rec["broken_reason"]}
    what = []
    if cadence:
        cadence = str(cadence).strip()
        if not cadence:
            return {"ok": False, "message": "Періодичність порожня."}
        interval = cadence_to_seconds(cadence)
        if interval < 60:
            return {"ok": False, "message": "Періодичність не може бути меншою за хвилину."}
        rec["cadence"] = cadence
        rec["interval_seconds"] = interval
        what.append("періодичність -> %s (%d с)" % (cadence, interval))
    if next_run_at:
        raw = str(next_run_at).strip().replace(" ", "T")
        if len(raw) == 16:          # 2026-07-28T09:30 з поля datetime-local
            raw += ":00"
        when = _parse_dt(raw)
        if when is None:
            return {"ok": False, "message": "Не розумію дату. Формат: 2026-07-28 09:30."}
        rec["next_run_at"] = _iso(when)
        what.append("наступний запуск -> %s" % rec["next_run_at"][:16])
    elif cadence:
        # Змінили лише періодичність — переставляємо наступний запуск від НЕЇ,
        # щоб зміна набула чинності одразу, а не після старого інтервалу.
        rec["next_run_at"] = _iso(datetime.now()
                                  + timedelta(seconds=rec["interval_seconds"]))
        what.append("наступний запуск -> %s" % rec["next_run_at"][:16])
    saved = save(rec, "; ".join(what) or "розклад збережено")
    return {"ok": True, "cadence": saved["cadence"],
            "interval_seconds": saved["interval_seconds"],
            "next_run_at": saved["next_run_at"],
            "status": saved["status"]}


def request_run_now(auto_id: str) -> dict:
    """«Запустити зараз» — це ПРОХАННЯ ДО ДОШКИ, а не другий виконавець.

    ⭐⭐⭐ 30.07.2026 (Зміна B, рішення Андрія). Спокуса була зробити так, щоб двері
    самі виконали задачу. Це створило б ДРУГИЙ ШЛЯХ ВИКОНАННЯ — рівно ту хворобу,
    яку Зміна A лікувала: людина натискає кнопку, а працює не той механізм, що за
    розкладом (інший облік грошей, інша історія, інший статус). Тому тут ми лише
    пересуваємо час наступного запуску на «зараз», а бере задачу в роботу той
    самий і єдиний виконавець `run_due` — протягом хвилини.

    FAIL-CLOSED. Кнопка, яка «спрацювала», але нічого не запустила, — брехня на
    екрані. Тому на неактивній, зламаній, нечитабельній і вже працюючій задачі
    ми чесно кажемо «ні» з причиною, а не мовчки нічого не робимо."""
    rec = get_automation(auto_id)
    if not rec:
        return {"ok": False, "message": "Задачу не знайдено."}
    if rec["unreadable"]:
        return {"ok": False, "message": "Запис задачі не читається (%s). Її не можна "
                                        "запустити — тільки видалити або полагодити "
                                        "файл руками." % rec["broken_reason"]}
    if rec["broken"]:
        return {"ok": False, "message": "Задача зламана (%s) і не виконується ніколи. "
                                        "Спершу полагодьте або видаліть."
                                        % rec["broken_reason"]}
    if not rec["enabled"]:
        return {"ok": False, "message": "Задача неактивна. Увімкніть її — тоді "
                                        "запуск матиме силу."}
    if rec["status"] == STATUS_RUNNING:
        return {"ok": False, "message": "Задача саме зараз виконується."}
    rec["next_run_at"] = _iso(datetime.now())
    saved = save(rec, "запуск на вимогу людини")
    return {"ok": True, "next_run_at": saved["next_run_at"], "status": saved["status"],
            "message": "Взято в роботу — почнеться протягом хвилини. Наступний "
                       "плановий запуск відлічиться від цього прогону."}


def delete(auto_id: str) -> dict:
    """Прибирає задачу з дошки, ПЕРЕНОСЯЧИ теку, а не стираючи її.

    ⭐⭐⭐ Рішення Андрія 30.07.2026: його файли — актив, а стерте не повернеш.
    Задача зникає з дошки (людина бачить порядок), але лишається на диску в
    `automations\\_видалені\\<id>_<коли>`. Тому «видалити» — це операція, від якої
    можна відкотитись руками, і саме тому вона дозволена НАВІТЬ над нечитабельним
    записом: інакше сміття, яке не читається, не прибрати нічим.

    Чому не `save()`: писар фізично не може прибрати задачу — він уміє лише класти
    правду на диск. Прибирання — це РУХ ТЕКИ, і в цьому файлі він теж рівно в
    одному місці (`SINGLE_ACCESS['rename']`), щоб завтра не зʼявився другий
    прибиральник, який стирає по-справжньому.

    Заборонено, поки задача виконується: виконавець наприкінці прогону запише
    свій слід писарем і тим ВОСКРЕСИТЬ теку, яку ми щойно прибрали."""
    rec = get_automation(auto_id)
    if not rec:
        return {"ok": False, "message": "Задачу не знайдено."}
    if rec["status"] == STATUS_RUNNING:
        return {"ok": False, "message": "Задача саме зараз виконується — прибрати її "
                                        "можна після завершення прогону."}
    src = _path(rec["id"]).parent
    if not src.exists():
        return {"ok": False, "message": "Теки задачі вже немає на диску."}
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    dest = AUTO_DIR / DELETED_DIR_NAME / ("%s_%s" % (rec["id"], stamp))
    try:
        dest.parent.mkdir(parents=True, exist_ok=True)
        src.rename(dest)
    except Exception as e:
        return {"ok": False, "message": "Не вдалося прибрати теку задачі (%s). "
                                        "Найчастіша причина — файл відкритий іншою "
                                        "програмою." % type(e).__name__}
    return {"ok": True, "name": rec["name"], "moved_to": str(dest),
            "message": "Задачу «%s» прибрано з дошки. Тека збережена в «%s» — "
                       "нічого не стерто." % (rec["name"], DELETED_DIR_NAME)}


# ---------------------------------------------------------------------------
# Виконання
# ---------------------------------------------------------------------------
def _run_one(rec: dict, runner, now: datetime) -> dict:
    """Один прогін однієї задачі — ЗАВЖДИ всередині одного грошового обліку.

    ⭐ 30.07.2026. Раніше безмодельна гілка кликала `data_jobs.run()` голяком, без
    лічильника: а `tender_watch` у непевних випадках таки питає модель. Тому
    «нуль витрат» був не гарантією, а сподіванням, і денну стелю ці гроші
    обходили двічі. Тепер рід задачі впливає лише на те, ХТО виконує роботу,
    і ніколи — на те, чи її рахують."""
    rec["running_since"] = _iso(now)
    save(rec, "старт прогону")
    entry = None
    try:
        with costs.run_scope("scheduler/%s" % rec["id"], costs.KIND_AUTOMATION) as scope:
            if rec["kind"] == "data_sync":
                import data_jobs
                result = data_jobs.run(rec["job"]) or {}
            else:
                # Виконавець отримує ВЛАСНИКА задачі третім аргументом: інакше
                # він мусив би здогадуватись, від кого діє, — а здогад тут і є діра.
                result = runner(rec["task"], rec["target_system_id"],
                                rec.get("owner_account_id") or "") or {}
        # ⛒⛒⛒ 626а (22.09.2026). ПРАВДУ ПРО ДОСТАВКУ В ЗАПИС ПРОГОНУ ВКЛАДАЄ
        # ДОШКА, А НЕ КОЖНА РОБОТА. 🩸 Сторож тендерів звітував словом «sent»,
        # а з трьох адресатів лист отримав один. Якби рядок складала сама
        # робота, наступна робота забула б його так само. Складає ОДИН писар
        # (`delivery_report`), вкладає ОДНЕ місце — оце. Робота лише віддає
        # факт `delivery`, і забути про звіт нікому: забувати ніде.
        _said = (result.get("summary") or result.get("final_markdown", ""))[:400]
        try:
            import delivery_report as _dr626
            _said = _dr626.append_to(_said, result.get("delivery"))
        except Exception:
            pass                      # поломка писаря імен не їсть підсумок
        entry = {
            "at": _iso(now),
            "status": result.get("status", "completed"),
            "summary": _said[:900],
            "delivery": result.get("delivery") or None,
            "run_id": result.get("run_id"),
            "usd": round(float((scope.result or {}).get("usd") or 0.0), 4),
        }
    except Exception as e:
        # ⭐ 29.07.2026: `str(e)` тут їхав ПРЯМО в картку задачі, яку читає клієнт —
        # той самий канал сирої аварії, який лікує `failure`. Людині — причина
        # словами, машині — повний слід у журналі.
        try:
            import failure
            _txt = failure.client_text(e, "scheduler/%s" % rec.get("id"))
        except Exception:
            _txt = "Задачу не вдалося виконати. Причина збережена в журналі."
        entry = {"at": _iso(now), "status": "failed", "summary": _txt[:400], "usd": 0.0}
    finally:
        fresh = get_automation(rec["id"]) or rec
        fresh["running_since"] = None
        if entry is not None:
            fresh.setdefault("runs", []).append(entry)
            fresh["last_run_at"] = _iso(now)
        fresh["next_run_at"] = _iso(datetime.now()
                                    + timedelta(seconds=fresh["interval_seconds"]))
        save(fresh, "прогін: %s" % (entry or {}).get("status", "обірвано"))
    return entry


def run_due(runner) -> list:
    """Запускає задачі, час яких настав. Бере їх З ТОГО САМОГО СПИСКУ, що й людина.

    runner(task, target_system_id, owner_account_id) -> dict (summary/status)."""
    executed = []
    now = datetime.now()
    day_blocked = costs.over_day_cap()   # питаємо ОДИН раз на коло
    for rec in load_all():
        # ⭐ Виконавець не має права виконати те, чого немає в списку, — і не має
        # права виконати те, що в списку позначене неактивним чи зламаним.
        if rec["status"] != STATUS_ACTIVE:
            continue
        due = _parse_dt(rec["next_run_at"])
        if due is None or due > now:
            continue

        if day_blocked:
            entry = {"at": _iso(now), "status": "stopped_budget", "usd": 0.0,
                     "summary": costs.day_block_reason()}
            rec.setdefault("runs", []).append(entry)
            rec["last_run_at"] = _iso(now)
            rec["next_run_at"] = _iso(now + timedelta(seconds=rec["interval_seconds"]))
            save(rec, "прогін: stopped_budget")
        else:
            entry = _run_one(rec, runner, now)
        executed.append({"id": rec["id"], "name": rec["name"], "entry": entry})
    return executed


# ---------------------------------------------------------------------------
# ВОРОТА ПРОТИ ДРУГОГО ЧИТАЧА/ПИСАРЯ (обчислюються деревом коду, а не вірою)
# ---------------------------------------------------------------------------
# Правило, яке має пережити мене: у цьому файлі тека задач обходиться рівно в
# одному місці, файл задачі читається рівно в одному місці й пишеться рівно в
# одному. Чек `scheduler_board_test.py` кличе цю функцію — тому порушення видно
# ще до збірки, а не тоді, коли виконавець зробить те, чого людина не бачила.
SINGLE_ACCESS = {"iterdir": "load_all", "read_text": "_read_one", "write_text": "save",
                 # ⭐ 30.07.2026 (Зміна B): прибирання задачі — теж рівно одне місце.
                 # Інакше завтра поруч зʼявиться другий прибиральник, який стирає
                 # по-справжньому, і актив Андрія зникне без слідів.
                 "rename": "delete"}


def access_map(path: str = None) -> dict:
    """-> {'iterdir': ['load_all'], 'read_text': [...], 'write_text': [...]}

    ⚠ Сам цей розбір читає файл ВБУДОВАНИМ `open()`, а не `Path.read_text` —
    інакше ворота ловили б власного вартового як другого читача."""
    with open(path or __file__, "r", encoding="utf-8") as fh:
        src = fh.read()
    tree = ast.parse(src)
    found = {k: [] for k in SINGLE_ACCESS}
    for fn in ast.walk(tree):
        if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        for node in ast.walk(fn):
            if isinstance(node, ast.Attribute) and node.attr in found:
                if fn.name not in found[node.attr]:
                    found[node.attr].append(fn.name)
    return found
