# -*- coding: utf-8 -*-
"""deal_mail.py — АДРЕСА УГОДИ В ЛИСТУВАННІ (крок C2, 15.08.2026).

Проєкт — `DESIGN_Хребет_платформи.md`, розділ «КРОК C2», рішення Р1-Р6.

## КОРІНЬ
Лист не мав адреси угоди — тому будь-яке розкидання листів по угодах було
ЗДОГАДКОЮ. У постачальника з двадцятьма паралельними угодами з одним заводом
здогадка помиляється щодня, і помилку видно вже після відповіді клієнту.

## ЩО ЦЕЙ МОДУЛЬ
**ОДИН ПИСАР адреси угоди в листуванні.** І той, хто ставить адресу у вихідний
лист, і той, хто читає її з вхідного, — тут. Два писарі розійшлись би на першій
правці формату, і вхідне перестало б упізнавати власний токен.

## НОСІЙ АДРЕСИ (Р1)
Токен у ТЕМІ: `[SF-D0014]`. Поки лист відправляє поштова програма людини, тема —
єдине, що гарантовано доїде назад: поштові клієнти лишають її в `Re:`.
⛒ Це не милиця, а чесний вибір за наявних умов: власної відправки в платформі
немає (жодного `smtplib` у рушії), тому `Message-ID` свого листа ми не знаємо.
**Р2 (на потім):** коли зʼявиться `mail_send`, вхідне ловитимемо ще й за
`In-Reply-To`/`References`. Місце для цього вже є — параметр `headers`
у `address_of`. Токен лишиться ЗАПАСНИМ носієм: люди пересилають листи й
починають нові гілки.

## ЧОГО ТУТ СВІДОМО НЕМАЄ
⛔ **Вгадування «покладу в найсвіжішу угоду».** Якщо адреси в темі немає, а живих
угод у контрагента кілька — лист іде в чергу «Рознести» й чекає одного кліку
людини. Єдиний виняток — коли жива угода РІВНО ОДНА: там немає з чого вибирати,
іншого адресата не існує (це те саме правило, що вже стояло в `crm.note_inbound`,
і воно переїхало СЮДИ, щоб писар лишався один).
⛔ **Тиха підстановка.** Токен, під яким немає угоди, або токен чужої угоди — це
ВІДМОВА СЛОВАМИ й рядок у протоколі, а не «схоже, малось на увазі оце».
⛔ **Розбір старого листування заднім числом:** адреси в тих листах немає й не буде.

## ІЗОЛЯЦІЯ
🩸 Урок 15.08 (C1): новий писар СТАНУ слухає вимикач ізоляції САМ. Чужі чеки про
цю чергу не знають і знати не мусять — тому шлях бере `config.STATE_SANDBOXED`,
а не той, хто нас викликав.

Лише stdlib + `config`, `deals`, `parties`, `protocol`. Нічого не надсилає назовні.
"""

import json
import one_writer
import re
from datetime import datetime

import config
import deals
import entity
import parties
import protocol


class MailAddressError(Exception):
    """Відмова словами: адресу прочитати можна, але вона не сходиться."""


# ── ДЕ ЛЕЖИТЬ ЧЕРГА «РОЗНЕСТИ» ───────────────────────────────────────────────
DIR = config.CRM_DIR
SPREAD_JSON = DIR / "_deal_spread.json"

# ── ФОРМА ТОКЕНА ─────────────────────────────────────────────────────────────
# ⛒ Один шаблон і на запис, і на читання. Регістр не має значення (поштові
# клієнти й люди пишуть по-різному), пробіли всередині дужок теж прощаємо.
TOKEN_RE = re.compile(r"\[\s*SF-(D\s?\d{3,6})\s*\]", re.I)
TOKEN_FMT = "[SF-%s]"

# Причини відмови — окремими іменами, щоб чек судив ПРИЧИНУ, а не підрядок тексту.
WHY_NONE = "absent"       # адреси в темі немає — це не відмова
WHY_UNKNOWN = "unknown"   # токен є, а такої угоди немає
WHY_ALIEN = "alien"       # токен є, угода є, але вона не цього контрагента

HOW_TOKEN = "token"       # адресу дав токен у темі
HOW_ONLY_ONE = "only_one"  # жива угода рівно одна — вибору не існує
HOW_PARKED = "parked"     # чекає на один клік людини
HOW_REFUSED = "refused"   # адреса не сходиться — сказали словами


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ── ТОКЕН: ЗРОБИТИ Й ПРОЧИТАТИ ───────────────────────────────────────────────
def token(did) -> str:
    """Адреса угоди у вигляді, який доїде в темі листа: `[SF-D0014]`."""
    d = _s(did).lower()
    if not d:
        raise MailAddressError("Порожній номер угоди — нема з чого робити адресу листа.")
    return TOKEN_FMT % d.upper()


def read_token(subject) -> str:
    """Номер угоди з теми (`d0014`) або «» — якщо адреси там немає."""
    m = TOKEN_RE.search(_s(subject))
    if not m:
        return ""
    return m.group(1).replace(" ", "").lower()


def stamp(subject, did) -> str:
    """Тема з адресою угоди. Якщо адреса вже стоїть — другої не додаємо."""
    subj = _s(subject)
    tok = token(did)
    have = read_token(subj)
    if have == _s(did).lower():
        return subj
    if have:
        raise MailAddressError(
            "У темі вже стоїть адреса іншої угоди (%s). Дві адреси в одному листі — "
            "це рівно та плутанина, від якої C2 і рятує." % have.upper())
    return (tok + " " + subj).strip() if subj else tok


# ── ТЕМА ЛЮДСЬКОЮ МОВОЮ ──────────────────────────────────────────────────────
# Приставки, які дописує сам поштовий клієнт. Темою вони не є.
REPLY_PREFIX_RE = re.compile(r"^\s*(re|fw|fwd|відп|переслано)\s*(\[\d+\])?\s*:", re.I)


def topic_of(subject) -> str:
    """Те, що лишається від теми, коли прибрати адресу угоди й службові приставки.

    ⛒ «Re:»/«Fwd:» темою НЕ рахуються: це приставка поштового клієнта, а не те,
    що написала людина. Інакше «Re: [SF-D0014]» проходило б за тему листа."""
    rest = TOKEN_RE.sub(" ", _s(subject))
    while True:
        cut = REPLY_PREFIX_RE.sub("", rest)
        if cut == rest:
            break
        rest = cut
    return " ".join(rest.split())


# ── ОБОВʼЯЗКОВЕ ПОЛЕ В ЛИСТІ (зміна 183, 15.08.2026) ─────────────────────────
# ⭐⭐⭐ ОБІЦЯНКУ ОХОРОНЯЄ ТОЙ, ХТО ЇЇ ДАВ. C2 обіцяє клієнтові рівно одне:
# відповідь ляже саме в ЦЮ угоду. Тримається обіцянка на адресі в темі — а
# стерти її на екрані можна було одним Backspace, і нічого не спинялось: унизу
# форми стояло ПРОХАННЯ «не прибирай». Прохання — не ворота.
# ⛒ Ворота стоять у ПИСАРІ, а не в екрані: у листа не один вхід (екран сьогодні,
# автоматика завтра), і правило, яке живе в екрані, обходить перший же другий
# вхід. Це рівно той самий клас, що й `deals.check_stage_ready`.
MAIL_FIELD_NAMES = {
    "to": "кому (адреса пошти)",
    "token": "адресу угоди в темі",
    "topic": "тему листа (крім адреси угоди)",
}


def check_mail_ready(did, subject: str = "", to: str = "") -> None:
    """Ворота вихідного листа: чого бракує, щоб він поїхав. Відмова СЛОВАМИ."""
    d = _s(did).lower()
    if not deals.exists(d):
        raise MailAddressError("Угоди %s немає в реєстрі." % d)
    subj = _s(subject)
    have = read_token(subj)
    if have and have != d:
        raise MailAddressError(
            "У темі стоїть адреса чужої угоди (%s), а лист іде з %s. Відповідь "
            "клієнта лягла б не в ту угоду." % (token(have), token(d)))
    missing = []
    if not _s(to):
        missing.append(MAIL_FIELD_NAMES["to"])
    if not have:
        missing.append("%s %s" % (MAIL_FIELD_NAMES["token"], token(d)))
    if not topic_of(subj):
        missing.append(MAIL_FIELD_NAMES["topic"])
    if missing:
        raise MailAddressError(
            "Лист не готовий — бракує: %s. Лист без теми клієнт читає як спам, а "
            "без адреси угоди його відповідь не знайде дороги назад."
            % ", ".join(missing))



# ── ЧИЯ ЦЕ АДРЕСА ────────────────────────────────────────────────────────────
def address_of(subject, party: str = "", headers=None) -> dict:
    """Прочитати адресу угоди з листа.

    Повертає {deal, token, ok, why, reason}. `why` — ІМʼЯ причини (WHY_*),
    `reason` — те саме людськими словами.
    ⚠ `headers` поки не читаємо: `Message-ID` своїх листів платформа не знає,
    бо сама пошту не надсилає. Параметр стоїть тут як ОГОЛОШЕНЕ місце для Р2,
    щоб другий писар адреси не завівся деінде."""
    tok = read_token(subject)
    if not tok:
        return {"deal": "", "token": "", "ok": False, "why": WHY_NONE, "reason": ""}
    if not deals.exists(tok):
        return {"deal": "", "token": tok, "ok": False, "why": WHY_UNKNOWN,
                "reason": "У темі стоїть адреса %s, але такої угоди в базі немає."
                          % token(tok)}
    pid = _s(party)
    if pid:
        owner = deals.client_of(tok)
        people = [p.get("party_id") for p in deals.people_of(tok)]
        if pid != owner and pid not in people:
            return {"deal": "", "token": tok, "ok": False, "why": WHY_ALIEN,
                    "reason": "Лист від «%s», а угода %s належить «%s». "
                              "Сама я лист не переадресовую."
                              % (parties.title(pid) or pid, token(tok),
                                 parties.title(owner) or owner or "невідомо кому")}
    return {"deal": tok, "token": tok, "ok": True, "why": "", "reason": ""}


# ── ЧЕРГА «РОЗНЕСТИ» ─────────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(SPREAD_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("seq", 0)
    if not isinstance(d.get("items"), dict):
        d["items"] = {}
    return d


def _save(d: dict) -> None:
    """Атомарний запис: або старий файл цілий, або новий цілий."""
    SPREAD_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(SPREAD_JSON, d)


def _new_id(d: dict) -> str:
    seq = int(d.get("seq") or 0) + 1
    while ("m%04d" % seq) in d["items"]:
        seq += 1
    d["seq"] = seq
    return "m%04d" % seq


@one_writer.guard("SPREAD_JSON")
def park(party, channel: str = "email", subject: str = "", preview: str = "",
         identity: str = "", why: str = WHY_NONE, reason: str = "",
         to: str = "", cc: str = "") -> dict:
    """Покласти вхідне в чергу «Рознести»: воно ЧЕКАЄ на один клік людини.

    ⛒ Черга — не смітник: у кожному рядку видно, від кого лист, яка тема і
    ЧОМУ платформа не рознесла його сама.

    ⭐ 618: рядок памʼятає ще й «КОМУ» був лист. Саме там корпоративна скринька
    каже, ЧИЙ він (`sales+ivan@`), — і доти цю адресу викидали на порозі."""
    pid = _s(party)
    if not pid:
        raise MailAddressError("Не сказано, від кого лист — нема кого класти в чергу.")
    d = _load()
    subj = " ".join(_s(subject).split())[:300]
    prev = " ".join(_s(preview).split())[:300]
    addr_to = " ".join(_s(to).split())[:300]
    addr_cc = " ".join(_s(cc).split())[:300]
    for row in d["items"].values():
        if row.get("party") == pid and row.get("subject") == subj and row.get("channel") == channel:
            row["count"] = int(row.get("count", 1)) + 1
            row["last_seen"] = _now()
            if prev:
                row["preview"] = prev
            if addr_to:
                row["to"] = addr_to
            if addr_cc:
                row["cc"] = addr_cc
            _save(d)
            return dict(row)
    mid = _new_id(d)
    row = {"id": mid, "party": pid, "channel": _s(channel) or "email",
           "identity": _s(identity), "subject": subj, "preview": prev,
           "to": addr_to, "cc": addr_cc,
           "why": _s(why) or WHY_NONE, "reason": _s(reason),
           "count": 1, "first_seen": _now(), "last_seen": _now()}
    d["items"][mid] = row
    _save(d)
    return dict(row)


def owner_of(row) -> dict:
    """ЧИЙ ЦЕ ЛИСТ — питаємо ОДНОГО писаря (`mail_owner`), а не рахуємо тут.

    ⛒ Відповідь рахується НА ЧИТАННІ, а не береться з того, що лежало на диску
    вчора: передали клієнта іншому менеджеру — і черга каже правду тієї ж
    миті, без жодної міграції. Записане при поставленні в чергу лишається
    слідом того, що платформа знала ТОДІ, і живе в протоколі.

    ⛒ ПОЛОМКУ ТУТ НЕ ЛОВИМО СВІДОМО. Спіймана поломка зробила б кожен рядок
    «нічиїм», тобто ВИДИМИМ УСІМ, — і тихо повернула б рівно той витік, від
    якого ця зміна лікує. Гучна відмова дорожча за тиху дірку.
    """
    r = row if isinstance(row, dict) else {}
    import mail_owner
    return mail_owner.resolve(to=r.get("to") or "", cc=r.get("cc") or "",
                              subject=r.get("subject") or "",
                              party=r.get("party") or "")


def pending(party: str = "") -> list:
    """Що чекає на рознесення. Найсвіже — згори.

    ⭐⭐⭐ 618. ТУТ СТОЇТЬ СИТО. Це ТРЕТІЙ читач переліку в платформі (після
    `parties.all_parties` і `deals.all_deals`) — і єдиний, повз якого сито 589
    пройшло: черга віддавала ВСІМ теми й уривки чужого листування. Сито те
    саме й суддя той самий (`entity_scope`), бо правило одне: рядок із
    власником бачить власник і його керівник, нічий — усі."""
    d = _load()
    rows = [dict(r) for r in d["items"].values()]
    pid = _s(party)
    if pid:
        rows = [r for r in rows if r.get("party") == pid]
    for r in rows:
        r["party_name"] = parties.title(r.get("party")) or r.get("party")
        r["choices"] = [{"id": x["id"], "name": x.get("name") or x["id"],
                         "stage": x.get("stage") or ""}
                        for x in deals.deals_of_party(r.get("party"), archived=False)]
        who = owner_of(r)
        r["owner"] = who.get("owner") or ""
        r["owner_name"] = who.get("owner_name") or ""
        r["owner_how"] = who.get("how") or ""
        r["owner_why"] = who.get("why") or ""
        r["owner_candidates"] = list(who.get("candidates") or [])
        # ⛒ Екран питає людину ІМЕНАМИ, а не номерами: кнопка
        # «Це лист emp-0d0f191f» не є питанням, на яке можна відповісти.
        import mail_owner as _mo618
        r["owner_candidate_names"] = [_mo618.name_of(x) or x
                                      for x in r["owner_candidates"]]
        r["owner_ask"] = bool(who.get("ask"))
    rows.sort(key=lambda r: r.get("last_seen") or "", reverse=True)
    # ⛒ СИТО НЕ ОБГОРНУТЕ В «ЯКЩО ВИЙДЕ». Замок, який при поломці пропускає,
    # замком не є: саме так повертаються витоки, яких ніхто не помітив.
    import entity_scope
    return entity_scope.sift_owned(rows, key="owner")


def get_pending(mid) -> dict:
    return dict(_load()["items"].get(_s(mid)) or {})


@one_writer.guard("SPREAD_JSON")
def _forget(mid) -> bool:
    d = _load()
    if _s(mid) in d["items"]:
        del d["items"][_s(mid)]
        _save(d)
        return True
    return False


def assign(mid, did, by: str = "") -> dict:
    """Один клік людини: лист із черги лягає у ВКАЗАНУ угоду.

    ⛒ Перевіряємо те саме, що й на вході: угода існує і належить цьому
    контрагентові. Інакше клік по чужому рядку тихо зіпсував би дві угоди."""
    row = get_pending(mid)
    if not row:
        raise MailAddressError("У черзі «Рознести» немає рядка %s." % _s(mid))
    d = _s(did).lower()
    if not deals.exists(d):
        raise MailAddressError("Угоди %s немає в реєстрі." % d)
    owner = deals.client_of(d)
    people = [p.get("party_id") for p in deals.people_of(d)]
    if row.get("party") != owner and row.get("party") not in people:
        raise MailAddressError(
            "Угода %s належить «%s», а лист від «%s». Спершу привʼяжіть контакт до угоди."
            % (token(d), parties.title(owner) or owner or "невідомо кому",
               parties.title(row.get("party")) or row.get("party")))
    deals.set_attention(d, inc=1)
    protocol.write(protocol.A_DEAL_MAIL_IN, deals.ref(d),
                   about=[parties.ref(row.get("party"))],
                   source="human.console",
                   note="рознесено рукою: «%s»" % (row.get("subject") or "(без теми)"))
    _forget(mid)
    return {"deal": d, "item": row}


def set_owner(mid, emp_id, by: str = "") -> dict:
    """⭐⭐⭐ 618. ОДИН КЛІК ЛЮДИНИ: «цей лист — його».

    ⛒ КЛІК НЕ ПРИЛИПАЄ ДО РЯДКА, А НАВЧАЄ ЗВʼЯЗОК. Записати власника в сам
    рядок означало б лікувати один лист і чекати того самого питання завтра.
    Тому клік ставить ВІДПОВІДАЛЬНОГО КОНТРАГЕНТА — те саме поле, яке вже має
    свій екран і свого писаря (`parties.set_manager`), — і наступний лист від
    цього контрагента відповідає сам. Другого поля «власник листа», яке одного
    дня розійдеться з першим, ми не заводимо.

    ⛒ Відмову словами (звільнений, немає такого працівника) каже той самий
    писар — свого другого переліку заперечень тут немає."""
    row = get_pending(mid)
    if not row:
        raise MailAddressError("У черзі «Рознести» немає рядка %s." % _s(mid))
    pid = _s(row.get("party"))
    if not pid:
        raise MailAddressError("У рядка немає контрагента — нема кому закріпити лист.")
    parties.set_manager(pid, _s(emp_id), by=_s(by))
    protocol.write(protocol.A_DEAL_MAIL_PARKED, parties.ref(pid),
                   source="human.console",
                   note="чий це лист — сказала людина: «%s»"
                        % (_s(emp_id) or "знято"))
    return {"party": pid, "owner": _s(emp_id), "item": row}


def drop(mid, why: str = "") -> bool:
    """Прибрати рядок із черги без угоди («це не про угоди»)."""
    row = get_pending(mid)
    if not row:
        return False
    protocol.write(protocol.A_DEAL_MAIL_PARKED, parties.ref(row.get("party")),
                   outcome=protocol.OUT_REFUSED, source="human.console",
                   note="прибрано з черги «Рознести» без угоди: %s"
                        % (_s(why) or "рішення людини"))
    return _forget(mid)


# ── ВХІДНЕ: КУДИ ЙОГО ────────────────────────────────────────────────────────
def route(party, channel: str = "email", subject: str = "", preview: str = "",
          identity: str = "", headers=None, to: str = "", cc: str = "") -> dict:
    """ОДИН читач адреси вхідного. Повертає {deal, how, reason}.

    Порядок рівно такий: адреса в темі → рівно одна жива угода → черга.
    ⛔ Іншого порядку не буває: «найсвіжіша угода» — це здогадка."""
    pid = _s(party)
    if not pid:
        return {"deal": "", "how": HOW_PARKED, "reason": "невідомо, від кого лист"}
    res = address_of(subject, pid, headers=headers)

    if res["ok"]:
        did = res["deal"]
        deals.set_attention(did, inc=1)
        protocol.write(protocol.A_DEAL_MAIL_IN, deals.ref(did),
                       about=[parties.ref(pid)],
                       note="вхідне з адресою %s: «%s»"
                            % (token(did), _s(subject) or "(без теми)"))
        return {"deal": did, "how": HOW_TOKEN, "reason": ""}

    if res["why"] in (WHY_UNKNOWN, WHY_ALIEN):
        row = park(pid, channel, subject, preview, identity,
                   why=res["why"], reason=res["reason"], to=to, cc=cc)
        protocol.write(protocol.A_DEAL_MAIL_PARKED, parties.ref(pid),
                       outcome=protocol.OUT_REFUSED,
                       note=res["reason"])
        return {"deal": "", "how": HOW_REFUSED, "reason": res["reason"], "item": row["id"]}

    live = deals.live_deals_of_party(pid)
    if len(live) == 1:
        did = live[0]["id"]
        deals.set_attention(did, inc=1)
        protocol.write(protocol.A_DEAL_MAIL_IN, deals.ref(did),
                       about=[parties.ref(pid)],
                       note="адреси в темі немає, але жива угода одна: «%s»"
                            % (_s(subject) or _s(preview) or "(без теми)"))
        return {"deal": did, "how": HOW_ONLY_ONE, "reason": ""}

    why_text = ("живих угод у контрагента: %d — сама я не вибираю" % len(live)) if live \
        else "у контрагента ще немає живої угоди"
    row = park(pid, channel, subject, preview, identity, why=WHY_NONE,
               reason=why_text, to=to, cc=cc)
    protocol.write(protocol.A_DEAL_MAIL_PARKED, parties.ref(pid),
                   outcome=protocol.OUT_REFUSED, note=why_text)
    return {"deal": "", "how": HOW_PARKED, "reason": why_text, "item": row["id"]}


# ── ВИХІДНЕ: ЛИСТ ІЗ УГОДИ ───────────────────────────────────────────────────
def compose(did, subject: str = "", to: str = "") -> dict:
    """Заготовка листа З УГОДИ: тема вже несе адресу, кому — з картки клієнта.

    ⛒ Нічого не надсилає: платформа пошту не шле (це окремий крок `mail_send`).
    Наша обіцянка тут одна — адреса угоди поїде в темі й повернеться у `Re:`."""
    d = _s(did).lower()
    if not deals.exists(d):
        raise MailAddressError("Угоди %s немає в реєстрі." % d)
    row = deals.get(d)
    pid = deals.client_of(d)
    addr = _s(to)
    if not addr and pid:
        for h in (parties.get(pid) or {}).get("handles", {}).get(parties.H_EMAIL, []):
            addr = _s(h)
            if addr:
                break
    return {"deal": d, "to": addr, "party": pid,
            "subject": stamp(subject, d),
            "token": token(d),
            "deal_name": row.get("name") or d}


def note_sent(did, subject: str = "", to: str = "") -> dict:
    """Слід у протоколі: лист із угоди СФОРМОВАНО (обіцянку дано).

    ⛒ Пишемо «сформовано», а не «надіслано»: надсилає поштова програма людини,
    і брати на себе чужий факт ми не будемо [[feedback_no_architectural_lying]]."""
    d = _s(did).lower()
    # ⛒ ВОРОТА ПЕРЕД СЛІДОМ. «Сформовано» в протоколі мусить означати лист, який
    # СПРАВДІ має адресу угоди й тему. Слід про брак — це зелений обман поверхом
    # нижче: журнал каже «є», а клієнтові поїхало «[SF-D0014]» без жодного слова.
    check_mail_ready(d, subject=subject, to=to)
    pid = deals.client_of(d)
    about = [parties.ref(pid)] if pid else []
    protocol.write(protocol.A_DEAL_MAIL_OUT, deals.ref(d), about=about,
                   source="human.console",
                   note="лист із угоди сформовано%s: «%s»"
                        % ((" на " + _s(to)) if _s(to) else "", _s(subject) or "(без теми)"))
    return {"deal": d, "ok": True}
