# -*- coding: utf-8 -*-
"""taskdesk_worktypes.py — ТИПИ РОБОТИ І СТАНДАРТ ГОТОВНОСТІ (зміна 225).

⭐⭐⭐ КОРІНЬ. «Готово» в однієї людини і «готово» в іншої — різні речі.
Виконавець здає, постановник повертає на доопрацювання, бо мав на увазі ще дві
речі, яких ніхто не назвав. Це не недбалість: **правила не сказали ДО роботи**.

⛒ ДВА РІЗНІ ПИТАННЯ, ЯКІ НЕ МОЖНА ЗЛИВАТИ В ОДНЕ ПОЛЕ:
  • **критерій приймання** (зміна 223) — за чим приймемо ЦЮ задачу; унікальний
    щоразу, пише постановник;
  • **стандарт готовності** (цей файл) — що взагалі означає ГОТОВО для роботи
    ТАКОГО ТИПУ; пишеться ОДИН раз на тип і однаковий для всіх його задач.
Плюс третє, вже наявне: **чек-лист** каже, ЯК робити.

🩸 Рішення Андрія 26.08.2026: **заготовок від нас немає — типи й пункти складає
сам клієнт**. Тому довідник порожній на старті, і платформа без типів працює
рівно так, як працювала.

🩸 Рішення Андрія 26.08.2026: непозначені пункти **ПОКАЗУЮТЬСЯ, але нічого не
зупиняють**. Ми дивимось, а не перегороджуємо — той самий закон, яким скасовано
ліміт незавершеної роботи 25.08.

⛒ ВИДАЛЕННЯ ТУТ НЕМАЄ: тип ховається з вибору (`active=False`), бо на нього вже
можуть посилатись задачі, а історія не сміє осиротіти.
"""

import json
import uuid

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import one_writer

DESK_DIR = config.STATE_DIR / "taskdesk"

# ⛒ ДРУГИЙ ЗАМОК (27.08.2026): чек, завантажений не через файл, не сміє
# працювати по бойовому стану — тут лежать живі люди, ролі й задачі.
config.refuse_live_state_for_checks(__name__)
TYPES_JSON = DESK_DIR / "worktypes.json"

AUDIT_KEEP = 200

# Скільки пунктів має сенс. Це НЕ ворота, а порада: стандарт на двадцять рядків
# ніхто не читає, і він перестає працювати. Межа нижче — захист екрана від
# абсурду, а не перепона людині.
ADVISED_POINTS = 5
MAX_POINTS = 20
MAX_POINT_LEN = 300


class WorkTypeError(Exception):
    """Відмова, названа людськими словами. Тиші тут не буває."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _new_id(prefix: str) -> str:
    return "%s-%s" % (prefix, uuid.uuid4().hex[:8])


def _norm_points(raw) -> list:
    out = []
    for i, p in enumerate(raw or []):
        text = _s(p.get("text")) if isinstance(p, dict) else _s(p)
        if not text:
            continue
        pid = _s(p.get("id")) if isinstance(p, dict) else ""
        out.append({"id": pid or ("p%d" % (i + 1)), "text": text[:MAX_POINT_LEN]})
    return out


def _normalize(raw) -> dict:
    if not isinstance(raw, dict):
        raw = {}
    types = []
    for t in (raw.get("types") or []):
        if not isinstance(t, dict):
            continue
        item = {"id": _s(t.get("id")) or _new_id("wt"),
                "name": _s(t.get("name")),
                "points": _norm_points(t.get("points")),
                "active": bool(t.get("active", True))}
        # Похідне: чи стандарт узагалі сказаний. Тип без пунктів — це просто
        # ярлик, і людина має бачити це словом, а не порожнім місцем.
        item["has_standard"] = bool(item["points"])
        item["points_total"] = len(item["points"])
        types.append(item)
    return {"types": types,
            "audit": [a for a in (raw.get("audit") or []) if isinstance(a, dict)]}


def _strip_derived(state: dict) -> dict:
    out = {"types": [], "audit": list(state.get("audit") or [])}
    for t in state.get("types") or []:
        out["types"].append({k: v for k, v in t.items()
                             if k not in ("has_standard", "points_total")})
    return out


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ
# ---------------------------------------------------------------------------
def load() -> dict:
    """ЄДИНИЙ ЧИТАЧ довідника. Побитий файл не зникає й не затирається: він
    повертається порожнім із причиною, а писар відмовиться писати поверх."""
    if not TYPES_JSON.exists():
        st = _normalize({})
        st["unreadable_reason"] = ""
        return st
    try:
        raw = one_writer.read_json(TYPES_JSON)
        if not isinstance(raw, dict):
            st = _normalize({})
            st["unreadable_reason"] = ("у файлі не довідник типів, а %s"
                                       % type(raw).__name__)
            return st
        st = _normalize(raw)
        st["unreadable_reason"] = ""
        return st
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception as e:
        st = _normalize({})
        st["unreadable_reason"] = "файл не читається: %s" % type(e).__name__
        return st


def types(include_hidden: bool = False) -> list:
    out = load()["types"]
    return out if include_hidden else [t for t in out if t["active"]]


def work_type(type_id: str) -> dict:
    for t in load()["types"]:
        if t["id"] == _s(type_id):
            return t
    return None


def snapshot(type_id: str) -> list:
    """⭐⭐⭐ ЗНІМОК СТАНДАРТУ В МИТЬ, КОЛИ ЗАДАЧУ СТВОРИЛИ.

    Пункти КОПІЮЮТЬСЯ в задачу, а не читаються з довідника наживо. Інакше
    правка довідника тихо переписувала б історію: вчорашня прийнята робота
    заднім числом ставала б неготовою, бо сьогодні до стандарту додали пункт.
    Задача судиться правилами СВОГО часу — той самий закон, що й заморожений
    архівний запис."""
    t = work_type(type_id)
    if not t:
        return []
    return [{"id": p["id"], "text": p["text"], "done": False} for p in t["points"]]


# ---------------------------------------------------------------------------
# ОДИН ПИСАР
# ---------------------------------------------------------------------------
def save(state: dict, reason: str) -> dict:
    if not _s(reason):
        raise WorkTypeError("зміна без причини не пишеться: журнал довідника "
                            "мусить лишатись читабельним")
    on_disk = load()
    if on_disk.get("unreadable_reason"):
        raise WorkTypeError("довідник типів на диску не читається (%s) — писати "
                            "поверх заборонено, поки людина не вирішить його долю"
                            % on_disk["unreadable_reason"])
    st = _normalize(state)
    disk = _strip_derived(st)
    disk["audit"] = list(disk.get("audit") or [])
    disk["audit"].append({"at": clock.now(), "what": _s(reason)[:300]})
    disk["audit"] = disk["audit"][-AUDIT_KEEP:]
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(TYPES_JSON, disk)
    out = _normalize(disk)
    out["unreadable_reason"] = ""
    return out


def _check_points(points) -> list:
    items = _norm_points(points)
    if len(items) > MAX_POINTS:
        raise WorkTypeError("пунктів забагато (%d): стандарт, який не вміщається "
                            "на екран, перестають читати" % len(items))
    return items


def add_type(name: str, points=None) -> dict:
    st = load()
    name = _s(name)
    if not name:
        raise WorkTypeError("тип роботи без назви не заводиться")
    if any(t["name"].lower() == name.lower() for t in st["types"]):
        raise WorkTypeError("тип роботи «%s» уже є: два однакові означали б, що "
                            "стандарт має дві різні відповіді" % name)
    item = {"id": _new_id("wt"), "name": name,
            "points": _check_points(points), "active": True}
    st["types"].append(item)
    save(st, "заведено тип роботи «%s»" % name)
    return work_type(item["id"])


def update_type(type_id: str, name=None, points=None) -> dict:
    st = load()
    by_id = {t["id"]: t for t in st["types"]}
    type_id = _s(type_id)
    if type_id not in by_id:
        raise WorkTypeError("типу роботи «%s» немає" % type_id)
    if name is not None:
        nm = _s(name)
        if not nm:
            raise WorkTypeError("тип роботи без назви не лишається")
        if any(t["name"].lower() == nm.lower() and t["id"] != type_id
               for t in st["types"]):
            raise WorkTypeError("тип роботи «%s» уже є" % nm)
        by_id[type_id]["name"] = nm
    if points is not None:
        by_id[type_id]["points"] = _check_points(points)
    save(st, "змінено тип роботи «%s»" % by_id[type_id]["name"])
    return work_type(type_id)


def set_active(type_id: str, on: bool) -> dict:
    """Тип ХОВАЄТЬСЯ з вибору, а не видаляється: на нього вже можуть посилатись
    задачі, і історія не сміє осиротіти."""
    st = load()
    by_id = {t["id"]: t for t in st["types"]}
    type_id = _s(type_id)
    if type_id not in by_id:
        raise WorkTypeError("типу роботи «%s» немає" % type_id)
    by_id[type_id]["active"] = bool(on)
    save(st, "%s тип роботи «%s»" % ("повернуто у вибір" if on else "приховано",
                                     by_id[type_id]["name"]))
    return work_type(type_id)
