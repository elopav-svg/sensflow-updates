# -*- coding: utf-8 -*-
"""clean_audit_secrets.py — ПРИБРАТИ СЕКРЕТИ ЗІ СТАРОГО ЖУРНАЛУ АУДИТУ.

Зміна 257, 28.08.2026. Код більше не пише в журнал `salt` і `pwd_hash` — але
старі рядки лежать на диску й далі. Цей інструмент переписує журнал ТИМ САМИМ
писарем, що й жива платформа (`audit._safe_record`), — двох правил чистки бути
не може.

⛒ НІЧОГО НЕ ВИДАЛЯЄ: старий файл лишається поруч як
   `_audit.jsonl.БЕКАП_із_секретами_<дата>` — прибрати його може лише людина.
⛒ Рядки НЕ зникають: їх стільки ж, просто без секретів.

Запуск: python clean_audit_secrets.py [--fix]   (без --fix лише показує)
"""
import io
import json
import shutil
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import audit
import config

FIX = "--fix" in sys.argv
PATH = Path(config.RUNS_DIR) / "_audit.jsonl"

if not PATH.exists():
    print("Журналу немає: %s" % PATH)
    sys.exit(0)

lines = PATH.read_text(encoding="utf-8").splitlines()
dirty, out = 0, []
for ln in lines:
    if not ln.strip():
        continue
    try:
        rec = json.loads(ln)
    except Exception:
        out.append(ln)          # чужий рядок не чіпаємо
        continue
    safe = {"ts": rec.get("ts")}
    safe.update(audit._safe_record({k: v for k, v in rec.items() if k != "ts"}))
    if json.dumps(safe, ensure_ascii=False, sort_keys=True) != \
            json.dumps(rec, ensure_ascii=False, sort_keys=True):
        dirty += 1
    out.append(json.dumps(safe, ensure_ascii=False))

print("Журнал: %s" % PATH)
print("Рядків: %d · із секретами або зайвим: %d" % (len(out), dirty))
if not dirty:
    print("Чисто — робити нічого.")
    sys.exit(0)
if not FIX:
    print("Це показ. Щоб переписати — запусти з --fix (старий файл лишиться поруч).")
    sys.exit(0)

bak = PATH.with_name("_audit.jsonl.БЕКАП_із_секретами_%s" % time.strftime("%Y-%m-%d"))
if not bak.exists():
    shutil.copy2(PATH, bak)
io.open(PATH, "w", encoding="utf-8", newline="\n").write("\n".join(out) + "\n")
print("ГОТОВО. Рядків збережено: %d. Старий файл: %s" % (len(out), bak.name))
print("⚠ Бекап зі старими секретами лежить поруч — видалити його можеш лише ти.")
