# -*- coding: utf-8 -*-
"""
taskdesk_events.py — НЕРВ TASK DESK: журнал подій, черга і курсори ротів.

КОРІНЬ, ЯКИЙ ЦЕ ЛІКУЄ (08.08.2026). Екран задач був НІМИЙ: у жодному файлі
`taskdesk_*` не було сповіщень. Людина дізнавалась про свою задачу, лише якщо
САМА відкривала екран. Рішення Андрія про «прохання коментарем + повідомлення
тому, хто має право» уже обіцяло повідомлення, якого не існувало.

Це не «забули додати». Це відсутність шару, чия робота — знати, ЩО сталося
і КОГО це стосується.

⭐⭐⭐ ЗАКОН: **ЗАДАЧУ НЕ МОЖНА ЗБЕРЕГТИ БЕЗ ПОДІЇ.**
Подія — не додатковий виклик «а ще повідом» поруч зі збереженням (це було б
правило в промпті: одне забуте місце — і зміна тиха), а ОБОВʼЯЗКОВИЙ параметр
`taskdesk_tasks.save()`. Забути неможливо: без події задача не збережеться.

ТРИ ШАРИ, І ЦЕЙ ФАЙЛ — ЛИШЕ ОДИН З НИХ:
  1. ПОДІЯ    — що сталося: ВИД + машинні ДЕТАЛІ. Тут.
  2. АДРЕСАТИ — кого це стосується. Живе в `taskdesk_tasks.recipients()`, поруч
                з `ACTION_ROLES`: ролі — це домен задачі, і другої таблиці
                ролей бути не може.
  3. РОТИ     — хто доносить (телеграм, далі пошта, дзвіночок). Кожен рот веде
                СВІЙ курсор. Для закритого контуру рот просто не вмикається —
                саме тому роти відокремлені від нерва.

⚠ ЦЕЙ ФАЙЛ НЕ ІМПОРТУЄ `taskdesk_tasks` — інакше вийшло б коло. Він нічого не
знає ні про стадії, ні про ролі: йому приносять готову подію з адресатами.

⚠ ТЕКСТ ЛЮДИНІ ТУТ НЕ ЖИВЕ. У журналі лежать ВИД і ДЕТАЛІ. Слід у задачі малює
`taskdesk_tasks._reason()`, повідомлення в чат малюватиме рот. Це НЕ два писарі
однієї правди: правда одна (вид + деталі), а читачі різні.

⚠ МОЗОК (LLM) СЮДИ НЕ ХОДИТЬ. Черга, курсори й склеювання — логічні скрипти.
"""

import json
import sys
from datetime import datetime
from pathlib import Path

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import one_writer

DESK_DIR = config.STATE_DIR / "taskdesk"

# ⛒ ДРУГИЙ ЗАМОК (27.08.2026): чек, завантажений не через файл, не сміє
# працювати по бойовому стану — тут лежать живі люди, ролі й задачі.
config.refuse_live_state_for_checks(__name__)
JOURNAL = DESK_DIR / "events.jsonl"
SINKS = DESK_DIR / "sinks.json"
LOST = DESK_DIR / "events_lost.log"

# Скільки подій тримати в журналі понад те, що вже забрали ВСІ роти.
KEEP_AFTER_DELIVERED = 2000

# Вікно склеювання: серія дрібних подій по одній задачі в межах цього часу —
# ОДНЕ повідомлення. Бот, який шумить, вимикають — і тоді нерв марний.
COALESCE_SEC = 120


class EventError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


# ---------------------------------------------------------------------------
# СЛОВНИК ПОДІЙ. Тут лише те, що СПРАВДІ хтось народжує — вид без виробника
# був би обіцянкою, не покритою фактом.
# ---------------------------------------------------------------------------
KIND_CREATED = "created"            # задачу створено
KIND_COMMENT = "comment"            # коментар у стрічці
KIND_RESULT = "result"              # позначено результат
KIND_VERIFIED = "verified"          # результат перевірено (там, де є перевіряючий)
KIND_STAGE = "stage"                # стадія змінилась
KIND_DELEGATED = "delegated"        # змінився виконавець
KIND_REFUSED = "refused"            # відмова з причиною
KIND_UPDATED = "updated"            # правка тексту, термінів, складу
KIND_PROPOSAL = "proposal"          # мозок ПРОПОНУЄ (нічого не змінив)
KIND_PROPOSAL_DONE = "proposal_done"  # пропозицію прийняли або відхилили
KIND_CHECKLIST = "checklist"        # пункт плану
# ⭐ Стандарт готовності (зміна 225) — ОКРЕМИЙ вид події, а не «ще один
# пункт плану». Чек-лист каже ЯК робити, стандарт — ЗА ЧИМ приймемо; один
# вид на два смисли зробив би журнал нечитабельним для обох.
KIND_DOD = "dod"                    # пункт стандарту готовності
KIND_LINKED = "linked"              # задачу звʼязали з іншою сутністю
KIND_UNLINKED = "unlinked"          # звʼязок прибрали
# ⭐ ПРОТЕРМІНУВАННЯ — ПОДІЯ, А НЕ КАРТИНКА (зміна 172). Досі `overdue`
# рахувався в момент читання і ніде не зберігався: задача, що провисіла
# простроченою пʼять днів, після закриття не лишала ЖОДНОГО сліду.
# Народжує його сторож `taskdesk_overdue` — рівно один раз на перетин строку.
KIND_OVERDUE = "overdue"            # строк минув, а задача жива

KINDS_ALL = (KIND_CREATED, KIND_COMMENT, KIND_RESULT, KIND_VERIFIED, KIND_STAGE,
             KIND_DELEGATED, KIND_REFUSED, KIND_UPDATED, KIND_PROPOSAL,
             KIND_PROPOSAL_DONE, KIND_CHECKLIST, KIND_DOD,
             KIND_LINKED, KIND_UNLINKED, KIND_OVERDUE)

KIND_NAMES = {
    KIND_CREATED: "задачу створено",
    KIND_COMMENT: "коментар",
    KIND_RESULT: "результат",
    KIND_VERIFIED: "результат перевірено",
    KIND_STAGE: "стадія",
    KIND_DELEGATED: "зміна виконавця",
    KIND_REFUSED: "відмова",
    KIND_UPDATED: "правка задачі",
    KIND_PROPOSAL: "пропозиція мозку",
    KIND_PROPOSAL_DONE: "рішення щодо пропозиції",
    KIND_CHECKLIST: "пункт плану",
    KIND_DOD: "стандарт готовності",
    KIND_LINKED: "звʼязок задачі",
    KIND_UNLINKED: "звʼязок прибрано",
    KIND_OVERDUE: "строк минув",
}


def event(kind: str, **details) -> dict:
    """Конструктор події. Невідомий вид — відмова з причиною, а не мовчазний
    пропуск: подія, якої ніхто не назвав, нікуди й не дійде."""
    kind = ("" if kind is None else str(kind)).strip()
    if kind not in KINDS_ALL:
        raise EventError("Невідомий вид події «%s». Відомі: %s"
                         % (kind, ", ".join(KINDS_ALL)))
    return {"kind": kind, "details": dict(details)}


def parts(ev) -> tuple:
    """(вид, деталі) з події. Усе, що не подія, — відмова з причиною.

    ⭐ Це і є ворота: `save()` кличе саме її, тому передати текстову причину
    замість події фізично не вийде."""
    if not isinstance(ev, dict) or "kind" not in ev:
        raise EventError(
            "Задачу не зберегти без ПОДІЇ: замість неї передали %s. "
            "Подію робить taskdesk_events.event(вид, ...)." % type(ev).__name__)
    kind = ("" if ev.get("kind") is None else str(ev["kind"])).strip()
    if kind not in KINDS_ALL:
        raise EventError("Невідомий вид події «%s». Відомі: %s"
                         % (kind, ", ".join(KINDS_ALL)))
    det = ev.get("details") or {}
    if not isinstance(det, dict):
        raise EventError("Деталі події мають бути набором полів, а не %s."
                         % type(det).__name__)
    return kind, det


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ ЖУРНАЛУ
# ---------------------------------------------------------------------------
def _read_all() -> list:
    """Журнал з диска. Побитий рядок НЕ ковтаємо мовчки — кажемо про нього."""
    if not JOURNAL.exists():
        return []
    out = []
    for n, line in enumerate(one_writer.read_text(JOURNAL).splitlines(), 1):
        line = line.strip()
        if not line:
            continue
        try:
            rec = json.loads(line)
        except Exception as e:
            sys.stderr.write("[нерв] рядок %d журналу подій не читається: %s\n" % (n, e))
            continue
        if isinstance(rec, dict) and rec.get("id"):
            out.append(rec)
    return out


def all_events() -> list:
    return _read_all()


def last_id() -> int:
    evs = _read_all()
    return int(evs[-1]["id"]) if evs else 0


# ---------------------------------------------------------------------------
# ОДИН ПИСАР ЖУРНАЛУ
# ---------------------------------------------------------------------------
def emit(kind: str, task_id: str, actor_id: str, details: dict,
         to, title: str = "", digest=None) -> dict:
    """Записати подію. Адресатів рахує НЕ цей файл — їх приносять готовими.

    ⭐ Адресати рахуються В МОМЕНТ ПОДІЇ і лягають у журнал. Доставка може
    статись через добу, коли склад учасників уже інший: людина, яку прибрали з
    задачі, все одно мала право знати про те, що сталось при ній, а нового
    учасника не заливає історією."""
    if kind not in KINDS_ALL:
        raise EventError("Невідомий вид події «%s»." % kind)
    rec = {
        "id": last_id() + 1,
        "at": clock.now(),
        "kind": kind,
        "task_id": ("" if task_id is None else str(task_id)).strip(),
        "task_title": ("" if title is None else str(title))[:200],
        "actor_id": ("" if actor_id is None else str(actor_id)).strip(),
        "details": dict(details or {}),
        "to": [str(x) for x in (to or []) if str(x).strip()],
        # ⭐ Кому це йде НЕ ЗАРАЗ, а у зведенні (зміна 241). Лежить у ТІЙ САМІЙ
        # події: два журнали однієї правди розійшлися б на першому ж збої.
        "digest": [str(x) for x in (digest or []) if str(x).strip()],
    }
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    with JOURNAL.open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec


def lost(rec: dict, why: str):
    """Подія, яку не вдалося записати, НЕ зникає мовчки: вона лягає окремим
    слідом, звідки її можна повторити. Тихий успіх — те, що вбиває продукт."""
    try:
        DESK_DIR.mkdir(parents=True, exist_ok=True)
        with LOST.open("a", encoding="utf-8") as f:
            f.write(json.dumps({"at": clock.now(), "why": str(why),
                                "event": rec}, ensure_ascii=False) + "\n")
    except Exception as e:
        sys.stderr.write("[нерв] не зберегти навіть слід втрати: %s\n" % e)
    sys.stderr.write("[нерв] ПОДІЮ НЕ ЗАПИСАНО (%s): %s\n" % (why, rec))


# ---------------------------------------------------------------------------
# РОТИ: у кожного СВІЙ курсор. Один рот не бачить чужого.
# ---------------------------------------------------------------------------
def _load_sinks() -> dict:
    try:
        d = one_writer.read_json(SINKS)
        return d if isinstance(d, dict) else {}
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        return {}


def _save_sinks(d: dict):
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(SINKS, d)


def sinks() -> dict:
    return _load_sinks()


def cursor(sink: str) -> int:
    return int(_load_sinks().get(str(sink), 0))


def register(sink: str, from_now: bool = True) -> int:
    """Новий рот НЕ отримує всю історію: інакше перший запуск бота вивалить
    людині кількасот старих подій. За замовчуванням він починає з «зараз»."""
    sink = str(sink).strip()
    if not sink:
        raise EventError("У рота має бути імʼя.")
    d = _load_sinks()
    if sink not in d:
        d[sink] = last_id() if from_now else 0
        _save_sinks(d)
    return int(d[sink])


def pending(sink: str, limit: int = 200) -> list:
    """Що цей рот ще не доніс."""
    c = cursor(sink)
    return [e for e in _read_all() if int(e["id"]) > c][:max(1, int(limit))]


def ack(sink: str, event_id: int) -> int:
    """Курсор рухається ЛИШЕ після успішної доставки і ЛИШЕ вперед.

    ⭐ Це і є «одна подія — одне повідомлення»: якщо доставка впала посеред
    пачки, курсор лишився на останньому УСПІШНОМУ, і наступний прогін
    відправить тільки невідправлене — не всю пачку вдруге."""
    sink = str(sink).strip()
    d = _load_sinks()
    was = int(d.get(sink, 0))
    now = int(event_id)
    if now > was:
        d[sink] = now
        _save_sinks(d)
    return int(d.get(sink, was))


def prune() -> dict:
    """Прибирає лише те, що ЗАБРАЛИ ВСІ роти. Немає жодного рота — не чіпаємо
    нічого: інакше журнал спорожнів би раніше, ніж зʼявився перший бот."""
    d = _load_sinks()
    evs = _read_all()
    if not d or not evs:
        return {"removed": 0, "kept": len(evs), "reason": "ротів немає — не чіпаю"}
    safe = min(int(v) for v in d.values())
    keep = [e for e in evs if int(e["id"]) > safe - KEEP_AFTER_DELIVERED]
    removed = len(evs) - len(keep)
    if removed > 0:
        DESK_DIR.mkdir(parents=True, exist_ok=True)
        one_writer.write_text(
            JOURNAL, "".join(json.dumps(e, ensure_ascii=False) + "\n" for e in keep))
    return {"removed": removed, "kept": len(keep), "safe_below": safe}


# ---------------------------------------------------------------------------
# СКЛЕЮВАННЯ. Пʼять коментарів за хвилину — одне повідомлення.
# ---------------------------------------------------------------------------
def _dt(s: str):
    try:
        return datetime.fromisoformat(str(s))
    except Exception:
        return None


def coalesce(evs: list, window_sec: int = COALESCE_SEC) -> list:
    """Групи подій, які варто донести ОДНИМ повідомленням: та сама задача, той
    самий вид, у межах вікна. Порядок зберігається, нічого не губиться —
    кількість подій у групах завжди дорівнює кількості на вході."""
    groups = []
    for e in evs:
        placed = False
        for g in reversed(groups):
            same = (g[-1].get("task_id") == e.get("task_id")
                    and g[-1].get("kind") == e.get("kind"))
            if not same:
                continue
            a, b = _dt(g[-1].get("at")), _dt(e.get("at"))
            if a is None or b is None:
                continue
            if abs((b - a).total_seconds()) <= int(window_sec):
                g.append(e)
                placed = True
            break
        if not placed:
            groups.append([e])
    return groups


def snapshot() -> dict:
    """Стан нерва одним поглядом — для консолі й для чеків."""
    evs = _read_all()
    return {"events": len(evs), "last_id": int(evs[-1]["id"]) if evs else 0,
            "sinks": _load_sinks(), "journal": str(JOURNAL),
            "lost": LOST.exists()}
