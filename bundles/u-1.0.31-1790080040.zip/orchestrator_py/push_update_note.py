# -*- coding: utf-8 -*-
"""push_update_note.py — КОРОТКИЙ ПУШ КЛІЄНТУ: «вийшло оновлення, ось що в ньому».

ЧОМУ ЦЕ ОКРЕМИЙ КАНАЛ, А НЕ notify_client_update.
    Це два РІЗНІ жанри, і плутати їх — помилка.
      • Повний опис змін їде до клієнта ЗВИЧАЙНИМ МАРШРУТОМ: маніфест → консоль
        клієнта, поруч із кнопкою «Оновити». Там людина читає докладно.
      • Telegram — це ПУШ. Його завдання: людина побачила, що вийшло оновлення,
        і за 10 секунд зрозуміла, що в ньому. Довгий текст у пуші не читають.
    notify_client_update.py шле в Telegram повний опис із маніфесту. Для цього
    каналу це завелико.

ЩОБ КОРОТКЕ Й ПОВНЕ НЕ РОЗІЙШЛИСЬ, ПИСАР ЛИШАЄТЬСЯ ОДИН — РЕЛІЗ.
    Текст пуша живе НЕ в коді й не в батнику, а поруч із описом релізу:
        release_notes/<версія>.push.txt
    Тобто там само, де пишеться сам реліз, і однією рукою з ним. Код звідси
    тексту не додає й не вигадує.

ВОРОТА (fail-closed, кожне каже причину словами):
  1) немає привʼязки Telegram у CRM        → СТОП (краще не надіслати, ніж чужому);
  2) маніфест клієнта не на версії збірки   → СТОП (не оголошуємо неопубліковане);
  3) немає файлу пуша для цієї версії       → СТОП;
  4) текст довший за межу                   → СТОП (це вже опис, а не пуш).

Запуск:  python push_update_note.py --customer Casper [--dry-run]
"""
import argparse
import sys
from pathlib import Path

import config
import crm
import publish_update as pu
import telegram_bot as tb

# Формат запису в журналі CRM — ОДИН на запис і на читання.
HIST_PREFIX = "Telegram: пуш про оновлення "

# ⭐ МЕЖА — НЕ КОСМЕТИКА. Вона робить фізично неможливим перетворити пуш на
# другий опис змін. Розійтись із маніфестом може лише те, що дозволили довгим.
PUSH_MAX = 900


class Stop(Exception):
    """Зупинка, яка називає себе вголос і нічого не відправляє."""


def push_path(version: str) -> Path:
    return (Path(__file__).resolve().parent.parent
            / "release_notes" / ("%s.push.txt" % version))


def manifest_version(name: str) -> str:
    mp = (Path(__file__).resolve().parent.parent / "sensflow-updates"
          / "manifests" / ("%s.json" % pu.cust_hash(name)))
    if not mp.exists():
        raise Stop("немає маніфесту %s — цій людині ще нічого не публікували."
                   % mp.name)
    import json
    try:
        return str(json.loads(mp.read_text(encoding="utf-8")).get("version") or "")
    except Exception as e:
        raise Stop("маніфест %s не читається (%s)." % (mp.name, e))


def build_push(name: str, version: str) -> str:
    mver = manifest_version(name)
    if mver != version:
        raise Stop("маніфест клієнта на версії %s, а збірка — %s.\n"
                   "      Спершу опублікуйте оновлення, потім оголошуйте його."
                   % (mver or "?", version))

    p = push_path(version)
    if not p.exists():
        raise Stop("немає файлу пуша %s.\n"
                   "      Короткий текст пишеться поруч з описом релізу, "
                   "а не в коді." % p.name)

    text = p.read_text(encoding="utf-8").strip()
    if not text:
        raise Stop("файл пуша %s порожній." % p.name)
    if len(text) > PUSH_MAX:
        raise Stop("текст пуша %d символів, межа %d — це вже опис змін.\n"
                   "      Докладне клієнт читає в консолі біля кнопки «Оновити»."
                   % (len(text), PUSH_MAX))
    return text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--customer", default="Casper")
    ap.add_argument("--dry-run", action="store_true",
                    help="показати і НЕ відправляти")
    a = ap.parse_args()

    name, why = pu.canon_customer(a.customer)
    if not name:
        print("  [X] STOP: %s" % why)
        sys.exit(2)

    chat_id = crm.channels_of(name).get("telegram_id") or ""
    if not chat_id:
        print("  [X] STOP: у картці «%s» немає привʼязаного Telegram." % name)
        sys.exit(2)

    try:
        text = build_push(name, config.APP_VERSION)
    except Stop as e:
        print("  [X] STOP: %s" % e)
        sys.exit(2)

    print("=" * 60)
    print("  Клієнт : %s" % name)
    print("  Чат    : %s" % chat_id)
    print("  Версія : %s" % config.APP_VERSION)
    print("  Джерело: release_notes/%s.push.txt (%d символів)"
          % (config.APP_VERSION, len(text)))
    print("=" * 60)
    print(text)
    print("=" * 60)

    if a.dry_run:
        print("DRY-RUN: нічого не відправлено.")
        return

    token = tb._support_token()
    if not token:
        print("  [X] STOP: не налаштований токен бота підтримки "
              "(TELEGRAM_SUPPORT_BOT_TOKEN).")
        sys.exit(2)

    tb._ctx.token = token
    tb._ctx.role = "support"
    if not tb._send_message(chat_id, text):
        print("  [X] FAILED: Telegram не прийняв повідомлення. Причина — вище.")
        sys.exit(1)

    try:
        crm.add_history(name, "outbound", HIST_PREFIX + config.APP_VERSION)
    except Exception as e:
        print("  [!] Надіслано, але запис у журнал CRM не ліг: %s" % e)
    print("  [OK] Надіслано і записано в журнал CRM.")


if __name__ == "__main__":
    main()
