# -*- coding: utf-8 -*-
from pathlib import Path


def patch(fname, pairs):
    p = Path(fname)
    raw = p.read_bytes().decode("utf-8")
    crlf = "\r\n" in raw
    for tag, old, new in pairs:
        o = old.replace("\n", "\r\n") if crlf else old
        n = new.replace("\n", "\r\n") if crlf else new
        assert raw.count(o) == 1, "%s/%s: якорів %d" % (fname, tag, raw.count(o))
        raw = raw.replace(o, n)
    p.write_bytes(raw.encode("utf-8"))
    print("%s: правки внесено (CRLF=%s)" % (fname, crlf))


patch("llm.py", [
    ("памʼять",
     '_NO_THINKING_MODELS = set()   # заготовка 605 — ще нічого не робить',
     '''# ⭐⭐⭐ 605 (17.09.2026). У ВІДПОВІДІ МУСИТЬ ЛИШИТИСЬ БЮДЖЕТ.
# Живий прогін 15:29: складальник фінансової моделі закрив потік за 293 с,
# віддав ОДИН блок без тексту і чесне «обірвано межею». Модель витратила ВЕСЬ
# бюджет виводу (16 000) на роздуми і не написала жодного знака — бюджет був
# один на роздуми й на відповідь, і хто перший устиг, той і зʼїв. Тепер
# роздумам дається ЯВНА менша межа, і відповіді фізично лишається місце.
# Модель, яка такої межі не приймає, не мусить падати: її запамʼятовують тут.
_NO_THINKING_MODELS = set()
THINK_SHARE = 0.4          # яку частку бюджету віддаємо роздумам
THINK_MIN = 1024           # менше за це провайдер не приймає


def _thinking_for(mdl: str, max_tokens: int, stream: bool):
    """Межа роздумів для ВАЖКОГО виклику або None. Дрібні швидкі виклики не
    чіпаємо: там роздумів на весь бюджет не буває, а зайвий параметр — це
    зайвий клас відмов."""
    if not stream or (mdl in _NO_THINKING_MODELS):
        return None
    try:
        mt = int(max_tokens or 0)
    except Exception:
        return None
    if mt < 4 * THINK_MIN:
        return None
    budget = max(THINK_MIN, int(mt * THINK_SHARE))
    if budget > mt - THINK_MIN:
        budget = mt - THINK_MIN
    if budget < THINK_MIN:
        return None
    return {"type": "enabled", "budget_tokens": budget}'''),
    ("payload",
     '''    def _payload(use_cache, with_temp):
        # Кешування великого системного промпту: повторні виклики з тим самим
        # system стають значно швидші й дешевші (prompt caching).
        sys_field = _sys_field(system, use_cache)
        p = {
            "model": mdl,
            "system": sys_field,
            "messages": [{"role": "user", "content": user}],
            "max_tokens": max_tokens,
        }
        if with_temp and mdl not in _NO_TEMPERATURE_MODELS:
            p["temperature"] = temperature
        return p''',
     '''    def _payload(use_cache, with_temp, with_think=True):
        # Кешування великого системного промпту: повторні виклики з тим самим
        # system стають значно швидші й дешевші (prompt caching).
        sys_field = _sys_field(system, use_cache)
        p = {
            "model": mdl,
            "system": sys_field,
            "messages": [{"role": "user", "content": user}],
            "max_tokens": max_tokens,
        }
        # ⭐ 605: межа роздумів і температура разом не їздять — провайдер вимагає
        # сталої температури, коли роздуми названі явно. Тому вибір один.
        think = _thinking_for(mdl, max_tokens, stream) if with_think else None
        if think:
            p["thinking"] = think
        elif with_temp and mdl not in _NO_TEMPERATURE_MODELS:
            p["temperature"] = temperature
        return p'''),
    ("виклик",
     '''    try:
        data = _post(_payload(True, True))
    except LLMError as e:
        s = str(e)
        # 400 може бути через кешування АБО через непідтримуваний temperature — прибираємо обидва.
        if "HTTP 400" in s:
            if "temperature" in s.lower():
                _NO_TEMPERATURE_MODELS.add(mdl)
                _log(f"[llm] anthropic: {mdl} не приймає temperature — далі без нього")
            _log("[llm] anthropic: повтор без prompt-caching/temperature")
            data = _post(_payload(False, False))
        else:
            raise''',
     '''    try:
        data = _post(_payload(True, True))
    except LLMError as e:
        s = str(e)
        # 400 може бути через кешування, через непідтримуваний temperature АБО
        # через межу роздумів — прибираємо всі три й памʼятаємо причину.
        if "HTTP 400" in s:
            if "temperature" in s.lower():
                _NO_TEMPERATURE_MODELS.add(mdl)
                _log(f"[llm] anthropic: {mdl} не приймає temperature — далі без нього")
            if "thinking" in s.lower():
                _NO_THINKING_MODELS.add(mdl)
                _log(f"[llm] anthropic: {mdl} не приймає межі роздумів — далі без неї")
            _log("[llm] anthropic: повтор без prompt-caching/temperature/межі роздумів")
            data = _post(_payload(False, False, False))
        else:
            raise'''),
])

patch("executor.py", [
    ("ланцюг",
     '''    if high_stakes:
        add(config.brain_model())
        add(config.worker_model())
    else:
        add(config.worker_model())
        add(config.brain_model())
    for m in _cross_provider_reserve():
        add(m)
    return models''',
     '''    if high_stakes:
        # ⭐⭐⭐ 605 (17.09.2026). РЕЗЕРВ НА ВИСОКИХ СТАВКАХ МУСИТЬ БУТИ СИЛЬНИМ.
        # Живий прогін 15:29: мозок віддав порожню відповідь, і фінал ФІНАНСОВОЇ
        # моделі поїхала збирати найдешевша модель у крамниці — одразу після
        # мозку. Вона ж потім вигадала назви колонок і коштувала колом
        # виправлень. Для високих ставок «резерв» — це топ-моделі ІНШИХ
        # провайдерів; дешева робоча модель лишається ОСТАННІМ шансом, щоб
        # людина не лишилась без відповіді взагалі (слово власника 01.08.2026).
        add(config.brain_model())
        for m in _cross_provider_reserve():
            add(m)
        add(config.worker_model())
        return models
    add(config.worker_model())
    add(config.brain_model())
    for m in _cross_provider_reserve():
        add(m)
    return models'''),
])
