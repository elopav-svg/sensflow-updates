# -*- coding: utf-8 -*-
"""card_fields.py — БУДОВА КАРТОК: ОГОЛОШЕНІ ПОЛЯ (зміна 452, 02.09.2026).

⭐⭐⭐ НАВІЩО (слово Андрія 02.09.2026): «Ми з тобою ніколи не вигадаєм зручну для
всіх універсальну картку задачі, угоди, контакту. Ці картки — суто особлива
сутність для кожної компанії, і кожна компанія повинна мати можливість створити
собі ідеальну картку саме для себе. А для того, щоб не допустити хаосу, писар
повинен бути один — адміністратор системи.»

⭐⭐⭐ ОДИН МЕХАНІЗМ НА ВСІ КАРТКИ, А НЕ ПОЛЯ ДЛЯ ТОВАРУ. Та сама машинерія
потрібна угоді, задачі й контрагенту. Написати її «під товар» означало б писати
вдруге для угоди й утретє для задачі — рівно та хвороба двох писарів однієї
правди, від якої ми лікували екран CRM.

⭐ І ДРУГА ПРИЧИНА, менш очевидна: **оголошені поля — умова роботи ШІ.** Задум
Андрія — щоб ШІ витягав дані зі специфікації й дозаповнював картку угоди. Щоб
йому було КУДИ класти, поле має бути оголошене. У вільні пари «назва-значення»
ШІ щоразу напише по-різному; в оголошене поле — рівно те, що оголошено.

⛒ ПРАВА ТУТ НЕ ЖИВУТЬ. Хто має право міняти будову — вирішують ДВЕРІ, як і
всюди. Дозвіл адміністратора зʼявиться разом із ними: у `taskdesk_roles`
законом записано, що дозвіл без своїх воріт — декорація.

⛒ ЩО ТУТ НАВМИСНО ЗАБОРОНЕНО, І ЧОМУ:
  • **ТИП ПОЛЯ НЕ МІНЯЄТЬСЯ НІКОЛИ.** Текст, у якому вже лежить «близько 5 кг»,
    не стає числом — він стає СМІТТЯМ. Треба інший тип — заводять нове поле, а
    старе перестає діяти. Так само, як номер сутності.
  • **МНОЖИННІСТЬ ВМИКАЄТЬСЯ, АЛЕ НЕ ВИМИКАЄТЬСЯ.** З одного значення список
    робиться без втрат; зі списку одне значення — з втратою чотирьох із пʼяти.
  • **ПОЛЕ НЕ ВИДАЛЯЄТЬСЯ**, а перестає діяти: разом із ним зникли б дані, які
    люди вже занесли.
  • **ДВА ПОЛЯ З ОДНАКОВОЮ НАЗВОЮ В ОДНІЙ КАРТЦІ — ВІДМОВА.** Саме через це ми
    відмовились від вільних пар: «Обʼєм» і «обєм» як дві різні характеристики —
    це той самий хаос, від якого нас має вберегти єдиний писар.

⛒ ВЖИТЕ ЗНАЧЕННЯ СПИСКУ НЕ ПРИБИРАЄТЬСЯ (зміна 453). Прибрати значення, яке
вже лежить у чиїйсь картці, — це лишити там те, чого немає в переліку. Відмова
називає, які саме значення заважають.
"""
import json
import one_writer

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import entity                     # спільне імʼя сутності на всю платформу
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій

config.refuse_live_state_for_checks(__name__)

DIR = config.STATE_DIR / "state"
FIELDS_JSON = DIR / "card_fields.json"

# ── ЯКІ КАРТКИ МОЖНА РОЗШИРЮВАТИ ────────────────────────────────────────────
# ⛒ Перелік СВІДОМИЙ (fail-closed): картка, якої тут немає, полів не дістає.
# Забути дописати сюди нову картку означає лише, що вона не розширюється;
# зворотна помилка — поля на прогоні чи на конекторі — була б безглуздям.
CARDS = (entity.KIND_DEAL, entity.KIND_PARTY, entity.KIND_TASK, entity.KIND_GOOD)

# ── ТИПИ ПОЛІВ ──────────────────────────────────────────────────────────────
T_TEXT = "text"
T_NUMBER = "number"
T_DATE = "date"
T_YESNO = "yesno"
T_LIST = "list"
T_FILE = "file"
TYPES = (T_TEXT, T_NUMBER, T_DATE, T_YESNO, T_LIST, T_FILE)
TYPE_NAMES = {
    T_TEXT: "текст",
    T_NUMBER: "число",
    T_DATE: "дата",
    T_YESNO: "так або ні",
    T_LIST: "список значень",
    T_FILE: "файл",
}

F_ACTIVE = "active"

# ⭐⭐⭐ 593 (16.09.2026). ЗАЛЕЖНИЙ СПИСОК.
# Слово Андрія: у картці угоди два списки — «Напрям угоди» (продаж/закупівля) і
# категорія, значення якої МІНЯЮТЬСЯ ВІДПОВІДНО ДО НАПРЯМУ, а наповнює їх
# адміністратор клієнта (у кожного свій асортимент).
# ⛒ ЛІКУЄМО КЛАС, А НЕ ДВА ПОЛЯ. Зашити «продаж/закупівля» в код означало б, що
# наступну таку пару (регіон → місто, тип техніки → модель) доведеться зашивати
# знову. Тому будова карток вчиться одному: СПИСОК МОЖЕ ЗАЛЕЖАТИ ВІД СПИСКУ.
F_PARENT = "parent"          # id поля-списку, від якого залежать значення
F_CHOICES_BY = "choices_by"  # {значення батька: [дозволені значення]}

# ⛒ ВБУДОВАНІ ПОЛЯ — ДАНІ, А НЕ ЗАПИС НА ДИСКУ. Той самий прийом, що й у
# вбудованих ролей: поле є завжди, доки його не змінили; щойно змінили —
# лягає у файл і живе як звичайне. Номери сталі, бо на них посилається
# залежність.
BF_DIRECTION = "bf-deal-direction"
BF_CATEGORY = "bf-deal-category"

BUILTIN_FIELDS = [
    {"id": BF_DIRECTION, "card": entity.KIND_DEAL, "name": "Напрям угоди",
     "type": T_LIST, "many": False, "choices": ["продаж", "закупівля"],
     "hint": "Продаємо ми чи купуємо — від цього залежить категорія.",
     "order": 10, F_ACTIVE: True, F_PARENT: "", F_CHOICES_BY: {}},
    # ⛒ Приходить ПОРОЖНЬОЮ і це свідомо: асортимент у кожного клієнта свій,
    # і вигаданий нами перелік довелось би стирати руками в кожній збірці.
    {"id": BF_CATEGORY, "card": entity.KIND_DEAL, "name": "Категорія угоди",
     "type": T_LIST, "many": False, "choices": [],
     "hint": "Групи асортименту. Наповнює адміністратор компанії.",
     "order": 11, F_ACTIVE: True, F_PARENT: BF_DIRECTION, F_CHOICES_BY: {}},
]
BUILTIN_IDS = tuple(f["id"] for f in BUILTIN_FIELDS)


class FieldError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _load() -> dict:
    try:
        d = one_writer.read_json(FIELDS_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("seq", 0)
    d.setdefault("fields", {})
    return d


def _save(d: dict) -> None:
    FIELDS_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(FIELDS_JSON, d)


def _new_id(d: dict) -> str:
    seq = int(d.get("seq") or 0) + 1
    while ("f%04d" % seq) in d["fields"]:
        seq += 1
    d["seq"] = seq
    return "f%04d" % seq


def ref(fid) -> str:
    return entity.ref(entity.KIND_FIELD, _s(fid))


def _to_protocol(action: str, fid: str, what: str) -> None:
    try:
        protocol.write(action, ref(fid), note=what)
    except Exception:
        pass


# ── ЧИТАННЯ ─────────────────────────────────────────────────────────────────
def _materialize(fid) -> None:
    """Вбудоване поле, яке щойно вперше змінили, лягає у файл і живе як своє.

    ⛒ Доти воно існує лише як ДАНІ в коді. Записати його наперед означало б
    насмітити в реєстрі кожного клієнта полями, яких він не заводив."""
    key = _s(fid)
    d = _load()
    if key in d["fields"]:
        return
    b = _builtin(key)
    if not b:
        return
    now = clock.now()
    b = dict(b)
    b["created"] = now
    b["updated"] = now
    d["fields"][key] = b
    _save(d)


def exists(fid) -> bool:
    return _s(fid) in _load()["fields"]


def _builtin(fid):
    for b in BUILTIN_FIELDS:
        if b["id"] == _s(fid):
            return dict(b)
    return None


def get(fid):
    f = _load()["fields"].get(_s(fid))
    if not f:
        f = _builtin(fid)          # ⭐ 593: вбудоване поле є, доки його не чіпали
    if not f:
        return None
    out = dict(f)
    out.setdefault(F_PARENT, "")
    out.setdefault(F_CHOICES_BY, {})
    return out


def title(fid) -> str:
    return _s((get(fid) or {}).get("name"))


def is_active(f) -> bool:
    """ОДИН ЧИТАЧ: відсутність поля означає «діє», а не «невідомо»."""
    if isinstance(f, str):
        f = _load()["fields"].get(_s(f)) or {}
    return bool((f or {}).get(F_ACTIVE, True))


def by_name(card: str, name) -> str:
    """Номер поля з такою назвою в цій картці («» — такого немає)."""
    c, low = _s(card), _s(name).casefold()
    if not low:
        return ""
    for fid, f in _load()["fields"].items():
        if _s(f.get("card")) == c and _s(f.get("name")).casefold() == low:
            return fid
    return ""


def all_fields(card: str = "", active=None) -> list:
    """Оголошені поля; за потреби — однієї картки або одного стану."""
    c = _s(card)
    if c:
        check_card(c)
    have = _load()["fields"]
    rows = [dict(f) for f in have.values()]
    # ⛒ Вбудоване поле зʼявляється лише тоді, коли його ще не чіпали: щойно
    # адміністратор його змінив або вимкнув, у файлі лежить його версія, і
    # вона головна. Інакше вимкнене поле воскресало б щоразу.
    for b in BUILTIN_FIELDS:
        if b["id"] not in have:
            rows.append(dict(b))
    out = []
    for f in rows:
        f.setdefault(F_PARENT, "")
        f.setdefault(F_CHOICES_BY, {})
        if c and _s(f.get("card")) != c:
            continue
        if active is not None and is_active(f) != bool(active):
            continue
        out.append(f)
    out.sort(key=lambda x: (int(x.get("order") or 0), _s(x.get("name")).casefold()))
    return out


def layout(card: str) -> list:
    """⭐ БУДОВА КАРТКИ: що саме показувати й питати. Читає екран."""
    return all_fields(card, active=True)


def count(card: str = "") -> dict:
    live = all_fields(card, active=True)
    off = all_fields(card, active=False)
    return {"active": len(live), "off": len(off), "total": len(live) + len(off)}


# ── ПЕРЕВІРКИ ───────────────────────────────────────────────────────────────
def check_card(card: str) -> str:
    c = _s(card)
    if c not in CARDS:
        raise FieldError("Картку «%s» не можна розширювати. Можна: %s."
                         % (c, ", ".join(entity.KIND_NAMES[x] for x in CARDS)))
    return c


def check_type(kind: str) -> str:
    t = _s(kind)
    if t not in TYPES:
        raise FieldError("Невідомий тип поля «%s». Відомі: %s."
                         % (t, ", ".join("%s (%s)" % (TYPE_NAMES[x], x) for x in TYPES)))
    return t


def _check_name(card: str, name, owner: str = "") -> str:
    nm = _s(name)
    if not nm:
        raise FieldError("Поле без назви не заводиться.")
    other = by_name(card, nm)
    if other and other != _s(owner):
        raise FieldError("У картці «%s» уже є поле «%s» (%s). Два поля з однією "
                         "назвою — це і є той хаос, якого ми уникаємо."
                         % (entity.KIND_NAMES[_s(card)], _s(get(other).get("name")), other))
    return nm


def _check_choices(kind: str, choices, depends: bool = False) -> list:
    """Значення потрібні ЛИШЕ спискові — і без них список порожній і безглуздий.

    ⭐ 593: ЗАЛЕЖНИЙ список — виняток. Його власний перелік порожній завжди:
    значення живуть у `choices_by` і залежать від батька."""
    vals = [_s(v) for v in (choices or []) if _s(v)]
    if _s(kind) != T_LIST:
        if vals:
            raise FieldError("Перелік значень має лише поле типу «%s»."
                             % TYPE_NAMES[T_LIST])
        return []
    if depends:
        return []
    if not vals:
        raise FieldError("Поле типу «%s» без жодного значення нічого не дає — "
                         "назви хоча б одне." % TYPE_NAMES[T_LIST])
    seen, out = set(), []
    for v in vals:
        low = v.casefold()
        if low in seen:
            raise FieldError("Значення «%s» у переліку двічі." % v)
        seen.add(low)
        out.append(v)
    return out


# ── ЗАПИС ───────────────────────────────────────────────────────────────────
@one_writer.guard("FIELDS_JSON")
def create(card: str, name, kind: str = T_TEXT, many: bool = False,
           choices=None, hint: str = "", order=0) -> dict:
    """Оголосити поле в картці."""
    c = check_card(card)
    t = check_type(kind)
    nm = _check_name(c, name)
    ch = _check_choices(t, choices)
    d = _load()
    fid = _new_id(d)
    now = clock.now()
    d["fields"][fid] = {
        "id": fid,
        "card": c,
        "name": nm,
        "type": t,
        "many": bool(many),
        "choices": ch,
        "hint": _s(hint),
        "order": int(order or 0),
        F_ACTIVE: True,
        "created": now,
        "updated": now,
    }
    _save(d)
    _to_protocol(protocol.A_FIELD_CREATED, fid,
                 "«%s» у картці «%s» · %s%s"
                 % (nm, entity.KIND_NAMES[c], TYPE_NAMES[t],
                    " · множинне" if many else ""))
    return dict(d["fields"][fid])


@one_writer.guard("FIELDS_JSON")
def _mutate(fid: str, patch_fn, what: str, action: str = "") -> dict:
    key = _s(fid)
    d = _load()
    f = d["fields"].get(key)
    if not f:
        raise FieldError("Поля %s немає в будові карток." % (key or "«»"))
    patch_fn(f)
    f["updated"] = clock.now()
    d["fields"][key] = f
    _save(d)
    _to_protocol(_s(action) or protocol.A_FIELD_CHANGED, key, what)
    return dict(f)


def set_name(fid, name) -> dict:
    key = _s(fid)
    f = get(key)
    if not f:
        raise FieldError("Поля %s немає в будові карток." % (key or "«»"))
    nm = _check_name(_s(f.get("card")), name, owner=key)

    def _p(x):
        x["name"] = nm

    return _mutate(key, _p, "назва → «%s»" % nm)


def set_hint(fid, hint) -> dict:
    h = _s(hint)

    def _p(x):
        x["hint"] = h

    return _mutate(_s(fid), _p, "підказка → «%s»" % (h or "прибрано"))


def set_order(fid, order) -> dict:
    n = int(order or 0)

    def _p(x):
        x["order"] = n

    return _mutate(_s(fid), _p, "порядок → %d" % n)


def set_many(fid, many: bool = True) -> dict:
    """⛒ ВМИКАЄТЬСЯ, АЛЕ НЕ ВИМИКАЄТЬСЯ: зі списку в одне значення — це втрата."""
    key = _s(fid)
    f = get(key)
    if not f:
        raise FieldError("Поля %s немає в будові карток." % (key or "«»"))
    want = bool(many)
    if bool(f.get("many")) == want:
        raise FieldError("«%s» і так %s." % (_s(f.get("name")),
                                             "множинне" if want
                                             else "звичайне"))
    if not want:
        raise FieldError("Множинність не вимикається: у полі «%s» уже можуть "
                         "лежати кілька записів, і всі, крім першого, зникли б. "
                         "Заведи нове поле, а це переведи в недіючі."
                         % _s(f.get("name")))

    def _p(x):
        x["many"] = True

    return _mutate(key, _p, "стало множинним")


def set_choices(fid, choices) -> dict:
    """Замінити перелік значень спискового поля. ⚠ Названа межа — у заголовку."""
    key = _s(fid)
    f = get(key)
    if not f:
        raise FieldError("Поля %s немає в будові карток." % (key or "«»"))
    if _s(f.get(F_PARENT)):
        raise FieldError(
            "«%s» залежить від іншого поля — його значення задаються для "
            "кожного значення батька, а не одним переліком." % _s(f.get("name")))
    ch = _check_choices(_s(f.get("type")), choices)
    was = list(f.get("choices") or [])
    gone = [v for v in was if v not in ch]
    # ⛒⛒⛒ 453: ВЖИТЕ ЗНАЧЕННЯ НЕ ПРИБИРАЮТЬ. У 452 це була названа межа, бо
    # значень ще не існувало. Тепер існують — і мовчазне прибирання лишило б у
    # чужих картках значення, якого немає в переліку: показати його не можна, а
    # людина його заносила.
    if gone:
        import card_values as _cv
        still = [v for v in gone if _cv.is_choice_used(key, v)]
        if still:
            raise FieldError("Значення %s уже вжиті в картках — прибрати їх не "
                             "можна. Спершу заміни їх там, де вони стоять."
                             % ", ".join("«%s»" % v for v in still))
    added = [v for v in ch if v not in was]

    def _p(x):
        x["choices"] = ch

    said = []
    if added:
        said.append("додано: %s" % ", ".join(added))
    if gone:
        said.append("прибрано: %s" % ", ".join(gone))
    return _mutate(key, _p, "; ".join(said) or "перелік значень без змін")


# ─────────────────── ЗАЛЕЖНІСТЬ СПИСКІВ (зміна 593) ────────────────────────
def children_of(fid) -> list:
    """Поля, які залежать від цього. Один читач на всю платформу."""
    key = _s(fid)
    if not key:
        return []
    return [f for f in all_fields() if _s(f.get(F_PARENT)) == key]


def allowed_for(fid, parent_value) -> list:
    """ЩО МОЖНА ВИБРАТИ в цьому полі при такому значенні батька.

    ⛒ Батько не вибраний — не пропонуємо НІЧОГО. Показати повний перелік
    означало б дати людині вибрати категорію, яка суперечить напряму, і
    впертись у відмову вже після заповнення."""
    f = get(fid)
    if not f:
        return []
    if not _s(f.get(F_PARENT)):
        return list(f.get("choices") or [])
    by = f.get(F_CHOICES_BY) or {}
    return [x for x in (by.get(_s(parent_value)) or []) if _s(x)]


def _check_choices_by(raw) -> dict:
    if not isinstance(raw, dict):
        raise FieldError("Значення залежного списку задаються переліком для "
                         "кожного значення батька.")
    out = {}
    for k, v in raw.items():
        key = _s(k)
        if not key:
            continue
        vals, seen = [], set()
        for x in (v or []):
            x = _s(x)
            if not x:
                continue
            if x.casefold() in seen:
                raise FieldError("Значення «%s» у переліку двічі." % x)
            seen.add(x.casefold())
            vals.append(x)
        out[key] = vals
    return out


def set_depends(fid, parent, choices_by=None) -> dict:
    """Звʼязати список із батьківським списком і задати значення для кожного
    значення батька. Порожній `parent` — звʼязок знімається.

    ⛒ ПЕРЕВІРЯЄМО ВСЕ ДО ЗАПИСУ: батько мусить бути полем-СПИСКОМ ТІЄЇ САМОЇ
    картки, не самим полем і не його нащадком. Кільце зробило б відповідь на
    питання «що тут можна вибрати» невизначеною."""
    key, pkey = _s(fid), _s(parent)
    f = get(key)
    if not f:
        raise FieldError("Поля %s немає в будові карток." % (key or "«»"))
    if _s(f.get("type")) != T_LIST:
        raise FieldError("Залежними бувають лише поля типу «%s»."
                         % TYPE_NAMES[T_LIST])
    by = _check_choices_by(choices_by or {})
    if pkey:
        if pkey == key:
            raise FieldError("Поле не може залежати саме від себе.")
        pf = get(pkey)
        if not pf:
            raise FieldError("Поля-батька %s немає в будові карток." % pkey)
        if _s(pf.get("type")) != T_LIST:
            raise FieldError("Залежати можна лише від поля типу «%s», а «%s» — "
                             "це «%s»." % (TYPE_NAMES[T_LIST], _s(pf.get("name")),
                                           TYPE_NAMES.get(_s(pf.get("type")), "?")))
        if _s(pf.get("card")) != _s(f.get("card")):
            raise FieldError("«%s» лежить в іншій картці — залежність між "
                             "картками не буває." % _s(pf.get("name")))
        # ⛒ Кільце: піднімаємось ланцюгом батьків і шукаємо себе.
        cur, seen = pkey, set()
        while cur and cur not in seen:
            if cur == key:
                raise FieldError("Кільце: «%s» уже залежить від «%s» (прямо або "
                                 "через інші поля)." % (_s(pf.get("name")),
                                                        _s(f.get("name"))))
            seen.add(cur)
            cur = _s((get(cur) or {}).get(F_PARENT))
        unknown = [k for k in by if k not in (pf.get("choices") or [])]
        if unknown:
            raise FieldError("У батька «%s» немає значень: %s."
                             % (_s(pf.get("name")),
                                ", ".join("«%s»" % x for x in unknown)))
    elif by:
        raise FieldError("Значення для батьківських варіантів є, а батька не "
                         "названо.")
    _materialize(key)

    def _p(x):
        x[F_PARENT] = pkey
        x[F_CHOICES_BY] = by
        if pkey:
            x["choices"] = []

    said = ("залежить від %s" % _s((get(pkey) or {}).get("name"))) if pkey \
        else "залежність знято"
    return _mutate(key, _p, said)


def set_type(fid, kind):
    """⛔ ТИП НЕ МІНЯЄТЬСЯ. Функція існує, щоб відмова була ГУЧНОЮ і пояснила
    причину, а не щоб хтось тихо дописав це поле збоку."""
    f = get(_s(fid))
    nm = _s((f or {}).get("name")) or _s(fid)
    raise FieldError("Тип поля «%s» не міняється: те, що вже занесли люди, "
                     "перетворилось би на сміття. Заведи нове поле потрібного "
                     "типу, а це переведи в недіючі." % nm)


def set_active(fid, flag: bool = True) -> dict:
    """Повернути в роботу або вивести з неї. ⛔ Повтор — відмова СЛОВАМИ."""
    key = _s(fid)
    f = get(key)
    if not f:
        raise FieldError("Поля %s немає в будові карток." % (key or "«»"))
    want = bool(flag)
    if is_active(f) == want:
        raise FieldError("«%s» і так %s." % (_s(f.get("name")),
                                             "діє" if want else "не діє"))

    def _p(x):
        x[F_ACTIVE] = want

    return _mutate(key, _p, "діє" if want else "виведено з роботи",
                   action=protocol.A_FIELD_OFF)
