"""
audit.py — append-only журнал запусків (аудит-слід).

Призначення: трасованість і комплаєнс — для кожного запуску системи фіксуємо
МЕТАДАНІ (коли, яка система, статус, чи пройдено перевірку, скільки мертвих
посилань нейтралізовано). Це аргумент для продажу (audit trail) і допомога в
розслідуванні інцидентів.

ПРИНЦИП БЕЗПЕКИ: у журнал НЕ потрапляють секрети (ключі/токени) і повний текст
результату — лише короткий прев'ю задачі та її хеш. Запис у журнал ніколи не
валить основний потік (усе обгорнуто в try/except).

Файл: runs/_audit.jsonl (по одному JSON-запису на рядок).
"""

import json
import hashlib
import re
from datetime import datetime

import config
import entity                     # спільне імʼя сутності на всю платформу
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій (хребет, 13.08.2026)

_PATH = config.RUNS_DIR / "_audit.jsonl"


def _scrub(text: str) -> str:
    """⭐ 13.08.2026. ПРИБИРАННЯ СЕКРЕТІВ — ОДИН ПИСАР НА ВСЮ ПЛАТФОРМУ.

    Правило жило тут, усередині журналу прогонів. Поки журнал був один — усе
    гаразд. Але з появою загального протоколу зʼявився б і ДРУГИЙ чистильник, а
    два чистильники розходяться: один навчиться нового маркера, другий ні — і
    ключ виїде тим, що новіший. Тому правда переїхала в `protocol.scrub`, а тут
    лишився тонкий виклик (той самий прийом, що `agent._refusal_log` →
    `audit.log_refusal`). Поведінка не змінилась ні на знак: та сама межа 160."""
    return protocol.scrub(text, 160)


# ── Переклад статусу прогону в підсумок протоколу ────────────────────────────
# ⚠ Словник закритий у той бік, що має значення: НЕВІДОМИЙ статус вважається
# поломкою, а не успіхом. Мовчазне «ok» на незнайомому слові — це журнал, який
# бреше на користь платформи; такий гірший за відсутній.
_STATUS_OUTCOME = {
    "completed": protocol.OUT_OK,
    "ok": protocol.OUT_OK,
    "done": protocol.OUT_OK,
    "success": protocol.OUT_OK,
    "honest_stop": protocol.OUT_REFUSED,
    "refused": protocol.OUT_REFUSED,
    "blocked": protocol.OUT_REFUSED,
    "stopped_budget": protocol.OUT_STOPPED,
    "stopped": protocol.OUT_STOPPED,
    "cancelled": protocol.OUT_STOPPED,
    "canceled": protocol.OUT_STOPPED,
}


# ─────────── КЛІТКА НА ВХОДІ ЖУРНАЛУ (зміна 257, 28.08.2026) ─────────────────
# 🩸🩸🩸 ЗНАЙДЕНО 28.08.2026: у журнал разом із дією лягав ВЕСЬ обʼєкт актора —
# з `salt` і `pwd_hash`. На машині Андрія таких рядків було 154 з 383. Журнал
# аудиту мусить називати, ХТО зробив дію, а не носити матеріал для підбору
# пароля.
#
# ⛒ ЛІКУЄМО НЕ ВИКЛИКАЧА, А ВХІД. «Передавайте акуратно» — це домовленість, а
# домовленість не запобіжник: завтра зʼявиться новий викликач і принесе те саме.
# Тому кожен запис проходить ТУТ, і звідси не виходить нічого зайвого.
_SECRET_MARKS = ("pwd_hash", "password", "salt", "token", "api_key", "apikey",
                 "secret", "private_key")
_HIDDEN = "⛔ приховано журналом"


def actor_ref(actor) -> str:
    """ХТО зробив дію — імʼя і номер, і НІЩО інше.

    Приймає і словник актора, і рядок, у якому словник уже серіалізували
    (саме так секрети й потрапляли в журнал).
    """
    a = actor
    if isinstance(a, str) and a.strip().startswith("{") and "id" in a:
        try:
            import ast as _ast
            a = _ast.literal_eval(a.strip())
        except Exception:
            a = {}
            for _k in ("login", "name", "id"):
                _m = re.search(r"'%s'\s*:\s*'([^']*)'" % _k, str(actor))
                if _m:
                    a[_k] = _m.group(1)
    if isinstance(a, dict):
        who = str(a.get("login") or a.get("name") or "").strip()
        aid = str(a.get("id") or "").strip()
        if who and aid:
            return "%s (%s)" % (who, aid)
        return who or aid
    s = str(a or "").strip()
    return "" if any(m in s.lower() for m in _SECRET_MARKS) else s


def _safe_value(key, value):
    """Значення, придатне для журналу. Секрет не ховається — його просто немає."""
    if any(m in str(key).lower() for m in _SECRET_MARKS):
        return _HIDDEN
    if isinstance(value, dict):
        return {k: _safe_value(k, v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_safe_value(key, v) for v in value]
    if isinstance(value, str):
        return _HIDDEN if any(m in value.lower() for m in _SECRET_MARKS) else _scrub(value)
    return value


def _safe_record(rec: dict) -> dict:
    """ОДИН вхід у журнал. Актор зводиться до імені й номера, секрети не пишуться."""
    out = {}
    for k, v in (rec or {}).items():
        if k == "actor":
            out[k] = actor_ref(v)
        else:
            out[k] = _safe_value(k, v)
    return out


def _outcome_of(status) -> str:
    st = ("" if status is None else str(status)).strip().lower()
    kind = _STATUS_OUTCOME.get(st)
    if kind == protocol.OUT_OK:
        return protocol.OUT_OK
    if kind:
        return "%s: %s" % (kind, st)
    return "%s: %s" % (protocol.OUT_FAILED, st or "статус не названо")


def _subject_of(run_id, system_id) -> str:
    """Головна річ рядка: прогін, якщо він має номер; інакше — система.

    ⛒ Підстановки «якщо нічого немає — напишемо щось» тут немає навмисно: рядок
    без головної речі протокол відхилить ГОЛОСНО (у власний файл невдач), і це
    правильно — інакше в журналі зʼявились би дії нізвідки."""
    rid = ("" if run_id is None else str(run_id)).strip()
    if rid:
        return entity.ref(entity.KIND_RUN, rid)
    sid = ("" if system_id is None else str(system_id)).strip()
    return entity.ref(entity.KIND_SYSTEM, sid) if sid else ""


def log_run(system_id, task, status, verified, run_id="", dead_urls=0, extra=None):
    """Додає запис про завершений запуск системи. Безпечно за будь-яких помилок."""
    try:
        rec = {
            "ts": datetime.now().isoformat(timespec="seconds"),
            "run_id": run_id,
            "system_id": system_id,
            "task_preview": _scrub(task),
            "task_hash": hashlib.sha256((task or "").encode("utf-8")).hexdigest()[:12],
            "status": status,
            "verified": bool(verified),
            "dead_urls": int(dead_urls or 0),
        }
        if isinstance(extra, dict):
            for k, v in extra.items():
                rec.setdefault(k, v)
        _PATH.parent.mkdir(parents=True, exist_ok=True)
        with _PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        _to_protocol_run(system_id, status, run_id, rec["task_preview"])
        return True
    except Exception:
        return False


def _to_protocol_run(system_id, status, run_id, preview) -> None:
    """ТОЧКА ВРІЗКИ №1 — ПРОГОНИ (хребет, 13.08.2026).

    Чому саме тут, а не «додамо виклик у 30 місць»: правило, яке живе в одному
    шляху, — наш найдорожчий клас помилок. Але писар журналу прогонів уже ОДИН,
    тому забути неможливо, а майбутній канал (новий екран, нова система) потрапить
    у протокол сам — він усе одно ходить через `audit`."""
    try:
        subject = _subject_of(run_id, system_id)
        sid = ("" if system_id is None else str(system_id)).strip()
        actor = entity.ref(entity.KIND_SYSTEM, sid) if sid else ""
        rid = ("" if run_id is None else str(run_id)).strip()
        if rid:
            # Прогін став відомим — і тепер гроші, які порахує `costs`, знайдуть,
            # до чого їх прикласти. Це і є той звʼязок, що живе в протоколі.
            protocol.bind(run=entity.ref(entity.KIND_RUN, rid))
        protocol.write(protocol.A_RUN_FINISHED, subject, actor=actor,
                       outcome=_outcome_of(status), note=preview)
    except Exception:
        pass


def log_refusal(kind: str, system_id: str, questions=None, note: str = "") -> bool:
    """⭐⭐⭐ 01.08.2026. ОДИН ПИСАР СЛІДУ «РОБОТА НЕ ВІДБУЛАСЬ АБО ВІДБУЛАСЬ НЕ ТАК».

    Слід відмов народився 31.07 усередині `agent.py` — там, де його вперше
    забракло. Але зупиняє роботу не лише мозок: рушій теж має право не почати
    (не вдалося перевірити достатність даних) або піти далі з чесним
    застереженням. Поки писар жив в `agent`, рушій не міг ним скористатись —
    і майбутній канал протік би мовчки. Тому правда переїхала в журнал, а
    `agent._refusal_log` став тонким викликом до неї.

    Пише за перемикачем стану (`config.STATE_DIR`), щоб чеки не смітили в
    бойову теку. Ніколи не кидає: журнал не має права завалити роботу.
    """
    try:
        d = config.STATE_DIR / "runs"
        d.mkdir(parents=True, exist_ok=True)
        rec = {"ts": datetime.now().isoformat(), "kind": kind,
               "system_id": system_id or "",
               "questions": list(questions or []), "note": note}
        with (d / "_refusals.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        try:
            sid = ("" if system_id is None else str(system_id)).strip()
            if sid:
                ref = entity.ref(entity.KIND_SYSTEM, sid)
                protocol.write(protocol.A_RUN_REFUSED, ref, actor=ref,
                               outcome="%s: %s" % (protocol.OUT_REFUSED,
                                                   kind or "без виду"),
                               note=note)
        except Exception:
            pass
        return True
    except Exception:
        return False


def log_event(rec) -> bool:
    """⭐ ОДИН ПИСАР НЕ-ПРОГОННОГО РЯДКА АУДИТУ (11.08.2026, зміна 152).

    Журнал народився як слід ЗАВЕРШЕНОГО прогону (`log_run`). Але є
    події, які стаються ДО роботи і важать рівно стільки ж: як платформа
    зрозуміла задачу і чи питала про це людину. Щоб цей слід не завів ДРУГОГО
    писаря з власним форматом і власним шляхом до файла, він йде сюди.

    Ніколи не кидає: журнал не має права завалити роботу."""
    try:
        if not isinstance(rec, dict):
            return False
        out = {"ts": datetime.now().isoformat(timespec="seconds")}
        # ⛒ УСЕ, ЩО ЙДЕ В ЖУРНАЛ, ПРОХОДИТЬ ЧЕРЕЗ КЛІТКУ (зміна 257).
        for k, v in _safe_record({k2: v2 for k2, v2 in rec.items() if k2 != "ts"}).items():
            out[k] = v
        _PATH.parent.mkdir(parents=True, exist_ok=True)
        with _PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(out, ensure_ascii=False) + "\n")
        try:
            subject = _subject_of(out.get("run_id"), out.get("system_id"))
            if subject:
                protocol.write(protocol.A_RUN_EVENT, subject,
                               note=str(out.get("event") or out.get("kind") or ""))
        except Exception:
            pass
        return True
    except Exception:
        return False


def tail(n: int = 50) -> list:
    """Останні n записів журналу (для перегляду/UI)."""
    try:
        lines = _PATH.read_text(encoding="utf-8").splitlines()[-n:]
        return [json.loads(ln) for ln in lines if ln.strip()]
    except Exception:
        return []
