# -*- coding: utf-8 -*-
"""chains.py — ЛАНЦЮГИ СИСТЕМ: наряд, приймання за характеристиками, розбір невдачі.

ЗАДУМ (Андрій, 04-05.08.2026):
    одна система → ланцюг із наявних → нова система, якщо результату не дає
    НІ одна, НІ ланцюг. Будь-яка розбудова — лише за згодою людини: це її гроші.

🔴 ЩО МИ НАСПРАВДІ ЗАКРИВАЄМО. Мовчазний ланцюг був можливий і ДО цього файла:
мозок за один хід робить до 8 кроків міркування і міг запустити дві-три системи
підряд — без згоди, без названої ціни, без перевірки проміжного результату.
Тому це не «нова можливість», а ВОРОТА на поведінку, яка вже вміла витрачати
гроші клієнта.

ТРИ ОПОРИ КОНСТРУКЦІЇ:
  1. **НАРЯД** — план ланцюга, складений ДО витрат: кроки, характеристики
     результату кожного кроку, орієнтовна ціна, тверда стеля. Характеристики
     фіксуються до першого кроку і НЕ переписуються (інакше модель підганяє
     критерій під те, що вийшло, і сама собі ставить залік).
  2. **НАРЯД ВИКОНУЄ ПЛАТФОРМА, А НЕ МОЗОК.** Мозок планує і розбирає невдачі;
     кроки крутить код. Інакше мозок міг би мовчки відхилитись від власного плану.
  3. **РОЗБІР ПРИЧИНИ ПЕРЕД ПОВТОРОМ.** Слова Андрія: «оркестратор робить по три
     повтори з однаковим результатом — це релейність». Повтор дозволений РІВНО
     ОДИН і ЛИШЕ якщо розбір назвав, ЩО ЗМІНИТЬСЯ (потужніша модель або інші
     вказівки). Повтор без зміни умов заборонений кодом.

Судження моделі тут керує грошима, тому обмежене твердо: один повтор на крок,
спільна стеля на весь ланцюг, зміна умов обовʼязкова.
"""
import hashlib
import json
import time
from pathlib import Path

import config
import features
import llm
import phrases
import registry
import step_outcome

HERE = Path(__file__).resolve().parent

WORK_ID = "chains"          # робота в release_works.json (вимикач етапу 2)
MAX_STEPS = 3               # YAGNI: три системи покривають усі живі приклади
MAX_ATTEMPTS = 2            # перша спроба + РІВНО ОДИН повтор (рішення Андрія)


class ChainError(Exception):
    """Зупинка ланцюга, яка називає себе вголос."""


def enabled() -> bool:
    """Незавершена робота приїжджає до клієнта ВИМКНЕНОЮ (етап 2 воріт складу)."""
    return features.enabled(WORK_ID)


# ─────────────────────────── де живе наряд ───────────────────────────────────
def _dir() -> Path:
    d = Path(config.STATE_DIR) / "chains"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _path(cid: str) -> Path:
    return _dir() / ("%s.json" % _safe_id(cid))


def _safe_id(cid: str) -> str:
    s = "".join(ch for ch in str(cid or "") if ch.isalnum() or ch in "-_")
    if not s:
        raise ChainError("порожній номер наряду")
    return s


def expect_fingerprint(steps) -> str:
    """Відбиток ХАРАКТЕРИСТИК. Змінились після старту — це вже інший наряд."""
    body = "\n".join("%s|%s" % (s.get("system_id", ""), s.get("expect", "")) for s in steps or [])
    return hashlib.sha256(body.encode("utf-8")).hexdigest()[:16]


def save(plan: dict) -> str:
    _path(plan["id"]).write_text(json.dumps(plan, ensure_ascii=False, indent=2),
                                 encoding="utf-8")
    return plan["id"]


def load(cid: str) -> dict:
    p = _path(cid)
    if not p.exists():
        raise ChainError("наряд «%s» не знайдено" % cid)
    plan = json.loads(p.read_text(encoding="utf-8"))
    # ⭐ Характеристики — не рукопис, а зафіксована умова приймання.
    if plan.get("expect_sha") != expect_fingerprint(plan.get("steps")):
        raise ChainError("характеристики наряду «%s» змінились після складання — "
                         "це вже інший наряд, виконувати його не можна" % cid)
    return plan


# ────────── НАРЯД, ЩО ЧЕКАЄ ЗГОДИ, ЖИВЕ НА ДИСКУ (зміна 249, 28.08.2026) ──────
# 🩸🩸🩸 ЗРИВ 28.08.2026 НА ЛЮДЯХ. Андрій тричі сказав «так» — і тричі отримав
# НОВУ пропозицію замість запуску. Корінь: факт «цей наряд чекає згоди» жив у
# контексті ОДНОГО ходу. На наступному ході мозок мав «згадати» номер наряду з
# розмови — а його там не було, і модель чесно складала наряд заново.
#
# ⛒ ЗГОДА — ЦЕ СТАН, А НЕ СЛОВО В ТЕКСТІ. Наряд, що чекає, лежить НА ДИСКУ, і
# він ОДИН на чат. Платформа сама знає, який наряд чекає: мозку більше нічого
# не треба пригадувати, а кнопці згоди (крок 4) буде на що спиратись.
# ⛔ СВІДОМО НЕ РОБИМО «СЛОВНИК СЛІВ ЗГОДИ» — це вгадування (слово Андрія 28.08).

def _waiting_file() -> Path:
    return _dir() / "_waiting.json"


def _waiting_all() -> dict:
    p = _waiting_file()
    if not p.exists():
        return {}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _chat_key(chat_key) -> str:
    """Ключ чату. Порожній — теж ключ: консоль без входу — це теж одна людина."""
    return str(chat_key or "").strip() or "-"


def set_waiting(chat_key, cid: str) -> None:
    d = _waiting_all()
    d[_chat_key(chat_key)] = _safe_id(cid)
    _waiting_file().write_text(json.dumps(d, ensure_ascii=False, indent=2),
                               encoding="utf-8")


def clear_waiting(chat_key) -> None:
    d = _waiting_all()
    if d.pop(_chat_key(chat_key), None) is not None:
        _waiting_file().write_text(json.dumps(d, ensure_ascii=False, indent=2),
                                   encoding="utf-8")


def waiting_id(chat_key="") -> str:
    """Номер наряду, що ЧЕКАЄ ЗГОДИ в цьому чаті. Порожньо — не чекає жоден.

    ⛒ Стан звіряється з САМИМ НАРЯДОМ: запис у покажчику — не доказ. Наряд
    зник, зіпсувався або вже пішов у роботу — покажчик чиститься тут-таки.
    """
    cid = str(_waiting_all().get(_chat_key(chat_key)) or "")
    if not cid:
        return ""
    try:
        plan = load(cid)
    except ChainError:
        clear_waiting(chat_key)
        return ""
    if plan.get("status") != "proposed":
        clear_waiting(chat_key)
        return ""
    return cid


def waiting_plan(chat_key="") -> dict:
    cid = waiting_id(chat_key)
    return load(cid) if cid else {}


# ─────────────────────────── складання наряду ────────────────────────────────
def estimate(steps) -> tuple:
    """Орієнтовна ціна і тверда стеля на ВЕСЬ ланцюг.

    Чесно: точної ціни другого кроку до першого не знає ніхто — вона залежить від
    обсягу проміжного результату. Тому оцінка груба, а стеля тверда.
    """
    one = float(config.MAX_RUN_USD or 0.5)
    n = max(1, len(steps or []))
    est = round(one * 0.35 * n, 2)          # типовий прогін ~третина своєї стелі
    cap = round(one * n, 2)                 # стеля = сума стель кроків
    return est, cap


def propose(task: str, steps, why: str = "", chat_key="") -> dict:
    """Скласти наряд. НІЧОГО не виконує і грошей не витрачає.

    ⛒ ОДИН НАРЯД, ЩО ЧЕКАЄ ЗГОДИ, НА ЧАТ (зміна 249). Та сама задача з тими
    самими кроками — це ТОЙ САМИЙ наряд, а не новий: інакше кожне «так»
    народжувало б ще одну пропозицію (зрив 28.08). Інша задача — стара
    пропозиція вмирає названою («superseded»), бо чекати може лише одна.
    """
    steps = list(steps or [])
    if not (2 <= len(steps) <= MAX_STEPS):
        raise ChainError("ланцюг — це від 2 до %d систем (запропоновано %d)"
                         % (MAX_STEPS, len(steps)))
    clean = []
    for i, s in enumerate(steps, 1):
        sid = str((s or {}).get("system_id") or "").strip()
        expect = str((s or {}).get("expect") or "").strip()
        if not registry.find_system(sid):
            raise ChainError("системи «%s» немає в реєстрі" % sid)
        if len(expect) < 20:
            raise ChainError(
                "крок %d («%s») без характеристик результату. Опиши, ЩО саме має вийти, "
                "щоб наступний крок міг із цим працювати — інакше приймати нічим." % (i, sid))
        clean.append({"system_id": sid, "expect": expect, "task": str((s or {}).get("task") or "").strip(),
                      "status": "waiting", "attempts": 0, "spent_usd": 0.0,
                      "model_used": "", "changed": "", "note": ""})
    _sha = expect_fingerprint(clean)
    _wait = waiting_id(chat_key)
    if _wait:
        old = load(_wait)
        if old.get("expect_sha") == _sha and \
                (old.get("task") or "") == str(task or "").strip():
            return old          # ТОЙ САМИЙ наряд — другого не заводимо
        old["status"] = "superseded"
        old["superseded_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        save(old)
        clear_waiting(chat_key)
    est, cap = estimate(clean)
    # ⛒ НОМЕР МУСИТЬ БУТИ ВІЛЬНИМ. Доти два наряди, складені в ОДНУ СЕКУНДУ,
    # діставали однаковий номер, і другий МОВЧКИ затирав файл першого — разом
    # із ціною, яку людина вже бачила. Знайдено чеком chain_waiting_test 28.08.
    _ts = int(time.time())
    while _path("c-%d" % _ts).exists():
        _ts += 1
    plan = {"id": "c-%d" % _ts,
            "task": str(task or "").strip(),
            "why": str(why or "").strip(),
            "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
            "status": "proposed",          # proposed -> accepted -> running -> done|stopped
            "steps": clean,
            "est_usd": est, "cap_usd": cap, "spent_usd": 0.0,
            "report": []}
    plan["expect_sha"] = _sha
    save(plan)
    set_waiting(chat_key, plan["id"])
    return plan


def accept(cid: str, chat_key="") -> dict:
    """Згода людини — ОДНА, на весь ланцюг.

    ⛒ Згода ГАСИТЬ очікування (зміна 249): наряд, який уже пішов у роботу,
    більше не «чекає», і друге «так» не запустить його вдруге.
    """
    plan = load(cid)
    if plan.get("status") not in ("proposed", "accepted"):
        raise ChainError("наряд «%s» уже в стані «%s»" % (cid, plan.get("status")))
    plan["status"] = "accepted"
    plan["accepted_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
    save(plan)
    clear_waiting(chat_key)
    return plan


def human_offer(plan: dict, lang=None) -> str:
    """Репліку про ланцюг пише ПЛАТФОРМА — як і питання воріт уточнення.
    Мозок міг би переказати ціну своїми словами; ціна — не його зона.

    ⛒ І пише її МОВОЮ КОРИСТУВАЧА (зміна 255): службові тексти живуть у
    словнику, а не в коді. `why` від мозку не перекладаємо — це зміст, а не
    службовий напис.
    """
    lines = [phrases.t("chain.head", lang)]
    if plan.get("why"):
        lines.append(plan["why"])
    lines.append("")
    lines.append(phrases.t("chain.propose", lang, n=len(plan["steps"])))
    for i, s in enumerate(plan["steps"], 1):
        sysd = registry.find_system(s["system_id"]) or {}
        lines.append("%d. %s — %s" % (i, sysd.get("name") or s["system_id"], s["expect"]))
    lines.append("")
    lines.append(phrases.t("chain.price", lang, est=plan["est_usd"], cap=plan["cap_usd"]))
    lines.append(phrases.t("chain.price_note", lang))
    lines.append("")
    # ⛒ НОМЕР НАРЯДУ ВИДНО ЛЮДИНІ (зміна 249). Доти пропозиція не називала
    # себе ніяк — і прийняти її не було чим. Кнопка прийде кроком 4.
    lines.append(phrases.t("chain.order", lang, id=plan["id"]))
    lines.append(phrases.t("chain.run_q", lang))
    return "\n".join(lines)


# ─────────────────────── приймання кроку і розбір невдачі ────────────────────
_JUDGE_ACCEPT = (
    "Ти — приймальник проміжного результату в ланцюгу систем. Тобі дано ОПИС ТОГО, "
    "ЩО МАЛО ВИЙТИ (умова приймання, записана ДО роботи), і сам результат. "
    "Скажи, чи результат ПРИДАТНИЙ для наступного кроку. Не оцінюй красу — оцінюй "
    "придатність. Поверни JSON: {\"ok\": true|false, \"missing\": \"чого бракує, коротко\"}.")

_JUDGE_DIAGNOSE = (
    "Ти — розбір причини невдачі кроку в ланцюгу систем. Дано: що мало вийти, що "
    "вийшло, і чого бракує. Назви ОДИН клас причини:\n"
    "• need_input — бракує вхідних даних від людини;\n"
    "• weak_model — модель не потягнула: обірвана думка, поверхнево, не за формою;\n"
    "• not_capable — ця система такого не вміє в принципі;\n"
    "• blocked — непереборне: нема звʼязку, коштів, конектора, джерела, зламаний код.\n"
    "Поверни JSON: {\"cause\": \"<клас>\", \"why\": \"одним реченням\", "
    "\"hint\": \"що змінити в другій спробі, якщо вона доцільна\"}.")


def accept_step(expect: str, result_md: str) -> dict:
    """Приймання за ХАРАКТЕРИСТИКАМИ з наряду (а не за оком людини)."""
    if not (result_md or "").strip():
        return {"ok": False, "missing": "результату немає взагалі"}
    try:
        out = llm.judge_json(_JUDGE_ACCEPT,
                             "МАЛО ВИЙТИ:\n%s\n\nВИЙШЛО:\n%s" % (expect, result_md[:6000]),
                             purpose="chain_accept") or {}
    except Exception as e:
        # Суддя недоступний — це НЕ «придатно». Мовчазне «так» тут коштувало б
        # другого кроку на смітті.
        return {"ok": False, "missing": "перевірку придатності виконати не вдалося (%s)"
                                        % type(e).__name__}
    return {"ok": bool(out.get("ok")), "missing": str(out.get("missing") or "")}


_CAUSES = ("need_input", "weak_model", "not_capable", "blocked")


def diagnose(expect: str, result_md: str, missing: str) -> dict:
    """⭐ ВУЗОЛ РОЗБОРУ ПРИЧИН. Відповідь — КЛАС, а не текст: за класом діє код."""
    try:
        out = llm.judge_json(_JUDGE_DIAGNOSE,
                             "МАЛО ВИЙТИ:\n%s\n\nВИЙШЛО:\n%s\n\nЧОГО БРАКУЄ:\n%s"
                             % (expect, (result_md or "")[:4000], missing),
                             purpose="chain_diagnose") or {}
    except Exception as e:
        return {"cause": "blocked", "why": "розбір причини недоступний (%s)" % type(e).__name__,
                "hint": ""}
    cause = str(out.get("cause") or "").strip()
    if cause not in _CAUSES:
        # Невідомий клас — поводимось як з непереборним: краще чесний стоп, ніж
        # повтор навмання за гроші людини.
        cause = "blocked"
    return {"cause": cause, "why": str(out.get("why") or ""), "hint": str(out.get("hint") or "")}


def stronger_model(current: str) -> str:
    """Наступний щабель драбини (закон вичерпаності). Немає вище — порожньо.

    ⭐⭐⭐ КОРІНЬ 10.08.2026 (зміна 147), СПІЙМАНО ЧЕКОМ НА МАШИНІ ВЛАСНИКА.
    Тут стояло `return ladder[0]` для випадку «поточної моделі в драбині немає».
    А це найзвичайніший випадок: клієнт вибрав свою модель у консолі, або
    постачальник її зняв і вона вибула з драбини. Тоді «повтор ПОТУЖНІШОЮ»
    повертав ПЕРШИЙ щабель — тобто найдешевший, часто ту саму або слабшу
    модель. Клієнт платив за другу спробу, яка нічим не сильніша за першу.
    Саме проти цього й стоїть закон: повтор без зміни умов заборонений.

    Лікуємо чесно: модель, якою СПРАВДІ працювали, — це фактичний нульовий
    щабель. Ставимо її на початок драбини й беремо наступну. Так друга спроба
    ніколи не дорівнює першій, і ніколи не буває слабшою.
    """
    ladder = [m for m in (config.model_ladder() or []) if m]
    if not ladder:
        return ""
    if not current:
        return ladder[0]
    if current not in ladder:
        ladder = [current] + [m for m in ladder if m != current]
    i = ladder.index(current)
    return ladder[i + 1] if i + 1 < len(ladder) else ""


def may_retry(step: dict, diag: dict) -> dict:
    """ЧИ ВЗАГАЛІ ДОЦІЛЬНА ДРУГА СПРОБА — і що в ній ЗМІНИТЬСЯ.

    ⭐⭐⭐ Повтор без зміни умов заборонений: саме він давав «три однакові спроби».
    """
    if int(step.get("attempts") or 0) >= MAX_ATTEMPTS:
        return {"retry": False, "reason": "повтор уже був — другого не робимо"}
    cause = diag.get("cause")
    if cause == "need_input":
        return {"retry": False, "reason": "бракує вхідних даних — питаємо людину, "
                                          "повторювати наосліп нічого"}
    if cause == "not_capable":
        return {"retry": False, "reason": "система такого не вміє — повтор нічого не змінить"}
    if cause == "blocked":
        return {"retry": False, "reason": "непереборна обставина — зупиняємось і доповідаємо"}
    # weak_model -> повторюємо ПОТУЖНІШОЮ моделлю
    nxt = stronger_model(step.get("model_used") or "")
    if not nxt:
        return {"retry": False, "reason": "потужнішої моделі в доступі немає — "
                                          "повтор тією самою був би тією самою невдачею"}
    return {"retry": True, "model": nxt,
            "changed": "потужніша модель: %s" % nxt,
            "hint": diag.get("hint") or ""}


# ─────────────────────────── виконання наряду ────────────────────────────────
# ⛒ ВЛАСНОЇ ТАБЛИЦІ ТРАКТУВАНЬ У ЛАНЦЮГА БІЛЬШЕ НЕМАЄ (зміна 250, 28.08.2026).
# Тут стояв рядок «needs_capability -> not_capable»: ланцюг убивав крок там,
# де прямий запит спокійно добирав можливість і доводив роботу до кінця. Дві
# правди про одну подію — це та сама хвороба, що й два реєстри воріт.
# Тепер наслідок кроку трактує ОДИН обробник, спільний для обох шляхів.


def _step_task(plan: dict, step: dict, carry: str) -> str:
    """Задача кроку: своя (якщо мозок її написав) + результат попереднього кроку.

    ⭐ Передаємо ФАКТИЧНИЙ текст попереднього результату, а не переказ мозку:
    переказ — це другий писар тієї самої правди.
    """
    head = step.get("task") or plan.get("task") or ""
    if not carry:
        return head
    return ("%s\n\n--- РЕЗУЛЬТАТ ПОПЕРЕДНЬОГО КРОКУ (працюй із ним як із даними) ---\n%s"
            % (head, carry))


def _bill(plan: dict, step: dict, ex: dict) -> None:
    """Витрати прогону лягають у наряд. ДОБІРКА МОЖЛИВОСТІ — ТЕЖ ПРОГІН,
    і її гроші рахуються так само: невидимих витрат у наряді не буває."""
    usd = float((ex or {}).get("usd") or 0.0)
    step["spent_usd"] = float(step.get("spent_usd") or 0.0) + usd
    step["model_used"] = (ex or {}).get("model") or step.get("model_used") or ""
    plan["spent_usd"] = round(float(plan["spent_usd"]) + usd, 4)


def run(cid: str, runner, emit=None, finish=None) -> dict:
    """Виконати наряд. Кроки крутить ЦЕЙ код, а не мозок.

    runner(step, task, model) -> {"status","final_markdown","usd","model"}
    finish(ex, system, task)   -> текст здачі останнього кроку (єдина точка здачі
                                  в agent; сюди передається, щоб не заводити другого
                                  писаря приймання результату).
    """
    say = emit or (lambda *_a: None)
    plan = load(cid)
    if plan.get("status") != "accepted":
        raise ChainError("наряд «%s» не запускався: людина ще не дала згоди "
                         "(стан «%s»)" % (cid, plan.get("status")))
    plan["status"] = "running"
    save(plan)

    carry = ""
    last_ex, last_system, last_task = None, None, ""
    for idx, step in enumerate(plan["steps"]):
        sysd = registry.find_system(step["system_id"]) or {}
        name = sysd.get("name") or step["system_id"]
        while True:
            # ⭐ СПІЛЬНА СТЕЛЯ НА ВЕСЬ ЛАНЦЮГ, а не на кожен прогін окремо.
            if float(plan["spent_usd"]) >= float(plan["cap_usd"]):
                return _stop(plan, idx, "стеля вартості ланцюга вичерпана "
                                        "($%.2f із $%.2f)" % (plan["spent_usd"], plan["cap_usd"]),
                             say)
            step["attempts"] = int(step.get("attempts") or 0) + 1
            task = _step_task(plan, step, carry)
            if step["attempts"] > 1 and step.get("changed"):
                say("🔁 Крок %d «%s»: друга спроба — %s" % (idx + 1, name, step["changed"]))
            else:
                say("▶ Крок %d з %d: %s" % (idx + 1, len(plan["steps"]), name))
            ex = runner(step, task, step.get("retry_model") or "") or {}
            _bill(plan, step, ex)
            # ⛒ ОДИН ОБРОБНИК НАСЛІДКУ КРОКУ — ТОЙ САМИЙ, ЩО В ПРЯМОМУ ЗАПИТІ.
            outcome = step_outcome.interpret(ex, bool(step.get("capability_taken")))
            if outcome["kind"] == "capability":
                # ЧЕСНА ДОБІРКА: система попросила можливість — розширюємо
                # контракт наміру і перезапускаємо РІВНО ОДИН раз. Доти саме
                # тут ланцюг помирав, а прямий запит доїжджав.
                step["capability_taken"] = outcome["capability"]
                step["intent"] = dict(step.get("intent") or {}, **outcome["intent_patch"])
                say("🔁 Крок %d «%s»: добірка можливості (%s) — перезапускаю з "
                    "розширеним контрактом" % (idx + 1, name, outcome["capability"]))
                ex = runner(step, task, step.get("retry_model") or "") or {}
                _bill(plan, step, ex)
                outcome = step_outcome.interpret(ex, True)
            md = ex.get("final_markdown") or ""
            status = ex.get("status") or "unknown"

            if outcome["kind"] == "completed":
                verdict = accept_step(step["expect"], md)
            else:
                verdict = {"ok": False, "missing": str(ex.get("note") or status)}

            if verdict["ok"]:
                step["status"] = "accepted"
                step["note"] = ""
                plan["report"].append({"step": idx + 1, "system": step["system_id"],
                                       "attempts": step["attempts"], "usd": step["spent_usd"],
                                       "verdict": "прийнято"})
                save(plan)
                say("✓ Крок %d прийнято (%s)" % (idx + 1, name))
                carry = md
                last_ex, last_system, last_task = ex, sysd, task
                break

            # ── не прийнято: спершу РОЗБІР ПРИЧИНИ, і лише потім рішення ──
            if outcome["kind"] != "completed":
                diag = {"cause": outcome["cause"],
                        "why": outcome["why"] or status, "hint": ""}
            else:
                diag = diagnose(step["expect"], md, verdict["missing"])
            say("… крок %d не прийнято: %s" % (idx + 1, verdict["missing"] or diag.get("why") or "—"))
            decision = may_retry(step, diag)
            plan["report"].append({"step": idx + 1, "system": step["system_id"],
                                   "attempts": step["attempts"], "usd": step["spent_usd"],
                                   "verdict": "не прийнято", "cause": diag["cause"],
                                   "why": diag.get("why") or "", "missing": verdict["missing"],
                                   "retry": bool(decision.get("retry"))})
            if not decision.get("retry"):
                step["status"] = "failed"
                step["note"] = diag.get("why") or verdict["missing"]
                return _stop(plan, idx, "%s (%s)" % (decision.get("reason") or "далі не йдемо",
                                                     diag["cause"]), say,
                             cause=diag["cause"], missing=verdict["missing"])
            # ⭐ ПОВТОР ЛИШЕ ЗІ ЗМІНОЮ УМОВ — інакше це та сама витрата з тим самим кінцем.
            step["retry_model"] = decision.get("model") or ""
            step["changed"] = decision.get("changed") or ""
            if not step["changed"]:
                return _stop(plan, idx, "повтор без зміни умов заборонений", say)
            if decision.get("hint"):
                step["task"] = (step.get("task") or plan.get("task") or "") + \
                               "\n\nУВАГА до другої спроби: " + decision["hint"]
            save(plan)

    plan["status"] = "done"
    save(plan)
    say("✓ Ланцюг завершено ($%.2f із $%.2f)" % (plan["spent_usd"], plan["cap_usd"]))
    if finish and last_ex is not None:
        return {"plan": plan, "reply": finish(last_ex, last_system, last_task), "ok": True}
    return {"plan": plan, "reply": carry, "ok": True}


def _stop(plan: dict, idx: int, reason: str, say, cause: str = "", missing: str = "") -> dict:
    """Зупинка ланцюга, яка НАЗИВАЄ СЕБЕ (реєстр зупинок, 01.08)."""
    plan["status"] = "stopped"
    plan["stopped_reason"] = reason
    plan["stopped_step"] = idx + 1
    save(plan)
    say("⛔ Ланцюг зупинено на кроці %d: %s" % (idx + 1, reason))
    return {"plan": plan, "ok": False, "stopped_step": idx + 1, "reason": reason,
            "cause": cause, "missing": missing,
            "reply": report_text(plan)}


def report_text(plan: dict) -> str:
    """Звіт про ланцюг для людини: що робив кожен крок і скільки це коштувало."""
    lines = []
    if plan.get("status") == "done":
        lines.append("Ланцюг виконано (%d кроки)." % len(plan["steps"]))
    else:
        lines.append("Ланцюг зупинено на кроці %d: %s"
                     % (plan.get("stopped_step") or 0, plan.get("stopped_reason") or "—"))
    for r in plan.get("report") or []:
        sysd = registry.find_system(r.get("system")) or {}
        line = "%d) %s — %s" % (r.get("step"), sysd.get("name") or r.get("system"),
                                r.get("verdict"))
        if r.get("verdict") != "прийнято":
            line += ": %s" % (r.get("missing") or r.get("why") or "")
            if r.get("retry"):
                line += " → друга спроба"
        lines.append(line)
    lines.append("Витрачено $%.2f із межі $%.2f (орієнтовно очікували $%.2f)."
                 % (plan.get("spent_usd") or 0, plan.get("cap_usd") or 0, plan.get("est_usd") or 0))
    return "\n".join(lines)


# ────────────── ЧИ ПОКРИВАЄ ОБРАНА СИСТЕМА ЗАДАЧУ ЦІЛКОМ ─────────────────────
# ⭐⭐⭐ 05.08.2026, ЖИВИЙ ВИМІР. Ми дали мозку інструмент ланцюга і записали
# правило «одна → ланцюг → нова» в його інструкцію. Проба маршруту показала:
# на задачі «розпродати залишки» він однаково взяв ОДНУ найширшу систему.
# Це ще один доказ правила «ПРАВИЛО В ПРОМПТІ — ЦЕ ПРОХАННЯ, А НЕ ВОРОТА».
# Тому питання ставить ПЛАТФОРМА, перед запуском, і відповідь має наслідок.
#
# Питаємо не розпливчасте «чи підходить», а конкретне: чи є в задачі частина,
# якої ця система за ВЛАСНИМ ПАСПОРТОМ не робить. Паспорт — не наша вигадка,
# він складений мозком самої системи (`routing_card`, 04.08).
_JUDGE_COVER = (
    "Ти — вхідний контроль маршруту. Дано ТРИ речі: СЛОВА КОРИСТУВАЧА (першоджерело), "
    "ПЕРЕКАЗ задачі, який склав оркестратор, і ПАСПОРТ обраної системи (для чого вона · "
    "що на вхід · що на вихід · чого НЕ робить).\n"
    "⭐ Судити треба за СЛОВАМИ КОРИСТУВАЧА. Переказ — лише контекст, і він може звужувати "
    "або пом'якшувати задачу; якщо переказ звузив її так, що система підходить лише під "
    "переказ, а не під те, що просила людина, — це і є прогалина.\n"
    "Питання одне: чи є в тому, що просив КОРИСТУВАЧ, суттєва частина, якої ця система за "
    "своїм паспортом НЕ робить? Не вигадуй проблем: якщо система покриває — так і скажи. "
    "Поверни JSON: {\"covers\": true|false, \"gap\": \"якої частини бракує\", "
    "\"need\": \"який результат потрібен для цієї частини\"}.")


def covers_task(system: dict, task: str, original: str = "") -> dict:
    """Чи покриває обрана система задачу цілком (за її ж паспортом)."""
    card = (system or {}).get("routing_card") or {}
    if not card:
        try:
            import routing_card as _rc
            card = _rc.load(system) or {}
        except Exception:
            card = {}
    if not card:
        # Немає паспорта — немає підстави заперечувати. Мовчазних відмов не робимо.
        return {"covers": True, "gap": "", "need": "", "checked": False}
    body = "\n".join("%s: %s" % (k, v) for k, v in card.items() if isinstance(v, str))
    try:
        out = llm.judge_json(_JUDGE_COVER,
                             "СЛОВА КОРИСТУВАЧА (першоджерело):\n%s\n\n"
                             "ПЕРЕКАЗ ОРКЕСТРАТОРА:\n%s\n\nПАСПОРТ СИСТЕМИ «%s»:\n%s"
                             % (str(original or task)[:2000], str(task)[:2000],
                                (system or {}).get("name") or "", body[:3000]),
                             purpose="chain_cover") or {}
    except Exception:
        # Суддя недоступний — пропускаємо. Ворота маршруту не мають ставати
        # стіною перед роботою людини через наш збій.
        return {"covers": True, "gap": "", "need": "", "checked": False}
    return {"covers": bool(out.get("covers", True)), "gap": str(out.get("gap") or ""),
            "need": str(out.get("need") or ""), "checked": True}
