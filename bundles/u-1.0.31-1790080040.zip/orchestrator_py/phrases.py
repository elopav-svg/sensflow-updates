# -*- coding: utf-8 -*-
"""phrases.py — СЛУЖБОВІ ТЕКСТИ ПЛАТФОРМИ ЖИВУТЬ У СЛОВНИКУ, А НЕ В КОДІ.

🩸🩸🩸 ЩО КУПЛЕНО ЗРИВОМ 28.08.2026. Інтерфейс російською, запит російською — а
картка розуміння, пропозиція ланцюга і статуси прийшли УКРАЇНСЬКОЮ. Корінь:
`i18n.js` перекладає лише СТАТИЧНИЙ екран, а всі службові тексти складає
СЕРВЕР — і про мову користувача він не знав узагалі. Мова жила у двох місцях,
і жодне з них не знало про друге.

⛒ ЗАКОН: МОВА КОРИСТУВАЧА — ЧАСТИНА ЗАПИТУ ДО ПЛАТФОРМИ, а всі тексти, які
пише ПЛАТФОРМА (а не модель), беруться ЗВІДСИ.

⛔ МОВА ЗМІСТУ — ЦЕ ІНШЕ. Документ пишеться мовою ЗАДАЧІ: людина може працювати
в українському інтерфейсі й замовити лист англійською. Плутати ці дві речі не
можна, тому сюди не потрапляє жоден текст, який складає модель.

⛒ Ворота: ключа немає або переклад неповний — ГОЛОСНА помилка, а не тихе
повернення до однієї мови.Напівпереклад помітний лише клієнту, і платить
за нього він.
"""

LANGS = ("uk", "ru", "en")
DEFAULT = "uk"


class PhraseError(Exception):
    """Службовий текст, якого немає, — це помилка коду, а не привід мовчати."""


P = {
    # ── пропозиція ланцюга ────────────────────────────────────────────────
    "chain.head": {
        "uk": "Одна система цю задачу не покриває цілком.",
        "ru": "Одна система эту задачу целиком не покрывает.",
        "en": "A single system does not cover this task completely.",
    },
    "chain.propose": {
        "uk": "Пропоную ланцюг із %(n)d систем:",
        "ru": "Предлагаю цепочку из %(n)d систем:",
        "en": "I propose a chain of %(n)d systems:",
    },
    "chain.price": {
        "uk": "Орієнтовна вартість — близько $%(est).2f; більше $%(cap).2f не витрачу — "
              "зупинюсь і скажу.",
        "ru": "Ориентировочная стоимость — около $%(est).2f; больше $%(cap).2f не потрачу — "
              "остановлюсь и скажу.",
        "en": "Estimated cost is about $%(est).2f; I will not spend more than $%(cap).2f — "
              "I will stop and tell you.",
    },
    "chain.price_note": {
        "uk": "Ціна саме орієнтовна: вартість наступного кроку залежить від обсягу "
              "проміжного результату, якого ще немає.",
        "ru": "Цена именно ориентировочная: стоимость следующего шага зависит от объёма "
              "промежуточного результата, которого ещё нет.",
        "en": "The price is an estimate: the next step's cost depends on the size of the "
              "intermediate result, which does not exist yet.",
    },
    "chain.order": {
        "uk": "Наряд %(id)s.", "ru": "Наряд %(id)s.", "en": "Order %(id)s.",
    },
    "chain.run_q": {
        "uk": "Запускати?", "ru": "Запускать?", "en": "Run it?",
    },
    # ── кнопки згоди ──────────────────────────────────────────────────────
    "btn.run": {"uk": "▶ Запускати", "ru": "▶ Запускать", "en": "▶ Run it"},
    "btn.skip": {"uk": "✖ Не треба", "ru": "✖ Не нужно", "en": "✖ Not now"},
    "btn.do": {"uk": "✔ Зробити", "ru": "✔ Сделать", "en": "✔ Do it"},
    "btn.dont": {"uk": "✖ Не робити", "ru": "✖ Не делать", "en": "✖ Don\'t"},
    "hands.cancelled": {
        "uk": "Скасовано — у платформі нічого не змінив.",
        "ru": "Отменено — в платформе ничего не изменил.",
        "en": "Cancelled — nothing was changed in the platform.",
    },
    "ask.free_hint": {
        "uk": "Або просто напишіть словами — я зрозумію.",
        "ru": "Или просто напишите словами — я пойму.",
        "en": "Or just say it in your own words — I will understand.",
    },
    "ask.unclear": {
        "uk": "Не зрозумів, що саме обрано — нічого не запускав.",
        "ru": "Не понял, что именно выбрано — ничего не запускал.",
        "en": "I could not tell which option was chosen — nothing was started.",
    },
    "ask.used": {
        "uk": "Цю пропозицію вже виконано — вдруге не роблю. "
              "Треба ще раз — попросіть заново.",
        "ru": "Это предложение уже выполнено — второй раз не делаю. "
              "Нужно ещё раз — попросите заново.",
        "en": "This proposal has already been carried out — I will not repeat it. "
              "Ask again if you need it once more.",
    },
    "chain.skipped": {
        "uk": "Гаразд, не запускаю. Скажіть, коли буде треба.",
        "ru": "Хорошо, не запускаю. Скажите, когда понадобится.",
        "en": "All right, not starting it. Tell me when you need it.",
    },
    "chain.gone": {
        "uk": "Наряд уже не чекає згоди — запускати нічого.",
        "ru": "Наряд больше не ждёт согласия — запускать нечего.",
        "en": "The order is no longer waiting for consent — there is nothing to run.",
    },
    # ── пауза за вартістю ─────────────────────────────────────────────────
    "pause.q": {
        "uk": "Робота на паузі за вартістю. Що робимо?",
        "ru": "Работа на паузе по стоимости. Что делаем?",
        "en": "The work is paused on cost. What do we do?",
    },
    "btn.assemble": {
        "uk": "📦 Зібрати з готового",
        "ru": "📦 Собрать из готового",
        "en": "📦 Assemble from what is ready",
    },
    "btn.continue": {
        "uk": "▶ Довести до кінця (до $%(cap).2f)",
        "ru": "▶ Довести до конца (до $%(cap).2f)",
        "en": "▶ Finish it (up to $%(cap).2f)",
    },
    "btn.assemble.hint": {
        "uk": "Майже нічого не додасть до рахунку, але частина роботи лишиться незробленою.",
        "ru": "Почти ничего не добавит к счёту, но часть работы останется несделанной.",
        "en": "Adds almost nothing to the bill, but part of the work stays undone.",
    },
    "btn.continue.hint": {
        "uk": "Доплачується ЛИШЕ те, що лишилось: за вже зроблене повторно не платять.",
        "ru": "Доплачивается ТОЛЬКО оставшееся: за уже сделанное повторно не платят.",
        "en": "You pay only for what is left: already finished work is not charged twice.",
    },
    "pause.lost": {
        "uk": "Ця збережена робота вже застаріла — продовжити з неї не вийде.",
        "ru": "Эта сохранённая работа уже устарела — продолжить с неё не выйдет.",
        "en": "That saved work has expired — it cannot be continued.",
    },
    # ── картка розуміння ──────────────────────────────────────────────────
    "card.title": {
        "uk": "**Як я зрозумів задачу**",
        "ru": "**Как я понял задачу**",
        "en": "**How I understood the task**",
    },
    "card.system": {"uk": "Система", "ru": "Система", "en": "System"},
    "card.domain": {"uk": "Галузь", "ru": "Отрасль", "en": "Domain"},
    "card.jurisdiction": {"uk": "Право країни", "ru": "Право страны", "en": "Jurisdiction"},
    "card.output": {"uk": "Результат", "ru": "Результат", "en": "Result"},
    "card.fresh": {"uk": "Живі дані", "ru": "Живые данные", "en": "Live data"},
    "card.fresh_v": {"uk": "потрібні", "ru": "нужны", "en": "required"},
    "card.calc": {"uk": "Розрахунок", "ru": "Расчёт", "en": "Calculation"},
    "card.calc_v": {"uk": "потрібен", "ru": "нужен", "en": "required"},
    "card.route": {"uk": "Маршрут", "ru": "Маршрут", "en": "Route"},
    "card.route_v": {"uk": "замовлено", "ru": "заказан", "en": "ordered"},
    # ── типи результату ───────────────────────────────────────────────────
    "out.chat_answer": {"uk": "відповідь у чат", "ru": "ответ в чат", "en": "chat answer"},
    "out.document": {"uk": "документ", "ru": "документ", "en": "document"},
    "out.estimate_sheet": {"uk": "таблиця-оцінка", "ru": "таблица-оценка", "en": "estimate sheet"},
    "out.financial_model": {"uk": "фінансова модель", "ru": "финансовая модель",
                            "en": "financial model"},
    "out.report": {"uk": "звіт", "ru": "отчёт", "en": "report"},
    "out.system": {"uk": "працююча система", "ru": "работающая система",
                   "en": "a working system"},
}


def lang_of(value) -> str:
    """Мова користувача. Чуже значення НЕ вгадується — стає мовою за замовчуванням."""
    v = str(value or "").strip().lower()[:2]
    return v if v in LANGS else DEFAULT


def t(key: str, lang=None, **kw) -> str:
    """Службовий текст платформи. Ключа немає — ГОЛОСНА помилка."""
    row = P.get(key)
    if not row:
        raise PhraseError("службового тексту «%s» немає у словнику" % key)
    lg = lang_of(lang)
    text = row.get(lg) or row.get(DEFAULT)
    if not text:
        raise PhraseError("текст «%s» не перекладено мовою «%s»" % (key, lg))
    return (text % kw) if kw else text


def missing() -> list:
    """Напівперекладені ключі. Порожньо — словник цілий (стереже чек)."""
    bad = []
    for key, row in P.items():
        for lg in LANGS:
            if not (row.get(lg) or "").strip():
                bad.append("%s:%s" % (key, lg))
    return bad
