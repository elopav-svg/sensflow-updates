# -*- coding: utf-8 -*-
"""goods.py — БАЗА ТОВАРІВ І ПОСЛУГ КЛІЄНТА (зміна 451, 02.09.2026).

⭐⭐⭐ НАВІЩО (слово Андрія 02.09.2026): «Будь-яка компанія продає або товар, або
послугу, і менеджеру повинно бути зручно вибирати товар компанії з бази. Це
виключить можливість укладання угоди по неіснуючому товару, бо назва товару буде
братися з одного верифікованого місця.»

⚠ НЕ ПЛУТАТИ. `/api/crm/products` і `client_catalog.py` — це НАШІ системи, тобто
що клієнт купує В НАС (кухня сервіс-центру). Тут — те, що продає САМ КЛІЄНТ.

⛒ ПЛАТФОРМА НІЧОГО НЕ РАХУЄ. Рішення Андрія 02.09: суму угоди вводять руками, бо
знижки й акційні пропозиції втягнули б нас у бухгалтерію кожної окремої компанії
та кожної системи обліку. Тому тут немає ані множення «кількість × ціна», ані
підсумків: ціна зберігається такою, якою її ввела людина, і лише показується.

⭐⭐⭐ ОДИН ПЕРЕЛІК КОЛОНОК. `COLUMNS` — сталий універсальний перелік
характеристик. З нього платформа і ГЕНЕРУЄ шаблон для імпорту, і ЧИТАЄ той
імпорт. Другий перелік поруч розійшовся б із першим на першій же правці — і
шаблон почав би обіцяти колонку, якої читач не знає.

⛒ ПОРОЖНЄ НЕ ЗБЕРІГАЄТЬСЯ. Характеристика без значення означає «не стосується
цього товару», а не «забули заповнити», тому вона просто не лягає в запис. Так
екранам не треба вгадувати, показувати її чи ні: чого немає — того не видно.

⛒ АРТИКУЛ — КЛЮЧ ЗІСТАВЛЕННЯ. Руками не обовʼязковий, але якщо вказаний —
УНІКАЛЬНИЙ, бо саме за ним завтра ляже імпорт із обліку. Пакування (0,5 / 1 / 5 л)
— це ОКРЕМІ записи зі своїми артикулами, як і в обліку (погоджено 02.09).

⛒ ТОВАР НЕ ВИДАЛЯЄТЬСЯ, а стає недіючим: на ньому тримається історія угод. Той
самий закон, що й у ліквідації підрозділу.

⛒ НОМЕР НЕ МІНЯЄТЬСЯ НІКОЛИ. Назву можна перейменувати, артикул — виправити;
номер `t0001` лишається, бо на ньому тримаються позиції угод.
"""
import json
import one_writer

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import entity                     # спільне імʼя сутності на всю платформу
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій

config.refuse_live_state_for_checks(__name__)

DIR = config.CRM_DIR
GOODS_JSON = DIR / "goods.json"

# ── Закриті словники ─────────────────────────────────────────────────────────
KIND_GOODS = "goods"
KIND_SERVICE = "service"
KINDS = (KIND_GOODS, KIND_SERVICE)
KIND_NAMES = {KIND_GOODS: "товар", KIND_SERVICE: "послуга"}

# ⭐⭐⭐ БАЗОВІ ПОЛЯ — те, що є в будь-якого товару й будь-якої послуги.
BASE_COLUMNS = (
    ("name", "Назва"),
    ("sku", "Артикул"),
    ("kind", "Тип (товар або послуга)"),
    ("unit", "Одиниця виміру"),
    ("price", "Ціна"),
    ("currency", "Валюта"),
)

# ⭐⭐⭐ ХАРАКТЕРИСТИКИ — сталий універсальний перелік. Клієнт заповнює лише ті,
# що стосуються його товару; решта не зберігається й не показується.
TRAIT_COLUMNS = (
    ("packaging", "Пакування"),
    ("volume", "Обʼєм"),
    ("weight", "Вага"),
    ("size", "Розмір"),
    ("colour", "Колір"),
    ("material", "Матеріал"),
    ("brand", "Бренд або виробник"),
    ("vendor_code", "Код виробника"),
    ("country", "Країна походження"),
    ("warranty", "Гарантія"),
    ("shelf_life", "Термін придатності"),
    ("duration", "Тривалість"),
    ("barcode", "Штрихкод"),
    ("vat", "Ставка ПДВ"),
    ("note", "Примітка"),
)

COLUMNS = BASE_COLUMNS + TRAIT_COLUMNS
TRAITS = tuple(k for k, _ in TRAIT_COLUMNS)
COLUMN_NAMES = dict(COLUMNS)

F_ARCHIVED = "archived"


class GoodsError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _load() -> dict:
    try:
        d = one_writer.read_json(GOODS_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("seq", 0)
    d.setdefault("goods", {})
    return d


def _save(d: dict) -> None:
    GOODS_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(GOODS_JSON, d)


def _new_id(d: dict) -> str:
    seq = int(d.get("seq") or 0) + 1
    while ("t%04d" % seq) in d["goods"]:
        seq += 1
    d["seq"] = seq
    return "t%04d" % seq


def ref(gid) -> str:
    return entity.ref(entity.KIND_GOOD, _s(gid))


def _to_protocol(action: str, gid: str, what: str) -> None:
    """Хто зберігає — той і звітує (закон 171)."""
    try:
        protocol.write(action, ref(gid), note=what)
    except Exception:
        pass


# ── ЧИТАННЯ ─────────────────────────────────────────────────────────────────
def exists(gid) -> bool:
    return _s(gid) in _load()["goods"]


def get(gid):
    g = _load()["goods"].get(_s(gid))
    return dict(g) if g else None


def title(gid) -> str:
    g = _load()["goods"].get(_s(gid))
    return _s((g or {}).get("name"))


def is_archived(g) -> bool:
    """ОДИН ЧИТАЧ на весь продукт: відсутність поля — це «живий», а не «невідомо»."""
    if isinstance(g, str):
        g = _load()["goods"].get(_s(g)) or {}
    return bool((g or {}).get(F_ARCHIVED))


def by_sku(sku) -> str:
    """Номер власника артикула («» — нічий). Порожній артикул нічий ЗАВЖДИ."""
    s = _s(sku)
    if not s:
        return ""
    low = s.casefold()
    for gid, g in _load()["goods"].items():
        if _s(g.get("sku")).casefold() == low:
            return gid
    return ""


def all_goods(kind: str = "", archived=None) -> list:
    """Уся база; за потреби — лише один тип або один стан.

    ⚠ `archived=None` — УСІ: жоден старий виклик не сміє мовчки почати бачити
    менше, ніж бачив учора."""
    k = _s(kind)
    if k and k not in KINDS:
        raise GoodsError("Невідомий тип «%s». Відомі: %s."
                         % (k, ", ".join(KIND_NAMES[x] for x in KINDS)))
    out = []
    for gid, g in _load()["goods"].items():
        if k and _s(g.get("kind")) != k:
            continue
        if archived is not None and is_archived(g) != bool(archived):
            continue
        out.append(dict(g))
    out.sort(key=lambda x: _s(x.get("name")).casefold())
    return out


def count(archived=None) -> dict:
    d = _load()["goods"]
    pop = {k: v for k, v in d.items()
           if archived is None or is_archived(v) == bool(archived)}
    return {
        "all": len(pop),
        "live": sum(1 for v in d.values() if not is_archived(v)),
        "archived": sum(1 for v in d.values() if is_archived(v)),
        "total": len(d),
        KIND_GOODS: sum(1 for v in pop.values() if _s(v.get("kind")) == KIND_GOODS),
        KIND_SERVICE: sum(1 for v in pop.values() if _s(v.get("kind")) == KIND_SERVICE),
    }


# ── ПЕРЕВІРКИ ───────────────────────────────────────────────────────────────
def _check_kind(kind: str) -> str:
    k = _s(kind) or KIND_GOODS
    if k not in KINDS:
        raise GoodsError("Невідомий тип «%s». Відомі: %s."
                         % (k, ", ".join(KIND_NAMES[x] for x in KINDS)))
    return k


def _check_sku(sku, owner: str = "") -> str:
    """Артикул: не обовʼязковий, але якщо є — чужим бути не може."""
    s = _s(sku)
    if not s:
        return ""
    other = by_sku(s)
    if other and other != _s(owner):
        raise GoodsError("Артикул «%s» уже належить запису %s («%s»)."
                         % (s, other, title(other)))
    return s


def _check_traits(traits) -> dict:
    """Порожнє не зберігається; невідома характеристика — відмова.

    ⛒ Перелік характеристик СТАЛИЙ: саме з нього платформа зробить шаблон
    імпорту. Дозволити довільну колонку означало б, що шаблон нічого не
    обіцяє, а імпорт починає вгадувати."""
    out = {}
    for key, val in dict(traits or {}).items():
        k = _s(key)
        if k not in TRAITS:
            raise GoodsError("Невідома характеристика «%s». Відомі: %s."
                             % (k, ", ".join(TRAITS)))
        v = _s(val)
        if v:
            out[k] = v
    return out


# ── ЗАПИС ───────────────────────────────────────────────────────────────────
@one_writer.guard("GOODS_JSON")
def create(name, kind: str = KIND_GOODS, sku="", unit="", price="",
           currency="", traits=None, source: str = "manual") -> dict:
    """Завести товар або послугу. Назва обовʼязкова, решта — за бажанням."""
    nm = _s(name)
    if not nm:
        raise GoodsError("Товар без назви не заводиться.")
    k = _check_kind(kind)
    s = _check_sku(sku)
    tr = _check_traits(traits)
    d = _load()
    gid = _new_id(d)
    now = clock.now()
    d["goods"][gid] = {
        "id": gid,
        "name": nm,
        "sku": s,
        "kind": k,
        "unit": _s(unit),
        # ⛒ Ціна — ТЕКСТ, яким його ввела людина: платформа нічого не рахує.
        "price": _s(price),
        "currency": _s(currency),
        "traits": tr,
        F_ARCHIVED: False,
        # ⛒ Звідки запис: рука чи облік. Потрібне, щоб імпорт не затирав
        # заведене людиною.
        "source": _s(source) or "manual",
        "created": now,
        "updated": now,
    }
    _save(d)
    _to_protocol(protocol.A_GOOD_CREATED, gid,
                 "«%s» · %s%s" % (nm, KIND_NAMES[k],
                                  (" · артикул %s" % s) if s else ""))
    return dict(d["goods"][gid])


@one_writer.guard("GOODS_JSON")
def _mutate(gid: str, patch_fn, what: str, action: str = "") -> dict:
    """ОДНА точка запису на всю базу: хто зберігає — той і звітує."""
    key = _s(gid)
    d = _load()
    g = d["goods"].get(key)
    if not g:
        raise GoodsError("Товару %s немає в базі." % (key or "«»"))
    patch_fn(g)
    g["updated"] = clock.now()
    d["goods"][key] = g
    _save(d)
    _to_protocol(_s(action) or protocol.A_GOOD_CHANGED, key, what)
    return dict(g)


def set_fields(gid, **fields) -> dict:
    """Правка базових полів. Невідоме поле — відмова, а не тихе мовчання."""
    key = _s(gid)
    known = {"name", "sku", "kind", "unit", "price", "currency"}
    unknown = sorted(set(fields) - known)
    if unknown:
        raise GoodsError("Невідоме поле %s. Відомі: %s."
                         % (", ".join(unknown), ", ".join(sorted(known))))
    if not exists(key):
        raise GoodsError("Товару %s немає в базі." % (key or "«»"))
    said = []
    if "name" in fields:
        nm = _s(fields["name"])
        if not nm:
            raise GoodsError("Назву не можна стерти: товар без назви не існує.")
        said.append("назва → «%s»" % nm)
    if "kind" in fields:
        fields["kind"] = _check_kind(fields["kind"])
        said.append("тип → %s" % KIND_NAMES[fields["kind"]])
    if "sku" in fields:
        fields["sku"] = _check_sku(fields["sku"], owner=key)
        said.append("артикул → «%s»" % (fields["sku"] or "порожньо"))
    for f in ("unit", "price", "currency"):
        if f in fields:
            said.append("%s → «%s»" % (COLUMN_NAMES[f], _s(fields[f])))

    def _p(g):
        for f, v in fields.items():
            g[f] = _s(v) if f != "kind" else v

    return _mutate(key, _p, "; ".join(said) or "без змін")


def set_traits(gid, traits) -> dict:
    """Правка характеристик. Порожнє значення ПРИБИРАЄ характеристику."""
    key = _s(gid)
    if not exists(key):
        raise GoodsError("Товару %s немає в базі." % (key or "«»"))
    raw = dict(traits or {})
    for k in raw:
        if _s(k) not in TRAITS:
            raise GoodsError("Невідома характеристика «%s». Відомі: %s."
                             % (_s(k), ", ".join(TRAITS)))
    said = []

    def _p(g):
        cur = dict(g.get("traits") or {})
        for k, v in raw.items():
            kk, vv = _s(k), _s(v)
            if vv:
                cur[kk] = vv
                said.append("%s → «%s»" % (COLUMN_NAMES[kk], vv))
            elif kk in cur:
                del cur[kk]
                said.append("%s прибрано" % COLUMN_NAMES[kk])
        g["traits"] = cur

    return _mutate(key, _p, "; ".join(said) or "без змін")


def set_archived(gid, flag: bool = True) -> dict:
    """Прибрати з обігу або повернути. ⛔ Повтор — відмова СЛОВАМИ, а не тихе
    «гаразд»: інакше підсумок групової дії показав би не те, що сталось."""
    key = _s(gid)
    g = get(key)
    if not g:
        raise GoodsError("Товару %s немає в базі." % (key or "«»"))
    want = bool(flag)
    if is_archived(g) == want:
        raise GoodsError("«%s» і так %s." % (_s(g.get("name")),
                                             "не в обігу" if want else "в обігу"))

    def _p(x):
        x[F_ARCHIVED] = want

    return _mutate(key, _p, "не в обігу" if want else "повернено в обіг",
                   action=protocol.A_GOOD_ARCHIVED)


def template_columns() -> list:
    """Колонки шаблону імпорту. ⭐ ОДНЕ ДЖЕРЕЛО і для шаблону, і для читача."""
    return [{"key": k, "title": t} for k, t in COLUMNS]
