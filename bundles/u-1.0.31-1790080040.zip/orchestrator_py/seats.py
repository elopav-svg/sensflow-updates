# -*- coding: utf-8 -*-
"""seats.py — ЛІЧИЛЬНИК МІСЦЬ (зміна 508, 05.09.2026).

⛔ ВІН НІЧОГО НЕ ОБМЕЖУЄ І НІКОГО НЕ ВИГАНЯЄ.
Рішення Андрія 04.09.2026: «місцями не торгуємо» — безлімітні користувачі це
наша конкурентна перевага, а не товар. Але число знати треба, і знати його
треба З ПЕРШОГО ДНЯ, бо заднім числом його вже не порахуєш.

НАВІЩО ВІН ПОТРІБЕН НАСПРАВДІ. Ми міряємо все технічне — мілісекунди,
запити на секунду, розмір бази — і нічого ділового. Скільки людей у компанії
клієнта справді щодня працює в платформі, не знає ніхто, зокрема сам клієнт.
Це перше наше число, яке говорить про ЛЮДЕЙ, а не про залізо: на нього можна
спертись і в розмові про ціну, і в розмові про користь.

ЩО РАХУЄМО (слово Андрія 04.09):
  • скільки людей у системі ЗАРАЗ;
  • ПІК за сьогодні;
  • ПІК за поточний місяць;
  • скільки РІЗНИХ людей заходило цього місяця;
  • і все це лягає в журнал з першого дня.

🩸 РАХУЄМО ЛЮДЕЙ, А НЕ ВІКОНЦЯ. Одна людина може відкрити платформу на
робочому компʼютері й на телефоні — це дві сесії й один працівник. Лічильник,
що рахує токени, збрехав би клієнту вдвічі саме тоді, коли на нього дивляться.

ЗВІДКИ БЕРУТЬСЯ ЧИСЛА. Модуль НЕ читає сесії сам — про них знає шар «хто це»
(`taskdesk_identity`), і другий читач того самого файла був би тим самим класом
біди, що й другий писар. Тому напрям один: шар «хто це» ПОВІДОМЛЯЄ лічильнику,
хто зараз у системі, а лічильник тільки веде журнал.

ЗАПИС — ЧЕРЕЗ ОДНОГО ПИСАРЯ. Журнал живе поруч із сесіями і пишеться в ті самі
миті, коли десятеро заходять одночасно.

Жодних зовнішніх залежностей.
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import clock      # noqa: E402
import config     # noqa: E402
import one_writer  # noqa: E402

DESK_DIR = config.STATE_DIR / "taskdesk"
SEATS_JSON = DESK_DIR / "seats.json"

# Скільки днів тримаємо поденно. Журнал має жити «з першого дня», але не рости
# вічно: 1500 днів — це понад чотири роки, а дата початку зберігається окремо
# і не стирається ніколи.
KEEP_DAYS = 1500

# Скільки різних людей за день записуємо поіменно. Далі число зростає, а
# перелік — ні: журнал не має перетворюватись на базу відвідувань.
MAX_PEOPLE_PER_DAY = 500


def _day(ts: str = "") -> str:
    return (ts or clock.now())[:10]


def _month(ts: str = "") -> str:
    return (ts or clock.now())[:7]


def _empty() -> dict:
    return {"since": _day(), "days": {}}


def load() -> dict:
    """ЄДИНИЙ ЧИТАЧ журналу. Побитий файл не валить вхід у систему — лічильник
    важливий, але не настільки, щоб через нього не пустити людину на роботу."""
    if not SEATS_JSON.exists():
        return _empty()
    try:
        import json
        raw = one_writer.read_json(SEATS_JSON)
    except Exception:
        return _empty()
    if not isinstance(raw, dict):
        return _empty()
    days = raw.get("days")
    if not isinstance(days, dict):
        days = {}
    clean = {}
    for d, rec in days.items():
        if not isinstance(rec, dict):
            continue
        people = rec.get("people")
        clean[str(d)] = {
            "peak": max(0, int(rec.get("peak") or 0)),
            "people": [str(p) for p in people][:MAX_PEOPLE_PER_DAY]
            if isinstance(people, list) else [],
            "seen": max(0, int(rec.get("seen") or 0)),
        }
    since = str(raw.get("since") or "")
    if len(since) != 10:
        since = min(clean) if clean else _day()
    return {"since": since, "days": clean}


@one_writer.guard("SEATS_JSON")
def note(account_ids) -> dict:
    """Записати, хто зараз у системі. Викликається шаром «хто це» після кожної
    зміни складу сесій. Пік тільки росте — день закривається своїм максимумом."""
    ids = []
    for a in (account_ids or []):
        a = str(a or "").strip()
        if a and a not in ids:
            ids.append(a)

    d = load()
    today = _day()
    rec = d["days"].get(today) or {"peak": 0, "people": [], "seen": 0}
    rec["peak"] = max(int(rec.get("peak") or 0), len(ids))
    known = list(rec.get("people") or [])
    for a in ids:
        if a not in known:
            if len(known) < MAX_PEOPLE_PER_DAY:
                known.append(a)
            rec["seen"] = int(rec.get("seen") or 0) + 1
    rec["people"] = known
    rec["seen"] = max(int(rec.get("seen") or 0), len(known))
    d["days"][today] = rec

    if len(d["days"]) > KEEP_DAYS:
        for old in sorted(d["days"])[:len(d["days"]) - KEEP_DAYS]:
            d["days"].pop(old, None)

    one_writer.write_json(SEATS_JSON, d)
    return d


def stats(now_count: int = 0) -> dict:
    """Числа для екрана. `now_count` дає шар «хто це» — він єдиний знає сесії."""
    d = load()
    today = _day()
    month = _month()
    today_rec = d["days"].get(today) or {}

    peak_month = 0
    people_month = set()
    seen_month = 0
    days_month = 0
    for day, rec in d["days"].items():
        if not day.startswith(month):
            continue
        days_month += 1
        peak_month = max(peak_month, int(rec.get("peak") or 0))
        for p in (rec.get("people") or []):
            people_month.add(p)
        seen_month = max(seen_month, len(people_month))

    now = max(0, int(now_count or 0))
    return {
        "now": now,
        "peak_today": max(int(today_rec.get("peak") or 0), now),
        "peak_month": max(peak_month, now),
        "unique_month": len(people_month),
        "days_this_month": days_month,
        "since": d["since"],
        "days_kept": len(d["days"]),
        "limits": False,          # 🩸 лічильник НІКОГО не обмежує
    }


def console_lines(now_count: int = 0) -> list:
    """Те саме людськими словами — для вікна запуску й для консолі."""
    s = stats(now_count)
    return [
        "Місць у системі зараз: %d" % s["now"],
        "Пік за сьогодні: %d · за місяць: %d" % (s["peak_today"], s["peak_month"]),
        "Різних працівників цього місяця: %d" % s["unique_month"],
        "Лічильник нікого не обмежує — рахунок ведеться з %s" % s["since"],
    ]
