# -*- coding: utf-8 -*-
"""manual_build.py — МАНУАЛ ПЛАТФОРМИ: ОДНЕ ДЖЕРЕЛО, ДВА ВИХОДИ (зміна 567, 12.09.2026).

⭐⭐⭐ НАВІЩО. Правда про встановлення платформи жила в пʼяти місцях одночасно:
у `Інструкція_встановлення.docx` (червень 2026 — відсилає до `run.bat`, якого в
пакеті немає взагалі), у чек-листі зміни, у батниках служби, у `README.md` і в
голові того, хто ставив останній раз. Пʼять писарів однієї правди — це
гарантія, що десь вона вже неправда, і неправда ТИХА.

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ: ДОКУМЕНТ — ПОХІДНЕ, А НЕ ДЖЕРЕЛО.
Джерело одне: `Документація/МАНУАЛ_SensFlow.md`. З нього народжуються:
  • документ для людей  — `Документація/05_SensFlow_Мануал_платформи.docx`;
  • база знань консультанта платформи — `generated_systems/platform_consultant/Knowledge/`.
Обидва похідні ЗБИРАЮТЬСЯ, і власного тексту цей модуль не має НІ РЯДКА:
якби мав — народився б шостий писар.

⛔ ЧИСЛА НЕ ПИШЕ РУКА. У джерелі стоять мітки `{{ІМʼЯ}}`, а значення дає
`MARKS` — кожне з ТОГО МІСЦЯ, ЯКЕ ЗА НЬОГО ВІДПОВІДАЄ: порт із `config`,
мінімальна версія Python і документні пакети — З ТЕКСТУ ЗАПУСКАЧА, який
пише складальник клієнтського пакета; назва завдання служби — з
`service_common.ps1`; строки ключів — з `https_access`; числа про систему —
з `platform_numbers`. Мітка, значення якої порахувати не вдалося, — це
ВІДМОВА З ПРИЧИНОЮ, а не порожній рядок у документі.

⚠ FAIL-CLOSED. Не читається джерело, не порахувалась мітка, лишилась мітка в
похідному файлі — збирач каже це вголос і повертає ненульовий код.

Запуск: python3 manual_build.py            — показати мітки й перевірити джерело
        python3 manual_build.py --kb       — перезібрати базу знань консультанта
        python3 manual_build.py --docx     — перезібрати документ для людей
        python3 manual_build.py --all      — і те, і те
"""
import origin
import ast
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent          # orchestrator_py
PLATFORM = HERE.parent                          # AI_Orchestrator_Platform

SOURCE = PLATFORM / "Документація" / "МАНУАЛ_SensFlow.md"
DOCX_OUT = PLATFORM / "Документація" / "05_SensFlow_Мануал_платформи.docx"
CONSULTANT_ID = "platform_consultant"
KB_DIR = PLATFORM / "generated_systems" / CONSULTANT_ID / "Knowledge"

MARK_RE = re.compile(r"\{\{([A-Z_]+)\}\}")
# Заголовок розділу джерела: «## 1. НАЗВА». Підрозділи (###) лишаються всередині.
SECTION_RE = re.compile(r"^##\s+(\d+)\.\s+(.+?)\s*$", re.M)


# ── ⭐⭐⭐ 595. ДОРІЖКИ ДЖЕРЕЛА: ОДИН ТЕКСТ, РІЗНІ ЧИТАЧІ ────────────────────
# Правда про встановлення одна, але шматки її адресні: частина стосується лише
# Windows, частина лише Mac, частина — лише нас (наші кнопки, наші числа), і
# частина — лише клієнта. Доріжка позначається в ДЖЕРЕЛІ парою маркерів:
#     <!--ONLY WIN--> ... <!--/ONLY WIN-->
# Мануал для нас бере ВСІ доріжки, інструкція клієнта — свою машину плюс
# «клієнту». ⛒ Маркер незакритий або незнаний — ВІДМОВА, а не тихо викинутий
# шматок: мовчазна втрата абзацу і є те, чим документ бреше.
TRACKS = ("WIN", "MAC", "US", "CLIENT")
TRACK_OPEN = re.compile(r"^\s*<!--ONLY ([A-Z]+)-->\s*$")
TRACK_CLOSE = re.compile(r"^\s*<!--/ONLY ([A-Z]+)-->\s*$")


class ManualError(Exception):
    """Відмова з причиною словами. Тиха відмова = зівʼялий документ."""


def apply_tracks(text: str, keep=None) -> str:
    """Лишити рядки дозволених доріжок; маркери прибрати завжди."""
    allow = set(TRACKS if keep is None else keep)
    out, stack = [], []
    for i, line in enumerate(text.splitlines(), 1):
        mo = TRACK_OPEN.match(line)
        if mo:
            if mo.group(1) not in TRACKS:
                raise ManualError("рядок %d: незнана доріжка «%s»" % (i, mo.group(1)))
            stack.append(mo.group(1))
            continue
        mc = TRACK_CLOSE.match(line)
        if mc:
            if not stack or stack[-1] != mc.group(1):
                raise ManualError("рядок %d: доріжку «%s» закрито не там" % (i, mc.group(1)))
            stack.pop()
            continue
        if all(t in allow for t in stack):
            out.append(line)
    if stack:
        raise ManualError("доріжку «%s» не закрито до кінця файла" % stack[-1])
    return "\n".join(out)


def _read(path: Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except Exception as ex:
        raise ManualError("не читається %s: %s" % (path.name, ex))


# ── ЗВІДКИ БЕРЕТЬСЯ КОЖНЕ ЗНАЧЕННЯ ──────────────────────────────────────────
def _launcher_text() -> str:
    """Текст віндового запускача — його пише складальник клієнтського пакета.
    🩸 Саме ВІН вимагає версію Python і доставляє документні пакети, тому
    питаємо його, а не свою памʼять."""
    return _read(HERE / "make_client_build.py")


def python_min() -> str:
    src = _launcher_text()
    m = re.search(r"sys\.version_info\s*>=\s*\((\d+)\s*,\s*(\d+)\)", src)
    if not m:
        raise ManualError("у тексті запускача немає перевірки версії Python")
    return "%s.%s" % (m.group(1), m.group(2))


def doc_packages() -> str:
    src = _launcher_text()
    found = re.findall(r"pip install --quiet ([a-z0-9\-]+)'", src)
    uniq = []
    for name in found:
        if name not in uniq:
            uniq.append(name)
    if len(uniq) < 2:
        raise ManualError("у тексті запускача не видно документних пакетів")
    return ", ".join(uniq)


def launcher_name() -> str:
    src = _launcher_text()
    m = re.search(r"CLIENT_LAUNCHERS\s*=\s*(\([^)]*\))", src)
    if not m:
        raise ManualError("у складальнику немає переліку CLIENT_LAUNCHERS")
    names = [str(x) for x in ast.literal_eval(m.group(1))]
    bat = [n for n in names if n.lower().endswith(".bat")]
    if not bat:
        raise ManualError("серед запускачів немає .bat")
    return bat[0]


def launcher_mac() -> str:
    """Запускач Mac-збірки. Той самий перелік складальника, інша машина:
    інструкція, що кличе чужий запускач, — це вада, яка вже поїхала клієнту."""
    src = _launcher_text()
    m = re.search(r"CLIENT_LAUNCHERS\s*=\s*(\([^)]*\))", src)
    if not m:
        raise ManualError("у складальнику немає переліку CLIENT_LAUNCHERS")
    names = [str(x) for x in ast.literal_eval(m.group(1))]
    mac = [n for n in names if n.lower().endswith(".command")]
    if not mac:
        raise ManualError("серед запускачів немає .command")
    return mac[0]


def _ps_var(name: str) -> str:
    src = _read(PLATFORM / "service_common.ps1")
    m = re.search(r"\$%s\s*=\s*\"([^\"]+)\"" % name, src)
    if m:
        return m.group(1)
    m = re.search(r"\$%s\s*=\s*Join-Path\s+\$SfRoot\s+\"([^\"]+)\"" % name, src)
    if m:
        return m.group(1)
    raise ManualError("у service_common.ps1 не знайдено $%s" % name)


def service_task() -> str:
    return _ps_var("SfTask")


def service_log() -> str:
    return _ps_var("SfLog")


def _server_src() -> str:
    return _read(HERE / "server.py")


def office_key_url() -> str:
    """Адреса, якою віддається ключ офісу. Питаємо САМІ ДВЕРІ в server.py."""
    src = _server_src()
    m = re.search(r'path == "(/api/taskdesk/https/office_key)"', src)
    if not m:
        raise ManualError("у server.py немає дверей ключа офісу")
    return m.group(1)


def office_key_file_out() -> str:
    """Імʼя файла, під яким ключ офісу приходить людині — з самих дверей."""
    src = _server_src()
    m = re.search(r'filename="([^"]+\.crt)"', src)
    if not m:
        raise ManualError("двері ключа офісу не називають імені файла")
    return m.group(1)


def _access_html() -> str:
    return _read(HERE / "ui" / "taskdesk_access.html")


def access_screen() -> str:
    """Як екран називається ЛЮДИНІ. Беремо з самого екрана."""
    html = _access_html()
    m = re.search(r"<title>\s*([^<]+?)\s*(?:—|-)\s*SensFlow\s*</title>", html)
    if not m:
        raise ManualError("екран доступів не називає себе в <title>")
    return m.group(1).strip()


def office_key_button() -> str:
    html = _access_html()
    m = re.search(r'id="sec-key"[^>]*>([^<]+)<', html)
    if not m:
        raise ManualError("на екрані доступів немає кнопки ключа офісу")
    return m.group(1).strip()


def setup_url() -> str:
    src = _server_src()
    if '"/setup"' not in src:
        raise ManualError("у server.py немає сторінки /setup")
    return "%s/setup" % console_url()


def console_url() -> str:
    import config
    return "http://127.0.0.1:%d" % int(config.PORT)


def certs_dir() -> str:
    import config
    d = Path(str(config.CERTS_DIR))
    return "%s/%s" % (HERE.name, d.name)


def _numbers(key: str):
    import platform_numbers
    fn = platform_numbers.LIVE.get(key)
    if not fn:
        raise ManualError("platform_numbers не знає числа «%s»" % key)
    return fn[0]()



# ── ТЕЛЕГРАМ: імена токенів і вимикачів беремо з ТИХ МОДУЛІВ, ЩО ЇХ ЧИТАЮТЬ ──
def _tg_token_env(role_fn: str) -> str:
    """Імʼя змінної з токеном — із самої функції, яка цей токен читає."""
    src = _read(HERE / "telegram_bot.py")
    pat = r'def ' + role_fn + r'\(\) -> str:\s*\n\s*return \(config\.ENV\.get\("([A-Z_]+)"\)'
    m = re.search(pat, src)
    if not m:
        raise ManualError("у telegram_bot.py не видно токена для %s" % role_fn)
    return m.group(1)


def tg_owner_token() -> str:
    return _tg_token_env("_orch_token")


def tg_support_token() -> str:
    return _tg_token_env("_support_token")


def tg_tasks_token() -> str:
    return _tg_token_env("_tasks_token")


def tg_allowed_ids() -> str:
    """Рядок бутстрап-ID — питаємо того, хто його розбирає."""
    src = _read(HERE / "telegram_access.py")
    m = re.search(r'config\.ENV\.get\("([A-Z_]*CHAT_IDS)"\)', src)
    if not m:
        raise ManualError("у telegram_access.py не видно переліку довірених ID")
    return m.group(1)


def tg_support_switch() -> str:
    src = _read(HERE / "config.py")
    m = re.search(r'[A-Z_]*SUPPORT_MODE\s*=\s*\(ENV\.get\("([A-Z_]+)"\)', src)
    if not m:
        raise ManualError("у config.py не видно тумблера підтримки")
    return m.group(1)


def tg_screen() -> str:
    html = _read(HERE / "ui" / "telegram.html")
    m = re.search(r'<title>\s*SensFlow\s*(?:—|-)\s*([^<]+?)\s*</title>', html)
    if not m:
        raise ManualError("екран телеграму не називає себе в <title>")
    return m.group(1).strip()


def tg_screen_url() -> str:
    src = _server_src()
    if '"/telegram"' not in src:
        raise ManualError("у server.py немає сторінки /telegram")
    return "%s/telegram" % console_url()


def support_kb() -> str:
    import config
    return Path(str(config.SUPPORT_KB_PATH)).name


def env_file() -> str:
    """Файл настройок, у якому живуть токени: імʼя знає той, хто в нього пише."""
    src = _read(HERE / "config.py")
    m = re.search(r'ENV_LOCAL\s*=\s*[A-Za-z_]+\s*/\s*"([^"]+)"', src)
    if not m:
        m = re.search(r'"(\.env\.local)"', src)
    if not m:
        raise ManualError("у config.py не видно імені файла настройок")
    return "%s/%s" % (HERE.name, m.group(1))


# ── ЩОДЕННА РОБОТА Й ДАНІ: числа й переліки — з тих модулів, що ними живуть ──
def digest_hour() -> str:
    return str(__import__("taskdesk_digest").HOUR)


def _client_bat_for(script: str) -> str:
    """Імʼя кнопки в корені пакета, яка запускає ЦЕЙ механізм.

    🩸 571. Перша редакція питала «яка кнопка експорту?» СЛОВОМ у назві
    («data», «xport») і брала перше, що трапиться в НЕВПОРЯДКОВАНІЙ множині.
    Доки кнопка зі словом «data» була одна, це працювало випадково; друга така
    кнопка зробила б мітку в документі лотереєю — і мануал обіцяв би людині не
    ту кнопку. Кнопку впізнаємо за МЕХАНІЗМОМ, який вона запускає."""
    src = _launcher_text()
    m = re.search(r'CLIENT_ROOT_BATS\s*=\s*(\{[^}]*\})', src)
    if not m:
        raise ManualError("у складальнику немає переліку кнопок клієнта")
    try:
        pairs = ast.literal_eval(m.group(1))
    except Exception as ex:
        raise ManualError("перелік кнопок клієнта не читається: %s" % ex)
    if not isinstance(pairs, dict):
        raise ManualError("перелік кнопок клієнта не називає механізмів")
    for bat, mod in pairs.items():
        if str(mod) == script:
            return str(bat)
    raise ManualError("серед кнопок клієнта немає тієї, що запускає %s" % script)


def export_bat() -> str:
    return _client_bat_for("client_export.py")


def restore_bat() -> str:
    return _client_bat_for("client_restore.py")


def data_archive() -> str:
    """Як зветься архів даних — знає той, хто його творить."""
    import client_export
    val = str(getattr(client_export, "ARCHIVE_PREFIX", "")).strip()
    if not val:
        raise ManualError("client_export.py не називає імені архіву даних")
    return val


def backups_dir() -> str:
    """Тека, у якій лежать копії перед перезаписом. Питаємо ОНОВЛЕННЯ: саме
    воно оголошує цю теку недоторканною, і саме тому копія переживає оновлення."""
    import update
    rows = [str(x).rstrip("/") for x in getattr(update, "_PROTECTED", ())]
    pick = [r for r in rows if r.endswith("_backups")]
    if not pick:
        raise ManualError("update.py не оголошує теки бекапів захищеною")
    return pick[0]


def update_protected() -> str:
    """Що оновлення не чіпає — питаємо САМЕ оновлення, а не свою памʼять."""
    import update
    rows = [str(x) for x in getattr(update, "_PROTECTED", ())]
    if not rows:
        raise ManualError("update.py не називає захищених від оновлення місць")
    return ", ".join("`%s`" % r for r in rows)


def model_perpetual() -> str:
    import license as _lic
    val = str(getattr(_lic, "MODEL_PERPETUAL", "")).strip()
    if not val:
        raise ManualError("license.py не називає безстрокової моделі")
    return val


def logs_dir() -> str:
    import run_log
    val = str(getattr(run_log, "LOGS_DIR", "")).strip()
    if not val:
        raise ManualError("run_log.py не називає теки журналів")
    return val


# ⛒ ЗАКРИТИЙ ПЕРЕЛІК. Мітка, якої тут немає, НІКОЛИ не підставиться молча:
# нова мітка в джерелі заводиться ТУТ, свідомо, разом із тим, хто її знає.
MARKS = {
    "VERSION": lambda: str(__import__("config").APP_VERSION),
    "PORT": lambda: str(int(__import__("config").PORT)),
    "PYTHON_MIN": python_min,
    "DOC_PACKAGES": doc_packages,
    "LAUNCHER": launcher_name,
    "LAUNCHER_MAC": launcher_mac,
    "SERVICE_TASK": service_task,
    "SERVICE_LOG": service_log,
    "LOCAL_HOST": lambda: __import__("network_access").LOCAL_HOST,
    "CA_YEARS": lambda: str(__import__("https_access").CA_YEARS),
    "SRV_YEARS": lambda: str(__import__("https_access").SRV_YEARS),
    "CERTS_DIR": certs_dir,
    "OFFICE_KEY_URL": office_key_url,
    "OFFICE_KEY_FILE_OUT": office_key_file_out,
    "OFFICE_KEY_BUTTON": office_key_button,
    "ACCESS_SCREEN": access_screen,
    "MIN_PASSWORD": lambda: str(__import__("taskdesk_identity").MIN_PASSWORD),
    "SESSION_TTL": lambda: str(__import__("taskdesk_identity").SESSION_TTL_HOURS),
    "SETUP_URL": setup_url,
    "CONSOLE_URL": console_url,
    "SYSTEMS_TOTAL": lambda: str(_numbers("systems_total")),
    "PRODUCT_SYSTEMS": lambda: str(_numbers("product_systems")),
    "CHECKS": lambda: str(_numbers("checks")),
    "ENV_FILE": env_file,
    "TG_OWNER_TOKEN": tg_owner_token,
    "TG_SUPPORT_TOKEN": tg_support_token,
    "TG_TASKS_TOKEN": tg_tasks_token,
    "TG_ALLOWED_IDS": tg_allowed_ids,
    "TG_SUPPORT_SWITCH": tg_support_switch,
    "TG_SCREEN": tg_screen,
    "TG_SCREEN_URL": tg_screen_url,
    "SUPPORT_KB": support_kb,
    "CODE_TTL": lambda: str(__import__("taskdesk_link_codes").TTL_MIN),
    "CODE_LEN": lambda: str(__import__("taskdesk_link_codes").LENGTH),
    "DIGEST_HOUR": digest_hour,
    "EXPORT_BAT": export_bat,
    "RESTORE_BAT": restore_bat,
    "DATA_ARCHIVE": data_archive,
    "BACKUPS_DIR": backups_dir,
    "UPDATE_PROTECTED": update_protected,
    "MODEL_PERPETUAL": model_perpetual,
    "LOGS_DIR": logs_dir,
}


def values(only=None) -> dict:
    """Мітки й їхні значення. Не порахувалось — ВІДМОВА, а не порожнє.

    ⛒ 622г. РАХУЄМО ЛИШЕ ТЕ, ЩО В ТЕКСТІ Є. Доти `values()` рахувала ВСІ мітки
    гуртом — і довідник на машині клієнта падав через мітку, якої в його тексті
    вже немає: `PYTHON_MIN` читає наш `make_client_build.py`, якого в клієнта
    не буває й не буде. Один мовчазний файл нашої кухні клав увесь екран.
    """
    out = {}
    want = set(MARKS) if only is None else {m for m in only if m in MARKS}
    for name, fn in MARKS.items():
        if name not in want:
            continue
        try:
            val = fn()
        except ManualError:
            raise
        except Exception as ex:
            raise ManualError("мітку %s не вдалося порахувати: %s" % (name, ex))
        val = "" if val is None else str(val).strip()
        if not val:
            raise ManualError("мітка %s порахувалась порожньою" % name)
        out[name] = val
    return out


# ── ДЖЕРЕЛО І ЙОГО ПЕРЕВІРКА ────────────────────────────────────────────────
def source_text() -> str:
    return _read(SOURCE)


def marks_in_source(text: str = None) -> list:
    return sorted(set(MARK_RE.findall(source_text() if text is None else text)))


def unknown_marks(text: str = None) -> list:
    return [m for m in marks_in_source(text) if m not in MARKS]


def filled(text: str = None) -> str:
    """Джерело з підставленими значеннями. Лишилась мітка — ВІДМОВА."""
    src = source_text() if text is None else text
    bad = unknown_marks(src)
    if bad:
        raise ManualError("у джерелі мітки, яких ніхто не знає: %s" % ", ".join(bad))
    vals = values(only=marks_in_source(src))
    out = MARK_RE.sub(lambda m: vals[m.group(1)], src)
    left = MARK_RE.findall(out)
    if left:
        raise ManualError("після підстановки лишились мітки: %s" % ", ".join(left))
    return out


def sections(text: str = None) -> list:
    """Розділи джерела: (номер, назва, текст). Консультант називає саме їх."""
    src = apply_tracks(filled()) if text is None else text
    hits = list(SECTION_RE.finditer(src))
    if not hits:
        raise ManualError("у джерелі немає жодного розділу «## N. Назва»")
    out = []
    for i, m in enumerate(hits):
        end = hits[i + 1].start() if i + 1 < len(hits) else len(src)
        out.append((m.group(1), m.group(2).strip(), src[m.start():end].strip()))
    return out


# ── ВИХІД 1: БАЗА ЗНАНЬ КОНСУЛЬТАНТА ────────────────────────────────────────
def kb_file_name(num: str, title: str) -> str:
    slug = re.sub(r"[^0-9A-Za-zА-Яа-яЄєІіЇїҐґ ]+", "", title).strip().replace(" ", "_")
    return "rozdil_%s_%s.md" % (num, slug[:60])


def build_kb(into: Path = None) -> dict:
    """Один файл на розділ. Назва розділу стоїть ПЕРШИМ рядком — саме її
    консультант назве людині як джерело відповіді.

    `into` — тека, куди складати. Потрібна чеку: він перевіряє збирача на
    СВОЇЙ теці й не чіпає живої бази знань."""
    secs = sections()
    kb = Path(into) if into else KB_DIR
    kb.mkdir(parents=True, exist_ok=True)
    made, kept = [], []
    for num, title, body in secs:
        name = kb_file_name(num, title)
        head = "# Розділ %s. %s\n\n> Джерело: МАНУАЛ_SensFlow.md, розділ %s. " \
               "Збирач: manual_build.py. Руками не правити.\n\n" % (num, title, num)
        path = kb / name
        text = head + body + "\n"
        old = path.read_text(encoding="utf-8") if path.exists() else None
        path.write_text(text, encoding="utf-8")
        (made if old != text else kept).append(name)
    # ⛒ Розділ, якого більше немає в джерелі, не лишається в базі знань
    # привидом: інакше консультант відповідав би з вчорашнього мануала.
    alive = {kb_file_name(n, t) for n, t, _ in secs}
    dropped = []
    for p in sorted(kb.glob("rozdil_*.md")):
        if p.name not in alive:
            p.unlink()
            dropped.append(p.name)
    return {"sections": len(secs), "written": made, "unchanged": kept,
            "dropped": dropped, "dir": str(kb)}


# ── ВИХІД 2: ДОКУМЕНТ ДЛЯ ЛЮДЕЙ ─────────────────────────────────────────────
def build_docx(out_path: Path = None) -> dict:
    """Документ збирається з ТОГО САМОГО тексту. Потрібен python-docx:
    немає — кажемо це вголос, а не робимо вигляд, що документ є."""
    try:
        import docx
        from docx.shared import Pt
    except Exception as ex:
        raise ManualError("немає python-docx (%s): pip install python-docx" % ex)
    out_path = Path(out_path) if out_path else DOCX_OUT
    text = apply_tracks(filled())
    return _render_docx(text, out_path)


def _render_docx(text: str, out_path: Path) -> dict:
    """Верстка .docx — ОДИН писар на всі похідні мануала."""
    import docx
    from docx.shared import Pt
    doc = docx.Document()
    style = doc.styles["Normal"]
    style.font.name = "Arial"
    style.font.size = Pt(10.5)
    for raw in text.splitlines():
        line = raw.rstrip()
        if line.startswith("> "):            # наші службові примітки джерела
            continue
        if line.startswith("# "):
            doc.add_heading(line[2:].strip(), level=0)
        elif line.startswith("## "):
            doc.add_heading(line[3:].strip(), level=1)
        elif line.startswith("### "):
            doc.add_heading(line[4:].strip(), level=2)
        elif line.startswith("#### "):
            doc.add_heading(line[5:].strip(), level=3)
        elif line.startswith("| "):
            doc.add_paragraph(line.strip("| ").replace(" | ", " · "))
        elif line.startswith(("- ", "* ")):
            doc.add_paragraph(line[2:].strip(), style="List Bullet")
        elif re.match(r"^\d+\.\s", line):
            doc.add_paragraph(re.sub(r"^\d+\.\s", "", line), style="List Number")
        elif line.strip() in ("---", "```"):
            continue
        elif line.strip():
            doc.add_paragraph(line.strip())
    out_path.parent.mkdir(parents=True, exist_ok=True)
    doc.save(str(out_path))
    origin.stamp(out_path)   # ⛒ 583: ОДИН писар походження
    return {"path": str(out_path), "chars": len(text)}


# ── ВИХІД 3: ІНСТРУКЦІЯ ВСТАНОВЛЕННЯ ДЛЯ КЛІЄНТА ────────────────────────────
# ⛒⛒⛒ 595. Рукописної інструкції більше немає. Вона народжується з розділу 1
# цього ж джерела — під МАШИНУ і МОВУ конкретного пакета. Клас, який це лікує:
# документ, що не знає, кому їде. 16.09.2026 у пакетах Mac-клієнтів лежала
# віндова інструкція з `run.bat` і `diagnose.bat`, яких у них немає взагалі.
INSTALL_PLATFORMS = ("win", "mac")
INSTALL_SOURCES = {
    "uk": SOURCE,
    "ru": PLATFORM / "Документація" / "МАНУАЛ_SensFlow_RU.md",
}
INSTALL_NAMES = {
    "uk": "02_SensFlow_Інструкція_встановлення.docx",
    "ru": "02_SensFlow_Инструкция_по_установке.docx",
}


def install_text(platform: str = "win", lang: str = "uk") -> str:
    """Текст інструкції: розділ 1 джерела, доріжка машини плюс «клієнту»."""
    if platform not in INSTALL_PLATFORMS:
        raise ManualError("невідома машина «%s»" % platform)
    if lang not in INSTALL_SOURCES:
        raise ManualError("невідома мова «%s»" % lang)
    path = INSTALL_SOURCES[lang]
    if not path.exists():
        raise ManualError("немає джерела мовою «%s»: %s" % (lang, path.name))
    whole = apply_tracks(filled(_read(path)), {platform.upper(), "CLIENT"})
    hits = list(SECTION_RE.finditer(whole))
    if not hits:
        raise ManualError("у джерелі «%s» немає розділу «## N.»" % lang)
    end = hits[1].start() if len(hits) > 1 else len(whole)
    body = whole[hits[0].start():end].strip()
    body = SECTION_RE.sub("", body, count=1).strip()
    if len(body) < 1200:
        raise ManualError("доріжка «%s» у джерелі «%s» порожня" % (platform, lang))
    return body


def build_install(platform: str = "win", lang: str = "uk", out_path=None) -> dict:
    """Інструкція встановлення — похідна, а не рукопис."""
    text = install_text(platform, lang)
    out = Path(out_path) if out_path else (PLATFORM / "Документація" / INSTALL_NAMES[lang])
    res = _render_docx(text, out)
    res.update({"platform": platform, "lang": lang})
    return res


# ── ⭐⭐⭐ 622 (21.09.2026). ВИХІД 4: ДЖЕРЕЛО ДОВІДНИКА ДЛЯ КЛІЄНТА ───────────
# 🩸 КЛАС: живий екран читає ДЖЕРЕЛО, а перелік «що їде клієнту» названий
# ПОХІДНИМИ. Екран «Інструкція» (616) читає цей файл при кожному відкритті —
# а в пакеті клієнта його не було ніколи. 21.09.2026 Каспер одразу після
# 1.0.26 побачив на екрані [Errno 2] і шлях до файла, якого в нього немає.
# ⛒ Джерело їде НЕ будь-яке: доріжка «US» (наша кухня) лишається вдома, а
# мітки {{...}} лишаються ЦІЛИМИ — числа підставляє машина КЛІЄНТА, бо саме
# в цьому сенс живого довідника.
CLIENT_SOURCE_NAME = "МАНУАЛ_SensFlow.md"

# ⛒⛒⛒ 622г. МІТКИ, ЯКІ ЗНАЄ ЛИШЕ НАША КУХНЯ.
# 🩸 Довідник рахує числа живцем — і це правильно. Але частина міток читає
# НАШ інструмент складання (`make_client_build.py`), якого в клієнта немає за
# побудовою: `LAUNCHER`, `PYTHON_MIN`, `DOC_PACKAGES` беруть текст лаунчера
# саме звідти. Один мовчазний файл нашої кухні клав увесь екран клієнта.
# ⛒ ПЕРЕЛІКОМ ЦЕ НЕ ЛІКУЄТЬСЯ: я вже написав список із двох міток, і e2e на
# копії пакета клієнта показав третю. Тому судимо ФАКТ, а не пам'ять:
# підглядаємо, ЩО САМЕ читає писар мітки, і питаємо суддю поставки, чи їде
# той файл клієнту. Завтрашня мітка з такою залежністю впізнається сама.
def our_side_marks(text: str = None) -> list:
    """Мітки, чиє значення ЧИТАЄТЬСЯ З ФАЙЛА, — їх підставляємо при поставці.

    ⛒ Правило одне і просте: якщо писар мітки лізе у ФАЙЛ, її значення — це
    факт про ПОСТАВКУ (як зветься лаунчер, яке завдання служби, який батник
    експорту), а не про живий стан машини клієнта. Такі файли в пакеті клієнта
    можуть просто не існувати: `make_client_build.py` не їде нікому,
    `service_common.ps1` є лише там, де ставили службу. Живі числа — порт,
    кількість систем, шляхи, строки — рахуються з налаштувань і реєстру, без
    жодного файла, і лишаються живими.

    🩸 Переліком це не лікувалось: перший список мав дві мітки, e2e на копії
    пакета клієнта показав третю, потім пʼяту. Тому судимо ФАКТ читання.
    """
    global _read
    want = marks_in_source(text) if text is not None else list(MARKS)
    orig = _read
    seen = []

    def _spy(path):
        seen.append(Path(path))
        return orig(path)

    ours = []
    try:
        for name in want:
            fn = MARKS.get(name)
            if fn is None:
                continue
            seen.clear()
            _read = _spy
            try:
                fn()
            except Exception:
                ours.append(name)              # не рахується навіть у нас
                continue
            finally:
                _read = orig
            if seen:
                ours.append(name)
    finally:
        _read = orig
    return sorted(set(ours))


def client_source_bytes(platform: str = "win", lang: str = "uk") -> bytes:
    """Джерело довідника рівно таким, яким воно має лежати в клієнта."""
    if platform not in INSTALL_PLATFORMS:
        raise ManualError("невідома машина «%s»" % platform)
    if lang not in INSTALL_SOURCES:
        raise ManualError("невідома мова «%s»" % lang)
    path = INSTALL_SOURCES[lang]
    if not path.exists():
        raise ManualError("немає джерела мовою «%s»: %s" % (lang, path.name))
    text = apply_tracks(_read(path), {platform.upper(), "CLIENT"})
    # ⛒ 622г: мітки нашої кухні підставляємо тут; живі — лишаємо клієнтові.
    ours = our_side_marks(text)
    if ours:
        vals = values(only=ours)
        text = MARK_RE.sub(lambda m: vals.get(m.group(1), m.group(0)), text)
    if len(text) < 1200:
        raise ManualError("джерело для клієнта вийшло порожнім (%d знаків)" % len(text))
    return text.encode("utf-8")


def main() -> int:
    args = sys.argv[1:]
    print("=" * 64)
    print("МАНУАЛ ПЛАТФОРМИ — збирач (джерело: %s)" % SOURCE.name)
    print("=" * 64)
    try:
        if not SOURCE.exists():
            raise ManualError("джерела немає на диску: %s" % SOURCE)
        vals = values()
        for k in sorted(vals):
            print("  %-20s = %s" % (k, vals[k]))
        bad = unknown_marks()
        if bad:
            raise ManualError("мітки без писаря: %s" % ", ".join(bad))
        secs = sections()
        print("-" * 64)
        print("розділів у джерелі: %d" % len(secs))
        for num, title, _ in secs:
            print("  %s. %s" % (num, title))
        if "--kb" in args or "--all" in args:
            r = build_kb()
            print("база знань консультанта: %d розділів -> %s" % (r["sections"], r["dir"]))
            if r["written"]:
                print("  перезаписано: %s" % ", ".join(r["written"]))
            if r["dropped"]:
                print("  прибрано зниклі: %s" % ", ".join(r["dropped"]))
        if "--docx" in args or "--all" in args:
            r = build_docx()
            print("документ для людей: %s" % r["path"])
        if "--install" in args or "--all" in args:
            # ⛒ У теку «Документація» кладемо ЗРАЗОК для себе — віндовий, під
            # канонічним імʼям. Справжня інструкція клієнта народжується в
            # мить збірки пакета, під його машину: класти сюди ще й маківську
            # під тим самим імʼям означало б, що останній прогін вирішує, який
            # документ ми бачимо. Тека з документами — не місце для лотереї.
            out_dir = Path(args[args.index("--out") + 1]) if "--out" in args else None
            plats = INSTALL_PLATFORMS if out_dir else ("win",)
            for lang in sorted(INSTALL_SOURCES):
                if not INSTALL_SOURCES[lang].exists():
                    print("інструкція «%s»: джерела немає — пропущено" % lang)
                    continue
                for plat in plats:
                    out = (out_dir / ("%s_%s_%s" % (lang, plat, INSTALL_NAMES[lang]))
                           if out_dir else None)
                    r = build_install(plat, lang, out)
                    print("інструкція %s/%s: %s" % (lang, plat, r["path"]))
    except ManualError as ex:
        print("ВІДМОВА: %s" % ex)
        return 1
    print("=" * 64)
    print("ГОТОВО.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
