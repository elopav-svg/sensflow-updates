# -*- coding: utf-8 -*-
"""xlsx_calc.py — БУХГАЛТЕР, ЯКИЙ РАХУЄ КНИГУ (17.09.2026, зміна 606).

⭐⭐⭐ КОРІНЬ, ЗНЯТИЙ ІЗ ЖИВОГО ПРОГОНУ 17.09.2026, 15:35. Крок «🧾 Бухгалтер:
незалежний перерахунок ключових чисел» пройшов ЗЕЛЕНО, а книга, яку він
пропустив, показувала фіндиректору:

    Зведення!I4 = 'Параметри'!$B$4 -> 9   формат 0.00%  ->  900,00 %
    Зведення!J4 = E4-I4                  формат п.п.   ->   -8,9 п.п.
    Зведення!B4 = 12 498 300             а в тексті     ->  12 474 300

⛒ ЧОМУ. Прогін народжує ДВА артефакти: фінальний ТЕКСТ (його пише модель) і
.xlsx (його будує код зі спеки). Контролер бачить лише перший. Ніхто не
порівнює їх між собою і ніхто не рахує сам файл. Тому неправда, що зʼявилась
НА ЕТАПІ ЗБИРАННЯ КНИГИ, для контролера невидима за визначенням — а слово
«перераховано: ок» стосується не того артефакта, який поїде клієнту.

⭐ ПРАВИЛО КЛАСУ. У бухгалтера зʼявляється ТРЕТЄ джерело — сам файл:
  1. книгу РАХУЄ код — вузьким набором форм, які платформа сама й породжує;
  2. звіряється те, що людина ПОБАЧИТЬ у клітинці (значення разом із форматом),
     із тим, що вона ПРОЧИТАЛА в тексті; розрив — це адреса клітинки і два
     числа, а не загальні слова;
  3. підсумок книги звіряється зі СВОЇМИ ЧАСТИНАМИ;
  4. чого перевірити не вдалося — називається вголос і НЕ зветься «ок».

⛒ СВІДОМА МЕЖА. Обчислювач НЕ стає «своїм Excel». Він знає рівно те, що
породжує платформа: число, посилання (у тому числі на інший лист), + - * /,
дужки, SUM(діапазон), SUMPRODUCT(діапазон;діапазон). Усе інше він чесно зве
«не рахую» — бо щойно він почне ВГАДУВАТИ, у книги стане дві правди, а ми вже
платили за двох писарів однієї правди.

🩸 ДРУГИЙ БІК (хибна тривога — така сама вада, як пропущена): число, для якого
в книзі немає пари, — це ПОКРИТТЯ, а не помилка; колонку у відсотках підсумком
не судять; порожня клітинка в сумі — нуль, а текст у діапазоні SUM ігнорується
так само, як його ігнорує Excel.
"""
import re

# ── Одиниця клітинки з її ФОРМАТУ ────────────────────────────────────────────
_QUOTED_RE = re.compile(r'"[^"]*"')
_PP_FMT_RE = re.compile(r"п\.\s?п\.?", re.I)


def unit_of_format(fmt) -> str:
    """Одиниця, яку додає ФОРМАТ клітинки: "%" | "п.п." | ""."""
    s = str(fmt or "")
    quoted = " ".join(_QUOTED_RE.findall(s))
    bare = _QUOTED_RE.sub(" ", s)
    if _PP_FMT_RE.search(quoted) or _PP_FMT_RE.search(bare):
        return "п.п."
    if "%" in bare:
        return "%"
    return ""


def col_letters(idx: int) -> str:
    s = ""
    while idx > 0:
        idx, r = divmod(idx - 1, 26)
        s = chr(65 + r) + s
    return s


def _col_idx(letters: str) -> int:
    idx = 0
    for ch in str(letters).upper():
        idx = idx * 26 + (ord(ch) - 64)
    return idx


# ── ОБЧИСЛЮВАЧ: розбір вузького набору форм ─────────────────────────────────
class _Un(Exception):
    """Форма поза набором або клітинка, яку не порахувати. Не помилка — межа."""

    def __init__(self, why):
        Exception.__init__(self, why)
        self.why = why


_TOK_RE = re.compile(
    r"(?P<sp>\s+)"
    r"|(?:(?:'(?P<sq>[^']{1,60})'|(?P<sn>[^\s'!()+\-*/=:,;<>&%^]{1,40}))!)?"
    r"\$?(?P<c1>[A-Za-z]{1,3})\$?(?P<r1>\d{1,7})"
    r"(?::\$?(?P<c2>[A-Za-z]{1,3})\$?(?P<r2>\d{1,7}))?(?![\w(])"
    r"|(?P<num>\d+(?:\.\d+)?)"
    r"|(?P<fn>[A-Za-zА-Яа-яІЇЄҐіїєґ_]+)\s*(?=\()"
    r"|(?P<op>[-+*/(),;])", re.U)

_FUNCS = ("SUM", "SUMPRODUCT")


def _tokens(expr: str, this_sheet: str) -> list:
    out, pos, n = [], 0, len(expr)
    while pos < n:
        m = _TOK_RE.match(expr, pos)
        if not m or m.end() == pos:
            raise _Un("не розбираю «%s»" % expr[pos:pos + 12])
        pos = m.end()
        if m.group("sp"):
            continue
        if m.group("num"):
            out.append(("num", float(m.group("num"))))
        elif m.group("c1"):
            sheet = (m.group("sq") or m.group("sn") or this_sheet).strip()
            r1, c1 = int(m.group("r1")), _col_idx(m.group("c1"))
            if m.group("c2"):
                r2, c2 = int(m.group("r2")), _col_idx(m.group("c2"))
                out.append(("rng", (sheet, min(r1, r2), min(c1, c2),
                                    max(r1, r2), max(c1, c2))))
            else:
                out.append(("ref", (sheet, r1, c1)))
        elif m.group("fn"):
            name = m.group("fn").upper()
            if name not in _FUNCS:
                raise _Un("форму %s не рахую" % name)
            out.append(("fn", name))
        else:
            out.append(("op", m.group("op")))
    return out


class _P:
    """Розбір ліворуч направо: вираз -> доданок -> множник -> первинне."""

    def __init__(self, toks, get, rng):
        self.t, self.i, self.get, self.rng = toks, 0, get, rng

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else (None, None)

    def take(self):
        tok = self.peek()
        self.i += 1
        return tok

    def expr(self):
        v = self.term()
        while True:
            k, x = self.peek()
            if k == "op" and x in "+-":
                self.take()
                v = v + self.term() if x == "+" else v - self.term()
            else:
                return v

    def term(self):
        v = self.factor()
        while True:
            k, x = self.peek()
            if k == "op" and x in "*/":
                self.take()
                w = self.factor()
                if x == "*":
                    v = v * w
                else:
                    if abs(w) < 1e-15:
                        raise _Un("ділення на нуль")
                    v = v / w
            else:
                return v

    def factor(self):
        k, x = self.peek()
        if k == "op" and x in "+-":
            self.take()
            v = self.factor()
            return -v if x == "-" else v
        return self.primary()

    def primary(self):
        k, x = self.take()
        if k == "num":
            return x
        if k == "ref":
            return self.get(*x)
        if k == "rng":
            raise _Un("діапазон поза функцією")
        if k == "fn":
            k2, x2 = self.take()
            if k2 != "op" or x2 != "(":
                raise _Un("після %s немає дужки" % x)
            args = []
            while True:
                k3, x3 = self.peek()
                if k3 == "rng":
                    self.take()
                    args.append(self.rng(*x3))
                else:
                    args.append(self.expr())
                k4, x4 = self.take()
                if k4 == "op" and x4 in ",;":
                    continue
                if k4 == "op" and x4 == ")":
                    break
                raise _Un("зіпсована дужка в %s" % x)
            return _apply(x, args)
        if k == "op" and x == "(":
            v = self.expr()
            k2, x2 = self.take()
            if k2 != "op" or x2 != ")":
                raise _Un("дужка не закрита")
            return v
        raise _Un("не розбираю вираз")


def _apply(name, args):
    if name == "SUM":
        total = 0.0
        for a in args:
            total += sum(a) if isinstance(a, list) else a
        return total
    if name == "SUMPRODUCT":
        cols = [a if isinstance(a, list) else [a] for a in args]
        if not cols:
            return 0.0
        if len({len(c) for c in cols}) != 1:
            raise _Un("SUMPRODUCT: діапазони різної довжини")
        total = 0.0
        for row in zip(*cols):
            p = 1.0
            for v in row:
                p *= v
            total += p
        return total
    raise _Un("форму %s не рахую" % name)


def evaluate(wb):
    """Порахувати книгу з її ВЛАСНИХ констант.

    Повертає (values, unchecked):
      values    — {(лист, рядок, колонка): число} для КОЖНОЇ клітинки, яку
                  вдалося звести до числа (і сталої, і формули);
      unchecked — рядки «адреса: «формула» — причина» для того, чого не рахуємо.
                  Це ПОКРИТТЯ, а не перелік помилок."""
    sheets = {ws.title: ws for ws in wb.worksheets}
    vals, bad = {}, {}
    busy = set()

    def get(sheet, row, col):
        key = (sheet, row, col)
        if key in vals:
            return vals[key]
        if key in bad:
            raise _Un(bad[key])
        ws = sheets.get(sheet)
        if ws is None:
            raise _Un("листа «%s» немає" % sheet)
        raw = ws.cell(row=row, column=col).value
        if raw is None or raw == "":
            return 0.0                       # порожня клітинка — нуль, як в Excel
        if isinstance(raw, bool):
            raise _Un("логічне значення")
        if isinstance(raw, (int, float)):
            vals[key] = float(raw)
            return vals[key]
        s = str(raw).strip()
        if not s.startswith("="):
            raise _Un("у клітинці текст «%s»" % s[:18])
        if key in busy:
            raise _Un("циклічне посилання")
        busy.add(key)
        try:
            v = _P(_tokens(s[1:], sheet), get, rng).expr()
        except _Un as e:
            bad[key] = e.why
            raise
        except RecursionError:
            bad[key] = "надто довгий ланцюг посилань"
            raise _Un(bad[key])
        except Exception as e:                                # noqa: BLE001
            bad[key] = "не рахую (%s)" % e
            raise _Un(bad[key])
        finally:
            busy.discard(key)
        vals[key] = float(v)
        return vals[key]

    def rng(sheet, r1, c1, r2, c2):
        ws = sheets.get(sheet)
        if ws is None:
            raise _Un("листа «%s» немає" % sheet)
        out = []
        for r in range(r1, r2 + 1):
            for c in range(c1, c2 + 1):
                raw = ws.cell(row=r, column=c).value
                if raw is None or raw == "":
                    out.append(0.0)
                    continue
                if isinstance(raw, str) and not raw.strip().startswith("="):
                    continue            # текст у діапазоні Excel теж ігнорує
                out.append(get(sheet, r, c))
        return out

    unchecked = []
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if v is None or v == "" or isinstance(v, bool):
                    continue
                if isinstance(v, (int, float)):
                    vals[(ws.title, cell.row, cell.column)] = float(v)
                    continue
                if not str(v).strip().startswith("="):
                    continue
                try:
                    get(ws.title, cell.row, cell.column)
                except _Un as e:
                    unchecked.append("%s!%s: «%s» — %s"
                                     % (ws.title, cell.coordinate, str(v)[:60], e.why))
                except Exception as e:                        # noqa: BLE001
                    unchecked.append("%s!%s: «%s» — не рахую (%s)"
                                     % (ws.title, cell.coordinate, str(v)[:60], e))
    return vals, unchecked


def human(wb, values, sheet, row, col):
    """Що людина ПОБАЧИТЬ у клітинці: (число, одиниця) або None.

    Саме тут живе вада 15:35: значення 9 із форматом 0.00% людина бачить як
    900 %, і доки бухгалтер дивився в текст, цього не бачив ніхто."""
    v = values.get((sheet, row, col))
    if v is None:
        return None
    try:
        fmt = wb[sheet].cell(row=row, column=col).number_format
    except Exception:                                          # noqa: BLE001
        fmt = ""
    u = unit_of_format(fmt)
    if u == "%":
        return (round(v * 100.0, 10), "%")
    if u == "п.п.":
        return (round(v, 10), "п.п.")
    return (round(v, 10), "")


# ── ПІДСУМОК ПРОТИ СВОЇХ ЧАСТИН ─────────────────────────────────────────────
_SUM_OWN_RE = "SUM(%s%d:%s%d)"


def _label_unit(ws, reg, col):
    """Одиниця колонки за підписом шапки (щоб не додавати відсотки)."""
    hdr = (reg or {}).get("hdr")
    if not hdr:
        return ""
    try:
        import xlsx_units
        return {"pct": "%", "pp": "п.п."}.get(
            xlsx_units.unit_of_label(ws.cell(row=hdr, column=col).value), "")
    except Exception:                                          # noqa: BLE001
        return ""


def total_errors(wb, regions=None, values=None) -> list:
    """ВОРОТА: підсумок книги мусить дорівнювати сумі СВОЇХ ЧАСТИН.

    Судимо лише там, де рядок САМ заявив себе сумуючим (хоч одна клітинка в
    ньому — SUM по своїй колонці від першого до останнього рядка даних), і
    лише ті клітинки, що стоять КОНСТАНТОЮ: формула-сума тавтологічно дорівнює
    сама собі, а константа на місці підсумку — це вже чиєсь слово, а не
    арифметика. Колонки у відсотках і пунктах не судимо: частки не додаються."""
    if values is None:
        values, _ = evaluate(wb)
    errs = []
    for ws in wb.worksheets:
        reg = (regions or {}).get(ws.title) or {}
        tot, first, last = reg.get("totals"), reg.get("first"), reg.get("last")
        if not (tot and first and last and last >= first):
            continue
        ncols = int(reg.get("ncols") or 0) or ws.max_column
        summing = False
        for c in range(1, ncols + 1):
            f = ws.cell(row=tot, column=c).value
            if isinstance(f, str) and f.startswith("="):
                if (_SUM_OWN_RE % (col_letters(c), first, col_letters(c), last)
                        ).replace(" ", "") in f.replace(" ", "").upper():
                    summing = True
                    break
        if not summing:
            continue
        for c in range(2, ncols + 1):
            cell = ws.cell(row=tot, column=c)
            v = cell.value
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                continue                      # лише КОНСТАНТА на місці підсумку
            if unit_of_format(cell.number_format) or _label_unit(ws, reg, c):
                continue                      # відсотки й пункти не додаються
            parts, ok = [], True
            for r in range(first, last + 1):
                pv = values.get((ws.title, r, c))
                if pv is None:
                    ok = False
                    break
                parts.append(pv)
            if not ok or not parts:
                continue
            s = sum(parts)
            if abs(float(v) - s) > max(0.5, abs(s) * 1e-9):
                errs.append("%s!%s%d: підсумок %s не дорівнює сумі своїх частин %s "
                            "(рядки %d–%d)"
                            % (ws.title, col_letters(c), tot, _fmt(float(v)),
                               _fmt(s), first, last))
    return errs[:6]


# ── ФАЙЛ ПРОТИ ТЕКСТУ ───────────────────────────────────────────────────────
_NUM_RE = re.compile(r"[-+−–]?\d[\d\s  .,]*\d|[-+−–]?\d")
_PP_TXT_RE = re.compile(r"^\s*п\.\s?п\.?", re.I)


def _fmt(v, unit=""):
    s = ("%.2f" % v) if abs(v - round(v)) > 1e-9 or abs(v) < 1000 else ("%.2f" % v)
    whole, _, frac = s.partition(".")
    neg = whole.startswith("-")
    whole = whole.lstrip("-")
    groups = []
    while len(whole) > 3:
        groups.insert(0, whole[-3:])
        whole = whole[:-3]
    groups.insert(0, whole)
    out = ("-" if neg else "") + " ".join(groups) + "," + frac
    return out + ((" " + unit) if unit else "")


def _candidates(raw: str):
    """Число тексту -> [(значення, допуск)]. Читань може бути два («12,000» —
    це і 12, і 12 000), і тоді збіг ХОЧ ІЗ ОДНИМ вважається збігом: сумнів
    тлумачимо на користь тексту, бо хибна тривога — така сама вада."""
    s = re.sub(r"[\s  ]", "",
               raw.replace("−", "-").replace("–", "-"))
    neg = s.startswith("-")
    s = s.lstrip("+-")
    if not s or not s[0].isdigit():
        return []
    out = []

    def add(txt, decimals):
        try:
            v = float(txt)
        except Exception:                                      # noqa: BLE001
            return
        out.append(((-v if neg else v), 0.5 * (10.0 ** (-decimals)) + 1e-9))

    has_d, has_c = "." in s, "," in s
    if has_d and has_c:
        dec = "." if s.rfind(".") > s.rfind(",") else ","
        th = "," if dec == "." else "."
        body = s.replace(th, "")
        add(body.replace(dec, "."), len(body.split(dec)[-1]))
    elif has_d or has_c:
        sep = "." if has_d else ","
        parts = s.split(sep)
        if len(parts) == 2:
            add(s.replace(sep, "."), len(parts[-1]))
        if len(parts) >= 2 and all(len(p) == 3 for p in parts[1:]) and 1 <= len(parts[0]) <= 3:
            add(s.replace(sep, ""), 0)
    else:
        add(s, 0)
    res = []
    for v, t in out:
        if all(abs(v - x) > 1e-12 for x, _ in res):
            res.append((v, t))
    return res


def _numbers_in(text: str):
    """[(читання, одиниця)] для кожного числа клітинки тексту."""
    out = []
    for m in _NUM_RE.finditer(str(text or "")):
        tail = str(text)[m.end():m.end() + 6]
        unit = ""
        if tail.lstrip().startswith("%"):
            unit = "%"
        elif _PP_TXT_RE.match(tail):
            unit = "п.п."
        cand = _candidates(m.group(0))
        if cand:
            out.append((cand, unit, m.group(0).strip()))
    return out


_WORD_RE = re.compile(r"[а-яіїєґёa-z0-9%]+", re.U)


def _stems(s):
    t = str(s or "").lower().replace("ʼ", "'").replace("’", "'")
    t = re.sub(r"п\.\s?п\.?", " пп ", t)
    t = re.sub(r"[*_`#]+", "", t)
    out = []
    for w in _WORD_RE.findall(t):
        if w == "%" or len(w) >= 2:
            out.append(w[:5])
    return out


def _sim(a, b) -> float:
    """Схожість підписів: спільні основи / усі основи. Основи вважаємо
    спільними, коли одна є початком іншої («відхи» ~ «відхилення»)."""
    A, B = list(dict.fromkeys(a)), list(dict.fromkeys(b))
    if not A or not B:
        return 0.0
    used, common = set(), 0
    for x in A:
        for j, y in enumerate(B):
            if j in used:
                continue
            if x == y or x.startswith(y) or y.startswith(x):
                common += 1
                used.add(j)
                break
    union = len(A) + len(B) - common
    return (common / union) if union else 0.0


def _best(name, options, floor=0.5):
    """Єдиний найкращий збіг або None. Нічия -> None: сумнівну пару не судимо."""
    scored = sorted(((_sim(_stems(name), _stems(lbl)), key)
                     for key, lbl in options), key=lambda x: -x[0])
    if not scored or scored[0][0] < floor:
        return None
    if len(scored) > 1 and abs(scored[0][0] - scored[1][0]) < 1e-9:
        return None
    return scored[0][1]


def _md_tables(md: str):
    """Таблиці markdown із ПОЗИЦІЯМИ: [(шапка[], [(номер_рядка, сирі_клітинки[])])].

    ⛒ Сирі клітинки (без обрізання пробілів) потрібні, щоб ремонт числа міг
    зшити рядок назад БАЙТ У БАЙТ, змінивши рівно одне число. Писар, який
    перебирає рядок наново, псує те, чого не чіпав."""
    lines = str(md or "").splitlines()
    tables, cur = [], []
    for k, line in enumerate(lines):
        s = line.strip()
        if s.startswith("|") and s.endswith("|") and len(s) > 2:
            cur.append((k, s[1:-1].split("|")))
            continue
        if cur:
            tables.append(cur)
            cur = []
    if cur:
        tables.append(cur)
    out = []
    for tb in tables:
        if len(tb) < 2:
            continue
        head = [c.strip() for c in tb[0][1]]
        body = [(k, cells) for k, cells in tb[1:]
                if not all(set(c.strip()) <= set("-:") for c in cells if c.strip())]
        if body:
            out.append((head, body))
    return out


def _sheet_geometry(wb, regions=None):
    """{лист: {hdr, rows:[(рядок, підпис)], cols:[(колонка, підпис)]}}.

    Геометрію беремо з `regions`, коли вона є (той самий прохід 1, що й у
    рендера), і лише інакше знаходимо шапку самі — щоб у книзі, прочитаній з
    диска, теж було кого питати."""
    geo = {}
    for ws in wb.worksheets:
        reg = (regions or {}).get(ws.title) or {}
        hdr, first, last = reg.get("hdr"), reg.get("first"), reg.get("last")
        if not hdr:
            for r in range(1, min(ws.max_row, 30) + 1):
                a, b = ws.cell(r, 1).value, ws.cell(r, 2).value
                if not (isinstance(a, str) and a.strip()
                        and isinstance(b, str) and b.strip()):
                    continue
                nxt = [ws.cell(r + 1, c).value for c in range(2, ws.max_column + 1)]
                if any(isinstance(v, (int, float)) and not isinstance(v, bool)
                       or (isinstance(v, str) and v.startswith("=")) for v in nxt):
                    hdr = r
                    break
            if not hdr:
                continue
            first = hdr + 1
            last = ws.max_row
        rows = []
        end = (reg.get("totals") or last or hdr)
        for r in range(first or hdr + 1, (end or hdr) + 1):
            lbl = ws.cell(r, 1).value
            if isinstance(lbl, str) and lbl.strip():
                rows.append((r, lbl.strip()))
        cols = []
        ncols = int(reg.get("ncols") or 0) or ws.max_column
        for c in range(2, ncols + 1):
            h = ws.cell(hdr, c).value
            if isinstance(h, str) and h.strip():
                cols.append((c, h.strip()))
        if rows and cols:
            geo[ws.title] = {"hdr": hdr, "rows": rows, "cols": cols}
    return geo


def _walk(wb, md, regions=None, values=None):
    """ОДИН ПРОХІД ПО ПАРІ «ТЕКСТ — КНИГА». Повертає перелік записів:

        {kind: "ok"|"break"|"skip", sheet, row, col, line, cell, token, bval,
         bunit, head, label, msg}

    ⛒ Судити і лікувати мусить ОДИН прохід. Якби їх було два, вони розійшлись
    би рівно так, як розійшлись текст і книга, — тобто ми б відтворили ту саму
    ваду всередині її ж ліку."""
    if values is None:
        values, _ = evaluate(wb)
    geo = _sheet_geometry(wb, regions)
    recs = []
    if not geo:
        return [{"kind": "skip", "msg": "у книзі не знайдено таблиці з шапкою"}]
    for head, body in _md_tables(md):
        # ⛒ ТАБЛИЦЯ НАЛЕЖИТЬ ОДНОМУ АРКУШЕВІ, і обираємо його ОДИН раз — за
        # тим, скільки підписів шапки й назв рядків аркуш упізнає. Доти тут
        # стояв ПЕРШИЙ-ЛІПШИЙ аркуш зі схожою назвою рядка — і рядок
        # «Виробництво» зведення зшивався з рядком «Разом виробництво»
        # цехового аркуша. Це давало ВГАДАНУ тривогу на ЧИСТІЙ книзі — вада
        # рівно такого ж класу, як пропущена.
        rows_lbl = [(cells[0] if cells else "").strip() for _k, cells in body]
        rows_lbl = [re.sub(r"[*_`]+", "", x).strip() for x in rows_lbl]
        scores = []
        for sheet, g in geo.items():
            hcols = sum(1 for j in range(1, len(head))
                        if _best(head[j], [(c, l) for c, l in g["cols"]]))
            hrows = sum(1 for lbl in rows_lbl
                        if lbl and _best(lbl, [(r, l) for r, l in g["rows"]]))
            scores.append((hcols + hrows, sheet))
        scores.sort(key=lambda x: -x[0])
        if not scores or scores[0][0] < 2:
            recs.append({"kind": "skip", "msg": "таблиця «%s…» — відповідного "
                         "аркуша в книзі немає" % str(head[0] if head else "")[:28]})
            continue
        if len(scores) > 1 and scores[0][0] == scores[1][0]:
            recs.append({"kind": "skip", "msg": "таблиця «%s…» — два аркуші схожі "
                         "однаково, не суджу" % str(head[0] if head else "")[:28]})
            continue
        sheet = scores[0][1]
        g = geo[sheet]
        for line_no, cells in body:
            if len(cells) < 2:
                continue
            label = re.sub(r"[*_`]+", "", cells[0]).strip()
            if not label:
                continue
            r = _best(label, [(rr, lbl) for rr, lbl in g["rows"]])
            if not r:
                recs.append({"kind": "skip",
                             "msg": "рядок «%s» — у книзі такого рядка немає" % label[:40]})
                continue
            for j in range(1, min(len(cells), len(head))):
                nums = _numbers_in(cells[j])
                if not nums:
                    continue
                col = _best(head[j], [(c, lbl) for c, lbl in g["cols"]])
                if not col:
                    recs.append({"kind": "skip", "msg": "колонка «%s» — пари в книзі "
                                 "немає" % str(head[j])[:40]})
                    continue
                h = human(wb, values, sheet, r, col)
                if h is None:
                    recs.append({"kind": "skip",
                                 "msg": "%s!%s%d — клітинку не пораховано"
                                        % (sheet, col_letters(col), r)})
                    continue
                bval, bunit = h
                same_unit = [n for n in nums if n[1] == bunit]
                hit = any(any(abs(bval - v) <= max(tol, abs(v) * 1e-9) for v, tol in cand)
                          for cand, unit, _s in same_unit)
                base = {"sheet": sheet, "row": r, "col": col, "line": line_no,
                        "cell": j, "bval": bval, "bunit": bunit,
                        "head": dict(g["cols"]).get(col, ""), "label": label}
                if hit:
                    recs.append(dict(base, kind="ok"))
                elif not same_unit:
                    recs.append({"kind": "skip", "msg": "%s!%s%d — одиниця тексту й "
                                 "книги різні" % (sheet, col_letters(col), r)})
                else:
                    recs.append(dict(base, kind="break", token=same_unit[0][2]))
    return recs


def _break_text(rec) -> str:
    return ("%s!%s%d («%s», %s): у книзі %s, у тексті %s — одне з двох неправда"
            % (rec["sheet"], col_letters(rec["col"]), rec["row"],
               str(rec["head"])[:28], str(rec["label"])[:24],
               _fmt(rec["bval"], rec["bunit"]),
               rec["token"] + ((" " + rec["bunit"]) if rec["bunit"] else "")))


def text_vs_book(wb, md: str, regions=None, values=None) -> dict:
    """Звірити ЧИСЛА ТЕКСТУ з тим, що людина побачить у КНИЗІ.
    {"errors": [...], "checked": n, "unchecked": [...]}"""
    recs = _walk(wb, md, regions, values)
    return {"errors": [_break_text(r) for r in recs if r["kind"] == "break"][:6],
            "checked": sum(1 for r in recs if r["kind"] == "ok"),
            "unchecked": [r["msg"] for r in recs if r["kind"] == "skip"][:8]}


# ── РЕМОНТ: ЧИСЛО В ТЕКСТІ СТАВИТЬ КОД ІЗ КНИГИ ─────────────────────────────
# ⭐⭐⭐ 607. Це той самий клас, що й 600 («дані переносить КОД, а не модель»),
# лише на останньому кроці. Модель пише РОЗПОВІДЬ; числа в ній — не її справа.
# Доки платформа лише ПОЗНАЧАЛА розрив, людина отримувала документ, про який
# сама платформа каже «одне з двох тут неправда» — тобто роботу доводилось
# доробляти їй. Тепер розповідь зводиться до книги, а виправлене називається
# поіменно.
#
# ⛒ ЧОМУ КНИГА ГОЛОВНІША ЗА ТЕКСТ. Книга народжується детерміновано: числа в
# неї переносить код із таблиць клієнта (600), першоджерело судить 599, адреси
# — 598, одиниці — 604, підсумок проти частин — 606. Текст пише мовна модель
# з голови. Тому при розбіжності правий той, кого перевіряють шестеро воріт.
#
# 🩸 ДРУГИЙ БІК. Чесний текст не чіпаємо взагалі — жодного байта. Клітинку, якої
# не порахували чи не зшили однозначно, не чіпаємо. Ремонт НЕ мовчить: кожне
# виправлення названо адресою клітинки і двома числами.
def _num_style(token: str):
    """Стиль числа, яким його написала модель: (роздільник тисяч, десятковий,
    знаків після коми, знак «+» попереду, який саме мінус)."""
    s = str(token or "")
    plus = s.strip().startswith("+")
    minus = "−" if "−" in s else ("–" if "–" in s else "-")
    body = re.sub(r"^[\s+\-−–]+", "", s)
    space_th = bool(re.search(r"\d[\s  ]\d", body))
    has_d, has_c = "." in body, "," in body
    dec, th, dg = "", (" " if space_th else ""), 0
    if has_d and has_c:
        dec = "." if body.rfind(".") > body.rfind(",") else ","
        th = "," if dec == "." else "."
    elif has_d or has_c:
        sep = "." if has_d else ","
        parts = body.split(sep)
        if len(parts) == 2 and len(parts[-1]) != 3:
            dec = sep
        elif len(parts) >= 2 and all(len(x) == 3 for x in parts[1:]):
            th = sep
        else:
            dec = sep
    if dec:
        dg = len(body.split(dec)[-1])
    return {"th": th, "dec": dec, "dg": dg, "plus": plus, "minus": minus}


def _render_like(value: float, token: str) -> str:
    """Записати число книги ТИМ САМИМ стилем, яким модель написала своє."""
    st = _num_style(token)
    neg = value < 0
    body = ("%.*f" % (st["dg"], abs(value)))
    whole, _, frac = body.partition(".")
    if st["th"]:
        groups = []
        while len(whole) > 3:
            groups.insert(0, whole[-3:])
            whole = whole[:-3]
        groups.insert(0, whole)
        whole = st["th"].join(groups)
    out = whole + ((st["dec"] + frac) if st["dg"] else "")
    if neg:
        return st["minus"] + out
    return ("+" + out) if st["plus"] else out


def repair_text(wb, md: str, regions=None, values=None):
    """Звести числа тексту до книги. Повертає (текст, [що виправлено]).

    Виправляємо КЛІТИНКУ таблиці, а тоді те саме хибне число — скрізь у тексті,
    де модель його повторила (резюме, висновки): інакше документ суперечив би
    сам собі, а саме це ми й лікуємо."""
    if values is None:
        values, _ = evaluate(wb)
    recs = _walk(wb, md, regions, values)
    breaks = [r for r in recs if r["kind"] == "break"]
    if not breaks:
        return md, []
    lines = str(md or "").splitlines(True)          # з кінцями рядків
    fixes, seen = [], set()
    for rec in breaks:
        k = rec["line"]
        if k >= len(lines):
            continue
        raw = lines[k]
        nl = raw[len(raw.rstrip("\r\n")):]
        s = raw.rstrip("\r\n").strip()
        if not (s.startswith("|") and s.endswith("|")):
            continue
        cells = s[1:-1].split("|")
        j = rec["cell"]
        if j >= len(cells) or rec["token"] not in cells[j]:
            continue
        new_tok = _render_like(rec["bval"], rec["token"])
        cells[j] = cells[j].replace(rec["token"], new_tok, 1)
        lines[k] = "|" + "|".join(cells) + "|" + nl
        fixes.append({"old": rec["token"], "new": new_tok,
                      "addr": "%s!%s%d" % (rec["sheet"], col_letters(rec["col"]),
                                           rec["row"]),
                      "text": "%s!%s%d («%s», %s): %s → %s (з книги)"
                              % (rec["sheet"], col_letters(rec["col"]), rec["row"],
                                 str(rec["head"])[:28], str(rec["label"])[:24],
                                 rec["token"], new_tok)})
        if rec["token"] not in seen:
            seen.add(rec["token"])
    out = "".join(lines)
    # Те саме хибне число могло переїхати в резюме й висновки — там воно теж
    # хибне. Заміняємо рівно ту саму послідовність знаків, і лише її.
    for rec in breaks:
        tok = rec["token"]
        if tok not in seen:
            continue
        seen.discard(tok)
        new_tok = _render_like(rec["bval"], tok)
        if new_tok == tok:
            continue
        out = out.replace(tok, new_tok)
    return out, fixes
