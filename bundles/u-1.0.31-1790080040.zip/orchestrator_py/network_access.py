# -*- coding: utf-8 -*-
"""
network_access.py — зміна 506, 04.09.2026.
ОДНА ТОЧКА, ЯКА ВИРІШУЄ, КОМУ ВІДПОВІДАЄ ПЛАТФОРМА:
лише цій машині чи всім комп'ютерам офісної мережі.

ЧОМУ ОКРЕМИЙ МОДУЛЬ, А НЕ РЯДОК У server.py.
Адреса — це рішення про БЕЗПЕКУ, а не деталь запуску. На це питання
відповідають ТРОЄ: сервер (де ставати), екран «Доступи» (що показати
людині) і чек (що судити). Три власні відповіді на одне питання — той
самий клас біди, що й спільний .tmp: рано чи пізно хтось із трьох буде
неправий, і неправий тихо. Тому відповідь одна й лежить тут.

ЗАМОК БЕЗПЕКИ — головне в цьому файлі.
Відкрита мережа без пароля означає: платформа з усіма угодами, задачами,
людьми й документами доступна КОЖНОМУ, хто підключився до офісного WiFi,
і одразу з правами адміністратора. Тому:

    МЕРЕЖА ВІДКРИВАЄТЬСЯ ЛИШЕ ТОДІ, КОЛИ ВХІД ІЗ ПАРОЛЕМ УВІМКНЕНИЙ.

Замок стоїть НА ДВОХ ПОВЕРХАХ:
  1) екран не дає ввімкнути відкритий режим, поки немає входу з паролем;
  2) сервер при старті перевіряє САМ і повертається на закриту адресу,
     навіть якщо рядок у .env.local хтось вписав руками.
Один поверх тут не рятує: файл настройок редагується блокнотом.

ЗА ЗАМОВЧУВАННЯМ — ЗАКРИТО. Нічого не змінюється, поки людина свідомо
не ввімкнула. Жоден клієнт, що оновиться, не опиниться раптом у мережі.

Жодних зовнішніх залежностей.
"""

import os
import socket
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import config  # noqa: E402

# Дві адреси, третьої ми не пропонуємо: «слухати конкретну картку» —
# це настройка для інженера, а не для власника компанії.
LOCAL_HOST = "127.0.0.1"   # закрито: відповідає лише цій машині
OPEN_HOST = "0.0.0.0"      # відкрито: відповідає всій локальній мережі

ENV_KEY = "SENSFLOW_HOST"

# Чому мережу заблоковано, мовою людини.
REASON_NO_LOGIN = "no_login"
# 512: другий різновид тієї самої біди — вхід Є, але БЕЗ пароля.
REASON_LIGHT_LOGIN = "light_login"
# ⭐⭐⭐ 537, 08.09.2026: ТРЕТІЙ РІЗНОВИД ТІЄЇ САМОЇ БІДИ — вхід є, пароль є,
# а розмова йде офісним дротом ВІДКРИТИМ ТЕКСТОМ. Рішення Андрія: у периметрі
# офісу конфіденційність обов'язкова, отже це така сама перешкода, як і брак
# пароля.
REASON_NO_HTTPS = "no_https"


def https_ok() -> bool:
    """Чи є придатний сертифікат — питаємо ТОГО, ХТО ЗА ЦЕ ВІДПОВІДАЄ.

    Помилка читання = вважаємо, що шифрування НЕМАЄ. Безпечна відповідь тут
    та, що закриває мережу, а не та, що відкриває, — так само як із паролем.
    """
    try:
        import https_access as _sec
        return bool(_sec.usable())
    except Exception:
        return False


def https_state() -> dict:
    """Повний стан шифрування для екрана. Порожньо — отже модуль недоступний."""
    try:
        import https_access as _sec
        return _sec.state()
    except Exception:
        return {}


def login_on() -> bool:
    """Чи вимагає платформа пароль при вході.

    🩸 512: ПИТАННЯ ПРО ПАРОЛЬ, А НЕ ПРО ВХІД. До 05.09.2026 ця функція питала
    лише `login_required()` — «чи вимагається вхід узагалі». Але вхід буває
    двох різновидів, і другий — БЕЗ пароля: легкий режим, де людина вибирає
    себе зі списку. Виходило, що з увімкненим легким входом і двома записами
    замок вважав платформу захищеною і дозволяв відкрити її всій офісній
    мережі — де будь-хто вибрав би адміністратора і зайшов.

    Помилка читання = вважаємо, що пароля НЕМАЄ. Безпечна відповідь тут
    та, що закриває мережу, а не та, що відкриває.
    """
    try:
        import taskdesk_identity as _tdid
        return bool(_tdid.login_required()) and not bool(_tdid.light_mode())
    except Exception:
        return False


def light_login_on() -> bool:
    """Чи ввімкнений вхід без пароля. Потрібен, щоб екран і вікно запуску
    назвали ПРАВИЛЬНУ причину, а не одну на дві різні біди."""
    try:
        import taskdesk_identity as _tdid
        return bool(_tdid.light_mode())
    except Exception:
        return False


def wanted_open() -> bool:
    """Чого хоче власник — читаємо .env.local ЗАНОВО, а не з пам'яті процесу.
    Настройку могли змінити з екрана вже після запуску."""
    try:
        value = (config.load_env().get(ENV_KEY) or "").strip()
    except Exception:
        value = (config.ENV.get(ENV_KEY) or "").strip()
    return value == OPEN_HOST


def blocked_reason() -> str:
    """Порожньо, якщо перешкод немає. ТРИ різні біди — три різні причини:
    входу немає взагалі; вхід є, але без пароля; пароль є, але немає
    шифрування. 🩸 Одна причина на три біди змусила б людину гадати."""
    if not wanted_open():
        return ""
    if not login_on():
        return REASON_LIGHT_LOGIN if light_login_on() else REASON_NO_LOGIN
    if not https_ok():
        return REASON_NO_HTTPS
    return ""


def effective_host() -> str:
    """Адреса, на яку сервер стає НАСПРАВДІ. Єдине джерело для server.py.

    ⭐⭐⭐ 537: ТРИ УМОВИ, А НЕ ДВІ. Мережа відкривається, лише коли власник
    цього хоче, вхід вимагає пароля І розмова буде зашифрована. Кожна умова
    перевіряється тут ЩЕ РАЗ — бо `.env.local` редагується блокнотом, і
    екранного замка самого по собі мало.
    """
    if wanted_open() and login_on() and https_ok():
        return OPEN_HOST
    return LOCAL_HOST


def lan_ip() -> str:
    """Адреса цієї машини в локальній мережі — та, яку люди наберуть у
    браузері. Нічого нікуди не надсилає: UDP-сокет лише питає систему,
    через яку картку вона пішла б назовні."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        finally:
            s.close()
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass
    try:
        ip = socket.gethostbyname(socket.gethostname())
        if ip and not ip.startswith("127."):
            return ip
    except Exception:
        pass
    return ""


def state() -> dict:
    """Повний стан для екрана, консолі й чека. ОДНА відповідь на всіх."""
    port = int(getattr(config, "PORT", 7799))
    host = effective_host()
    ip = lan_ip()
    sec = https_state()
    # 537: адреса, яку роздають людям, називає СПРАВЖНІЙ спосіб зайти.
    # Поки шифрування немає, мережа й так закрита, тож брехати нема про що.
    scheme = "https" if sec.get("usable") else "http"
    return {
        "wanted_open": wanted_open(),
        "is_open": host == OPEN_HOST,
        "login_on": login_on(),
        "blocked": blocked_reason(),
        "host": host,
        "port": port,
        "lan_ip": ip,
        # З цієї ж машини звичайний вхід лишається робочим завжди: трафік
        # не виходить за межі комп'ютера.
        "url_local": "http://127.0.0.1:%d" % port,
        "url_lan": ("%s://%s:%d" % (scheme, ip, port)) if ip else "",
        "https": sec,
    }


def set_open(on: bool) -> dict:
    """Свідомо відкрити або закрити мережу. Повертає стан.
    Відмова — це теж відповідь: 'refused' каже, чому не вийшло."""
    on = bool(on)
    if on and not login_on():
        out = state()
        out["refused"] = REASON_NO_LOGIN
        return out
    # ⭐⭐⭐ 537: КНОПКА ЛИШАЄТЬСЯ ОДНА. Власник натиснув «Відкрити доступ з
    # мережі» — платформа сама готує шифрування. Він не зобов'язаний знати
    # слово «сертифікат»; він зобов'язаний знати, що всередині офісу безпечно.
    if on and not https_ok():
        made = {}
        try:
            import https_access as _sec
            made = _sec.make()
        except Exception as ex:
            made = {"ok": False, "error": str(ex)}
        if not made.get("ok") or not https_ok():
            out = state()
            out["refused"] = REASON_NO_HTTPS
            out["refused_detail"] = str(made.get("error") or "")
            return out
    config.update_env_local({ENV_KEY: OPEN_HOST if on else LOCAL_HOST})
    out = state()
    out["refused"] = ""
    return out


def console_lines() -> list:
    """Що сказати людині у вікні запуску. Людина не має гадати."""
    st = state()
    lines = []
    if st["is_open"]:
        where = st["url_lan"] or ("порт %d" % st["port"])
        lines.append(" Доступ          : МЕРЕЖА — з інших комп'ютерів: %s" % where)
        lines.append(" Вхід            : з паролем (обов'язковий)")
    else:
        lines.append(" Доступ          : лише ця машина (127.0.0.1)")
        if st["blocked"] == REASON_NO_LOGIN:
            lines.append(" УВАГА: мережу увімкнено в настройках, але вхід із паролем")
            lines.append("        вимкнений. Платформа лишилась закритою навмисне.")
            lines.append("        Заведіть облікові записи на екрані Доступи.")
        elif st["blocked"] == REASON_NO_HTTPS:
            lines.append(" УВАГА: мережу увімкнено, але шифрування не готове.")
            lines.append("        У периметрі офісу платформа працює лише")
            lines.append("        зашифровано. Платформа лишилась закритою")
            lines.append("        навмисне. Відкрийте екран Доступи.")
        elif st["blocked"] == REASON_LIGHT_LOGIN:
            lines.append(" УВАГА: мережу увімкнено, але вхід зараз БЕЗ ПАРОЛЯ")
            lines.append("        (легкий режим). У мережі це означало б, що будь-хто")
            lines.append("        вибере себе зі списку і зайде. Платформа лишилась")
            lines.append("        закритою навмисне. Вимкніть легкий режим.")
    return lines
