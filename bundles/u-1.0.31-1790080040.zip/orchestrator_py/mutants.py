# -*- coding: utf-8 -*-
"""mutants.py — ОДИН ПИСАР ЗАКОНУ МУТАЦІЇ (609, 18.09.2026).

⭐⭐⭐ НАВІЩО. Досі закон мутації кожен набір писав сам, і законів стало
чотири: 26 наборів вимагали ЄДИНОГО якоря, 21 — щоб якір ПРОСТО БУВ (і бив
по першому збігу), решта судила функцією. А єдиний суддя всього цього гинув
з винятком, бо ФОРМАТ оголошення він вгадував за формою кортежу.

⛒ ЗАКОН, ЯКИЙ ТУТ ЖИВЕ (один на всіх):

  1. **ЯКІР МУСИТЬ БУТИ ЄДИНИЙ.** Нуль збігів — правило без охорони.
     Два збіги — гірше: мутація ляже на перший, а охорона вціліє в другому,
     і набір відрапортує «червона» про те, чого не ламав. Доказ, який
     тримається на порядку рядків у файлі, — не доказ.
  2. **ФОРМАТ ОГОЛОШУЮТЬ, А НЕ ВГАДУЮТЬ.** Кожен набір пише `MUTANT_FORMAT`.
     Писар читає оголошене; форми кортежу він не нюхає.
  3. **СУДДЯ НЕ ГИНЕ.** Набір, якого не вдалось прочитати, — це ЧЕРВОНЕ з
     назвою набору, а не виняток, що вбиває перевірку всіх інших.

Повз цього писаря правити код наборам не дозволено — це судиться ДЕРЕВОМ
КОДУ в `mutants_law_test.py` (той самий прийом, що й «одні двері до стану»).

Офлайн, $0. Сам нічого не запускає і не друкує.
"""
import importlib.util
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile

# ⭐ 18.09.2026 (610): «samples» — набір, який показує зуби сторожеві НЕ
# правкою коду, а ТЕКОЮ-ЗРАЗКОМ. Сторож, що судить ФАЙЛИ (напр. промпти
# систем), інакше довести свої зуби не може, а недоведений сторож — це
# рівно той несправний прилад, від якого лікувалась зміна 609.
FORMATS = ("name_edits", "name_probe_edits", "file_first", "src_pairs",
           "callable", "samples")

_FORMAT_RE = re.compile(r'^MUTANT_FORMAT\s*=\s*["\']([a-z_]+)["\']', re.M)
_ROOT_RE = re.compile(r'^MUTANT_ROOT\s*=\s*["\']([^"\']+)["\']', re.M)


class AnchorError(Exception):
    """Якір не єдиний: або його немає, або він трапляється кілька разів."""


# ─────────────────────────────── НАКЛАДАННЯ ────────────────────────────────

def applies_once(text, old):
    """ЗАКОН ЯКОРЯ в одному рядку: якір мусить трапитись рівно один раз.

    Тут він живе один-єдиний раз на всю платформу. Набори питають ЦЕЙ закон,
    а не переписують його в себе (0 збігів — правило без охорони; 2 збіги —
    мутація ляже на перший, а охорона вціліє в другому).
    """
    return text.count(old) == 1


def apply_one(text, old, new):
    """Накласти мутацію. Якір мусить трапитись РІВНО ОДИН раз.

    Повертає новий текст. Інакше — AnchorError, і жодного запису.
    """
    if not applies_once(text, old):
        found = text.count(old)
        head = old.strip().split("\n")[0][:70]
        raise AnchorError(
            "якір не єдиний: збігів %d (треба рівно 1). Якір: %r" % (found, head))
    return text.replace(old, new, 1)


def apply_in(path, old, new, encoding="utf-8"):
    """Те саме, але прямо у файлі: прочитати, накласти за законом, записати."""
    p = pathlib.Path(path)
    try:
        src = p.read_text(encoding=encoding)
    except FileNotFoundError:
        raise AnchorError("файла немає: %s" % p)
    p.write_text(apply_one(src, old, new), encoding=encoding)


# ─────────────────────────────── ЧИТАННЯ НАБОРУ ─────────────────────────────

def sets(where):
    """Усі набори мутацій у теці (без бекапів)."""
    return sorted(p for p in pathlib.Path(where).glob("*_mutants.py")
                  if ".BACKUP" not in p.name and "_BACKUP" not in p.name)


def declared_format(path):
    """Оголошений формат набору. Читається з тексту — без імпорту."""
    src = pathlib.Path(path).read_text(encoding="utf-8", errors="replace")
    m = _FORMAT_RE.search(src)
    return m.group(1) if m else None


def declared_root(path):
    """Тека, від якої набір рахує свої шляхи. Оголошується, а не вгадується.

    Немає оголошення — шляхи рахуються від теки самого набору.
    """
    src = pathlib.Path(path).read_text(encoding="utf-8", errors="replace")
    m = _ROOT_RE.search(src)
    return m.group(1) if m else None


def load(path):
    """Імпортувати набір як модуль (його тека мусить бути на шляху)."""
    p = pathlib.Path(path).resolve()
    here = str(p.parent)
    if here not in sys.path:
        sys.path.insert(0, here)
    spec = importlib.util.spec_from_file_location(p.stem, str(p))
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def parse(path):
    """Канонічний перелік мутацій набору.

    Повертає список `(назва, [(файл, старе, нове), ...])` для текстових
    мутацій і `(назва, [(файл, функція)])` для мутацій-функцій.
    Файл — рядок або Path так, як його назвав набір.
    """
    p = pathlib.Path(path)
    fmt = declared_format(p)
    if fmt is None:
        raise ValueError("набір не оголосив MUTANT_FORMAT")
    if fmt not in FORMATS:
        raise ValueError("невідомий MUTANT_FORMAT: %r" % fmt)

    mod = load(p)
    items = getattr(mod, "MUTANTS", None)
    if items is None:
        raise ValueError("у наборі немає MUTANTS")

    out = []
    for i, it in enumerate(items, 1):
        try:
            if fmt == "name_edits":
                label, edits = it[0], it[1]
                out.append((label, [tuple(e) for e in edits]))
            elif fmt == "name_probe_edits":
                label, _probe, edits = it[0], it[1], it[2]
                out.append((label, [tuple(e) for e in edits]))
            elif fmt == "file_first":
                fname, old, new, label = it
                out.append((label, [(fname, old, new)]))
            elif fmt == "src_pairs":
                old, new, label = it
                src = getattr(mod, "SRC", None)
                if src is None:
                    raise ValueError("формат src_pairs без SRC у модулі")
                out.append((label, [(src, old, new)]))
            elif fmt == "callable":
                fname, fn, label = it
                out.append((label, [(fname, fn)]))
            elif fmt == "samples":
                # Зразок несе СВІЙ текст; якорів у коді немає — судити нічого.
                out.append((it[0], []))
        except Exception as exc:
            raise ValueError("мутація #%d не читається форматом %s: %r"
                             % (i, fmt, exc))
    return out


# ─────────────────────────────── СУД НАД ЯКОРЯМИ ────────────────────────────

class Report(object):
    """Вирок по одному набору. Ніколи не кидає винятків назовні."""

    def __init__(self, name, problems=None, total=0, fmt=None):
        self.name = name
        self.problems = list(problems or [])
        self.total = total
        self.format = fmt

    def __repr__(self):
        return "Report(%r, проблем=%d, якорів=%d)" % (
            self.name, len(self.problems), self.total)


def anchors_report(path, base=None):
    """Судить ОДИН набір: чи кожен якір знаходить своє місце РІВНО раз.

    Ніколи не кидає винятку: усе, що завадило, стає рядком у problems.
    """
    p = pathlib.Path(path)
    rep = Report(p.name)
    try:
        rep.format = declared_format(p)
        muts = parse(p)
    except Exception as exc:
        rep.problems.append("набір не читається: %s" % exc)
        return rep

    root = pathlib.Path(base) if base else p.resolve().parent
    declared = declared_root(p)
    if declared:
        root = (root / declared).resolve()
    cache = {}

    def text_of(fname):
        key = str(fname)
        if key not in cache:
            fp = pathlib.Path(fname)
            if not fp.is_absolute():
                fp = root / fp
            cache[key] = fp.read_text(encoding="utf-8") if fp.exists() else None
        return cache[key]

    for label, edits in muts:
        for edit in edits:
            rep.total += 1
            fname = edit[0]
            src = text_of(fname)
            if src is None:
                rep.problems.append("%s -> файла %s немає" % (str(label)[:52], fname))
                continue
            if len(edit) == 2:                       # мутація-функція
                fn = edit[1]
                try:
                    if fn(src) == src:
                        rep.problems.append(
                            "%s -> %s: функція нічого не змінює"
                            % (str(label)[:52], fname))
                except Exception as exc:
                    rep.problems.append("%s -> %s: функція впала: %r"
                                        % (str(label)[:52], fname, exc))
                continue
            old = edit[1]
            found = src.count(old)
            if found != 1:
                rep.problems.append(
                    "%s -> %s: збігів %d (треба рівно 1)"
                    % (str(label)[:52], fname, found))
    return rep


# ═══════════════════════════════════════════════════════════════════════════
# ⭐⭐⭐ 614. РОБОЧА КОПІЯ: ЄДИНЕ МІСЦЕ, ДЕ ПИСАРЮ ВЗАГАЛІ МОЖНА ПИСАТИ
# ═══════════════════════════════════════════════════════════════════════════
# 🩸 Що було. Пʼятнадцять наборів псували файли НА МІСЦІ — у бойовій теці
# Андрія, — а на час прогону клали поруч дзеркало `файл_MUTBAK_...`. Прибрати
# дзеркало набір не може: через місток до машини власника видаляти заборонено
# завжди. Тому 13.09.2026 у теці `ui` лишився `index.html_MUTBAK_581b` і
# пролежав там тиждень. Гірше за сам слід те, що обрив прогону лишав у коді
# МУТАНТА: інструмент перевірки псував платформу й ішов.
#
# ⛒ КЛАС: ПИСАР, ЯКОМУ НЕ СКАЗАНО, ДЕ ЙОМУ МОЖНА ПИСАТИ, ПИШЕ В БОЙОВУ ТЕКУ.
# Лік не в тому, щоб переписати пʼятнадцять наборів (шістнадцятий напишеться
# наступної зміни), а в тому, щоб закон жив у ПИСАРЯ:
#   * писати можна ЛИШЕ всередині теки, ЯВНО позначеної як робоча копія;
#   * усе інше — відмова з винятком, ДО будь-якого запису (default-deny);
#   * набір, що псує на місці, одним рядком іде в ізоляцію — і псує копію.
# Тоді бойова тека недосяжна за побудовою, а не за уважністю автора набору.
WORK_MARK = ".sf_work_copy"

# ⛒ ЩО НЕ ЇДЕ В РОБОЧУ КОПІЮ. Два правила, і обидва про суть, а не про смаки:
#   * ВИРОБЛЕНЕ І СТАН — теки, які код перезаповнює сам (прогони, нитки,
#     журнали, збірки, оновлення, бекапи). Чек, що спирається на вчорашній
#     прогін, і так не доказ.
#   * ВАГА ФАЙЛА — джерело не важить мегабайтами. Важкий файл у копії означає
#     артефакт, а не код, тож він відсікається ВАГОЮ, а не іменем: перелік імен
#     рота, а вага — ні.
# 🩸 614: першу редакцію цього писаря ловили ВАГОЮ ТЕКИ, і вона викинула всю
# `generated_systems` (305 МБ) разом із методикою на 76 КБ, без якої
# `card_edit_test` у копії червонів 24 рази. Вага судить ФАЙЛ, а не теку.
_WORK_SKIP_DIRS = {"__pycache__", "runs", "threads", "logs", ".git",
                   "_to_delete", "_backups", "node_modules", "Бекапи",
                   "runs_paused", "artifacts", "output", "tender_index",
                   "sensflow-updates", "codex_control_plane",
                   "Пакет для клієнта"}
_WORK_MAX_FILE = 2 * 1024 * 1024


class LiveTreeError(Exception):
    """Писаря попросили змінити файл поза позначеною робочою копією."""


def is_work_copy(path):
    """Чи лежить шлях усередині позначеної робочої копії."""
    p = pathlib.Path(path).resolve()
    for d in (p,) + tuple(p.parents):
        try:
            if (d / WORK_MARK).exists():
                return True
        except OSError:
            return False
    return False


def _skip_dir(name):
    # ⛒ Тека з двокрапкою в імені — це слід «диска D:», а не тека.
    return name in _WORK_SKIP_DIRS or ":" in name


def _copy_tree(src, dst, skip=()):
    """Скопіювати теку, відсікаючи вироблене, важке й таємне."""
    dst.mkdir(parents=True, exist_ok=True)
    for p in src.iterdir():
        if p.name == WORK_MARK or ".BACKUP" in p.name or "_BACKUP" in p.name:
            continue
        try:
            if p.is_dir():
                if _skip_dir(p.name) or (skip and p.name in skip):
                    continue
                _copy_tree(p, dst / p.name)
            elif p.is_file():
                # ⛒ Таємні ключі машини в тимчасову теку не їдуть.
                if p.name.startswith(".env"):
                    continue
                if p.stat().st_size > _WORK_MAX_FILE:
                    continue
                shutil.copy2(p, dst / p.name)
        except OSError:
            continue


def work_copy(here, prefix="sf_work_"):
    """Зробити позначену робочу копію платформи в тимчасовій теці.

    ⛒ Копіюється ВЕСЬ рівень платформи, а не самий рушій: код рахує від себе і
    `PLATFORM_ROOT` (реєстр систем, `config`, `crm`, `ui`), і робочу теку
    проєкту. Копія без цих тек — не те саме оточення, що бій, і чек у ній
    червоніє не через ваду.
    """
    here = pathlib.Path(here).resolve()
    platform = here.parent
    root = pathlib.Path(tempfile.mkdtemp(prefix=prefix))
    # ⛒ Рушій копіюється ОКРЕМО і за своїми правилами: цілком він важить 290 МБ
    # (журнали, прогони, нитки), а за вирахуванням відновлюваного — 15 МБ, і
    # межа ваги не сміє викинути саме ту теку, заради якої все робиться.
    _copy_tree(platform, root / platform.name, skip={here.name})
    work = root / platform.name / here.name
    _copy_tree(here, work)
    (work / WORK_MARK).write_text("робоча копія набору мутацій\n", encoding="utf-8")
    return work


def isolate(setfile):
    """Відправити набір у робочу копію. `None` — ми вже в ній, працюй далі.

    Один рядок на початку `main()` набору — і жоден його запис не дістає
    бойової теки. Вихід дочірнього прогону йде людині як свій.
    """
    f = pathlib.Path(setfile).resolve()
    if (f.parent / WORK_MARK).exists():
        return None
    work = work_copy(f.parent, prefix="sf_mut_")
    try:
        r = subprocess.run([sys.executable, "-B", str(work / f.name)] + sys.argv[1:],
                           cwd=str(work))
        return r.returncode
    finally:
        shutil.rmtree(work.parents[1], ignore_errors=True)


# ────────────────────── ДЗЕРКАЛО ОБІРВАНОГО ПРОГОНУ ─────────────────────────

class LeftoverError(Exception):
    """Дзеркало попереднього прогону і живий файл розійшлись — судити людині."""


def check_leftovers(pairs):
    """⭐⭐⭐ 609: ДЗЕРКАЛО ОБІРВАНОГО ПРОГОНУ НЕ ВІДНОВЛЮЄТЬСЯ МОВЧКИ.

    🩸 Що було. Набори, які псують файли НА МІСЦІ, лишали поруч копію
    `файл_MUTBAK_...`, а на початку наступного прогону БЕЗУМОВНО копіювали її
    назад. Копію після прогону видаляють — але якщо видалення не спрацювало
    (а через місток до машини власника воно не спрацьовує ніколи), копія
    лишалась лежати. Наступний прогін мовчки повертав файл до стану
    багатоденної давності — і всю роботу, зроблену між тим, стирало б.

    ⛒ КЛАС: ПИСАР, ЯКИЙ МОЖЕ ЗНИЩИТИ РОБОТУ, НЕ СМІЄ ДІЯТИ БЕЗ СУДУ.
    Тому тут fail-closed: нічого не відновлюємо самі.
      * копія збігається з живим файлом → прогін завершився чисто, копія
        стала непотрібним слідом; кажемо про неї і працюємо далі;
      * копія РОЗХОДИТЬСЯ з живим файлом → зупиняємось і кажемо, ЯКІ файли
        і чим саме різняться. Рішення — за людиною, а не за мною.

    `pairs` — перелік пар `(живий файл, копія)`.
    """
    stale, diverged = [], []
    for src, bak in pairs:
        src, bak = pathlib.Path(src), pathlib.Path(bak)
        if not bak.exists():
            continue
        try:
            same = src.exists() and src.read_bytes() == bak.read_bytes()
        except Exception:
            same = False
        (stale if same else diverged).append((src, bak))
    if stale:
        print("⛒ слід попереднього прогону (файли цілі, копії зайві): %s"
              % ", ".join(b.name for _s, b in stale))
    if diverged:
        names = "; ".join("%s <> %s" % (s.name, b.name) for s, b in diverged)
        raise LeftoverError(
            "дзеркало попереднього прогону РОЗХОДИТЬСЯ з живим файлом: %s. "
            "Сам не відновлюю: між тим у файлі могла зʼявитись справжня "
            "робота. Звір обидва файли й вирішуй, який лишити." % names)
    return len(stale)

# ─────────────────── КІНЦІ РЯДКІВ ПЕРЕЖИВАЮТЬ МУТАЦІЮ ───────────────────────

_EOL = {}


def read_source(path):
    """Прочитати файл цілі, запамʼятавши, ЯКІ в ньому кінці рядків.

    🩸 609: набори, що псують файли НА МІСЦІ, читали `read_text` і повертали
    `write_text`. На Windows це нічого не міняє, а коли той самий набір
    проганяють із Linux (а так я і працюю на машині власника через місток),
    увесь файл мовчки переходить із CRLF на LF. Жодного рядка коду не
    змінилось — а файл змінився ВЕСЬ. Так 18.09.2026 переписався `license.py`.
    """
    p = pathlib.Path(path)
    raw = p.read_bytes()
    _EOL[str(p.resolve())] = "\r\n" if b"\r\n" in raw else "\n"
    return raw.decode("utf-8").replace("\r\n", "\n")


def write_source(path, text):
    """Записати назад ТИМИ САМИМИ кінцями рядків, що були при читанні.

    ⛒ 614. І ЛИШЕ В ПОЗНАЧЕНУ РОБОЧУ КОПІЮ. Відмова стається ДО запису, тож
    файл поза копією не встигає змінитись навіть на байт.
    """
    p = pathlib.Path(path)
    if not is_work_copy(p):
        raise LiveTreeError(
            "писар мутацій не пише поза робочою копією: %s. "
            "Набір мусить першим рядком main() покликати mutants.isolate(__file__)."
            % p)
    eol = _EOL.get(str(p.resolve()), "\n")
    data = text.replace("\r\n", "\n")
    if eol == "\r\n":
        data = data.replace("\n", "\r\n")
    p.write_bytes(data.encode("utf-8"))


def drop_mirror(path):
    """Прибрати дзеркало після ЧИСТОГО прогону — і не впасти, якщо не дали.

    🩸 609: прибирання стояло ПІСЛЯ відновлення файлів, але його невдача
    валила весь прогін винятком. Через місток до машини власника видаляти
    заборонено завжди, тож кожен такий набір закінчувався трейсбеком — і
    саме в цьому шумі 18.09.2026 загубилось те, що `origin.py` лишився
    зіпсованим. Невдале прибирання — це слід, а не аварія.
    """
    try:
        pathlib.Path(path).unlink()
        return True
    except FileNotFoundError:
        return True
    except Exception as exc:
        print("⛒ дзеркало лишилось на диску (%s): %s"
              % (pathlib.Path(path).name, exc.__class__.__name__))
        return False

