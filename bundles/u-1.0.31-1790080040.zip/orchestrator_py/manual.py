# -*- coding: utf-8 -*-
"""manual.py — ЖИВИЙ ДОВІДНИК ДЛЯ ЛЮДИНИ НА ЕКРАНІ (зміна 616, 20.09.2026).

⭐⭐⭐ ЩО ЦЕ ДЛЯ ЛЮДИНИ. Кнопка «Інструкція» вгорі домашньої сторінки. Всередині
— розділи довідника, стан ЦІЄЇ збірки просто зараз і кнопка «Запитати
оркестратора» для питань, відповіді на які людина не знайшла сама.

⛒ ЧОМУ НЕ PDF І НЕ ФАЙЛ. Документ, відданий файлом, застаріває наступного дня:
рівно так `README.md` роками обіцяв «18 активних систем», порт 8787 і «Global
Orchestrator is Codex». Довідник, який ЧИТАЄ джерело при кожному відкритті,
цією хворобою не хворіє за побудовою.

⛒ ВЛАСНОГО ТЕКСТУ ТУТ НЕМАЄ НІ РЯДКА. Джерело одне —
`Документація/МАНУАЛ_SensFlow.md`, і з нього ж зібрана база знань консультанта
платформи. Другого джерела заводити не можна: екран казав би одне, консультант
відповідав би інше, а людина повірила б тому, хто відповів останнім. Числа в
текст підставляє `manual_build` — кожне з того місця, яке за нього відповідає.

⛒ ЧИСЛА ПРО ЗБІРКУ РАХУЄ ТОЙ, ХТО ЇХ ЗНАЄ. «Систем у реєстрі» питаємо в
`platform_numbers`, порт — у налаштувань, версію — у писаря версій, конектори —
у реєстру конекторів. Жодного числа цей модуль не памʼятає.
"""
import re

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import manual_build               # ОДНЕ ДЖЕРЕЛО довідника й бази знань консультанта
import platform_numbers           # ОДИН лічильник живих чисел про збірку
import registry

SOURCE = manual_build.SOURCE
CONSULTANT_ID = manual_build.CONSULTANT_ID

# ⛒ ЗАКРИТИЙ ПЕРЕЛІК ПОЛІВ РОЗДІЛУ. Поле, яке екран малює повз цей перелік,
# ловить проба (стеля споживача) — як це вже працює для блоків картки.
SECTION_FIELDS = ("num", "title", "text")

SNIPPET = 400

# ⛒ СТАН КОНЕКТОРА МИ НЕ ВИГАДУЄМО — його каже реєстр конекторів, і ми лише
# перекладаємо його слово людині.
# 🩸 616: перша версія цього екрана питала в реєстру поле `ready`, якого він не
# віддає ЗОВСІМ, — і кожен конектор, включно з живим Gmail, показувався б
# «не підключено». Мовчазне `False` замість відповіді — це та сама брехня на
# екрані, від якої лікується весь цей модуль. Тому стан читається ДОСЛІВНО, а
# стан без слова ловить проба.
STATUS_WORDS = {
    "connected": "підключено",
    "not_connected": "не підключено",
    "not_configured": "не налаштовано",
    "authorization_required": "потрібна ваша згода",
}


class ManualScreenError(Exception):
    """Відмова з причиною словами. Тиха відмова = порожній екран без пояснення."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ════════════════════════════ ЗВІДКИ ЦЕ ВЗЯТО ══════════════════════════════
def sources() -> list:
    """Які файли стоять за довідником. Названі, щоб не гадати, звідки текст."""
    return [{"what": "мануал платформи (джерело правди)",
             "path": str(SOURCE), "exists": SOURCE.exists()},
            {"what": "база знань консультанта платформи",
             "path": str(manual_build.KB_DIR), "exists": manual_build.KB_DIR.exists()}]


def tracks() -> tuple:
    """Доріжки джерела, які стосуються ЦІЄЇ машини.

    ⛒ Доріжка «US» (наша кухня) клієнтові не показується: у його збірці цього
    тексту немає й на диску. Еталон упізнається тим самим писарем, що й скрізь."""
    keep = ["CLIENT"]
    import sys as _sys
    keep.append("MAC" if _sys.platform == "darwin" else "WIN")
    try:
        import features
        if features.is_master():
            keep.append("US")
    except Exception:
        pass
    return tuple(keep)


# ════════════════════════════════ РОЗДІЛИ ══════════════════════════════════
def sections(all_tracks: bool = False) -> list:
    """Розділи довідника — з диска, з підставленими живими числами.

    ⛒ Мітка `{{…}}`, що лишилась у тексті, — це ВІДМОВА в `manual_build`, а не
    порожнє місце на екрані людини. Ми її сюди не пропускаємо мовчки."""
    try:
        text = manual_build.filled()
        if not all_tracks:
            text = manual_build.apply_tracks(text, keep=tracks())
        rows = manual_build.sections(text)
    except manual_build.ManualError as ex:
        raise ManualScreenError("Довідник не зібрався: %s. Це поломка джерела, "
                                "а не ваша — скажіть про неї розробнику." % ex)
    except Exception as ex:
        raise ManualScreenError("Довідник не прочитався з диска: %s" % ex)
    return [{"num": _s(n), "title": _s(t), "text": _s(x)} for n, t, x in rows]


# ═══════════════════ ЦЯ ЗБІРКА ПРОСТО ЗАРАЗ (ЖИВІ ЧИСЛА) ═══════════════════
def now() -> dict:
    """Стан саме цієї збірки. Кожне число питаємо в того, хто його знає."""
    out = {"counted_at": clock.now(), "port": config.PORT}

    try:
        live = platform_numbers.live()
    except Exception as ex:
        raise ManualScreenError("Живі числа про збірку не порахувались: %s" % ex)
    out.update({k: live[k] for k in live})

    try:
        import update
        out["version"] = _s(update.current_version())
    except Exception:
        out["version"] = ""

    try:
        out["connectors"] = [
            {"id": _s(c.get("id")), "name": _s(c.get("name")) or _s(c.get("id")),
             "status": _s(c.get("status")),
             "label": _s(c.get("label")) or STATUS_WORDS.get(_s(c.get("status")), ""),
             "on": _s(c.get("status")) == "connected"}
            for c in (registry.connector_inventory() or [])]
    except Exception:
        out["connectors"] = []

    try:
        import license as _lic
        ent = _lic.entitlement() or {}
        out["license"] = {"mode": _s(ent.get("mode")), "until": _s(ent.get("until")),
                          "message": _s(ent.get("message"))}
    except Exception:
        out["license"] = {"mode": "", "until": "", "message": ""}

    return out


def screen() -> dict:
    """ВСЕ, що малює екран інструкції. Сам екран не знає нічого."""
    return {"sections": sections(), "now": now(), "sources": sources(),
            "section_fields": list(SECTION_FIELDS),
            "consultant": consultant_name()}


# ═════════════════════════════════ ПОШУК ═══════════════════════════════════
def search(query) -> list:
    """Пошук ЗВУЖУЄ довідник, а не вигадує відповідь.

    ⛒ Порожній запит — відмова словами, а не весь довідник: «знайдено все» і
    «не шукали» — це різні речі, і людина має бачити різницю."""
    q = _s(query).lower()
    if len(q) < 2:
        raise ManualScreenError("Напишіть, що шукати — хоча б два знаки. "
                                "Порожній запит знаходить усе, тобто нічого.")
    out = []
    for s in sections():
        hay = (s["title"] + "\n" + s["text"]).lower()
        if q not in hay:
            continue
        i = hay.find(q)
        lo = max(0, i - SNIPPET // 2)
        row = dict(s)
        row["snippet"] = (s["title"] + "\n" + s["text"])[lo:lo + SNIPPET]
        row["hits"] = hay.count(q)
        out.append(row)
    return out


# ═══════════════════════════ ЗАПИТАТИ ОРКЕСТРАТОРА ═════════════════════════
def consultant_name() -> str:
    sysd = registry.find_system(CONSULTANT_ID)
    return _s((sysd or {}).get("name"))


def ask(question, by: str = "", emp: str = None) -> dict:
    """Вільне питання — консультантові платформи, який відповідає ЛИШЕ з мануала.

    ⛒ ПРОДУКТОВИЙ ШЛЯХ, А НЕ СВІЙ: та сама `executor.run_system`, що й скрізь,
    тож тут працює суддя результату 612. Свого судді поруч не заводимо."""
    q = _s(question)
    if len(q) < 3:
        raise ManualScreenError("Питання порожнє. Напишіть словами, що саме "
                                "не виходить — консультант відповість із мануала.")
    sysd = registry.find_system(CONSULTANT_ID)
    if not sysd:
        raise ManualScreenError(
            "Консультанта платформи (%s) немає в реєстрі систем цієї збірки — "
            "питати нема кого. Розділи довідника на цьому екрані працюють і "
            "без нього." % CONSULTANT_ID)

    import executor
    import taskdesk_identity
    res = executor.run_system(taskdesk_identity.resolve_actor(emp), sysd, q) or {}
    status = _s(res.get("status"))
    if status == "honest_stop":
        hs = dict(res.get("honest_stop") or {})
        raise ManualScreenError(
            "Консультант спинився: %s. Що зробити: %s."
            % (_s(hs.get("reason")) or "причина не названа",
               _s(hs.get("action")) or "подивитись журнал прогону"))
    if status != "completed":
        raise ManualScreenError("Консультант завершив станом «%s» — відповіді "
                                "немає." % (status or "невідомо"))
    answer = _s(res.get("final_markdown"))
    if not answer:
        raise ManualScreenError("Консультант повернув порожню відповідь.")
    return {"answer": answer, "system": _s(sysd.get("name")),
            "asked": q, "at": clock.now()}
