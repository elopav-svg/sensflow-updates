# -*- coding: utf-8 -*-
"""taskdesk_org_chart.py — МАЛЮВАЛЬНИК СХЕМИ СТРУКТУРИ КОМПАНІЇ (зміна 284).

⭐ ЩО ЦЕ. Читач над оргданими: бере те, що вже лежить у taskdesk_people, і
рахує РОЗКЛАДКУ — де стоїть кожна коробка, куди йдуть лінії підпорядкування і
де лежать смуги горизонтів. Нічого не зберігає і нічого не заводить.

⛒ ЧОМУ РОЗКЛАДКУ РАХУЄ СЕРВЕР, А НЕ ЕКРАН. Екран не тримає власного слова:
якби координати рахував браузер, у нас було б два писарі однієї правди —
і друк, і картка працівника, і майбутній експорт розійшлися б із тим, що
людина бачить. Тут рахує ОДИН, а екран лише малює.

⛒ ЧОМУ СХЕМІ МОЖНА ВІРИТИ. Підпорядкування не зберігається ніде: воно
обчислюється з дерева підрозділів при читанні. Малювальник бере вже готове
manager_id і не вигадує власної вертикалі.

⭐ ВИСОТУ ЗАДАЄ ГЛИБИНА (слово Андрія 29.08.2026). Рівень коробки — це глибина
людини в дереві підпорядкування, а не її горизонт. Горизонт лише РОЗТЯГУЄ свою
смугу під тих, хто на ньому стоїть.

⛒ СМУГИ НЕ НАКЛАДАЮТЬСЯ. Якщо два горизонти претендують на ті самі рівні —
платформа КАЖЕ про це людині словами і не малює жодного з двох, замість того
щоб малювати кашу.

⛒ ЧЕСНІ МЕЖІ, НАЗВАНІ ВГОЛОС. Схема малює лише офіційну підпорядкованість.
Людина без керівника показується коренем окремого дерева, а не підвішується
навмання: саме через це схема ще й сторож оргданих — керівник одразу бачить,
у кого немає начальника.

⭐ ЗГОРТАННЯ ГІЛОК (зміна 337). 700 людей у ширину — це майже два кілометри
прокрутки, тобто схема, якою не можна користуватись. Тому велика структура
відкривається ВЕРХІВКОЮ: два верхні щаблі видно, глибші гілки згорнуті й
підписані числом схованих. Маленька — як досі, вся одразу. Межа одна й названа
числом (AUTO_FULL_LIMIT), щоб та сама компанія відкривалась щоразу однаково.

⛒ ЗГОРНУТЕ НЕ ЗБЕРІГАЄТЬСЯ НА ДИСКУ. Це не властивість компанії, а погляд
однієї людини в одну мить: писати його в оргдані означало б, що двоє людей
не можуть дивитись на схему по-різному.

Офлайн, $0. Нічого не пише на диск.
"""
import taskdesk_people as P

# Розміри коробки й проміжків. Живуть тут, бо розкладку рахує сервер.
BOX_W = 240
BOX_H = 62
GAP_X = 26
GAP_Y = 58
PAD = 28
TREE_GAP = 1          # порожній слот між окремими деревами
BAND_PAD = 12         # наскільки смуга виступає над коробкою і під нею
BAND_PAD_X = 10       # і наскільки вона виступає ліворуч та праворуч

# ── ЗГОРТАННЯ ГІЛОК ───────────────────────────────────────────────────────
# ⚖ Слово Андрія 30.08.2026: маленька компанія відкривається ПОВНІСТЮ, велика —
# верхівкою. Межа названа числом тут, в одному місці, а не розсипана по коду.
AUTO_FULL_LIMIT = 40  # доти схема відкривається вся, як досі
OPEN_LEVELS = 2       # скільки верхніх щаблів лишається відкритими у великої
FOLD_W = 88           # знак згортання: не вужчий за 44 — це зона під палець
FOLD_H = 44
FOLD_GAP = 4          # відступ знака від нижнього краю коробки
PILL_W = 60           # сам знак: малий для ока, зона навколо — велика
PILL_H = 24


def _color(raw) -> str:
    """Колір горизонту, придатний до малювання. Чужий текст сюди не проходить.
    ⛒ Що САМЕ є кольором, вирішує не малювальник, а оргдані: одне правило —
    один сторож."""
    txt = (raw or "").strip()
    return txt if P.is_horizon_color(txt) else ""


def _plural(n: int, one: str, few: str, many: str) -> str:
    """Українське число словами. Текст для людини не сміє бути калікою."""
    last, two = n % 10, n % 100
    if 11 <= two <= 14:
        return many
    if last == 1:
        return one
    if 2 <= last <= 4:
        return few
    return many


def _unit_word(n: int, names: list) -> str:
    """«Підрозділ «X»» або «Підрозділи «X», «Y»» — з правильним числом."""
    word = _plural(n, "Підрозділ", "Підрозділи", "Підрозділи")
    return "%s %s" % (word, ", ".join("«%s»" % s for s in names))


def _tree_word(n: int) -> str:
    return "%d %s" % (n, _plural(n, "окреме дерево", "окремі дерева", "окремих дерев"))


def _people_word(n: int) -> str:
    return "%d %s" % (n, _plural(n, "людину", "людей", "людей"))


def _people_nom(n: int) -> str:
    """Те саме число, але у називному відмінку: «у компанії 3 ЛЮДИНИ».
    ⛒ Один помічник на обидва відмінки — це каліка в тексті для клієнта."""
    return "%d %s" % (n, _plural(n, "людина", "людини", "людей"))


def _order_key(e: dict) -> tuple:
    """Порядок сусідів. Стабільний і не залежить від того, як лягли дані:
    інакше та сама структура малювалась би щоразу інакше."""
    return (e.get("unit_name") or "", e.get("full_name") or "", e.get("id") or "")


def _levels(parent: dict) -> dict:
    """Рівень = глибина в дереві підпорядкування. Той, до кого не вдалося
    дійти (він у кільці або під кільцем), сюди не потрапляє."""
    level = {}
    for eid in parent:
        chain, cur, seen, ok = [], eid, set(), True
        while cur and cur not in level:
            if cur in seen:
                ok = False
                break
            seen.add(cur)
            chain.append(cur)
            cur = parent.get(cur, "")
        if not ok:
            continue
        base = level[cur] + 1 if cur else 0
        for i, node in enumerate(reversed(chain)):
            level[node] = base + i
    return level


def _ring_members(parent: dict, unresolved) -> set:
    """Хто САМЕ стоїть у кільці. Підлеглі під кільцем не винні — їм керівника
    не рвемо."""
    ring = set()
    for eid in unresolved:
        cur, seen = parent.get(eid, ""), set()
        while cur and cur not in seen:
            if cur == eid:
                ring.add(eid)
                break
            seen.add(cur)
            cur = parent.get(cur, "")
    return ring


def _why_empty(number: str, st: dict, emps: list, heads: set,
               hidden_on: int = 0) -> str:
    """Чому на горизонті нікого немає — словами й з наступним кроком.
    Повідомлення без причини людина читає як поломку.

    ⛒ ЗГОРНУТА ГІЛКА — НЕ ПОРОЖНІЙ ГОРИЗОНТ. Якщо люди на горизонті є, але
    вони сховані під згорнутою гілкою, сказати «нікого немає» означало б
    збрехати: людина пішла б заводити те, що вже заведено."""
    if hidden_on:
        return ("Горизонт %s зараз не видно: %s на ньому %s у згорнутих "
                "гілках. Розгорніть гілку, щоб побачити його смугу."
                % (number, _people_nom(hidden_on),
                   "стоїть" if hidden_on == 1 else "стоять"))
    # ⛒ БЕЗ КРАПКИ В КІНЦІ: далі може стати причина, і тоді речення склеїлось би
    # через крапку з малої літери. Крапку ставить той, хто закінчує речення.
    base = "Горизонт %s заведено, але на ньому поки нікого немає" % number
    units_on = [u for u in (st.get("units") or [])
                if (u.get("horizon_id") or "") == number and u.get("alive", True)]
    own = [e for e in emps if (e.get("horizon_id") or "") == number]
    if not units_on and not own:
        return base + ". Його ще нікому не поставлено: номер дається підрозділу " \
                      "або окремій людині в її картці."
    why = []
    for u in units_on:
        name = u.get("name") or u.get("id")
        inside = [e for e in emps if e.get("unit_id") == u["id"]]
        if not inside:
            why.append("у підрозділі «%s» ще немає працівників" % name)
        elif all(e["id"] == (u.get("head_employee_id") or "") for e in inside):
            why.append("у підрозділі «%s» єдина людина — його керівник, а на "
                       "керівника горизонт підрозділу не діє: поставте номер "
                       "йому особисто, в його картці" % name)
    # Причина — не окреме повідомлення, а пояснення до першої половини, тому
    # двокрапка, а не крапка.
    return base + (": " + "; ".join(why) + "." if why else ".")


def _subtree_size(children: dict, eid: str) -> int:
    """Скільки людей стоїть ПІД цією людиною — на всю глибину. Саме це число
    людина бачить на знаку згортання, тож воно мусить бути повним, а не
    «скільки безпосередніх підлеглих»."""
    total, stack = 0, list(children.get(eid, []))
    while stack:
        cur = stack.pop()
        total += 1
        stack.extend(children.get(cur, []))
    return total


def _default_collapsed(children: dict, level: dict, total: int) -> set:
    """ЩО ПЛАТФОРМА ЗГОРТАЄ САМА, поки людина нічого не натискала.

    ⛒ ПРАВИЛО ОДНЕ Й ПЕРЕДБАЧУВАНЕ: доки людей небагато — не згортаємо нічого;
    щойно їх більше за межу — лишаємо відкритими два верхні щаблі, а кожну
    гілку з підлеглими глибше згортаємо. Розумніший добір («згортати, доки
    не влізе») дав би схему, яку людина не може передбачити: та сама компанія
    відкривалась би щоразу інакше."""
    if total <= AUTO_FULL_LIMIT:
        return set()
    return set(eid for eid in children
               if eid and children.get(eid) and level.get(eid, 0) >= OPEN_LEVELS - 1)


def _hidden_under(children: dict, collapsed: set, roots: list) -> set:
    """Хто не малюється. Ховає ГІЛКУ, а не саму людину: згорнута людина
    лишається на схемі — інакше не було б на що натиснути, щоб розгорнути."""
    hidden, stack = set(), [(r, False) for r in roots]
    while stack:
        eid, under = stack.pop()
        if under:
            hidden.add(eid)
        deeper = under or (eid in collapsed)
        for k in children.get(eid, []):
            stack.append((k, deeper))
    return hidden


def layout(include_dismissed: bool = False, fold=None, open_=None) -> dict:
    """Готова розкладка схеми. Екран лише малює те, що тут пораховано.

    `fold` і `open_` — це те, що людина натиснула САМА, поверх того, що
    платформа згорнула за правилом. Тримати їх окремо від правила треба, щоб
    посилання на схему лишалось коротким і читалось як «типовий вигляд плюс
    мої кліки», а не як довжелезний перелік усіх гілок."""
    st = P.load()
    emps = [e for e in (st.get("employees") or [])
            if include_dismissed or e.get("active")]
    by_id = {e["id"]: e for e in emps}
    notes = []

    # ⛒ Схема показує компанію, ЯКА Є. Ліквідований підрозділ у неї не
    # входить — ні керівником, ні порожнечею, про яку варто сказати.
    live_units = [u for u in (st.get("units") or []) if u.get("alive", True)]
    heads = set()
    for u in live_units:
        h = u.get("head_employee_id") or ""
        if h:
            heads.add(h)

    # Керівник береться з даних. Якщо він не малюється (звільнений або його
    # немає) — людина стає коренем, а не висить у порожнечі.
    parent = {}
    for e in emps:
        m = e.get("manager_id") or ""
        parent[e["id"]] = m if (m in by_id and m != e["id"]) else ""

    level = _levels(parent)
    unresolved = [eid for eid in parent if eid not in level]
    if unresolved:
        ring = _ring_members(parent, unresolved)
        for eid in ring:
            parent[eid] = ""
        level = _levels(parent)
        for eid in parent:
            level.setdefault(eid, 0)
        if ring:
            notes.append("У підпорядкуванні знайдено кільце. %s показано без "
                         "керівника." % _people_word(len(ring)))

    children = {}
    for eid, m in parent.items():
        children.setdefault(m, []).append(eid)
    for key in children:
        children[key].sort(key=lambda i: _order_key(by_id[i]))
    roots = children.get("", [])
    # Спершу СПРАВЖНІ дерева, потім самотні люди без керівника: інакше одна
    # прибиральниця відсуває всю компанію праворуч, і схема починається з
    # порожнього місця.
    roots.sort(key=lambda i: (0 if children.get(i) else 1, _order_key(by_id[i])))

    # ── ЗГОРТАННЯ ГІЛОК ────────────────────────────────────────────────────
    auto = _default_collapsed(children, level, len(emps))
    asked_fold = set(x for x in (fold or []) if x in by_id)
    asked_open = set(x for x in (open_ or []) if x in by_id)
    # Слово людини сильніше за правило платформи, і «розгорнути» сильніше за
    # «згорнути»: інакше розгорнута гілка згорталась би сама, і людина не
    # змогла б до неї дістатись.
    collapsed = set(eid for eid in ((auto | asked_fold) - asked_open)
                    if children.get(eid))
    hidden = _hidden_under(children, collapsed, roots)
    shown = [e for e in emps if e["id"] not in hidden]
    shown_ids = set(e["id"] for e in shown)

    kids_shown = {}
    for key, kids in children.items():
        kids_shown[key] = [k for k in kids if k in shown_ids]
    roots_shown = [r for r in roots if r in shown_ids]

    # Слоти по горизонталі: листки стають поруч, батько — по центру над своїми.
    # Згорнута людина рахується листком — під нею нічого не малюється.
    slot, cursor = {}, [0]

    def _walk(eid):
        kids = kids_shown.get(eid, []) if eid not in collapsed else []
        if not kids:
            slot[eid] = float(cursor[0])
            cursor[0] += 1
            return slot[eid]
        xs = [_walk(k) for k in kids]
        slot[eid] = (xs[0] + xs[-1]) / 2.0
        return slot[eid]

    for r in roots_shown:
        _walk(r)
        cursor[0] += TREE_GAP

    boxes = []
    for e in shown:
        eid = e["id"]
        under = _subtree_size(children, eid)
        bx = PAD + slot.get(eid, 0.0) * (BOX_W + GAP_X)
        by = PAD + level.get(eid, 0) * (BOX_H + GAP_Y)
        box = {
            "emp_id": eid,
            "name": e.get("full_name") or "",
            "position": e.get("position_name") or "",
            "unit": e.get("unit_name") or "",
            "level": level.get(eid, 0),
            "x": bx,
            "y": by,
            "w": BOX_W,
            "h": BOX_H,
            "horizon_id": e.get("horizon_effective_id") or "",
            "is_head": eid in heads,
            "broken": bool(e.get("broken")),
            "broken_reason": e.get("broken_reason") or "",
            "collapsed": eid in collapsed,
            "under_count": under,
        }
        # ⛒ ЗНАК ЗГОРТАННЯ ТЕЖ РАХУЄ СЕРВЕР. Якби його місце вигадував екран,
        # у нас було б два писарі однієї розкладки. Ширина й висота знаку —
        # не менші за 44, бо це зона під палець.
        if under:
            box["fold"] = {
                # Зона під палець: по ній ловиться натиск, її не видно.
                "x": bx + BOX_W / 2.0 - FOLD_W / 2.0,
                "y": by + BOX_H + FOLD_GAP,
                "w": FOLD_W,
                "h": FOLD_H,
                # Сам знак: те, що бачить око, рівно посередині зони.
                "px": bx + BOX_W / 2.0 - PILL_W / 2.0,
                "py": by + BOX_H + FOLD_GAP + (FOLD_H - PILL_H) / 2.0,
                "pw": PILL_W,
                "ph": PILL_H,
                # І де стоїть саме число: центрувати підпис у прямокутнику —
                # теж розкладка, а розкладку рахує один.
                "tx": bx + BOX_W / 2.0,
                "ty": by + BOX_H + FOLD_GAP + FOLD_H / 2.0,
                "hidden": under if eid in collapsed else 0,
                "collapsed": eid in collapsed,
                "label": ("+%d" % under) if eid in collapsed else "−",
                "title": (("Розгорнути: під цією людиною %s" % _people_nom(under))
                          if eid in collapsed
                          else ("Згорнути: сховати %s" % _people_word(under))),
            }
        boxes.append(box)
    boxes.sort(key=lambda b: (b["level"], b["x"], b["emp_id"]))
    box_by_id = {b["emp_id"]: b for b in boxes}

    links = []
    for eid, m in parent.items():
        if not m or eid in hidden or m in hidden or eid not in box_by_id:
            continue
        a, b = box_by_id[m], box_by_id[eid]
        links.append({"from_emp_id": m, "to_emp_id": eid,
                      "x1": a["x"] + a["w"] / 2.0, "y1": a["y"] + a["h"],
                      "x2": b["x"] + b["w"] / 2.0, "y2": b["y"]})
    links.sort(key=lambda l: (l["from_emp_id"], l["to_emp_id"]))

    width = int(max([b["x"] + b["w"] for b in boxes] or [0]) + PAD)
    height = int(max([b["y"] + b["h"] + (FOLD_GAP + FOLD_H if b.get("fold") else 0)
                      for b in boxes] or [0]) + PAD)

    # ── СМУГИ ГОРИЗОНТІВ ───────────────────────────────────────────────────
    # ⛒ СМУГА ЛЯГАЄ ЛИШЕ ПІД ВИДИМИМИ. Сховану людину смуга накрити не може —
    # її на схемі немає; про схованих платформа каже СЛОВАМИ, нижче.
    rows_of = {}
    for b in boxes:
        if b["horizon_id"]:
            rows_of.setdefault(b["horizon_id"], set()).add(b["level"])

    hidden_on = {}
    for e in emps:
        h = e.get("horizon_effective_id") or ""
        if h and e["id"] in hidden:
            hidden_on[h] = hidden_on.get(h, 0) + 1

    cands = []
    for h in (st.get("horizons") or []):
        rows = rows_of.get(h["id"]) or set()
        if not rows:
            notes.append(_why_empty(h["id"], st, emps, heads,
                                    hidden_on.get(h["id"], 0)))
            continue
        lo, hi = min(rows), max(rows)
        cands.append({"horizon_id": h["id"], "color": _color(h.get("color")),
                      "number": int(h["id"]),
                      "lo": lo, "hi": hi,
                      "levels": set(range(lo, hi + 1))})

    # ⛒ Два правила на пару смуг, і обидва про одне: картинка не сміє
    # суперечити номерам. Менший номер стоїть ВИЩЕ і не займає чужих рядів.
    cands.sort(key=lambda x: x["number"])
    conflicts, bad = [], set()
    for i in range(len(cands)):
        for j in range(i + 1, len(cands)):
            a, c = cands[i], cands[j]          # a — з МЕНШИМ номером
            if a["levels"] & c["levels"]:
                bad.add(a["horizon_id"])
                bad.add(c["horizon_id"])
                conflicts.append(
                    "Горизонти %s і %s стоять на тих самих рівнях структури. "
                    "Поки це не розведено, жоден із них на схемі не показано."
                    % (a["number"], c["number"]))
            elif a["lo"] > c["hi"]:
                bad.add(a["horizon_id"])
                bad.add(c["horizon_id"])
                conflicts.append(
                    "Горизонт %s опинився НИЖЧЕ за горизонт %s: номери йдуть "
                    "згори вниз, тож картинка суперечила б самим номерам. "
                    "Поки це не виправлено, жоден із них на схемі не показано."
                    % (a["number"], c["number"]))

    # ⛒ Смуга складається з ВІДРІЗКІВ: по одному на кожну суцільну низку
    # своїх людей у ряду. Чужа людина в ряду розриває смугу, а не потрапляє
    # під неї: інакше картинка припише її до чужої паралелі.
    by_level = {}
    for b in boxes:
        by_level.setdefault(b["level"], []).append(b)
    for lv in by_level:
        by_level[lv].sort(key=lambda b: b["x"])

    bands = []
    for c in cands:
        if c["horizon_id"] in bad:
            continue
        first = True
        for lv in sorted(l for l in by_level
                         if any(b["horizon_id"] == c["horizon_id"]
                                for b in by_level[l])):
            run = []
            for b in by_level[lv] + [None]:
                mine = b is not None and b["horizon_id"] == c["horizon_id"]
                # ⛒ НИЗКА УРИВАЄТЬСЯ І НА ПОРОЖНЬОМУ МІСЦІ. Згортання розсуває
                # сусідів, і між двома своїми може лягти діра завширшки з
                # екран. Пофарбувати її означало б пообіцяти паралель там, де
                # немає жодної людини.
                if mine and run and \
                        b["x"] - (run[-1]["x"] + run[-1]["w"]) > GAP_X:
                    mine = "break"
                if mine is True:
                    run.append(b)
                    continue
                if run:
                    left = run[0]["x"] - BAND_PAD_X
                    right = run[-1]["x"] + run[-1]["w"] + BAND_PAD_X
                    bands.append({
                        "horizon_id": c["horizon_id"], "color": c["color"],
                        "number": c["number"], "level": lv,
                        "x": left, "w": right - left,
                        "y": PAD + lv * (BOX_H + GAP_Y) - BAND_PAD,
                        "h": BOX_H + 2 * BAND_PAD,
                        # Номер підписується РАЗ на горизонт — біля найпершого
                        # відрізка; вісім підписів одного числа це не легенда,
                        # а шум.
                        "label": first})
                    first = False
                    run = []
                if mine == "break":
                    run.append(b)
        if hidden_on.get(c["horizon_id"]):
            n = hidden_on[c["horizon_id"]]
            notes.append("Горизонт %s: ще %s у згорнутих гілках — смуга "
                         "показує лише видимих." % (c["number"], _people_nom(n)))

    # ⛒ Підрозділ без людей на схемі не існує — бо коробка це людина. Мовчати
    # про це не можна: людина шукатиме свою роботу й не знайде.
    empty_units = [u.get("name") or u["id"] for u in live_units
                   if not any(e.get("unit_id") == u["id"] for e in emps)]
    if empty_units:
        notes.append("%s поки без працівників, тому на схемі %s немає: схема "
                     "показує людей. %s"
                     % (_unit_word(len(empty_units), empty_units),
                        "їх" if len(empty_units) > 1 else "його",
                        "Заведіть у них працівників на екрані «Працівники й "
                        "підрозділи»."))

    if len(roots_shown) > 1:
        notes.append("Схема показує %s: стільки людей не мають керівника."
                     % _tree_word(len(roots_shown)))

    # ⛒ ІНСТРУМЕНТ ПОЯСНЮЄ СЕБЕ САМ. Людина, яка відкрила схему й побачила
    # менше людей, ніж їх є, мусить одразу прочитати ЧОМУ і ЩО натиснути.
    if hidden:
        if auto and not asked_fold and not asked_open:
            notes.append(
                "У компанії %s, тому схема відкрита до другого щабля: гілки з "
                "підлеглими згорнуті. Натисніть знак з числом під людиною, щоб "
                "розгорнути її гілку." % _people_nom(len(emps)))
        else:
            notes.append("Зараз показано %s із %d: решта — у згорнутих гілках."
                         % (_people_word(len(shown)), len(emps)))
    elif len(emps) > AUTO_FULL_LIMIT:
        # Плоска структура: згортати нема чого, і мовчати про це не можна —
        # інакше людина шукатиме знак, якого немає.
        notes.append("У компанії %s, але згортати нічого: глибших гілок "
                     "немає — усі стоять на одному щаблі, тому схема "
                     "прокручується вбік." % _people_nom(len(emps)))

    return {"boxes": boxes, "links": links, "bands": bands,
            "band_conflicts": conflicts, "notes": notes,
            "roots": list(roots_shown), "width": width, "height": height,
            "levels": (max([b["level"] for b in boxes]) + 1) if boxes else 0,
            "collapsed": sorted(collapsed),
            "auto_collapsed": bool(auto),
            "people_total": len(emps),
            "people_shown": len(shown),
            "unreadable_reason": st.get("unreadable_reason") or ""}
