# -*- coding: utf-8 -*-
"""machine.py — ⛒ ЛІЦЕНЗІЯ ЖИВЕ НА ОДНІЙ МАШИНІ (шар 3 захисту, 13.09.2026).

⛒⛒⛒ ЩО ЦЕ ЛІКУЄ: **ТИХЕ РОЗПОВЗАННЯ КОПІЇ ВСЕРЕДИНІ КОМПАНІЇ.** «А нам теж
треба — постав ще на пʼять». Тека копіюється за хвилину, і жодна ліцензія цьому
не заважає, бо платформа не знає, на якій вона машині.

⭐ РІШЕННЯ ВЛАСНИКА 13.09.2026, шар 3 плану захисту від тиражування.

⛒ ЧОМУ ПРИВʼЯЗКА ПРИ ПЕРШОМУ СТАРТІ, А НЕ ВІДБИТОК У КЛЮЧІ. План казав «ключ
містить відбиток заліза». Так не виходить: ключ клієнта вшивається у збірку ще
у власника, а на якій машині її поставлять — невідомо. Тому платформа привʼязує
себе САМА при першому старті; шлях «ключ уже привʼязаний» лишається відкритим
для нових ключів.

⛒ ЧОМУ КІЛЬКА ОЗНАК, А НЕ ОДНА. Серійник диска, мережева адреса, ім'я машини
поодинці ненадійні: оновився драйвер, увімкнувся VPN, замінили адаптер — і
чесний клієнт заблокований без вини. 🩸 Для мілтеку зупинка без причини гірша
за копію. Тому ознак кілька, і машина вважається своєю, поки збігається
БІЛЬШІСТЬ. Змінилась одна — працюємо далі.

⛒ І ЗУПИНКА НЕ МОВЧИТЬ. «Просто не стартує» — це вада, а не захист: людина не
знає, що сталось і що робити. Платформа каже, що машина інша, і називає вихід.

⛒ ЧЕСНА МЕЖА. Це зупиняє КОПІЮВАННЯ ТЕКИ, а не свідомий злам: хто прицільно
знайде й почистить привʼязку — обійде. План це визнає; тримає зв'язка трьох
шарів, а не один. Зате людина, що копіює без злого наміру, зупиняється сама —
бо бачить чорним по білому, що ця копія не для цієї машини.
"""
import hashlib
import hmac
import json
import platform
import sys
import uuid
from pathlib import Path

import config

# Файл привʼязки лежить У ТЕЦІ ПЛАТФОРМИ навмисно: копія теки несе привʼязку з
# собою, і на новій машині одразу видно, що вона чужа. Сховай ми його в профіль
# користувача — копія приїхала б «чистою» і привʼязалась би заново.
# ⛒ Імʼя — у ПИСАРЯ ЖИВОГО СТАНУ, не тут: цей файл не сміє поїхати клієнту
# в пакеті, і судді складу питають саме його.
import state_files

_PATH = config.STATE_DIR / state_files.MACHINE_BIND

# ⛒ ПРАВИЛО БІЛЬШОСТІ, ЯКЕ НЕ ЗАЛЕЖИТЬ ВІД ТОГО, СКІЛЬКИ ОЗНАК ДАЛА ОС.
# Машина своя, коли збіглося щонайменше NEED ознак І РОЗІЙШЛОСЯ не більше DRIFT.
#   NEED  — щоб одна випадково спільна ознака (спільне імʼя, спільний образ
#           диска в конторі) не робила чужу машину своєю;
#   DRIFT — щоб оновлення драйвера чи VPN, які міняють ОДНУ ознаку, не
#           блокували чесного клієнта.
# 🩸 13.09.2026: поки поріг був один (NEED), правило означало різне на різних
# машинах — на чотириознаковій воно пропускало ДВІ змінені ознаки. Тепер обидва
# боки названі числом, і вердикт однаковий скрізь.
NEED = 2
DRIFT = 1


def _secret() -> bytes:
    """Той самий секрет, що підписує ліцензію: один ключ на весь продукт."""
    try:
        import license as _lic
        return _lic._as_bytes(_lic._SECRET)
    except Exception:
        return b"sensflow"


def _host_name() -> str:
    """Імʼя компʼютера. Окремий читач — щоб проба могла його підмінити."""
    try:
        return str(platform.node() or "").strip().lower()
    except Exception:
        return ""


def _volume_serial() -> str:
    """Серійник системного тому. Windows — через системний виклик, Linux — з
    machine-id. Немає — порожньо, і це не біда: ознак кілька."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            buf = ctypes.c_uint(0)
            ctypes.windll.kernel32.GetVolumeInformationW(
                ctypes.c_wchar_p("C:\\"), None, 0, ctypes.byref(buf),
                None, None, None, 0)
            return ("%08X" % buf.value) if buf.value else ""
        except Exception:
            return ""
    for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
        try:
            return Path(p).read_text(encoding="utf-8").strip()[:32]
        except Exception:
            continue
    return ""


def _machine_guid() -> str:
    """Windows MachineGuid — найстабільніша ознака: живе від встановлення ОС."""
    if not sys.platform.startswith("win"):
        return ""
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                            r"SOFTWARE\Microsoft\Cryptography") as k:
            return str(winreg.QueryValueEx(k, "MachineGuid")[0])
    except Exception:
        return ""


def traits() -> dict:
    """Ознаки цієї машини. Порожня ознака — норма, не помилка.

    ⛒ Нічого особистого: ім'я компʼютера, серійник тому, апаратна адреса й
    ідентифікатор встановлення ОС. Ні користувача, ні шляхів, ні файлів."""
    return {"host": _host_name(),
            "volume": _volume_serial(),
            "guid": _machine_guid(),
            "mac": _mac()}


def _mac() -> str:
    """Апаратна адреса цієї машини — окремий читач, як і решта ознак."""
    try:
        return mac_of(uuid.getnode())
    except Exception:
        return ""


def mac_of(n) -> str:
    """Апаратна адреса як ознака машини — або порожньо.

    ⛒ Python, коли не зміг прочитати справжню адресу, повертає ВИГАДАНЕ число
    з піднятим наймолодшим бітом першого байта. Таке число щоразу інше, і
    взяти його за ознаку машини означало б блокувати клієнта на кожному
    старті."""
    try:
        n = int(n)
    except Exception:
        return ""
    if (n >> 40) & 1:
        return ""
    return "%012x" % n


def _sign(tr: dict) -> str:
    body = json.dumps(tr, sort_keys=True, ensure_ascii=False).encode("utf-8")
    return hmac.new(_secret(), body, hashlib.sha256).hexdigest()[:32]


def _saved() -> dict:
    """Записана привʼязка. Порожньо — привʼязки немає або вона не наша."""
    try:
        raw = json.loads(Path(_PATH).read_text(encoding="utf-8"))
    except Exception:
        return {}
    tr = raw.get("traits")
    if not isinstance(tr, dict) or not raw.get("sign"):
        return {}
    # ⛒ Підпис — щоб привʼязку не можна було переписати блокнотом.
    # 🩸 Порівнюємо БАЙТИ, а не рядки: `compare_digest` на рядку з кирилицею
    # кидає TypeError, і підроблена привʼязка валила б платформу замість того,
    # щоб чесно не прийнятись. Спіймано пробою 13.09.2026.
    try:
        _got = str(raw["sign"]).encode("utf-8", "ignore")
    except Exception:
        return {}
    if not hmac.compare_digest(_got, _sign(tr).encode("utf-8")):
        return {}
    return raw


def check() -> dict:
    """Стан привʼязки: {state, ok, matched, of}.

    state: `first` — привʼязки ще немає (перший старт, робота дозволена);
           `same`  — та сама машина;
           `foreign` — інша машина, роботу починати не можна."""
    saved = _saved()
    if not saved:
        return {"state": "first", "ok": True, "matched": 0, "of": 0}
    now, was = traits(), saved["traits"]
    keys = [k for k in was if str(was.get(k) or "").strip()]
    if not keys:
        # Привʼязка без жодної живої ознаки нічого не доводить — вважаємо,
        # що привʼязки немає, а не що машина чужа.
        return {"state": "first", "ok": True, "matched": 0, "of": 0}
    matched = sum(1 for k in keys if str(now.get(k) or "") == str(was[k]))
    # 🩸 Нижній поріг не може вимагати більше, ніж ознак існує: на машині,
    # де ОС дала лише одну ознаку, правило «треба дві» зробило б машину чужою
    # САМІЙ СОБІ — і чесний клієнт не запустив би платформу ніколи.
    need = min(NEED, len(keys))
    ok = matched >= need and (len(keys) - matched) <= DRIFT
    return {"state": "same" if ok else "foreign",
            "ok": ok, "matched": matched, "of": len(keys)}


def bind() -> bool:
    """Записати привʼязку до цієї машини. Мовчазна невдача заборонена."""
    tr = traits()
    if not any(str(v).strip() for v in tr.values()):
        return False              # ⛒ нічого не прочитали — не вигадуємо
    try:
        Path(_PATH).parent.mkdir(parents=True, exist_ok=True)
        Path(_PATH).write_text(
            json.dumps({"traits": tr, "sign": _sign(tr)}, ensure_ascii=False),
            encoding="utf-8")
        return True
    except Exception as ex:
        try:
            import llm
            llm._log("[machine] привʼязку не записано: %s" % ex)
        except Exception:
            pass
        return False


def explain(st=None) -> str:
    """Що сказати людині. ⛒ Не «доступ заборонено», а що сталось і що робити."""
    st = st if isinstance(st, dict) else check()
    if st.get("ok"):
        return ""
    return ("Ця копія платформи ліцензована для ІНШОЇ машини. Збіглося %d "
            "ознак із %d — це не той компʼютер, на якому її встановили.\n"
            "Що зробити: попросіть новий ключ для цієї машини — ліцензія "
            "переноситься, доплата за це не потрібна."
            % (st.get("matched", 0), st.get("of", 0)))


def ensure_bound() -> dict:
    """⛒ ОДНА ДІЯ НА СТАРТІ: немає привʼязки — привʼязуємось; є — звіряємо."""
    st = check()
    if st.get("state") == "first":
        bind()
        st = check()
    return st
