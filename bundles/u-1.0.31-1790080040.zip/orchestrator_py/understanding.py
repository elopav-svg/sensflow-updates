# -*- coding: utf-8 -*-
"""understanding.py — ОДИН ПИСАР РОЗУМІННЯ ЗАДАЧІ (11.08.2026, зміна 152, крок 4).

НАВІЩО ЦЕЙ МОДУЛЬ ІСНУЄ.
Платформа перестала вгадувати сенс запиту переліками слів і почала його
ОГОЛОШУВАТИ (зміни 150-151). Але оголошення, якого людина не бачить, — це та
сама здогадка, лише машинна: 11.08 мозок оголосив «закупівлі» на питання водія,
і клієнт дізнався про це вже з відповіді, за свої гроші.

Тому перед запуском системи платформа ПОКАЗУЄ, як вона зрозуміла задачу, і дає
виправити ОДНИМ КЛІКОМ — до витрат.

    СЕНС ДАЄ МОЗОК, НАСЛІДОК НЕСЕ КОД. ТЕКСТ КАРТКИ СКЛАДАЄ ПЛАТФОРМА.

ЩО ТУТ ЖИВЕ (і ніде більше):
  • ПОРЯДОК СИЛИ: клієнт > тверда очевидність > мозок > паспорт системи > дефолт;
  • ТЕКСТ картки — з довідника, жодного речення від моделі;
  • ВІДБИТОК контракту (щоб мовчати про те, що не змінилось);
  • СУПЕРЕЧНІСТЬ із паспортом системи — ОДИН писар, а не два;
  • СЛІД у `runs/_audit.jsonl` — і коли питали, і коли пройшли мовчки.

ЧОГО ТУТ НЕМАЄ. Жодного переліку слів. Жодного рішення «запускати чи ні» — це
робить той, хто має канал до людини. Модуль лише КАЖЕ, що зрозуміло і що
розбіжне.

⚠ ЧОМУ СУПЕРЕЧНІСТЬ СУДИТЬ ЛИШЕ ЯВНА ДЕКЛАРАЦІЯ ПАСПОРТА.
Галузь системи вміє братися з НАШОЇ категорії (`registry._system_domain`) — це
законна ЗАПАСНА підказка, коли галузь не оголошено. Але зупиняти роботу через
неї не можна: категорія `legal` дає `civil_contract`, і тоді юрист-консультант
відмовився б відповідати водієві про ПДР — рівно той дефект, який ми лікуємо,
лише з іншого боку. Зупиняє тільки те, що записано в паспорті РУКОЮ, як факт
про систему: `entry["domain"]`.
"""

import config
import phrases

# Ключі рядків картки, які мають НАСЛІДОК і які клієнт може змінити.
EDITABLE = ("domain", "jurisdiction")

# Джерела значення — в порядку спадання сили.
SRC_CLIENT = "client"        # людина виправила в картці (сильніше за все)
SRC_EVIDENCE = "evidence"    # тверда очевидність у тексті (номер UA-…)
SRC_BRAIN = "brain"          # оголошення мозку в контракті наміру
SRC_PASSPORT = "passport"    # запасне: паспорт/категорія системи
SRC_DEFAULT = "default"      # дефолт збірки
SRC_NONE = "none"            # не встановлено


def _log(msg):
    try:
        import llm
        llm._log("[understanding] %s" % msg)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 1. ПОРЯДОК СИЛИ
# ---------------------------------------------------------------------------
def _evidence_domain(blob: str) -> str:
    """Тверда очевидність у тексті: формальний номер процедури `UA-…`.

    Питаємо ОДНОГО писаря очевидності (`tender_legal`), а не заводимо свій
    регекс: межа, яку пишуть два місця, вже коштувала нам двічі."""
    if not (blob or "").strip():
        return ""
    try:
        import tender_legal as _tl
        if not _tl.TENDER_ID_RE.search(blob):
            return ""
        import domains as _dm
        return _dm.domain_with_evidence("tender_id") or ""
    except Exception as e:
        _log("тверда очевидність не спрацювала: %s" % e)
        return ""


# ⛒⛒⛒ 581б. ОДИН ПИСАР КАЖЕ, ЩО В ПІДТВЕРДЖЕННІ Є ПОПРАВКОЮ.
# 🩸 13.09.2026: дорога від екрана до роботи знала РІВНО ДВА імені полів —
# `domain` і `jurisdiction` — і знала їх у чотирьох місцях (екран, сервер двічі,
# мозок, `resolve`). Зміна 581 поклала в картку клас машини й витрату пального:
# людина їх бачила, випадний список намалювався б сам, а відповідь мовчки
# викидалась би по дорозі. Показати поле «виправ мене» і з'їсти виправлення —
# гірше, ніж не показувати нічого.
# ⭐ Тепер дорога не знає ЖОДНОГО імені поля. Вона знає лише свої два керівні
# прапорці; усе інше в підтвердженні — поправка людини, і вона їде далі як є.
CONFIRM_CONTROL = ("go", "anyway")


def client_fields(confirm) -> dict:
    """Поправки людини з підтвердження картки. Керування — не поправка.

    Порожнє значення НЕ їде: список, лишений на місці, не сміє стирати те, що
    людина обрала раніше."""
    c = confirm if isinstance(confirm, dict) else {}
    return {k: v for k, v in c.items()
            if k not in CONFIRM_CONTROL and str(v if v is not None else "").strip()}


def resolve(system=None, intent=None, blob: str = "", client=None) -> dict:
    """⭐ ГОЛОВНА ФУНКЦІЯ. Складає ОСТАТОЧНИЙ контракт розуміння.

    system — паспорт системи (може бути None);
    intent — контракт наміру від мозку (сирий або нормалізований);
    blob   — текст, у якому шукаємо ТВЕРДУ ОЧЕВИДНІСТЬ (запит людини + задача);
    client — поправка людини: {"domain": ..., "jurisdiction": ...}.

    Повертає готовий контракт із НАЗВАНИМ джерелом кожного значення. Функція
    чиста і детермінована: два виклики на тих самих вхідних даних дають той
    самий результат — саме тому її можна кликати і в мозку, і у виконавці, не
    заводячи другого писаря правди."""
    try:
        import domains as _dm
    except Exception as e:
        _dm = None
        _log("довідник не імпортується: %s" % e)

    d = intent if isinstance(intent, dict) else {}
    c = client if isinstance(client, dict) else {}
    book_ok = bool(_dm and _dm.available())
    book_problem = (_dm.problem() if _dm else "довідник галузей недоступний")

    def known(did):
        return bool(_dm and _dm.is_known(did))

    def jknown(jid):
        return bool(_dm and _dm.jurisdiction_is_known(jid))

    # ── ГАЛУЗЬ ────────────────────────────────────────────────────────────────
    domain, dsrc = "", SRC_NONE
    ev = _evidence_domain(blob)
    if known(c.get("domain")):
        domain, dsrc = str(c["domain"]).strip(), SRC_CLIENT
    elif ev:
        domain, dsrc = ev, SRC_EVIDENCE
    elif known(d.get("domain")):
        domain, dsrc = str(d["domain"]).strip(), SRC_BRAIN
    else:
        passport = ""
        try:
            import registry as _rg
            passport = _rg._system_domain(system or {})
        except Exception as e:
            _log("паспорт системи не прочитано: %s" % e)
        if known(passport):
            domain, dsrc = passport, SRC_PASSPORT
        else:
            domain, dsrc = "unknown", SRC_NONE

    # ⭐ ТВЕРДА ОЧЕВИДНІСТЬ НЕ МОВЧИТЬ, КОЛИ ПРОГРАЄ ЛЮДИНІ (рішення 13 задуму):
    # виграє клієнт, але картка окремим рядком каже про суперечність.
    ev_note = ""
    if ev and domain != ev and dsrc == SRC_CLIENT:
        ev_note = ("у тексті є номер процедури — веду так, як сказали ви")

    # ── ЮРИСДИКЦІЯ ────────────────────────────────────────────────────────────
    default_jur = (getattr(config, "DEFAULT_JURISDICTION", "UA") or "UA").upper()
    if jknown(c.get("jurisdiction")):
        jur, jsrc = str(c["jurisdiction"]).strip().upper(), SRC_CLIENT
    elif jknown(d.get("jurisdiction")):
        jur, jsrc = str(d["jurisdiction"]).strip().upper(), SRC_BRAIN
    else:
        jur, jsrc = default_jur, SRC_DEFAULT

    out = {"domain": domain or "unknown", "domain_source": dsrc,
           "jurisdiction": jur, "jurisdiction_source": jsrc,
           "evidence_note": ev_note,
           # ⛒ 581б. НЕПРОЗОРИЙ МІШОК. Поправки людини, які не є полями самого
           # контракту, їдуть далі НЕЗАЙМАНИМИ — тим самим готовим контрактом,
           # що й галузь. Розпаковує їх той писар, який склав відповідний рядок
           # картки (`assumed`), а не той, хто везе.
           "choices": {k: v for k, v in c.items()
                       if k not in ("domain", "jurisdiction")},
           "book_ok": book_ok, "book_problem": "" if book_ok else book_problem}
    out["conflict"] = conflict_of(system, out)
    return out


# ⭐⭐⭐ 11.08.2026 (зміна 153, знайдено ЖИВИМ ПРОГОНОМ за $0.07).
# КОНТРАКТ СКЛАДАЄТЬСЯ ОДИН РАЗ І ЇДЕ ГОТОВИМ — ЙОГО НЕ ПЕРЕСКЛАДАЮТЬ.
# Дефект, який це закриває: ворота (`agent`) складали контракт ІЗ поправкою
# людини, а виконавець (`executor`) складав його ЗАНОВО — без неї. Порядок сили
# один, але входи різні, тому результат розходився МОВЧКИ: людина виправляла
# галузь у картці, а якщо в тексті стояв номер `UA-…`, тверда очевидність била
# її поправку, і робота йшла ІНШОЮ галуззю. Картка при цьому показувала людині,
# що її почули. Це «платформа не може збрехати» навиворіт.
# Ліки: той, хто вже має готовий контракт, ПЕРЕДАЄ його далі; той, хто отримав, —
# БЕРЕ, а не перескладає. Хто нічого не отримав (телеграм, розклад, ланцюг) —
# складає сам, як і раніше.
def is_contract(c) -> bool:
    """Чи це справді готовий контракт розуміння, а не випадковий словник.
    Виконавець бере ЧУЖЕ рішення лише тоді, коли впізнав його як своє."""
    return (isinstance(c, dict)
            and isinstance(c.get("domain"), str) and bool(c.get("domain"))
            and isinstance(c.get("jurisdiction"), str)
            and c.get("domain_source") in (SRC_CLIENT, SRC_EVIDENCE, SRC_BRAIN,
                                           SRC_PASSPORT, SRC_DEFAULT, SRC_NONE))


def fingerprint(contract) -> str:
    """Відбиток розуміння. Картка мовчить, доки відбиток не змінився."""
    c = contract if isinstance(contract, dict) else {}
    # ⛒ 581б. Виправлений людиною рядок — це ІНШЕ розуміння. Інакше картка
    # мовчала б про зміну, яку сама ж і прийняла.
    ch = c.get("choices") if isinstance(c.get("choices"), dict) else {}
    tail = ";".join("%s=%s" % (k, ch[k]) for k in sorted(ch))
    return "%s|%s|%s" % (c.get("domain") or "unknown",
                         c.get("jurisdiction") or "", tail)


# ---------------------------------------------------------------------------
# 2. СУПЕРЕЧНІСТЬ ІЗ ПАСПОРТОМ СИСТЕМИ — ОДИН ПИСАР
# ---------------------------------------------------------------------------
def declared_domain(system) -> str:
    """Галузь, ЗАПИСАНА В ПАСПОРТІ СИСТЕМИ РУКОЮ. Не категорія, не здогадка.

    Порожньо — значить система себе галуззю не обмежує, і суперечності бути
    не може. Мовчання паспорта ніколи не зупиняє роботу."""
    did = str(((system or {}) if isinstance(system, dict) else {}).get("domain") or "").strip()
    try:
        import domains as _dm
        return did if _dm.is_known(did) else ""
    except Exception:
        return ""


def alternatives(domain_id, exclude_id="") -> list:
    """Які НАШІ системи оголосили саме цю галузь. Платформа сама називає вихід,
    а не пропонує людині вгадувати. Порожньо — так і кажемо."""
    out = []
    try:
        import registry as _rg
        for s in _rg.load_systems():
            if s.get("id") == exclude_id:
                continue
            if declared_domain(s) == str(domain_id or "").strip():
                out.append({"id": s.get("id"), "name": s.get("name") or s.get("id")})
    except Exception as e:
        _log("перелік альтернатив не склався: %s" % e)
    return out


def conflict_of(system, contract):
    """Чи оголошена галузь суперечить ЯВНІЙ декларації паспорта системи.

    Повертає None або опис суперечності з двома виходами. ОДИН писар: і коли
    галузь назвав мозок, і коли її виправив клієнт (п.2 і п.3 частини 4 задуму
    — це той самий шлях, а не два)."""
    dec = declared_domain(system)
    if not dec:
        return None
    did = str((contract or {}).get("domain") or "").strip()
    if not did or did in ("", "unknown") or did == dec:
        return None
    try:
        import domains as _dm
        sys_name = (system or {}).get("name") or (system or {}).get("id") or "система"
        return {"system_id": (system or {}).get("id") or "",
                "system_name": sys_name,
                "system_domain": dec,
                "system_domain_name": _dm.name_of(dec),
                "case_domain": did,
                "case_domain_name": _dm.name_of(did),
                "alternatives": alternatives(did, exclude_id=(system or {}).get("id") or "")}
    except Exception as e:
        _log("суперечність не склалась: %s" % e)
        return None


# ---------------------------------------------------------------------------
# 2б. СУПЕРЕЧНІСТЬ ОЗНАК ВИРІШУЄ КОД (зміна 253, 28.08.2026)
# ---------------------------------------------------------------------------
# 🩸🩸🩸 ЗРИВ 28.08.2026 НА ЛЮДЯХ. Андрій замовив «фінансову модель з
# розрахунками в Excel». Мозок оголосив: «Розрахунок: потрібен» І «Результат:
# звіт» — дві ознаки, які суперечать одна одній. Ворота живих формул вмикались
# від НАЗВИ результату, тому вимкнули самі себе, і клієнт отримав таблицю з
# мертвими числами.
#
# ⛒ ЗАКОН: ЗАМОВЛЕНО РОЗРАХУНОК — ЧИСЛА МУСЯТЬ БУТИ ЖИВИМИ. При суперечності
# беремо СУВОРІШЕ, і робить це КОД — не модель (вона й склала суперечність) і
# не людина (перепитувати про власну плутанину — не її робота: слово Андрія
# 28.08 «а для чого тоді мозок»).
#
# ⛔ МЕЖА СВІДОМА. Коротка відповідь у чат і документ (договір, лист, стаття)
# фінмоделлю не стають: інакше «порахуй 15% від 200 000» вимагало б книги Excel,
# а ворота, що дають хибну тривогу, вимикають.
_CALC_UPGRADES = ("report", "estimate_sheet")


def settle_output(intent) -> str:
    """ОДИН ПИСАР РІШЕННЯ ПРО ТИП РЕЗУЛЬТАТУ. Чиста функція: питають і мозок
    (для картки, яку бачить людина), і виконавець (для воріт формул) — щоб про
    один і той самий намір не існувало двох правд."""
    d = intent if isinstance(intent, dict) else {}
    out = d.get("output") or "chat_answer"
    if (d.get("computation") or "") == "required" and out in _CALC_UPGRADES:
        return "financial_model"
    return out


def output_upgraded(intent) -> bool:
    """Чи саме платформа посилила тип результату — щоб сказати це вголос."""
    d = intent if isinstance(intent, dict) else {}
    return settle_output(d) != (d.get("output") or "chat_answer")


# ---------------------------------------------------------------------------
# 3. КАРТКА — ТЕКСТ СКЛАДАЄ ПЛАТФОРМА
# ---------------------------------------------------------------------------
# ⛒ НАЗВИ ТИПІВ РЕЗУЛЬТАТУ ЖИВУТЬ У СЛОВНИКУ (зміна 255): картку читає людина,
# і читає вона СВОЄЮ мовою.
def _output_name(out, lang=None) -> str:
    try:
        return phrases.t("out." + str(out or "chat_answer"), lang)
    except phrases.PhraseError:
        return phrases.t("out.chat_answer", lang)


# ⭐⭐⭐ 17.08.2026, зміна 194. КАРТКА РОЗУМІННЯ — ЦЕ ОСТАННЄ, ЩО ЛЮДИНА БАЧИТЬ
# ДО ВИТРАТ. Тому в ній має стояти не лише «як я зрозумів задачу», а й те, що
# робить саму задачу безглуздою: закупівля, на яку вже не подаси. 🩸 17.08
# платформа зібрала повний пакет на закупівлю зі строком подання 15.08.
# ⚠ Тут НЕМАЄ знання про тендери — тут є питання «чи має ця система що сказати
# людині про саму роботу». Сьогодні відповідає лише тендерайтер; двері відкриті.
def _job_warnings(system, intent) -> list:
    """Попередження ПРО САМУ РОБОТУ для картки розуміння. Мовчання — норма."""
    out = []
    try:
        import tender_pack
        if (system or {}).get("id") != tender_pack.SYSTEM_ID:
            return out
        tid = tender_pack.tender_id_in((intent or {}).get("task") or "")
        if not tid:
            return out
        note = tender_pack.admissibility_note(tender_pack.tender_state(tid))
        if note:
            out.append(note.lstrip("⛔⚠ ").strip())
    except Exception:
        pass                      # межа знання не сміє валити картку розуміння
    return out


# ⛒⛒⛒ 581. ДРУГІ ДВЕРІ КАРТКИ: НЕ «ЯК Я ЗРОЗУМІВ ПИТАННЯ», А «З ЧИМ БУДУ
# РАХУВАТИ». 🩸 12.09.2026 замовник побачив свій клас машини й витрату пального
# уперше в готовому документі — тобто після грошей. Клас тоді називав АГЕНТ
# усередині прогону, і той самий агент писав документ: єдиний, хто знав
# рішення, був той, хто його й вигадав, тож ані показати заздалегідь, ані
# перевірити його платформа не могла.
# ⭐ Тут клас визначає КОД за таблицею методики — детерміновано, офлайн, за $0 —
# і людина бачить його ДО запуску. Жодного переліку слів у коді: «Газель» і
# «фура» живуть у методиці системи, а не тут. Немає ні назви машини, ні
# тоннажу — писар МОВЧИТЬ: припустити мовчки означало б зробити рівно те, що
# ми лікуємо.
def _job_assumptions(system, intent, contract=None) -> list:
    """Рядки картки про те, З ЧИМ платформа рахуватиме. Мовчання — норма.

    ⛒ 581б: рядки складає той самий писар, який приймає їх поправку, і бере він
    її з ГОТОВОГО контракту — тому екран показує саме те, з чим піде робота."""
    try:
        import assumed
        import registry
        return assumed.rows_for(registry.system_root(system),
                                (intent or {}).get("task") or "", contract)
    except Exception:
        return []                 # межа знання не сміє валити картку розуміння


def card(system, contract, intent=None, lang=None) -> dict:
    """Машинна картка розуміння: рядки, списки вибору і ГОТОВИЙ ТЕКСТ.

    ⭐ ЖОДНОГО РЕЧЕННЯ ВІД МОДЕЛІ. Назви беруться з довідника, назва системи —
    з реєстру, тип результату — з контракту наміру. Це і є те, чим картка
    відрізняється від «хай мозок пояснить, як він зрозумів»."""
    try:
        import domains as _dm
    except Exception:
        _dm = None
    c = contract if isinstance(contract, dict) else {}
    d = intent if isinstance(intent, dict) else {}
    dname = (_dm.name_of(c.get("domain"), "не встановлено") if _dm else "не встановлено")
    jname = (_dm.jurisdiction_name(c.get("jurisdiction"), c.get("jurisdiction") or "")
             if _dm else (c.get("jurisdiction") or ""))

    rows = [{"key": "system", "label": phrases.t("card.system", lang),
             "value": (system or {}).get("name") or (system or {}).get("id") or "—"},
            {"key": "domain", "label": phrases.t("card.domain", lang), "value": dname,
             "id": c.get("domain") or "unknown",
             "choices": (_dm.choices() if _dm else [])},
            {"key": "jurisdiction", "label": phrases.t("card.jurisdiction", lang), "value": jname,
             "id": c.get("jurisdiction") or "",
             "choices": (_dm.jurisdiction_choices() if _dm else [])},
            {"key": "output", "label": phrases.t("card.output", lang),
             # ⛒ КАРТКА ПОКАЗУЄ ВИРІШЕНЕ, А НЕ ОГОЛОШЕНЕ (зміна 253). Мозок міг
             # оголосити «звіт» при замовленому розрахунку — людина мусить бачити
             # те, що платформа СПРАВДІ робитиме, інакше про один намір існує дві
             # правди. Писар той самий, якого питає виконавець.
             "value": _output_name(settle_output(d), lang)}]
    # ⛒ 581. Одразу під «що робимо» — «чим рахуємо»: клас машини й витрата
    # пального стоять на екрані ДО того, як людина натисне «запускай».
    rows.extend(_job_assumptions(system, d, c))
    if (d.get("fresh_data") or "") == "required":
        rows.append({"key": "fresh_data", "label": phrases.t("card.fresh", lang),
                     "value": phrases.t("card.fresh_v", lang)})
    if (d.get("computation") or "") == "required":
        rows.append({"key": "computation", "label": phrases.t("card.calc", lang),
                     "value": phrases.t("card.calc_v", lang)})
    if (d.get("route") or "") == "required":
        rows.append({"key": "route", "label": phrases.t("card.route", lang),
                     "value": phrases.t("card.route_v", lang)})

    notes = list(_job_warnings(system, d))
    if not c.get("book_ok"):
        notes.append("довідник галузей недоступний — доменні запобіжники вимкнено")
    if c.get("evidence_note"):
        notes.append(c["evidence_note"])
    if (c.get("domain") or "unknown") == "unknown":
        notes.append("галузь не встановлено — доменні запобіжники не вмикаються")

    width = max(len(r["label"]) for r in rows) + 1
    lines = [phrases.t("card.title", lang), ""]
    for r in rows:
        lines.append("%s%s %s" % (r["label"] + ":", " " * (width - len(r["label"])), r["value"]))
    for n in notes:
        lines.append("")
        lines.append("⚠ " + n)
    return {"rows": rows, "notes": notes, "text": "\n".join(lines),
            "fingerprint": fingerprint(c)}


def conflict_text(conflict) -> str:
    """Текст зупинки на суперечності. Теж складає ПЛАТФОРМА, простими словами,
    і НАЗИВАЄ обидва виходи. Мовчазна робота «не тим юристом» — не варіант."""
    k = conflict if isinstance(conflict, dict) else {}
    alt = k.get("alternatives") or []
    t = ("**Зупинився до роботи: справа не тієї галузі**\n\n"
         "Система «%s» працює з галуззю «%s», а ця справа — «%s».\n\n"
         % (k.get("system_name") or "—", k.get("system_domain_name") or "—",
            k.get("case_domain_name") or "—"))
    if alt:
        t += ("Цю галузь у нас веде: %s.\n\n"
              % ", ".join("«%s»" % a.get("name") for a in alt))
    else:
        t += "Окремої системи саме для цієї галузі в реєстрі немає.\n\n"
    t += "Що робимо: взяти іншу систему чи все одно запустити цю?"
    return t


# ---------------------------------------------------------------------------
# 4. СЛІД — ЗАВЖДИ
# ---------------------------------------------------------------------------
def trace(event: str, system=None, contract=None, actor="", extra=None) -> bool:
    """Рядок у `runs/_audit.jsonl`. Пишеться і коли питали людину, і коли
    пройшли мовчки, і коли людину спитати нікому (автоматизація, розклад).

    ⭐ Правило 7 картки: слід лишається ЗАВЖДИ. Інакше постфактум нічим довести,
    що платформа взагалі питала — а це «тихий успіх» із переліку смертельних."""
    try:
        import audit
        c = contract if isinstance(contract, dict) else {}
        rec = {"kind": "understanding", "event": str(event or ""),
               "system_id": (system or {}).get("id") if isinstance(system, dict) else "",
               "domain": c.get("domain"), "domain_source": c.get("domain_source"),
               "jurisdiction": c.get("jurisdiction"),
               "jurisdiction_source": c.get("jurisdiction_source"),
               "book_ok": bool(c.get("book_ok")),
               "conflict": bool(c.get("conflict")),
               # ⛒ Актора НЕ серіалізуємо тут: саме `str(actor)` і затягував у
               # журнал `salt` та `pwd_hash` (зміна 257). Зводить його до імені
               # й номера ОДИН писар — сам журнал.
               "actor": actor}
        if isinstance(extra, dict):
            rec.update(extra)
        return audit.log_event(rec)
    except Exception as e:
        _log("слід не записався: %s" % e)
        return False
