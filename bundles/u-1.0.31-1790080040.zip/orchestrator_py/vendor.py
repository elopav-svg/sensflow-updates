# -*- coding: utf-8 -*-
"""vendor.py — ОДИН ПИСАР «ХТО РОЗРОБНИК» (зміна 616, 20.09.2026).

⛒ НАВІЩО ОКРЕМИЙ ПИСАР. Магазину треба знати, КОМУ надіслати замовлення.
Підтримці — кому скаржитись. Ліцензії — хто продавець. Доти цієї відповіді не
було НІДЕ: адреса розробника не живе ні в коді, ні в налаштуваннях. Вписати її
в екран магазину означало б завести писаря, якого через місяць продублює
екран підтримки, — і одна з двох адрес колись застаріє мовчки.

⛒ ЦЕ ДАНІ ПРОДАВЦЯ, А НЕ КЛІЄНТА. Файл `config/vendor.json` ЇДЕ ЗІ ЗБІРКОЮ і
оновлюється оновленням. Клієнт його не редагує: підмінити адресу розробника в
себе на машині означало б надсилати замовлення не туди.

⛒ НЕМАЄ ФАЙЛА — КАЖЕМО СЛОВАМИ, ЧОГО САМЕ БРАКУЄ. Порожній рядок замість
адреси — це лист у нікуди з виглядом успіху.
"""
import json

import config

VENDOR_JSON = config.PLATFORM_ROOT / "config" / "vendor.json"

# Закритий перелік: поле, якого тут немає, у відповідь не їде.
FIELDS = ("name", "email", "phone", "site", "note")
REQUIRED = ("name", "email")
FIELD_NAMES = {
    "name": "назва виконавця",
    "email": "електронна пошта",
    "phone": "телефон",
    "site": "сайт",
    "note": "примітка",
}


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def info() -> dict:
    """Хто розробник — з диска. Немає файла — усі поля порожні, і це видно."""
    try:
        raw = json.loads(VENDOR_JSON.read_text(encoding="utf-8-sig"))
    except Exception:
        raw = {}
    if not isinstance(raw, dict):
        raw = {}
    return {k: _s(raw.get(k)) for k in FIELDS}


def missing() -> list:
    """Яких обовʼязкових полів бракує — НАЗВАМИ, а не «щось не так»."""
    got = info()
    return [FIELD_NAMES[k] for k in REQUIRED if not got.get(k)]


def known() -> bool:
    return not missing()


def said() -> str:
    """Як розробник звучить у документі й у листі — одним писарем на всі місця."""
    g = info()
    out = g["name"]
    tail = [x for x in (g["email"], g["phone"], g["site"]) if x]
    if tail:
        out = (out + ", " if out else "") + ", ".join(tail)
    return out
