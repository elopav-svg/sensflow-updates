# -*- coding: utf-8 -*-
"""mail_owner.py — ЧИЙ ЦЕ ЛИСТ (зміна 618, 20.09.2026).

⭐⭐⭐ КОРІНЬ. Вхідний лист мав відповідь на питання «У ЯКУ УГОДУ» (`deal_mail`,
крок C2) і не мав ЖОДНОЇ на питання «ЧИЙ ВІН». Поки скринька була одна й
господар один, питання не існувало. Щойн�� в компанії пʼять менеджерів і одна
корпоративна скринька — це найдорожче питання в усій пошті: лист, який ліг не
тому, лежить не прочитаним доти, доки клієнт не подзвонить сам.

🩸 КЛАС: **ВХІДНИЙ СИГНАЛ БЕЗ АДРЕСАТА.** Той самий клас, який платформа
лікувала в `entity_scope` («чий це клієнт») і в 617 («чий це конектор»).

⛒ ПОРЯДОК — ВІД ПЕВНОГО ДО ЗДОГАДУ, І ВІН ОГОЛОШЕНИЙ, А НЕ СХОВАНИЙ У КОДІ:

  1. `HOW_BOX`     — лист прочитано з ОСОБИСТОЇ скриньки. Тут питання не
                     виникає взагалі: чужої скриньки не бачить ніхто, і жодна
                     мітка цього не перебиває.
  2. `HOW_ADDRESS` — «кому» називає працівника: його власна адреса або
                     плюс-адресація корпоративної скриньки
                     (`sales+ivan@company.com`). Безкоштовно, точно, без моделі.
  3. `HOW_DEAL`    — мітка платформи в темі (`[SF-D0014]`) → той, хто ВЕДЕ цю
                     угоду. Це наша власна мітка на ЦЬОМУ листуванні.
  4. `HOW_PARTY`   — відповідальний контрагента. Надійно рівно настільки,
                     наскільки заповнені картки, — тому він останній.

⛒ ЧОМУ АДРЕСА СТОЇТЬ ВИЩЕ ЗА ВІДПОВІДАЛЬНОГО. План 20.09.2026 називав порядок
«мітка → контрагент → плюс-адресація». Кажу прямо: сам принцип у плані —
«від ПЕВНОГО до здогаду», і плюс-адресацію той самий план називає словом
«точно», а звʼязок за контрагентом — «надійно рівно настільки, наскільки
заповнені контакти». Отже принцип і перелік у плані суперечили одне одному;
я лишив ПРИНЦИП і переставив два рядки. Адреса — це явна дія того, хто писав;
відповідальний — стан довідника, який у живій базі заповнений у половини
карток.

⛒ ДВА ПЕВНІ ДЖЕРЕЛА, ЯКІ НЕ СХОДЯТЬСЯ, — ЦЕ ВІДКРИТЕ ПИТАННЯ, А НЕ ВИБІР.
Лист адресовано Іванові, а угоду веде Петро — платформа НЕ бере жодного з
двох. Вона називає обох і чекає одного кліку. Тихо обраний «перший у порядку»
тут коштував би чужим клієнтом.
⛒ Слабше джерело суперечки не створює: воно відповідає лише тоді, коли сильні
мовчать. У цьому й сенс порядку.

⛒ ЛИСТ БЕЗ ВЛАСНИКА НЕ ЗНИКАЄ І НЕ ПРИПИСУЄТЬСЯ МОВЧКИ. Він стоїть у черзі, і
видно, що він нічий. Один клік людини закриває питання і НАВЧАЄ звʼязок на
майбутнє (ставить відповідального контрагента).

⛒ ОДНООСІБНА ЗБІРКА НЕ ПОМІЧАЄ НІЧОГО. Питання «чий» виникає тоді й лише тоді,
коли платформа взагалі розрізняє людей. Відповідає той самий писар, що й у
617 (`connector_owner.multi_user`), — другого ми не заводимо.

⛒ ЗДОГАДУ МОДЕЛІ ТУТ НЕМАЄ. Місце для нього оголошене (`HOW_GUESS`), але
порожнє: здогад мусить приходити ПРОПОЗИЦІЄЮ З НАЗВАНОЮ ПЕВНІСТЮ, а не тихим
призначенням, і коштувати грошей за прогін там, де три безкоштовні джерела
вже відповіли. Порожнє оголошене місце — щоб другий писар здогаду не завівся
деінде (той самий прийом, що `headers` у `deal_mail.address_of`).

⛒ ЖОДНОГО НОВОГО РЕЄСТРУ ПРАВДИ. Хто веде угоду й контрагента — питаємо
`entity_scope`; хто така ця адреса — оргструктуру й обліковки; чи розрізняє
платформа людей — `connector_owner`. Свого списку «чий лист» на диску немає.

Лише stdlib + модулі платформи. Нічого не надсилає назовні, нічого не пише.
"""
from email.utils import getaddresses

# ── ДЖЕРЕЛА ВІДПОВІДІ ────────────────────────────────────────────────────────
HOW_BOX = "box"          # особиста скринька — питання не виникає
HOW_ADDRESS = "address"  # «кому» називає працівника (своя адреса або плюс-тег)
HOW_DEAL = "deal"        # мітка угоди в темі → той, хто веде угоду
HOW_PARTY = "party"      # відповідальний контрагента
HOW_GUESS = "guess"      # ⛒ ОГОЛОШЕНЕ МІСЦЕ ЗДОГАДУ МОДЕЛІ. Порожнє.

# Стани, у яких власника немає.
HOW_SOLO = "solo"        # платформа одноосібна — питання не виникає
HOW_NONE = "none"        # нічий: стоїть у черзі, і видно, що нічий
HOW_CLASH = "clash"      # два певні джерела не сходяться — вирішує людина

# ⛒ ПОРЯДОК ОГОЛОШЕНО ЗАКРИТИМ ПЕРЕЛІКОМ. Нове джерело = новий рядок ТУТ,
# і проба судить саме цей перелік, а не наявність функцій.
ORDER = (HOW_BOX, HOW_ADDRESS, HOW_DEAL, HOW_PARTY)

# ⛒ ПЕВНІ ДЖЕРЕЛА. Розбіжність МІЖ НИМИ — відкрите питання. Слабше джерело
# (`HOW_PARTY`) суперечки не створює: воно говорить, лише коли ці мовчать.
CERTAIN = (HOW_ADDRESS, HOW_DEAL)

HOW_NAMES = {
    HOW_BOX: "особиста скринька працівника",
    HOW_ADDRESS: "лист адресовано йому особисто",
    HOW_DEAL: "мітка угоди в темі листа",
    HOW_PARTY: "він веде цього контрагента",
    HOW_GUESS: "здогад моделі",
    HOW_SOLO: "платформа одного господаря",
    HOW_NONE: "нічий",
    HOW_CLASH: "два джерела не сходяться",
}


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ── ХТО ХОВАЄТЬСЯ ЗА АДРЕСОЮ ────────────────────────────────────────────────
def addresses(raw) -> list:
    """Усі адреси з поля «кому»/«копія» — і з голого рядка, і з «Імʼя <пошта>».

    ⛒ Один читач на обидва поля: два розійшлися б на першому ж записі з
    комою всередині лапок."""
    text = _s(raw)
    if not text:
        return []
    out = []
    for _name, addr in getaddresses([text]):
        a = _s(addr).lower()
        if a and "@" in a:
            out.append(a)
    return out


def _split(addr: str):
    """«sales+ivan@firma.ua» → («sales», «ivan», «firma.ua»)."""
    local, _, domain = _s(addr).lower().partition("@")
    base, plus, tag = local.partition("+")
    return base, (tag if plus else ""), domain


def _staff() -> list:
    """Чинні працівники. ⛒ Звільнений власником листа не стає: пошта лягала б
    тому, хто вже не працює, і чекала б відповіді вічно."""
    try:
        import taskdesk_people as people
        return [e for e in (people.employees() or []) if e.get("active")]
    except Exception:
        return []


def _login_of(emp_id: str) -> str:
    try:
        import taskdesk_identity as tdid
        return _s((tdid.account_of_employee(_s(emp_id)) or {}).get("login")).lower()
    except Exception:
        return ""


def employees_at(raw) -> list:
    """Кого НАЗИВАЄ це поле адрес. Порожньо — нікого; двоє — теж відповідь.

    Збіг рахується трьома способами, і всі три — з наявних даних:
      • повна адреса дорівнює адресі працівника в оргструктурі;
      • плюс-тег дорівнює імені скриньки працівника (`sales+ivan` ↔ `ivan@…`);
      • плюс-тег дорівнює його логіну в платформі.
    ⛔ Здогадів за схожістю ПІБ тут немає: «Іванов» і «Іваненко» коштували б
    чужим клієнтом, а помилку видно вже після відповіді."""
    found, seen = [], set()
    staff = _staff()
    if not staff:
        return []
    by_mail, by_local, by_login = {}, {}, {}
    for e in staff:
        eid = _s(e.get("id"))
        mail = _s(e.get("email")).lower()
        if mail:
            by_mail.setdefault(mail, eid)
            by_local.setdefault(mail.split("@")[0], eid)
        lg = _login_of(eid)
        if lg:
            by_login.setdefault(lg, eid)
    for addr in addresses(raw):
        base, tag, _dom = _split(addr)
        who = by_mail.get(addr) or ""
        if not who and tag:
            who = by_local.get(tag) or by_login.get(tag) or ""
        if not who and not tag:
            # ⛒ Адреса без плюс-тега, якої немає серед адрес працівників, може
            # збігатись із їхнім логіном лише випадково — тому логін тут не
            # питаємо. Інакше скринька `info@` в клієнта з логіном «info»
            # зробила б власником його.
            who = ""
        if who and who not in seen:
            seen.add(who)
            found.append(who)
    return found


def employee_at(raw) -> str:
    """Рівно один названий працівник або «». ⛒ Двоє — це НЕ вибір першого:
    джерело мовчить, і відповідає наступне за порядком."""
    who = employees_at(raw)
    return who[0] if len(who) == 1 else ""


# ── ХТО ВЕДЕ УГОДУ Й КОНТРАГЕНТА (питаємо одного суддю) ─────────────────────
def _holders():
    try:
        import entity_scope
        return entity_scope.owners()
    except Exception:
        return None


def _deal_owner(subject, own) -> str:
    """Мітка угоди в темі → той, хто веде цю угоду."""
    try:
        import deal_mail
        import deals
    except Exception:
        return ""
    tok = _s(deal_mail.read_token(subject))
    if not tok or not deals.exists(tok):
        return ""
    return _s(own.deal_holder(tok)) if own is not None else ""


def _party_owner(party, own) -> str:
    pid = _s(party)
    if not pid or own is None:
        return ""
    who = own.holders("party", pid)
    # ⛒ Двоє ведуть того самого контрагента (він веде картку, а колега — свою
    # угоду з ним) — це не відповідь, а розгалуження. Мовчимо.
    return sorted(who)[0] if len(who) == 1 else ""


def name_of(emp_id: str) -> str:
    """Людське імʼя — щоб рядок черги називав людину, а не номер."""
    emp = _s(emp_id)
    if not emp:
        return ""
    try:
        import taskdesk_people as people
        return _s((people.employee(emp) or {}).get("full_name"))
    except Exception:
        return ""


def _multi_user() -> bool:
    """Чи платформа взагалі розрізняє людей. ⛒ ТОЙ САМИЙ ПИСАР, що в 617."""
    try:
        import connector_owner
        return bool(connector_owner.multi_user())
    except Exception:
        return True


# ── ЄДИНА ВІДПОВІДЬ «ЧИЙ ЦЕ ЛИСТ» ───────────────────────────────────────────
def resolve(to: str = "", cc: str = "", subject: str = "", party: str = "",
            deal: str = "", box_owner: str = "", connector: str = "") -> dict:
    """→ {owner, owner_name, how, why, candidates, ask}.

    `how` — ІМʼЯ джерела (HOW_*), `why` — те саме людськими словами.
    `ask` — чи мусить черга спитати людину."""
    if not _multi_user():
        # ⛒ ОДНООСІБНА ЗБІРКА. Лист тут не буває «нічиїм»: господар один, і
        # питати його «чий це лист» означало б вигадати йому роботу з нічого.
        return {"owner": "", "owner_name": "", "how": HOW_SOLO,
                "why": "Платформою користується один господар — питання «чий "
                       "це лист» тут не виникає.",
                "candidates": [], "ask": False}

    # 1. ОСОБИСТА СКРИНЬКА. Питання не виникає: чужої скриньки не бачить ніхто.
    box = _s(box_owner)
    if not box and _s(connector):
        try:
            import connector_owner
            if connector_owner.personal(connector):
                box = _s(connector_owner.owner_of(connector)[0])
        except Exception:
            box = ""
    if box:
        return {"owner": box, "owner_name": name_of(box), "how": HOW_BOX,
                "why": "Лист прочитано з особистої скриньки цього працівника.",
                "candidates": [], "ask": False}

    own = _holders()

    # 2. АДРЕСА. «Кому» — і лише якщо там нікого, дивимось у копію.
    by_addr = employee_at(to) or employee_at(cc)

    # 3. МІТКА УГОДИ.
    by_deal = _deal_owner(subject, own)

    # ⛒ ДВА ПЕВНІ ДЖЕРЕЛА НЕ СХОДЯТЬСЯ — ПИТАННЯ ВІДКРИТЕ.
    if by_addr and by_deal and by_addr != by_deal:
        pair = sorted({by_addr, by_deal})
        return {"owner": "", "owner_name": "", "how": HOW_CLASH,
                "why": "Лист адресовано «%s», а угоду в темі веде «%s». Сама я "
                       "між ними не вибираю — скажіть, чий він."
                       % (name_of(by_addr) or by_addr, name_of(by_deal) or by_deal),
                "candidates": pair, "ask": True}

    if by_addr:
        return {"owner": by_addr, "owner_name": name_of(by_addr),
                "how": HOW_ADDRESS,
                "why": "Лист адресовано особисто йому (%s)."
                       % HOW_NAMES[HOW_ADDRESS],
                "candidates": [], "ask": False}
    if by_deal:
        return {"owner": by_deal, "owner_name": name_of(by_deal), "how": HOW_DEAL,
                "why": "У темі стоїть мітка угоди, яку веде цей працівник.",
                "candidates": [], "ask": False}

    # 4. ВІДПОВІДАЛЬНИЙ КОНТРАГЕНТА — останній, і саме тому найслабший.
    by_party = _party_owner(party, own)
    if by_party:
        return {"owner": by_party, "owner_name": name_of(by_party),
                "how": HOW_PARTY,
                "why": "Цього контрагента веде він.",
                "candidates": [], "ask": False}

    # ⛒ НІЧИЙ. Не зникає і не приписується мовчки.
    return {"owner": "", "owner_name": "", "how": HOW_NONE,
            "why": "Ні адреса листа, ні мітка угоди, ні картка контрагента не "
                   "кажуть, чий він. Оберіть власника — і наступний лист від "
                   "цього контрагента вже не спитає.",
            "candidates": [], "ask": True}
