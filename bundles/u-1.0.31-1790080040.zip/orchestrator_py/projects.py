"""
projects.py — фіча «Проєкти»: робочі напрями користувача.

Проєкт = жива тека всередині оркестратора, що тримає три речі разом:
  1) згруповані чати (thread_ids),
  2) спільний контекст (текст, який мозок тримає в голові в кожному чаті проєкту),
  3) зведення готових документів (артефакти з результатів цих чатів — без копіювання).

Кожен проєкт — JSON-файл у orchestrator_py/projects/<id>.json:
  {id, name, context, thread_ids:[...], created_at, updated_at}

Членство — двостороннє для швидкого гарячого шляху чату:
  - проєкт тримає thread_ids (авторитет для списків/документів);
  - тред стампиться project_id (threads.set_project) для O(1) пошуку контексту в /api/chat.
"""

import json
import uuid
from datetime import datetime
from pathlib import Path

import config
import threads

# ⭐⭐⭐ 01.09.2026. ТЕКА ПРОЄКТІВ ІДЕ ЗА ПЕРЕМИКАЧЕМ СТАНУ.
# У бою `STATE_DIR == ENGINE_DIR`, тож шлях не змінюється ні на байт. Але
# під чеком стан відведено вбік — і проєкти більше не падають у бойову теку.
PROJECTS_DIR = config.STATE_DIR / "projects"
PROJECTS_DIR.mkdir(parents=True, exist_ok=True)


def _path(pid: str) -> Path:
    safe = "".join(ch for ch in (pid or "") if ch.isalnum() or ch in "-_")
    return PROJECTS_DIR / f"{safe}.json"


def _save(rec: dict):
    rec["updated_at"] = datetime.now().isoformat()
    _path(rec["id"]).write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")


def get(pid: str):
    p = _path(pid)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def create(name: str = None, owner_id: str = "") -> dict:
    """⭐ ВЛАСНИК (01.09.2026). Проєкт заводить конкретна людина, і саме з неї
    ОБЧИСЛЮЄТЬСЯ, кому цей проєкт видно в Task Desk: власникові, всім, хто над
    ним у дереві компанії, і всім, кому в проєкті поставлено задачу. Галочки
    «кому видно» немає свідомо — її забувають зняти, а дерево не забуває.

    Порожній `owner_id` дозволений: так заводяться проєкти з консолі, де людини
    Task Desk може не бути зовсім. Такий проєкт нічий — і поводиться, як досі."""
    pid = "prj-" + uuid.uuid4().hex[:8]
    now = datetime.now().isoformat()
    rec = {"id": pid, "name": (name or "Новий проєкт").strip()[:80],
           "context": "", "thread_ids": [], "owner_id": (owner_id or "").strip(),
           "created_at": now, "updated_at": now}
    _save(rec)
    return rec


def update(pid: str, name: str = None, context: str = None) -> dict:
    rec = get(pid)
    if rec is None:
        return None
    if name is not None:
        rec["name"] = name.strip()[:80] or rec.get("name") or "Новий проєкт"
    if context is not None:
        rec["context"] = context
    _save(rec)
    return rec


def delete(pid: str) -> bool:
    rec = get(pid)
    if rec is None:
        return False
    # Прибираємо мітку project_id з усіх членів — чати лишаються, лише виходять із проєкту.
    for tid in rec.get("thread_ids", []):
        try:
            threads.set_project(tid, None)
        except Exception:
            pass
    p = _path(pid)
    try:
        p.unlink()
        return True
    except Exception:
        return False


def add_thread(pid: str, tid: str) -> dict:
    """Кладе чат у проєкт. Чат може належати лише одному проєкту — спершу
    прибираємо його з попереднього (за стампом project_id на треді)."""
    rec = get(pid)
    if rec is None or not tid:
        return rec
    prev = threads.project_of(tid)
    if prev and prev != pid:
        remove_thread(prev, tid)
    if tid not in rec["thread_ids"]:
        rec["thread_ids"].append(tid)
        _save(rec)
    threads.set_project(tid, pid)
    return rec


def remove_thread(pid: str, tid: str) -> dict:
    rec = get(pid)
    if rec is None:
        return None
    if tid in rec.get("thread_ids", []):
        rec["thread_ids"].remove(tid)
        _save(rec)
    if threads.project_of(tid) == pid:
        threads.set_project(tid, None)
    return rec


def context_for_thread(tid: str) -> str:
    """Спільний контекст проєкту, якому належить цей чат (для інжекту в мозок).
    Порожньо, якщо чат поза проєктом."""
    pid = threads.project_of(tid)
    if not pid:
        return ""
    rec = get(pid)
    if not rec:
        return ""
    return (rec.get("context") or "").strip()


def _first_heading(md: str) -> str:
    import re
    for line in (md or "").splitlines():
        m = re.match(r"^\s{0,3}#{1,3}\s+(.+?)\s*#*\s*$", line)
        if m:
            return m.group(1).strip()
    return ""


def documents(pid: str) -> list:
    """Зведення готових документів проєкту: проходимо чати-члени, збираємо
    результати (один запис на зданий результат із його файлами). Нічого фізично
    не переносимо — це вітрина над тим, що вже лежить у чатах."""
    rec = get(pid)
    if rec is None:
        return []
    out = []
    for tid in rec.get("thread_ids", []):
        thr = threads.get(tid)
        if not thr:
            continue
        ttitle = thr.get("title") or "Без назви"
        for m in thr.get("messages", []):
            if m.get("role") != "assistant":
                continue
            res = m.get("result") or {}
            arts = [a for a in (res.get("artifacts") or [])
                    if isinstance(a, dict) and a.get("filename") and a.get("url")]
            if not arts:
                continue
            title = _first_heading(res.get("final_markdown") or "") or ttitle
            out.append({
                "thread_id": tid,
                "thread_title": ttitle,
                "title": title,
                "at": m.get("at"),
                "artifacts": [{"filename": a["filename"], "url": a["url"]} for a in arts],
            })
    # Найновіші — згори.
    out.sort(key=lambda x: x.get("at") or "", reverse=True)
    return out


def list_projects(limit: int = 60) -> list:
    out = []
    if not PROJECTS_DIR.exists():
        return out
    files = sorted(PROJECTS_DIR.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True)
    for p in files:
        try:
            r = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        out.append({
            "id": r["id"],
            "name": r.get("name") or "Без назви",
            "owner_id": (r.get("owner_id") or ""),
            "chat_count": len(r.get("thread_ids", [])),
            "has_context": bool((r.get("context") or "").strip()),
            "updated_at": r.get("updated_at"),
        })
        if len(out) >= limit:
            break
    return out
