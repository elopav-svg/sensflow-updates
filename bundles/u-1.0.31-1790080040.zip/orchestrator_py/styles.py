"""
styles.py — памʼять стилів письма.

Аналізує текст-зразок у структурований профіль стилю (через LLM-мозок) і
зберігає його як іменований пресет (JSON у orchestrator_py/styles/). Потім
оркестратор підставляє цей профіль агентам-письменникам при написанні статей
«у стилі X».
"""

import json
import re
import uuid
from datetime import datetime
from pathlib import Path

import config
import llm

# ⭐⭐⭐ 01.09.2026. ПИШЕМО У СТАН, ЧИТАЄМО СПЕРШУ ЗІ СТАНУ, ТОДІ З РУШІЯ —
# той самий рецепт, що вже працює в `tender_profile` (PACKS_DIR/BUILTIN_PACKS_DIR).
# У бою обидві теки — одна й та сама, тож не змінюється нічого. Під чеком запис
# іде вбік, але справжні стилі й далі читаються там, де лежать.
STYLES_DIR = config.STATE_DIR / "styles"            # куди ПИШЕМО
BUILTIN_STYLES_DIR = config.ENGINE_DIR / "styles"   # звідки ЧИТАЄМО готове
STYLES_DIR.mkdir(parents=True, exist_ok=True)


def _read_dirs():
    """Теки для ЧИТАННЯ, у порядку старшинства: свіже зі стану — головніше."""
    if STYLES_DIR == BUILTIN_STYLES_DIR:
        return [STYLES_DIR]
    return [STYLES_DIR, BUILTIN_STYLES_DIR]


def _all_style_files():
    """Усі файли стилів з обох тек. Один і той самий id зі стану перемагає:
    інакше готовий стиль із пакета затирав би щойно збережений."""
    seen, out = set(), []
    for d in _read_dirs():
        if not d.exists():
            continue
        for p in sorted(d.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True):
            if p.name in seen:
                continue
            seen.add(p.name)
            out.append(p)
    return out


def _slug(name: str) -> str:
    s = re.sub(r"[^a-z0-9а-яіїєґ]+", "_", (name or "").lower(), flags=re.IGNORECASE)
    s = re.sub(r"_+", "_", s).strip("_")
    return s or ("style_" + uuid.uuid4().hex[:6])


def _path(style_id: str, for_write: bool = False) -> Path:
    """Запис — завжди у теку стану. Читання — стан, тоді готове з рушія."""
    p = STYLES_DIR / f"{style_id}.json"
    if for_write or STYLES_DIR == BUILTIN_STYLES_DIR or p.exists():
        return p
    b = BUILTIN_STYLES_DIR / f"{style_id}.json"
    return b if b.exists() else p


# ---------------------------------------------------------------------------
# Аналіз зразка -> профіль стилю
# ---------------------------------------------------------------------------
def analyze(text: str) -> dict:
    """LLM аналізує зразок і повертає структурований профіль стилю."""
    if not config.provider_ready():
        return {"summary": "Аналіз недоступний: LLM не налаштований."}
    sample = (text or "")[:12000]
    system = (
        "Ти — аналітик авторського стилю. Розбери наданий текст-зразок і виведи "
        "стислий, але конкретний ПРОФІЛЬ СТИЛЮ, який інший автор зможе відтворити. "
        "Спирайся лише на текст, не вигадуй. Поверни РІВНО ОДИН JSON:\n"
        "{\n"
        '  "summary": "1-2 речення: суть стилю",\n'
        '  "tone": "тон і настрій (напр. іронічний, експертний, теплий)",\n'
        '  "sentence_style": "довжина і ритм речень, проста/складна структура",\n'
        '  "vocabulary": "лексика: проста/термінологічна, сленг, образність",\n'
        '  "devices": ["конкретні прийоми: метафори, антитези, риторичні питання, перелік-тріади тощо"],\n'
        '  "structure": "як будується текст: зачин, розвиток, фінал/CTA",\n'
        '  "hooks": ["типові зачини/гачки уваги зі зразка"],\n'
        '  "signature_moves": ["фірмові хитрощі автора"],\n'
        '  "do": ["що РОБИТИ, щоб писати в цьому стилі"],\n'
        '  "dont": ["чого УНИКАТИ"],\n'
        '  "stats": "приблизна статистика: середня довжина речення, частка коротких речень, тощо"\n'
        "}\n"
        "Без тексту поза JSON."
    )
    try:
        return llm.judge_json(system, f"ТЕКСТ-ЗРАЗОК:\n{sample}", temperature=0.1,
                              model=config.brain_model(), max_tokens=1500,
                              purpose="профіль стилю")
    except llm.LLMError as e:
        return {"summary": f"Не вдалося проаналізувати: {e}"}


# ---------------------------------------------------------------------------
# CRUD пресетів
# ---------------------------------------------------------------------------
def save_style(name: str, profile: dict, sample_excerpt: str = "") -> dict:
    sid = _slug(name)
    rec = {
        "id": sid,
        "name": name or sid,
        "profile": profile or {},
        "sample_excerpt": (sample_excerpt or "")[:600],
        "created_at": datetime.now().isoformat(),
    }
    _path(sid).write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")
    return rec


def analyze_and_save(name: str, text: str) -> dict:
    profile = analyze(text)
    rec = save_style(name, profile, text)
    return rec


def list_styles() -> list:
    out = []
    for p in _all_style_files():
        try:
            r = json.loads(p.read_text(encoding="utf-8"))
            out.append({"id": r["id"], "name": r.get("name"),
                        "summary": (r.get("profile") or {}).get("summary", ""),
                        "created_at": r.get("created_at")})
        except Exception:
            continue
    return out


def find_style(name_or_id: str) -> dict:
    """Шукає стиль за id або назвою (нечутливо до регістру)."""
    if not name_or_id:
        return None
    sid = _slug(name_or_id)
    p = _path(sid)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            pass
    # за назвою
    low = name_or_id.strip().lower()
    for s in _all_style_files():
        try:
            r = json.loads(s.read_text(encoding="utf-8"))
            if (r.get("name", "").strip().lower() == low) or r.get("id") == name_or_id:
                return r
        except Exception:
            continue
    return None


def delete_style(name_or_id: str) -> bool:
    rec = find_style(name_or_id)
    if not rec:
        return False
    p = _path(rec["id"])
    try:
        p.unlink()
        return True
    except Exception:
        return False


def profile_as_prompt(rec: dict) -> str:
    """Готує текстовий блок профілю стилю для підстановки агентам."""
    if not rec:
        return ""
    p = rec.get("profile", {}) or {}
    lines = [f"# ОБОВʼЯЗКОВИЙ СТИЛЬ ПИСЬМА: «{rec.get('name')}»"]
    if p.get("summary"):
        lines.append(f"Суть: {p['summary']}")
    for key, label in [("tone", "Тон"), ("sentence_style", "Речення"),
                       ("vocabulary", "Лексика"), ("structure", "Структура"),
                       ("stats", "Статистика")]:
        if p.get(key):
            lines.append(f"{label}: {p[key]}")
    for key, label in [("devices", "Прийоми"), ("hooks", "Зачини"),
                       ("signature_moves", "Фірмові ходи"), ("do", "Робити"), ("dont", "Уникати")]:
        v = p.get(key)
        if v:
            items = v if isinstance(v, list) else [v]
            lines.append(f"{label}: " + "; ".join(str(i) for i in items))
    lines.append("Пиши СУВОРО в цьому стилі.")
    return "\n".join(lines)
