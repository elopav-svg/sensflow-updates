# -*- coding: utf-8 -*-
"""step_outcome.py — ОДНЕ ТРАКТУВАННЯ НАСЛІДКУ КРОКУ ДЛЯ ОБОХ ШЛЯХІВ.

🩸🩸🩸 ЩО КУПЛЕНО ЗРИВОМ 28.08.2026. У платформи два виконавці одного й того
самого кроку: прямий запит (`agent`) і ланцюг (`chains`). На ОДИН І ТОЙ САМИЙ
сигнал системи «мені бракує можливості» вони поводились ПО-РІЗНОМУ:
  · прямий запит робив ОДИН детермінований перезапуск із розширеним контрактом
    і доводив роботу до кінця;
  · ланцюг трактував той самий сигнал як «система такого не вміє в принципі»
    і вбивав крок — разом із усім нарядом, за який людина вже заплатила згодою.
Андрій побачив це на презентації: ланцюг став на першому ж кроці.

⛒ ЗАКОН: ДВА ВИКОНАВЦІ ОДНОГО КРОКУ НЕ СМІЮТЬ МАТИ ДВІ ПРАВДИ. Трактування
наслідку кроку живе ТУТ, в одному місці, і його питають обидва — так само, як
публікатор і пробник ходять одним реєстром воріт (зміна 239).

⛔ Тут НЕМАЄ жодного виклику моделі: це ФАКТ про наслідок, а не судження.
Платити за судження там, де є факт, — марна витрата.
"""

# Яку саме частину контракту наміру відчиняє добірка можливості.
# ⛒ Один словник на платформу: доти «calculator -> computation» стояло в
# `agent`, а `chains` про це не знав узагалі.
CAPABILITY_INTENT = {
    "calculator": {"computation": "required"},
    "web": {"fresh_data": "required"},
}

# Технічний статус -> КЛАС ПРИЧИНИ для розбору невдачі.
# ⛒ `needs_capability` тут СВІДОМО ВІДСУТНІЙ: це не причина невдачі, а прохання
# добрати можливість. Він стає причиною лише тоді, коли добірку вже робили.
_CAUSE = {
    "needs_input": "need_input",
    "paused_budget": "blocked",
    "runtime_error": "blocked",
    "cancelled": "blocked",
    "honest_stop": "not_capable",
}


def interpret(ex, capability_taken=False) -> dict:
    """Що означає наслідок кроку — однаково для прямого запиту і для ланцюга.

    Повертає:
      kind            — completed | capability | needs_input | paused_budget |
                        cancelled | honest_stop | failed
      capability      — чого просить система (лише для kind="capability")
      intent_patch    — що дописати в контракт наміру перед перезапуском
      cause           — клас причини для розбору невдачі
      why             — словами, звідки це відомо
    """
    ex = ex or {}
    st = str(ex.get("status") or "unknown")
    why = str(ex.get("note") or ex.get("failure") or st)

    if st == "completed":
        return {"kind": "completed", "capability": "", "intent_patch": {},
                "cause": "", "why": ""}

    if st == "needs_capability":
        cap = str(ex.get("capability") or "calculator")
        if capability_taken:
            # ⛒ ДОБІРКА РІВНО ОДНА. Друге те саме прохання — це вже чесне
            # «система такого не вміє», а не привід крутити гроші по колу.
            return {"kind": "failed", "capability": cap, "intent_patch": {},
                    "cause": "not_capable",
                    "why": "система просить «%s» і після добірки можливості" % cap}
        return {"kind": "capability", "capability": cap,
                "intent_patch": dict(CAPABILITY_INTENT.get(cap) or {"computation": "required"}),
                "cause": "", "why": "система просить можливість «%s»" % cap}

    if st in ("needs_input", "paused_budget", "cancelled", "honest_stop"):
        return {"kind": st, "capability": "", "intent_patch": {},
                "cause": _CAUSE[st], "why": why}

    return {"kind": "failed", "capability": "", "intent_patch": {},
            "cause": _CAUSE.get(st, "blocked"), "why": why}
