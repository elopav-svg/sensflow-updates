# -*- coding: utf-8 -*-
"""notify_license.py — ЛИСТ КЛІЄНТУ ПРО ЛІЦЕНЗІЮ (зміна 244, 27.08.2026).

ЧОМУ ЦЕ ТРЕТІЙ КАНАЛ, А НЕ ВТИСНУТИ В НАЯВНІ.
    У нас уже два жанри, і плутати їх ми вже раз обпеклись:
      • `notify_client_update` — ПОВНИЙ опис змін релізу;
      • `push_update_note`     — КОРОТКИЙ пуш «вийшло оновлення».
    Обидва прибиті до ВЕРСІЇ: їхні ворота вимагають, щоб маніфест клієнта стояв
    на версії збірки. Лист про ліцензію версії не має взагалі — продовження
    строку не є релізом. Пропхати його тим каналом означало б або зламати
    ворота, або оголосити реліз, якого немає.

⛒ ЩО ЦЕЙ КАНАЛ РОБИТЬ. Бере ГОТОВИЙ, СХВАЛЕНИЙ ЛЮДИНОЮ текст із файлу і шле
його ботом підтримки в чат, привʼязаний у CRM. Тексту звідси код НЕ ДОДАЄ і не
вигадує: писар листа — людина, а не скрипт.

ВОРОТА (fail-closed, кожне каже причину словами):
  1) невідомий клієнт                        → СТОП;
  2) немає привʼязки Telegram у CRM          → СТОП (краще не надіслати, ніж чужому);
  3) немає файлу з текстом / він порожній    → СТОП;
  4) у тексті НЕМА ключа з картки клієнта    → СТОП. Це головні ворота: лист
     із ЧУЖИМ або ВЧОРАШНІМ ключем гірший за ненадісланий — клієнт вставить
     його, платформа не активується, і винні будемо ми;
  5) у тексті НЕМА строку з картки клієнта   → СТОП (обіцяємо не той строк);
  6) текст довший за межу                    → СТОП (це вже не лист, а документ).

Запуск:  python notify_license.py --customer Casper --text-file <файл> [--dry-run]
"""
import argparse
import sys
from pathlib import Path

import crm
import publish_update as pu
import telegram_bot as tb

HIST_PREFIX = "Telegram: лист про ліцензію до "

# Межа листа. Ключ сам по собі ~250 знаків, тому межа більша за пуш — але це
# все одно ЛИСТ, а не документ: докладне їде іншим маршрутом.
NOTE_MAX = 1600


class Stop(Exception):
    """Зупинка, яка називає себе вголос і нічого не відправляє."""


def _human(iso: str) -> str:
    """Строк очима людини (DD.MM.YYYY) — у листі стоїть саме так."""
    v = str(iso or "").strip()
    return "%s.%s.%s" % (v[8:10], v[5:7], v[0:4]) if len(v) >= 10 else v


def build(name: str, text_file: Path) -> str:
    card = crm.get_client(name) or {}
    if not text_file.exists():
        raise Stop("немає файлу з текстом: %s" % text_file)
    text = text_file.read_text(encoding="utf-8").strip()
    if not text:
        raise Stop("файл із текстом порожній: %s" % text_file)

    key = str(card.get("license_key") or "").strip()
    if not key:
        raise Stop("у картці «%s» немає ключа ліцензії — нема про що писати." % name)
    if key not in text:
        raise Stop("у тексті листа НЕМА ключа з картки клієнта. Лист із чужим або "
                   "вчорашнім ключем гірший за ненадісланий.")

    until = _human(card.get("expiry"))
    if not until:
        raise Stop("у картці «%s» немає строку ліцензії." % name)
    if until not in text:
        raise Stop("у тексті листа немає строку «%s» із картки клієнта — лист "
                   "обіцяв би не те, що ми справді видали." % until)

    if len(text) > NOTE_MAX:
        raise Stop("лист задовгий: %d знаків, межа %d." % (len(text), NOTE_MAX))
    return text


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--customer", default="Casper", help="імʼя або псевдонім клієнта")
    ap.add_argument("--text-file", required=True, help="файл зі СХВАЛЕНИМ текстом листа")
    ap.add_argument("--dry-run", action="store_true", help="показати і НЕ відправляти")
    a = ap.parse_args()

    name, why = pu.canon_customer(a.customer)
    if not name:
        print("  [X] STOP: %s" % why)
        sys.exit(2)

    chat_id = crm.channels_of(name).get("telegram_id") or ""
    if not chat_id:
        print("  [X] STOP: у картці «%s» немає привʼязаного Telegram." % name)
        sys.exit(2)

    try:
        text = build(name, Path(a.text_file))
    except Stop as e:
        print("  [X] STOP: %s" % e)
        sys.exit(2)

    card = crm.get_client(name) or {}
    until = _human(card.get("expiry"))
    print("=" * 60)
    print("  Клієнт : %s" % name)
    print("  Чат    : %s" % chat_id)
    print("  Строк у картці: %s" % until)
    print("  Знаків : %d (межа %d)" % (len(text), NOTE_MAX))
    print("=" * 60)
    print(text)
    print("=" * 60)

    if a.dry_run:
        print("DRY-RUN: нічого не відправлено.")
        return

    token = tb._support_token()
    if not token:
        print("  [X] STOP: не налаштований токен бота підтримки "
              "(TELEGRAM_SUPPORT_BOT_TOKEN).")
        sys.exit(2)
    tb._ctx.token = token
    tb._ctx.role = "support"
    if not tb._send_message(chat_id, text):
        print("  [X] FAILED: Telegram не прийняв повідомлення. Причина — вище.")
        sys.exit(1)

    try:
        crm.add_history(name, "outbound", HIST_PREFIX + until)
    except Exception:
        pass
    print("OK: лист про ліцензію надіслано клієнту «%s» (чат %s)." % (name, chat_id))


if __name__ == "__main__":
    main()
