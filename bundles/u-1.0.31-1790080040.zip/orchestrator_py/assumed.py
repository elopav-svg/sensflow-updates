# -*- coding: utf-8 -*-
"""assumed.py — ⭐⭐⭐ ОДИН ПИСАР: З ЧИМ ПЛАТФОРМА БУДЕ РАХУВАТИ
(зміна 581, 13.09.2026).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ: **ПЛАТФОРМА ПОКАЗУЄ, ЯК ЗРОЗУМІЛА ЗАПИТАННЯ, І ХОВАЄ,
З ЧИМ БУДЕ РАХУВАТИ.**

Картка «Як я зрозумів задачу» показує галузь, право й тип результату — тобто
все про ПИТАННЯ. Про те, на чому стоятиме ВІДПОВІДЬ, вона мовчить. 🩸 12.09.2026
замовник дізнався, що його «Газель, 5 тонн» порахували середнім класом із
витратою 20 л/100 км, лише з готового документа — після грошей. А в рейсі 1 у
документ пішла витрата 35 л/100 км, якої в методиці немає взагалі.

⭐ КОРІНЬ, А НЕ ВИПАДОК. Клас називав АГЕНТ усередині прогону — і той самий
агент потім писав документ. Тому платформа не могла ані показати клас
заздалегідь, ані перевірити його: єдиний, хто знав рішення, був той, хто його й
вигадав. Тут зʼявляється один писар:

  1. КЛАС ВИЗНАЧАЄ КОД за таблицею методики — детерміновано, офлайн, за $0;
  2. клас і витрата стають рядками картки «Як я зрозумів задачу» — людина
     бачить їх ДО витрат;
  3. той самий клас іде агентові ФАКТОМ («ось твій клас і його нормативи,
     чужий брати заборонено»), а не проханням;
  4. а сторож 579 потім перевіряє, що названий норматив таки вжито.

⛒ ЖОДНОГО ПЕРЕЛІКУ СЛІВ У КОДІ. «Газель», «фура», «сідельний тягач», межі мас
і самі нормативи живуть у таблицях методики. Система, яка напише свою таблицю
класів, дістане ту саму поведінку без жодного рядка коду тут. Модуль не знає
слова «вантажівка» — він знає, як читається таблиця.

⛒ І НІЧОГО НЕ ВИГАДУЄМО. Немає ні назви, ні тоннажу — писар МОВЧИТЬ. Показати
«легкий за замовчуванням» означало б зробити рівно те, що ми лікуємо.

Модуль без залежностей: його можна спитати без усієї платформи.
"""
import re
from pathlib import Path

# Заголовок таблиці класів у методиці. Шукаємо саме за змістом стовпців, а не
# за номером рядка: методику пишуть люди, і рядки в ній рухаються.
_H_CLASS = ("клас",)
_H_MASS = ("маса", "вага")

# ⛒ Тоннаж — це число З ОДИНИЦЕЮ впритул. «вул. Вагнера, 16» і «Окружна, 21»
# тоннажем не є; «250 грн/год» і «08:00» теж.
_TONS = re.compile(r"(\d+(?:[.,]\d+)?)\s*(?:т\b|тон|тонн)", re.IGNORECASE)

# Межі маси з клітинки методики: «до 3,5 т», «3,5-12 т», «понад 12 т».
_UPTO = re.compile(r"до\s*(\d+(?:[.,]\d+)?)", re.IGNORECASE)
_OVER = re.compile(r"(?:понад|більше|від)\s*(\d+(?:[.,]\d+)?)", re.IGNORECASE)
_RANGE = re.compile(r"(\d+(?:[.,]\d+)?)\s*[-–—]\s*(\d+(?:[.,]\d+)?)")


def _num(tok: str):
    try:
        return float(str(tok).replace(",", "."))
    except (TypeError, ValueError):
        return None


# ⛒ СЛОВО В ЗАПИТІ СТОЇТЬ У СВОЇЙ ФОРМІ: «фурою», «Газеллю», «сідельним тягачем».
# Тому звіряємо ОСНОВУ — слово без хвостових голосних і «ь»/«й» — і дозволяємо
# кілька літер закінчення. Основа не коротша за три літери: інакше «борт»
# перетворився б на «бор» і чіплявся б за «Бориспіль».
#
# ⛒ ЗАКІНЧЕННЯ СУДИТЬСЯ ЗА ФОРМОЮ, А НЕ ЗА ДОВЖИНОЮ. 🩸 13.09.2026 тут спершу
# стояло «дозволяємо N будь-яких літер», і виміряне живе тіло (569 файлів)
# показало, чому це хибний СПОСІБ, а не хибне число:
#   • при трьох літерах «довгомірного» не впізнавалося як «довгомір» — а це
#     дослівні слова живого запиту 12.09.2026; клас тоді врятувала лише друга
#     назва «сідельний тягач», що трапилася поруч;
#   • при чотирьох воно впізналось, але разом із ним «органічний БУСТ» у
#     маркетинговому тексті став «бусом»;
#   • при пʼяти додались «бустери», при шести — «фурнітура».
# Жодне число не розділяє «фурою» і «фурнітуру»: різниця не в довжині, а в тому,
# ЩО САМЕ стоїть після основи. Тож дозволено рівно три речі, і всі три — правила
# мови, а не здогад:
#   1) закінчення відмінка: починається з голосної, «ь» або «й» («фур|ою»);
#   2) прикметник від назви: суфікси -н-, -ов-, -ев-, -ськ- («довгомір|ного»,
#      «борт|овий») — машина, названа прикметником, лишається тією ж машиною;
#   3) подвоєння приголосної основи перед голосною («газел|лю»).
# Усе інше — чуже слово, хай там скільки літер. Довжина лишається стелею згори.
_TAIL = "аеєиіїоуюяьй"
_LETTER = "[а-яіїєґёa-z]"
_ENDING = 4
_VOWEL = "аеєиіїоуюяьй"
_DERIV = ("ськ", "ов", "ев", "єв", "н")


def _tail_ok(stem: str, tail: str) -> bool:
    """Чи це та сама назва, лише в іншій формі."""
    if not tail:
        return True
    if len(tail) > _ENDING:
        return False
    if tail[0] in _VOWEL:
        return True
    if any(tail.startswith(d) for d in _DERIV):
        return True
    # «газел» + «лю»: подвоєна приголосна основи, далі голосна.
    return bool(stem and tail[0] == stem[-1] and tail[1:2] and tail[1] in _VOWEL)


def _stem(w: str) -> str:
    w = w.strip()
    while len(w) > 3 and w[-1] in _TAIL:
        w = w[:-1]
    return w


def _mentions(low: str, phrase: str) -> bool:
    """Чи згадано цю назву в запиті. Назва з кількох слів мусить бути вся."""
    parts = [p for p in re.split(r"[\s'’-]+", phrase) if len(p) >= 3]
    if not parts:
        return False
    for p in parts:
        st = _stem(p)
        if not _found(low, st):
            return False
    return True


def _found(low: str, stem: str) -> bool:
    """Чи стоїть у тексті слово з цією основою — саме як окреме слово."""
    for m in re.finditer(r"(?<!%s)%s(%s*)" % (_LETTER, re.escape(stem), _LETTER), low):
        if _tail_ok(stem, m.group(1)):
            return True
    return False


def _tables(root) -> list:
    """Таблиці бази знань системи — КОЖНА ОКРЕМО, рядками клітинок.

    ⛒ Саме окремо, а не суцільним потоком рядків. 🩸 13.09.2026 перша редакція
    зливала всі таблиці в одну: читач класів «зʼїдав» сусідню таблицю
    нормативів і оголошував класом рядок «Показник». Межа таблиці — порожній
    рядок або будь-який текст без стінок."""
    kb = Path(root) / "Knowledge"
    if not kb.is_dir():
        return []
    out = []
    for p in sorted(kb.glob("*.md")):
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        cur = []
        for line in text.splitlines():
            if line.count("|") >= 2:
                cells = [c.strip() for c in line.strip().strip("|").split("|")]
                if len(cells) >= 2:
                    cur.append(cells)
                    continue
            if cur:
                out.append(cur)
                cur = []
        if cur:
            out.append(cur)
    return out


def _is_ruler(cells) -> bool:
    return set("".join(cells)) <= set("-: ")


def classes(root) -> list:
    """Класи машин ІЗ МЕТОДИКИ: назва, межі маси, як це зветься в житті.

    Порожньо — у цієї системи такої таблиці немає, і писати нам нема про що."""
    for table in _tables(root):
        head = [c.lower() for c in table[0]]
        if len(head) < 3:
            continue
        if not (any(h in head[0] for h in _H_CLASS)
                and any(any(h in c for h in _H_MASS) for c in head[1:])):
            continue
        out = []
        for cells in table[1:]:
            if _is_ruler(cells) or len(cells) < 3:
                continue
            name = re.sub(r"[*`]", "", cells[0]).strip().lower()
            # ⛒ Клас — це те, що має НАЗВУ. Рядок без жодної літери («| 1 | 2 |
            # 3 |» — звичка нумерувати стовпці) класом не є.
            # 🩸 13.09.2026 тут стояло «жодної цифри», і це різало живе: методика
            # цієї ж системи в сусідній таблиці пише клас як «легкий (до 3,5 т)».
            # Така методика лишалася б без жодного класу, і писар мовчав би —
            # тобто робив би рівно те, що ми лікуємо.
            if not any(ch.isalpha() for ch in name):
                continue
            mass = cells[1]
            lo, hi = 0.0, float("inf")
            m = _RANGE.search(mass)
            if m:
                lo, hi = _num(m.group(1)) or 0.0, _num(m.group(2)) or float("inf")
            elif _UPTO.search(mass):
                hi = _num(_UPTO.search(mass).group(1)) or float("inf")
            elif _OVER.search(mass):
                lo = _num(_OVER.search(mass).group(1)) or 0.0
            words = [w.strip(" «»\"'.").lower()
                     for w in re.split(r"[,;/]", re.sub(r"[*`]", "", cells[2]))]
            out.append({"id": name, "mass": mass, "lo": lo, "hi": hi,
                        "words": [w for w in words if len(w) >= 3]})
        if out:
            return out
    return []


# ── ⛒⛒⛒ 582. ЧИМ ЗАПРАВЛЯЮТЬ — ЦЕ ТЕЖ ПІДСТАВА, А НЕ ДРІБНИЦЯ ───────────────
# 581 поклала в картку «32 л / 100 км». Літр ЧОГО — платформа мовчала, а ціна
# дизеля в методиці 95 грн, газу 48: вид пального рухає суму рейсу так само
# сильно, як клас машини. Замовник його не називає ніколи (виміряно по всіх
# текстах платформи: жодної згадки в живих запитах). Отже платформа мовчки
# брала одне й мовчки множила.
#
# ⛒ Види беруться з ЦІНОВОЇ ТАБЛИЦІ методики, за ФОРМОЮ рядка: назва
# починається зі слова «ціна», а значення — число за ЛІТР. Жодного «дизеля»,
# «бензину» чи «газу» в коді: система, яка напише свою цінову таблицю, дістане
# ту саму поведінку без рядка коду тут.
_PRICE_NAME = re.compile(r"^\s*цін\w*\s+(.+?)\s*$", re.IGNORECASE)
_PER_LITRE = re.compile(r"(\d+(?:[.,]\d+)?)\s*([^\s|/]*)\s*/\s*л\b", re.IGNORECASE)


def fuel_kinds(root) -> list:
    """Види пального З МЕТОДИКИ: {id, label, price, unit, raw}.

    Порожньо — цінової таблиці немає, і казати нам нема про що."""
    out, seen = [], set()
    for table in _tables(root):
        for cells in table:
            if _is_ruler(cells) or len(cells) < 2:
                continue
            name = re.sub(r"[*`]", "", cells[0]).strip()
            m = _PRICE_NAME.match(name)
            if not m:
                continue
            val = re.sub(r"[*`]", "", cells[1]).strip()
            p = _PER_LITRE.search(val)
            if not p:
                continue                   # ⛒ «ціна» не за літр — це не пальне
            kid = m.group(1).strip().lower()
            if not kid or kid in seen:
                continue
            seen.add(kid)
            out.append({"id": kid, "price": _fmt(_num(p.group(1))),
                        "unit": (p.group(2) + "/л").strip(),
                        "raw": val, "label": "%s (%s)" % (kid, val)})
    return out


def _mentions_any(low: str, phrase: str) -> bool:
    """Чи згадано БОДАЙ ОДНЕ значуще слово назви.

    ⛒ Тут навмисно не так, як із класами машин. «сідельний тягач» — складена
    назва, і половина від неї нічого не означає. А «газу (LPG)» — це той самий
    вид, названий двома способами: людина пише або одне, або друге."""
    for part in re.split(r"[\s'’\-()/,]+", phrase):
        if len(part) >= 3 and _found(low, _stem(part)):
            return True
    return False


def norms_of(root, class_id) -> list:
    """Рядки нормативів САМЕ цього класу: (показник, значення).

    Стовпець класу знаходимо за шапкою таблиці нормативів — тією, у якій
    згадані назви всіх класів."""
    cls = [c["id"] for c in classes(root)]
    if not cls or class_id not in cls:
        return []
    out = []
    for table in _tables(root):
        head = [c.lower() for c in table[0]]
        hits = [i for i, c in enumerate(head) if any(k in c for k in cls)]
        if len(hits) < len(cls):
            continue
        col = None
        for i, c in enumerate(head):
            if class_id in c:
                col = i
                break
        if col is None:
            continue
        for cells in table[1:]:
            if _is_ruler(cells) or col >= len(cells):
                continue
            name = re.sub(r"[*`]", "", cells[0]).strip()
            val = re.sub(r"[*`]", "", cells[col]).strip()
            if name and val and any(ch.isdigit() for ch in val):
                out.append((name, val))
        if out:
            return out
    return out


def _fuel_of_norms_name(norms) -> str:
    """Вид, яким МЕТОДИКА задає витрату — з назви самого рядка норм.

    ⛒ Ось де живе «за замовчуванням дизель», якого власник просив: рядок
    зветься «витрата дизеля, навантажений», отже методика САМА каже, чим вона
    рахує. Слова «дизель» у коді через це немає — є правило читання назви."""
    for name, _v in norms or []:
        low = str(name).lower()
        if any(k in low for k in _FUEL_ROW) and "порожн" not in low:
            head = re.split(r"[,(]", low, 1)[0]
            words = [w for w in re.split(r"\s+", head) if len(w) >= 3]
            return " ".join(words[1:]).strip()      # перше слово — показник
    return ""


def _without(low: str, word: str) -> str:
    """Текст запиту без слова, яке ВЖЕ дало клас машини.

    🩸 Інакше «Газель, 5 тонн» перетворювалась би на рейс на ГАЗУ: основа «газ»
    чесно знаходиться всередині «газелі». Одне слово не може бути водночас
    назвою машини й видом пального, і перше рішення платформа вже ухвалила й
    показала людині — отже друге бере текст, що лишився."""
    if not word:
        return low
    st = _stem(word)
    if len(st) < 3:
        return low
    return re.sub(r"(?<!%s)%s%s*" % (_LETTER, re.escape(st), _LETTER), " ", low)


def _fuel_pick(root, low: str, norms, choice):
    """Яке пальне платформа візьме — і ЧОМУ. Порядок сили:
    методика < назване в запиті < виправлене людиною в картці.

    ⛒ Виду, якого в ціновій таблиці немає, не беремо ні з запиту, ні від
    людини: той самий закон, за яким клас машини береться лише з методики."""
    kinds = fuel_kinds(root)
    if not kinds:
        return None, "", ""
    by = {k["id"]: k for k in kinds}
    want = str((choice if isinstance(choice, dict) else {}).get(KEY_FUEL)
               or "").strip().lower()
    if want in by:
        return by[want], "обрали ВИ в картці розуміння", ""
    for k in kinds:
        if _mentions_any(low, k["id"]):
            return k, "названо в запиті замовника", ""
    # ⛒ Замовчування — не вписане словом, а прочитане з назви рядка витрати.
    named = _fuel_of_norms_name(norms)
    if named:
        for k in kinds:
            if k["id"] == named or _mentions_any(" %s " % named, k["id"]):
                return k, "за замовчуванням методики", named
    return kinds[0], "за замовчуванням методики (перший у таблиці)", named


def decide(root, text: str, choice=None):
    """⭐ ГОЛОВНА ФУНКЦІЯ. Який клас платформа візьме — і чому.

    Повертає {class_id, mass, tons, by, why, fuel, norms} або None, коли ні
    назви, ні тоннажу в запиті немає. Чиста функція: два виклики на тих самих
    вхідних даних дають те саме.

    choice — поправка людини з картки розуміння {"vehicle_class": "важкий"}.
    Вона сильніша за висновок платформи, але не сильніша за методику: класу,
    якого в таблиці немає, ми не беремо ні від кого."""
    cls = classes(root)
    if not cls or not (text or "").strip():
        return None
    low = " " + re.sub(r"\s+", " ", str(text).lower()) + " "

    # ── за тоннажем ──────────────────────────────────────────────────────────
    # ⛒ Тоннажів у запиті буває кілька («Газель 5 т, вантаж ~1.67 т на точку»).
    # Беремо НАЙБІЛЬШИЙ: методика каже прямо, що занижений розрахунок гірший за
    # завищений, і при суперечності велить брати більший клас.
    tons = None
    for m in _TONS.finditer(low):
        v = _num(m.group(1))
        if v is not None and (tons is None or v > tons):
            tons = v

    # ── ⛒⛒⛒ 581б. ВИБІР ЛЮДИНИ СИЛЬНІШИЙ ЗА ВИСНОВОК ПЛАТФОРМИ ──────────────
    # 🩸 581 показала клас на екрані — і на цьому спинилась: виправити його було
    # ніде, бо дорога від екрана до роботи знала лише два імені полів. Тепер
    # рядок картки можна виправити, і поправка приходить сюди.
    # ⛒ АЛЕ НЕ БУДЬ-ЯКА. Клас, якого в таблиці ЦІЄЇ методики немає, не береться
    # навіть від людини — той самий закон, за яким `understanding.resolve`
    # відкидає галузь «космічне» від клієнта. Платформа не вигадує ні за себе,
    # ні за людину.
    want = str((choice if isinstance(choice, dict) else {}).get(KEY_CLASS) or "").strip().lower()
    if want:
        for c in cls:
            if c["id"] == want:
                norms = norms_of(root, c["id"])
                return _with_fuel({"class_id": c["id"], "mass": c["mass"],
                                   "tons": tons, "by": "вибір людини",
                                   "why": "клас обрали ВИ в картці розуміння",
                                   "fuel": _fuel_of(norms), "norms": norms},
                                  root, low, choice)

    # ── за назвою ────────────────────────────────────────────────────────────
    # ⛒ ПЕРЕМАГАЄ НАЙДОВША НАЗВА, А НЕ НАЙБІЛЬШИЙ КЛАС. «фургон» — це легкий
    # клас, і його не сміє перебити важка «фура» лише тому, що «фур» є всередині
    # слова «фургон». Точніша назва точніша, і крапка.
    by_name, hit_word, hit_len = None, "", 0
    for c in cls:
        for w in c["words"]:
            if _mentions(low, w):
                if len(w) > hit_len:
                    by_name, hit_word, hit_len = c, w, len(w)

    # ── за тоннажем: клас, у чиї межі маси потрапляє названий тоннаж ─────────
    by_tons = None
    if tons is not None:
        for c in cls:
            if c["lo"] <= tons <= c["hi"] or (c["hi"] == float("inf") and tons > c["lo"]):
                by_tons = c
                break

    if by_name is None and by_tons is None:
        return None                        # ⛒ нічого не вигадуємо

    # ── ⛒ ПРИ СУПЕРЕЧНОСТІ — БІЛЬШИЙ КЛАС (пряме правило методики) ───────────
    if by_name is not None and by_tons is not None and by_name["id"] != by_tons["id"]:
        pick = by_name if by_name["lo"] > by_tons["lo"] else by_tons
        why = ("назва «%s» вказує на клас «%s», а тоннаж %s т — на «%s»; "
               "за методикою взято БІЛЬШИЙ"
               % (hit_word, by_name["id"], _fmt(tons), by_tons["id"]))
        by = "конфлікт назви й тоннажу"
    elif by_tons is not None:
        pick, by = by_tons, "тоннаж із запиту"
        why = "тоннаж %s т із запиту замовника" % _fmt(tons)
    else:
        pick, by = by_name, "назва машини із запиту"
        why = "назва «%s» із запиту замовника; тоннаж не названо" % hit_word

    norms = norms_of(root, pick["id"])
    return _with_fuel({"class_id": pick["id"], "mass": pick["mass"], "tons": tons,
                       "by": by, "why": why, "fuel": _fuel_of(norms),
                       "norms": norms},
                      root, _without(low, hit_word), choice)


def _with_fuel(d, root, low, choice):
    """Додати до рішення вид пального, його ціну й ЧЕСНУ МЕЖУ витрати.

    ⛒ ОДИН додавач на обидва виходи `decide`: два місця розійшлись би мовчки —
    рівно та хвороба «двох писарів однієї правди», яку лікували 153 і 581б."""
    k, why, rate_kind = _fuel_pick(root, low, d.get("norms"), choice)
    if not k:
        return d                       # цінової таблиці немає — мовчимо
    d["fuel_kind"] = k["id"]
    d["fuel_price"] = k["price"]
    d["fuel_unit"] = k["unit"]
    d["fuel_raw"] = k["raw"]
    d["fuel_by"] = why
    # ⛒ МЕЖА ВГОЛОС. Витрату методика задає лише для одного виду. Беремо ціну
    # обраного, витрату лишаємо ту, що є, і КАЖЕМО це — замовник дістає
    # результат і бачить межу, а не чесну відмову. Заразом видно, що саме
    # дописати в методику.
    named = rate_kind or _fuel_of_norms_name(d.get("norms"))
    d["fuel_rate_note"] = ""
    if named and k["id"] != named and not _mentions_any(" %s " % named, k["id"]):
        d["fuel_rate_note"] = ("витрату методика задає лише для «%s»; для «%s» "
                               "взято ту саму, іншої методика не має"
                               % (named, k["id"]))
    return d


def _fmt(v) -> str:
    if v is None:
        return "—"
    s = ("%.2f" % v).rstrip("0").rstrip(".")
    return s.replace(".", ",")


# ⛒ 582. Рядок витрати впізнається за ПОКАЗНИКОМ, а не за видом пального.
# 🩸 Тут стояло ще й «дизел» — тобто писар, який гордо не знає слова «Газель»,
# знав слово «дизель». Вид пального — це ЗНАЧЕННЯ з методики, і в коді йому не
# місце рівно так само, як назві машини.
_FUEL_ROW = ("витрат", "пальн")


def _fuel_of(norms):
    """Витрата на НАВАНТАЖЕНОМУ пробігу — те, чим рахують основне плече."""
    for name, val in norms:
        low = name.lower()
        if any(k in low for k in _FUEL_ROW) and "порожн" not in low:
            m = re.search(r"\d+(?:[.,]\d+)?", val)
            if m:
                return _num(m.group())
    return None


# ⛒ ІМʼЯ ПОЛЯ ЖИВЕ В ОДНОМУ МІСЦІ — у писаря, який цей рядок складає. Ні
# екран, ні сервер, ні мозок, ні виконавець його не знають і знати не мусять.
KEY_CLASS = "vehicle_class"
KEY_FUEL = "fuel_kind"


def _choice_of(contract):
    """Поправки людини з ГОТОВОГО контракту розуміння. Контракт везе їх
    непрозорим мішком; розпаковує його той, хто складав рядок."""
    c = contract if isinstance(contract, dict) else {}
    ch = c.get("choices")
    return ch if isinstance(ch, dict) else {}


def rows_for(root, text: str, contract) -> list:
    """Двері картки: рядки з урахуванням того, що людина вже виправила."""
    return rows(root, text, _choice_of(contract))


def block_for(root, text: str, contract) -> str:
    """Двері виконавця: факт агентові з урахуванням поправки людини."""
    return block(root, text, _choice_of(contract))


def rows(root, text: str, choice=None) -> list:
    """Рядки для картки «Як я зрозумів задачу». Порожньо — показувати нічого."""
    try:
        d = decide(root, text, choice)
    except Exception:
        return []                          # межа знання не сміє валити картку
    if not d:
        return []
    # ⛒⛒⛒ 581б. РЯДОК, ЯКИЙ МОЖНА ВИПРАВИТИ, МУСИТЬ ПРИВЕЗТИ СВІЙ СПИСОК.
    # Екран не тримає ані імен полів, ані переліку класів: він малює випадний
    # список тому рядку, який його привіз, і повертає відповідь під ключем
    # рядка. Тому класи тут — із таблиці САМЕ ЦІЄЇ методики, як і все інше.
    out = [{"key": KEY_CLASS, "label": "Клас машини",
            "id": d["class_id"],
            "choices": [[c["id"], "%s (%s)" % (c["id"], c["mass"])]
                        for c in classes(root)],
            "value": "%s (%s) — %s" % (d["class_id"], d["mass"], d["why"])}]
    if d.get("fuel") is not None:
        _v = ("%s л / 100 км (навантажений, норматив методики для класу «%s»)"
              % (_fmt(d["fuel"]), d["class_id"]))
        # ⛒ 582. Межа їде В ТОМУ САМОМУ рядку, а не окремою зноскою внизу:
        # застереження, яке стоїть не там, де число, людина не читає.
        if d.get("fuel_rate_note"):
            _v += " — ⚠ %s" % d["fuel_rate_note"]
        out.append({"key": "fuel_rate", "label": "Витрата пального", "value": _v})
    # ⛒⛒⛒ 582. ВИД ПАЛЬНОГО Й ЙОГО ЦІНА. Показати «32 л/100 км» і сховати, чого
    # саме літр, означало б повторити ваду 581 на крок глибше: дизель 95 грн,
    # газ 48 — вид рухає суму рейсу не слабше за клас машини.
    if d.get("fuel_kind"):
        out.append({"key": KEY_FUEL, "label": "Вид пального",
                    "id": d["fuel_kind"],
                    "choices": [[k["id"], k["label"]] for k in fuel_kinds(root)],
                    "value": "%s — %s" % (d["fuel_kind"], d.get("fuel_by") or "")})
        out.append({"key": "fuel_price", "label": "Ціна пального",
                    "value": "%s (норматив методики, прийнято для розрахунку; "
                             "підставте свою ціну заправки — перерахунок за "
                             "10 секунд)" % (d.get("fuel_raw") or "")})
    return out


def block(root, text: str, choice=None) -> str:
    """Факт агентові: ось твій клас і його нормативи. Не прохання — дані."""
    try:
        d = decide(root, text, choice)
    except Exception:
        return ""
    if not d or not d.get("norms"):
        return ""
    body = "\n".join("| %s | %s |" % (n, v) for n, v in d["norms"])
    return (
        "## ⛒ КЛАС МАШИНИ %s, А НЕ ТИ\n"
        "Клас: **%s** (%s). Підстава: %s.\n\n"
        "Нормативи ЦЬОГО класу — і тільки цього:\n\n"
        "| Показник | Значення |\n|---|---|\n%s\n\n"
        "⛔ Брати норматив іншого класу ЗАБОРОНЕНО. 🩸 12.09.2026 «Газель», "
        "порахована чужим класом, дала витрату втричі більшу за справжню, а в "
        "іншому рейсі в документ пішли 35 л/100 км, яких у методиці немає.\n"
        "⛒ Цей клас і цю витрату замовник УЖЕ БАЧИВ на екрані «Як я зрозумів "
        "задачу» — до того, як заплатив. Міняти їх мовчки не можна: якщо клас "
        "хибний, скажи це окремим рядком і назви, що саме не сходиться.\n"
        % ("ОБРАВ ЗАМОВНИК" if d.get("by") == "вибір людини"
           else "ВИЗНАЧИЛА ПЛАТФОРМА",
           d["class_id"], d["mass"], d["why"], body)
    ) + _fuel_block(d)


def _fuel_block(d) -> str:
    """⛒ 582. Вид пального і ЙОГО ціна — агентові фактом, разом із межею.

    Без цього агент бачив число витрати й сам вирішував, чим заправляють і
    почому. 🩸 12.09.2026 у документ уже йшла ціна дизеля 55,50 грн/л, якої в
    методиці немає взагалі."""
    if not d.get("fuel_kind"):
        return ""
    out = ("\n## ⛒ ВИД ПАЛЬНОГО І ЦІНА — ТЕЖ НЕ ТВІЙ ВИБІР\n"
           "Пальне: **%s** (%s). Ціна: **%s** — норматив методики.\n"
           % (d["fuel_kind"], d.get("fuel_by") or "", d.get("fuel_raw") or ""))
    if d.get("fuel_rate_note"):
        out += "⚠ %s. Скажи це в документі окремим рядком.\n" % d["fuel_rate_note"]
    out += ("⛔ Іншої ціни за літр НЕ бери й не шукай у памʼяті. Разом із ціною в "
            "документ іде рядок: «підставте свою ціну заправки — перерахунок за "
            "10 секунд».\n")
    return out
