# -*- coding: utf-8 -*-
"""shop.py — ОДИН ПИСАР ПРОПОЗИЦІЇ: ЩО МИ ПРОДАЄМО І ПОЧОМУ (616, 20.09.2026).

⭐⭐⭐ ЩО ЦЕ ДЛЯ ЛЮДИНИ. Власник відкриває «Магазин» і бачить, що платформа
вміє і скільки коштує розширення. Позначає потрібне, тисне «Сформувати
замовлення» — і дістає ДОКУМЕНТ платформи з номером і місцем у сховищі, а не
файл у «Завантаженнях», який завтра ніхто не знайде.

⛒ КЛАС, ЯКИЙ ЦЕЙ МОДУЛЬ ЗАКРИВАЄ — «ЕКРАН ПЕРЕКАЗУЄ ДИСК».
`README.md` роками обіцяв «18 активних систем», порт 8787 і «Global
Orchestrator is Codex»: він ПЕРЕКАЗУВАВ по памʼяті те, що мав ЧИТАТИ. Магазин
із цінами, вписаними в HTML, засох би так само — і засохлу ціну побачив би
клієнт. Тому тут НЕМАЄ жодного числа: прайс рахується з файла прайсу, перелік
систем — з реєстру систем, а екран малює лише те, що дав цей модуль.

⛒ ЧОМУ ПРАЙС ПРОДАВЦЯ НЕ ЛЕЖИТЬ У «ТОВАРАХ І ПОСЛУГАХ». Цей довідник —
власність КЛІЄНТА: він його заводить і править сам. Магазин, який рахує ціну
ПРОДАВЦЯ з файла ПОКУПЦЯ, — не магазин, а бланк із порожнім полем «ціна»:
досить відкрити «Товари і послуги» й поставити 1 грн. Тому прайс продавця їде
ЗІ ЗБІРКОЮ, оновлюється оновленням і клієнтом не редагується.
⚠ План 20.09.2026 називав джерелом саме «Товари і послуги» — кажу прямо, що
план тут вів не туди, і чому. Записи `SF-*`, заведені в довіднику клієнта
20.09.2026, лишаються корисними: з них CRM бере ПОЗИЦІЇ УГОДИ, коли Андрій
продає. Це інша робота: позиція угоди — знімок домовленості, а не прайс.

⛒ НОМЕР ЗАМОВЛЕННЯ ВИДАЄ ТОЙ САМИЙ ПИСАР, ЩО Й НОМЕР ДОГОВОРУ (`doc_numbers`).
Свій лічильник поруч означав би два реєстри номерів в одній компанії й перший
же збіг у паперах. Пропуск у нумерації нікому не шкодить; збіг шкодить усім.

⛒ ЦІНИ В ЗАМОВЛЕННІ — ЗНІМОК. Завтрашній прайс не переписує вчорашнє
замовлення: той самий закон, що в позиціях угоди (535).

⛒ «НАДІСЛАНО» ТУТ НЕ КАЖЕ НІХТО. Платформа пошту не шле — конектор пошти має
права ЛИШЕ на читання, і це свідомий захист акаунта власника. Тому замовлення
має два чесні стани: «сформовано» і «передано поштовій програмі». Взяти на
себе чужий факт означало б збрехати в журналі.
"""
import json

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import doc_numbers as numbers     # ОДИН ПИСАР НОМЕРІВ ДОКУМЕНТІВ
import entity                     # спільне імʼя сутності на всю платформу
import file_store                 # ОДИН рушій файлового сховища
import one_writer
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій
import registry                   # ОДИН читач реєстру систем
import vendor                     # ОДИН писар «хто розробник»

config.refuse_live_state_for_checks(__name__)

# ⛒ Прайс ПРОДАВЦЯ — у теці платформи (їде зі збіркою), а не в теці стану,
# яку наповнює клієнт.
# 🩸 616: спершу прайс ліг у власну теку `shop/` — і НЕ ПОЇХАВ БИ В КЛІЄНТА
# ЗОВСІМ: складальник пакета везе з кореня платформи закритий перелік тек
# (`registry`, `config`, `templates`, `docs`, `generated_systems`), а нової
# теки він не знає. Клієнт дістав би магазин, який каже «прайсу немає на
# диску». Тому прайс живе там, де вже живе решта даних, що їдуть зі
# збіркою, — поруч із «хто розробник». Проба судить це деревом коду.
PRICE_JSON = config.PLATFORM_ROOT / "config" / "price.json"

# ⭐⭐⭐ 619: КАТАЛОГ ВИКОНАВЦЯ — ЩО Є У SENSFLOW.
# 🩸 Вада, яку це лікує (питання власника 20.09.2026): перелік систем
# рахувався з РЕЄСТРУ ЦІЄЇ МАШИНИ — тобто магазин показував те, що в
# людини ВЖЕ СТОЇТЬ. Докупити було можна лише наосліп — «ще одну
# систему», не бачачи, яку саме; а в клієнтській збірці складальник ріже
# реєстр під фактично передані системи — отже решти асортименту клієнт
# не побачив би ніде й ніколи.
# ⛒ КЛАС: ВІТРИНУ ПІДМІНЕНО СКЛАДОМ. Перелік того, що ПРОДАЄТЬСЯ,
# не сміє рахуватись із того, що вже КУПЛЕНЕ. Джерела два, і місцями їх
# міняти не можна: КАТАЛОГ каже, що є у SensFlow; РЕЄСТР каже, що
# стоїть у цього клієнта.
# ⛒ Лежить поруч із прайсом і з тієї самої причини (урок 616): складальник
# везе з кореня платформи ЗАКРИТИЙ перелік тек, і нової він не знає.
CATALOGUE_JSON = config.PLATFORM_ROOT / "config" / "catalogue.json"

# Замовлення — це вже СТАН цієї машини, тому воно живе там, де решта стану.
DIR = config.CRM_DIR
ORDERS_JSON = DIR / "shop_orders.json"

# ⛒ ЗАКРИТИЙ ПЕРЕЛІК ПОЛІВ РЯДКА ПРАЙСУ. Поле, якого тут немає, на екран не
# їде; поле, яке екран малює повз цей перелік, ловить проба (стеля споживача).
LEVEL_FIELDS = ("sku", "name", "unit", "price", "currency", "note", "group")

# ⛒ ЗАКРИТИЙ СЛОВНИК СТАНІВ. Слова «надіслано» тут немає й не буде, поки
# платформа не вміє надсилати сама.
STATE_FORMED = "formed"
STATE_HANDED = "handed_to_mail"
STATES = (STATE_FORMED, STATE_HANDED)
STATE_NAMES = {
    STATE_FORMED: "замовлення сформовано",
    STATE_HANDED: "передано поштовій програмі",
}

DEFAULT_CURRENCY = "грн"


class ShopError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ═══════════════════════════ ГРОШІ: ОДИН ЧИТАЧ ═════════════════════════════
# ⛒ Ціна лежить так, як її написала людина («45 000»). Читач один: два читачі
# розійшлися б на першому ж нерозривному пробілі.
_SPACES = (" ", " ", " ", " ")


def money(raw) -> int:
    """«45 000» → 45000. Сміття — ВІДМОВА СЛОВАМИ, а не тихий нуль."""
    t = _s(raw)
    for sp in _SPACES:
        t = t.replace(sp, "")
    t = t.replace(",", ".")
    if not t:
        raise ShopError("Ціна не названа — порахувати вартість немає з чого.")
    try:
        val = float(t)
    except ValueError:
        raise ShopError("Ціна «%s» не читається як число. Виправте її в прайсі — "
                        "вигадувати числа платформа не буде." % _s(raw))
    if val < 0:
        raise ShopError("Ціна «%s» відʼємна — так не буває." % _s(raw))
    return int(round(val))


def say_money(n) -> str:
    """Число → «45 000». Один писар на документ, екран і лист."""
    return "{:,}".format(int(n)).replace(",", " ")


# ═══════════════════════ ПРАЙС ПРОДАВЦЯ — З ДИСКА ══════════════════════════
def _price_raw() -> dict:
    try:
        d = json.loads(PRICE_JSON.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        raise ShopError("Прайсу немає на диску (%s) — магазину нема з чого "
                        "рахувати. Перевстановіть оновлення платформи."
                        % PRICE_JSON.name)
    except Exception as ex:
        raise ShopError("Прайс не читається: %s" % ex)
    if not isinstance(d, dict) or not isinstance(d.get("rows"), list):
        raise ShopError("Прайс має бути обʼєктом із переліком «rows».")
    return d


def currency() -> str:
    return _s(_price_raw().get("currency")) or DEFAULT_CURRENCY


def levels() -> list:
    """Платні рівні — рівно ті, що лежать у прайсі. Ні рядком більше."""
    cur = currency()
    out = []
    for r in _price_raw()["rows"]:
        if not isinstance(r, dict) or not _s(r.get("sku")):
            continue
        row = {k: _s(r.get(k)) for k in LEVEL_FIELDS}
        row["currency"] = row["currency"] or cur
        money(row["price"])            # ⛒ нечитабельна ціна кричить ТУТ, а не в кошику
        out.append(row)
    if not out:
        raise ShopError("У прайсі немає жодного рядка — показувати нічого.")
    return out


def level(sku) -> dict:
    k = _s(sku)
    for r in levels():
        if r["sku"] == k:
            return r
    return {}


# ════════════════════ СИСТЕМИ — З РЕЄСТРУ, А НЕ З ПАМʼЯТІ ══════════════════
def catalogue() -> list:
    """АСОРТИМЕНТ ВИКОНАВЦЯ — з власного файла, і нізвідки більше.

    ⛒ ТУТ НЕМАЄ ЖОДНОГО ЧИТАННЯ РЕЄСТРУ. Як тільки вітрина почне
    зазирати в те, що вже стоїть, вона знову стане складом."""
    try:
        d = json.loads(CATALOGUE_JSON.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        raise ShopError("Каталогу систем немає на диску (%s) — магазину нічого "
                        "показувати на вітрині. Перевстановіть оновлення платформи."
                        % CATALOGUE_JSON.name)
    except Exception as ex:
        raise ShopError("Каталог систем (%s) не читається: %s"
                        % (CATALOGUE_JSON.name, ex))
    if not isinstance(d, dict) or not isinstance(d.get("systems"), list):
        raise ShopError("Каталог систем має бути об’єктом із переліком «systems».")
    out = []
    for r in d["systems"]:
        if not isinstance(r, dict) or not _s(r.get("id")):
            continue
        out.append({"id": _s(r.get("id")),
                    "name": _s(r.get("name")) or _s(r.get("id")),
                    "description": _s(r.get("description")),
                    "category": _s(r.get("category")),
                    "sku": _s(r.get("sku"))})
    if not out:
        raise ShopError("У каталозі систем немає жодного рядка — показувати нічого.")
    return out


def installed() -> dict:
    """ЩО СТОЇТЬ У ЦЬОГО КЛІЄНТА — з реєстру на диску.

    ⛒ Беремо ПОВНИЙ реєстр, а не видимий перелік: система, яку
    вимкнули, не сміє зникнути мовчки — її треба ПОКАЗАТИ вимкненою
    (правило 616)."""
    out = {}
    for s in (registry.load_registry().get("systems") or []):
        if not isinstance(s, dict) or not _s(s.get("id")):
            continue
        out[_s(s.get("id"))] = s
    return out


def systems() -> list:
    """ВІТРИНА + СКЛАД ОДНИМ ПЕРЕЛІКОМ, і кожен рядок каже, чим є.

    ⛒ ДВА ДЖЕРЕЛА, ЩО НЕ ПІДМІНЯЮТЬ ОДНЕ ОДНОГО:
      • каталог виконавця — що можна купити (їде зі збіркою);
      • реєстр на диску — що стоїть у цього клієнта.
    ⛒ І ЗВОРОТНИЙ БІК: система, побудована ПІД КЛІЄНТА, у каталозі
    не значиться — і з екрана не зникає. Каталог ДОДАЄ вітрину, а не
    ріже склад."""
    have = installed()
    by_sku = {r["sku"]: r for r in levels()}
    rows, seen = [], set()
    for c in catalogue():
        sku = c["sku"]
        src = by_sku.get(sku)
        if not src:
            # ⛒ ТИХОГО РЯДКА БЕЗ ЦІНИ НЕ БУДЕ. Вітрина, яка не може
            # назвати ціну, гірша за чесну відмову.
            raise ShopError("У каталозі система «%s» посилається на артикул "
                            "«%s», якого немає в прайсі. Показати ціну немає з чого."
                            % (c["name"], sku or "«»"))
        row = dict(c)
        raw = have.get(c["id"])
        status = _s((raw or {}).get("status"))
        row["installed"] = raw is not None
        row["on"] = status == "active"
        row["status"] = status
        row["price"] = src["price"]
        row["currency"] = src["currency"]
        row["price_name"] = src["name"]
        if raw is not None:
            # ⛒ Назва й опис того, ЩО ВЖЕ СТОЇТЬ, беруться з реєстру:
            # у клієнта систему могли перейменувати під його процес.
            row["name"] = _s(raw.get("name")) or row["name"]
            row["description"] = _s(raw.get("description")) or row["description"]
        rows.append(row)
        seen.add(c["id"])
    for sid, raw in have.items():
        if sid in seen:
            continue
        status = _s(raw.get("status"))
        rows.append({"id": sid,
                     "name": _s(raw.get("name")) or sid,
                     "description": _s(raw.get("description")),
                     "category": _s(raw.get("category")),
                     "sku": "", "price": "", "currency": "",
                     "price_name": "",
                     "installed": True, "on": status == "active",
                     "status": status, "custom": True})
    return rows


def counted() -> dict:
    sys_rows = systems()
    return {
        "levels": len(levels()),
        "systems": len(sys_rows),
        "systems_on": len([s for s in sys_rows if s["on"]]),
        # ⭐ 619: два різні числа, бо це два різні питання:
        # що в мене є і що я можу докупити.
        "systems_installed": len([s for s in sys_rows if s.get("installed")]),
        "systems_available": len([s for s in sys_rows
                                  if not s.get("installed")]),
    }


def offer() -> dict:
    """ПРОПОЗИЦІЯ ЦІЛКОМ — усе, що малює екран. Екран сам нічого не знає."""
    return {
        "vendor": vendor.info(),
        "vendor_known": vendor.known(),
        "vendor_missing": vendor.missing(),
        "currency": currency(),
        "levels": levels(),
        "systems": systems(),
        "counted": counted(),
        "level_fields": list(LEVEL_FIELDS),
        "counted_at": clock.now(),
        "sources": [
            {"what": "прайс виконавця", "path": str(PRICE_JSON)},
            {"what": "каталог систем виконавця", "path": str(CATALOGUE_JSON)},
            {"what": "реєстр систем цієї машини", "path": str(config.REGISTRY_JSON)},
        ],
    }


# ═════════════════════════════ КОШИК І ПІДСУМОК ════════════════════════════
def quote(picks) -> dict:
    """Порахувати кошик. Невідомий артикул чи кількість — ВІДМОВА СЛОВАМИ."""
    rows, total = [], 0
    if not picks:
        raise ShopError("У замовленні немає жодної позиції — замовляти нічого.")
    by_sku = {r["sku"]: r for r in levels()}
    for p in picks:
        sku = _s((p or {}).get("sku"))
        src = by_sku.get(sku)
        if not src:
            raise ShopError("Артикула «%s» немає в прайсі. Замовити те, чого не "
                            "продають, платформа не дасть." % (sku or "«»"))
        raw_qty = (p or {}).get("qty")
        # ⛒ «or 1» тут була б дірою: нуль — теж названа кількість, і мовчки
        # перетворити його на одиницю означало б продати те, чого не просили.
        raw_qty = "1" if raw_qty is None or _s(raw_qty) == "" else _s(raw_qty)
        try:
            qty = int(raw_qty)
        except ValueError:
            raise ShopError("Кількість «%s» для «%s» не читається як число."
                            % ((p or {}).get("qty"), src["name"]))
        if qty <= 0:
            raise ShopError("Кількість для «%s» — %d. Нуль позицій це не "
                            "замовлення." % (src["name"], qty))
        price = money(src["price"])
        line = price * qty
        total += line
        rows.append({"sku": sku, "name": src["name"], "unit": src["unit"],
                     "qty": qty, "price": price, "sum": line})
    return {"rows": rows, "total": total, "currency": currency()}


# ═══════════════════════ ЗАМОВЛЕННЯ — ДОКУМЕНТ ПЛАТФОРМИ ═══════════════════
def _load() -> dict:
    try:
        d = one_writer.read_json(ORDERS_JSON)
    except PermissionError:
        raise
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("orders", {})
    d.setdefault("seq", 0)
    return d


def _save(d: dict) -> None:
    DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(ORDERS_JSON, d)


def _new_id(d: dict) -> str:
    seq = int(d.get("seq") or 0) + 1
    while ("zam%04d" % seq) in d["orders"]:
        seq += 1
    d["seq"] = seq
    return "zam%04d" % seq


def _buyer_name() -> str:
    """Чиє це замовлення — назвою компанії. ОДИН писар, і він у оргструктурі."""
    try:
        import taskdesk_people as _tp
        return _s(_tp.company_name())
    except Exception:
        return ""


def paper(row: dict) -> str:
    """ТЕКСТ ЗАМОВЛЕННЯ — один писар на файл, на лист і на екран."""
    v = row.get("vendor") or {}
    out = ["# ЗАМОВЛЕННЯ № %s від %s" % (row["number"], row["date"]), ""]
    if _s(row.get("buyer")):
        # ⛒ 618/619: ТУТ «ПОКУПЕЦЬ», А НЕ «ЗАМОВНИК», і це не стилістика.
        # Слово «замовник» із двокрапкою — мітка ТЕНДЕРНОГО тексту,
        # і складати його вміє
        # рівно один писар (`tender_message`); сторож цього правила
        # червонів від 20.09.2026 (616), і червона стояла непоміченою.
        # У замовленні на купівлю сторона й зветься покупцем — так
        # чесніше й точніше, а сторож лишається суворим.
        out += ["**Покупець:** " + _s(row["buyer"])]
    out += ["**Виконавець:** " + (_s(v.get("name")) or "не названий"), ""]
    out += ["| № | Артикул | Що замовляємо | Од. | Ціна | К-сть | Сума |",
            "|---|---|---|---|---|---|---|"]
    for i, r in enumerate(row["rows"], 1):
        out.append("| %d | %s | %s | %s | %s | %d | %s |"
                   % (i, r["sku"], r["name"], r["unit"] or "шт",
                      say_money(r["price"]), r["qty"], say_money(r["sum"])))
    out += ["", "**Разом: %s %s**" % (say_money(row["total"]), row["currency"]), ""]
    if _s(row.get("note")):
        out += ["**Примітка покупця:** " + _s(row["note"]), ""]
    out += ["---", "",
            "Замовлення сформувала платформа SensFlow — номер видано реєстром "
            "документів, файл лежить у сховищі платформи."]
    return "\n".join(out)


def order(picks, by: str = "", note: str = "") -> dict:
    """Сформувати замовлення: порахувати, дати номер, покласти файл у сховище.

    ⛒ СПЕРШУ ПЕРЕВІРЯЄМО ВСЕ, ПОТІМ ПИШЕМО. І порядок кроків не випадковий:
    спершу ФАЙЛ, потім НОМЕР. Номер із реєстру не повертається ніколи, тому
    взяти його першим означало б палити номер на кожній невдалій спробі."""
    q = quote(picks)
    today = numbers.today()
    row = {
        "id": "",
        "number": "",
        "date": today,
        "rows": q["rows"],
        "total": q["total"],
        "currency": q["currency"],
        "vendor": vendor.info(),
        "buyer": _buyer_name(),
        "note": _s(note),
        "by": _s(by),
        "state": STATE_FORMED,
        "created": clock.now(),
    }

    d = _load()
    oid = _new_id(d)
    row["id"] = oid

    # 1. Файл. Номер у тексті ще не стоїть — ставимо його після видачі.
    what = "замовлення розробнику"
    num = numbers.issue(today, what)
    row["number"] = num
    body = paper(row).encode("utf-8")
    name = "Замовлення № %s від %s.md" % (num, today)
    try:
        blob = file_store.put(body, name, by=_s(by))
    except Exception as ex:
        raise ShopError("Замовлення № %s не збережено у сховищі: %s. Номер уже "
                        "виданий і вдруге не видається — наступна спроба дістане "
                        "новий." % (num, ex))
    row["file_id"] = _s(blob.get("id"))
    row["file_name"] = _s(blob.get("name")) or name

    d["orders"][oid] = row
    _save(d)
    _say(oid, protocol.A_SHOP_ORDER,
         "замовлення № %s на %s %s (позицій: %d)"
         % (num, say_money(row["total"]), row["currency"], len(row["rows"])))
    return dict(row)


def orders() -> list:
    out = [dict(v) for v in _load()["orders"].values()]
    out.sort(key=lambda x: (_s(x.get("created")), _s(x.get("id"))), reverse=True)
    return out


def get(oid) -> dict:
    return dict(_load()["orders"].get(_s(oid)) or {})


def _say(oid, action, note) -> None:
    """Слід у ЗАГАЛЬНОМУ журналі. Ніколи не валить роботу."""
    try:
        protocol.write(action, entity.ref(entity.KIND_ORDER, _s(oid)), note=note)
    except Exception:
        pass


# ═══════════════════════════ ДОСТАВКА РОЗРОБНИКОВІ ═════════════════════════
def letter(oid) -> dict:
    """Готовий лист розробникові: кому, тема, текст.

    ⛒ Нічого не надсилає. Конектор пошти має права ЛИШЕ на читання — це
    свідомий захист акаунта власника, а не недогляд. Тому лист формує
    платформа, а надсилає поштова програма людини одним кліком."""
    row = get(oid)
    if not row:
        raise ShopError("Замовлення %s немає." % (_s(oid) or "«»"))
    if not vendor.known():
        raise ShopError("Не названо, кому надсилати: бракує %s. Адреса "
                        "розробника їде зі збіркою — оновіть платформу або "
                        "спитайте виконавця." % ", ".join(vendor.missing()))
    v = vendor.info()
    subject = "Замовлення № %s%s" % (row["number"],
                                     (" — " + row["buyer"]) if row.get("buyer") else "")
    return {"to": v["email"], "subject": subject, "body": paper(row),
            "order": row["id"], "number": row["number"]}


def note_handed(oid, by: str = "") -> dict:
    """Слід: замовлення ПЕРЕДАНО поштовій програмі.

    ⛒ Саме «передано», а не «надіслано»: натискає «Надіслати» людина, і брати
    на себе чужий факт платформа не буде."""
    d = _load()
    row = d["orders"].get(_s(oid))
    if not row:
        raise ShopError("Замовлення %s немає." % (_s(oid) or "«»"))
    row["state"] = STATE_HANDED
    row["handed_at"] = clock.now()
    row["handed_by"] = _s(by)
    _save(d)
    _say(_s(oid), protocol.A_SHOP_HANDED,
         "замовлення № %s передано поштовій програмі" % row["number"])
    return dict(row)
