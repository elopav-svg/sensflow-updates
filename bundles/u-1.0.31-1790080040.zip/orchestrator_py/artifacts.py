"""
artifacts.py — рендер результату у файли: .md, .html (завжди, stdlib),
.docx (якщо встановлено python-docx), .xlsx (якщо є markdown-таблиці й openpyxl),
.csv (fallback для таблиць без openpyxl).

Опційні залежності визначаються під час виконання — рушій працює і без них.
"""

import re
import csv
import io
import html as _html
import os

import origin        # ⛒ один писар походження документа (583)
import store


def table_cell(v):
    """ОДИН ПИСАР КЛІТИНКИ MARKDOWN-ТАБЛИЦІ НА ВЕСЬ ПРОДУКТ.

    ⭐⭐⭐ 02.08.2026, спіймано на живому прогоні клієнта. Прозорро віддало імʼя
    переможця блоком із переносами `\r`. Рядок таблиці розірвався, і все, що
    було НИЖЧЕ, випало з .xlsx: у звіті 57 рядків, у файлі клієнта — 52.
    ТИХА ВТРАТА П'ЯТИ РЯДКІВ — найгірший вид невдачі.
    Той самий клас жив ще у двох місцях (юрист і його експорт), де прибирання
    не було взагалі. Тому писар ОДИН і живе тут, у власника таблиць.

    `split()` без аргументів ріже ВСІ пробільні символи (`\r`, `\n`, `\t`,
    `\x0b`, `\x0c`, `\x85`, `\u2028`, `\u2029`), тож новий вид переносу з
    джерела вже не пройде. Вертикальна риска стає скісною, щоб не розрізати
    рядок на зайві колонки.
    """
    s = ("" if v is None else str(v)).replace("|", "/")
    s = " ".join(s.split())
    return s or "—"

# Опційні бібліотеки
try:
    import docx  # python-docx
    from docx.shared import Pt
    _HAS_DOCX = True
except Exception:
    _HAS_DOCX = False

try:
    import openpyxl
    _HAS_XLSX = True
except Exception:
    _HAS_XLSX = False

try:
    import pptx  # python-pptx
    from pptx.util import Inches, Pt as PptPt
    _HAS_PPTX = True
except Exception:
    _HAS_PPTX = False


def capabilities() -> dict:
    return {"docx": _HAS_DOCX, "xlsx": _HAS_XLSX, "pptx": _HAS_PPTX}


# ---------------------------------------------------------------------------
# Бренд-активи рушія: ЄДИНЕ ДЖЕРЕЛО поруч із кодом (orchestrator_py/assets/brand/).
# Так лого доступне і локально, і в клієнтських збірках — без залежності від теки сайту.
# ---------------------------------------------------------------------------
_BRAND_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "brand")


def _brand_asset(name: str):
    """Абсолютний шлях до бренд-файлу поруч із рушієм, або None якщо його нема (fail-safe)."""
    p = os.path.join(_BRAND_DIR, name)
    return p if os.path.exists(p) else None


# ---------------------------------------------------------------------------
# Markdown utils
# ---------------------------------------------------------------------------
def _inline(text: str) -> str:
    t = _html.escape(text)
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', t)
    return t


def extract_tables(md: str):
    """Повертає список таблиць: [{'headers':[...], 'rows':[[...],...]}]."""
    tables = []
    lines = md.splitlines()
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if line.startswith("|") and i + 1 < len(lines) and re.match(r"^\|?[\s:\-|]+\|?$", lines[i + 1].strip()):
            headers = [c.strip() for c in line.strip("|").split("|")]
            rows = []
            j = i + 2
            while j < len(lines) and lines[j].strip().startswith("|"):
                cells = [c.strip() for c in lines[j].strip().strip("|").split("|")]
                rows.append(cells)
                j += 1
            tables.append({"headers": headers, "rows": rows})
            i = j
        else:
            i += 1
    return tables


_HTML_BRAND_HEADER = (
    '<div style="display:flex;align-items:center;gap:5px;margin:0 0 12px 0;padding-bottom:7px;border-bottom:1px solid #E3E9EF"><svg width="15" height="15" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="SensFlow"><defs><linearGradient id="sfbrand" gradientUnits="userSpaceOnUse" x1="13" y1="88" x2="86" y2="20"><stop offset="0" stop-color="#FF7A3C"/><stop offset="0.16" stop-color="#FFB05A"/><stop offset="0.40" stop-color="#1FC4D4"/><stop offset="0.60" stop-color="#1FC4D4"/><stop offset="0.84" stop-color="#FFB05A"/><stop offset="1" stop-color="#FF7A3C"/></linearGradient></defs><path fill="url(#sfbrand)" d="M 60.07 52.9 L 31.01 31.98 L 40.01 24.47 L 69.19 24.47 L 69.19 8 L 89.24 18.03 L 69.19 28.05 L 69.19 11.58 L 35.35 11.58 L 9.98 32.72 L 52.53 63.36 Z"/><path fill="url(#sfbrand)" d="M 42.41 37.51 L 71.28 59.16 L 68.85 61.99 L 24.15 66.32 L 10.98 84.42 L 21.41 92 L 31.16 78.59 L 75.26 74.32 L 90.02 57.1 L 50.14 27.19 Z"/></svg><span style="font-family:\'Space Grotesk\',\'Segoe UI\',system-ui,sans-serif;font-size:12px;font-weight:500;color:#16202B;letter-spacing:.2px">Sens<span style="font-weight:700">Flow</span></span></div>'
)


def md_to_html(md: str, title: str = "Результат", brand: bool = True) -> str:
    out = []
    in_ul = False
    in_table = False
    lines = md.splitlines()
    i = 0

    def close_ul():
        nonlocal in_ul
        if in_ul:
            out.append("</ul>")
            in_ul = False

    while i < len(lines):
        line = lines[i]
        s = line.strip()
        # table
        if s.startswith("|") and i + 1 < len(lines) and re.match(r"^\|?[\s:\-|]+\|?$", lines[i + 1].strip()):
            close_ul()
            headers = [c.strip() for c in s.strip("|").split("|")]
            out.append("<table><thead><tr>" + "".join(f"<th>{_inline(h)}</th>" for h in headers) + "</tr></thead><tbody>")
            j = i + 2
            while j < len(lines) and lines[j].strip().startswith("|"):
                cells = [c.strip() for c in lines[j].strip().strip("|").split("|")]
                out.append("<tr>" + "".join(f"<td>{_inline(c)}</td>" for c in cells) + "</tr>")
                j += 1
            out.append("</tbody></table>")
            i = j
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            close_ul()
            lvl = len(m.group(1))
            out.append(f"<h{lvl}>{_inline(m.group(2))}</h{lvl}>")
        elif re.match(r"^[-*]\s+", s):
            if not in_ul:
                out.append("<ul>")
                in_ul = True
            out.append(f"<li>{_inline(s[2:])}</li>")
        elif s == "":
            close_ul()
        else:
            close_ul()
            out.append(f"<p>{_inline(s)}</p>")
        i += 1
    close_ul()

    body = "\n".join(out)
    return (
        "<!DOCTYPE html><html lang='uk'><head><meta charset='utf-8'>"
        f"<title>{_html.escape(title)}</title>"
        "<style>body{font-family:Segoe UI,system-ui,sans-serif;max-width:820px;margin:40px auto;"
        "padding:0 20px;line-height:1.6;color:#1a1a1a}h1,h2,h3{line-height:1.25}"
        "table{border-collapse:collapse;width:100%;margin:16px 0}th,td{border:1px solid #ccc;padding:7px 10px;text-align:left}"
        "th{background:#f4f6f8}code{background:#f0f2f4;padding:1px 5px;border-radius:4px}"
        "a{color:#2563eb}</style></head><body>" + (_HTML_BRAND_HEADER if brand else "") + body + "</body></html>"
    )


# ---------------------------------------------------------------------------
# DOCX
# ---------------------------------------------------------------------------
# Бренд-палітра SensFlow для друкованих документів (читабельна на білому).
_DOCX_INK = (0x16, 0x1F, 0x2B)        # графіт-навігація (основний текст/H1/H3)
_DOCX_ACCENT = (0x0E, 0x6E, 0x78)     # глибокий бірюзовий акцент (H2)
_DOCX_MUTED = (0x8A, 0x93, 0xA0)      # приглушений сірий (футер/підписи)
_DOCX_HEADFILL = "EDF1F5"             # світла заливка шапки таблиці


def _docx_set_defaults(document):
    """Професійна типографіка: шрифт, кеглі, кольори заголовків."""
    try:
        from docx.shared import Pt, RGBColor
        normal = document.styles["Normal"]
        normal.font.name = "Calibri"
        normal.font.size = Pt(10.5)
        normal.font.color.rgb = RGBColor(*_DOCX_INK)
        pf = normal.paragraph_format
        pf.line_spacing = 1.15
        pf.space_after = Pt(6)
        heads = {"Heading 1": (_DOCX_INK, 18), "Heading 2": (_DOCX_ACCENT, 13.5),
                 "Heading 3": (_DOCX_INK, 11.5), "Heading 4": (_DOCX_MUTED, 10.5)}
        for name, (col, sz) in heads.items():
            try:
                st = document.styles[name]
                st.font.name = "Calibri"
                st.font.bold = True
                st.font.size = Pt(sz)
                st.font.color.rgb = RGBColor(*col)
                st.paragraph_format.space_before = Pt(10)
                st.paragraph_format.space_after = Pt(4)
            except Exception:
                pass
    except Exception:
        pass


def _docx_add_rich(paragraph, text):
    """Рендерить **жирний** як bold-runs; прибирає `беклапки` коду."""
    text = re.sub(r"`([^`]*)`", r"\1", text or "")
    for part in re.split(r"(\*\*[^*]+\*\*)", text):
        if not part:
            continue
        if part.startswith("**") and part.endswith("**") and len(part) > 4:
            paragraph.add_run(part[2:-2]).bold = True
        else:
            paragraph.add_run(part)


def _docx_shade(cell, hex_fill):
    try:
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
        shd = OxmlElement("w:shd")
        shd.set(qn("w:val"), "clear")
        shd.set(qn("w:fill"), hex_fill)
        cell._tc.get_or_add_tcPr().append(shd)
    except Exception:
        pass


def _docx_footer(document):
    """Футер: «SensFlow · конфіденційно» ліворуч + номер сторінки праворуч."""
    try:
        from docx.shared import Pt, RGBColor
        from docx.oxml.ns import qn
        from docx.oxml import OxmlElement
        sec = document.sections[0]
        p = sec.footer.paragraphs[0]
        p.text = ""
        r1 = p.add_run("SensFlow · конфіденційно")
        r1.font.size = Pt(8); r1.font.color.rgb = RGBColor(*_DOCX_MUTED)
        p.add_run("\t\t").font.size = Pt(8)
        rp = p.add_run()
        rp.font.size = Pt(8); rp.font.color.rgb = RGBColor(*_DOCX_MUTED)
        for tag, attr, val in (("w:fldChar", "w:fldCharType", "begin"),):
            el = OxmlElement(tag); el.set(qn(attr), val); rp._r.append(el)
        instr = OxmlElement("w:instrText"); instr.set(qn("xml:space"), "preserve")
        instr.text = "PAGE"; rp._r.append(instr)
        end = OxmlElement("w:fldChar"); end.set(qn("w:fldCharType"), "end"); rp._r.append(end)
    except Exception:
        pass


def _docx_header_logo(document):
    """Фірмовий бланк: локап SensFlow у шапці першої секції — ліворуч, ~1.1 см заввишки.
    Fail-safe: якщо файлу/бібліотеки нема або стався збій — документ зберігається БЕЗ лого,
    жоден зі сценаріїв 22 систем не падає."""
    try:
        from docx.shared import Cm
        logo = _brand_asset("lockup-light.png")
        if not logo:
            return
        sec = document.sections[0]
        hdr = sec.header
        hdr.is_linked_to_previous = False
        p = hdr.paragraphs[0] if hdr.paragraphs else hdr.add_paragraph()
        p.text = ""
        p.add_run().add_picture(logo, height=Cm(1.1))
    except Exception:
        pass


def md_to_docx(md: str, path):
    if not _HAS_DOCX:
        return False
    document = docx.Document()
    _docx_set_defaults(document)
    _docx_footer(document)
    _docx_header_logo(document)
    lines = md.splitlines()
    i = 0
    while i < len(lines):
        s = lines[i].strip()
        if s.startswith("|") and i + 1 < len(lines) and re.match(r"^\|?[\s:\-|]+\|?$", lines[i + 1].strip()):
            headers = [c.strip() for c in s.strip("|").split("|")]
            rows = []
            j = i + 2
            while j < len(lines) and lines[j].strip().startswith("|"):
                rows.append([c.strip() for c in lines[j].strip().strip("|").split("|")])
                j += 1
            table = document.add_table(rows=1, cols=len(headers))
            try:
                table.style = "Light List Accent 1"
            except Exception:
                pass
            for k, h in enumerate(headers):
                cell = table.rows[0].cells[k]
                cell.text = ""
                _docx_add_rich(cell.paragraphs[0], re.sub(r"\*\*", "", h))
                for run in cell.paragraphs[0].runs:
                    run.bold = True
                _docx_shade(cell, _DOCX_HEADFILL)
            for r in rows:
                cells = table.add_row().cells
                for k, val in enumerate(r[:len(headers)]):
                    cells[k].text = ""
                    _docx_add_rich(cells[k].paragraphs[0], val)
            document.add_paragraph()
            i = j
            continue
        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            document.add_heading(re.sub(r"\*\*|`", "", m.group(2)), level=min(len(m.group(1)), 4))
        elif re.match(r"^>\s?", s):
            para = document.add_paragraph(style="Intense Quote" if "Intense Quote" in [st.name for st in document.styles] else None)
            _docx_add_rich(para, re.sub(r"^>\s?", "", s))
        elif re.match(r"^\d+\.\s+", s):
            para = document.add_paragraph(style="List Number")
            _docx_add_rich(para, re.sub(r"^\d+\.\s+", "", s))
        elif re.match(r"^[-*]\s+", s):
            para = document.add_paragraph(style="List Bullet")
            _docx_add_rich(para, s[2:])
        elif s:
            para = document.add_paragraph()
            _docx_add_rich(para, s)
        i += 1
    document.save(str(path))
    origin.stamp(path)   # ⛒ 583: ОДИН писар походження на всі виходи
    return True


# ---------------------------------------------------------------------------
# PPTX (презентації)
# ---------------------------------------------------------------------------
def _md_to_slides(md: str):
    """Розбиває markdown на слайди за заголовками. Повертає [(title, [bullets])]."""
    slides = []
    title, bullets = None, []
    for raw in md.splitlines():
        s = raw.strip()
        h = re.match(r"^(#{1,3})\s+(.*)$", s)
        if h:
            if title is not None or bullets:
                slides.append((title or "Слайд", bullets))
            title = re.sub(r"\*\*|`", "", h.group(2)).strip()
            bullets = []
        elif re.match(r"^[-*]\s+", s):
            bullets.append(re.sub(r"\*\*|`", "", s[2:]).strip())
        elif s:
            bullets.append(re.sub(r"\*\*|`", "", s).strip())
    if title is not None or bullets:
        slides.append((title or "Слайд", bullets))
    return slides


def md_to_pptx(md: str, path, deck_title: str = "Презентація") -> bool:
    if not _HAS_PPTX:
        return False
    from pptx.util import Inches
    prs = pptx.Presentation()
    slides = _md_to_slides(md)
    lockup = _brand_asset("lockup-light.png")   # титул: знак + напис
    mark = _brand_asset("sensflow-mark-faint.png")  # контент: водяний знак у кут
    sw, sh = prs.slide_width, prs.slide_height
    # Титульний слайд
    title_layout = prs.slide_layouts[0]
    s0 = prs.slides.add_slide(title_layout)
    s0.shapes.title.text = slides[0][0] if slides else deck_title
    # Локап угорі титулу; підпис «SensFlow» тоді зайвий (локап його вже містить).
    try:
        s0.placeholders[1].text = "" if lockup else "SensFlow"
    except Exception:
        pass
    if lockup:
        try:
            s0.shapes.add_picture(lockup, Inches(0.5), Inches(0.4), width=Inches(2.4))
        except Exception:
            pass
    # Контентні слайди
    content_layout = prs.slide_layouts[1]
    for title, bullets in (slides[1:] if len(slides) > 1 else slides):
        sl = prs.slides.add_slide(content_layout)
        sl.shapes.title.text = title[:120]
        body = sl.placeholders[1].text_frame
        body.clear()
        for i, b in enumerate(bullets[:12]):
            p = body.paragraphs[0] if i == 0 else body.add_paragraph()
            p.text = b[:300]
        if mark:   # маленький знак у нижній правий кут (fail-safe)
            try:
                mw = Inches(0.32)
                sl.shapes.add_picture(mark, sw - mw - Inches(0.28),
                                      sh - mw - Inches(0.24), width=mw)
            except Exception:
                pass
    prs.save(str(path))
    origin.stamp(path)   # ⛒ 583: ОДИН писар походження на всі виходи
    return True


def looks_like_presentation(task: str, md: str) -> bool:
    blob = ((task or "") + " " + (md or "")[:200]).lower()
    if any(k in blob for k in ("презентаці", "слайд", "slide", "powerpoint", "pptx",
                               "доповідь", "presentation", "deck", "питч", "pitch")):
        return True
    return False


# ---------------------------------------------------------------------------
# Витяг повноцінного HTML-документа (презентація/дашборд із графіками)
# ---------------------------------------------------------------------------
_FENCE_HTML_RE = re.compile(r"```+[ \t]*html[ \t]*\r?\n(.*?)```+", re.S | re.I)
_FENCE_ANY_RE = re.compile(r"```+[ \t]*\r?\n(.*?)```+", re.S)
_HTML_DOC_HINT = re.compile(r"<!DOCTYPE html|<html[\s>]", re.I)
_HTML_VIS_HINT = re.compile(r"<canvas|<svg|new\s+Chart|chart\.js|Chart\s*\(", re.I)


# Запобіжник «розтягнутого» дашборда: стеля висоти полотен графіків + адекватні
# контейнери. Без цього Chart.js росте безконтрольно і дашборд не вміщається в екран.
_CHART_SAFETY_CSS = (
    "<style>"
    "canvas{max-height:60vh!important;max-width:100%!important;height:auto!important}"
    ".chart,.chart-container,.chart-box,.chart-wrap,.canvas-wrap{"
    "position:relative;max-height:60vh!important;overflow:hidden}"
    "</style>"
)


def _inject_chart_safety(html_text: str) -> str:
    """Вшиває стелю висоти графіків у готовий HTML-документ (перед </head>)."""
    if not html_text or "canvas" not in html_text.lower():
        return html_text
    if "max-height:60vh" in html_text:
        return html_text
    m = re.search(r"</head\s*>", html_text, re.I)
    if m:
        return html_text[:m.start()] + _CHART_SAFETY_CSS + html_text[m.start():]
    m = re.search(r"<body[^>]*>", html_text, re.I)
    if m:
        return html_text[:m.end()] + _CHART_SAFETY_CSS + html_text[m.end():]
    return _CHART_SAFETY_CSS + html_text


def _html_to_text(html_text: str) -> str:
    """Грубий витяг читабельного тексту з HTML (для наповнення .md/.docx, коли весь
    зміст пішов у HTML-дашборд). Викидає скрипти/стилі, теги → текст."""
    t = re.sub(r"(?is)<(script|style)[^>]*>.*?</\1>", " ", html_text or "")
    t = re.sub(r"(?is)<br\s*/?>", "\n", t)
    t = re.sub(r"(?is)</(p|div|section|article|h[1-6]|li|tr|table|ul|ol)>", "\n", t)
    t = re.sub(r"(?is)<li[^>]*>", "- ", t)
    t = re.sub(r"(?is)<h[1-6][^>]*>", "\n## ", t)
    t = re.sub(r"(?is)<[^>]+>", " ", t)
    t = _html.unescape(t)
    lines = [re.sub(r"[ \t]+", " ", ln).strip() for ln in t.splitlines()]
    return "\n".join(ln for ln in lines if ln)


def _wrap_html_fragment(frag: str) -> str:
    """Загорнути HTML-фрагмент у мінімальний каркас; підключити Chart.js, якщо потрібно."""
    low = frag.lower()
    needs_chart = ("chart(" in low or "new chart" in low) and "chart.js" not in low and "cdn" not in low
    cdn = "<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>" if needs_chart else ""
    return ("<!DOCTYPE html><html lang='uk'><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width,initial-scale=1'>"
            "<title>Презентація</title>" + cdn + _CHART_SAFETY_CSS + "</head><body>" + frag + "</body></html>")


def extract_html_document(md: str):
    """Якщо результат містить повноцінний HTML-документ у code-fence (інтерактивна
    презентація/дашборд із графіками), повертає (html_text, md_без_цього_блоку).
    Інакше (None, md). Так HTML стає РЕАЛЬНИМ відкриваним файлом, а не кодом у тексті."""
    if not md or "```" not in md:
        return None, md
    candidates = list(_FENCE_HTML_RE.finditer(md))
    if not candidates:
        candidates = [m for m in _FENCE_ANY_RE.finditer(md)
                      if _HTML_DOC_HINT.search(m.group(1) or "") or _HTML_VIS_HINT.search(m.group(1) or "")]
    best = None
    for m in candidates:
        inner = (m.group(1) or "").strip()
        if not (_HTML_DOC_HINT.search(inner) or _HTML_VIS_HINT.search(inner)):
            continue
        if best is None or len(inner) > len(best.group(1)):
            best = m
    if not best:
        return None, md
    html_text = (best.group(1) or "").strip()
    if not _HTML_DOC_HINT.search(html_text):
        html_text = _wrap_html_fragment(html_text)
    md_clean = (md[:best.start()].rstrip()
                + "\n\n*(Інтерактивна презентація з графіками — у файлі .html нижче.)*\n\n"
                + md[best.end():].lstrip()).strip()
    return html_text, md_clean


# ---------------------------------------------------------------------------
# Графіки як ДАНІ → платформа сама рендерить дашборд (контракт «дані → рендер»)
# ---------------------------------------------------------------------------
_CHART_FENCE_RE = re.compile(r"```+[ \t]*chart[ \t]*\r?\n(.*?)```+", re.S | re.I)
_CHART_PALETTE = ["#0E6E78", "#2563EB", "#F59E0B", "#10B981", "#EF4444",
                  "#8B5CF6", "#14B8A6", "#E11D48", "#0EA5E9", "#84CC16"]


def _parse_chart_spec(raw: str):
    import json
    try:
        spec = json.loads(raw)
    except Exception:
        return None
    if not isinstance(spec, dict):
        return None
    ctype = str(spec.get("type", "bar")).lower()
    if ctype not in ("bar", "line", "pie", "doughnut"):
        ctype = "bar"
    labels = [str(x) for x in (spec.get("labels") or [])]
    series = []
    for s in (spec.get("series") or []):
        if isinstance(s, dict):
            series.append({"name": str(s.get("name", "")), "data": list(s.get("data") or [])})
        elif isinstance(s, (list, tuple)):
            series.append({"name": "", "data": list(s)})
    if not labels or not series:
        return None
    return {"type": ctype, "title": str(spec.get("title", "")), "labels": labels, "series": series}


def _chart_to_md_table(spec: dict) -> str:
    """Дані графіка → Markdown-таблиця (ті самі числа потрапляють у звіт/.docx/.xlsx)."""
    cols = [spec["title"] or "Категорія"] + [s["name"] or f"Ряд {i+1}" for i, s in enumerate(spec["series"])]
    head = "| " + " | ".join(cols) + " |"
    sep = "| " + " | ".join(["---"] * len(cols)) + " |"
    rows = []
    for i, lab in enumerate(spec["labels"]):
        cells = [lab] + [str(s["data"][i]) if i < len(s["data"]) else "" for s in spec["series"]]
        rows.append("| " + " | ".join(cells) + " |")
    cap = f"**{spec['title']}**\n\n" if spec["title"] else ""
    return cap + head + "\n" + sep + "\n" + "\n".join(rows)


def extract_charts(md: str):
    """Виймає блоки ```chart (JSON-дані графіків). Повертає (список_специфікацій,
    md_із_заміненими_блоками_на_таблиці-даних). Так графіки стають ДАНИМИ, а не кодом."""
    specs = []

    def _repl(m):
        spec = _parse_chart_spec((m.group(1) or "").strip())
        if not spec:
            return ""
        specs.append(spec)
        return _chart_to_md_table(spec)

    md2 = _CHART_FENCE_RE.sub(_repl, md or "")
    return specs, md2


def _chart_js(cid: str, spec: dict) -> str:
    import json
    is_pie = spec["type"] in ("pie", "doughnut")
    datasets = []
    for i, s in enumerate(spec["series"]):
        color = _CHART_PALETTE[i % len(_CHART_PALETTE)]
        if is_pie:
            datasets.append({"label": s["name"], "data": s["data"],
                             "backgroundColor": _CHART_PALETTE[:len(spec["labels"])]})
        else:
            datasets.append({"label": s["name"] or f"Ряд {i+1}", "data": s["data"],
                             "backgroundColor": color, "borderColor": color,
                             "borderWidth": 2, "fill": False, "tension": 0.3})
    options = {"responsive": True, "maintainAspectRatio": False,
               "plugins": {"legend": {"display": bool(is_pie or len(spec["series"]) > 1)}}}
    if not is_pie:
        options["scales"] = {"y": {"beginAtZero": True}}
    cfg = {"type": spec["type"], "data": {"labels": spec["labels"], "datasets": datasets},
           "options": options}
    return f"new Chart(document.getElementById('{cid}'),{json.dumps(cfg, ensure_ascii=False)});"


def render_dashboard_html(report_md: str, charts: list, title: str = "Дашборд") -> str:
    """Платформа сама будує дашборд: графіки зі сталим КОРЕКТНИМ конфігом (фіксована
    висота, авто-масштаб осей) + повний текстовий звіт під ними. Модель HTML НЕ пише."""
    report_html = md_to_html(report_md, title, brand=False)
    m = re.search(r"<body>(.*)</body>", report_html, re.S)
    report_body = m.group(1) if m else report_html
    blocks, scripts = [], []
    for idx, spec in enumerate(charts):
        cid = f"chart{idx}"
        cap = _html.escape(spec["title"] or "Графік")
        blocks.append(f"<figure class='cardchart'><figcaption>{cap}</figcaption>"
                      f"<div class='cwrap'><canvas id='{cid}'></canvas></div></figure>")
        scripts.append(_chart_js(cid, spec))
    charts_html = ("<section class='charts'>" + "".join(blocks) + "</section>") if blocks else ""
    return (
        "<!DOCTYPE html><html lang='uk'><head><meta charset='utf-8'>"
        "<meta name='viewport' content='width=device-width,initial-scale=1'>"
        f"<title>{_html.escape(title)}</title>"
        "<script src='https://cdn.jsdelivr.net/npm/chart.js'></script>"
        "<style>"
        "body{font-family:Segoe UI,system-ui,sans-serif;max-width:1040px;margin:32px auto;"
        "padding:0 20px;line-height:1.6;color:#16202B}"
        "h1{line-height:1.2}h2{color:#0E6E78;line-height:1.25}h3{line-height:1.25}"
        "table{border-collapse:collapse;width:100%;margin:14px 0}"
        "th,td{border:1px solid #D6DDE5;padding:7px 10px;text-align:left}th{background:#EEF3F7}"
        ".charts{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px;margin:20px 0}"
        ".cardchart{margin:0;padding:14px;border:1px solid #E3E9EF;border-radius:12px;"
        "background:#fff;box-shadow:0 2px 10px rgba(0,0,0,.04)}"
        ".cardchart figcaption{font-weight:600;margin-bottom:8px;color:#0E6E78}"
        ".cwrap{position:relative;height:340px}canvas{max-height:340px!important}"
        "a{color:#2563EB}"
        "</style></head><body>"
        + _HTML_BRAND_HEADER +
        f"<h1>{_html.escape(title)}</h1>" + charts_html + report_body +
        "<script>" + "\n".join(scripts) + "</script></body></html>"
    )


# ---------------------------------------------------------------------------
# Excel-МОДЕЛЬ як ДАНІ → платформа сама будує .xlsx із живими формулами
# (контракт «дані → рендер», як у ```chart; формат описано в config.XLSX_MODEL_NOTE)
# ---------------------------------------------------------------------------
_XLSXMODEL_FENCE_RE = re.compile(r"```+[ \t]*xlsxmodel[ \t]*\r?\n(.*?)```+", re.S | re.I)


def _parse_one_sheet(spec):
    """Розбір спеки ОДНОГО листа (спільний для одинарної моделі й для листа книги)."""
    if not isinstance(spec, dict):
        return None
    cols = [str(c) for c in (spec.get("columns") or [])]
    # Явні рядки таблиці: приймаємо і "rows", і "data" (моделі часто серіалізують
    # заповнену таблицю саме як "data"). Було: читалось лише "rows" → реальні дані
    # мовчки губились, а рендер підставляв row_template із вигаданими заглушками
    # {data_A}… (корінь бага чек-листа 16.07).
    _data = spec.get("data")
    rows = spec.get("rows") or (_data if isinstance(_data, list) else None) or []
    tmpl = spec.get("row_template") or []
    try:
        cnt = int(spec.get("row_count") or 0)
    except Exception:
        cnt = 0
    if rows:
        tmpl, cnt = [], 0   # є явні рядки → шаблон-генератор не потрібен (інакше junk-плейсхолдери)
    # ⭐⭐⭐ 10.08.2026. ЛИСТ ЛИШЕ З ПАРАМЕТРАМИ ЗНИКАВ МОВЧКИ — І РУЙНУВАВ КНИГУ.
    # Рендер такий лист підтримує прямо (`_render_sheet`: «if not columns: return
    # — лист лише з параметрами»), а розбір повертав None. Тому природний аркуш
    # «Параметри» вилітав із книги, всі формули {Pk:Параметри} інших листів били
    # в неіснуючий лист → `missing_sheet_refs` → файл не збирався ВЗАГАЛІ, і
    # клієнт не отримував нічого й не дізнавався причини.
    _params_only = bool(spec.get("params")) and not cols and not rows and not tmpl
    if not _params_only and (not cols or (not rows and not (tmpl and cnt > 0))):
        return None
    params = []
    for p in (spec.get("params") or []):
        if isinstance(p, dict) and p.get("name") is not None:
            params.append({"name": str(p["name"]), "value": p.get("value")})
    return {"title": str(spec.get("title", "") or "Модель"),
            # Ім'я аркуша: модельєр пише "name", старіші спеки — "sheet". Приймаємо ОБИДВА,
            # інакше аркуші отримують дефолт «Модель» і перехресні формули (Параметри!B2)
            # б'ють у неіснуючий аркуш → #REF! (корінь «пустого» кредитного файла 10.07).
            "sheet": (str(spec.get("sheet") or spec.get("name") or "") or "Модель")[:31],
            "params": params, "columns": cols, "rows": rows,
            "first_row": spec.get("first_row") or None,
            "row_template": tmpl, "row_count": min(cnt, 5000),
            "totals": spec.get("totals") or None}


def _parse_xlsxmodel(raw: str):
    import json
    try:
        spec = json.loads(raw)
    except Exception:
        return None
    if not isinstance(spec, dict):
        return None
    # Багатолистова КНИГА: {title, sheets:[<спека листа>, ...]} → рендер xlsxbook_to_xlsx.
    if isinstance(spec.get("sheets"), list) and spec.get("sheets"):
        sheets = [s for s in (_parse_one_sheet(sh) for sh in spec["sheets"]) if s]
        return {"title": str(spec.get("title", "") or "Книга"), "sheets": sheets} if sheets else None
    return _parse_one_sheet(spec)


# ═════════ ПАСТКА ЗСУВУ РЯДКА (10.08.2026, зміна 143) ══════════════════════
# ⭐⭐⭐ КОРІНЬ, ЗНАЙДЕНИЙ ЖИВИМ ПРОГОНОМ ЗА ГРОШІ. Щоб послатись на 3-й рядок
# листа, у контракті треба писати `B{first+2}` — зсув ВСЕРЕДИНІ дужок. Модель
# написала `B{first}+2` — зсув ЗЗОВНІ. Різниця в одній дужці, обидва варіанти
# дають ВАЛІДНИЙ Excel, і лише один означає те, що задумано. У живій фінмоделі
# це дало «Валовий прибуток = B4-B4+1», тобто рівно 1 гривню щомісяця, і ворота
# сказали ok: `B4+2` — бездоганна формула, аудит координат тут безсилий.
# Це найдорожчий вид браку: охайна таблиця з мовчазно неправильним числом.
_TRAP_MSG = ("зсув рядка стоїть ЗЗОВНІ дужок — Excel прочитає це як арифметику, "
             "а не як інший рядок, і число мовчки буде НЕ ТЕ. Пиши зсув "
             "ВСЕРЕДИНІ: B{first+2}, а не B{first}+2 (те саме для {row}/{prev}/"
             "{last}). Знайдено — %s")
_ROW_TRAP_RE = re.compile(r"\$?[A-Z]{1,3}\$?\{(row|prev|first|last|i)\}\s*[+-]\s*\d")

# ⭐⭐⭐ 16.09.2026, зміна 598. ПАСТКА БИЛА ПО НЕВИННОМУ.
# Наскрізний прогін на справжніх файлах показу засудив формулу
# `=IF(F{row}>0, B{row}/F{row}-1, 0)` — «факт поділити на план, мінус одиниця»,
# тобто найзвичайніше відхилення у відсотках. Форма та сама, що в пастки
# (посилання, а далі ±число), а зміст протилежний: тут «−1» стосується ЧАСТКИ,
# а не адреси. Судити тут можна лише за одним НАЗВАНИМ правилом:
# ⛒ АДРЕСИ НЕ ОДЕРЖУЮТЬ МНОЖЕННЯМ. Якщо перед посиланням стоїть «*» або «/»,
# це вже не адреса, а операнд арифметики — зсуву рядка там бути не може.
# Обидві живі пастки (`B{first}-B{first}+1`, `B{first}+2/B{first}`) цим правилом
# лишаються червоними: у них перед посиланням «=» або «−», а не множення.
_TRAP_SKIP_BEFORE = ("*", "/")


def row_ref_trap_errors(spec) -> list:
    """Адреси, зібрані з плейсхолдера рядка й зсунуті ЗЗОВНІ дужок.

    Повертає перелік знайдених місць («рядок → формула»). Порожньо — чисто.
    """
    out = []

    def _scan(where, val):
        if not isinstance(val, str):
            return
        for m in _ROW_TRAP_RE.finditer(val):
            j = m.start() - 1
            while j >= 0 and val[j].isspace():
                j -= 1
            if j >= 0 and val[j] in _TRAP_SKIP_BEFORE:
                continue        # операнд множення/ділення — не адреса
            out.append("%s: %s" % (where, val[:70]))
            return

    sheets = (spec or {}).get("sheets") or [spec or {}]
    for sh in sheets:
        if not isinstance(sh, dict):
            continue
        name = str(sh.get("sheet") or sh.get("name") or "лист")
        for row in (sh.get("rows") or []):
            label = str((row or ["?"])[0])[:32] if isinstance(row, list) else "?"
            for cell in (row if isinstance(row, list) else []):
                _scan("%s / %s" % (name, label), cell)
        for key in ("first_row", "row_template"):
            for cell in (sh.get(key) or []):
                _scan("%s / %s" % (name, key), cell)
    return out


# ═════════ НОМЕР РЯДКА НАЗВАНО ЧИСЛОМ (16.09.2026, зміна 598) ══════════════
# ⭐⭐⭐ КОРІНЬ, ЗНАЙДЕНИЙ ЖИВИМ ПРОГОНОМ ЗА ГРОШІ ($2,24). Зведена фінмодель
# корпорації зібралась охайно — і збрехала. Звірка КОЖНОГО посилання зведення
# дала не хаос, а РІВНИЙ ЗСУВ: Виробництво!E8 → E6, Кафе!B9 → B7, Сервіс!E9 →
# E7 (−2), Параметри!B3 → B2, Параметри!B4 → B3 (−1).
#
# Пояснення зсуву просте: рендер сам домальовує зверху кожного аркуша титул і
# порожній рядок, а на аркуші параметрів — титул перед першим параметром.
# Моделі цієї механіки НЕ ВИДНО: вона рахує «шапка в рядку 1, дані з рядка 2» і
# пише номер рядка НА ПАМ'ЯТЬ. Промах виходить рівно на ту висоту, яку рендер
# додав без неї. На виході — бездоганна формула, яку жодні інші ворота засудити
# не можуть: `Виробництво!E6` синтаксично ідеальна, координата в межах даних,
# циклу немає. Найдорожчий клас браку: охайна книга з тихо неправильним числом.
#
# ⛒ ЧОМУ ЦЕ КЛАС, А НЕ ВИПАДОК. Правило в контракті було з 10.07.2026
# («ЗАБОРОНЕНО писати вгадані номери рядків … відхиляються перевіркою»), але
# ПЕРЕВІРКИ не існувало — слова без воріт. Доки в спеці МОЖНА написати номер
# рядка числом, модель час від часу вгадає неправильно, і мовчки.
#
# ⭐ РІШЕННЯ КЛАСУ: адресу називає ЗБИРАЧ, а не модель. Модель дає НАМІР іменем
# ({first}, {last}, {totals:Лист}, {Pk:Лист}), координату рахує рендер із
# власної геометрії. Будь-який літеральний номер рядка у формулі спеки —
# відмова з називанням знайденої адреси.
_LITERAL_ROW_RE = re.compile(r"(?<![A-Za-z0-9_])(\$?[A-Z]{1,3}\$?)(\d{1,7})(?![\w(])")

_LITERAL_MSG = (
    "НОМЕР РЯДКА НАЗВАНО ЧИСЛОМ — %s. Ти НЕ знаєш фізичних рядків готового "
    "файла: платформа додає зверху титул, блок параметрів і шапку, тому вгаданий "
    "номер мовчки вкаже не туди (жива вада: «Виробництво!E8» перетворилось на "
    "«Виробництво!E6» — підсумок став рядком одного виробу). Пиши ІМЕНА, "
    "координати підставить платформа: свій лист — {row}/{prev}/{first}/{last}; "
    "чужий лист — 'Лист'!B{row:Лист}, діапазон 'Лист'!D{first:Лист}:D{last:Лист}, "
    "РЯДОК ПІДСУМКІВ 'Лист'!D{totals:Лист}, параметр {Pk:Лист}.")


def literal_row_ref_errors(spec) -> list:
    """Адреси клітинок, у яких номер рядка написано числом. Порожньо — чисто.

    Судимо СПЕКУ (до підстановки), бо після підстановки всі адреси законні —
    саме тому вада й проходила всі ворота готової книги.
    Колонку числом не судимо: порядок колонок модель знає з `columns`."""
    out = []
    sheets = (spec or {}).get("sheets") or [spec or {}]
    for sh in sheets:
        if not isinstance(sh, dict):
            continue
        name = str(sh.get("sheet") or sh.get("name") or sh.get("title") or "лист")[:31]
        n_params = len(sh.get("params") or [])

        def _scan(where, val):
            if not isinstance(val, str):
                return
            t = val.strip()
            if not (t.startswith("=") or _XM_BARE_REF_RE.match(t)):
                return          # текст, число, дата — адрес там немає
            # 🩸 Спершу прибираємо ІМЕНА: {P2:Параметри} — це намір, а не адреса,
            # і «P2» всередині дужок не сміє виглядати як клітинка колонки P.
            t = _XM_PLACEHOLDER_RE.sub("@", t)
            for m in _LITERAL_ROW_RE.finditer(t):
                col, num = m.group(1), m.group(2)
                # «Голий» Pk — це параметр (так дозволяє контракт), а не клітинка.
                if col == "P" and 1 <= int(num) <= n_params:
                    continue
                out.append("%s / %s: %s" % (name, where, m.group(0)))

        for p_ in (sh.get("params") or []):
            if isinstance(p_, dict):
                _scan("параметр «%s»" % str(p_.get("name") or "?")[:24],
                      _param_value(p_))
        for row in (sh.get("rows") or []):
            label = str((row or ["?"])[0])[:24] if isinstance(row, list) else "?"
            for cell in (row if isinstance(row, list) else []):
                _scan("рядок «%s»" % label, cell)
        for key in ("first_row", "row_template", "totals"):
            for cell in (sh.get(key) or []):
                _scan(key, cell)
    # Один і той самий промах не треба називати двадцять разів.
    seen, uniq = set(), []
    for e in out:
        if e not in seen:
            seen.add(e)
            uniq.append(e)
    return uniq


def dead_formula_errors(formulas) -> list:
    """НЕЗАЛЕЖНИЙ ШАР: формула, яка віднімає САМЕ СЕБЕ.

    `=B4-B4+1` завжди дорівнює 1 незалежно від даних — це не розрахунок, а стала
    під виглядом розрахунку. Судимо ЗІБРАНУ книгу, тому шар не залежить від
    того, звідки формула взялась (модель, спека, ремонт).
    """
    out = []
    ref = re.compile(r"(?<![A-Za-z0-9_!])(\$?[A-Z]{1,3}\$?\d+)")
    for f in (formulas or []):
        t = str(f or "")
        if not t.startswith("="):
            continue
        for m in re.finditer(r"(\$?[A-Z]{1,3}\$?\d+)\s*-\s*(\$?[A-Z]{1,3}\$?\d+)", t):
            if m.group(1).replace("$", "") == m.group(2).replace("$", ""):
                out.append("формула віднімає сама себе (завжди стала): %s" % t[:70])
                break
    return out


# ═════════ ЧИСЛО НЕ З ПЕРШОДЖЕРЕЛА (16.09.2026, зміна 599) ═════════════════
# ⭐⭐⭐ КОРІНЬ, ЗНАЙДЕНИЙ ЖИВИМ ПРОГОНОМ ЗА $2,39. Платформа прочитала чотири
# доданих файли бездоганно, а в готовій книзі опинився ХЛІБЗАВОД: «Хліб та
# хлібобулочні вироби» 200000x25, договори «N2026-118», план маржинальності
# 65 % замість 9 %. Книга при цьому охайна: живі формули, правильні посилання,
# зведення сходиться саме з собою. Найдорожчий клас браку — документ, що
# бездоганно виглядає і бреше в кожному числі.
#
# Корінь лікує executor.assembler_input_text (складач тепер бачить першоджерело).
# Ці ворота — ДРУГИЙ шар, який судить НАСЛІДОК, а не намір: навіть якщо модель
# знову почне вигадувати, вигадане число не проїде.
#
# ⛒ ПРАВИЛО, ЯКЕ ТУТ СУДИТЬСЯ, ОДНЕ:
#    число, вписане РУКОЮ, мусить бути в першоджерелі;
#    число, яке треба ПОРАХУВАТИ, мусить бути ФОРМУЛОЮ.
# Тому чесне зведення 124 щоденних рядків у =SUMIF ворота не чіпають, а кругле
# «2 700 000» замість нього — червонять.
#
# 🩸 БЕЗ ПЕРШОДЖЕРЕЛА ВОРОТА МОВЧАТЬ. Задача без доданих файлів (калькулятор,
# прогноз із голови) не має з чим звірятись — судити там нічого, і хибна тривога
# коштувала б живого прогону.
# 🩸 РОЗДІЛЬНИК ТИСЯЧ — ЦЕ ПРОБІЛ, А НЕ БУДЬ-ЯКИЙ ПРОГАЛ. Спершу тут стояло
# «\s», щоб читати «41 812 497» як одне число. Але «\s» — це ще й ПЕРЕНЕСЕННЯ
# РЯДКА, тому два сусідні числа з різних рядків джерела злипались в одне
# неіснуюче, і сторож не знаходив жодного з них. Знайдено наскрізною пробою
# 16.09.2026 — до живого прогону, не після.
_FULL_NUM_RE = re.compile(r"^-?\d[\d \u00a0\u202f']*(?:[.,]\d+)?$")
_ANY_NUM_RE = re.compile(r"-?\d[\d \u00a0\u202f']*(?:[.,]\d+)?")
# Дрібні структурні числа: номери періодів, місяці, частки на 100/1000.
_STRUCTURAL_NUMS = set(range(0, 13)) | {24, 36, 48, 60, 100, 1000}

_UNGROUND_MSG = (
    "ЧИСЛО НЕ З ПЕРШОДЖЕРЕЛА — %s. Ці числа вписані рукою, але їх немає ні в "
    "доданих файлах, ні в запиті. Правило одне: число, яке треба ПЕРЕНЕСТИ, беруть "
    "з доданих файлів ДОСЛІВНО; число, яке треба ПОРАХУВАТИ (сума по точці, "
    "підсумок, зведення) — це ФОРМУЛА Excel (=SUM/=SUMIF/…), а не вписане значення. "
    "Вигадувати «приблизні» або круглі числа ЗАБОРОНЕНО: якщо даних бракує — скажи "
    "це чесно, а не домальовуй правдоподібне.")


def _num_or_none(v):
    """Значення клітинки як число — ЛИШЕ якщо воно ЦІЛКОМ число (не дата, не текст)."""
    t = str(v if v is not None else "").strip()
    if not t or t.startswith("="):
        return None
    if not _FULL_NUM_RE.match(t):
        return None
    try:
        return float(t.replace(" ", "").replace("\u00a0", "").replace("'", "").replace(",", "."))
    except Exception:
        return None


def _source_numbers(text: str) -> set:
    out = set()
    for m in _ANY_NUM_RE.finditer(str(text or "")):
        t = m.group(0).replace(" ", "").replace("\u00a0", "").replace("'", "").replace(",", ".")
        try:
            v = float(t)
        except Exception:
            continue
        out.add(round(v, 4))
        out.add(round(v, 2))
    return out


def ungrounded_number_errors(spec, source_text: str) -> list:
    """Числа спеки, яких немає в першоджерелі. Порожньо — чисто.

    Першоджерело = текст доданих файлів + текст запиту (курс, ставку тощо людина
    часто дає словами в задачі, і це так само джерело)."""
    if not source_text or not str(source_text).strip():
        return []                      # нема з чим звіряти — ворота мовчать
    src = _source_numbers(source_text)
    if not src:
        return []
    out = []

    def _ok(v):
        if abs(v) in _STRUCTURAL_NUMS or (float(v).is_integer() and abs(v) in _STRUCTURAL_NUMS):
            return True
        for cand in (v, v * 100, v / 100.0):
            if round(cand, 4) in src or round(cand, 2) in src:
                return True
        return False

    sheets = (spec or {}).get("sheets") or [spec or {}]
    for sh in sheets:
        if not isinstance(sh, dict):
            continue
        name = str(sh.get("sheet") or sh.get("name") or "лист")[:31]

        def _scan(where, val):
            v = _num_or_none(val)
            if v is None or _ok(v):
                return
            # 🩸 Число в скарзі мусить виглядати як у спеці: «%g» перетворював
            # 987654321 на «9.87654e+08», і людина не впізнавала власного числа.
            _shown = ("%d" % int(v)) if float(v).is_integer() else ("%.4f" % v).rstrip("0").rstrip(".")
            out.append("%s / %s: %s" % (name, where, _shown))

        for p_ in (sh.get("params") or []):
            if isinstance(p_, dict):
                _scan("параметр «%s»" % str(p_.get("name") or "?")[:28], _param_value(p_))
        for row in (sh.get("rows") or []):
            label = str((row or ["?"])[0])[:28] if isinstance(row, list) else "?"
            for cell in (row if isinstance(row, list) else [])[1:]:
                _scan("рядок «%s»" % label, cell)
        for key in ("first_row", "row_template", "totals"):
            for cell in (sh.get(key) or [])[1:]:
                _scan(key, cell)
    seen, uniq = set(), []
    for e in out:
        if e not in seen:
            seen.add(e)
            uniq.append(e)
    return uniq


def check_xlsxmodel(md: str, require_live: bool = False, source_text: str = ""):
    """Валідація блоку ```xlsxmodel БЕЗ побічних ефектів. Повертає (ok, err):
    ok=True — є валідний блок; інакше err пояснює, що саме не так (для
    повернення складальнику на виправлення)."""
    import json
    if not md:
        return False, "немає блоку ```xlsxmodel"
    m = _XLSXMODEL_FENCE_RE.search(md)
    if not m:
        return False, "немає блоку ```xlsxmodel"
    raw = (m.group(1) or "").strip()
    try:
        spec = json.loads(raw)
    except Exception as e:
        return False, f"усередині блоку невалідний JSON ({e})"
    if not isinstance(spec, dict):
        return False, "у блоці не JSON-обʼєкт"
    # Багатолистова книга (кілька листів) — ПІДТРИМУЄТЬСЯ через sheets[].
    if isinstance(spec.get("sheets"), list):
        if not spec["sheets"]:
            return False, "порожній масив sheets"
        for i, sh in enumerate(spec["sheets"], 1):
            if not isinstance(sh, dict):
                return False, f"лист №{i}: не JSON-обʼєкт"
            # ⭐⭐⭐ 10.08.2026. АРКУШ ЛИШЕ З ПАРАМЕТРАМИ — ЗАКОННИЙ.
            # Рендер його підтримує з самого початку, а ці ворота вимагали
            # columns від КОЖНОГО листа. Через це природний аркуш «Параметри»
            # (самі вхідні дані, на які посилаються інші листи) відхилявся, і
            # складач мусив вигадувати йому фальшиву таблицю або губити його —
            # а без нього всі формули {Pk:Параметри} б'ють у неіснуючий лист.
            if not sh.get("columns"):
                if sh.get("params"):
                    continue                      # лист-параметри: таблиці не буває
                return False, f"лист №{i}: бракує обовʼязкового поля columns"
            if not (sh.get("rows") or (sh.get("row_template") and str(sh.get("row_count") or "0").isdigit()
                                       and int(sh.get("row_count") or 0) > 0)):
                return False, f"лист №{i}: бракує rows АБО пари row_template+row_count"
        parsed = _parse_xlsxmodel(raw)
        if not parsed:
            return False, "книга не пройшла розбір (перевір типи полів)"
        # ⭐ 10.08.2026: ворота на мовчазне обрізання — і для книги теж.
        _tr = truncation_error(parsed, md)
        if _tr:
            return False, _tr
        _trap = row_ref_trap_errors(parsed)
        if _trap:
            return False, _TRAP_MSG % "; ".join(_trap[:4])
        _lit = literal_row_ref_errors(parsed)
        if _lit:
            return False, _LITERAL_MSG % "; ".join(_lit[:6])
        _ung = ungrounded_number_errors(parsed, source_text)
        if _ung:
            return False, _UNGROUND_MSG % "; ".join(_ung[:8])
        return _check_rendered(parsed, require_live=require_live)
    if not spec.get("columns"):
        return False, "бракує обовʼязкового поля columns"
    if not (spec.get("rows") or (spec.get("row_template") and str(spec.get("row_count") or "0").isdigit()
                                 and int(spec.get("row_count") or 0) > 0)):
        return False, "бракує rows АБО пари row_template+row_count"
    parsed = _parse_xlsxmodel(raw)
    if not parsed:
        return False, "блок не пройшов розбір (перевір типи полів)"
    # ⭐ 10.08.2026: спершу — чи не обрізано аркуш мовчки (порівняння з текстом).
    _tr = truncation_error(parsed, md)
    if _tr:
        return False, _tr
    _trap = row_ref_trap_errors(parsed)
    if _trap:
        return False, _TRAP_MSG % "; ".join(_trap[:4])
    _lit = literal_row_ref_errors(parsed)
    if _lit:
        return False, _LITERAL_MSG % "; ".join(_lit[:6])
    _ung = ungrounded_number_errors(parsed, source_text)
    if _ung:
        return False, _UNGROUND_MSG % "; ".join(_ung[:8])
    return _check_rendered(parsed, require_live=require_live)


def _md_tables(md: str) -> list:
    """Таблиці markdown у тексті: [(шапка[], кількість рядків даних)].

    Потрібно воротам «мовчазне обрізання»: складач часто виписує повну таблицю
    ТЕКСТОМ і водночас кладе в спеку один рядок. Ми порівнюємо ці два світи."""
    out = []
    lines = (md or "").splitlines()
    i = 0
    while i < len(lines):
        ln = lines[i].strip()
        if ln.startswith("|") and ln.endswith("|") and i + 1 < len(lines):
            sep = lines[i + 1].strip()
            if sep.startswith("|") and set(sep) <= set("|-: \t"):
                head = [c.strip() for c in ln.strip("|").split("|")]
                j = i + 2
                n = 0
                while j < len(lines) and lines[j].strip().startswith("|"):
                    cells = [c.strip() for c in lines[j].strip().strip("|").split("|")]
                    if any(cells):
                        n += 1
                    j += 1
                out.append((head, n))
                i = j
                continue
        i += 1
    return out


def _norm_cell(x) -> str:
    return "".join(ch for ch in str(x or "").lower() if ch.isalnum())


def truncation_error(parsed, md: str) -> str:
    """⭐⭐⭐ ВОРОТА «МОВЧАЗНЕ ОБРІЗАННЯ АРКУША» (10.08.2026).

    КОРІНЬ, знайдений на живому прогоні 09.08.2026: контракт не давав форми для
    таблиці з РІЗНОРІДНИМИ рядками, тому складач клав у спеку один рядок
    (`row_count: 1`), а повну таблицю виписував текстом markdown. Аудит координат
    дивився лише на формули — і аркуш з ОДНИМ рядком проходив зеленим. Клієнт
    отримував .xlsx, де P&L і Cash Flow мали по одному рядку, і ніхто про це не
    казав. Це рівно клас «мовчазне обрізання».

    Тут ми порівнюємо ДВА СВІТИ однієї відповіді: скільки рядків складач показав
    ЛЮДИНІ текстом і скільки поклав У ФАЙЛ. Розбіжність — не стиль, а втрата.
    """
    sheets = (parsed.get("sheets") or [parsed]) if isinstance(parsed, dict) else []
    tables = _md_tables(md)
    if not tables:
        return ""
    bad = []
    for sh in sheets:
        cols = [_norm_cell(c) for c in ((sh or {}).get("columns") or [])]
        if not cols:
            continue
        in_file = len(sh.get("rows") or []) or int(sh.get("row_count") or 0)
        # ⭐⭐⭐ 16.09.2026, зміна 598. ХИБНА ТРИВОГА, ЩО КОШТУВАЛА ДВА ПРОГОНИ.
        # Рядок «Разом» їде у файл ОКРЕМИМ полем totals[] — рендер ставить його
        # одразу під даними. Сторож його не рахував, тому ЗАКОННА книга (3 напрями
        # в rows + «Разом» у totals, 4 рядки в тексті) виглядала обрізаною. Дві
        # живі роботи вбито ні за що ($2,16), а порада «переключіть мозок на Opus»
        # не могла зарадити, бо модель тут ні до чого. Рахуємо ВЕСЬ файл.
        if sh.get("totals"):
            in_file += 1
        for head, n_rows in tables:
            h = [_norm_cell(c) for c in head]
            if len(h) != len(cols):
                continue
            same = sum(1 for a, b_ in zip(h, cols) if a and a == b_)
            if same * 2 < len(cols):          # шапка не та сама таблиця
                continue
            if n_rows > max(in_file, 0):
                bad.append("аркуш «%s»: у тексті ти показав %d рядків, а у файл поклав %d"
                           % (sh.get("sheet") or sh.get("title") or "?", n_rows, in_file))
                break
    if not bad:
        return ""
    return ("МОВЧАЗНЕ ОБРІЗАННЯ АРКУША — " + "; ".join(bad[:4])
            + ". Таблицю з різнорідними рядками не виписують текстом: усі рядки мусять "
              "бути у полі \"rows\" спеки (список рядків, кожен — список клітинок у "
              "порядку columns). row_template/row_count тут не вживають узагалі.")


def _check_rendered(parsed, require_live: bool = False):
    """АУДИТ КООРДИНАТ на пробному рендері в памʼяті (файл НЕ пишеться): формат
    може бути валідний, а координати — фейкові (кредитний кейс 10.07 ~22:10:
    зсув на 7 рядків, цикл в останньому платежі, SUM повз дані, {name}-заглушки).
    Точна помилка повертається коректору складальника на виправлення."""
    if not _HAS_XLSX:
        return True, ""  # без openpyxl файл і так не збереться — формат уже звірено
    try:
        wb, regions = _render_book(parsed)
    except Exception as e:
        return False, f"модель не рендериться: {e}"
    # ⭐⭐⭐ 31.07.2026. ВОРОТА ЖИВОЇ ФОРМУЛИ.
    # Аудит координат перевіряє формули, ЯКІ Є. При нулі формул йому нічого
    # перевіряти — і він мовчки зелений (клас «порожній перелік робить чек
    # фальшивим»). Книга з параметрами, але без жодної формули, — це не модель,
    # а мертва табличка: клієнт міняє жовту клітинку й нічого не перераховується.
    # Params існують ЛИШЕ щоб на них посилались формули ({P1}..{Pn}), тому
    # «є params і нема формул» — самосуперечність спеки, а не стиль.
    _sheets = (parsed.get("sheets") or [parsed]) if isinstance(parsed, dict) else [parsed]
    _has_params = any((s or {}).get("params") for s in _sheets)
    if _has_params or require_live:
        _live = 0
        for _ws in wb.worksheets:
            for _row in _ws.iter_rows():
                for _c in _row:
                    if isinstance(_c.value, str) and _c.value.startswith("="):
                        _live += 1
        if _live == 0:
            return False, ("у книзі НЕМАЄ ЖОДНОЇ живої формули — самі готові числа. "
                           "Це не модель: клієнт змінить вхідний параметр і нічого не "
                           "перерахується. Розрахунки в rows/first_row/row_template "
                           "мають бути формулами Excel (починатись зі знака «=») і "
                           "посилатись на параметри через {P1}..{Pn}, а не містити "
                           "порахований результат числом.")
    # ⭐⭐⭐ 10.09.2026, зміна 549. ВИРОК ПРО КНИГУ ПИШЕ ОДИН ПИСАР.
    # Перелік воріт більше не переписується тут руками: його дає
    # `book_gate_errors`, і той самий перелік питають обидва записувачі файла.
    # Наш клопіт тут — лише СЛОВА людині й складачеві на кожні ворота.
    for _gate, _errs in book_gate_errors(wb, regions):
        if not _errs:
            continue
        _head, _tail, _limit = _GATE_SAYS[_gate]
        return False, (_head + "; ".join(_errs[:_limit]) + _tail)
    return True, ""


def extract_xlsxmodel(md: str):
    """Виймає ПЕРШИЙ валідний блок ```xlsxmodel. Повертає (spec|None, md_без_блоку).
    У тексті блок замінюється короткою довідкою (параметри + відсилання до .xlsx).
    НЕвалідні блоки теж ВИРІЗАЮТЬСЯ (з чесною позначкою) — сирий службовий JSON
    ніколи не має потрапляти в чат чи файли користувача."""
    if not md or "xlsxmodel" not in md:
        return None, md
    # ⭐⭐⭐ 10.08.2026. ДРУГИЙ БЛОК ЗНИКАВ МОВЧКИ.
    # Раніше тут стояло «другий і подальші валідні блоки — просто прибрати». На
    # живому прогоні 09.08 складач віддав ДВА валідні блоки (1562 і 1518 байтів) —
    # другий вилетів без жодного слова. А розкладати книгу на кілька блоків —
    # природна реакція на «аркуші різні». Тепер листи ЗЛИВАЮТЬСЯ в одну книгу:
    # нічого не губиться, і мовчазного викидання не існує.
    _all = []
    for _m in _XLSXMODEL_FENCE_RE.finditer(md):
        _s = _parse_xlsxmodel((_m.group(1) or "").strip())
        if not _s:
            continue
        _all.append(_s)
    merged = None
    if len(_all) > 1:
        _sheets, _seen = [], set()
        for _s in _all:
            for _sh in (_s.get("sheets") or [_s]):
                _nm = (_sh.get("sheet") or _sh.get("title") or "")
                _key = _nm.lower()
                while _key in _seen:                     # два аркуші з тим самим імʼям
                    _nm = (_nm + " (2)")[:31]
                    _key = _nm.lower()
                _seen.add(_key)
                _sh = dict(_sh, sheet=_nm)
                _sheets.append(_sh)
        merged = {"title": str(_all[0].get("title") or "Книга"), "sheets": _sheets}

    found = {"spec": None}

    def _repl(m):
        s = _parse_xlsxmodel((m.group(1) or "").strip())
        if s and found["spec"] is None:
            found["spec"] = merged or s
            s = found["spec"]
            if s.get("sheets"):
                names = ", ".join((sh.get("sheet") or sh.get("title") or f"Лист{i}")
                                  for i, sh in enumerate(s["sheets"], 1))
                return (f"**{s['title']}** *(жива Excel-книга з формулами — у файлі .xlsx нижче)*\n"
                        f"\nЛисти: {names}\n")
            plist = "\n".join(f"- {p['name']}: {p['value']}" for p in s["params"])
            return (f"**{s['title']}** *(жива Excel-модель з формулами — у файлі .xlsx нижче)*\n"
                    + (f"\nПараметри моделі:\n{plist}\n" if plist else ""))
        if s:
            return ""  # другий і подальші валідні блоки — просто прибрати
        return ("*(службовий блок Excel-моделі був у невалідному форматі й не потрапив "
                "у файл — таблиці зібрано простим способом)*")

    md2 = _XLSXMODEL_FENCE_RE.sub(_repl, md)
    return found["spec"], md2


# ⭐⭐⭐ 554. РОЗМОВА ПЛАТФОРМИ ПРО СЕБЕ — НЕ ЧАСТИНА РЕЗУЛЬТАТУ КЛІЄНТА.
# 10.09.2026 перший рядок клієнтської SEO-стратегії був такий: «⚠ Перевірку «чи
# вистачає даних» виконати не вдалось…». Застереження чесне, але адресоване тому,
# хто ЗАМОВЛЯВ, а не тому, хто потім читатиме цей документ. Тому службова врізка
# дістає МАШИННІ МАРКЕРИ — впізнавати її за словами не можна: слова змінять, і
# наступна врізка знову протече у файл.
_NOTE_RULE = "\n\n---\n\n"
_NOTE_OPEN = "<!--sf:note-->"
_NOTE_CLOSE = "<!--/sf:note-->"
_NOTE_RE = re.compile(re.escape(_NOTE_OPEN) + r".*?" + re.escape(_NOTE_CLOSE),
                      re.S)


def platform_note(text: str) -> str:
    """ЄДИНИЙ писар службової врізки: текст платформи ПРО СЕБЕ, позначений так,
    щоб код міг відрізнити його від результату. Порожній текст маркерів не дістає."""
    t = (text or "").strip()
    if not t:
        return ""
    # 554-б. Роздільник — ЧАСТИНА врізки і живе ВСЕРЕДИНІ маркерів: інакше
    # у файл клієнта врізка не їде, а її межа їде, і документ починається з «---».
    return _NOTE_OPEN + t + _NOTE_RULE + _NOTE_CLOSE


def strip_platform_notes(md: str, keep_text: bool = False) -> str:
    """keep_text=True  — лишає ТЕКСТ врізки, прибирає лише маркери (шлях у ЧАТ:
                         людині, яка замовляла, застереження потрібне).
       keep_text=False — вирізає врізку ЦІЛКОМ (шлях у ФАЙЛ: документ клієнта не
                         повинен починатися з розмови про наш збій)."""
    if not md or _NOTE_OPEN not in md:
        return md
    if keep_text:
        return md.replace(_NOTE_OPEN, "").replace(_NOTE_CLOSE, "")
    out = _NOTE_RE.sub("", md)
    return out.lstrip("\n")


def strip_service_blocks(md: str) -> str:
    """Захисний скраб службових блоків (```xlsxmodel/```schemaorg). Прибирає їх навіть
    із кривою огорожею (1-3 лапки) або зовсім без огорожі (голий заголовок + {...}),
    щоб сирий службовий JSON НІКОЛИ не потрапив у чат чи файли (Правило №15)."""
    if not md or "xlsxmodel" not in md:
        return md
    md = re.sub(r"`+[ \t]*xlsxmodel[ \t]*\r?\n.*?`+[ \t]*(?:\r?\n|$)",
                "", md, flags=re.S | re.I)
    lines = md.splitlines(keepends=True)
    out, i = [], 0
    hdr = re.compile(r"^\s*`*\s*xlsxmodel\s*`*\s*$", re.I)
    while i < len(lines):
        if hdr.match(lines[i]):
            j = i + 1
            while j < len(lines) and "{" not in lines[j]:
                j += 1
            if j < len(lines):
                depth, k, done = 0, j, False
                while k < len(lines) and not done:
                    for ch in lines[k]:
                        if ch == "{":
                            depth += 1
                        elif ch == "}":
                            depth -= 1
                            if depth == 0:
                                done = True
                                break
                    k += 1
                if done:
                    i = k
                    continue
        out.append(lines[i])
        i += 1
    return "".join(out)


def _xm_subst(text, n_params, row=None, first=None, last=None, i=None, regions=None):
    """Плейсхолдери спеки → адреси клітинок: {Pk}/Pk→$B$(1+k), {row}/{prev}/{first}/{last}/{i}.
    Приймає і {P2}, і «голе» P2 (як моделі пишуть посилання параметра-на-параметр
    усередині блоку params); підставляє лише Pk у межах наявних параметрів (1..n_params),
    щоб не зачепити випадкові посилання на колонку P.

    КООРДИНАТНИЙ КОНТРАКТ (10.07.2026): модель НЕ знає фізичних рядків чужого листа
    (рендерер додає титул+параметри+шапку зверху — звідси зсув на 7 рядків у
    кредитному файлі). Тому крос-листові координати — ТІЛЬКИ плейсхолдерами:
      {row:Лист}   → фізичний рядок i-го рядка ДАНИХ цільового листа
      {first:Лист} / {last:Лист} → перший/останній рядок даних цільового листа
      {totals:Лист} → фізичний рядок ПІДСУМКІВ цільового листа (16.09.2026: саме
                     цього імені бракувало — зведення не мало чим послатись на
                     «Разом» чужого аркуша, і модель полізла вгадувати число)
      {Pk:Лист}    → повне посилання на k-й параметр цільового листа ('Лист'!$B$k+1)
    regions = {імʼя_листа: {n_params, first, last, ...}} — рахує рендерер (2 проходи)."""
    # 🩸 553. Порожнеча НЕ сміє стати рядком «None»: саме так непрочитане поле
    # спеки лягало в клітинку правдоподібним сміттям, якого не бачили ворота.
    s = "" if text is None else str(text)
    if regions:
        def _cross(m):
            kind, off, target = m.group(1), m.group(2), (m.group(3) or "").strip().strip("'")
            reg = regions.get(target)
            if not reg:
                return m.group(0)  # невідомий лист — лишаємо, аудит назве поіменно
            _d = int(off) if off else 0
            if kind.startswith("P"):
                k = int(kind[1:])
                if 1 <= k <= reg.get("n_params", 0):
                    return "'%s'!$B$%d" % (target, 1 + k)
                return m.group(0)
            if kind == "row":
                return str(reg["first"] + (i - 1) + _d) if (reg.get("first") and i) else m.group(0)
            if kind == "first":
                return str(reg["first"] + _d) if reg.get("first") else m.group(0)
            if kind == "last":
                return str(reg["last"] + _d) if reg.get("last") else m.group(0)
            if kind == "totals":
                return str(reg["totals"] + _d) if reg.get("totals") else m.group(0)
            return m.group(0)
        s = re.sub(r"\{(P\d+|row|first|last|totals)([+-]\d+)?:([^}]{1,40})\}", _cross, s)
    def _p(m):
        k = int(m.group(1))
        return "$B$%d" % (1 + k) if 1 <= k <= n_params else m.group(0)
    s = re.sub(r"\{P(\d+)\}", _p, s)                   # {Pk}
    s = re.sub(r"(?<![A-Za-z$'\d])P(\d+)\b", _p, s)    # голе Pk
    _nums = {}
    if row is not None:
        _nums["row"] = row
        _nums["prev"] = row - 1
    if i is not None:
        _nums["i"] = i
    if first is not None:
        _nums["first"] = first
    if last is not None:
        _nums["last"] = last

    def _num(m):
        name, off = m.group(1), m.group(2)
        if name not in _nums:
            return m.group(0)          # імені нема в контексті — не чіпаємо (аудит зловить лишок)
        return str(_nums[name] + (int(off) if off else 0))
    # {name} = зсув 0; {name+N}/{name-N} — арифметика координат (модель пише {first+1},
    # {last-1}). Раніше зсув не підставлявся -> живий "{first+1}" у формулі -> Excel #NAME? (24.07).
    s = re.sub(r"\{(row|prev|first|last|i)([+-]\d+)?\}", _num, s)
    return s


# «Голе» посилання на клітинку без «=» (Параметри!B4, $B$3, 'Графік платежів'!G9):
# як текст воно мертве (EDATE/арифметика на ньому падають) — однозначний намір
# моделі це формула, підносимо до формули детерміновано.
_XM_BARE_REF_RE = re.compile(
    r"^\s*(?:(?:'[^']{1,31}'|[\wЀ-ӿ]{1,31})!)?\$?[A-Z]{1,3}\$?\d{1,7}\s*$")


# ⭐⭐⭐ 16.09.2026, зміна 598. ВІДСОТОК, ПОКАЗАНИЙ ЯК ГРОШІ, — ТЕЖ НЕПРАВДА.
# У живій книзі колонка «Маржинальність, %» дістала грошовий формат #,##0.00,
# і частка 0,26 показалась як «0,26». Власник прочитав це як нуль — і мав рацію:
# число на екрані не означало того, що означало насправді. Формат клітинки —
# частина правди про число, а не оздоблення, тому його називає ЗАГОЛОВОК
# КОЛОНКИ, а не позиція («усе, крім першої колонки, — гроші»).
_PCT_HEAD_RE = re.compile(r"%|відсот|маржинальн|рентабельн|частк", re.I)
_PP_HEAD_RE = re.compile(r"п\.\s?п\.?|проц\w*\s+пункт", re.I)
_X100_RE = re.compile(r"\*\s*100(?!\d)")


def _xm_num_format(header, raw, is_formula):
    """Формат числової клітинки за ЗАГОЛОВКОМ її колонки.

    Відсоткову колонку ніколи не показуємо грошима. Чи вже помножено на 100,
    вирішуємо по самому значенню: формула з «*100» і число більше за одиницю —
    це вже відсоткові одиниці, їх не множимо вдруге (інакше 27,6 стало б 2760%)."""
    head = str(header or "")
    pp, pct = bool(_PP_HEAD_RE.search(head)), bool(_PCT_HEAD_RE.search(head))
    if not (pp or pct):
        return "#,##0.00"
    if is_formula:
        scaled = bool(_X100_RE.search(str(raw)))
    else:
        try:
            scaled = abs(float(str(raw).replace(" ", "").replace(",", "."))) > 1.0
        except Exception:
            scaled = False
    if pp:
        return '0.0" п.п."'
    return '0.0"%"' if scaled else "0.00%"


def _xm_cell(ws, r, c, value, money_fmt=True, header=None):
    """Пише клітинку: '='-рядок → жива формула; число → число; дата DD.MM.YYYY →
    СПРАВЖНЯ дата (текстова дата ламає EDATE — кредитний кейс 10.07); «голе»
    посилання на клітинку → формула; інше → текст.
    header — заголовок колонки: ним визначається формат числа (гроші/відсоток)."""
    import datetime as _dt
    s = str(value) if value is not None else ""
    cell = ws.cell(row=r, column=c)
    if s.startswith("="):
        cell.value = s
        if money_fmt:
            cell.number_format = _xm_num_format(header, s, True)
        return
    if _XM_BARE_REF_RE.match(s):
        cell.value = "=" + s.strip()
        if money_fmt:
            cell.number_format = _xm_num_format(header, s, True)
        return
    m = _XLS_DATE_RE.match(s)
    if m:
        try:
            cell.value = _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            cell.number_format = "DD.MM.YYYY"
            return
        except ValueError:
            pass
    try:
        num = float(s.replace(" ", "").replace(",", "."))
        if num == int(num) and "." not in s and "," not in s:
            cell.value = int(num)
        else:
            cell.value = num
            if money_fmt:
                cell.number_format = _xm_num_format(header, s, False)
    except ValueError:
        cell.value = s


# ---------------------------------------------------------------------------
# УНІВЕРСАЛЬНИЙ ОЗДОБЛЮВАЧ XLSX — єдина «рука», через яку проходить КОЖЕН
# лист будь-якої системи. Гарантія: жоден xlsx не виходить неохайним
# (заголовки, автоширина, формати чисел/дат, рамки, зебра, заморозка).
# ---------------------------------------------------------------------------
_XLS_INK      = "1F2A37"   # заголовки колонок — темний слейт
_XLS_INK_FONT = "FFFFFF"
_XLS_ZEBRA    = "F4F7FA"
_XLS_TOTALS   = "E5E9EE"
_XLS_LINE     = "D0D7DE"

_XLS_DATE_RE = re.compile(r"^\s*(\d{1,2})\.(\d{1,2})\.(\d{4})\s*$")
_XLS_PCT_RE  = re.compile(r"^\s*-?[\d\s ]+(?:[.,]\d+)?\s*%\s*$")
_XLS_NUM_RE  = re.compile(
    r"^\s*-?[\d\s ]{1,}(?:[.,]\d+)?\s*(?:грн|₴|\$|€|usd|uah|eur)?\s*$", re.I)


def _xls_numberize(cell):
    """Рядок, що ВИГЛЯДАЄ як число/відсоток/дата → справжнє значення + формат.
    Текст лишається текстом; формули та вже-числові клітинки не чіпаються."""
    import datetime as _dt
    v = cell.value
    if not isinstance(v, str):
        return
    s = v.strip()
    if not s or s.startswith("="):
        return
    m = _XLS_DATE_RE.match(s)
    if m:
        try:
            cell.value = _dt.date(int(m.group(3)), int(m.group(2)), int(m.group(1)))
            cell.number_format = "DD.MM.YYYY"
        except ValueError:
            pass
        return
    if _XLS_PCT_RE.match(s):
        body = s.rstrip("% ").replace(" ", "").replace(" ", "").replace(",", ".")
        try:
            cell.value = float(body) / 100.0
            cell.number_format = "0.00%"
        except ValueError:
            pass
        return
    if _XLS_NUM_RE.match(s):
        had_money = bool(re.search(r"грн|₴|\$|€|uah|usd|eur", s, re.I))
        body = re.sub(r"[^\d,.\-]", "", s)
        if "," in body and "." in body:      # 1.234,56 → крапка тисячна
            body = body.replace(".", "").replace(",", ".")
        else:
            body = body.replace(",", ".")
        try:
            num = float(body)
        except ValueError:
            return
        if had_money:
            cell.value = num
            cell.number_format = ('#,##0.00\\ "грн"'
                                  if re.search(r"грн|₴|uah", s, re.I) else "#,##0.00")
        elif "." in body:
            cell.value = num
            cell.number_format = "#,##0.00"
        else:
            cell.value = int(num)
            cell.number_format = "#,##0"


def _xls_autowidth(ws, max_width=48):
    from openpyxl.utils import get_column_letter
    widths = {}
    for row in ws.iter_rows():
        for cell in row:
            if cell.value is None:
                continue
            if isinstance(cell.value, str):
                if cell.value.startswith("="):
                    ln = 12          # формула показує число, а не свій текст
                else:
                    ln = max((len(x) for x in cell.value.split("\n")), default=0)
            else:
                ln = len(str(cell.value)) + 2   # формати чисел трохи ширші
            if ln > widths.get(cell.column, 0):
                widths[cell.column] = ln
    for col, ln in widths.items():
        ws.column_dimensions[get_column_letter(col)].width = min(max_width, max(10, ln + 3))


def style_worksheet(ws, header_row=1, data_first=None, data_last=None,
                    ncols=None, totals_row=None, zebra=True, freeze=True,
                    numberize=False, borders=True):
    """Єдиний стиль будь-якого листа. Викликається УСІМА xlsx-продюсерами платформи."""
    if not _HAS_XLSX:
        return
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    thin = Side(style="thin", color=_XLS_LINE)
    box = Border(left=thin, right=thin, top=thin, bottom=thin)

    if ncols is None:
        ncols = ws.max_column
    if data_first is None:
        data_first = header_row + 1
    if data_last is None:
        data_last = ws.max_row
        if totals_row and data_last >= totals_row:
            data_last = totals_row - 1

    ws.sheet_view.showGridLines = False

    hfill = PatternFill("solid", fgColor=_XLS_INK)
    for c in range(1, ncols + 1):
        cell = ws.cell(header_row, c)
        cell.font = Font(bold=True, color=_XLS_INK_FONT)
        cell.fill = hfill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        if borders:
            cell.border = box

    zfill = PatternFill("solid", fgColor=_XLS_ZEBRA)
    for r in range(data_first, data_last + 1):
        for c in range(1, ncols + 1):
            cell = ws.cell(r, c)
            if numberize:
                _xls_numberize(cell)
            if borders:
                cell.border = box
            if zebra and (r - data_first) % 2 == 1:
                cell.fill = zfill

    if totals_row:
        tfill = PatternFill("solid", fgColor=_XLS_TOTALS)
        for c in range(1, ncols + 1):
            cell = ws.cell(totals_row, c)
            if numberize:
                _xls_numberize(cell)
            cell.font = Font(bold=True)
            cell.fill = tfill
            if borders:
                cell.border = box

    _xls_autowidth(ws)
    if freeze:
        ws.freeze_panes = ws.cell(row=header_row + 1, column=1)


def _xls_param_format(name, value):
    """Формат для значення параметра за його підписом (частка→%, грн→гроші).
    Обережно: % лише коли значення — справді частка (|value|<=1), щоб 36 не стало 3600%."""
    if not isinstance(value, (int, float)):
        return None
    hl = str(name).lower()
    if ("%" in hl or "відсот" in hl or "інфляц" in hl or "націнк" in hl
            or "ставк" in hl or "маржа" in hl) and abs(value) <= 1.0:
        return "0.00%"
    if "грн" in hl or "₴" in hl or "uah" in hl:
        return '#,##0.00" грн"'
    if "$" in hl or "usd" in hl:
        return '#,##0.00" $"'
    if "€" in hl or "eur" in hl:
        return '#,##0.00" €"'
    return None


# ⭐⭐⭐ 553. ІМʼЯ ЛИСТА МАЄ ОДНОГО ПИСАРЯ І ЯВНИЙ ПЕРЕЛІК СИНОНІМІВ.
# 10.09.2026 модель написала {"name": "Inputs"}, код читав лише `sheet`/`title` —
# лист став «Лист», крос-посилання порвались, книга не поїхала клієнту. Перелік
# синонімів мусить бути НАЗВАНИЙ і лежати в одному місці, інакше наступний
# синонім знову зникне мовчки. Порядок значущий: `sheet` лишається першим, бо
# так було досі; `title` лишається останнім, бо це ще й заголовок у клітинці A1.
_SHEET_NAME_KEYS = ("sheet", "name", "sheet_name", "sheetName", "title")

# Значення параметра теж має ОДНОГО писаря: модель пише або `value`, або
# `formula` (жива формула в блоці параметрів — законна річ).
_PARAM_VALUE_KEYS = ("value", "formula")


def _first_key(d, keys):
    """Перше НЕПОРОЖНЄ значення з переліку ключів. Один писар вибору ключа."""
    if not isinstance(d, dict):
        return None
    for k in keys:
        v = d.get(k)
        if v is not None and str(v).strip() != "":
            return v
    return None


def _param_value(p):
    """Значення параметра: `value` або `formula`. НІКОЛИ не рядок «None»."""
    return _first_key(p, _PARAM_VALUE_KEYS)


def _sheet_final_name(s) -> str:
    return (str(_first_key(s, _SHEET_NAME_KEYS) or "Лист"))[:31]


def _spec_regions(sheets: list) -> dict:
    """ПРОХІД 1 координатного контракту: фізична геометрія КОЖНОГО листа ще до
    рендера — {імʼя: {n_params, ncols, hdr, first, last, totals}}. Джерело правди
    для крос-листових плейсхолдерів ({row:Лист}…) і для аудиту книги."""
    regions, used = {}, set()
    for s in sheets:
        name, k = _sheet_final_name(s), 2
        base = name
        while name in used:  # та сама логіка унікальності, що в рендері
            name = (base[:27] + f" ({k})")[:31]
            k += 1
        used.add(name)
        n = len(s.get("params") or [])
        cols = s.get("columns") or []
        rows = s.get("rows")
        nrows = len(rows) if rows else int(s.get("row_count") or 0)
        if cols and nrows:
            hdr = n + 3
            first, last = hdr + 1, hdr + nrows
        else:
            hdr = first = last = None
        regions[name] = {"n_params": n, "ncols": len(cols), "hdr": hdr,
                         "first": first, "last": last,
                         "totals": (last + 1) if (s.get("totals") and last) else None}
    return regions


def _render_model_sheet(ws, s, regions=None, sheet_name=None):
    """Рендерить ОДИН лист моделі у ws: блок параметрів зверху + таблиця з
    ЖИВИМИ формулами (зокрема перехресними між листами) + підсумки, і чепурить стиляром.
    Спека листа: sheet(назва), title(необ.), params[], columns[], rows[] АБО
    first_row/row_template/row_count, totals[]. regions — геометрія всіх листів
    книги (прохід 1) для крос-листових плейсхолдерів."""
    from openpyxl.styles import Font
    bold = Font(bold=True)
    ws.title = sheet_name or _sheet_final_name(s)
    ws.cell(row=1, column=1, value=s.get("title") or s.get("sheet") or "").font = Font(bold=True, size=13)
    params = s.get("params") or []
    n = len(params)
    # Геометрія ВЛАСНОГО листа (перший/останній рядок даних) відома з проходу 1
    # (_spec_regions). Передаємо її і в зону параметрів, щоб підсумок-формула угорі
    # листа на кшталт =SUM(F{first}:F{last}) стала живою, а не «сирою» (баг 16.07:
    # {first} у параметрі лишався незаповненим → весь файл падав у простий режим).
    _self = (regions or {}).get(ws.title) or {}
    _sf, _sl = _self.get("first"), _self.get("last")
    for k, p in enumerate(params, 1):
        ws.cell(row=1 + k, column=1, value=p.get("name")).font = bold
        _xm_cell(ws, 1 + k, 2, _xm_subst(_param_value(p), n, first=_sf, last=_sl, regions=regions))
        fmt = _xls_param_format(p.get("name"), ws.cell(row=1 + k, column=2).value)
        if fmt:
            ws.cell(row=1 + k, column=2).number_format = fmt
    columns = s.get("columns") or []
    if not columns:
        return  # лист лише з параметрами/підсумками — таблиці немає
    hdr = n + 3
    for _c, _name in enumerate(columns, 1):        # ЗАГОЛОВКИ КОЛОНОК у рядок hdr
        ws.cell(row=hdr, column=_c, value=str(_name))
    rows = s.get("rows")
    if not rows:
        rows = []
        for i in range(1, (s.get("row_count") or 0) + 1):
            if i == 1 and s.get("first_row"):
                rows.append(list(s["first_row"]))
            else:
                rows.append(list(s.get("row_template") or []))
    first, last = hdr + 1, hdr + len(rows)
    for i, row_vals in enumerate(rows, 1):
        r = hdr + i
        for c, v in enumerate(row_vals[:len(columns)], 1):
            _xm_cell(ws, r, c, _xm_subst(v, n, row=r, first=first, last=last, i=i,
                                         regions=regions),
                     money_fmt=(c > 1), header=columns[c - 1])
    totals_row = None
    if s.get("totals"):
        r = last + 1
        for c, v in enumerate(s["totals"][:len(columns)], 1):
            _xm_cell(ws, r, c, _xm_subst(v, n, row=r, first=first, last=last,
                                         regions=regions),
                     money_fmt=(c > 1), header=columns[c - 1])
        totals_row = last + 1
    style_worksheet(ws, header_row=hdr, data_first=first, data_last=last,
                    ncols=len(columns), totals_row=totals_row, numberize=False)


# Посилання формули на аркуш: 'Ім\'я з пробілами'!  АБО  Ім'я_без_пробілів!
# (?<!#) відсікає службовий #REF!. Використовується воротами цілісності книги.
_SHEET_REF_RE = re.compile(r"(?:'([^']{1,31})'|(?<![\w#])([\w]{1,31}))!", re.U)


def missing_sheet_refs(wb):
    """Імена аркушів, на які посилаються формули книги, але яких у книзі НЕМАЄ.
    Порожня множина = усі перехресні посилання цілі."""
    names = set(wb.sheetnames)
    missing = set()
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if isinstance(v, str) and v.startswith("="):
                    for m in _SHEET_REF_RE.finditer(v):
                        ref = (m.group(1) or m.group(2) or "").strip()
                        if ref and ref not in names:
                            missing.add(ref)
    return missing


# Посилання на клітинку/діапазон у формулі (з необов'язковим аркушем). Захисти:
# зліва не частина ідентифікатора; справа не «(» (щоб LOG10( не стало посиланням).
_CELL_REF_RE = re.compile(
    r"(?:(?:'([^']{1,31})'|([A-Za-zЀ-ӿ_][\wЀ-ӿ.]{0,30}))!)?"
    r"(?<![A-Za-z0-9_])\$?([A-Z]{1,3})\$?(\d{1,7})"
    r"(?::\$?([A-Z]{1,3})\$?(\d{1,7}))?(?![\w(])", re.U)

# Незаповнений плейсхолдер словника спеки (лишився в клітинці = брак).
_XM_PLACEHOLDER_RE = re.compile(r"\{(?:P\d+|row|prev|first|last|totals|i|name|value)(?:[+-]\d+)?(?::[^}]*)?\}")


def _xm_allowed_row(reg, col_idx, row_no) -> bool:
    """Чи дозволений цій формулі рядок цільового листа: значення параметрів
    (колонка B), рядки даних, рядок підсумків. Титул/шапка/порожнеча — НІ."""
    if not reg:
        return True  # невідомий лист перевіряє інша брама (missing_sheet_refs)
    n = reg.get("n_params", 0)
    if n and 2 <= row_no <= 1 + n:
        return col_idx == 2  # у блоці параметрів жива лише колонка B (A — підписи)
    if reg.get("first") and reg["first"] <= row_no <= reg["last"]:
        return True
    if reg.get("totals") and row_no == reg["totals"]:
        return True
    return False


def audit_workbook(wb, regions) -> list:
    """АУДИТ КООРДИНАТ КНИГИ (детермінований, без LLM). Ловить клас «правдоподібний
    файл із фейковими числами» (кредитний кейс 10.07 ~22:10): (а) незаповнені
    плейсхолдери; (б) формули/діапазони, що бʼють у службові рядки (титул, підписи,
    шапку) або повз дані; (в) циклічні посилання. Повертає список помилок поіменно."""
    from openpyxl.utils import column_index_from_string, get_column_letter
    errors, ph_errs, deps = [], [], {}
    for ws in wb.worksheets:
        reg_self = regions.get(ws.title)
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if not isinstance(v, str):
                    continue
                if _XM_PLACEHOLDER_RE.search(v):
                    ph_errs.append(f"{ws.title}!{cell.coordinate}: незаповнений "
                                   f"плейсхолдер «{_XM_PLACEHOLDER_RE.search(v).group(0)}»")
                    continue
                if not v.startswith("="):
                    continue
                node = (ws.title, cell.coordinate)
                deps.setdefault(node, set())
                for m in _CELL_REF_RE.finditer(v):
                    target = (m.group(1) or m.group(2) or ws.title).strip()
                    reg = regions.get(target)
                    c1 = column_index_from_string(m.group(3))
                    r1 = int(m.group(4))
                    if m.group(5):  # діапазон: перевіряємо обидва кінці й межі
                        c2 = column_index_from_string(m.group(5))
                        r2 = int(m.group(6))
                        lo, hi = min(r1, r2), max(r1, r2)
                        bad = [rr for rr in (lo, hi)
                               if not _xm_allowed_row(reg, c1, rr)]
                        if bad:
                            errors.append(
                                f"{ws.title}!{cell.coordinate}: діапазон "
                                f"{m.group(0).lstrip('=')} захоплює службові рядки "
                                f"{bad} листа «{target}»"
                                + (f" (дані: {reg['first']}–{reg['last']})" if reg and reg.get("first") else ""))
                        # цикли: ребра лише в межах розумного розміру
                        if reg and reg.get("first") and (hi - lo) <= 2000:
                            for rr in range(lo, hi + 1):
                                for cc in range(min(c1, c2), max(c1, c2) + 1):
                                    deps[node].add((target, f"{get_column_letter(cc)}{rr}"))
                    else:
                        if not _xm_allowed_row(reg, c1, r1):
                            hint = (f" (параметри: B2–B{1 + reg['n_params']}; "
                                    f"дані: {reg['first']}–{reg['last']})"
                                    if reg and reg.get("first") else "")
                            errors.append(f"{ws.title}!{cell.coordinate}: посилання "
                                          f"{m.group(0)} бʼє у службовий рядок листа "
                                          f"«{target}»{hint}")
                        deps[node].add((target, m.group(4) and
                                        f"{m.group(3)}{m.group(4)}"))
    # (в) цикли — ітеративний трикольоровий DFS
    WHITE, GRAY, BLACK = 0, 1, 2
    color = {}
    for start in deps:
        if color.get(start, WHITE) != WHITE:
            continue
        stack = [(start, iter(deps.get(start, ())))]
        color[start] = GRAY
        while stack:
            node, it = stack[-1]
            adv = False
            for nxt in it:
                nxt = (nxt[0], (nxt[1] or "").replace("$", "").upper())
                if nxt not in deps:
                    continue
                st = color.get(nxt, WHITE)
                if st == GRAY:
                    # ⛒ 17.09.2026. НАЗИВАЄМО НАЙЧАСТІШУ ПРИЧИНУ, А НЕ САМ ФАКТ.
                    # Живий прогін: модель поклала рядок «Разом» у rows — і {last}
                    # почав вказувати на нього самого, тобто підсумок підсумував сам
                    # себе. Повідомлення «циклічне посилання» правдиве, але нічого не
                    # підказує; коректор двічі виправляв не те. Тепер підказує.
                    errors.append(
                        "циклічне посилання: %s!%s ⇄ %s!%s (найчастіша причина — "
                        "рядок «Разом» покладено в rows: тоді {last} вказує на нього "
                        "самого. Підсумок має бути в полі totals, а не в rows)"
                        % (node[0], node[1], nxt[0], nxt[1]))
                elif st == WHITE:
                    color[nxt] = GRAY
                    stack.append((nxt, iter(deps.get(nxt, ()))))
                    adv = True
                    break
            if not adv:
                color[node] = BLACK
                stack.pop()
    # Баланс класів у звіті: заглушки не мають витісняти зсуви посилань і цикли.
    if len(ph_errs) > 3:
        ph_errs = ph_errs[:2] + [f"…і ще {len(ph_errs) - 2} незаповнених плейсхолдерів"]
    return (ph_errs + errors)[:12]


# ---------------------------------------------------------------------------
# ⭐⭐⭐ 10.09.2026, ЗМІНА 549. ОДИН ПИСАР ВИРОКУ ПРО ЦІЛІСНІСТЬ КНИГИ.
#
# КОРІНЬ (знайдено читанням коду наступного дня після 547). Сторож «розрив у
# ряді періодів» стояв лише в `_check_rendered`. Але .xlsx народжується в
# `write_result_artifacts`, а туди ведуть ТРИ шляхи, і лише ОДИН проходить
# через `_fix_xlsxmodel`: звіт планової роботи і покриття обіцянки про файл
# ідуть повз. На двох шляхах із трьох книга з пропущеним періодом записалась би
# МОВЧКИ — рівно та вада, яку ми лікували напередодні.
#
# ⛒ Дірка не в забутому сторожі, а в тому, що ПЕРЕЛІК воріт був переписаний
# РУКАМИ у трьох місцях. Це наш закон «ОДИН ПИСАР», не застосований до воріт:
# автор наступного сторожа мусив би памʼятати про три двері й повторив би 547.
# Тому перелік живе ТУТ і тільки тут. Додав сторожа — він сам став на всі двері.
#
# ЩО СЮДИ НЕ ВХОДИТЬ І ЧОМУ: ворота живої формули судять СПЕКУ (`params`,
# `require_live`), а не готову книгу, і лишаються в `_check_rendered`. Сюди
# йде лише те, що видно в самій книзі.
#
# ⚠ Порядок воріт значущий: спершу цілі посилання й координати, і аж потім
# повнота ряду — на книзі зі зламаними координатами числа першої колонки нічого
# не означають, і сторож ряду сварився б не на те.
BOOK_GATES = ("sheets", "dead", "coords", "junk", "series")

# СЛОВА НА КОЖНІ ВОРОТА: (початок, пояснення складачеві, скільки помилок казати).
# 🩸 Ворота без слів — це мовчазна відмова. Чек `book_gates_test.py` не дасть
# додати ворота в BOOK_GATES і забути про людину.
_GATE_SAYS = {
    "sheets": ("", "", 99),
    "dead": ("", "", 3),
    "coords": ("координати формул зламані — ",
               ". Використовуй плейсхолдери {row}/{prev}/{first}/{last}, "
               "а для чужого листа {row:Лист}/{first:Лист}/{last:Лист}/{Pk:Лист} — "
               "НІКОЛИ не вгадуй номери рядків.", 5),
    "junk": ("у книзі лишилось сміття з нечитаного поля спеки — ",
             ". Значення параметра задавай ключем \"value\" (число/текст) або "
             "\"formula\" (рядок, що починається з =). Імʼя листа — ключем "
             "\"sheet\" або \"name\". Порожній параметр, на який посилаються "
             "формули, робить усю книгу #VALUE!.", 5),
    "series": ("РОЗРИВ У РЯДІ ПЕРІОДІВ — ",
               ". Перший рядок таблиці (first_row) — це вже i=1, тому {i} "
               "у row_template дає 2 для ДРУГОГО рядка. Якщо перший період "
               "нульовий (місяць 0 — інвестиція), пиши в шаблоні {i-1}, а "
               "не {i}. Ряд періодів мусить іти рівним кроком без пропусків.", 4),
    # ⭐ 604: змішана одиниця відсотка. Слова тут — це те, що читає складач,
    # коли книгу повертають на виправлення, тому вони мусять називати ПРАВИЛО,
    # а не лише факт: інакше наступна спроба повторить ту саму одиницю.
    "units": ("ОДИНИЦЯ ВІДСОТКА ЗМІШАНА — ",
              ". У книзі відсоток зберігається ЧАСТКОЮ (9 % — це 0.09), а "
              "колонка «п.п.» — це різниця двох часток, помножена на 100. "
              "Не пиши відсоток числом 9 і не віднімай частку від числа.", 4),
    # ⭐ 606: підсумок проти своїх частин. Слова називають ПРАВИЛО, а не
    # лише факт: складач має зрозуміти, що підсумок — це формула, а не число.
    "math": ("ПІДСУМОК НЕ ЗІЙШОВСЯ З ВЛАСНИМИ ЧАСТИНАМИ — ",
             ". Рядок підсумків пишеться ФОРМУЛОЮ =SUM({first}:{last}) по своїй "
             "колонці, а не готовим числом: число не перерахується, коли клієнт "
             "змінить рядок, і книга починає суперечити сама собі.", 4),
}


# ⭐⭐⭐ 553. СМІТТЯ З НЕЧИТАНОГО ПОЛЯ СПЕКИ.
# Ворота 547/549 судять формули, координати й повноту ряду. Жодні з них не
# бачать клітинки, у якій лежить РЯДОК «None»: це не формула, не координата і
# не період. А саме так виглядає поле спеки, якого код не прочитав. Книга з
# такою клітинкою відкривається, має живі формули — і вся світиться #VALUE!.
_JUNK_CELL_VALUES = {"none", "nan", "null", "undefined", "nonetype", "n/a"}


def junk_cell_errors(wb, regions) -> list:
    """Сміття від нечитаного поля спеки: (а) клітинка-«None»; (б) ПОРОЖНІЙ
    параметр, на який СПРАВДІ посилаються формули.

    🩸 Свідомо вузько: порожній параметр сам по собі нікому не заважає —
    червонить лише той, чию адресу вже вписали у формулу. Так ворота не дають
    хибних тривог на листах-роздільниках."""
    errors = []
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if isinstance(v, str) and v.strip().lower() in _JUNK_CELL_VALUES:
                    errors.append(
                        "%s!%s: у клітинці лежить «%s» — поле спеки не прочитано"
                        % (ws.title, cell.coordinate, v.strip()))
    # (б) порожній параметр, на який є посилання
    used = set()
    for ws in wb.worksheets:
        for row in ws.iter_rows():
            for cell in row:
                if not isinstance(cell.value, str) or not cell.value.startswith("="):
                    continue
                for m in re.finditer(r"(?:'([^']{1,40})'!)?\$?B\$?(\d+)", cell.value):
                    used.add(((m.group(1) or ws.title).strip(), int(m.group(2))))
    for ws in wb.worksheets:
        reg = (regions or {}).get(ws.title) or {}
        for k in range(1, int(reg.get("n_params") or 0) + 1):
            r = 1 + k
            if (ws.title, r) not in used:
                continue
            if ws.cell(row=r, column=2).value in (None, ""):
                errors.append(
                    "%s!B%d: параметр «%s» порожній, але на нього посилаються "
                    "формули" % (ws.title, r,
                                 str(ws.cell(row=r, column=1).value or "")[:40]))
    return errors[:12]


def book_gate_errors(wb, regions) -> list:
    """ЄДИНИЙ ПИСАР: усі ворота цілісності ГОТОВОЇ книги, у сталому порядку.

    Повертає [(назва_воріт, [помилки])] — список, а не «так/ні», щоб кожен
    споживач дав свою пораду, але НІХТО не міг забути ворота.
    Порожній список помилок = ці ворота відчинені."""
    out = []
    _miss = missing_sheet_refs(wb)
    out.append(("sheets",
                ["формули посилаються на неіснуючі листи: " + ", ".join(sorted(_miss))]
                if _miss else []))
    out.append(("dead", list(dead_formula_errors(
        [c.value for ws in wb.worksheets for row in ws.iter_rows()
         for c in row if isinstance(c.value, str)]) or [])))
    out.append(("coords", list(audit_workbook(wb, regions) or [])))
    out.append(("junk", list(junk_cell_errors(wb, regions) or [])))
    out.append(("series", list(series_break_errors(wb, regions) or [])))
    # ⭐ 604: змішана одиниця відсотка — така сама неправда в готовій книзі, як
    # обірваний аркуш чи мертва формула, тому вона стоїть у тому самому переліку.
    try:
        import xlsx_units
        out.append(("units", list(xlsx_units.unit_errors(wb, regions) or [])))
    except Exception:
        out.append(("units", []))
    # ⭐ 606: підсумок, який не дорівнює сумі своїх частин, — така сама неправда в
    # готовій книзі, як змішана одиниця чи мертва формула, тому вона стоїть у тому
    # самому переліку, а не в окремому сторожа, про якого можна забути.
    try:
        import xlsx_calc
        out.append(("math", list(xlsx_calc.total_errors(wb, regions) or [])))
    except Exception:
        out.append(("math", []))
    return out


def book_is_whole(wb, regions) -> bool:
    """Коротка відповідь для записувачів файла: книгу віддавати можна?"""
    return not any(errs for _gate, errs in book_gate_errors(wb, regions))


def series_break_errors(wb, regions) -> list:
    """⭐⭐⭐ ВОРОТА «РОЗРИВ У РЯДІ ПЕРІОДІВ» (10.09.2026).

    КОРІНЬ, знайдений живим ходом 09.09.2026: {i} рахує рядки ВСІЄЇ таблиці,
    рахуючи й first_row. Поки перший рядок — це період 1, усе сходиться. Але
    фінмодель починається з періоду 0 (інвестиція): складач кладе 0 у first_row,
    пише {i} у row_template — і ряд виходить 0, 2, 3 … 24. Один період зникає
    МОВЧКИ, а контролер каже «розбіжність 0%», бо звіряє арифметику, а не
    ПОВНОТУ РЯДУ (урок 17 від 09.09.2026).

    Судимо готову книгу, а не слова: якщо перша колонка даних — суцільні числа,
    крок між сусідніми значеннями мусить бути ОДНАКОВИЙ. Розрив кроку — це
    втрачений або зайвий період, а не питання стилю. Текст, дати й формули не
    судимо взагалі: ряду періодів там немає."""
    import ast as _ast
    from collections import Counter
    _NUMF = re.compile(r"^=[\d\s+\-*/().]+$")   # чиста арифметика без імен клітинок
    errors = []
    for ws in wb.worksheets:
        reg = (regions or {}).get(ws.title) or {}
        first, last = reg.get("first"), reg.get("last")
        if not first or not last or (last - first) < 2:
            continue                     # менше трьох рядків — кроку ще немає
        vals, ok = [], True
        for r in range(first, last + 1):
            v = ws.cell(row=r, column=1).value
            if isinstance(v, str) and _NUMF.match(v.strip()):
                try:                     # ={i}-1 → "=2-1": для ока це число, не посилання
                    v = eval(compile(_ast.parse(v.strip()[1:], mode="eval"),
                                     "<series>", "eval"), {"__builtins__": {}}, {})
                except Exception:
                    ok = False
                    break
            if isinstance(v, bool) or not isinstance(v, (int, float)):
                ok = False               # назва, дата, посилання — не ряд періодів
                break
            vals.append(v)
        if not ok or len(vals) < 3:
            continue
        steps = [round(vals[k + 1] - vals[k], 6) for k in range(len(vals) - 1)]
        if len(set(steps)) <= 1:
            continue                     # крок однаковий — ряд цілий
        common = Counter(steps).most_common(1)[0][0]
        for k, st in enumerate(steps):
            if st != common:
                errors.append(
                    "аркуш «%s»: після %g одразу йде %g (крок %g), хоча решта ряду "
                    "йде кроком %g — між ними бракує періоду"
                    % (ws.title, vals[k], vals[k + 1], st, common))
                break
    return errors[:4]


def _render_book(model) -> tuple:
    """ЄДИНЕ рендер-ядро моделі/книги (2 проходи): (wb, regions).
    Використовується і збіркою файла, і перевіркою check_xlsxmodel — одна логіка,
    двоє воріт."""
    sheets = model.get("sheets") or [model]
    regions = _spec_regions(sheets)
    names = list(regions.keys())
    wb = openpyxl.Workbook()
    for idx, s in enumerate(sheets):
        ws = wb.active if idx == 0 else wb.create_sheet()
        _render_model_sheet(ws, s, regions=regions, sheet_name=names[idx])
    # ⭐⭐⭐ 604. ОДИНИЦІ ЗВОДИТЬ ОДИН ПИСАР, І САМЕ ТУТ — на виході рендер-ядра,
    # через яке проходять і збірка файла, і перевірка `check_xlsxmodel`. Доти
    # одиницю вирішували ЛОКАЛЬНО: формат — регуляркою по заголовку, «чи вже
    # помножено» — регуляркою по тексту формули. Текст формули не може знати
    # одиниці клітинки, на яку вказує, тому «=Параметри!$B$4» з числом 9
    # показувалось як 900 %, а «=E4-I4» у п.п. давало −8,9 замість −1,55.
    try:
        import xlsx_units
        xlsx_units.normalize(wb, regions)
    except Exception as _e:
        try:
            import llm as _llm
            _llm._log("[artifacts] писар одиниць не спрацював: %s" % _e)
        except Exception:
            pass
    return wb, regions


def xlsxmodel_to_xlsx(spec, path) -> bool:
    """Спека → справжній .xlsx: ОДИН лист, параметри зверху, таблиця з живими формулами."""
    if not _HAS_XLSX or not spec:
        return False
    wb, regions = _render_book(spec)
    # ВОРОТА ЦІЛІСНОСТІ — ПИТАЄМО ЄДИНОГО ПИСАРЯ (549). Тут НЕ можна перелічувати
    # сторожів руками: саме так 547 не доїхав до двох шляхів із трьох.
    if not book_is_whole(wb, regions):
        return False
    wb.save(str(path))
    origin.stamp(path)   # ⛒ 583: ОДИН писар походження на всі виходи
    return True


def xlsxbook_to_xlsx(book, path) -> bool:
    """Багатолистова книга: {title, sheets:[...]} → .xlsx з кількома листами
    та живими перехресними формулами. Єдине рендер-ядро _render_book (2 проходи)."""
    if not _HAS_XLSX or not book:
        return False
    if not (book.get("sheets") or None):
        return False
    wb, regions = _render_book(book)
    # ВОРОТА ЦІЛІСНОСТІ — ПИТАЄМО ЄДИНОГО ПИСАРЯ (549), той самий перелік, що й
    # для одного листа: два записувачі не сміють судити книгу по-різному.
    if not book_is_whole(wb, regions):
        return False
    wb.save(str(path))
    origin.stamp(path)   # ⛒ 583: ОДИН писар походження на всі виходи
    return True


# ---------------------------------------------------------------------------
# XLSX / CSV
# ---------------------------------------------------------------------------
_XLS_TOTAL_LABELS = {"разом", "всього", "усього", "итого", "підсумок", "подытог",
                     "total", "totals", "sum", "грандъ", "grand total"}


def _xls_apply_column_formats(ws, headers, r0, r1):
    """Уніфікує формат чисел у колонці за її заголовком (грн/$/€/%),
    щоб уся колонка виглядала однаково, а не рядок-у-рядок по-різному."""
    for c, h in enumerate(headers, 1):
        hl = str(h).lower()
        if "%" in hl or "відсот" in hl or "percent" in hl:
            fmt = "0.00%"
        elif "грн" in hl or "₴" in hl or "uah" in hl:
            fmt = '#,##0.00" грн"'
        elif "$" in hl or "usd" in hl:
            fmt = '#,##0.00" $"'
        elif "€" in hl or "eur" in hl:
            fmt = '#,##0.00" €"'
        else:
            continue
        for r in range(r0, r1 + 1):
            cell = ws.cell(r, c)
            if isinstance(cell.value, (int, float)) and fmt != "0.00%":
                cell.number_format = fmt
            elif isinstance(cell.value, (int, float)) and cell.value <= 1.0:
                cell.number_format = fmt  # частка → відсоток


def tables_to_xlsx(tables, path):
    if not _HAS_XLSX or not tables:
        return False
    wb = openpyxl.Workbook()
    wb.remove(wb.active)
    single = len(tables) == 1
    for idx, t in enumerate(tables, 1):
        title = "Дані" if single else f"Таблиця {idx}"
        ws = wb.create_sheet(title=title[:31])
        ws.append(t["headers"])
        for row in t["rows"]:
            ws.append(row)
        nrows = len(t["rows"])
        ncols = len(t["headers"])
        # чи є підсумковий рядок (перша клітинка = «Разом/Total/…»)?
        totals_row = None
        if nrows and t["rows"]:
            first_cell = str((t["rows"][-1] or [""])[0]).strip().lower()
            if first_cell in _XLS_TOTAL_LABELS:
                totals_row = 1 + nrows
        data_last = (totals_row - 1) if totals_row else (1 + nrows)
        style_worksheet(ws, header_row=1, data_first=2, data_last=data_last,
                        ncols=ncols, totals_row=totals_row, numberize=True)
        _xls_apply_column_formats(ws, t["headers"], 2, 1 + nrows)
    wb.save(str(path))
    origin.stamp(path)   # ⛒ 583: ОДИН писар походження на всі виходи
    return True


def tables_to_csv(tables) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    for idx, t in enumerate(tables, 1):
        if idx > 1:
            w.writerow([])
        w.writerow(t["headers"])
        for row in t["rows"]:
            w.writerow(row)
    return buf.getvalue()


# ---------------------------------------------------------------------------
# Головна функція
# ---------------------------------------------------------------------------
def result_title(md: str) -> str:
    """Перший заголовок (#/##/###) у Markdown — джерело для імені файлу."""
    for line in (md or "").splitlines():
        m = re.match(r"^\s{0,3}#{1,3}\s+(.+?)\s*#*\s*$", line)
        if m:
            return m.group(1).strip()
    return ""


def write_document_files(run_id: str, documents) -> list:
    """Кожен документ пакета — ОКРЕМИМ файлом (10.08.2026, зміна 144).

    Учасник подає на майданчик окремі файли, а не один зведений аркуш. Порядок
    зберігаємо номером у назві, щоб пакет читався так само, як складений.
    Зведений документ пише `write_result_artifacts` — він лишається для перегляду.
    """
    arts = []
    for i, d in enumerate(list(documents or []), 1):
        title = str((d or {}).get("title") or "документ").strip()
        body = str((d or {}).get("body") or "").strip()
        if not body:
            continue
        slug = store.slugify(title, 60) or ("dokument-%d" % i)
        base = "%02d_%s" % (i, slug)
        md = "# %s\n\n%s\n" % (title, body)
        arts.append(store.write_artifact(run_id, base + ".md", md))
        if _HAS_DOCX:
            try:
                path = store.run_dir(run_id) / (base + ".docx")
                if md_to_docx(md, path):
                    arts.append({"filename": base + ".docx", "path": str(path),
                                 "url": "/artifacts/%s/%s.docx" % (run_id, base)})
            except Exception:
                pass
    return arts


def write_result_artifacts(run_id: str, final_md: str, base_name: str = "final_result",
                           task: str = "", evidence=None) -> list:
    """Завжди .md + .html; за можливості .docx; таблиці -> .xlsx/.csv;
    презентаційний запит -> .pptx (якщо є python-pptx).

    ⛒ 620. `evidence` — оголошення шляху про те, що платформа СПРАВДІ читала
    в цьому прогоні. Без нього останні двері судять наосліп: число з голови
    під підписом «за даними» стає файлом, який клієнт надішле далі. Свідчення
    називає КОЖЕН із трьох шляхів — явно, зокрема й порожні."""
    arts = []
    if not final_md or not final_md.strip():
        return arts

    # Осмислена назва файлів: слаг із заголовка результату (або задачі), а не «final_result».
    if base_name == "final_result":
        slug = store.slugify(result_title(final_md) or task, 48)
        if slug:
            base_name = slug

    # Службовий блок Excel-моделі (```xlsxmodel) виймаємо з ЄДИНОГО джерела ПЕРШИМ —
    # ДО будь-якого рендера (HTML/дашборд/docx). Інакше, коли поруч є ще й блок ```chart,
    # HTML-дашборд печеться з тексту, де JSON ще присутній, і сирий блок протікає в .html
    # (баг протоку 16.07). У тексті лишається коротка довідка, .xlsx збереться з xmodel.
    xmodel, final_md = extract_xlsxmodel(final_md)
    # ЗАХИСТ (Правило №15): службовий блок, що не розпарсився (крива огорожа), НІКОЛИ
    # не сміє потрапити у файли/чат — вичищаємо на ВСІХ шляхах, не лише fail-closed.
    final_md = strip_service_blocks(final_md)
    # 554. Службова врізка платформи (застереження про НАШ збій) у файл клієнта
    # НЕ їде: він надсилатиме цей документ далі. У чаті вона лишається — там
    # сидить той, хто замовляв.
    final_md = strip_platform_notes(final_md, keep_text=False)

    # ⛒⛒⛒ 612. ОСТАННІ ДВЕРІ ПЕРЕД ФАЙЛОМ ЛЮДИНИ — ПОЛІТИКА РЕЗУЛЬТАТУ.
    #
    # 🩸 ЖИВА ВАДА 19.09.2026: писар закону про комерційну пропозицію
    # (`kp_document`, 610) стояв ЛИШЕ у тренувальному прогоні КП. Документ,
    # замовлений у чаті, кнопкою чи розкладом, ставав файлом непрочитаним — і
    # самосуперечливе КП (у тексті «12-й місяць», за власною таблицею 13-й)
    # спокійно перетворювалось на .md/.html/.docx/.xlsx для клієнта.
    #
    # ⭐ ЧОМУ САМЕ ТУТ. Сюди ведуть ТРИ шляхи (результат системи, звіт планової
    # роботи, покриття обіцянки про файл), і лише один із них проходить повз
    # виконавця. Той самий закон, що й у 549 (`BOOK_GATES`): сторож, якого немає
    # на одних дверях, — не сторож. І судиться САМЕ той текст, що стане файлом,
    # а не його чернетка: службову врізку вже знято рядком вище.
    #
    # ⛒ Політика мовчить про все, що не є її типом результату: чужий документ
    # проходить тут так само, як проходив до 612.
    try:
        import result_policy
        _policy_block = result_policy.blocks(final_md, "", evidence)
    except Exception as _erp:
        _policy_block = None
        import sys as _srp
        _srp.stderr.write("[result_policy] двері файла: суд не відбувся: %r\n" % (_erp,))
    if _policy_block:
        import sys as _srp2
        _srp2.stderr.write("[result_policy] ФАЙЛ НЕ НАПИСАНО: %s\n"
                           % _policy_block.get("reason", ""))
        try:
            import llm as _llm_rp
            _llm_rp._log("[artifacts] політика результату спинила видачу файла: %s"
                         % _policy_block.get("reason", ""))
        except Exception:
            pass
        return arts

    # FAIL-CLOSED (24.07.2026): якщо ЖИВА фінмодель не зібралась (слабкий мозок
    # віддав несумісну спеку — маркер лишає _fix_xlsxmodel), матеріалізатор НЕ
    # сміє клепати .xlsx з мертвих markdown-значень і видавати його за модель —
    # це була б неправда платформи. Тоді нарізку таблиць у .xlsx/.csv пропускаємо.
    _live_model_failed = (xmodel is None
                          and "Жива Excel-модель з формулами не зібралась" in (final_md or ""))

    # Якщо модель віддала готовий HTML-документ (презентація/дашборд із графіками) —
    # робимо його РЕАЛЬНИМ відкриваним .html, а в .md/.docx лишаємо чистий текст без коду.
    html_doc, md_for_docs = extract_html_document(final_md)
    if html_doc:
        html_doc = _inject_chart_safety(html_doc)
        md_render = md_for_docs
        # Якщо після виймання HTML текстова частина майже порожня — наповнюємо
        # .md/.docx текстом, витягнутим із самого HTML (інакше Word виходить пустий).
        if len(re.sub(r"\W+", "", md_render or "")) < 200:
            extracted = _html_to_text(html_doc)
            if extracted:
                md_render = ((md_for_docs or "").strip() + "\n\n" + extracted).strip()
    else:
        # АРХІТЕКТУРА «дані → рендер»: модель віддала текстовий звіт + блоки ```chart.
        # Платформа сама будує дашборд; звіт лишається єдиним джерелом для .md/.docx/.xlsx.
        charts, md_report = extract_charts(final_md)
        md_render = md_report
        if charts:
            dash_title = result_title(md_report) or (task or "Дашборд")
            html_doc = render_dashboard_html(md_report, charts, dash_title)

    arts.append(store.write_artifact(run_id, f"{base_name}.md", md_render))
    if html_doc:
        arts.append(store.write_artifact(run_id, f"{base_name}.html", html_doc))
    else:
        arts.append(store.write_artifact(run_id, f"{base_name}.html", md_to_html(md_render)))

    # DOCX
    if _HAS_DOCX:
        try:
            docx_path = store.run_dir(run_id) / f"{base_name}.docx"
            if md_to_docx(md_render, docx_path):
                arts.append({"filename": f"{base_name}.docx", "path": str(docx_path),
                             "url": f"/artifacts/{run_id}/{base_name}.docx"})
        except Exception:
            pass

    # Excel-модель → .xlsx з живими формулами (пріоритет над нарізкою таблиць)
    model_xlsx_done = False
    if xmodel and _HAS_XLSX:
        try:
            xlsx_path = store.run_dir(run_id) / f"{base_name}.xlsx"
            _render_ok = (xlsxbook_to_xlsx(xmodel, xlsx_path) if xmodel.get("sheets")
                          else xlsxmodel_to_xlsx(xmodel, xlsx_path))
            if _render_ok:
                arts.append({"filename": f"{base_name}.xlsx", "path": str(xlsx_path),
                             "url": f"/artifacts/{run_id}/{base_name}.xlsx"})
                model_xlsx_done = True
        except Exception:
            pass

    # Таблиці -> XLSX / CSV (fallback для звичайних звітів без Excel-моделі)
    tables = extract_tables(md_render)
    if tables and model_xlsx_done:
        tables = []  # модель уже дала .xlsx — не перезаписувати його нарізкою
    if tables and _live_model_failed:
        tables = []  # fail-closed: не видавати мертві значення фінмоделі за .xlsx-модель
    if tables:
        if _HAS_XLSX:
            try:
                xlsx_path = store.run_dir(run_id) / f"{base_name}.xlsx"
                if tables_to_xlsx(tables, xlsx_path):
                    arts.append({"filename": f"{base_name}.xlsx", "path": str(xlsx_path),
                                 "url": f"/artifacts/{run_id}/{base_name}.xlsx"})
            except Exception:
                pass
        else:
            arts.append(store.write_artifact(run_id, f"{base_name}.csv", tables_to_csv(tables)))

    # PPTX — лише коли запит/результат презентаційний
    if _HAS_PPTX and looks_like_presentation(task, final_md):
        try:
            pptx_path = store.run_dir(run_id) / f"{base_name}.pptx"
            if md_to_pptx(md_render, pptx_path):
                arts.append({"filename": f"{base_name}.pptx", "path": str(pptx_path),
                             "url": f"/artifacts/{run_id}/{base_name}.pptx"})
        except Exception:
            pass

    return arts
