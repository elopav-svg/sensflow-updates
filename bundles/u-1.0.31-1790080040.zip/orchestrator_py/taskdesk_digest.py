# -*- coding: utf-8 -*-
"""ЗВЕДЕННЯ ЗАМІСТЬ ПʼЯТНАДЦЯТИ СПОВІЩЕНЬ (зміна 241, 27.08.2026).

КОРІНЬ. Зі звіту дослівно: замість пʼятнадцяти окремих сповіщень людина має
отримати ОДНЕ зведення за проміжок. Телеграм-пульт найшвидше перетворюється на
шум, який вимикають, — а вимкнений пульт не сповіщає вже ні про що.

МЕЖА ПРОХОДИТЬ ПО РОЛІ, А НЕ ПО ВИДУ ПОДІЇ. Її проводить `tasks.audience()`:
від кого чекають дії — сповіщення одразу; кого лише повідомляють — у зведення.
Тут ця межа не перераховується: другий суддя аудиторії розійшовся б із першим.

ЩО ТУТ ВИРІШЕНО
1. ОДИН ЖУРНАЛ. Зведення не має власної черги: воно читає ТОЙ САМИЙ журнал
   подій, а в події лежить перелік «кому у зведення». Друга копія правди
   розійшлась би з першою на першому ж збої.
2. ВОДЯНИЙ ЗНАК НА ЛЮДИНУ, А НЕ НА ПРОЦЕС. У файлі лежить, до якої події цій
   людині вже надіслано. Перезапуск сервера не шле те саме вдруге, а людина,
   яка щойно підключила телеграм, не отримує всю історію.
3. ЗНАК РУХАЄТЬСЯ ЛИШЕ ПІСЛЯ УСПІШНОЇ ВІДПРАВКИ І ЛИШЕ ВПЕРЕД. Не дійшло —
   спробуємо завтра з того самого місця.
4. ПОРОЖНЄ ЗВЕДЕННЯ НЕ НАДСИЛАЄТЬСЯ. «За добу нічого не сталось» — це той
   самий шум, від якого ми тікаємо.
5. НІКОЛИ НЕ КИДАЄ НАГОРУ: фоновий потік не сміє зупинити платформу. Але й не
   мовчить — кожна невдача названа в журналі сервера.

ЧОГО СЮДИ НЕ ЗАЇХАЛО
- Налаштування періоду для кожної людини. Поки — названа типова година; екран
  налаштувань додасть роботи людині ще до того, як вона почала користуватись.
- Друга черга «на відправку». Черга вже є — це журнал подій.
"""

import json
import sys

import clock
import config
import taskdesk_events as events
import taskdesk_people as people
import taskdesk_telegram as mouth
import one_writer

DESK_DIR = config.STATE_DIR / "taskdesk"
config.refuse_live_state_for_checks(__name__)

MARK = DESK_DIR / "digest_marks.json"

# Названа типова година: зведення приходить уранці, до початку роботи.
HOUR = 9
SLEEP_SEC = 300
MAX_LINES = 40          # довше за екран телефона ніхто не читає


class DigestError(Exception):
    """Відмова з причиною словами."""


def _marks() -> dict:
    try:
        return one_writer.read_json(MARK)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        return {}


def _save_marks(m: dict) -> None:
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(MARK, m)


def pending(emp_id: str, rows=None) -> list:
    """Події, які ЦІЙ людині ще не пішли у зведенні. Порядок — як у журналі."""
    emp_id = str(emp_id or "").strip()
    if not emp_id:
        return []
    seen = int(_marks().get(emp_id, 0))
    out = []
    for e in (rows if rows is not None else events.all_events()):
        if int(e.get("id") or 0) <= seen:
            continue
        if emp_id in (e.get("digest") or []):
            out.append(e)
    return out


def text_for(rows) -> str:
    """Одне повідомлення на всі події: по рядку на ЗАДАЧУ, а не на подію.

    Людині важливо «що змінилось у справах, за якими я стежу», а не перелік
    натискань. Тому групуємо по задачі й називаємо число."""
    by = {}
    order = []
    for e in rows:
        tid = str(e.get("task_id") or "")
        if tid not in by:
            by[tid] = {"title": e.get("task_title") or tid, "n": 0, "last": ""}
            order.append(tid)
        by[tid]["n"] += 1
        by[tid]["last"] = str(e.get("kind") or "")
    head = ("Зведення за час, поки вас не турбували. Ви стежите за цими "
            "задачами — дій від вас ніхто не чекає.")
    lines = []
    for tid in order[:MAX_LINES]:
        d = by[tid]
        tail = (" · %d зміни" % d["n"]) if d["n"] > 1 else ""
        lines.append("• %s %s%s" % (tid, d["title"], tail))
    if len(order) > MAX_LINES:
        lines.append("… і ще задач: %d" % (len(order) - MAX_LINES))
    return head + "\n\n" + "\n".join(lines)


def due_now(now: str = "") -> bool:
    """Чи настала година зведення. Окремою функцією — щоб її можна було
    спитати, а не вгадувати за поведінкою потоку."""
    now = now or clock.now()
    try:
        return int(str(now)[11:13]) == HOUR
    except Exception:
        return False


def sweep(send=None, now: str = "") -> dict:
    """Розіслати зведення тим, кому назбиралось. Повертає, що сталося."""
    send = send or mouth._send
    rows = events.all_events()
    marks = _marks()
    stat = {"people": 0, "sent": 0, "no_chat": 0, "failed": 0, "empty": 0}
    for emp in people.employees(True):
        eid = emp["id"]
        mine = pending(eid, rows)
        if not mine:
            stat["empty"] += 1
            continue
        stat["people"] += 1
        chat = mouth.chat_of(eid)
        if not chat:
            # ⛒ Недоступний канал НЕ ТИША: людина мусить знати, що її зведення
            # нікуди не йде, а ми — бачити це в журналі сервера.
            stat["no_chat"] += 1
            sys.stderr.write("[зведення] %s: телеграм не підключено, зведення "
                             "нікуди не йде\n" % (emp.get("full_name") or eid))
            continue
        try:
            ok = send(chat, text_for(mine))
        except Exception as ex:
            ok = False
            sys.stderr.write("[зведення] %s: не надіслано (%s)\n" % (eid, ex))
        if not ok:
            stat["failed"] += 1
            continue
        marks[eid] = max(int(e.get("id") or 0) for e in mine)
        stat["sent"] += 1
    if stat["sent"]:
        _save_marks(marks)
    return stat


def loop(sleep_sec: int = SLEEP_SEC):
    """Фоновий потік. ОКРЕМИЙ від решти навмисно: поломка зведення не сміє
    зупиняти ні автоматизації, ні сторожа строків."""
    import time
    last_day = ""
    while True:
        try:
            today = clock.now()[:10]
            if due_now() and today != last_day:
                st = sweep()
                if st["sent"]:
                    print("[зведення] надіслано: %d" % st["sent"])
                last_day = today
        except Exception as ex:
            sys.stderr.write("[зведення] спіткнулось: %s\n" % ex)
        time.sleep(sleep_sec)
