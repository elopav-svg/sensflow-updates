# -*- coding: utf-8 -*-
"""
client_restore.py — ⭐⭐⭐ ПОВЕРНУТИ СВОЄ (зміна 571, 12.09.2026).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ: **КОПІЯ, ЯКУ НІХТО НЕ ВМІЄ ПОВЕРНУТИ, — ЦЕ НЕ КОПІЯ,
А ВІРА В КОПІЮ.** Платформа вміла віддати людині архів її даних, і на цьому
все: механізму покласти архів назад не існувало жодного. Обіцянка «ваші дані
ваші» була покрита рівно наполовину, а друга половина знадобиться саме того
дня, коли машина вмерла, — тобто в найгіршу мить.

ТРИ РІШЕННЯ, НА ЯКИХ ЦЕ СТОЇТЬ.

  ⭐ ПЕРШЕ: **ВІДНОВЛЕННЯ НЕ ПИТАЄ ЛІЦЕНЗІЮ.** Дзеркало експорту. Людина
  повертає СВОЄ; ворота оплати тут відмовляли б рівно в той день, заради якого
  цей механізм існує.

  ⭐ ДРУГЕ: **СУДДЯ ОДИН НА ОБИДВА НАПРЯМКИ** — `client_export.is_client_data`.
  Свого переліку тек тут немає й бути не може: два переліки одного класу
  розходяться, і розійшовшись дають ваду, якої ніхто не бачить — файл поїхав в
  архів, а назад не вернувся.

  ⭐ ТРЕТЄ: **АРХІВ — ЦЕ ЗОВНІШНІЙ ФАЙЛ, А НЕ ДРУГ.** Імена всередині нього
  пише хто завгодно, тож кожне проходить того самого суддю: шлях, що веде за
  корінь продукту, наш код і секрети не виймаються ніколи. Те, що затирається,
  спершу лягає в бекап; будь-який збій посеред роботи — повний відкат.

Запуск:  python client_restore.py               (знайде архів поруч)
         python client_restore.py <шлях.zip>
"""
import json
import shutil
import sys
import zipfile
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent          # orchestrator_py
ROOT = HERE.parent                              # корінь продукту

sys.path.insert(0, str(HERE))
import client_export as EXP  # noqa: E402  (ОДИН суддя на обидва напрямки)

BACKUPS_DIRNAME = "_backups"


def accepts(rel_path) -> bool:
    """Чи цей запис архіву можна класти на машину. Питаємо суддю експорту."""
    return EXP.is_client_data(rel_path)


def archives_near(root: Path = None) -> list:
    """Архіви даних, які лежать поруч. Імʼя архіву знає той, хто його творить."""
    root = Path(root or ROOT)
    found = []
    for place in (root, root.parent, Path.home() / "Desktop", Path.home() / "Downloads"):
        try:
            if place.is_dir():
                found += list(place.glob(EXP.ARCHIVE_PREFIX + "*.zip"))
        except Exception:
            continue
    uniq = {p.resolve(): p for p in found}
    return sorted(uniq.values(), key=lambda p: p.stat().st_mtime, reverse=True)


def plan(archive, root: Path = None) -> dict:
    """Що з архіву буде взято, а що ні — ДО того, як щось змінилось."""
    root = Path(root or ROOT)
    take, skip = [], []
    with zipfile.ZipFile(str(archive)) as z:
        for m in z.namelist():
            if m.endswith("/"):
                continue
            if m == EXP.README_NAME:
                continue                      # пояснення для людини, не дані
            if accepts(m):
                take.append(m)
            else:
                skip.append((m, "це не дані машини — код, ключ або чужий шлях"))
    return {"take": take, "skip": skip, "root": str(root)}


def _write_one(data: bytes, dst: Path):
    """Один файл на диск. Окремою функцією — щоб проба вміла зламати саме її."""
    dst.parent.mkdir(parents=True, exist_ok=True)
    dst.write_bytes(data)


def restore(archive, root: Path = None) -> dict:
    """Кладе дані з архіву назад. Повертає {ok, restored, skipped, backup_dir, message}."""
    root = Path(root or ROOT)
    archive = Path(archive)
    res = {"ok": False, "restored": 0, "skipped": [], "backup_dir": "", "message": ""}
    if not archive.is_file():
        res["message"] = "Файла архіву немає: %s" % archive
        return res
    try:
        pl = plan(archive, root)
    except Exception as ex:
        res["message"] = "Це не читається як архів даних (%s)." % ex
        return res
    res["skipped"] = [n for n, _ in pl["skip"]]
    if not pl["take"]:
        res["message"] = ("У цьому архіві немає даних SensFlow. Візьміть файл, "
                          "що починається на «%s»." % EXP.ARCHIVE_PREFIX)
        return res

    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    bdir = root / BACKUPS_DIRNAME / ("restore_%s" % ts)
    overwritten, added = [], []
    try:
        with zipfile.ZipFile(str(archive)) as z:
            # 1) бекап того, що затремо; реєстрація того, що додаємо
            bdir.mkdir(parents=True, exist_ok=True)
            for m in pl["take"]:
                target = root / m
                if target.exists():
                    dst = bdir / m
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, dst)
                    overwritten.append(m)
                else:
                    added.append(m)
            (bdir / "_changeset.json").write_text(
                json.dumps({"overwritten": overwritten, "added": added,
                            "archive": str(archive)}, ensure_ascii=False),
                encoding="utf-8")
            # 2) кладемо
            for m in pl["take"]:
                _write_one(z.read(m), root / m)
        res["ok"] = True
        res["restored"] = len(pl["take"])
        res["backup_dir"] = str(bdir)
        res["message"] = "Повернуто файлів: %d." % len(pl["take"])
        return res
    except Exception as ex:
        _rollback(root, bdir, overwritten, added)
        res["backup_dir"] = str(bdir)
        res["message"] = ("Збій під час повернення (%s) — машину повернуто в той "
                          "стан, що був до початку." % ex)
        return res


def _rollback(root: Path, bdir: Path, overwritten: list, added: list):
    """Кладе назад затерте й прибирає щойно додане."""
    for m in overwritten:
        src = bdir / m
        if src.exists():
            dst = root / m
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
    for m in added:
        try:
            (root / m).unlink()
        except Exception:
            pass


def _pick(args) -> Path:
    """Який архів брати. Один — беремо його; кілька — питаємо номер."""
    if args:
        return Path(args[0].strip('"'))
    found = archives_near()
    if not found:
        return None
    if len(found) == 1:
        return found[0]
    print(" Знайдено кілька архівів. Який повернути?\n")
    for i, p in enumerate(found[:9], 1):
        when = datetime.fromtimestamp(p.stat().st_mtime).strftime("%d.%m.%Y %H:%M")
        print("   %d) %s   (%s, %.1f МБ)"
              % (i, p.name, when, p.stat().st_size / 1048576.0))
    print("")
    try:
        n = int(input(" Номер (Enter — найновіший): ").strip() or "1")
    except Exception:
        n = 1
    return found[max(1, min(n, len(found[:9]))) - 1]


def main() -> int:
    print("=" * 60)
    print(" SensFlow - повернути ваші дані з архіву")
    print("=" * 60)
    arc = _pick(sys.argv[1:])
    if not arc:
        print(" Архіву поруч не знайдено.")
        print(" Покладіть файл «%s....zip» у теку продукту" % EXP.ARCHIVE_PREFIX)
        print(" і запустіть цю кнопку ще раз.")
        print("=" * 60)
        return 1
    print(" Архів: %s" % arc)
    res = restore(arc)
    print(" %s" % res["message"])
    if res.get("backup_dir") and res.get("ok"):
        print(" Те, що було замінено, збережено тут:")
        print("   %s" % res["backup_dir"])
    if res.get("skipped"):
        print(" Не взято з архіву (це не дані машини): %d"
              % len(res["skipped"]))
    print(" Перезапустіть SensFlow, щоб він побачив повернене.")
    print("=" * 60)
    return 0 if res["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
