# -*- coding: utf-8 -*-
"""
https_access.py — зміна 537, 08.09.2026.

ОДНА ТОЧКА, ЯКА ВІДПОВІДАЄ НА ПИТАННЯ «ЧИ ЗАШИФРОВАНО».

ЧОМУ ОКРЕМИЙ МОДУЛЬ. Те саме, що й з адресою (`network_access.py`): на це
питання відповідають ТРОЄ — сервер (чим накрити сокет), екран «Доступи»
(що показати людині) і замок мережі (чи можна взагалі відкриватись). Три
власні відповіді на одне питання рано чи пізно розійдуться, і розійдуться
ТИХО. Тому відповідь одна й лежить тут.

ЩО МИ ЗАХИЩАЄМО. Рішення Андрія 08.09.2026: конфіденційність у ПЕРИМЕТРІ
ОФІСУ. Люди заходять зі своїх комп'ютерів через офісний роутер; усе, що
йде всередині офісу — паролі, угоди, документи — має бути закрите.
Назовні платформа не виходить взагалі.

ТРИ ПРАВИЛА, НА ЯКИХ ЦЕ ТРИМАЄТЬСЯ.

  1. ШИФРУВАННЯ — НЕ ОКРЕМИЙ ВИМИКАЧ. Його не можна вимкнути окремо від
     мережі. Мережа відкрита → шифрування є. Немає придатного сертифіката
     → мережа НЕ відкривається. Це ТРЕТІЙ ПОВЕРХ того самого замка, на
     якому вже стоять «вхід із паролем» і «пароль, а не легкий режим».

  2-a. ⛒ 568. КЛЮЧ ОФІСУ ЖИВЕ У СХОВИЩІ WINDOWS, А PFX — ЛИШЕ ПЕРЕНОСНА
     КОПІЯ. Донині перевипуск відкривав `office_ca.pfx` паролем із `made.json`
     — тобто таємниця жила ОКРЕМО від файла, який вона відкриває, і та сама
     Windows, що ключ зробила, свій же pfx імпортувати відмовлялась
     («The specified network password is not correct», журнал 12.09.2026).
     Тепер ключ офісу беремо зі сховища за імʼям `CN=SensFlow Office Key`,
     pfx лишається для сумісності й пишеться сучасним форматом, а якщо ключа
     немає НІДЕ — робимо новий і кажемо ціну вголос.

  2. КЛЮЧ НАРОДЖУЄ САМА WINDOWS, а не наш код. Ми не пишемо власної
     криптографії: ключ і сертифікат створює вбудований засіб системи
     (`New-SelfSignedCertificate`), а цей модуль лише перекладає готові
     числа у формат, який читає Python. Ключ народжується на машині
     клієнта і НІКУДИ З НЕЇ НЕ ЇДЕ.

  3. ПРАЦІВНИКАМ СТАВИТЬСЯ КЛЮЧ ОФІСУ, А НЕ СЕРТИФІКАТ СЕРВЕРА. Машина
     створює собі ВЛАСНИЙ ключ офісу (на 10 років) і ним підписує
     сертифікат сервера (на 5). У браузери працівників один раз ставиться
     ключ офісу. Далі сервер може змінити адресу чи перевипустити свій
     сертифікат — і обходити десять комп'ютерів удруге не треба.
     Сертифікат сервера, виписаний на адресу, обходу вимагав би щоразу.

ЩО ЛЕЖИТЬ НА ДИСКУ (тека `certs`, оголошена ЖИВИМ СТАНОМ машини — вона не
їде в клієнтський пакет і не затирається оновленням):

    office_ca.crt.pem  — ключ офісу, ВІДКРИТА частина. Цей файл і тільки
                         цей роздається на комп'ютери працівників.
    office_ca.key.pem  — ключ офісу, ТАЄМНА частина. Не покидає машину.
    office_ca.pfx      — той самий ключ офісу у форматі Windows: потрібен,
                         щоб перевипустити сертифікат сервера, не турбуючи
                         працівників.
    server.crt.pem     — сертифікат сервера на поточну адресу.
    server.key.pem     — таємний ключ сервера.
    made.json          — хто і коли зробив. Це НОТАТКА ДЛЯ ЕКРАНА.

🩸 СУДДЯ — САМ ФАЙЛ, А НЕ НАША НОТАТКА. Строк дії і адресу ми читаємо з
самого сертифіката (мінімальний розбір DER нижче), а не з `made.json`.
Нотатка може розійтись із дійсністю; сертифікат — ні. Це той самий урок,
що й «чек мусить питати те місце, яке за намір відповідає».

Жодних зовнішніх залежностей.
"""

import base64
import datetime
import json
import os
import socket
import ssl
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import config  # noqa: E402
import one_writer  # noqa: E402

# ── Імена файлів. Одне місце, щоб екран, чек і збирач не вигадували своїх ──
CA_CRT = "office_ca.crt.pem"
CA_KEY = "office_ca.key.pem"
CA_PFX = "office_ca.pfx"
SRV_CRT = "server.crt.pem"
SRV_KEY = "server.key.pem"
MADE = "made.json"

CA_YEARS = 10          # ключ офісу: ставиться працівникам ОДИН раз
SRV_YEARS = 5          # сертифікат сервера: перевипускається без обходу машин
WARN_DAYS = 30         # за скільки днів до кінця почати попереджати

# Чому шифрування непридатне — мовою, яку розуміє екран і вікно запуску.
PROBLEM_MISSING = "missing"       # сертифіката ще немає
PROBLEM_BROKEN = "broken"         # файли є, але не читаються
PROBLEM_EXPIRED = "expired"       # строк вийшов
PROBLEM_IP = "ip_changed"         # адреса машини змінилась, сертифікат чужий


def certs_dir():
    """Тека ключів. 🩸 Адресу рахує ЛИШЕ `config` — правило продукту."""
    return config.CERTS_DIR


def paths() -> dict:
    d = certs_dir()
    return {
        "dir": d,
        "ca_crt": d / CA_CRT,
        "ca_key": d / CA_KEY,
        "ca_pfx": d / CA_PFX,
        "srv_crt": d / SRV_CRT,
        "srv_key": d / SRV_KEY,
        "made": d / MADE,
    }


# ═══════════════════════════════════════════════════════════════════════════
# МІНІМАЛЬНИЙ РОЗБІР СЕРТИФІКАТА
#
# Нам треба знати рівно три речі: доки він дійсний, на які адреси виписаний
# і чи він — ключ офісу. Це НЕ криптографія: ми нічого не перевіряємо й
# нічого не підписуємо, а лише читаємо поля з файла. Підпис і шифрування
# робить `ssl` (тобто OpenSSL), як і робив.
# ═══════════════════════════════════════════════════════════════════════════

_OID_SAN = b"\x55\x1d\x11"   # subjectAltName — адреси, на які виписано
_OID_BC = b"\x55\x1d\x13"    # basicConstraints — чи це ключ, яким підписують


def _tlv(buf, i):
    """Один вузол DER: (тег, початок вмісту, кінець вмісту, початок наступного)."""
    tag = buf[i]
    i += 1
    n = buf[i]
    i += 1
    if n & 0x80:
        k = n & 0x7F
        n = int.from_bytes(buf[i:i + k], "big")
        i += k
    return tag, i, i + n, i + n


def _children(buf, start, end):
    out = []
    i = start
    while i < end:
        tag, s, e, nxt = _tlv(buf, i)
        out.append((tag, s, e))
        i = nxt
    return out


def _parse_time(raw: bytes, tag: int):
    t = raw.decode("ascii", "ignore").strip()
    if t.endswith("Z"):
        t = t[:-1]
    if tag == 0x17:                      # UTCTime: YYMMDDHHMMSS
        yy = int(t[0:2])
        year = 2000 + yy if yy < 50 else 1900 + yy
        rest = t[2:]
    else:                                # GeneralizedTime: YYYYMMDDHHMMSS
        year = int(t[0:4])
        rest = t[4:]
    mo = int(rest[0:2])
    dd = int(rest[2:4])
    hh = int(rest[4:6]) if len(rest) >= 6 else 0
    mi = int(rest[6:8]) if len(rest) >= 8 else 0
    ss = int(rest[8:10]) if len(rest) >= 10 else 0
    return datetime.datetime(year, mo, dd, hh, mi, ss)


def pem_to_der(text: str) -> bytes:
    body = []
    keep = False
    for line in str(text or "").splitlines():
        if line.startswith("-----BEGIN"):
            keep = True
            continue
        if line.startswith("-----END"):
            break
        if keep:
            body.append(line.strip())
    return base64.b64decode("".join(body))


def cert_facts(der: bytes) -> dict:
    """Строк дії, адреси й «чи це ключ офісу» — прочитані з самого файла."""
    out = {"not_before": None, "not_after": None, "ips": [], "dns": [], "is_ca": False}
    _t, s, e, _n = _tlv(der, 0)                       # Certificate
    kids = _children(der, s, e)
    tbs = kids[0]                                     # tbsCertificate
    for (t, cs, ce) in _children(der, tbs[1], tbs[2]):
        if t == 0x30 and out["not_after"] is None:
            two = _children(der, cs, ce)
            if len(two) == 2 and all(x[0] in (0x17, 0x18) for x in two):
                out["not_before"] = _parse_time(der[two[0][1]:two[0][2]], two[0][0])
                out["not_after"] = _parse_time(der[two[1][1]:two[1][2]], two[1][0])
        elif t == 0xA3:                               # extensions [3]
            seq = _children(der, cs, ce)
            if not seq:
                continue
            for (_et, es, ee) in _children(der, seq[0][1], seq[0][2]):
                parts = _children(der, es, ee)
                if not parts:
                    continue
                oid = der[parts[0][1]:parts[0][2]]
                val = None
                for (pt, ps, pe) in parts[1:]:
                    if pt == 0x04:
                        val = (ps, pe)
                if val is None:
                    continue
                if oid == _OID_SAN:
                    inner = _children(der, val[0], val[1])
                    if inner:
                        for (gt, gs, ge) in _children(der, inner[0][1], inner[0][2]):
                            if gt == 0x82:
                                out["dns"].append(der[gs:ge].decode("ascii", "ignore"))
                            elif gt == 0x87 and (ge - gs) == 4:
                                out["ips"].append(".".join(str(b) for b in der[gs:ge]))
                elif oid == _OID_BC:
                    inner = _children(der, val[0], val[1])
                    if inner:
                        for (bt, bs, be) in _children(der, inner[0][1], inner[0][2]):
                            if bt == 0x01 and be > bs and der[bs] != 0:
                                out["is_ca"] = True
    return out


def facts_of(path) -> dict:
    """Факти сертифіката з файла. Порожньо — отже прочитати не вдалось."""
    try:
        text = open(str(path), "r", encoding="utf-8", errors="ignore").read()
        return cert_facts(pem_to_der(text))
    except Exception:
        return {}


# ═══════════════════════════════════════════════════════════════════════════
# СТАН — ОДНА ВІДПОВІДЬ ДЛЯ СЕРВЕРА, ЕКРАНА, ВІКНА ЗАПУСКУ І ЧЕКА
# ═══════════════════════════════════════════════════════════════════════════

def _lan_ip() -> str:
    """Адреса машини в офісній мережі. Питаємо сусіда, щоб відповідь була одна."""
    try:
        import network_access as _net
        return _net.lan_ip()
    except Exception:
        return ""


def state() -> dict:
    """Повний стан шифрування. Судить ФАЙЛИ, а не нотатку."""
    p = paths()
    ip_now = _lan_ip()
    out = {
        "have": False,
        "usable": False,
        "problem": PROBLEM_MISSING,
        "detail": "",
        "ip_now": ip_now,
        "ips": [],
        "not_after": "",
        "days_left": 0,
        "expiring": False,
        "ca_not_after": "",
        "ca_days_left": 0,
        "maker": "",
        "made_at": "",
        "ca_source": "",
        "ca_renewed": False,
    }
    have_files = all(os.path.exists(str(p[k])) for k in ("ca_crt", "srv_crt", "srv_key"))
    if not have_files:
        return out
    out["have"] = True
    srv = facts_of(p["srv_crt"])
    ca = facts_of(p["ca_crt"])
    if not srv or not srv.get("not_after") or not ca or not ca.get("not_after"):
        out["problem"] = PROBLEM_BROKEN
        return out
    now = datetime.datetime.utcnow()
    out["ips"] = list(srv.get("ips") or [])
    out["not_after"] = srv["not_after"].strftime("%d.%m.%Y")
    out["days_left"] = (srv["not_after"] - now).days
    out["ca_not_after"] = ca["not_after"].strftime("%d.%m.%Y")
    out["ca_days_left"] = (ca["not_after"] - now).days
    try:
        made = json.load(open(str(p["made"]), "r", encoding="utf-8"))
        out["maker"] = str(made.get("maker") or "")
        out["made_at"] = str(made.get("made_at") or "")
        out["ca_source"] = str(made.get("ca_source") or "")
        out["ca_renewed"] = bool(made.get("ca_renewed"))
    except Exception:
        pass
    if srv["not_after"] <= now or ca["not_after"] <= now:
        out["problem"] = PROBLEM_EXPIRED
        return out
    # 🩸 АДРЕСА МАШИНИ ЗМІНИЛАСЬ — СЕРТИФІКАТ ЧУЖИЙ. Браузер покаже червоне
    # не тому, що ми його не знаємо, а тому, що він виписаний не на цю адресу.
    # Мовчати про це не можна: людина побачить попередження і не зрозуміє чому.
    if ip_now and ip_now not in out["ips"]:
        out["problem"] = PROBLEM_IP
        return out
    # ⭐⭐⭐ 537ж, 08.09.2026. ОСТАННЄ СЛОВО — ЗА СПРОБОЮ, А НЕ ЗА ПАСПОРТОМ.
    # 🩸 ЗНАЙДЕНО ЖИВОЮ МАШИНОЮ: Windows підписала сертифікат старим способом
    # (SHA-1). Дати правильні, адреси правильні, паспорт бездоганний — а `ssl`
    # такий сертифікат не приймає. Ми казали «увімкнено», замок пускав мережу,
    # і платформа стала б на 0.0.0.0 БЕЗ ШИФРУВАННЯ.
    # Тому придатність доводиться ЄДИНИМ способом: спробувати підняти
    # шифрування насправді. Не піднялось — непридатне, і причина названа.
    ctx, err = _build_context()
    if ctx is None:
        out["problem"] = PROBLEM_BROKEN
        out["detail"] = err
        return out
    out["problem"] = ""
    out["usable"] = True
    out["expiring"] = out["days_left"] <= WARN_DAYS
    return out


def usable() -> bool:
    """Коротка відповідь для замка мережі."""
    return bool(state().get("usable"))


def _build_context():
    """Спробувати підняти шифрування. Повертає (контекст, причина відмови).

    🩸 ЦЕ ЄДИНЕ МІСЦЕ, ЯКЕ ВІДПОВІДАЄ НА ПИТАННЯ «ЧИ МОЖЕМО МИ ШИФРУВАТИ».
    І `state()`, і `context()` питають саме його: два різні способи відповісти
    на одне питання розійшлись би — і розійшлись би тихо.
    """
    p = paths()
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(certfile=str(p["srv_crt"]), keyfile=str(p["srv_key"]))
        return ctx, ""
    except Exception as ex:
        return None, str(ex)[:300]


def context():
    """Готовий контекст TLS або None. Єдине джерело для server.py."""
    if not usable():
        return None
    return _build_context()[0]


def tls_error() -> str:
    """Чому шифрування не піднімається — словами системи. Для екрана й журналу."""
    return _build_context()[1]


def ca_public_pem() -> str:
    """Той САМИЙ файл, що ставиться працівникам. Лише відкрита частина.
    🩸 Таємний ключ офісу тут не з'являється НІКОЛИ — цієї функції немає."""
    try:
        return open(str(paths()["ca_crt"]), "r", encoding="utf-8").read()
    except Exception:
        return ""


def console_lines() -> list:
    """Що сказати у вікні запуску. Людина не має гадати."""
    st = state()
    lines = []
    if st.get("ca_renewed"):
        # 🩸 568. Людина має дізнатись це з вікна запуску, а не від працівника,
        # у якого браузер раптом показав попередження. Текст — не свій: той
        # самий, що й у відповіді екрана (`renewal_note`).
        import textwrap as _tw
        _first = True
        for _chunk in _tw.wrap(renewal_note(True), 56):
            lines.append((" Ключ офісу      : " if _first else "        ") + _chunk)
            _first = False
    if st["usable"]:
        lines.append(" Шифрування      : УВІМКНЕНО (сертифікат діє до %s)" % st["not_after"])
        if st["expiring"]:
            lines.append("        УВАГА: лишилось %d днів. Створіть новий сертифікат"
                         % st["days_left"])
            lines.append("        на екрані Доступи — комп'ютери працівників чіпати не треба.")
    elif st["problem"] == PROBLEM_MISSING:
        lines.append(" Шифрування      : сертифіката ще немає")
    elif st["problem"] == PROBLEM_EXPIRED:
        lines.append(" Шифрування      : сертифікат ПРОСТРОЧЕНИЙ")
    elif st["problem"] == PROBLEM_IP:
        lines.append(" Шифрування      : сертифікат виписаний на іншу адресу")
        lines.append("        (тепер %s, а в сертифікаті %s)"
                     % (st["ip_now"] or "?", ", ".join(st["ips"]) or "?"))
    else:
        lines.append(" Шифрування      : файли сертифіката не читаються")
    return lines


# ═══════════════════════════════════════════════════════════════════════════
# СТВОРЕННЯ КЛЮЧІВ
#
# 🩸 ГОЛОВНЕ ПРАВИЛО ЦЬОГО РОЗДІЛУ: МИ НЕ ПИШЕМО КРИПТОГРАФІЇ.
# Ключ і підпис робить сама операційна система своїм вбудованим засобом.
# Наш код виконує рівно дві дії, у яких немає жодної таємниці:
#   1) каже системі, ЯКИЙ сертифікат потрібен (на які адреси, доки, ким
#      підписаний);
#   2) перекладає готові числа з формату Windows у формат PEM, який читає
#      Python. Це перекладання — розкладка чисел по коробочках DER, а не
#      обчислення. Жодного байта ключа ми не вигадуємо.
#
# Для експертизи це принципова різниця: «використали засоби операційної
# системи» проти «написали своє шифрування».
# ═══════════════════════════════════════════════════════════════════════════

def _der_len(n: int) -> bytes:
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def _der_int(raw: bytes) -> bytes:
    v = raw.lstrip(b"\x00") or b"\x00"
    if v[0] & 0x80:                       # DER: старший біт означав би мінус
        v = b"\x00" + v
    return b"\x02" + _der_len(len(v)) + v


def _der_seq(parts: bytes) -> bytes:
    return b"\x30" + _der_len(len(parts)) + parts


def _pem_block(title: str, der: bytes) -> str:
    b64 = base64.b64encode(der).decode("ascii")
    rows = [b64[i:i + 64] for i in range(0, len(b64), 64)]
    return ("-----BEGIN %s-----\n" % title) + "\n".join(rows) + ("\n-----END %s-----\n" % title)


def rsa_key_pem(d: dict) -> str:
    """PEM таємного ключа з готових чисел, які видала система.

    Порядок чисел визначений стандартом (PKCS#1) і не є нашим винаходом:
    версія, модуль, відкритий показник, таємний показник, два прості
    множники і три допоміжні числа для швидкості.
    """
    g = lambda k: base64.b64decode(d[k])          # noqa: E731
    body = _der_seq(
        _der_int(b"\x00")
        + _der_int(g("n")) + _der_int(g("e")) + _der_int(g("d"))
        + _der_int(g("p")) + _der_int(g("q"))
        + _der_int(g("dp")) + _der_int(g("dq")) + _der_int(g("iq"))
    )
    return _pem_block("RSA PRIVATE KEY", body)


def cert_pem(b64: str) -> str:
    return _pem_block("CERTIFICATE", base64.b64decode(b64))


def _write(path, text: str):
    """Запис із заміною: спершу поруч, потім на місце. Половини файла не буває."""
    path = str(path)
    tmp = path + ".new"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    one_writer.replace_with_patience(tmp, path)


def _san_parts() -> tuple:
    """Адреси, на які виписуємо сертифікат: своя адреса в мережі, ця машина
    сама для себе, і ім'я комп'ютера. 🩸 Браузер, якому дали адресу цифрами,
    вимагає, щоб саме ЦИФРИ стояли в сертифікаті — імені йому мало."""
    ips = ["127.0.0.1"]
    ip = _lan_ip()
    if ip and ip not in ips:
        ips.append(ip)
    names = ["localhost"]
    try:
        h = socket.gethostname()
        if h and h not in names:
            names.append(h)
    except Exception:
        pass
    return ips, names


_PS_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$out    = '{OUT}'
$caPfx  = '{CAPFX}'
$pwdText= '{PFXPWD}'
$needCa = '{NEEDCA}'
$subject= 'CN=SensFlow Office Key'
$prov   = 'Microsoft Enhanced RSA and AES Cryptographic Provider'
$store  = 'Cert:\CurrentUser\My'
$pwd    = ConvertTo-SecureString -String $pwdText -Force -AsPlainText

function Get-Rsa($c) {{
  $r = $null
  try {{ $r = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($c) }} catch {{ }}
  if ($r -eq $null) {{ $r = $c.PrivateKey }}
  return $r
}}
function Dump($c) {{
  $p = (Get-Rsa $c).ExportParameters($true)
  return @{{
    cert = [Convert]::ToBase64String($c.RawData)
    n  = [Convert]::ToBase64String($p.Modulus)
    e  = [Convert]::ToBase64String($p.Exponent)
    d  = [Convert]::ToBase64String($p.D)
    p  = [Convert]::ToBase64String($p.P)
    q  = [Convert]::ToBase64String($p.Q)
    dp = [Convert]::ToBase64String($p.DP)
    dq = [Convert]::ToBase64String($p.DQ)
    iq = [Convert]::ToBase64String($p.InverseQ)
  }}
}}

# 1. КЛЮЧ ОФІСУ — У СХОВИЩІ WINDOWS. Там його й зробила сама Windows, і там
#    він лишається: саме це дає перевипуск БЕЗ обходу компʼютерів працівників.
$ca = $null
$source = ''
try {{
  $ca = Get-ChildItem $store | Where-Object {{ $_.Subject -eq $subject -and $_.HasPrivateKey }} |
        Sort-Object NotAfter -Descending | Select-Object -First 1
  if ($ca -ne $null) {{
    $null = (Get-Rsa $ca).ExportParameters($true)
    $source = 'store'
  }}
}} catch {{ $ca = $null }}

# 2. СУМІСНІСТЬ: машини, де ключ лежить лише переносною копією.
if ($ca -eq $null -and (Test-Path $caPfx)) {{
  try {{
    $ca = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2 @($caPfx, $pwdText, 'Exportable,PersistKeySet')
    $source = 'pfx'
  }} catch {{ $ca = $null }}
}}

# 3. НЕ ВІДКРИВСЯ НІЧИМ — робимо НОВИЙ і кажемо про це вголос (Python нижче).
if ($ca -eq $null) {{
  $ca = New-SelfSignedCertificate -Subject $subject `
        -KeyExportPolicy Exportable -Provider $prov -KeyLength 2048 `
        -KeyUsage CertSign,CRLSign,DigitalSignature -HashAlgorithm SHA256 `
        -TextExtension @('2.5.29.19={{text}}CA=true&pathlength=0') `
        -NotAfter (Get-Date).AddYears({CAYEARS}) -CertStoreLocation $store
  $source = 'new'
}}

# Переносна копія ключа офісу — СУЧАСНИМ форматом. Застарілий (3DES/SHA-1)
# сучасна Windows імпортувати відмовляється, і саме на цьому падав перевипуск.
if ($source -eq 'new') {{
  try {{
    Export-PfxCertificate -Cert $ca -FilePath $caPfx -Password $pwd -CryptoAlgorithmOption AES256_SHA256 | Out-Null
  }} catch {{
    Export-PfxCertificate -Cert $ca -FilePath $caPfx -Password $pwd | Out-Null
  }}
}}

$srv = New-SelfSignedCertificate -Subject 'CN=SensFlow' -Signer $ca -HashAlgorithm SHA256 `
       -KeyExportPolicy Exportable -Provider $prov -KeyLength 2048 `
       -TextExtension @('2.5.29.37={{text}}1.3.6.1.5.5.7.3.1', '{SAN}') `
       -NotAfter (Get-Date).AddYears({SRVYEARS}) -CertStoreLocation $store

$res = @{{ server = (Dump $srv); source = $source; reused = ($source -ne 'new') }}
if ($source -eq 'new' -or $needCa -eq '1') {{ $res['ca'] = (Dump $ca) }}
[IO.File]::WriteAllText($out, ($res | ConvertTo-Json -Depth 6), [Text.Encoding]::UTF8)

# ⛒ Прибираємо зі сховища ЛИШЕ сертифікат сервера: він похідний і
# перевипускається. КЛЮЧ ОФІСУ ЛИШАЄТЬСЯ — інакше наступний перевипуск знову
# залежав би від пароля у нотатці (вада, знайдена 12.09.2026).
Remove-Item -Path ($store + '\' + $srv.Thumbprint) -Force -ErrorAction SilentlyContinue
"""


def _make_windows(ips, names) -> dict:
    """Ключ народжує Windows. Ми лише просимо і перекладаємо."""
    import secrets
    p = paths()
    san = "2.5.29.17={text}" + "&".join(
        ["IPAddress=%s" % x for x in ips] + ["DNS=%s" % x for x in names])
    made_pwd = ""
    try:
        made_pwd = json.load(open(str(p["made"]), "r", encoding="utf-8")).get("pfx_pwd") or ""
    except Exception:
        made_pwd = ""
    if not made_pwd:
        made_pwd = secrets.token_hex(16)
    # Чи треба видати наново ВІДКРИТУ половину ключа офісу: якщо PEM-файлів
    # немає, їх нікому буде роздати працівникам.
    need_ca = not (os.path.exists(str(p["ca_crt"])) and os.path.exists(str(p["ca_key"])))
    had_key = os.path.exists(str(p["ca_crt"])) or os.path.exists(str(p["ca_pfx"]))
    work = tempfile.mkdtemp(prefix="sensflow_cert_")
    ps_file = os.path.join(work, "make_cert.ps1")
    out_file = os.path.join(work, "out.json")
    script = _PS_SCRIPT.format(
        OUT=out_file.replace("'", "''"),
        CAPFX=str(p["ca_pfx"]).replace("'", "''"),
        PFXPWD=made_pwd,
        NEEDCA="1" if need_ca else "0",
        CAYEARS=CA_YEARS,
        SRVYEARS=SRV_YEARS,
        SAN=san,
    )
    try:
        # 🩸 .ps1 читається й пишеться в utf-8-sig — правило продукту.
        with open(ps_file, "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write(script)
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-File", ps_file],
            capture_output=True, text=True, timeout=300)
        if r.returncode != 0 or not os.path.exists(out_file):
            msg = (r.stderr or r.stdout or "").strip()
            return {"ok": False, "error": msg[:900] or "Windows не створила сертифікат",
                    "maker": "windows"}
        data = json.load(open(out_file, "r", encoding="utf-8-sig"))
        data["had_key"] = had_key
        return _lay_down(data, "windows", made_pwd)
    except Exception as ex:
        return {"ok": False, "error": str(ex)[:900], "maker": "windows"}
    finally:
        for f in (ps_file, out_file):
            try:
                os.remove(f)
            except Exception:
                pass
        try:
            os.rmdir(work)
        except Exception:
            pass


def _make_openssl(ips, names) -> dict:
    """СТЕНД. Той самий склад файлів, зроблений openssl — щоб механізм
    шифрування, замок і екран можна було довести тут, у робочій оболонці.
    🩸 У клієнта на Windows працює НЕ цей шлях, а той, що вище."""
    p = paths()
    work = tempfile.mkdtemp(prefix="sensflow_cert_")
    ext = os.path.join(work, "ext.cnf")
    san = ",".join(["IP:%s" % x for x in ips] + ["DNS:%s" % x for x in names])
    try:
        open(ext, "w", encoding="utf-8").write(
            "subjectAltName=%s\nextendedKeyUsage=serverAuth\nbasicConstraints=CA:FALSE\n" % san)
        ca_crt = str(p["ca_crt"])
        ca_key = str(p["ca_key"])
        reused = os.path.exists(ca_crt) and os.path.exists(ca_key)
        run = lambda a: subprocess.run(a, capture_output=True, text=True)  # noqa: E731
        if not reused:
            r = run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                     "-keyout", ca_key, "-out", ca_crt,
                     "-days", str(CA_YEARS * 365), "-subj", "/CN=SensFlow Office Key",
                     "-addext", "basicConstraints=critical,CA:TRUE,pathlen:0",
                     "-addext", "keyUsage=critical,keyCertSign,cRLSign"])
            if r.returncode != 0:
                return {"ok": False, "error": (r.stderr or "")[:900], "maker": "openssl"}
        csr = os.path.join(work, "s.csr")
        r = run(["openssl", "req", "-newkey", "rsa:2048", "-nodes",
                 "-keyout", str(p["srv_key"]), "-out", csr, "-subj", "/CN=SensFlow"])
        if r.returncode != 0:
            return {"ok": False, "error": (r.stderr or "")[:900], "maker": "openssl"}
        r = run(["openssl", "x509", "-req", "-in", csr, "-CA", ca_crt, "-CAkey", ca_key,
                 "-CAcreateserial", "-out", str(p["srv_crt"]),
                 "-days", str(SRV_YEARS * 365), "-extfile", ext])
        if r.returncode != 0:
            return {"ok": False, "error": (r.stderr or "")[:900], "maker": "openssl"}
        # ⛒⛒⛒ 568. НОТАТКУ ПИШЕ ОДИН ПИСАР — `_lay_down`, і на стенді теж.
        # Доти стенд писав `made.json` сам: два писарі однієї нотатки означали,
        # що правда про джерело ключа жила лише на одному з двох шляхів, і чек
        # на стенді зеленів там, де на Windows уже брехало.
        return _lay_down({"source": "pem" if reused else "new",
                          "had_key": reused}, "openssl (стенд)", "")
    except Exception as ex:
        return {"ok": False, "error": str(ex)[:900], "maker": "openssl"}
    finally:
        for f in (ext, os.path.join(work, "s.csr")):
            try:
                os.remove(f)
            except Exception:
                pass
        try:
            os.rmdir(work)
        except Exception:
            pass


def renewal_note(renewed: bool) -> str:
    """⛒ 568. ЦІНУ НОВОГО КЛЮЧА ОФІСУ КАЖЕ ОДНЕ РЕЧЕННЯ — і екранові, і вікну
    запуску. Порожньо означає «ключ той самий, обходити машини не треба»."""
    if not renewed:
        return ""
    return ("Ключ офісу створено ЗАНОВО: старий не відкривався. Якщо ви вже "
            "ставили ключ компʼютерам працівників — поставте новий файл ще раз.")


def _lay_down(data: dict, maker: str, pfx_pwd: str) -> dict:
    """Розкласти по файлах те, що видала система.

    ⛒ 568. Джерело ключа офісу називається СЛОВОМ (`store`/`pfx`/`new`), а не
    вгадується по тому, чи є файл: саме це слово потім каже людині, чи ключ
    створено заново — і чи треба обійти компʼютери працівників."""
    p = paths()
    source = str(data.get("source") or ("pem" if data.get("reused") else "new"))
    reused = source != "new"
    renewed = bool(source == "new" and data.get("had_key"))
    if data.get("ca"):
        ca = data["ca"]
        _write(p["ca_crt"], cert_pem(ca["cert"]))
        _write(p["ca_key"], rsa_key_pem(ca))
    srv = data.get("server") or {}
    if srv:
        _write(p["srv_crt"], cert_pem(srv["cert"]))
        _write(p["srv_key"], rsa_key_pem(srv))
    _write(p["made"], json.dumps({
        "maker": maker,
        "made_at": datetime.datetime.now().strftime("%d.%m.%Y %H:%M"),
        "ca_reused": reused,
        "ca_source": source,
        "ca_renewed": renewed,
        # 🩸 ЧЕСНО: цей пароль нічого не додає до безпеки — він лежить поруч
        # із самим файлом. Windows просто не вміє зберігати ключ без пароля.
        # Захищає ці файли тека, а не пароль.
        "pfx_pwd": pfx_pwd,
    }, ensure_ascii=False, indent=2))
    out = {"ok": True, "error": "", "maker": maker, "ca_reused": reused,
           "ca_source": source, "ca_renewed": renewed, "said": ""}
    if renewed:
        out["said"] = renewal_note(renewed)
    return out


def make() -> dict:
    """Створити (або перевипустити) сертифікат сервера.

    Ключ офісу створюється ОДИН раз і далі перевикористовується: працівники
    вже поставили його собі, і другого обходу машин бути не повинно.
    """
    try:
        os.makedirs(str(certs_dir()), exist_ok=True)
    except Exception as ex:
        return {"ok": False, "error": "не вдалось створити теку ключів: %s" % ex, "maker": ""}
    ips, names = _san_parts()
    out = _make_windows(ips, names) if os.name == "nt" else _make_openssl(ips, names)
    # ⭐⭐⭐ 537ж: СТВОРИЛИ — ДОВЕДИ. Файли можуть лягти на диск і бути
    # непридатними (саме так і сталось 08.09.2026 із підписом SHA-1). Кажемо
    # «зроблено» лише тоді, коли шифрування СПРАВДІ піднімається.
    if out.get("ok"):
        ctx, err = _build_context()
        if ctx is None:
            out["ok"] = False
            out["error"] = ("сертифікат створено, але шифрування ним не "
                            "піднімається: %s" % err)
    return out
