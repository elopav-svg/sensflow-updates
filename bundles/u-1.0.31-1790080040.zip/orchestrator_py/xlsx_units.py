# -*- coding: utf-8 -*-
"""xlsx_units.py — ОДИН ПИСАР ОДИНИЦЬ У ГОТОВІЙ КНИЗІ (17.09.2026, зміна 604).

⭐⭐⭐ КОРІНЬ, ЗНЯТИЙ ІЗ ЖИВОЇ КНИГИ 17.09.2026 (прогін 15:35). Виручка зійшлася
з ручним контролем власника до копійки, а дві колонки поруч були неправдою:

    Параметри!B4                = 9          формат General  (насправді «9 %»)
    Зведення!I4 = Параметри!$B$4             формат 0.00%  ->   900,00 %
    Зведення!E4 = D4/B4         = 0,0745     формат 0.00%  ->     7,45 %
    Зведення!J4 = E4-I4         = 0,0745-9   формат п.п.   ->    -8,9 п.п.

Правда була −1,55 п.п.

⛒ ЧОМУ. Відсоток у книзі має ДВІ одиниці — ЧАСТКА (0,0745) і ВІДСОТКОВЕ ЧИСЛО
(9) — і переходу між ними не володів ніхто. Контракт каже складачеві «відсоток —
це частка»; код, що переносить значення з файла клієнта (зміна 600), кладе сире
число джерела як є. Двоє писарів однієї домовленості розійшлись, і число,
перетнувши межу листа, приїхало без своєї одиниці. Формат при цьому вирішувався
ЛОКАЛЬНО — регуляркою по заголовку і по тексту формули, — а текст формули не
може знати одиниці клітинки, на яку вказує.

⭐ ПРАВИЛО КЛАСУ. Одиницю тримає ОДИН писар, і судить він ГОТОВУ КНИГУ:
  1. клітинка-відсоток зберігає ЧАСТКУ і має відсотковий формат;
  2. клітинка «п.п.» — це різниця двох ЧАСТОК, помножена на 100;
  3. чого писар не виправив однозначно — те ворота не випускають у файл.

🩸 ДРУГИЙ БІК, ЯКИЙ МУСИТЬ ЛИШИТИСЬ ЦІЛИМ: частку, яка вже частка, ділити вдруге
не можна; формулу, де вже є «*100», множити вдруге не можна; гроші, кількості й
дати не чіпати взагалі.
"""
import re

# Заголовок називає одиницю. Порядок значущий: «Відхилення МАРЖИНАЛЬНОСТІ, п.п.»
# містить обидві ознаки, і п.п. мусить перемогти — інакше різницю часток
# показали б як частку.
_PP_RE = re.compile(r"п\.\s?п\.?|проц\w*\s+пункт", re.I)
_PCT_RE = re.compile(r"%|відсот|маржинальн|рентабельн|частк", re.I)

_REF = r"(?:'[^']+'!|[^\s'!()+\-*/=]+!)?\$?[A-Za-z]{1,3}\$?\d+"
_ANY_REF_RE = re.compile(_REF)
_REF_RE = re.compile(r"^(?:'([^']+)'!|([^\s'!()+\-*/=]+)!)?\$?([A-Za-z]{1,3})\$?(\d+)$")
_X100_RE = re.compile(r"[*/]\s*100(?!\d)")

PCT_FMT = "0.00%"


def unit_of_label(text) -> str:
    """Одиниця, яку називає підпис: "pp" | "pct" | ""."""
    s = str(text or "")
    if not s.strip():
        return ""
    if _PP_RE.search(s):
        return "pp"
    if _PCT_RE.search(s):
        return "pct"
    return ""


def _col_letters(idx: int) -> str:
    s = ""
    while idx > 0:
        idx, r = divmod(idx - 1, 26)
        s = chr(65 + r) + s
    return s


def unit_map(wb, regions=None) -> dict:
    """{(лист, рядок, колонка): одиниця} — для параметрів і для колонок таблиці.

    ⛒ Мапа будується ОДИН раз і з тих самих джерел, що й рендер: блок
    параметрів (підпис ліворуч, значення праворуч) і рядок заголовків таблиці,
    геометрію якого дає `_spec_regions`. Другого способу дізнатись одиницю в
    цьому файлі нема й бути не повинно."""
    out = {}
    for ws in wb.worksheets:
        reg = (regions or {}).get(ws.title) or {}
        n = int(reg.get("n_params") or 0)
        for k in range(1, n + 1):
            u = unit_of_label(ws.cell(row=1 + k, column=1).value)
            if u:
                out[(ws.title, 1 + k, 2)] = u
        hdr = reg.get("hdr")
        first, last = reg.get("first"), reg.get("last")
        if not hdr:
            continue
        ncols = int(reg.get("ncols") or 0) or ws.max_column
        rows = []
        if first and last:
            rows = list(range(int(first), int(last) + 1))
        if reg.get("totals"):
            rows.append(int(reg["totals"]))
        for c in range(1, ncols + 1):
            u = unit_of_label(ws.cell(row=hdr, column=c).value)
            if not u:
                continue
            for r in rows:
                out[(ws.title, r, c)] = u
    return out


def _split_top_minus(expr: str):
    """Розбити вираз по ВІДНІМАННЮ верхнього рівня: "A-B" -> (A, B).

    ⛒ 604б. Спершу тут стояла одна форма — «гола різниця двох посилань». На
    живій книзі 16:29 рядок «РАЗОМ» був різницею двох ДРОБІВ
    (=SUM(D4:D6)/SUM(B4:B6) − SUMPRODUCT(...)/SUM(...)), під ту форму не підпав
    і поїхав до клієнта в сто разів меншим: 0,0 п.п. замість 1,4. Одиниця не
    залежить від того, наскільки складний вираз, тому ділимо по СТРУКТУРІ, а не
    по зовнішньому вигляду."""
    # ⛒ Розріз шукаємо, але зшиваємо назад ТИМ САМИМ мінусом, тому окремий
    # сторож проти унарного мінуса тут нічого не міняє: мутація показала, що
    # він мертвий. Рішення приймає не місце розрізу, а те, чи ОБИДВА боки
    # виявились частками (`_is_share`) — саме воно і є суддею.
    depth = 0
    for i, ch in enumerate(expr):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "-" and depth == 0 and i > 0:
            left, right = expr[:i].strip(), expr[i + 1:].strip()
            if left and right:
                return left, right
    return None


def _strip_parens(s: str) -> str:
    s = s.strip()
    while s.startswith("(") and s.endswith(")"):
        d = 0
        for i, ch in enumerate(s):
            if ch == "(":
                d += 1
            elif ch == ")":
                d -= 1
                if d == 0 and i != len(s) - 1:
                    return s
        s = s[1:-1].strip()
    return s


def _is_share(side: str, umap: dict, sheet: str) -> bool:
    """Чи цей бік різниці — ЧАСТКА (а не відсоткові пункти й не гроші).

    Два способи бути часткою, обидва арифметичні, без вгадування:
      • усі посилання в ньому — клітинки-відсотки (частки);
      • або це ДІЛЕННЯ верхнього рівня: відношення двох величин однієї природи
        (виручка/виручка, маржа/виручка) — це за визначенням частка."""
    body = _strip_parens(side)
    refs = [_resolve(r, sheet) for r in _ANY_REF_RE.findall(body)]
    refs = [r for r in refs if r]
    if refs and all(umap.get(r) == "pct" for r in refs):
        return True
    depth = 0
    for ch in body:
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "/" and depth == 0:
            return True
    return False


def _pp_needs_x100(formula: str, umap: dict, sheet: str):
    """Чи це різниця ДВОХ ЧАСТОК без ×100 -> (лівий, правий) або None.

    ОДИН суддя і для писаря, і для воріт: якби їх було двоє, вони розійшлись би
    рівно так, як розійшлись контракт і код у зміні 604."""
    f = (formula or "").strip()
    if not f.startswith("=") or _X100_RE.search(f):
        return None
    parts = _split_top_minus(f[1:].strip())
    if not parts:
        body = _strip_parens(f[1:])
        parts = _split_top_minus(body)
    if not parts:
        return None
    left, right = parts
    if _is_share(left, umap, sheet) and _is_share(right, umap, sheet):
        return left, right
    return None


def _resolve(ref: str, this_sheet: str):
    """'Лист'!$B$4 | B4 -> (лист, рядок, колонка) або None."""
    m = _REF_RE.match((ref or "").strip())
    if not m:
        return None
    sheet = m.group(1) or m.group(2) or this_sheet
    col = m.group(3).upper()
    idx = 0
    for ch in col:
        idx = idx * 26 + (ord(ch) - 64)
    return (sheet, int(m.group(4)), idx)


def normalize(wb, regions=None) -> list:
    """Звести одиниці книги до однієї. Повертає перелік того, що виправлено."""
    fixed = []
    umap = unit_map(wb, regions)

    # 1. ВІДСОТОК ЗБЕРІГАЄТЬСЯ ЧАСТКОЮ. Число більше за одиницю в клітинці-
    #    відсотку — це відсоткові одиниці з файла клієнта (9 = 9 %), і саме
    #    воно, перетнувши межу листа, перетворювалось на 900 %.
    for (sheet, r, c), u in umap.items():
        if u != "pct":
            continue
        cell = wb[sheet].cell(row=r, column=c)
        v = cell.value
        if isinstance(v, bool) or not isinstance(v, (int, float)):
            continue
        if abs(float(v)) > 1.0:
            cell.value = float(v) / 100.0
            fixed.append("%s!%s%d: %s → частка %s" % (sheet, _col_letters(c), r,
                                                      v, cell.value))
        cell.number_format = PCT_FMT

    # 2. «П.П.» — ЦЕ РІЗНИЦЯ ЧАСТОК, ПОМНОЖЕНА НА 100. Формулу пише складач, а
    #    одиницю знає лише код: він і дописує множник, а не просить модель.
    for (sheet, r, c), u in umap.items():
        if u != "pp":
            continue
        cell = wb[sheet].cell(row=r, column=c)
        f = cell.value
        if not (isinstance(f, str) and f.startswith("=")):
            continue
        parts = _pp_needs_x100(f, umap, sheet)
        if not parts:
            continue                      # різниця НЕ часток — не наша справа
        cell.value = "=(%s-%s)*100" % (parts[0], parts[1])
        fixed.append("%s!%s%d: %s → %s" % (sheet, _col_letters(c), r, f, cell.value))
    return fixed


def unit_errors(wb, regions=None) -> list:
    """ВОРОТА: що лишилось у змішаній одиниці. Порожньо = книгу віддавати можна."""
    errs = []
    umap = unit_map(wb, regions)
    for (sheet, r, c), u in sorted(umap.items()):
        cell = wb[sheet].cell(row=r, column=c)
        v = cell.value
        addr = "%s!%s%d" % (sheet, _col_letters(c), r)
        if u == "pct":
            if isinstance(v, (int, float)) and not isinstance(v, bool) and abs(float(v)) > 1.0:
                errs.append("%s: відсоток записано числом %s — у книзі відсоток "
                            "зберігається ЧАСТКОЮ (%s = %s%%)" % (addr, v, v / 100.0, v))
            elif isinstance(v, (int, float)) and "%" not in (cell.number_format or ""):
                errs.append("%s: частка %s показана без відсоткового формату — "
                            "на екрані це буде не те число" % (addr, v))
        elif u == "pp":
            if isinstance(v, str) and _pp_needs_x100(v, umap, sheet):
                errs.append("%s: «%s» — це різниця двох ЧАСТОК без ×100; "
                            "у відсоткових пунктах вона буде у сто разів "
                            "меншою" % (addr, v))
    return errs
