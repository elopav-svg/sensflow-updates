# -*- coding: utf-8 -*-
"""deal_items.py — ПОЗИЦІЇ УГОДИ (зміна 535, 07.09.2026).

⭐⭐⭐ НАВІЩО (рішення, не скасоване з 02.09.2026): «Позиції в угоді — перелік з
усіма параметрами, і він накопичується по стадіях: на фіналі видно, про що
домовлялись і що клієнт обрав».

⭐⭐⭐ ОКРЕМЕ СХОВИЩЕ, А НЕ ПОЛЕ В УГОДІ. `deals.json` читає кожен екран списку
й кожна воронка. Сотні рядків позицій усередині угоди вбили б швидкість саме
там, де її видно щодня, тому позиції лежать своїм файлом і читаються лише тоді,
коли відкрито картку.

⛒⛒⛒ ЗНІМОК, А НЕ ПОСИЛАННЯ. Позиція везе ВЛАСНУ копію назви, артикулу,
одиниці й роду товару на момент домовленості, а ціну — таку, про яку
домовились. Ціни, що завтра приїдуть із обліку, НЕ СМІЮТЬ переписати вчорашню
домовленість: інакше «видно, про що домовлялись» стає брехнею. Тому читання
позицій НІКОЛИ не ходить у `goods` — воно читає лише знімок.

⛒ ПЛАТФОРМА НІЧОГО НЕ РАХУЄ (слово Андрія 02.09.2026: «залишимо ручний ввід
суми угоди»). Кількість і ціна лежать ТЕКСТОМ, як їх увела людина. Ані
множення, ані підсумку тут немає й не буде — сума угоди вводиться руками.

⛒ ПРИБРАНА ПОЗИЦІЯ ЗНИКАЄ ЗІ СПИСКУ, А СЛІД ІДЕ В НАЯВНИЙ ЖУРНАЛ УГОДИ (слово
Андрія 07.09.2026). Другого журналу не заводимо: історія угоди має лишатись
однією стрічкою.

⛔ НЕДІЮЧИЙ ТОВАР НОВОЮ ПОЗИЦІЄЮ НЕ ДОДАЄТЬСЯ, але вже додані позиції живуть
далі — саме тому товар і не видаляється з бази ніколи.
"""
import json
import one_writer

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import deals
import entity                     # спільне імʼя сутності на всю платформу
import goods
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій

config.refuse_live_state_for_checks(__name__)

# ⛒ АДРЕСУ ТЕКИ ПІД КОРЕНЕМ ПРОДУКТУ ОБЧИСЛЮЄ ЛИШЕ `config` — саморобний шлях
# ловить `state_scope_test`, і ловить справедливо.
DIR = config.CRM_DIR
ITEMS_JSON = DIR / "deal_items.json"

# ⭐ ЩО САМЕ ЗАМОРОЖУЄТЬСЯ. Ціна лежить окремо (`price`), бо вона — предмет
# домовленості, а не опис товару.
SNAP_FIELDS = ("name", "sku", "kind", "unit", "currency")


class DealItemError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _load() -> dict:
    try:
        d = one_writer.read_json(ITEMS_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("items", {})
    d.setdefault("seq", 0)
    return d


def _save(d: dict) -> None:
    DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(ITEMS_JSON, d)


def _new_id(d: dict) -> str:
    seq = int(d.get("seq") or 0) + 1
    while ("i%04d" % seq) in d["items"]:
        seq += 1
    d["seq"] = seq
    return "i%04d" % seq


def _to_protocol(action: str, did: str, what: str, gid: str = "") -> None:
    """Хто зберігає — той і звітує. Слід іде в журнал УГОДИ: її клієнт — в
    `about`, тому «покажи все про Каспера» бачить і рух його позицій.
    ⚠ Ніколи не валить роботу: реєстр — актив, журнал — його тінь."""
    try:
        about = []
        pid = deals.client_of(did)
        if pid:
            about.append(entity.ref(entity.KIND_PARTY, pid))
        if _s(gid):
            about.append(entity.ref(entity.KIND_GOOD, _s(gid)))
        protocol.write(action, entity.ref(entity.KIND_DEAL, _s(did)),
                       about=about, note=what)
    except Exception:
        pass


def get(iid) -> dict:
    return dict(_load()["items"].get(_s(iid)) or {}) or {}


def exists(iid) -> bool:
    return _s(iid) in _load()["items"]


def said(row: dict) -> str:
    """Як позиція звучить у журналі й на екрані — ОДНИМ писарем на всі місця."""
    snap = dict(row.get("snap") or {})
    out = _s(snap.get("name")) or "без назви"
    if _s(snap.get("sku")):
        out += " (арт. %s)" % _s(snap.get("sku"))
    if _s(row.get("qty")):
        out += ", %s%s" % (_s(row.get("qty")),
                           (" " + _s(snap.get("unit"))) if _s(snap.get("unit")) else "")
    if _s(row.get("price")):
        out += ", %s%s" % (_s(row.get("price")),
                           (" " + _s(snap.get("currency"))) if _s(snap.get("currency")) else "")
    return out


def items_of(did) -> list:
    """Позиції однієї угоди, у порядку додавання.

    ⛒ СЮДИ НЕ ЗАХОДИТЬ `goods`: те, що бачить людина, — це ЗНІМОК на момент
    домовленості, а не сьогоднішня картка товару."""
    key = _s(did)
    out = [dict(v) for v in _load()["items"].values() if _s(v.get("deal")) == key]
    out.sort(key=lambda x: (_s(x.get("created")), _s(x.get("id"))))
    # ⭐⭐⭐ 592: ЦІНА ПОЗИЦІЇ — ТЕЖ ГРОШІ УГОДИ. Сховати суму в картці й лишити
    # ціни в позиціях означало б не сховати нічого: чотири вікна по 25 000
    # складаються в голові швидше, ніж у калькуляторі. Сама позиція лишається —
    # ховаємо гроші, а не роботу.
    try:
        import entity_scope as _vs592i
        return _vs592i.hide_money(out, ("price", "sum", "total", "amount"),
                                  did=key)
    except Exception:
        return out


def count_of(did) -> int:
    return len(items_of(did))


def deals_of_good(gid) -> list:
    """У яких угодах товар уже вжитий. ⭐ Саме через це товар не видаляється."""
    key = _s(gid)
    seen = []
    for v in _load()["items"].values():
        if _s(v.get("good")) == key and _s(v.get("deal")) not in seen:
            seen.append(_s(v.get("deal")))
    return seen


@one_writer.guard("DEAL_ITEMS_JSON")
def add(did, gid, qty="", price="", by: str = "") -> dict:
    """Додати позицію в угоду. Знімок робиться ТУТ і більше не оновлюється."""
    dk, gk = _s(did), _s(gid)
    if not deals.exists(dk):
        raise DealItemError("Угоди %s немає." % (dk or "«»"))
    g = goods.get(gk)
    if not g:
        raise DealItemError("Товару %s немає в базі." % (gk or "«»"))
    if goods.is_archived(g):
        raise DealItemError("«%s» не в обігу: новою позицією не додається."
                            % _s(g.get("name")))
    d = _load()
    iid = _new_id(d)
    now = clock.now()
    row = {
        "id": iid,
        "deal": dk,
        "good": gk,
        # ⛒ ЗНІМОК: копія опису на момент домовленості.
        "snap": {k: _s(g.get(k)) for k in SNAP_FIELDS},
        # ⛒ ТЕКСТ, а не число: платформа нічого не рахує.
        "qty": _s(qty),
        "price": _s(price) if _s(price) else _s(g.get("price")),
        # ⭐ На якій стадії домовились — щоб на фіналі було видно, як мінялась
        # домовленість.
        "stage": _s((deals.get(dk) or {}).get("stage")),
        "by": _s(by),
        "created": now,
        "updated": now,
    }
    d["items"][iid] = row
    _save(d)
    _to_protocol(protocol.A_DEAL_ITEM_ADDED, dk, "додано: " + said(row), gid=gk)
    return dict(row)


@one_writer.guard("DEAL_ITEMS_JSON")
def _mutate(iid, patch_fn, what: str) -> dict:
    """ОДНА точка правки: хто зберігає — той і звітує."""
    key = _s(iid)
    d = _load()
    row = d["items"].get(key)
    if not row:
        raise DealItemError("Позиції %s немає в угоді." % (key or "«»"))
    patch_fn(row)
    row["updated"] = clock.now()
    d["items"][key] = row
    _save(d)
    _to_protocol(protocol.A_DEAL_ITEM_CHANGED, _s(row.get("deal")),
                 "%s: %s" % (said(row), what), gid=_s(row.get("good")))
    return dict(row)


def set_qty(iid, qty) -> dict:
    return _mutate(iid, lambda r: r.update({"qty": _s(qty)}),
                   "кількість → «%s»" % _s(qty))


def set_price(iid, price) -> dict:
    """⛒ Ціну домовленості правлять РУКАМИ. Вона не тягнеться з бази наново."""
    return _mutate(iid, lambda r: r.update({"price": _s(price)}),
                   "ціна → «%s»" % _s(price))


@one_writer.guard("DEAL_ITEMS_JSON")
def remove(iid, by: str = "") -> bool:
    """Прибрати позицію. ⛒ Зі списку вона ЗНИКАЄ, а слід іде в НАЯВНИЙ журнал
    угоди — це слово Андрія 07.09.2026, і другого журналу ми не заводимо."""
    key = _s(iid)
    d = _load()
    row = d["items"].get(key)
    if not row:
        raise DealItemError("Позиції %s немає в угоді." % (key or "«»"))
    del d["items"][key]
    _save(d)
    _to_protocol(protocol.A_DEAL_ITEM_REMOVED, _s(row.get("deal")),
                 "прибрано з позицій: " + said(row), gid=_s(row.get("good")))
    return True
