# -*- coding: utf-8 -*-
"""release_passport.py — ⭐⭐⭐ ОДИН ВІДТВОРЮВАНИЙ ЗАПИС ПРО ГОТОВНІСТЬ
(зміна 611, 19.09.2026).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ: **ГОТОВНІСТЬ ЗАЯВЛЯЄ ТЕКСТ, А НЕ ПРОГІН.**
18.09.2026 останній повний журнал закінчувався `SELF-CHECK: FAIL (5)`, а точка
зупинки того ж дня казала «лишились дві». Заяву й доказ писали різні руки в
різний час — і зійтись вони не мусили.

⭐ ТУТ ПАСПОРТ РАХУЄТЬСЯ З ДИСКА: відбиток коду · час і підсумок прогону ·
склад реєстру · НАЗВАНІ МЕЖІ того, що НЕ доведено. Код, змінений після
прогону, робить паспорт застарілим САМ — переказ більше не може пережити код.

⛒ Паспорт нічого не вирішує і нічого не лагодить. Він лише не дає сказати
«готово» без запису, на який можна показати пальцем.

Запуск: python release_passport.py   (пише «ПАСПОРТ_ГОТОВНОСТІ.md» у корінь)
"""
import hashlib
import json
import re
import time
from pathlib import Path

LOG_NAME = "_SUITE_RUN_LOG.txt"
OUT_NAME = "ПАСПОРТ_ГОТОВНОСТІ.md"

# ⛒ МЕЖІ НАЗИВАЮТЬСЯ, А НЕ ХОВАЮТЬСЯ. Кожен рядок — те, чого зелений набір НЕ
# доводить. Знімати межу можна лише разом із доказом; нова межа додається тут
# у той же день, коли її знайшли.
LIMITS = [
    # ⛒ 19.09.2026, зміна 612: попередня межа («суддя КП працює лише у прогоні
    # КП») ЗНЯТА разом із доказом — `result_policy_test.py`, 27 зелених,
    # 12 мутацій із 12 показали зуби. На її місце стають дві ВУЖЧІ межі, які
    # лишились правдою.
    {"when": "19.09.2026",
     "what": "Політика результату судить поки ОДИН тип документа — комерційну "
             "пропозицію. Інші документи (договір, тендерний пакет, правова "
             "довідка) власного закону ще не мають.",
     "price": "Документ іншого типу може суперечити сам собі, і ворота цього "
              "не побачать."},
    {"when": "19.09.2026",
     "what": "Перезбір документа за вироком політики доведено офлайн і "
             "мутаціями, але ЖИВОГО платного прогону через продуктовий шлях "
             "ще не було.",
     "price": "Як поводиться складальник на справжній моделі, коли дістає свої "
              "ж помилки дослівно, поки видно лише на тренувальному прогоні."},
    # ⛒ 19.09.2026, зміна 613: місток «картка угоди → КП».
    {"when": "19.09.2026",
     "what": "Місток «картка угоди → КП» доведено офлайн і мутаціями (40 "
             "зелених, 11 мутацій з 11 показали зуби), але ЖИВОГО платного "
             "прогону ЧЕРЕЗ КНОПКУ в картці ще не було: прогін на стенді "
             "підмінявся.",
     "price": "Як місток поводиться на справжній моделі — скільки коштує один "
              "натиск і чи доходить вирок судді до картки в бою — поки "
              "невідомо."},
    {"when": "19.09.2026",
     "what": "Системи «Пошта → Календар» на живій скриньці не прогнано: згода "
             "Google протермінована 19.08.2026.",
     "price": "Обіцянку щоденної синхронізації підтверджено лише кодом і пробами."},
    {"when": "19.09.2026",
     "what": "Встановлення, оновлення й відкат клієнтської збірки на ЧИСТІЙ "
             "машині цим набором не перевіряються.",
     "price": "Перше встановлення в нового клієнта лишається ручною роботою."},
    {"when": "19.09.2026",
     "what": "Ринкові числа в документах перевіряються на наявність джерела, "
             "але не на те, що число справді взяте звідти.",
     "price": "Цифру в пропозиції можна оскаржити, і захиститись буде нічим."},
]

_SKIP = ("__pycache__",)


def _is_code(p: Path) -> bool:
    if p.suffix != ".py" or not p.is_file():
        return False
    if "BACKUP" in p.name or ".BACKUP" in p.name:
        return False
    return not any(s in p.parts for s in _SKIP)


def code_fingerprint(engine_dir) -> str:
    """Відбиток УСЬОГО коду рушія: імена + вміст. Один байт — інший відбиток.

    ⛒ Проби й набори мутацій входять сюди свідомо: інструмент, яким доводять,
    — частина того, що доводиться (урок 609)."""
    h = hashlib.sha256()
    for p in sorted(Path(engine_dir).rglob("*.py"), key=lambda x: str(x).lower()):
        if not _is_code(p):
            continue
        h.update(p.name.encode("utf-8"))
        h.update(hashlib.sha256(p.read_bytes()).digest())
    return h.hexdigest()[:16]


def _newest_code(engine_dir):
    """(час, назва) найсвіжішого файла коду. (0, '') — коду немає."""
    best, who = 0.0, ""
    for p in Path(engine_dir).rglob("*.py"):
        if not _is_code(p):
            continue
        t = p.stat().st_mtime
        if t > best:
            best, who = t, p.name
    return best, who


def _den(ts) -> str:
    try:
        return time.strftime("%d.%m.%Y %H:%M", time.localtime(float(ts)))
    except Exception:
        return "—"


def passport(root) -> dict:
    """Стан готовності, порахований із диска. Нічого не вигадує."""
    root = Path(root)
    engine = root / "orchestrator_py"
    if not engine.is_dir():
        engine = root / "AI_Orchestrator_Platform" / "orchestrator_py"
    out = {"ready": False, "stale": False, "checks": 0, "why": "",
           "fingerprint": "", "when": "", "verdict": "", "engine": str(engine),
           "systems": {}, "limits": LIMITS}
    if engine.is_dir():
        out["fingerprint"] = code_fingerprint(engine)

    log = root / LOG_NAME
    if not log.is_file():
        out["why"] = ("Повного прогону набору немає: файл «%s» не знайдено. "
                      "Без нього про готовність не говоримо." % LOG_NAME)
        return out

    text = log.read_text(encoding="utf-8", errors="replace")
    out["when"] = _den(log.stat().st_mtime)
    m = re.search(r"SELF-CHECK SUITE \((\d+)\s*chek\)", text)
    if m:
        out["checks"] = int(m.group(1))
    tail = [ln for ln in text.splitlines() if ln.startswith("SELF-CHECK:")]
    out["verdict"] = tail[-1].strip() if tail else ""

    newest, who = _newest_code(engine) if engine.is_dir() else (0, "")
    if newest > log.stat().st_mtime:
        out["stale"] = True
        out["why"] = ("Код змінювався ПІСЛЯ прогону (найсвіжіший файл «%s», %s; "
                      "прогін %s). Паспорт застарілий — прогнати набір заново."
                      % (who, _den(newest), out["when"]))
        return out

    if not out["verdict"]:
        out["why"] = "У журналі немає підсумкового рядка набору — прогін обірвався."
        return out
    if "PASS" not in out["verdict"]:
        out["why"] = "Останній прогін набору червоний: %s" % out["verdict"][:200]
        return out

    out["ready"] = True
    out["why"] = ("Повний набір (%d чеків) пройдено без червоних на незміненій "
                  "збірці." % out["checks"])
    return out


def _systems_state(root):
    try:
        import registry
        ss = registry.load_systems()
        by = {}
        for s in ss:
            by[str(s.get("status") or "?")] = by.get(str(s.get("status") or "?"), 0) + 1
        return {"total": len(ss), "by_status": by}
    except Exception:
        return {}


def render(p: dict) -> str:
    rows = [
        "# ПАСПОРТ ГОТОВНОСТІ SensFlow",
        "",
        "Цей файл **рахується з диска**, а не пишеться від руки. Якщо код "
        "змінився після прогону — паспорт сам скаже, що він застарілий.",
        "",
        "| | |",
        "|---|---|",
        "| Стан | **%s** |" % ("ДОВЕДЕНО" if p.get("ready")
                               else ("ЗАСТАРІЛИЙ" if p.get("stale") else "НЕ ДОВЕДЕНО")),
        "| Відбиток коду | `%s` |" % (p.get("fingerprint") or "—"),
        "| Прогін набору | %s |" % (p.get("when") or "—"),
        "| Чеків у наборі | %s |" % (p.get("checks") or "—"),
        "| Підсумок прогону | `%s` |" % (p.get("verdict") or "—"),
    ]
    st = p.get("systems") or {}
    if st:
        rows.append("| Систем у реєстрі | %s (%s) |"
                    % (st.get("total"),
                       ", ".join("%s: %d" % (k, v)
                                 for k, v in sorted((st.get("by_status") or {}).items()))))
    rows += ["", "**Що це означає:** %s" % p.get("why", ""), "",
             "---", "", "## ЧОГО ЦЕЙ ПАСПОРТ НЕ ДОВОДИТЬ", "",
             "Зелений набір доводить архітектурні гарантії. Нижче — те, що він "
             "НЕ перевіряє. Кожен рядок знімається лише разом із доказом.", ""]
    for x in p.get("limits") or []:
        rows.append("* **%s** — %s" % (x.get("when"), x.get("what")))
        rows.append("  *Ціна:* %s" % x.get("price"))
    rows += ["", "---", "",
             "Зроблено писарем `orchestrator_py/release_passport.py` "
             "%s." % time.strftime("%d.%m.%Y %H:%M")]
    return "\n".join(rows) + "\n"


def main(root=None) -> int:
    here = Path(__file__).resolve().parent
    root = Path(root) if root else here.parent.parent
    p = passport(root)
    p["systems"] = _systems_state(root)
    (root / OUT_NAME).write_text(render(p), encoding="utf-8")
    print(render(p))
    print("Паспорт записано: %s" % (root / OUT_NAME))
    return 0 if p.get("ready") else 1


if __name__ == "__main__":
    import sys
    sys.exit(main())
