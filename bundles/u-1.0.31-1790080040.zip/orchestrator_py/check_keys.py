# -*- coding: utf-8 -*-
"""check_keys.py — ЧИ ЖИВІ КЛЮЧІ, ЯКИМИ ДУМАЄ ПЛАТФОРМА (16.09.2026).

⛒ НАВІЩО. 16.09.2026 платформа піднялась здоровою, показала «Провайдер :
anthropic [готовий]» — і на першому ж прогоні отримала від постачальника
HTTP 401. «Ключ є» і «ключ приймають» — це різні речі, а дізнавались ми про
різницю в мить, коли робота вже потрібна.

Цей інструмент питає САМИХ ПОСТАЧАЛЬНИКІВ найдешевшим запитом (перелік
моделей — грошей не коштує) і каже словами, яким ключем сьогодні можна
працювати. Секретів не друкує: лише довжину й початок.

Запуск: python check_keys.py     (або кнопка «ПЕРЕВІРИТИ КЛЮЧІ.bat» у корені)
"""
import json
import re
import ssl
import sys
import urllib.error
import urllib.request
from pathlib import Path


# ⛒ 623: ДОВІРУ ДО СЕРТИФІКАТА ЗНАЄ ОДИН ПИСАР (netfetch.ssl_context).
# Модуль, що відкриває сокет сам, у клієнта зі старим сховищем коренів ляже
# мовчки — саме це сталось 21.09.2026 з Telegram. Тому кожен вихід питає його.
def _sf_ssl():
    try:
        import netfetch
        return netfetch.ssl_context()
    except Exception:
        return None


HERE = Path(__file__).resolve().parent
ENV = HERE / ".env.local"
TIMEOUT = 20


def env_value(name: str) -> str:
    try:
        text = ENV.read_text(encoding="utf-8")
    except Exception as ex:
        print("ВІДМОВА: не читається %s (%s)" % (ENV.name, ex))
        sys.exit(2)
    m = re.search(r"^%s=(.*)$" % re.escape(name), text, re.M)
    return (m.group(1).strip() if m else "")


def _from_provider(ex) -> bool:
    """Чи це відповів САМ постачальник, а не щось по дорозі.

    🩸🩸🩸 УРОК 16.09.2026, І ВІН ДОРОГИЙ. Ця перевірка сказала «ключ мертвий»
    на живому ключі — бо дивилась на НОМЕР відповіді й не питала, ХТО відповів.
    Насправді 401 повернув фільтр мережі на шляху (він не випускає назовні
    запит із ключем), а не Anthropic. Я на цій підставі підняв тривогу перед
    показом — дарма.
    ⛒ КЛАС: код відповіді без автора — це не вирок. Постачальник відповідає
    СВОЇМ форматом: json і свій слід у заголовках. Гола сторінка «Unauthorized»
    текстом — це хтось по дорозі, і казати про ключ по ній не можна.
    """
    ctype = (ex.headers.get("Content-Type") or "").lower()
    if "json" in ctype:
        return True
    marks = ("cf-ray", "x-request-id", "request-id", "anthropic-ratelimit-requests-limit",
             "openai-processing-ms", "x-goog-api-client", "server-timing")
    return any(ex.headers.get(m) for m in marks)


def ask(url: str, headers: dict) -> tuple:
    """(живий, що сказав постачальник). Мережеву біду не плутаємо з ключем."""
    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT, context=_sf_ssl()) as r:
            r.read(200)
        return True, "ключ прийнято"
    except urllib.error.HTTPError as ex:
        code = ex.code
        if not _from_provider(ex):
            return None, ("відповів не постачальник, а щось на шляху "
                          "(HTTP %d, без ознак постачальника) — проксі, фаєрвол "
                          "або фільтр мережі" % code)
        if code in (401, 403):
            return False, "ключ НЕ прийнято (HTTP %d, відповів сам постачальник)" % code
        if code == 429:
            return True, "ключ живий, але зараз ліміт запитів (HTTP 429)"
        return False, "постачальник відповів HTTP %d" % code
    except Exception as ex:
        return None, "не додзвонились до постачальника (%s)" % type(ex).__name__


def main() -> int:
    print("=" * 64)
    print("  ЧИ ЖИВІ КЛЮЧІ ПЛАТФОРМИ — питаємо самих постачальників")
    print("=" * 64)
    brain = env_value("LLM_PROVIDER") or "(не названо)"
    print("  Мозок за налаштуваннями: %s" % brain)
    print("-" * 64)

    checks = [
        ("anthropic", "ANTHROPIC_API_KEY",
         "https://api.anthropic.com/v1/models?limit=1",
         lambda k: {"x-api-key": k, "anthropic-version": "2023-06-01"}),
        ("openai", "OPENAI_API_KEY",
         "https://api.openai.com/v1/models",
         lambda k: {"Authorization": "Bearer %s" % k}),
        ("gemini", "GEMINI_API_KEY",
         "https://generativelanguage.googleapis.com/v1beta/models?key=%s",
         None),
    ]
    alive, dead, unknown = [], [], []
    for name, env_name, url, hdr in checks:
        key = env_value(env_name)
        if not key:
            print("  %-10s ключа у налаштуваннях немає" % name)
            continue
        ok, why = ask(url % key if hdr is None else url,
                      {} if hdr is None else hdr(key))
        mark = {True: "ЖИВИЙ  ", False: "МЕРТВИЙ", None: "?      "}[ok]
        print("  %-10s %s %s   (%d знаків, %s…)" % (name, mark, why, len(key), key[:7]))
        (alive if ok else (unknown if ok is None else dead)).append(name)

    print("-" * 64)
    # ⛒ «Не додзвонились» — це НЕ «ключ мертвий». Плутати ці два стани означає
    # послати людину міняти робочий ключ через те, що в неї впав інтернет.
    if not alive and unknown:
        print("  ПЕРЕВІРКА НЕ ЗАВЕРШЕНА: до %s не вдалося додзвонитись."
              % ", ".join(unknown))
        print("  Це схоже на мережу (інтернет, проксі, фаєрвол), а не на ключі.")
        if dead:
            print("  А от ці ключі постачальник прямо відхилив: %s." % ", ".join(dead))
        return 1
    if not alive:
        print("  ЖОДНОГО ЖИВОГО КЛЮЧА. Платформа підніметься, але жодного")
        print("  прогону не зробить. Вставити робочий ключ:")
        print("     http://127.0.0.1:7799/setup")
        return 1
    if brain in alive:
        print("  МОЖНА ПРАЦЮВАТИ: мозок «%s» має живий ключ." % brain)
    else:
        print("  УВАГА: мозок налаштований на «%s», а живі ключі — %s."
              % (brain, ", ".join(alive)))
        print("  Перемкнути мозок на живого постачальника: http://127.0.0.1:7799/setup")
    return 0


if __name__ == "__main__":
    sys.exit(main())
