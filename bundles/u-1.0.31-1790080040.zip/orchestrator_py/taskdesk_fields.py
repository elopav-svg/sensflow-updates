# -*- coding: utf-8 -*-
"""
taskdesk_fields.py — ОДИН РЕЄСТР ПОЛІВ ЗАДАЧІ НА ВЕСЬ TASK DESK.

Навіщо цей файл існує. Андрій попросив три речі одразу: фільтр по полях задачі,
налаштовувані колонки списку і вивантаження налаштованого списку в xlsx. Якби
кожна з них знала свій власний перелік полів, ми б завели ТРЬОХ ПИСАРІВ ОДНІЄЇ
ПРАВДИ: додав поле в список — забув у фільтрі; полагодив у фільтрі — розійшовся
з файлом. Це рівно той клас, який уже коштував нам збірок.

Тому поле оголошується ТУТ РІВНО ОДИН РАЗ, а всі четверо його лише питають:
  * список на екрані        — які колонки взагалі бувають і як показати значення;
  * налаштування колонок    — той самий перелік, нічого свого;
  * панель фільтра          — чим це поле фільтрується і які в нього варіанти;
  * вивантаження в xlsx     — ті самі колонки й ті самі значення, що на екрані.

⭐⭐⭐ ТРИ ЗАКОНИ ЦЬОГО ФАЙЛА
1. **ФІЛЬТР ЛИШЕ ЗВУЖУЄ.** На вхід приходить те, що людині вже видно за
   `taskdesk_tasks.visible_ids()`. Фільтр не має доступу до диска й не вміє
   додати жодної задачі — фізично, а не за домовленістю.
2. **НЕВІДОМЕ ПОЛЕ — ВІДМОВА СЛОВАМИ.** Фільтр по полю, якого немає в реєстрі,
   не ігнорується мовчки (це показало б людині повний список як «відфільтрований»),
   а зупиняється з причиною.
3. **ЩО НА ЕКРАНІ — ТЕ Й У ФАЙЛІ.** Значення для клітинки таблиці й для клітинки
   xlsx рахує ОДНА функція `value()`. Другого форматувальника не існує.

⚠ Мозок (LLM) сюди не ходить — це логічний скрипт.
"""

import taskdesk_people as people
import taskdesk_tasks as tasks


class FieldError(Exception):
    """Відмова з причиною словами: тиха відмова = вимкнені ворота."""


# ---------------------------------------------------------------------------
# КОНТЕКСТ — те, чого немає в самій задачі, але треба для показу (імена, відділи).
# Збираємо ОДИН раз на запит, щоб не бити диск на кожному рядку.
# ---------------------------------------------------------------------------
def context() -> dict:
    emps = people.employees(True)
    # ⛒ ТУТ ліквідовані потрібні: це карта ІМЕН для читання старих записів,
    # а не список, з якого вибирають. Безіменний підрозділ у історії задач —
    # та сама сирітська історія, якої ми уникали, не видаляючи запис.
    unit_name = {u["id"]: u.get("name", "")
                 for u in people.units(include_liquidated=True)}
    return {
        "names": {e["id"]: e.get("full_name", "") for e in emps},
        "unit_of": {e["id"]: unit_name.get(e.get("unit_id", ""), "") for e in emps},
        "people": [{"value": e["id"], "label": e.get("full_name", "")} for e in emps],
    }


def _human_date(iso: str) -> str:
    """Людині — DD.MM.YYYY. Машині — те, що лежить на диску. Перетворення тут."""
    s = str(iso or "")
    if len(s) < 10:
        return ""
    d = "%s.%s.%s" % (s[8:10], s[5:7], s[0:4])
    return (d + " " + s[11:16]) if len(s) >= 16 and s[10] in "T " else d


def _names(ctx, ids) -> str:
    return ", ".join([ctx["names"].get(i, i) for i in (ids or [])])


# ---------------------------------------------------------------------------
# ⭐ САМ РЕЄСТР. Порядок тут = порядок у налаштуваннях колонок і у фільтрі.
#   kind   — як показувати (для ширини колонки та вирівнювання у xlsx);
#   filter — чим фільтрується: set (вибір зі списку) | text | date | flag | none;
#   show   — ОДНА функція значення: і для екрана, і для файла;
#   raw    — значення, за яким порівнює фільтр (не те, що бачить око).
# ---------------------------------------------------------------------------
FIELDS = [
    {"id": "id", "label": "№", "kind": "text", "filter": "text", "w": 12,
     "show": lambda t, c: t["id"], "raw": lambda t, c: t["id"]},

    {"id": "title", "label": "Задача", "kind": "text", "filter": "text", "w": 52,
     "show": lambda t, c: t["title"], "raw": lambda t, c: t["title"]},

    {"id": "assignee", "label": "Виконавець", "kind": "person", "filter": "set", "w": 24,
     "show": lambda t, c: c["names"].get(t["assignee_id"], ""),
     "raw": lambda t, c: t["assignee_id"]},

    {"id": "author", "label": "Постановник", "kind": "person", "filter": "set", "w": 24,
     "show": lambda t, c: c["names"].get(t["author_id"], ""),
     "raw": lambda t, c: t["author_id"]},

    {"id": "unit", "label": "Підрозділ виконавця", "kind": "text", "filter": "set", "w": 26,
     "show": lambda t, c: c["unit_of"].get(t["assignee_id"], ""),
     "raw": lambda t, c: c["unit_of"].get(t["assignee_id"], "")},

    {"id": "stage", "label": "Стадія", "kind": "text", "filter": "set", "w": 16,
     "show": lambda t, c: t["stage_name"], "raw": lambda t, c: t["stage"],
     # ⭐ Підпис варіанта каже САМЕ ПОЛЕ. Доти його знав `options()` — і кожне
     # нове поле з нелюдськими значеннями вимагало б там нового «якщо».
     "label_of": lambda v, c: tasks.STAGE_NAMES.get(v, v)},

    # ⭐⭐ ПРОЄКТ (01.09.2026). Робочий напрям, до якого належить задача. Заведено
    # в РЕЄСТР, а не в екран: звідси його даром дістають фільтр, пошук,
    # сортування, налаштування колонок і вивантаження у xlsx.
    # ⛒ Порівнює фільтр за НОМЕРОМ проєкту, а не за назвою: назву можна
    # перейменувати, і збережений фільтр перестав би працювати мовчки.
    # ⛒ Назву дає `tasks.project_name` — ОДИН писар: він же каже «проєкт
    # видалено» замість порожнечі, і те саме слово побачить і список, і файл.
    {"id": "project", "label": "Проєкт", "kind": "text", "filter": "set", "w": 26,
     "show": lambda t, c: tasks.project_name(t.get("project_id") or ""),
     "raw": lambda t, c: t.get("project_id") or "",
     "label_of": lambda v, c: tasks.project_name(v)},

    {"id": "due", "label": "Термін", "kind": "date", "filter": "date", "w": 18,
     "show": lambda t, c: _human_date(t["due_effective"]),
     "raw": lambda t, c: (t["due_effective"] or "")[:10]},

    {"id": "due_source", "label": "Звідки термін", "kind": "text", "filter": "set", "w": 16,
     "show": lambda t, c: t["due_source"], "raw": lambda t, c: t["due_source"]},

    {"id": "overdue", "label": "Протерміновано", "kind": "flag", "filter": "flag", "w": 16,
     "show": lambda t, c: "так" if t["overdue"] else "",
     "raw": lambda t, c: bool(t["overdue"])},

    {"id": "days_left", "label": "Днів лишилось", "kind": "number", "filter": "none", "w": 15,
     "show": lambda t, c: "" if t["days_left"] is None else str(t["days_left"]),
     "raw": lambda t, c: t["days_left"]},

    {"id": "plan", "label": "План", "kind": "text", "filter": "none", "w": 12,
     "show": lambda t, c: ("%d/%d" % (t["checklist_done"], t["checklist_total"]))
                          if t["checklist_total"] else "",
     "raw": lambda t, c: t["checklist_total"]},

    {"id": "has_result", "label": "Є результат", "kind": "flag", "filter": "flag", "w": 14,
     "show": lambda t, c: "так" if t["result_comment_id"] else "",
     "raw": lambda t, c: bool(t["result_comment_id"])},

    {"id": "coassignees", "label": "Співвиконавці", "kind": "person", "filter": "set", "w": 28,
     "show": lambda t, c: _names(c, t["coassignee_ids"]),
     "raw": lambda t, c: list(t["coassignee_ids"] or [])},

    {"id": "watchers", "label": "Спостерігачі", "kind": "person", "filter": "set", "w": 28,
     "show": lambda t, c: _names(c, t["watcher_ids"]),
     "raw": lambda t, c: list(t["watcher_ids"] or [])},

    {"id": "description", "label": "Опис", "kind": "text", "filter": "text", "w": 60,
     "show": lambda t, c: t["description"], "raw": lambda t, c: t["description"]},

    {"id": "created_at", "label": "Створено", "kind": "date", "filter": "date", "w": 18,
     "show": lambda t, c: _human_date(t["created_at"]),
     "raw": lambda t, c: (t["created_at"] or "")[:10]},

    {"id": "updated_at", "label": "Останній рух", "kind": "date", "filter": "date", "w": 18,
     "show": lambda t, c: _human_date(t["updated_at"]),
     "raw": lambda t, c: (t["updated_at"] or "")[:10]},

    # ⭐ ЗАТОРИ (зміна 240). Дві сторони одного факту: СКІЛЬКИ стоїть — число,
    # ЧИ стоїть — ознака, за якою можна відфільтрувати. Обидві РАХУЮТЬСЯ.
    {"id": "idle_days", "label": "Стоїть днів", "kind": "number", "filter": "none", "w": 14,
     "show": lambda t, c: ("" if t.get("idle_days") is None
                           else ("сьогодні" if t["idle_days"] <= 0
                                 else "%d" % t["idle_days"])),
     "raw": lambda t, c: (t.get("idle_days") if t.get("idle_days") is not None else "")},

    {"id": "stuck", "label": "Стоїть", "kind": "flag", "filter": "flag", "w": 14,
     "show": lambda t, c: (("стоїть %d дн." % t["idle_days"]) if t.get("stuck") else ""),
     "raw": lambda t, c: bool(t.get("stuck"))},

    # ⭐ ЗАЛЕЖНОСТІ (зміна 242). «Чекає на іншу» — ознака, за якою можна
    # відфільтрувати: питання керівника «що стоїть не через нас» тепер має
    # відповідь одним кліком, а не обходом карток.
    {"id": "waiting", "label": "Чекає на іншу", "kind": "flag", "filter": "flag", "w": 18,
     "show": lambda t, c: (("чекає на %d" % len(t.get("waiting_for") or []))
                           if t.get("waiting") else ""),
     "raw": lambda t, c: bool(t.get("waiting"))},

    {"id": "broken", "label": "Запис пошкоджено", "kind": "flag", "filter": "flag", "w": 18,
     "show": lambda t, c: t["broken_reason"] if t["broken"] else "",
     "raw": lambda t, c: bool(t["broken"])},
]

BY_ID = {f["id"]: f for f in FIELDS}

# Колонки, які людина бачить, доки нічого не налаштувала.
DEFAULT_COLUMNS = ["id", "title", "assignee", "stage", "due", "plan"]


def field(fid: str) -> dict:
    f = BY_ID.get(str(fid or "").strip())
    if f is None:
        raise FieldError("Поля «%s» у задачі немає. Є такі: %s"
                         % (fid, ", ".join([x["id"] for x in FIELDS])))
    return f


def catalogue() -> list:
    """Перелік полів для інтерфейсу — БЕЗ функцій, самий опис."""
    return [{"id": f["id"], "label": f["label"], "kind": f["kind"],
             "filter": f["filter"]} for f in FIELDS]


def normalize_columns(cols) -> list:
    """Невідомі колонки відкидаємо мовчки (могли зникнути після оновлення),
    але порожній набір не пускаємо — інакше список став би порожньою таблицею."""
    out, seen = [], set()
    for c in (cols or []):
        c = str(c or "").strip()
        if c in BY_ID and c not in seen:
            out.append(c)
            seen.add(c)
    return out or list(DEFAULT_COLUMNS)


def value(t: dict, fid: str, ctx: dict) -> str:
    """⭐ ОДИН ФОРМАТУВАЛЬНИК: і для клітинки на екрані, і для клітинки у xlsx."""
    try:
        return field(fid)["show"](t, ctx)
    except FieldError:
        raise
    except Exception:
        return ""


def row(t: dict, cols, ctx: dict) -> list:
    return [value(t, c, ctx) for c in cols]


# ---------------------------------------------------------------------------
# ФІЛЬТР
# ---------------------------------------------------------------------------
def options(tasks_list, ctx: dict) -> dict:
    """Варіанти для полів типу «вибір зі списку» — рахуємо з ТОГО, ЩО ВИДНО.
    Людині не показуємо варіантів, яких у її задачах усе одно немає."""
    out = {}
    for f in FIELDS:
        if f["filter"] != "set":
            continue
        vals = set()
        for t in tasks_list:
            r = f["raw"](t, ctx)
            if isinstance(r, list):
                vals.update([x for x in r if x])
            elif r:
                vals.add(r)
        # ⛒ ПІДПИС ВАРІАНТА ЗНАЄ ПОЛЕ, А НЕ ЦЕЙ ЦИКЛ. Доти тут стояв ланцюжок
        # «якщо» з полями поіменно — і кожне нове поле з нелюдськими значеннями
        # мусило б дописати в нього свій рядок. Того рядка й забувають.
        if f.get("label_of"):
            items = [{"value": v, "label": f["label_of"](v, ctx)} for v in vals]
        elif f["kind"] == "person":
            items = [{"value": v, "label": ctx["names"].get(v, v)} for v in vals]
        else:
            items = [{"value": v, "label": v} for v in vals]
        out[f["id"]] = sorted(items, key=lambda x: x["label"])
    return out


def _match(f, t, ctx, cond) -> bool:
    kind = f["filter"]
    raw = f["raw"](t, ctx)
    if kind == "set":
        want = [str(x) for x in (cond or []) if str(x)]
        if not want:
            return True
        have = raw if isinstance(raw, list) else [raw]
        return any([str(h) in want for h in have])
    if kind == "text":
        needle = str(cond or "").strip().lower()
        return (needle in str(raw or "").lower()) if needle else True
    if kind == "date":
        lo = str((cond or {}).get("from") or "")
        hi = str((cond or {}).get("to") or "")
        cur = str(raw or "")
        if lo and (not cur or cur < lo):
            return False
        if hi and (not cur or cur > hi):
            return False
        return True
    if kind == "flag":
        if cond in (None, "", "any"):
            return True
        return bool(raw) is (cond in (True, "true", "1", 1, "так"))
    raise FieldError("Поле «%s» не фільтрується." % f["id"])


def apply_filter(tasks_list, flt, ctx: dict) -> list:
    """⭐ ЗАКОН: сюди приходить ВЖЕ видиме людині, і воно може лише зменшитись.
    Доступу до диска ця функція не має — розширити набір їй нічим."""
    flt = flt or {}
    if not isinstance(flt, dict):
        raise FieldError("Фільтр має бути набором «поле → умова».")
    conds = []
    for fid, cond in flt.items():
        f = field(fid)                       # невідоме поле = відмова словами
        if f["filter"] == "none":
            raise FieldError("За полем «%s» фільтрувати не можна." % f["label"])
        conds.append((f, cond))
    if not conds:
        return list(tasks_list)
    return [t for t in tasks_list
            if all([_match(f, t, ctx, cond) for f, cond in conds])]


# ---------------------------------------------------------------------------
# ⭐ ШВИДКИЙ ПОШУК — «знайди КОНКРЕТНУ задачу».
#
# Це третє питання екрана, і воно не таке, як два інші. «Покажи інший зріз» —
# це набір; «збудуй складний відбір» — це панель фільтра; а «де та задача про
# оплату» людина питає щодня одним словом і не має заради нього нічого
# розкривати. Доти цього питання на екрані не було ВЗАГАЛІ.
#
# ⭐⭐⭐ ЧОМУ ПОШУК ЖИВЕ ТУТ, А НЕ НА СТОРІНЦІ. Правило звуження — це правило про
# ПОЛЯ ЗАДАЧІ, а поля оголошені рівно тут. Якби пошук знав свій власний перелік
# полів, ми б завели ДРУГОГО ПИСАРЯ тієї самої правди: додав поле — забув у
# пошуку. Та сама причина, що й у фільтра, колонок і xlsx.
#
# ⭐⭐⭐ І ЧОМУ ВІН ІДЕ ТИМ САМИМ ШЛЯХОМ, ЩО ФІЛЬТР. Пошук отримує вже ВИДИМЕ
# людині й може лише зменшити його. Окремий «пошук», який сам ходить на диск,
# був би ДРУГИМ ВХОДОМ повз `taskdesk_tasks.visible_ids()` — тобто дірою в
# чужі задачі, а не зручністю.
#
# ⭐⭐ ДВА РІЗНІ ПРАВИЛА, І ЦЕ НАВМИСНО:
#   * назва й номер — ПІДРЯДКОМ: людина памʼятає шматок фрази з середини;
#   * прізвище — ЗА ПОЧАТКОМ СЛОВА: людина набирає перші літери, і «ко» не має
#     витягувати всіх Петренків, Хоменків і Марченків одразу.
# ---------------------------------------------------------------------------
SEARCH_HINT = "назва, номер або прізвище"

SEARCH_TEXT = ("id", "title")                                  # підрядком
SEARCH_PEOPLE = ("assignee", "author", "coassignees", "watchers")   # з початку слова


def _word_starts(name: str, needle: str) -> bool:
    """Чи починається з `needle` хоч одне слово імені."""
    for w in str(name or "").lower().replace(",", " ").split():
        if w.startswith(needle):
            return True
    return False


def search_narrow(tasks_list, query, ctx: dict) -> list:
    """⭐ ЗАКОН той самий, що в `apply_filter`: сюди приходить ВЖЕ видиме, і воно
    може лише зменшитись. Порожній запит нічого не змінює — це не «показати
    все», а «людина ще нічого не питала»."""
    q = str(query or "").strip().lower()
    if not q:
        return list(tasks_list)
    out = []
    for t in tasks_list:
        hit = False
        for fid in SEARCH_TEXT:
            if q in str(field(fid)["raw"](t, ctx) or "").lower():
                hit = True
                break
        if not hit:
            for fid in SEARCH_PEOPLE:
                raw = field(fid)["raw"](t, ctx)
                ids = raw if isinstance(raw, list) else [raw]
                for i in ids:
                    if i and _word_starts(ctx["names"].get(i, ""), q):
                        hit = True
                        break
                if hit:
                    break
        if hit:
            out.append(t)
    return out


# ---------------------------------------------------------------------------
# ⭐ ПОРЯДОК СПИСКУ — ще одне правило про ПОЛЯ, тож живе теж тут.
#
# ⭐⭐⭐ ЗАКОН: СОРТУВАННЯ МІНЯЄ ПОРЯДОК, А НЕ СКЛАД. Це не фільтр: жодна задача
# не має ні зникнути, ні зʼявитись. Тому воно й не ходить на диск.
#
# ⭐⭐ СОРТУЄМО ЗА ТИМ, ЩО ЛЮДИНА БАЧИТЬ, А НЕ ЗА ТИМ, ЩО ЛЕЖИТЬ У ФАЙЛІ.
# Виконавець у файлі — це `emp-3f2a...`; сортувати за цим означало б розкласти
# людей у випадковому порядку. Тому для людей ключ — ІМЕНА.
#
# ⭐⭐ ПОРОЖНІ — ЗАВЖДИ В КІНЦІ, і при зростанні, і при спаданні. Задача без
# терміну — не «найраніша» і не «найпізніша», вона просто без терміну.
# ---------------------------------------------------------------------------
def sort_key(t: dict, fid: str, ctx: dict):
    f = field(fid)
    raw = f["raw"](t, ctx)
    if f["kind"] == "person":
        if isinstance(raw, list):
            names = sorted([ctx["names"].get(x, "") for x in raw if x])
            raw = names[0] if names else ""
        else:
            raw = ctx["names"].get(raw, "")
    elif f["kind"] == "number":
        return 0.0 if raw is None else float(raw)
    elif f["kind"] == "flag":
        return 1 if raw else 0
    if isinstance(raw, list):
        raw = ", ".join([str(x) for x in raw if x])
    return str(raw or "").lower()


def _is_empty(t: dict, fid: str, ctx: dict) -> bool:
    k = sort_key(t, fid, ctx)
    return k == "" if isinstance(k, str) else False


def sort_rows(tasks_list, fid: str, desc: bool, ctx: dict) -> list:
    """⭐ ОДИН ПИСАР ПОРЯДКУ на список, дошку і xlsx."""
    fid = str(fid or "").strip()
    if not fid:
        return list(tasks_list)
    field(fid)                               # невідоме поле = відмова словами
    have = [t for t in tasks_list if not _is_empty(t, fid, ctx)]
    empty = [t for t in tasks_list if _is_empty(t, fid, ctx)]
    have.sort(key=lambda t: sort_key(t, fid, ctx), reverse=bool(desc))
    return have + empty
