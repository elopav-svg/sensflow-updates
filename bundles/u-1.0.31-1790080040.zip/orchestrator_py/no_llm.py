# -*- coding: utf-8 -*-
"""no_llm.py — ⛒ ПРОБА НЕ РОЗМОВЛЯЄ З ЖИВОЮ МОДЕЛЛЮ (581г, 13.09.2026).

⛒⛒⛒ КЛАС ВАДИ: **ПРОБА, ЧИЙ ВИРОК УХВАЛЮЄ МОДЕЛЬ.**

🩸 13.09.2026. `understanding_card_test` почервоніла на машині власника й була
зелена в дзеркалі. Причина з журналу дослівно:

    [agent] ворота маршруту: система=legal_assistant покриває=True
    [agent] ворота маршруту: система=legal_assistant покриває=False

Ворота маршруту питали ЖИВУ МОДЕЛЬ і на те саме питання про ту саму систему
відповіли двічі по-різному. Проба порахувала це поломкою платформи. Власник
клікнув — і знову став вимірювальним приладом.

581в зачинила ТІ двері (вирок воріт пришпилено). Але зачинити двері по одному —
це латка: назавтра хтось додасть у цей шлях новий виклик моделі, і все
повториться. ⛒ 13.09.2026 вимір показав, що так і є: у пробі лишалось ще одне
справжнє звернення (`capability_offer._rank` → `llm.judge_json`), і в точці
зупинки 581в я зарано написав, що клік «більше не палить грошей».

⭐ ЛІК КЛАСУ: проба ОГОЛОШУЄ, що з моделлю не говорить, і сама себе на цьому
судить. Кожен вихід `llm` назовні тут підмінено тихим записувачем: він нічого
не питає, повертає порожню відповідь і ЗАПАМʼЯТОВУЄ, хто його смикнув. Наприкінці
проба вимагає НУЛЯ звернень і НАЗИВАЄ винуватця.

⛒ Чому записувач, а не виняток: половина шляхів платформи ловить помилку моделі
й чесно працює далі (FAIL-CLOSED). Виняток вони проковтнули б — і двері знову
стали б невидимими. Записувача проковтнути не можна: він лишає слід.
"""

_OUTWARD = ("complete", "complete_full", "complete_whole", "complete_vision",
            "complete_json", "judge_json", "search_complete")




# ⛒ ДВА ГОЛОСИ ДЛЯ ОДНОГО Й ТОГО САМОГО ПИТАННЯ. Проба прогоняється під обома
# і мусить винести ТОЙ САМИЙ вирок. Саме на цьому 13.09.2026 і згоріла зміна:
# жива модель відповіла двічі по-різному, а вирок пішов за нею.
VOICES = {
    "мовчання": {"complete": "", "complete_full": "", "complete_whole": "",
                 "complete_vision": "", "complete_json": {}, "judge_json": {},
                 "search_complete": ""},
    "суперечка": {"complete": "МОДЕЛЬ КАЖЕ СВОЄ", "complete_full": "МОДЕЛЬ КАЖЕ СВОЄ",
                  "complete_whole": "МОДЕЛЬ КАЖЕ СВОЄ",
                  "complete_vision": "МОДЕЛЬ КАЖЕ СВОЄ",
                  "complete_json": {"covers": False, "refusal": True, "pick": []},
                  "judge_json": {"covers": False, "refusal": True, "pick": []},
                  "search_complete": "МОДЕЛЬ КАЖЕ СВОЄ"},
}


class Silence:
    """Тиша на час прогону проби. `calls` — імена функцій, які хтось смикнув.

    voice — яким голосом відповідає підмінена модель (див. VOICES)."""

    def __init__(self, voice="мовчання"):
        self.calls = []
        self.voice = voice
        self._answers = VOICES.get(voice, VOICES["мовчання"])
        self._orig = {}

    def __enter__(self):
        import llm
        for name in _OUTWARD:
            fn = getattr(llm, name, None)
            if fn is None:
                continue
            self._orig[name] = fn
            setattr(llm, name, self._spy(name))
        return self

    def _spy(self, name):
        def _rec(*a, **k):
            self.calls.append(name)
            return self._answers.get(name, "")
        return _rec

    def __exit__(self, *exc):
        import llm
        for name, fn in self._orig.items():
            setattr(llm, name, fn)
        self._orig = {}
        return False

    def report(self) -> str:
        """Чим саме проба сходила до моделі. Порожньо — не сходила."""
        if not self.calls:
            return ""
        seen = {}
        for c in self.calls:
            seen[c] = seen.get(c, 0) + 1
        return ", ".join("%s×%d" % (k, seen[k]) for k in sorted(seen))
