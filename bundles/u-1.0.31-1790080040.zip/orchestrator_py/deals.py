# -*- coding: utf-8 -*-
"""deals.py — УГОДА СТАЄ СУТНІСТЮ CRM (крок C1, 15.08.2026).

⭐⭐⭐ КОРІНЬ. До сьогодні угода не була сутністю: вона була НАЗВОЮ КАРТКИ в
`crm/clients.json`. У тій самій картці одночасно жили три різні речі — ліцензія й
канал оновлень, продаж, і бейдж уваги. Наслідки бачив кожен:

  1. На угоду НЕМА ЧИМ ВКАЗАТИ: `entity` не знав виду `deal`, тому ні задача, ні
     протокол, ні майбутня заявка не могли сказати «це про цю угоду».
  2. КЛЮЧ — РЯДОК НАЗВИ: перейменував клієнта — отримав другу угоду. На диску вже
     лежав доказ: «Борис Мамлін» і «Boris Mamlin» — дві картки на один `p0004`.
  3. ОДНА УГОДА НА ВСЕ ЖИТТЯ КЛІЄНТА: повторному продажу, продовженню, апсейлу
     не було де жити.
  4. ВОРОНКА МІРЯЛА НЕ ТЕ: у ній лежали 23 картки, з них 11 — тестувальники
     чужого продукту.
  5. ЛІЦЕНЗІЯ Й ПРОДАЖ ЗВʼЯЗАНІ НАЗВОЮ — тому ТЕХНІЧНА дія (збірка пакета)
     мовчки рухала ГРОШІ у воронці.

⛒ ЗАКОН ШАРУ (продовження B1): ХТО ЦЕЙ КОНТРАГЕНТ — знає `parties`; ЩО МИ ЙОМУ
ПРОДАЄМО — знає ЦЕЙ ФАЙЛ; ЯКУ ЛІЦЕНЗІЮ ЙОМУ ВИДАНО І ЯКИМ КАНАЛОМ ЇДУТЬ
ОНОВЛЕННЯ — лишається в `crm/clients.json`, і воно НЕ ЧІПАЄТЬСЯ (рішення Р3
проєкту C1). Ліцензія — це техніка, а не гроші у воронці.

⛔ ЧОГО ЦЕЙ ФАЙЛ НЕ РОБИТЬ. Він не знає, хто такий контрагент (питає `entity` /
`parties`), не веде історію спілкування (вона на контакті, B1) і не має власного
реєстру звʼязків: «угода з компанією» і «контактна особа угоди» лежать у
`links.py` — тому картка контакту показує свої угоди ПОХІДНО, без другого сховища.

Файл: `crm/deals.json`. Шлях лежить у змінній модуля — чек підміняє її й не сміє
писати в бойову теку (той самий прийом, що з `audit._PATH`, `parties.PARTIES_JSON`,
`links.LINKS_JSON`, `protocol._PATH`).
"""

import json
import one_writer
import re

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import entity                     # спільне імʼя сутності на всю платформу
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій (хребет)

# 🩸🩸🩸 ЗНАЙДЕНО ОКОМ 15.08.2026, ЩОЙНО ПЕРЕЇЗД ЛІГ НА ДИСК: у бойовому реєстрі
# опинилось ПʼЯТЬ угод із чужих чеків («Проба Фірма», «ФОП Стрейнджер»). Причина
# не в самих чеках: `contact_layer_test` і `parties_test` чесно відводять убік
# CRM, довідник, звʼязки й протокол — але про НОВИЙ реєстр вони не знали й знати
# не могли. Це рівно той клас, від якого нас лікував `state_isolation`: писар,
# який не слухається вимикача ізоляції, рано чи пізно напише в актив Андрія.
# ⛒ ТОМУ ВИМИКАЧ СЛУХАЄ САМ РЕЄСТР, а не той, хто його викликає: у чек-режимі
# (`config.STATE_SANDBOXED`) угоди лягають у пісочницю. У бою шлях не міняється
# ні на байт.
DIR = config.CRM_DIR
DEALS_JSON = DIR / "deals.json"

# ── ВОРОНКА: ОДИН ПИСАР СТАДІЙ НА ВСЮ ПЛАТФОРМУ ──────────────────────────────
# ⛒ Стадії переїхали СЮДИ з `crm.py` разом із самим продажем. `crm.STAGES`
# лишається тим самим імʼям, але тепер це ПОСИЛАННЯ на цей перелік: два переліки
# стадій розійшлись би на першій же правці, і воронка почала б губити картки.
STAGES = [
    "Новий клієнт", "Збір даних", "Кваліфікація", "Перемовини",
    "Пілотне випробування", "Укладення угоди",
    "Чекаємо оплати", "Активні клієнти", "Неактивні клієнти", "Архів",
]
DEFAULT_STAGE = "Новий клієнт"
STAGE_ARCHIVE = "Архів"
STAGE_ACTIVE = "Активні клієнти"
STAGE_PILOT = "Пілотне випробування"

# Імовірність закриття угоди за стадією (для прогнозу виручки).
STAGE_PROB = {
    "Новий клієнт": 0.10, "Перемовини": 0.30, "Пілотне випробування": 0.50,
    "Укладення угоди": 0.70, "Чекаємо оплати": 0.90, "Активні клієнти": 1.00,
    "Неактивні клієнти": 0.0, "Архів": 0.0,
}

# Валюта за замовчуванням — та сама, що лежала в картках до переїзду.
CURRENCY = "₴"

# ── ОБОВʼЯЗКОВЕ ПОЛЕ НА СТАДІЇ (крок після C1, 15.08.2026) ───────────────────
# ⭐⭐⭐ ЯКІСТЬ ДАНИХ ТРИМАЄТЬСЯ НА СТАДІЇ, А НЕ НА СУМЛІННОСТІ. Угода без суми в
# «Укладенні угоди» робить весь прогноз воронки порожнім числом: дашборд покаже
# нуль там, де насправді гроші. Це не «валідація форми» — це ворота: у стадію,
# яка щось ОБІЦЯЄ бізнесу, не пускаємо без того, на чому обіцянка тримається.
# ⛒ Словник ЗАКРИТИЙ і живе тут: правило, яке живе в екрані, обходиться першим же
# другим входом (телеграм, імпорт, автоматика) — урок «промпт — не ворота».
# ⭐⭐⭐ 585 (16.09.2026). ДРУГА ВИМОГА — ДОГОВІР. Слово Андрія 13.09.2026:
# «Жодна угода без договору, який причеплений до цієї угоди, не може вважатися
# успішно завершеною.» Це правило ЗАКРИТТЯ угоди, а не поле в картці, — тому
# воно лягає сюди, у ті самі ворота стадії, а не в екран і не в окремий сторож.
#
# 🩸 ЧОМУ ТРИ СТАДІЇ, А НЕ ОДНА. «Успішно завершена» в цій воронці — це не одна
# поділка, а три: угоду уклали, чекаємо оплати, клієнт активний. Поставити
# ворота лише на першу означало б лишити дірку завширшки з два кліки: стадію
# можна задати будь-яку, і угода перестрибнула б ворота, не торкнувшись їх.
STAGE_REQUIRES = {
    "Укладення угоди": ("amount", "contract"),
    "Чекаємо оплати": ("contract",),
    "Активні клієнти": ("contract",),
}
# ⛒ ВІДМОВА КАЖЕ, ЩО ЗРОБИТИ, А НЕ ЯК ЗВЕТЬСЯ ПОЛЕ. Суму ВКАЗУЮТЬ, договір
# ПРИЧІПЛЯЮТЬ — це різні дії, і людині треба почути свою. Один перелік із
# спільним дієсловом «вкажіть» зробив би з половини вимог нісенітницю.
FIELD_NAMES = {"amount": "вкажіть суму угоди (разову або щомісячну)",
               "contract": "причепіть до угоди договір"}

MAX_NAME = 200        # довша «назва» — це вже текст, а не назва угоди
MAX_NOTE = 2000


class DealError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def num(s) -> float:
    """Число з рядка суми ('150 000', '30000₴' → 150000.0). Порожнє → 0.

    ⚠ ОДИН ПИСАР АРИФМЕТИКИ СУМИ. Раніше це жило в `crm._num`; там воно лишається
    тонким викликом сюди — інакше дашборд і воронка рахували б гроші по-різному."""
    digits = re.sub(r"[^\d.]", "", str(s or "").replace(",", ""))
    try:
        return float(digits) if digits else 0.0
    except Exception:
        return 0.0


# ── Сховище ──────────────────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(DEALS_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("seq", 0)
    if not isinstance(d.get("deals"), dict):
        d["deals"] = {}
    return d


def _save(d: dict) -> None:
    """Атомарний запис: або старий файл цілий, або новий цілий. Половини не буває."""
    DEALS_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(DEALS_JSON, d)


def _new_id(d: dict) -> str:
    seq = int(d.get("seq") or 0) + 1
    while ("d%04d" % seq) in d["deals"]:
        seq += 1
    d["seq"] = seq
    return "d%04d" % seq


# ── Словники ─────────────────────────────────────────────────────────────────
def has_amount(row: dict) -> bool:
    """Чи названо в угоді хоч якісь гроші."""
    a = (row or {}).get("amount") or {}
    return bool(_s(a.get("one_time")) or _s(a.get("mrr")))


def _has_contract(row: dict) -> bool:
    """⛒ ВІДПОВІДЬ ПРО ДОГОВІР ДАЄ ТОЙ, ХТО ЙОГО ЗБЕРІГАЄ (`deal_documents`),
    а не цей файл. Імпорт ЛОКАЛЬНИЙ свідомо: документи знають про угоди, і
    зустрічний імпорт зверху замкнув би коло на завантаженні модулів.

    ⚠ FAIL-CLOSED: якщо сховище документів чомусь не відповідає, ворота
    вважають, що договору немає. «Не знаю» на замку означає «ні»."""
    did = _s((row or {}).get("id"))
    if not did:
        return False
    try:
        import deal_documents as _dd585
        return bool(_dd585.has_contract(did))
    except Exception:
        return False


def check_stage_ready(row: dict, stage: str) -> None:
    """Ворота стадії: чого бракує, щоб туди перейти. Відмова — СЛОВАМИ.

    ⚠ Судимо не «чи заповнена форма», а сам ЗАПИС угоди: у неї є кілька входів
    (екран, збірка, майбутній імпорт), і кожен мусить упертись в одні ворота."""
    need = STAGE_REQUIRES.get(_s(stage)) or ()
    missing = []
    for field in need:
        if field == "amount" and not has_amount(row):
            missing.append(FIELD_NAMES["amount"])
        if field == "contract" and not _has_contract(row):
            missing.append(FIELD_NAMES["contract"])
    if missing:
        raise DealError(
            "Щоб перевести угоду на стадію «%s», спершу %s. Угода без договору "
            "не вважається успішно завершеною, а воронка без суми рахує "
            "обіцянку порожнім числом." % (_s(stage), ", ".join(missing)))


def check_stage(stage) -> str:
    """Стадія зі ЗАКРИТОГО переліку — або відмова словами.

    ⚠ До переїзду `crm.set_stage` на невідомій стадії мовчки повертав `None`:
    людина натискала, нічого не відбувалось, і ніхто не казав чому. Тиха відмова —
    це вимкнені ворота."""
    st = _s(stage)
    if st not in STAGES:
        raise DealError("Невідома стадія «%s». Воронка знає лише: %s."
                        % (st, ", ".join(STAGES)))
    return st


def check_name(name) -> str:
    nm = _s(name)
    if not nm:
        raise DealError("Угода без назви не заводиться: назва — це те, що менеджер "
                        "бачить у воронці.")
    if len(nm) > MAX_NAME:
        raise DealError("Назва угоди задовга: %d знаків, а можна щонайбільше %d."
                        % (len(nm), MAX_NAME))
    return nm


def check_amount(amount) -> dict:
    """Суми угоди у сталій формі. Чужі ключі — відмова, а не тиха втрата."""
    src = dict(amount or {})
    out = {"one_time": "", "mrr": "", "currency": CURRENCY}
    for k, v in src.items():
        k = _s(k)
        if k not in out:
            raise DealError("Невідоме поле суми «%s». Угода знає: разова сума "
                            "(one_time), щомісячна (mrr), валюта (currency)." % k)
        out[k] = _s(v)
    out["currency"] = out["currency"] or CURRENCY
    return out


def check_next_action(text, date_str="") -> dict:
    """Наступна дія: текст + строк. Строк зберігаємо ЗАВЖДИ у вигляді РРРР-ММ-ДД.

    🩸 ЗНАЙДЕНО ЖИВИМИ ДАНИМИ (проба переїзду, 15.08.2026): у картці на диску
    лежить строк «11.08.2026» — Андрій писав його руками у ЛЮДСЬКОМУ вигляді.
    Стара перевірка протермінування (`date.fromisoformat`) таку дату НЕ читала
    ніколи — тобто протермінована дія мовчки не спалахувала. Це рівно той клас,
    що й «дата запису не читається» у стрічці подій (B3).
    ⛒ Тому ЛЮДСЬКУ форму приймаємо і ПЕРЕКЛАДАЄМО, а не відкидаємо; будь-яку
    іншу — відмова словами. Мовчки покласти нечитабельний строк не можна: він
    виглядав би як «строку немає»."""
    na = {"text": _s(text), "date": _s(date_str)}
    if not na["date"]:
        return na
    m = re.match(r"^(\d{2})\.(\d{2})\.(\d{4})$", na["date"])
    if m:
        na["date"] = "%s-%s-%s" % (m.group(3), m.group(2), m.group(1))
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", na["date"]):
        raise DealError("Строк наступної дії має бути у вигляді РРРР-ММ-ДД "
                        "(або ДД.ММ.РРРР), а не «%s»." % _s(date_str))
    from datetime import date as _d
    try:
        _d.fromisoformat(na["date"])
    except Exception:
        raise DealError("Такої дати не існує: «%s»." % _s(date_str))
    return na


# ── ПОСИЛАННЯ Й НАЗВА ────────────────────────────────────────────────────────
def ref(did) -> str:
    """Посилання на угоду для загального протоколу платформи."""
    d = _s(did)
    return entity.ref(entity.KIND_DEAL, d) if d else ""


def title(did) -> str:
    d = get(did)
    return _s(d.get("name")) or _s(did)


# ── Читання ──────────────────────────────────────────────────────────────────
def get(did) -> dict:
    return dict(_load()["deals"].get(_s(did)) or {})


def exists(did) -> bool:
    return _s(did) in _load()["deals"]


def _row(d: dict) -> dict:
    """Повна форма рядка — щоб екран не мусив знати, коли завели угоду."""
    row = dict(d or {})
    row.setdefault("id", "")
    row.setdefault("name", "")
    row["stage"] = _s(row.get("stage")) or DEFAULT_STAGE
    row["amount"] = check_amount(row.get("amount"))
    na = dict(row.get("next_action") or {})
    row["next_action"] = {"text": _s(na.get("text")), "date": _s(na.get("date"))}
    row["attention"] = int(row.get("attention") or 0)
    row["archived"] = bool(row.get("archived"))
    row.setdefault("note", "")
    row.setdefault("created", "")
    row.setdefault("updated", "")
    row.setdefault("source", "")
    return row


# ═══════════ ФІЛЬТР ВОРОНКИ ЗА ПОЛЕМ КАРТКИ (зміна 594, 16.09.2026) ════════
# ⛒ ЛІКУЄМО КЛАС, А НЕ «НАПРЯМ УГОДИ». 593 навчила картку питати напрям
# (продаж/закупівля) і категорію, але воронка про це не знала: поле
# заповнюється, а подивитись «лише закупівлі» неможливо. Фільтр зроблено по
# БУДЬ-ЯКОМУ оголошеному полю-списку картки угоди — завтрашній «регіон» або
# «тип техніки» фільтруватиметься без жодного рядка коду.
# ⛒ ПЕРЕЛІК ФІЛЬТРІВ РАХУЄ СЕРВЕР, а не екран: зашитий на екрані перемикач
# «продаж/закупівля» не побачив би поля, заведеного вчора.
def filters() -> list:
    """Поля, за якими воронку можна звузити, з їхніми значеннями."""
    try:
        import card_fields as _cf
        out = []
        for f in _cf.layout(entity.KIND_DEAL):
            if _s(f.get("type")) != _cf.T_LIST:
                continue
            ch = list(f.get("choices") or [])
            if _s(f.get(_cf.F_PARENT)):
                # ⛒ У залежного списку власного переліку немає: збираємо всі
                # значення, які він узагалі вміє приймати, — інакше за
                # категорією фільтрувати було б нічим.
                seen = []
                for vals in (f.get(_cf.F_CHOICES_BY) or {}).values():
                    for v in (vals or []):
                        if v not in seen:
                            seen.append(v)
                ch = seen
            out.append({"id": _s(f.get("id")), "name": _s(f.get("name")),
                        "choices": ch})
        return out
    except Exception:
        return []


def check_filter(field, value) -> tuple:
    """(поле, значення) або ВІДМОВА СЛОВАМИ.

    ⛒ Порожня воронка замість відмови — найгірша з відповідей: людина читає її
    як «угод немає», а насправді помилка в самому питанні."""
    fid, val = _s(field), _s(value)
    if not fid and not val:
        return "", ""
    import card_fields as _cf
    if not fid:
        raise DealError("Сказано, ЩО шукати, але не сказано, у якому полі.")
    f = _cf.get(fid)
    if not f:
        raise DealError("Поля %s немає в будові карток." % fid)
    if _s(f.get("card")) != entity.KIND_DEAL:
        raise DealError("«%s» лежить у картці «%s», а не в картці угоди."
                        % (_s(f.get("name")),
                           entity.KIND_NAMES.get(_s(f.get("card")), "?")))
    if _s(f.get("type")) != _cf.T_LIST:
        raise DealError("Воронку звужують за полем-списком, а «%s» — це «%s»."
                        % (_s(f.get("name")),
                           _cf.TYPE_NAMES.get(_s(f.get("type")), "?")))
    if not val:
        return fid, ""
    allowed = []
    for row in filters():
        if row["id"] == fid:
            allowed = row["choices"]
            break
    if val not in allowed:
        raise DealError("Поле «%s» не має значення «%s». Є: %s."
                        % (_s(f.get("name")), val,
                           ", ".join(allowed) or "(перелік порожній)"))
    return fid, val


def _field_values(fid) -> dict:
    """{номер угоди: значення поля} — за одне читання реєстру значень."""
    out = {}
    try:
        import card_values as _cv
        for ref_, val in _cv.values_of_field(fid).items():
            if entity.kind_of(ref_) == entity.KIND_DEAL:
                out[entity.ident_of(ref_)] = val
    except Exception:
        return {}
    return out


def all_deals(archived=None, party: str = "", sift: bool = True,
              field: str = "", value: str = "") -> list:
    """Усі угоди. `archived=None` — усі, True/False — лише архівні/живі.
    `party` — лише угоди цього контрагента. Свіжіші згори."""
    pid = _s(party)
    keep = set(deal_ids_of_party(pid)) if pid else None
    out = []
    for did, d in _load()["deals"].items():
        row = _row(d)
        row["id"] = row["id"] or did
        if archived is not None and bool(row["archived"]) != bool(archived):
            continue
        if keep is not None and did not in keep:
            continue
        out.append(row)
    out.sort(key=lambda x: _s(x.get("created")), reverse=True)
    # ⭐⭐⭐ 589: СИТО ВИДИМОСТІ — у читача переліку. Через нього йдуть канбан,
    # воронка, плитки в картці контрагента і та сама дошка, яку ЗАПИС повертає
    # у відповідь. Угода судиться господарем свого контрагента.
    # ⭐ 594: звуження за полем картки — ДО сита видимості: фільтр лише
    # звужує і не має права показати те, чого людині не видно.
    fid, val = _s(field), _s(value)
    if fid:
        got = _field_values(fid)
        keep = []
        for row in out:
            have = got.get(_s(row.get("id")))
            have = have if isinstance(have, list) else ([have] if have else [])
            if val and val in [_s(x) for x in have]:
                keep.append(row)
            elif not val and have:
                keep.append(row)
        out = keep
    # ⭐ 590: `sift=False` просить ПОВНИЙ перелік — його бере лише той, хто
    # сам притемнить чужі рядки (картка контрагента). Ховати там не можна:
    # перелік угод клієнта — це факт стосунків компанії з ним.
    if not sift:
        return out
    try:
        import entity_scope as _vs589
        return _vs589.sift(_vs589.KIND_DEAL, out)
    except Exception:
        return out


def count() -> dict:
    d = _load()["deals"]
    live = sum(1 for x in d.values() if not x.get("archived"))
    return {"all": len(d), "live": live, "archived": len(d) - live}


# ── КЛІЄНТ УГОДИ Й ЇЇ ЛЮДИ — ЧЕРЕЗ РЕЄСТР ЗВʼЯЗКІВ ───────────────────────────
# ⭐⭐⭐ ДРУГОГО СХОВИЩА НЕ ЗʼЯВЛЯЄТЬСЯ. «Угода з компанією» і «контактна особа
# угоди» — це факти про ДВІ сутності, а не властивість жодної з них (закон B2).
# Тому вони лежать у реєстрі звʼязків, а картка контакту показує свої угоди
# ПОХІДНО — рівно як «Контактні особи» в B5.
# ⚠ Реєстр імпортуємо ВСЕРЕДИНІ функцій: `links` питає `entity`, `entity` питає
# `deals`, і верхній імпорт закільцював би трійку.
def _links():
    import links
    return links


def client_of(did) -> str:
    """Номер контрагента-клієнта цієї угоди («» — звʼязку немає)."""
    me = ref(did)
    if not me:
        return ""
    try:
        L = _links()
        for row in L.outgoing(me):
            if _s(row.get("rel")) == L.REL_DEAL_WITH:
                return entity.ident_of(row.get("ref"))
    except Exception:
        pass
    return ""


# ─────────────────── ХТО ВЕДЕ ЦЮ УГОДУ (зміна 590, 16.09.2026) ─────────────
# ⭐⭐⭐ ВИПАДОК АНДРІЯ. Контрагента завів і веде Петренко. Той самий клієнт
# купує товар іншого напряму — і ту угоду веде Хоменко. Досі відповідального в
# угоди не було ЗОВСІМ, і видимість 589 судила угоду господарем компанії: Хоменко
# не міг ні завести угоду, ні відкрити її, а в базі зʼявився б ДУБЛЬ компанії.
#
# ⛒ ДРУГЕ ПОЛЕ — НЕ ДУБЛЬ ПЕРШОГО. «Хто веде компанію» і «хто веде цю угоду» —
# два різні питання: компанія живе роками й має одного господаря, угода живе
# тижнями й належить своєму напряму. Той самий клієнт буває і покупцем, і
# постачальником, і закупівельні угоди веде третя людина.
#
# ⛒ СХОВИЩЕ ТЕ САМЕ. Відповідальний живе в реєстрі звʼязків (`managed_by`), як і
# в контрагента: другого місця для однієї й тієї ж відповіді не заводимо.
def manager_ref(did) -> str:
    """Посилання на людину, яка веде цю угоду (або "").

    ⚠ Загорнуто: зламаний реєстр не сміє повалити картку угоди."""
    try:
        L = _links()
        me = ref(did)
        if not me:
            return ""
        for row in L.outgoing(me):
            if _s(row.get("rel")) == L.REL_MANAGED_BY:
                return _s(row.get("ref"))
    except Exception:
        return ""
    return ""


def manager_of(did) -> str:
    """Номер працівника, який веде угоду («» — власного відповідального немає).

    ⛒ ПОРОЖНЬО — ЦЕ НЕ «НІЧИЯ». Угоди, заведені до 590, власного відповідального
    не мають і матимуть його лише тоді, коли поставлять руками; доти вони
    судяться відповідальним СВОГО КОНТРАГЕНТА (`entity_scope`). Інакше жива база
    клієнта одного ранку стала б нічиєю."""
    row = manager_ref(did)
    return entity.ident_of(row) if row else ""


def set_manager(did, emp_id, by: str = "") -> dict:
    """Призначити відповідального за угоду або зняти його (порожньо = зняти).

    ⛒ РІВНО ОДИН: старий звʼязок ПРИБИРАЄМО, а не додаємо другий."""
    key = _s(did)
    if not exists(key):
        raise DealError("Угоди %s немає в реєстрі." % (key or "«»"))
    L = _links()
    me = ref(key)
    old = manager_of(key)
    new = _s(emp_id)
    if new:
        import taskdesk_people as _people
        rec = _people.employee(new)
        if not rec:
            raise DealError("Працівника %s немає в оргструктурі." % new)
        if rec.get("dismissed"):
            raise DealError(
                "%s звільнений — угоду йому не віддають. Виберіть чинного "
                "працівника." % (_s(rec.get("full_name")) or new))
    if old == new:
        return {"deal": key, "manager": new}
    if old:
        try:
            L.remove(me, L.REL_MANAGED_BY, entity.ref(entity.KIND_PERSON, old),
                     by=_s(by))
        except Exception:
            pass
    if new:
        L.add(me, L.REL_MANAGED_BY, entity.ref(entity.KIND_PERSON, new),
              by=_s(by))
    _to_protocol(protocol.A_DEAL_CHANGED, key,
                 "відповідальний: %s" % (entity.title(
                     entity.ref(entity.KIND_PERSON, new)) if new else "(знято)"))
    return {"deal": key, "manager": new}


def manager_name(did) -> str:
    """Імʼя того, хто веде угоду, — словами й одним писарем."""
    row = manager_ref(did)
    return entity.title(row) if row else ""


def people_of(did) -> list:
    """Контактні особи угоди: [{party_id, note}] (їх буває скільки треба)."""
    me = ref(did)
    if not me:
        return []
    out = []
    try:
        L = _links()
        for row in L.outgoing(me):
            if _s(row.get("rel")) == L.REL_DEAL_PERSON:
                out.append({"party_id": entity.ident_of(row.get("ref")),
                            "ref": _s(row.get("ref")),
                            "note": _s(row.get("note"))})
    except Exception:
        return []
    return out


def deal_ids_of_party(pid) -> list:
    """Номери угод цього контрагента (він — КЛІЄНТ угоди)."""
    p = _s(pid)
    if not p:
        return []
    out = []
    try:
        L = _links()
        me = entity.ref(entity.KIND_PARTY, p)
        for row in L.incoming(me):
            if _s(row.get("rel")) == L.REL_DEAL_WITH:
                out.append(entity.ident_of(row.get("ref")))
    except Exception:
        return []
    return out


def deals_of_party(pid, archived=None, sift: bool = True) -> list:
    """Угоди контрагента у повній формі рядка."""
    return all_deals(archived=archived, party=pid, sift=sift)


def live_deals_of_party(pid) -> list:
    """⭐ ГОЛОВНЕ ПИТАННЯ Р5: чи є в цього контакта РІВНО ОДНА жива угода.

    Технічна дія (збірка пакета) сміє рухати гроші у воронці лише тоді, коли
    іншого адресата не існує. При нулі або кількох — не вгадуємо."""
    return all_deals(archived=False, party=pid)


# ── ЗАГАЛЬНИЙ ПРОТОКОЛ ───────────────────────────────────────────────────────
# ЗАКОН (успадкований від `parties`, зміна 171): ХТО ЗБЕРІГАЄ — ТОЙ І ЗВІТУЄ.
# Рядок пише не кожна письмова функція окремо (одну неминуче забудуть), а ТРИ
# точки, через які вони всі й так проходять: `create`, `_mutate`, `delete`.
# ⚠ ЩО САМЕ ЗМІНИЛОСЬ, називає ВИКЛИКАЧ (`what`) — дефолту немає свідомо:
# мовчазне «щось змінилось» дало б журнал, який нічого не пояснює.
def _to_protocol(action: str, did: str, what: str, source: str = "") -> None:
    """Дописати рядок у загальний журнал платформи.

    ⭐ КЛІЄНТ УГОДИ ЙДЕ В `about` — саме цим «покажи все про Каспера» починає
    бачити рух його угод, не читаючи двох журналів.
    ⚠ Ніколи не валить роботу: реєстр угод — актив компанії, журнал — його тінь."""
    try:
        me = ref(did)
        about = []
        pid = client_of(did)
        if pid:
            about.append(entity.ref(entity.KIND_PARTY, pid))
        protocol.write(action, me, about=about, note=what, source=source)
    except Exception:
        pass


# ── Запис ────────────────────────────────────────────────────────────────────
@one_writer.guard("DEALS_JSON")
def create(name, party, stage: str = DEFAULT_STAGE, amount=None,
           next_action=None, note: str = "", source: str = "manual",
           by: str = "") -> dict:
    """Завести угоду. КЛІЄНТ ОБОВʼЯЗКОВИЙ.

    ⛒ «Угода без клієнта — не угода» (рішення Р2 проєкту C1). Тому клієнт не
    «поле, яке можна дозаповнити потім», а умова народження. Порядок такий:
    спершу перевіряємо ВСЕ (включно з тим, чи можна завести звʼязок), і лише
    потім пишемо. Угода-сирота без клієнта не зʼявляється навіть на мить.

    ⚠ ЯКЩО ЗВʼЯЗОК УСЕ Ж НЕ ЛІГ — угода прибирається, а відмова летить далі.
    Половини не буває: саме на «щось записалось, а щось ні» ми й горіли."""
    nm = check_name(name)
    st = check_stage(stage)
    amt = check_amount(amount)
    na = check_next_action((next_action or {}).get("text") if isinstance(next_action, dict) else "",
                           (next_action or {}).get("date") if isinstance(next_action, dict) else "")
    pid = _s(party)
    if not pid:
        raise DealError("Угода заводиться лише з клієнтом: скажіть, з ким вона.")
    party_ref = entity.ref(entity.KIND_PARTY, pid)
    if not entity.exists(party_ref):
        raise DealError("Контрагента %s немає в довіднику — угода вела б у порожнечу."
                        % pid)
    if len(_s(note)) > MAX_NOTE:
        raise DealError("Нотатка угоди задовга: %d знаків, межа %d."
                        % (len(_s(note)), MAX_NOTE))

    # Ворота стадії діють і на народженні: інакше «Укладення угоди» без суми
    # заводилось би в обхід — тим самим другим входом, від якого ми лікуємось.
    check_stage_ready({"amount": amt}, st)
    d = _load()
    did = _new_id(d)
    now = clock.now()
    d["deals"][did] = {
        "id": did,
        "name": nm,
        "stage": st,
        "amount": amt,
        "next_action": na,
        "attention": 0,
        "archived": (st == STAGE_ARCHIVE),
        "note": _s(note),
        "source": _s(source) or "manual",
        "created": now,
        "updated": now,
    }
    _save(d)

    try:
        L = _links()
        L.add(ref(did), L.REL_DEAL_WITH, party_ref, by=by)
    except Exception as ex:
        # Відкіт: угода без клієнта не має права лишитись на диску.
        back = _load()
        back["deals"].pop(did, None)
        _save(back)
        raise DealError("Угоду не заведено: %s" % ex)

    _to_protocol(protocol.A_DEAL_CREATED, did,
                 "«%s» · %s · клієнт: %s · джерело: %s"
                 % (nm, st, entity.title(party_ref), _s(source) or "manual"))
    return _row(d["deals"][did])


@one_writer.guard("DEALS_JSON")
def _mutate(did, patch_fn, what: str, action: str = "", source: str = "") -> dict:
    """ОДНА точка запису на весь реєстр угод: хто зберігає — той і звітує."""
    key = _s(did)
    d = _load()
    row = d["deals"].get(key)
    if not row:
        raise DealError("Угоди %s немає в реєстрі." % (key or "«»"))
    patch_fn(row)
    row["updated"] = clock.now()
    d["deals"][key] = row
    _save(d)
    _to_protocol(_s(action) or protocol.A_DEAL_CHANGED, key, what, source=source)
    return _row(row)


def set_name(did, name) -> dict:
    """⭐ Назва міняється — НОМЕР НІ. Саме заради цього угода й стала сутністю:
    після перейменування канал оновлень пілота цього навіть не помітить."""
    nm = check_name(name)
    old = title(did)
    return _mutate(did, lambda r: r.__setitem__("name", nm),
                   "назву змінено: «%s» → «%s»" % (old or "?", nm))


def set_stage(did, stage, source: str = "") -> dict:
    """Перевести угоду на стадію воронки. Архів і стадія тримаються синхронно."""
    st = check_stage(stage)
    cur = get(did)
    if not cur:
        raise DealError("Угоди %s немає в реєстрі." % (_s(did) or "«»"))
    check_stage_ready(_row(cur), st)
    prev = _s(cur.get("stage")) or DEFAULT_STAGE

    def _p(r):
        r["stage"] = st
        r["archived"] = (st == STAGE_ARCHIVE)

    return _mutate(did, _p, "%s → %s" % (prev, st),
                   action=protocol.A_DEAL_STAGE, source=source)


def set_amount(did, amount) -> dict:
    """Оновити суми (те, що приходить, — те й міняється; решта лишається)."""
    cur = check_amount(get(did).get("amount"))
    src = dict(amount or {})
    # ⚠ СПЕРШУ СУДИМО ВХІД, а вже потім міняємо. Перебирати лише ВІДОМІ ключі
    # означало б мовчки проковтнути чуже поле: людина вписала «комісію», нічого
    # не сталось, і ніхто не сказав чому (спіймано власним чеком 15.08).
    check_amount({k: v for k, v in src.items() if v is not None})
    for k in ("one_time", "mrr", "currency"):
        if k in src and src[k] is not None:
            cur[k] = _s(src[k])
    cur = check_amount(cur)
    return _mutate(did, lambda r: r.__setitem__("amount", cur),
                   "суми: разова %s · щомісяця %s %s"
                   % (cur["one_time"] or "—", cur["mrr"] or "—", cur["currency"]))


def set_next_action(did, text, date_str: str = "") -> dict:
    na = check_next_action(text, date_str)
    return _mutate(did, lambda r: r.__setitem__("next_action", na),
                   "наступна дія: %s%s" % (na["text"] or "— знято —",
                                           (" · до " + na["date"]) if na["date"] else ""))


def mark_action_done(did) -> dict:
    """«Дію виконано»: гасить бейдж уваги і чистить саму дію одним кроком."""
    cur = get(did)
    txt = _s((cur.get("next_action") or {}).get("text"))

    def _p(r):
        r["next_action"] = {"text": "", "date": ""}
        r["attention"] = 0

    return _mutate(did, _p, "дію виконано: %s" % (txt or "без опису"))


def set_attention(did, value=None, inc: int = 0) -> dict:
    """Бейдж «потребує уваги». ⭐ Він лишається на УГОДІ (заміна Р4 за словом
    Андрія 15.08): увага — про роботу продавця по ЦІЙ угоді."""
    cur = int(get(did).get("attention") or 0)
    new = int(value) if value is not None else (cur + int(inc))
    new = max(0, new)

    def _p(r):
        r["attention"] = new

    return _mutate(did, _p, "увага: %d" % new)


def set_archived(did, flag: bool = True) -> dict:
    """В архів (угода не відбулась / завершена) або назад у роботу."""
    def _p(r):
        r["archived"] = bool(flag)
        r["stage"] = STAGE_ARCHIVE if flag else STAGE_ACTIVE

    return _mutate(did, _p, "перенесено в архів" if flag else "повернуто з архіву",
                   action=protocol.A_DEAL_STAGE)


def set_note(did, note) -> dict:
    text = _s(note)
    if len(text) > MAX_NOTE:
        raise DealError("Нотатка угоди задовга: %d знаків, межа %d."
                        % (len(text), MAX_NOTE))
    return _mutate(did, lambda r: r.__setitem__("note", text), "нотатку змінено")


def set_client(did, pid, by: str = "") -> dict:
    """Змінити компанію-клієнта угоди. Рівно одна — тому старий звʼязок ПРИБИРАЄМО,
    а не додаємо другий (інакше «угода з двома клієнтами» = дві угоди)."""
    key = _s(did)
    if not exists(key):
        raise DealError("Угоди %s немає в реєстрі." % (key or "«»"))
    new_pid = _s(pid)
    party_ref = entity.ref(entity.KIND_PARTY, new_pid)
    if not entity.exists(party_ref):
        raise DealError("Контрагента %s немає в довіднику." % (new_pid or "«»"))
    old = client_of(key)
    if old == new_pid:
        return _row(get(key))
    L = _links()
    me = ref(key)
    if old:
        L.remove(me, L.REL_DEAL_WITH, entity.ref(entity.KIND_PARTY, old), by=by)
    L.add(me, L.REL_DEAL_WITH, party_ref, by=by)
    return _mutate(key, lambda r: None,
                   "клієнта змінено: %s → %s"
                   % (entity.title(entity.ref(entity.KIND_PARTY, old)) if old else "—",
                      entity.title(party_ref)))


def add_person(did, pid, note: str = "", by: str = "") -> dict:
    """Додати контактну особу угоди (їх буває скільки треба — правка C3 v2)."""
    key = _s(did)
    if not exists(key):
        raise DealError("Угоди %s немає в реєстрі." % (key or "«»"))
    L = _links()
    L.add(ref(key), L.REL_DEAL_PERSON, entity.ref(entity.KIND_PARTY, _s(pid)),
          by=by, note=note)
    return _row(get(key))


def remove_person(did, pid, by: str = "") -> dict:
    key = _s(did)
    L = _links()
    L.remove(ref(key), L.REL_DEAL_PERSON, entity.ref(entity.KIND_PARTY, _s(pid)), by=by)
    return _row(get(key))


@one_writer.guard("DEALS_JSON")
def delete(did, by: str = "") -> bool:
    """Прибрати угоду. Видалення НЕ вгадує форму — тільки за номером."""
    key = _s(did)
    d = _load()
    if key not in d["deals"]:
        return False
    gone = _s((d["deals"].get(key) or {}).get("name"))
    # Клієнта питаємо ДО видалення — після нього про нього нема кого спитати.
    _to_protocol(protocol.A_DEAL_DELETED, key, "«%s»" % (gone or "без назви"))
    d["deals"].pop(key)
    _save(d)
    # ⭐⭐⭐ ВИДАЛЕНА СУТНІСТЬ НЕ ЛИШАЄ ЖИВИХ ЗВʼЯЗКІВ (закон B2). Дані від цього
    # не зникають: кожне прибирання лягає в протокол окремим рядком.
    me = entity.ref(entity.KIND_DEAL, key)
    try:
        _links().forget(me, by=by)
    except Exception as ex:
        protocol.write(protocol.A_LINK_REMOVED, me,
                       outcome="%s: %s" % (protocol.OUT_FAILED, ex),
                       note="звʼязки прибраної угоди лишились у реєстрі")
    return True


# ── ЩО ПОТРЕБУЄ УВАГИ ────────────────────────────────────────────────────────
def _is_overdue(date_str) -> bool:
    from datetime import date as _date
    try:
        return bool(date_str) and _date.fromisoformat(_s(date_str)[:10]) < _date.today()
    except Exception:
        return False


def due_reason(row: dict) -> str:
    """Чому угода потребує уваги (порожньо = не потребує). Лише живі.

    ⚠ ЛІЦЕНЗІЯ ТУТ НЕ ПИТАЄТЬСЯ. Її строк — факт КАРТКИ КЛІЄНТА (техніка), і
    підмішувати його в продажну воронку означало б повернути рівно те злиття,
    яке C1 і розділяє. Хто хоче бачити ліцензію — дивиться картку клієнта."""
    if row.get("archived"):
        return ""
    na = row.get("next_action") or {}
    if _is_overdue(na.get("date")):
        return "Протермінована дія: " + _s(na.get("text"))
    return ""


# ── ВОРОНКА, ДАШБОРД, ПЛИТКА — ПО УГОДАХ ─────────────────────────────────────
# ⭐⭐⭐ Рішення Р8 проєкту C1: воронка рахує УГОДИ, а не картки. Різниця не
# косметична: до переїзду у воронці лежали 23 картки, з них 11 — тестувальники
# чужого продукту, які нічого не купували. `crm.board()` / `crm.pipeline()`
# лишаються тими самими іменами, але стають тонкими викликами сюди.
def managers(dids=()) -> dict:
    """Хто веде кожну з угод — за ОДНЕ читання реєстру звʼязків (590).

    ⛒ Поіменне питання про кожну угоду перетворило б відкриття воронки на
    сотню читань файла. Той самий прийом, що й `parties.managers`."""
    want = set(_s(x) for x in (dids or ()))
    out = {}
    try:
        L = _links()
        rows = L.all_links()
    except Exception:
        return out
    for row in rows or ():
        if _s(row.get("rel")) != L.REL_MANAGED_BY:
            continue
        frm = _s(row.get("from"))
        if entity.kind_of(frm) != entity.KIND_DEAL:
            continue
        did = entity.ident_of(frm)
        if want and did not in want:
            continue
        out[did] = _s(row.get("to") or row.get("ref"))
    return out


def _list_fields_of(did) -> dict:
    """Значення полів-списків цієї угоди: {номер поля: значення}."""
    out = {}
    try:
        import card_fields as _cf
        import card_values as _cv
        me = ref(did)
        for f in _cf.layout(entity.KIND_DEAL):
            if _s(f.get("type")) != _cf.T_LIST:
                continue
            got = _cv.value(me, f["id"])
            if got:
                out[_s(f["id"])] = got
    except Exception:
        return {}
    return out


def _tile(row: dict, mgr_ref: str = None, fields: dict = None) -> dict:
    """Плитка угоди для екрана. ⭐ Ключ плитки — НОМЕР УГОДИ, а не назва клієнта.

    ⭐ 590: плитка КАЖЕ, ХТО ВЕДЕ УГОДУ. Керівник мусить бачити це в переліку, а
    не відкриваючи кожну картку; і саме цей підпис відрізняє «мою» угоду від
    угоди колеги з тим самим клієнтом."""
    pid = client_of(row.get("id"))
    mref = manager_ref(row.get("id")) if mgr_ref is None else _s(mgr_ref)
    amt = row.get("amount") or {}
    na = row.get("next_action") or {}
    tile = {
        "id": _s(row.get("id")),
        "ref": ref(row.get("id")),
        "href": entity.screen(ref(row.get("id"))),
        "name": _s(row.get("name")),
        "stage": _s(row.get("stage")) or DEFAULT_STAGE,
        "party_id": pid,
        "client": entity.title(entity.ref(entity.KIND_PARTY, pid)) if pid else "",
        "client_href": entity.screen(entity.ref(entity.KIND_PARTY, pid)) if pid else "",
        "one_time": _s(amt.get("one_time")),
        "mrr": _s(amt.get("mrr")),
        "currency": _s(amt.get("currency")) or CURRENCY,
        "next_action": _s(na.get("text")),
        "next_date": _s(na.get("date")),
        "attention": int(row.get("attention") or 0),
        "archived": bool(row.get("archived")),
        "due": bool(due_reason(row)),
        "updated": _s(row.get("updated")),
        "manager": entity.ident_of(mref) if mref else "",
        "manager_name": entity.title(mref) if mref else "",
        # ⭐ 594: ПЛИТКА КАЖЕ, ЧОГО ВОНА. Напрям угоди видно, не відкриваючи
        # картку, — інакше відфільтрований канбан і повний виглядали б однаково.
        "fields": (_list_fields_of(row.get("id")) if fields is None
                   else dict(fields or {})),
    }
    # ⭐⭐⭐ 592: ГРОШІ — ОКРЕМА ВІСЬ, ВУЖЧА ЗА ВИДИМІСТЬ. Колега по підрозділу
    # мусить бачити, що угода Є (щоб не лізти до того самого клієнта наосліп), і
    # не мусить бачити, СКІЛЬКИ в ній. Ховаємо тут, бо це один писар форми
    # плитки: і канбан, і картка, і плитки в картці контрагента йдуть через нього.
    try:
        import entity_scope as _vs592
        return _vs592.hide_money([tile], ("one_time", "mrr"),
                                 did=_s(row.get("id")))[0]
    except Exception:
        return tile


def tiles_of_party(pid) -> list:
    """⭐ ОДИН ПИСАР ПЕРЕЛІКУ УГОД КОНТРАГЕНТА для будь-якого екрана.

    🩸 Знайдено читанням коду 15.08.2026: картка контакта брала цей перелік із
    КАРТКИ КЛІЄНТА (`crm/clients.json`). Контакт без картки-ліцензії — а це кожна
    контактна особа після B5 — показував би «угод немає», МАЮЧИ їх. Порожній
    перелік замість правди читається людиною як факт."""
    rows = deals_of_party(pid, sift=False)
    mgrs = managers([r.get("id") for r in rows])
    tiles = [_tile(r, mgrs.get(_s(r.get("id")), "")) for r in rows]
    # ⭐⭐⭐ 590: ПЕРЕЛІК ПОВНИЙ, ЧУЖІ РЯДКИ ПРИТЕМНЕНІ. Ховати чужу угоду тут
    # означало б брехати про стосунки з клієнтом: менеджер не знав би, що з
    # цією компанією вже працює колега по іншому напряму, і поліз би туди
    # наосліп. Видно назву, стадію й ХТО ВЕДЕ; грошей і наступної дії — ні.
    try:
        import entity_scope as _vs590
        return _vs590.redact(_vs590.KIND_DEAL, tiles, keep=(
            "ref", "href", "name", "stage", "party_id", "client", "client_href",
            "manager", "manager_name", "archived", "updated"))
    except Exception:
        return tiles


def board(field: str = "", value: str = "") -> dict:
    """Канбан-зріз по угодах: стадії + угоди кожної стадії + лічильники."""
    by_stage = {s: [] for s in STAGES}
    counts = {s: 0 for s in STAGES}
    attention = {s: 0 for s in STAGES}
    rows = all_deals(field=field, value=value)
    rows.sort(key=lambda r: _s(r.get("name")).lower())
    mgrs = managers([r.get("id") for r in rows])
    for row in rows:
        st = _s(row.get("stage")) or DEFAULT_STAGE
        if st not in by_stage:
            st = DEFAULT_STAGE
        tile = _tile(row, mgrs.get(_s(row.get("id")), ""))
        tile["stage"] = st
        by_stage[st].append(tile)
        counts[st] += 1
        attention[st] += int(row.get("attention") or 0)
    return {"stages": STAGES, "by_stage": by_stage, "counts": counts,
            "attention": attention}


def count_filtered(field: str = "", value: str = "") -> dict:
    """Лічильники того самого зрізу, що й дошка: одне питання — одна відповідь.

    ⛒ Окремий лічильник, який рахує ВСЮ базу, поруч із відфільтрованою дошкою
    брехав би людині просто в очі: «угод 40», а видно чотири."""
    rows = all_deals(field=field, value=value)
    live = sum(1 for r in rows if not r.get("archived"))
    return {"all": len(rows), "live": live, "archived": len(rows) - live}


def pipeline(field: str = "", value: str = "") -> dict:
    """Зведення воронки для дашборда. Рахуємо лише ЖИВІ угоди (не архів).
    Прогноз = сума × імовірність стадії."""
    live = all_deals(archived=False, field=field, value=value)
    # ⛒ 592: ВОРОНКА — ЦЕ ТЕЖ ГРОШІ. Сховати суму в картці й лишити її в
    # прогнозі означало б не сховати нічого: різниця двох прогнонів назвала б
    # чужу суму з точністю до гривні.
    try:
        import entity_scope as _vs592p
        live = _vs592p.hide_money(live, ("amount",))
    except Exception:
        pass
    amt = lambda r, k: num((r.get("amount") or {}).get(k))
    prob = lambda r: STAGE_PROB.get(_s(r.get("stage")), 0)
    sum_one = sum(amt(r, "one_time") for r in live)
    sum_mrr = sum(amt(r, "mrr") for r in live)
    w_one = sum(amt(r, "one_time") * prob(r) for r in live)
    w_mrr = sum(amt(r, "mrr") * prob(r) for r in live)
    by_stage_val = {s: {"count": 0, "one_time": 0.0, "mrr": 0.0} for s in STAGES}
    for r in live:
        s = _s(r.get("stage")) or DEFAULT_STAGE
        if s not in by_stage_val:
            s = DEFAULT_STAGE
        by_stage_val[s]["count"] += 1
        by_stage_val[s]["one_time"] += amt(r, "one_time")
        by_stage_val[s]["mrr"] += amt(r, "mrr")
    due = []
    for r in sorted(live, key=lambda x: _s(x.get("name")).lower()):
        reason = due_reason(r)
        att = int(r.get("attention") or 0)
        if reason or att:
            pid = client_of(r.get("id"))
            due.append({
                "deal": _s(r.get("id")),
                "name": _s(r.get("name")),
                "href": entity.screen(ref(r.get("id"))),
                # ⛒ 442: ТЕ САМЕ, ЩО У ВОРОНЦІ, ЗВЕТЬСЯ ТАК САМО. Тут лежить
                # назва КОНТРАГЕНТА -- це товар. Слово `customer` лишається
                # за НАШОЮ ліцензійною карткою, інакше суддя кухонних полів
                # зріже клієнтові потрібне разом із чужим.
                "client": entity.title(entity.ref(entity.KIND_PARTY, pid)) if pid else "",
                "stage": _s(r.get("stage")) or DEFAULT_STAGE,
                "reason": reason or "Позначено вручну",
                "attention": att,
            })
    # ⭐⭐⭐ 431: ЧИСЛО, ЯКЕ НЕ МОЖЕ БУТИ ПРАВИЛЬНИМ, НЕ ВИДАЄТЬСЯ.
    #
    # 🩸 Доти зведення складало гривні з доларами в ОДНЕ число й підписувало
    # його валютою ПЕРШОЇ-ЛІПШОЇ живої угоди. Поки сум немає — не видно;
    # щойно в базі стають дві угоди в різних валютах, плитка починає брехати,
    # і саме тією брехнею, яку людина не має шансу помітити.
    #
    # Тому: рахуємо ПО КОЖНІЙ валюті окремо, і якщо грошові валюти не одна —
    # спільну суму не віддаємо ЗОВСІМ (None), а не показуємо «майже правду».
    by_cur = {}
    for r in live:
        c = _s((r.get("amount") or {}).get("currency")) or CURRENCY
        slot = by_cur.setdefault(c, {"one_time": 0.0, "mrr": 0.0, "deals": 0})
        slot["one_time"] += amt(r, "one_time")
        slot["mrr"] += amt(r, "mrr")
        slot["deals"] += 1
    with_money = sorted(c for c, v in by_cur.items() if v["one_time"] or v["mrr"])
    mixed = len(with_money) > 1
    by_currency = {c: {"one_time": round(v["one_time"]), "mrr": round(v["mrr"]),
                       "deals": v["deals"]}
                   for c, v in sorted(by_cur.items())}
    # Коли грошей немає ЗОВСІМ, валюту не «вгадуємо» з першої-ліпшої угоди:
    # беремо валюту платформи. Інакше підпис «0 $» стояв би над базою,
    # де майже всі угоди в гривні, — дрібна, але щоденна неправда.
    cur = with_money[0] if with_money else CURRENCY
    return {
        "deals": len(live),
        "clients": len({client_of(r.get("id")) for r in live if client_of(r.get("id"))}),
        "currency": "" if mixed else cur,
        "sum_one_time": None if mixed else round(sum_one),
        "sum_mrr": None if mixed else round(sum_mrr),
        "forecast_one_time": None if mixed else round(w_one),
        "forecast_mrr": None if mixed else round(w_mrr),
        "by_currency": by_currency,
        "mixed_currency": mixed,
        "by_stage_value": by_stage_val,
        "due": due, "due_count": len(due),
        "stages": STAGES,
    }


# ── КАРТКА УГОДИ ДЛЯ ЕКРАНА ──────────────────────────────────────────────────
def card(did) -> dict:
    """Усе, що екран показує в картці угоди, — ОДНИМ читанням.

    ⭐ ЛІЦЕНЗІЯ ПРИЇЖДЖАЄ ЧИТАЧЕМ, А НЕ ДРУГИМ СХОВИЩЕМ (рішення Р9): блок
    «Ліцензія та оновлення» бере факти з `crm/clients.json` за номером
    контрагента. Угода ліцензію НЕ зберігає і НЕ править."""
    key = _s(did)
    row = get(key)
    if not row:
        return None
    out = _row(row)
    out["id"] = out["id"] or key
    out["ref"] = ref(key)
    # ⛒ Причину «потребує дії» рахуємо ДО зведення форми: вона читає СХОВИЩНУ
    # форму `next_action` (словник), якої після зведення в картці вже не буде.
    _reason = due_reason(out)
    pid = client_of(key)
    people = []
    for p in people_of(key):
        pr = entity.ref(entity.KIND_PARTY, p["party_id"])
        people.append({"party_id": p["party_id"], "ref": pr,
                       "name": entity.title(pr), "href": entity.screen(pr),
                       "note": p["note"]})
    # ⭐ C2: адресу угоди в листуванні знає ОДИН писар — `deal_mail`. Імпорт
    # локальний: на рівні модуля вийшло б коло (deal_mail читає deals).
    import deal_mail as _dm

    # ⭐⭐⭐ 429: КАРТКА — ЦЕ ТА САМА ПЛИТКА, ЩО Й У ВОРОНЦІ, ПЛЮС ДЕТАЛІ.
    #
    # 🩸 ЧОМУ ЦЕ КОРІНЬ, А НЕ ОДРУКІВКА. Досі та сама угода приїжджала на
    # екран у ДВОХ формах: у воронку — розкладена `_tile()`, у картку — зі
    # вкладеними `amount:{...}`, `next_action:{...}` і `client:{...}`. Екран,
    # написаний під першу форму, на другій малював людині «[object Object]»
    # замість клієнта й наступної дії, а рядки «Сума» і «Строк» просто
    # зникали — і жоден із 170 чеків цього не бачив, бо чек екрана читав
    # розмітку як текст. Два писарі однієї правди розійшлись.
    #
    # Тепер писар форми ОДИН — `_tile`. Картка бере його зведення й додає
    # рівно те, чого у воронці немає. Сховищну форму `amount` картка більше
    # НЕ віддає: друга проєкція тих самих грошей — це той самий другий писар.
    out.update(_tile(out))
    out.pop("amount", None)
    out["due_reason"] = _reason
    out["people"] = people
    out["license"] = license_of_party(pid)
    out["mail_token"] = _dm.token(key)
    out["stages"] = STAGES
    return out


def license_of_party(pid) -> dict:
    """Ліцензія й канал оновлень контрагента — ЧИТАЧЕМ картки клієнта.

    ⛒ Це і є межа C1: продаж переїхав в угоду, ЛІЦЕНЗІЯ ЛИШИЛАСЬ ТАМ, ДЕ БУЛА
    (`publish_update.canon_customer` читає ту саму назву картки). Тут ми лише
    ДИВИМОСЬ на неї — жодного запису."""
    out = {"customer": "", "edition": "", "expiry": "", "version": "",
           "applied": 0, "has_key": False, "href": ""}
    p = _s(pid)
    if not p:
        return out
    try:
        import crm
        name = crm.card_of_party(p)
        if not name:
            return out
        c = crm.get_client(name) or {}
        out.update({
            "customer": name,
            "edition": _s(c.get("edition")),
            "expiry": _s(c.get("expiry")),
            "version": _s(c.get("version")),
            "applied": len(c.get("applied") or []),
            "has_key": bool(c.get("license_key")),
        })
    except Exception:
        pass
    return out
