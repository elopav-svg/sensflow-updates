# -*- coding: utf-8 -*-
"""project_memory.py — ОДИН ПИСАР ПРАВДИ «ЧИ ПАМʼЯТЬ ПРОЄКТУ ЛЕЖИТЬ НА ДИСКУ».

⭐⭐⭐ ЖИВИЙ ВИПАДОК 10.09.2026. Перевстановлення Claude знищило памʼять проєкту.
Роки домовленостей, уроків і правил жили ЛИШЕ в хмарі помічника. На диску, який
щодня пакується в бекап, їх не було зовсім. Тобто бекап рятував КОД і не рятував
ЗНАННЯ — а без знання код на новій машині нічого не вартий: людина не памʼятає,
чому саме так, і починає з ремонту вчорашнього.

⛒ КЛАС: АКТИВ ЖИВЕ В ОДНОМУ ЕКЗЕМПЛЯРІ ПОЗА КОНТУРОМ ВЛАСНОГО БЕКАПУ.

ЛІК. У робочій теці зʼявляється ДЗЕРКАЛО ПАМʼЯТІ — звичайна тека з файлами:
інструкції проєкту, точки зупинки, уроки, памʼять про Андрія, і найперший файл
«_ЯК_ВІДНОВИТИСЬ.md». Дзеркало пише помічник наприкінці кожної зміни (з хмари на
диск — інакше ніяк, скрипт до хмари не дістає). А цей модуль — ОДИН ПИСАР, який
каже про дзеркало правду: є воно, повне воно, і чи не відстало від живих
документів. Бекапер питає цього писаря й каже відповідь ВГОЛОС.

🩸 Писар НІКОЛИ не зупиняє бекап. Неповний бекап кращий за незроблений.
Його справа — сказати вголос, а не заборонити.

Офлайн, лише stdlib.
"""
import json
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent            # .../orchestrator_py
PLATFORM = HERE.parent                            # .../AI_Orchestrator_Platform
WORKSPACE = PLATFORM.parent                       # .../Проект ИИ

# Імʼя теки дзеркала. З підкреслення — щоб лежала зверху переліку і щоб
# складальник клієнтської збірки вважав її нашою (ours_dir) і НЕ слав клієнту.
MIRROR_DIRNAME = "_ПАМЯТЬ_ПРОЄКТУ"
STAMP_NAME = "_ЗЛІПОК.json"
ENTRY_NAME = "_ЯК_ВІДНОВИТИСЬ.md"

# Скільки днів дзеркало має право відставати від живих документів, поки це
# ще не «застаріле». Тиждень: за тиждень роботи домовленості встигають змінитись.
# ⛒ 609б: було 7. Дзеркало пишеться НАПРИКІНЦІ КОЖНОЇ ЗМІНИ, тому тижневий
# допуск означав «тиждень можна не писати» — і саме так дзеркало відстало від
# 563-ї до 609-ї зміни, а сторож увесь той час казав «свіже».
STALE_DAYS = 1

# Живі документи, за якими видно, що проєкт поїхав далі, а дзеркало — ні.
LIVING_GLOBS = ("Журнал_змін_SensFlow.md", "ROADMAP_SensFlow.md",
                "Інструкції_проєкту_СТАТУТ.md", "_ТОЧКА_ЗУПИНКИ_*.md")

# ⛒⛒⛒ 609б: ЩО СУДИТЬСЯ ЗМІСТОМ, А НЕ ДАТОЮ.
# Дзеркало тримає КОПІЇ цих файлів. Копія, яка розійшлась з оригіналом, — це
# не «трохи старе дзеркало», це СТАРІ ПРАВИЛА в руках того, хто відновлюється.
# Дату можна оновити, переклавши файли; збіг байтів підробити не можна.
MIRRORED = (
    ("Інструкції_проєкту_СТАТУТ.md",
     "1_інструкції/Інструкції_проєкту_СТАТУТ.md", "Статут"),
    ("Журнал_змін_SensFlow.md",
     "3_стан_проєкту/Журнал_змін_SensFlow.md", "журнал змін"),
)


def mirror_dir(workspace=None) -> Path:
    return Path(workspace or WORKSPACE) / MIRROR_DIRNAME


def _dmy(ts) -> str:
    return time.strftime("%d.%m.%Y", time.localtime(ts))


def living_docs(workspace=None):
    """Найсвіжіші живі документи проєкту — за ними міряємо відставання."""
    ws = Path(workspace or WORKSPACE)
    out = []
    for g in LIVING_GLOBS:
        out.extend(p for p in ws.glob(g) if p.is_file())
    return out


def state(workspace=None) -> dict:
    """Правда про дзеркало. Один писар — одна відповідь.

    Ключі: ok, exists, broken, stale, files, bytes, when, why, missing, newest.
    """
    ws = Path(workspace or WORKSPACE)
    d = mirror_dir(ws)
    st = {"dir": str(d), "exists": False, "broken": False, "stale": False,
          "ok": False, "files": 0, "bytes": 0, "when": "", "why": "",
          "missing": [], "newest": "", "newest_when": ""}

    stamp = d / STAMP_NAME
    if not d.is_dir() or not stamp.is_file():
        st["why"] = ("дзеркала памʼяті на диску НЕМАЄ (%s). У бекап поїде код "
                     "без знань про проєкт." % MIRROR_DIRNAME)
        return st
    st["exists"] = True

    try:
        data = json.loads(stamp.read_text(encoding="utf-8"))
    except Exception as e:
        st["broken"] = True
        st["why"] = "зліпок дзеркала не читається: %s" % e
        return st

    listed = list(data.get("files") or [])
    missing = [rel for rel in listed if not (d / rel).is_file()]
    st["missing"] = missing
    on_disk = [p for p in d.rglob("*") if p.is_file()]
    st["files"] = len(on_disk)
    st["bytes"] = sum(p.stat().st_size for p in on_disk)

    ts = float(data.get("ts") or stamp.stat().st_mtime)
    st["when"] = _dmy(ts)

    if missing:
        st["broken"] = True
        st["why"] = ("дзеркало неповне: у зліпку %d файл(ів), на диску немає %d — %s"
                     % (len(listed), len(missing), ", ".join(missing[:4])))
        return st
    if not (d / ENTRY_NAME).is_file():
        st["broken"] = True
        st["why"] = "у дзеркалі немає вхідного файла %s" % ENTRY_NAME
        return st

    # ⛒ 609б: ЗМІСТ ПЕРЕД ДАТОЮ. Спершу питаємо, чи копії збігаються з
    # оригіналами, і лише потім — чи давно робився зліпок.
    for src_name, rel, human in MIRRORED:
        src = ws / src_name
        copy = d / rel
        if not src.is_file():
            continue
        if not copy.is_file():
            st["stale"] = True
            st["why"] = ("дзеркало не тримає %s: немає «%s». Відновлюватись "
                         "буде нема з чого." % (human, rel))
            return st
        try:
            same = src.read_bytes() == copy.read_bytes()
        except Exception as e:
            st["broken"] = True
            st["why"] = "копію «%s» не вдалось прочитати: %s" % (rel, e)
            return st
        if not same:
            st["stale"] = True
            st["why"] = ("дзеркало відстало ЗМІСТОМ: копія «%s» розходиться з "
                         "живим файлом «%s». Онови дзеркало памʼяті."
                         % (human, src_name))
            return st

    live = living_docs(ws)
    if live:
        newest = max(live, key=lambda p: p.stat().st_mtime)
        st["newest"] = newest.name
        st["newest_when"] = _dmy(newest.stat().st_mtime)
        if newest.stat().st_mtime > ts + STALE_DAYS * 86400:
            st["stale"] = True
            days = int((newest.stat().st_mtime - ts) / 86400)
            st["why"] = ("дзеркало відстало на %d дн.: «%s» змінено %s, а зліпок "
                         "памʼяті — %s" % (days, newest.name, st["newest_when"],
                                           st["when"]))
            return st

    st["ok"] = True
    st["why"] = "дзеркало памʼяті повне і свіже (зліпок %s)" % st["when"]
    return st


def say(st=None, workspace=None):
    """Готові рядки ВГОЛОС. Повертає перелік рядків, не друкує сам."""
    st = st or state(workspace)
    head = "  Памʼять проєкту на диску: "
    if st["ok"]:
        return ["%s✓ %s | файлів: %d | %.1f МБ"
                % (head, st["why"], st["files"], st["bytes"] / (1024 * 1024))]
    lines = ["%s[!] %s" % (head, st["why"])]
    if not st["exists"]:
        lines.append("      Скажи помічникові: «онови дзеркало памʼяті» — "
                     "він запише теку %s і вона поїде в наступний бекап."
                     % MIRROR_DIRNAME)
    elif st["stale"]:
        lines.append("      Скажи помічникові: «онови дзеркало памʼяті».")
    return lines


if __name__ == "__main__":
    s = state()
    for ln in say(s):
        print(ln)
    print("  тека: %s" % s["dir"])

def stamp(workspace=None, who="помічник (Claude)"):
    """⭐ 609б: ОДИН ПИСАР ЗЛІПКА. Раніше `_ЗЛІПОК.json` писався руками, і
    перелік файлів у ньому розходився з тим, що справді лежить у теці.

    Перед записом КОПІЮЄ живі документи в дзеркало (`MIRRORED`) — інакше
    зліпок фіксував би свіжу дату на старому змісті, а це та сама брехня,
    від якої ми лікувались.
    """
    import shutil
    ws = Path(workspace or WORKSPACE)
    d = mirror_dir(ws)
    if not d.is_dir():
        raise RuntimeError("дзеркала памʼяті немає: %s" % d)

    for src_name, rel, _human in MIRRORED:
        src = ws / src_name
        if src.is_file():
            dst = d / rel
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)

    files = sorted(str(p.relative_to(d)).replace("\\", "/")
                   for p in d.rglob("*")
                   if p.is_file() and p.name != STAMP_NAME)
    now = time.time()
    data = {
        "ts": now,
        "when": _dmy(now),
        "хто_записав": who,
        "нащо": ("щоб утрата машини або памʼяті помічника не коштувала знань "
                 "про проєкт"),
        "files": files,
    }
    (d / STAMP_NAME).write_text(
        json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    return data

