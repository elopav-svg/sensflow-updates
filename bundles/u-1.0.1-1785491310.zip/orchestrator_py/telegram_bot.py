"""
telegram_bot.py — Telegram-вхід до SensFlow.

ДВА НЕЗАЛЕЖНІ БОТИ (обидва через long-polling, лише stdlib/urllib):
  • Оркестратор  (роль "orchestrator") — токен TELEGRAM_BOT_TOKEN.
      Приватний: лише власник(и) з TELEGRAM_ALLOWED_CHAT_IDS. Приймає задачі →
      engine.handle_message → відповідь + готові файли назад у чат.
  • Підтримка    (роль "support")      — токен TELEGRAM_SUPPORT_BOT_TOKEN.
      Клієнти (схвалені в консолі) → support_brain; складне ескалює власнику.
      Реагує лише коли TELEGRAM_SUPPORT_MODE=1 (тумблер «підтримка увімкнена»).

Кожен бот — свій фоновий потік-поллер зі своїм токеном і роллю (thread-local
контекст `_ctx`). Жодних вхідних портів: боти самі опитують Telegram.

Запуск:
  • автоматично — фоновими потоками із server.py (start_in_background);
  • окремо — `python telegram_bot.py`.
"""

import io
import json
import sys
import time
import threading
import urllib.request
import urllib.parse
import urllib.error

import config
import engine
import netfetch          # ЄДИНЕ вікно назовні: телеграм більше не ходить у мережу сам
import tender_outbound   # вартовий: тендерний текст без печатки не виходить
import threads as threadstore
import filetext
import telegram_access
import support_brain
import inbound

_API = "https://api.telegram.org/bot{token}/{method}"
_FILE_API = "https://api.telegram.org/file/bot{token}/{file_path}"

# Сумісність зі старим кодом: токен «за замовчуванням» = оркестратор.
_TOKEN = (config.ENV.get("TELEGRAM_BOT_TOKEN") or "").strip()

# Контекст поточного поллера — свій у кожному потоці-боті (який токен, яка роль).
_ctx = threading.local()


def _tok() -> str:
    return getattr(_ctx, "token", "") or (config.ENV.get("TELEGRAM_BOT_TOKEN") or "").strip()


def _role() -> str:
    return getattr(_ctx, "role", "orchestrator")


def _orch_token() -> str:
    return (config.ENV.get("TELEGRAM_BOT_TOKEN") or "").strip()


def _support_token() -> str:
    return (config.ENV.get("TELEGRAM_SUPPORT_BOT_TOKEN") or "").strip()


_RICH_EXT = (".docx", ".xlsx", ".pptx", ".pdf", ".csv")
_MAX_MSG = 3800          # запас під ліміт Telegram у 4096 символів
_CHAT_THREADS = {}       # (role, chat_id) -> thread_id (мапінг у памʼяті процесу)


# ДОСТУП ДО БОТІВ — ОДИН СПИСОК НА ОБИДВА (31.07.2026).
# Було ДВА писарі однієї правди: сторінка «Авторизовані користувачі» писала у
# свій файл, а бот-оркестратор питав owner_ids() — лише .env.local. Клієнт
# додавав себе кнопкою, кнопка казала «додано», бот не пускав. Кнопка, яка
# спрацювала і нічого не зробила, — брехня на екрані.
#  • обидва боти пускають за telegram_access.is_allowed() = .env.local + консоль;
#  • owner_ids() лишається ВЛАСНИКОМ (ескалації, мовчання в групі) — це інша роль.
def _is_allowed(chat_id) -> bool:
    return telegram_access.is_allowed(chat_id)


def _sender_name(msg) -> str:
    f = msg.get("from") or {}
    name = " ".join(x for x in (f.get("first_name"), f.get("last_name")) if x).strip()
    if f.get("username"):
        name = (name + f" (@{f['username']})").strip()
    return name


def _signal_inbound(msg, chat_id):
    """Фаза 4: вхідне від клієнта → позначка «потребує уваги» на його картці CRM.
    У приваті ідентифікатор = chat_id; у групі = відправник (from_id). Повідомлення
    власника НЕ рахуємо за інбаунд. Тиха, відмово-стійка операція (не ламає відповідь)."""
    try:
        chat = msg.get("chat") or {}
        is_group = (chat.get("type") or "private") in ("group", "supergroup")
        frm = msg.get("from") or {}
        from_id = frm.get("id")
        signal_id = from_id if is_group else chat_id
        if signal_id is None or signal_id in telegram_access.owner_ids():
            return
        text = (msg.get("text") or msg.get("caption") or "").strip()
        inbound.from_telegram(signal_id, username=(frm.get("username") or ""),
                              name=_sender_name(msg), text=text)
    except Exception as e:
        sys.stderr.write(f"[tg] inbound-сигнал: {e}\n")


def ready() -> bool:
    return bool(_orch_token() or _support_token())


# ── Низькорівневі виклики Bot API (токен = поточний бот через _tok()) ────────
def _api(method, params=None, timeout=60):
    """Виклик Telegram API через ЄДИНЕ вікно назовні (netfetch).

    ЧОМУ НЕ urllib НАПРЯМУ (як було до 27.07.2026). Телеграм — це канал, яким
    факти виходять до людини. Власний urllib означав, що цей канал обходить
    ворота виходу: у режимі максимального збереження / Стелс дані пішли б
    назовні непоміченими, і жоден МАЙБУТНІЙ мережевий канал не був би прикритий
    автоматично. Тіло на дроті лишилось те саме (form-urlencoded).
    """
    url = _API.format(token=_tok(), method=method)
    body = urllib.parse.urlencode(params or {}).encode("utf-8")
    raw = netfetch.post_json(
        url, payload=body, timeout=timeout,
        extra_headers={"Content-Type": "application/x-www-form-urlencoded"})
    return json.loads(raw)


def _split(text, n=_MAX_MSG):
    text = text or ""
    if len(text) <= n:
        return [text] if text.strip() else []
    out, cur = [], ""
    for line in text.split("\n"):
        while len(line) > n:                       # дуже довгий рядок ріжемо жорстко
            if cur:
                out.append(cur); cur = ""
            out.append(line[:n]); line = line[n:]
        if len(cur) + len(line) + 1 > n:
            if cur:
                out.append(cur)
            cur = line
        else:
            cur += (("\n" if cur else "") + line)
    if cur.strip():
        out.append(cur)
    return out


def _send_message(chat_id, text):
    # ⭐ ВАРТОВИЙ НА ВИХОДІ. Стоїть ДО нарізки на шматки — інакше перевіряли б
    # уламки тексту, а не повідомлення. Тендерний текст без печатки складача
    # (tender_message.build) сюди не проходить: замість нього піде чесна відмова.
    text = tender_outbound.guard(text)
    ok = False
    for chunk in _split(text):
        try:
            _api("sendMessage", {"chat_id": chat_id, "text": chunk,
                                 "disable_web_page_preview": "true"})
            ok = True
        except Exception as e:
            sys.stderr.write(f"[tg] sendMessage: {e}\n")
            return False
    # ⚠ Повертаємо ПРАВДУ про відправку: сторож позначає тендер «надісланим»
    # лише коли він реально пішов. Інакше тендер зникне назавжди — його вже
    # не покажуть удруге, а людина його ніколи не бачила.
    return ok


def _send_chat_action(chat_id, action="typing"):
    try:
        _api("sendChatAction", {"chat_id": chat_id, "action": action})
    except Exception:
        pass


def _send_document(chat_id, path, filename):
    try:
        with open(path, "rb") as f:
            content = f.read()
    except Exception as e:
        sys.stderr.write(f"[tg] read file {path}: {e}\n")
        return
    boundary = "----orx" + str(int(time.time() * 1000))
    body = io.BytesIO()

    def w(s):
        body.write(s.encode("utf-8") if isinstance(s, str) else s)

    w(f"--{boundary}\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n{chat_id}\r\n")
    w(f"--{boundary}\r\nContent-Disposition: form-data; name=\"document\"; "
      f"filename=\"{filename}\"\r\n")
    w("Content-Type: application/octet-stream\r\n\r\n")
    w(content)
    w(f"\r\n--{boundary}--\r\n")
    try:
        netfetch.post_json(
            _API.format(token=_tok(), method="sendDocument"),
            payload=body.getvalue(), timeout=180,
            extra_headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    except Exception as e:
        sys.stderr.write(f"[tg] sendDocument {filename}: {e}\n")


def _download_file(file_id):
    info = _api("getFile", {"file_id": file_id})
    fp = (info.get("result") or {}).get("file_path")
    if not fp:
        return None, None
    url = _FILE_API.format(token=_tok(), file_path=fp)
    return fp.split("/")[-1], netfetch.get_bytes(url, timeout=180)


# ── Обробка повідомлень ────────────────────────────────────────────────────
def _thread_for(chat_id):
    key = (_role(), chat_id)
    tid = _CHAT_THREADS.get(key)
    if tid and threadstore.get(tid):
        return tid
    tid = threadstore.create(title=f"Telegram {chat_id}")["id"]
    _CHAT_THREADS[key] = tid
    return tid


def _handle_update(upd):
    msg = upd.get("message") or upd.get("edited_message")
    if not msg:
        return
    chat_id = (msg.get("chat") or {}).get("id")
    if chat_id is None:
        return

    role = _role()

    # ── БОТ ПІДТРИМКИ (@TechCareSF) ──────────────────────────────────────────
    if role == "support":
        if not config.TELEGRAM_SUPPORT_MODE:
            return  # підтримку призупинено тумблером у консолі
        # Шлагбаум: обслуговуємо лише авторизованих; решта → черга заявок власнику.
        if not _is_allowed(chat_id):
            try:
                telegram_access.record_pending(chat_id, _sender_name(msg))
            except Exception:
                pass
            _send_message(chat_id,
                          "🔒 Це приватний бот. Ваш запит на доступ надіслано власнику.\n"
                          f"Ваш Telegram ID: {chat_id}\n"
                          "Щойно власник схвалить його в консолі — ви зможете користуватися ботом.")
            sys.stderr.write(f"[tg/support] заявка неавторизованому chat_id={chat_id}\n")
            return
        # Інбаунд-сигнал: клієнт написав → бейдж «уваги» на його картці CRM.
        _signal_inbound(msg, chat_id)
        chat_type = (msg.get("chat") or {}).get("type") or "private"
        is_group = chat_type in ("group", "supergroup")
        if is_group:
            from_id = (msg.get("from") or {}).get("id")
            # У групі бот МОВЧИТЬ на повідомлення власника — відповідає сам Андрій.
            if from_id is not None and from_id in telegram_access.owner_ids():
                return
        _handle_support(chat_id, msg, is_group=is_group)
        return

    # ── БОТ ОРКЕСТРАТОРА (@SFAIO) — приватний ────────────────────────────────
    # Пускає ТОЙ САМИЙ список, що й бот підтримки: .env.local + схвалені в консолі.
    from_id = (msg.get("from") or {}).get("id")
    is_owner = _is_allowed(chat_id) or (from_id is not None and _is_allowed(from_id))
    if not is_owner:
        # Відмова МУСИТЬ давати шлях усередину: інакше замкнене коло — щоб додати
        # себе, треба знати свій номер, а дізнатись його ніде (баг 31.07.2026).
        try:
            telegram_access.record_pending(chat_id, _sender_name(msg))
        except Exception:
            pass
        _send_message(chat_id,
                      "🔒 Це приватний бот-оркестратор SensFlow. "
                      "Ваш запит на доступ надіслано власнику.\n"
                      f"Ваш Telegram ID: {chat_id}\n"
                      "Щойно власник схвалить його в консолі — ви зможете користуватися ботом.")
        sys.stderr.write(f"[tg/orch] заявка неавторизованому chat_id={chat_id}\n")
        return

    text = (msg.get("text") or msg.get("caption") or "").strip()

    if text in ("/start", "/help"):
        _send_message(chat_id,
                      "Вітаю! Я ваш AI-оркестратор. Надішліть задачу людською мовою або "
                      "прикріпіть файл (docx, xlsx, pdf, csv, txt) — я визначу потрібну "
                      "систему, виконаю її, перевірю результат і поверну готові файли.")
        return

    # Прикріплений документ → витяг тексту в контекст
    files_context = ""
    doc = msg.get("document")
    if doc:
        try:
            name, raw = _download_file(doc.get("file_id"))
            if raw:
                fname = doc.get("file_name") or name or "файл"
                extracted = filetext.extract_text(fname, raw)
                if extracted and extracted.strip():
                    files_context = f"## ДОДАНИЙ ФАЙЛ: {fname}\n{extracted}"
        except Exception as e:
            sys.stderr.write(f"[tg] download/extract: {e}\n")
            _send_message(chat_id, "Не вдалося прочитати прикріплений файл. "
                                   "Спробуйте інший формат (docx, xlsx, pdf, csv, txt).")

    if not text and not files_context:
        _send_message(chat_id, "Порожнє повідомлення. Напишіть задачу або прикріпіть файл.")
        return

    tid = _thread_for(chat_id)
    rec = threadstore.get(tid) or {}
    history = rec.get("messages", [])
    inherited_fc = files_context or threadstore.latest_files_context(tid)

    _send_chat_action(chat_id)
    _ack = {"t": time.time()}

    def emit(label):
        # Тримаємо «друкує…», але не спамимо повідомленнями.
        now = time.time()
        if now - _ack["t"] > 7:
            _ack["t"] = now
            _send_chat_action(chat_id)

    try:
        res = engine.handle_message(text or "(прикріплений файл)",
                                    history=history,
                                    files_context=inherited_fc,
                                    emit=emit)
    except Exception as e:
        sys.stderr.write(f"[tg] engine: {e}\n")
        _send_message(chat_id, f"Сталася помилка під час виконання: {e}")
        return

    reply = (res.get("reply") or "Готово.").strip()
    _send_message(chat_id, reply)

    # Згенеровані файли: надсилаємо «насичені» (docx/xlsx/pptx/pdf/csv),
    # а якщо таких немає — лишаємо md як запасний.
    result = res.get("result") or {}
    arts = [a for a in (result.get("artifacts") or []) if isinstance(a, dict) and a.get("path")]
    rich = [a for a in arts if a.get("filename", "").lower().endswith(_RICH_EXT)]
    to_send = rich or [a for a in arts if a.get("filename", "").lower().endswith(".md")][:1]
    if to_send:
        _send_chat_action(chat_id, "upload_document")
    for a in to_send:
        _send_document(chat_id, a["path"], a.get("filename", "result"))

    # Зберігаємо хід у thread (для контексту наступних повідомлень)
    try:
        threadstore.append(tid, "user", text or "(прикріплений файл)",
                           files_context=files_context or None)
        threadstore.append(tid, "assistant", reply)
    except Exception as e:
        sys.stderr.write(f"[tg] thread append: {e}\n")


# ── Режим техпідтримки («Клод» / TechCareSF) ───────────────────────────────
def _download_photo(msg):
    """Найбільший розмір фото (скріншот) → (media_type, bytes) або (None, None)."""
    photos = msg.get("photo") or []
    if not photos:
        return None, None
    big = photos[-1]
    try:
        _name, raw = _download_file(big.get("file_id"))
        if raw:
            return "image/jpeg", raw
    except Exception as e:
        sys.stderr.write(f"[tg] download photo: {e}\n")
    return None, None


def _notify_owners(text):
    """Надсилає повідомлення власнику(ам) — для ескалацій підтримки."""
    try:
        owners = telegram_access.owner_ids()
    except Exception:
        owners = []
    for oid in owners:
        try:
            _send_message(oid, text)
        except Exception as e:
            sys.stderr.write(f"[tg] notify owner {oid}: {e}\n")


def _handle_support(chat_id, msg, is_group=False):
    """Техпідтримка: відповідь «Клод» з бази знань; невідоме/невпевнене → ескалація власнику.
    У групі (is_group): відповідає лише клієнту; повідомлення власника сюди не доходять (фільтр вище)."""
    text = (msg.get("text") or msg.get("caption") or "").strip()
    _cmd = text.split("@", 1)[0] if text.startswith("/") else text
    if _cmd in ("/start", "/help"):
        _send_message(chat_id,
                      f"Вітаю! Я {config.SUPPORT_BOT_NAME}, технічна підтримка SensFlow. "
                      "Опишіть проблему словами або надішліть скріншот — допоможу із запуском і "
                      "налаштуванням. Складні випадки передам Андрію.")
        return

    images = []
    mt, raw = _download_photo(msg)
    if raw:
        images.append({"media_type": mt, "data": raw})

    extra_text = ""
    doc = msg.get("document")
    if doc:
        fname = (doc.get("file_name") or "")
        mime = (doc.get("mime_type") or "")
        is_img = mime.startswith("image/") or fname.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))
        try:
            _n, draw = _download_file(doc.get("file_id"))
        except Exception as e:
            draw = None
            sys.stderr.write(f"[tg] support doc: {e}\n")
        if draw and is_img:
            images.append({"media_type": mime or "image/png", "data": draw})
        elif draw:
            try:
                ex = filetext.extract_text(fname or "файл", draw)
                if ex and ex.strip():
                    extra_text = f"\n\n[Вміст файлу {fname}]\n{ex[:4000]}"
            except Exception as e:
                sys.stderr.write(f"[tg] support extract: {e}\n")

    if not text and not images and not extra_text:
        if not is_group:   # у групі не шумимо на не-текстові події
            _send_message(chat_id, "Напишіть, будь ласка, питання або надішліть скріншот — і я допоможу.")
        return

    tid = _thread_for(chat_id)
    rec = threadstore.get(tid) or {}
    history = rec.get("messages", [])
    _send_chat_action(chat_id)
    try:
        res = support_brain.answer((text + extra_text).strip(), history=history,
                                   images=images or None)
    except Exception as e:
        sys.stderr.write(f"[tg] support_brain: {e}\n")
        _send_message(chat_id, "Вибачте, стався технічний збій. Передаю Андрію — він відповість.")
        _notify_owners(f"⚠️ Збій підтримки у боті: {e}\nКлієнт chat_id {chat_id}.")
        return

    reply = (res.get("reply") or "Готово.").strip()
    _send_message(chat_id, reply)

    if res.get("escalate"):
        who = _sender_name(msg) or str(chat_id)
        note = res.get("owner_note") or ""
        # У групі Андрій присутній — досить відповіді в чаті. У 1:1 — окремий DM власнику.
        if not is_group:
            _notify_owners(f"🆘 Ескалація від клієнта {who} (chat_id {chat_id}):\n{note}\n\n"
                           f"Клієнту вже відповіли «передаю Андрію». Дайте відповідь — він чекає.")

    try:
        threadstore.append(tid, "user", text or "(зображення)")
        threadstore.append(tid, "assistant", reply)
    except Exception as e:
        sys.stderr.write(f"[tg] support thread append: {e}\n")


# ── Цикл long-polling (по одному на кожен бот) ──────────────────────────────
def _loop(token, role):
    _ctx.token = token
    _ctx.role = role
    sys.stderr.write(f"[tg/{role}] бот запущено (long-polling)\n")
    offset = None
    while True:
        try:
            params = {"timeout": 50, "allowed_updates": json.dumps(["message"])}
            if offset is not None:
                params["offset"] = offset
            resp = _api("getUpdates", params, timeout=65)
            for upd in resp.get("result", []):
                offset = upd["update_id"] + 1
                try:
                    _handle_update(upd)
                except Exception as e:
                    sys.stderr.write(f"[tg/{role}] update: {e}\n")
        except urllib.error.URLError as e:
            sys.stderr.write(f"[tg/{role}] мережа: {e}; пауза 5с\n")
            time.sleep(5)
        except Exception as e:
            sys.stderr.write(f"[tg/{role}] loop: {e}; пауза 5с\n")
            time.sleep(5)


_threads = {}   # role -> Thread


def _running(role) -> bool:
    t = _threads.get(role)
    return t is not None and t.is_alive()


def is_running() -> bool:
    return any(_running(r) for r in ("orchestrator", "support"))


def _start_one(role, token) -> bool:
    """Запускає бота вказаної ролі (ідемпотентно). True, якщо працює."""
    if not token:
        return False
    if _running(role):
        return True
    th = threading.Thread(target=_loop, args=(token, role), daemon=True,
                          name=f"telegram-{role}")
    th.start()
    _threads[role] = th
    return True


def start_in_background() -> bool:
    """Запускає обидва боти (у кого є токен) фоновими демон-потоками. True, якщо хоч один працює."""
    a = _start_one("orchestrator", _orch_token())
    b = _start_one("support", _support_token())
    return a or b


def set_token(token: str) -> dict:
    """Зберігає токен ОРКЕСТРАТОРА у .env.local й запускає його бот — без рестарту."""
    global _TOKEN
    token = (token or "").strip()
    try:
        config.update_env_local({"TELEGRAM_BOT_TOKEN": token})
    except Exception as e:
        sys.stderr.write(f"[tg] збереження токена оркестратора: {e}\n")
    config.ENV["TELEGRAM_BOT_TOKEN"] = token
    _TOKEN = token
    started = _start_one("orchestrator", token) if token else False
    return {"has_token": bool(token), "running": _running("orchestrator"), "started": started}


def set_support_token(token: str) -> dict:
    """Зберігає токен ПІДТРИМКИ у .env.local й запускає її бот — без рестарту."""
    token = (token or "").strip()
    try:
        config.update_env_local({"TELEGRAM_SUPPORT_BOT_TOKEN": token})
    except Exception as e:
        sys.stderr.write(f"[tg] збереження токена підтримки: {e}\n")
    config.ENV["TELEGRAM_SUPPORT_BOT_TOKEN"] = token
    started = _start_one("support", token) if token else False
    return {"has_token": bool(token), "running": _running("support"), "started": started}


def status() -> dict:
    return {
        "has_token": ready(),
        "running": is_running(),
        "orchestrator": {"has_token": bool(_orch_token()), "running": _running("orchestrator")},
        "support": {"has_token": bool(_support_token()), "running": _running("support")},
    }


if __name__ == "__main__":
    if not start_in_background():
        print("Немає жодного токена (TELEGRAM_BOT_TOKEN / TELEGRAM_SUPPORT_BOT_TOKEN) "
              "у .env.local — бот не запущено.")
        sys.exit(1)
    while True:
        time.sleep(3600)
