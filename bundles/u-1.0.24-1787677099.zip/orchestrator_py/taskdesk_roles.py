# -*- coding: utf-8 -*-
"""taskdesk_roles.py — ХТО КОМУ МАЄ ПРАВО СТАВИТИ ЗАДАЧІ (етап 2, варіант А).

⭐⭐⭐ НАВІЩО. Слова Андрія (02.08.2026): «права доступу — найболючіше питання;
для малих компаній непомітно, для великих з оргштатною структурою — головний
біль». Досі в коді воріт на постановку не було ЗОВСІМ: будь-який працівник міг
поставити задачу будь-кому. Малому клієнту це не муляє, а держзамовник питає
про це першим.

⛒ ОДНЕ ДЖЕРЕЛО ВЛАДИ. Матриця «роль × дозвіл» — це ДАНІ. Питає її рівно одна
функція (`allows`), і через неї ходять усі канали: веб, телеграм, розклад,
майбутній мобільний. Другого писаря правди про повноваження не буде.

⛒ РОЛЬ ВІШАЄТЬСЯ НА ПРАЦІВНИКА **АБО НА ПІДРОЗДІЛ**. Роль на вузлі структури
економить сотні призначень і не старіє при ротації людей — саме тому в реєстрі
помилок «імена замість ролей» стоїть окремим рядком.

⛒ ЩО ЦЕЙ ФАЙЛ НЕ РОБИТЬ. Він не знає про стадії, терміни й видимість — це
`taskdesk_tasks`. Він не знає про вхід у платформу — це `taskdesk_identity`
(шари й доступ до систем — ІНША вісь, свідомо окрема).

⚠ МОЗОК (LLM) СЮДИ НЕ ХОДИТЬ. Повноваження — логіка, а не судження.

📐 ЗА ЗАМОВЧУВАННЯМ — СЬОГОДНІШНЯ ПОВЕДІНКА. Поки адміністратор нічого не
налаштував, усі чотири напрями постановки дозволені: Андрій прямо назвав
горизонтальні звʼязки «прийнятними й бажаними». Цінність матриці — у тому, що
її МОЖНА звузити, а не в тому, щоб зламати живу роботу пілота вимкненим за
замовчуванням. ⛒ Але зламаний файл ролей — це ВІДМОВА, а не «ну тоді все можна».
"""
import json

import clock
import config
import taskdesk_people as people

DESK_DIR = config.STATE_DIR / "taskdesk"
ROLES_JSON = DESK_DIR / "roles.json"
AUDIT_KEEP = 200


class RoleError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


# ─────────────────────────────── СЛОВНИК ДОЗВОЛІВ ──────────────────────────
# ⛒ ДОЗВІЛ, ЯКОГО НІХТО НЕ ПИТАЄ, — ДЕКОРАЦІЯ. Тому тут лежать РІВНО ті, під
# якими вже стоять ворота в коді. Решта зʼявиться разом зі своїми воротами.
P_SET_OWN_UNIT = "set_own_unit"
P_SET_OWN_HEAD = "set_own_head"
P_SET_OTHER_UNIT = "set_other_unit"
P_SET_OTHER_HEAD = "set_other_head"

PERMS = [
    {"id": P_SET_OWN_UNIT, "section": "Постановка задач",
     "name": "Ставити задачі співробітникам свого підрозділу"},
    {"id": P_SET_OWN_HEAD, "section": "Постановка задач",
     "name": "Ставити задачі керівнику свого підрозділу"},
    {"id": P_SET_OTHER_UNIT, "section": "Постановка задач",
     "name": "Ставити задачі співробітникам інших підрозділів"},
    {"id": P_SET_OTHER_HEAD, "section": "Постановка задач",
     "name": "Ставити задачі керівникам інших підрозділів"},
]
PERM_IDS = tuple(p["id"] for p in PERMS)
PERM_NAMES = {p["id"]: p["name"] for p in PERMS}

ROLE_FULL = "full"
ROLE_HEAD = "head"
ROLE_WORKER = "worker"

BUILTIN = [
    {"id": ROLE_FULL, "name": "Повний доступ", "builtin": True,
     "perms": {p: True for p in PERM_IDS}},
    {"id": ROLE_HEAD, "name": "Керівник", "builtin": True,
     "perms": {p: True for p in PERM_IDS}},
    {"id": ROLE_WORKER, "name": "Співробітник", "builtin": True,
     "perms": {p: True for p in PERM_IDS}},
]


def _s(v) -> str:
    return "" if v is None else str(v).strip()


# ─────────────────────────────── СХОВИЩЕ ───────────────────────────────────
def _normalize(raw) -> dict:
    if not isinstance(raw, dict):
        raw = {}
    roles, seen = [], set()
    for r in (raw.get("roles") or []):
        if not isinstance(r, dict):
            continue
        rid = _s(r.get("id"))
        if not rid or rid in seen:
            continue
        seen.add(rid)
        perms = r.get("perms") if isinstance(r.get("perms"), dict) else {}
        roles.append({"id": rid, "name": _s(r.get("name")) or rid,
                      "builtin": bool(r.get("builtin")),
                      # ⛒ Невідомий дозвіл мовчки не зникає і мовчки не діє:
                      # у роль потрапляють РІВНО оголошені імена.
                      "perms": {p: bool(perms.get(p, False)) for p in PERM_IDS}})
    for b in BUILTIN:                       # вбудовані ролі не зникають ніколи
        if b["id"] not in seen:
            roles.append({"id": b["id"], "name": b["name"], "builtin": True,
                          "perms": dict(b["perms"])})
    assign = {}
    for k, v in (raw.get("assign") or {}).items():
        k, v = _s(k), _s(v)
        if k.startswith(("emp:", "unit:")) and v:
            assign[k] = v
    default_role = _s(raw.get("default_role")) or ROLE_WORKER
    if default_role not in {r["id"] for r in roles}:
        default_role = ROLE_WORKER
    return {"roles": roles, "assign": assign, "default_role": default_role,
            "audit": list(raw.get("audit") or [])[-AUDIT_KEEP:]}


def load() -> dict:
    """ОДИН ЧИТАЧ. Немає файла — вбудовані ролі. Файл ЗЛАМАНИЙ — це відмова.

    ⛒ Різниця принципова: «ще не налаштовано» і «налаштування побите» — різні
    стани. Прочитати друге як перше означало б тихо роздати повноваження."""
    if not ROLES_JSON.exists():
        return _normalize({})
    try:
        raw = json.loads(ROLES_JSON.read_text(encoding="utf-8"))
    except Exception as e:
        raise RoleError(
            "Файл ролей %s не читається (%s). Поки він побитий, повноваження "
            "не роздаються: виправте або приберіть файл."
            % (ROLES_JSON.name, type(e).__name__))
    return _normalize(raw)


def save(state: dict, reason: str) -> dict:
    st = _normalize(state)
    st["audit"] = (st.get("audit") or [])[-AUDIT_KEEP:]
    st["audit"].append({"at": clock.now(), "what": _s(reason)})
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    ROLES_JSON.write_text(json.dumps(st, ensure_ascii=False, indent=2),
                          encoding="utf-8")
    return st


def roles() -> list:
    return load()["roles"]


def role(role_id: str) -> dict:
    rid = _s(role_id)
    for r in load()["roles"]:
        if r["id"] == rid:
            return r
    return {}


def set_perm(role_id: str, perm: str, on: bool) -> dict:
    """Клітинка матриці. Часткових станів не буває — лише ввімкнено/вимкнено."""
    rid, p = _s(role_id), _s(perm)
    if p not in PERM_IDS:
        raise RoleError("Невідомий дозвіл «%s»." % p)
    st = load()
    for r in st["roles"]:
        if r["id"] == rid:
            r["perms"][p] = bool(on)
            return save(st, "роль %s: %s -> %s" % (rid, p, "так" if on else "ні"))
    raise RoleError("Ролі «%s» немає." % rid)


def add_role(name: str, copy_from: str = "") -> dict:
    nm = _s(name)
    if not nm:
        raise RoleError("У ролі має бути назва.")
    st = load()
    base = {}
    if copy_from:
        src = [r for r in st["roles"] if r["id"] == _s(copy_from)]
        if not src:
            raise RoleError("Ролі «%s», з якої копіюємо, немає." % copy_from)
        base = dict(src[0]["perms"])
    rid = "role-%d" % (len(st["roles"]) + 1)
    while any(r["id"] == rid for r in st["roles"]):
        rid += "x"
    st["roles"].append({"id": rid, "name": nm, "builtin": False,
                        "perms": {p: bool(base.get(p, False)) for p in PERM_IDS}})
    save(st, "нова роль «%s»" % nm)
    return role(rid)


def assign_to(kind: str, target_id: str, role_id: str) -> dict:
    """Роль вішається на ПРАЦІВНИКА (`emp`) або на ПІДРОЗДІЛ (`unit`)."""
    kind, tid, rid = _s(kind), _s(target_id), _s(role_id)
    if kind not in ("emp", "unit"):
        raise RoleError("Роль вішається на працівника або на підрозділ.")
    if not tid:
        raise RoleError("Не сказано, кому призначаємо роль.")
    st = load()
    if rid and rid not in {r["id"] for r in st["roles"]}:
        raise RoleError("Ролі «%s» немає." % rid)
    key = "%s:%s" % (kind, tid)
    if rid:
        st["assign"][key] = rid
    else:
        st["assign"].pop(key, None)
    return save(st, "%s -> %s" % (key, rid or "(знято)"))


# ─────────────────────────── ОДИН ЧИТАЧ ПОВНОВАЖЕНЬ ────────────────────────
def role_of(emp_id: str, st: dict = None) -> dict:
    """ЯКА РОЛЬ У ЦІЄЇ ЛЮДИНИ. Порядок один і назавжди:
       1) призначена особисто;
       2) призначена на її підрозділ (піднімаємось деревом угору);
       3) роль за замовчуванням.
    ⛒ Дерево йде вгору, бо роль на «Компанії» мусить діяти на всіх, кому нижче
    нічого не призначили. Інакше адміністратор налаштовував би кожен відділ."""
    st = st or load()
    by_id = {r["id"]: r for r in st["roles"]}
    eid = _s(emp_id)
    rid = st["assign"].get("emp:%s" % eid)
    if rid and rid in by_id:
        return by_id[rid]
    emp = people.employee(eid)
    unit_id = _s(emp.get("unit_id")) if emp else ""
    seen = set()
    while unit_id and unit_id not in seen:
        seen.add(unit_id)
        rid = st["assign"].get("unit:%s" % unit_id)
        if rid and rid in by_id:
            return by_id[rid]
        unit_id = _s(people.unit(unit_id).get("parent_id"))
    return by_id.get(st["default_role"]) or by_id[ROLE_WORKER]


def allows(emp_id: str, perm: str, st: dict = None) -> bool:
    """ЄДИНА ВІДПОВІДЬ «чи має ця людина цей дозвіл»."""
    p = _s(perm)
    if p not in PERM_IDS:
        raise RoleError("Невідомий дозвіл «%s»." % p)
    return bool(role_of(emp_id, st)["perms"].get(p))


def _is_head(emp_id: str) -> bool:
    """Чи ця людина — керівник хоч якогось підрозділу."""
    eid = _s(emp_id)
    return any(_s(u.get("head_employee_id")) == eid for u in people.units())


def zone(author_id: str, target_id: str) -> str:
    """ЯКИЙ ЦЕ НАПРЯМ ПОСТАНОВКИ. Чотири, як назвав Андрій."""
    a, t = _s(author_id), _s(target_id)
    ae, te = people.employee(a), people.employee(t)
    same_unit = bool(ae) and bool(te) and _s(ae.get("unit_id")) \
        and _s(ae.get("unit_id")) == _s(te.get("unit_id"))
    boss = _s(people.manager_of(a)) == t if a and t else False
    if same_unit:
        return P_SET_OWN_HEAD if (boss or _is_head(t)) else P_SET_OWN_UNIT
    if boss:
        # керівник вищого рівня — це «свій» начальник, навіть якщо підрозділ інший
        return P_SET_OWN_HEAD
    return P_SET_OTHER_HEAD if _is_head(t) else P_SET_OTHER_UNIT


def may_set_task(author_id: str, target_id: str) -> tuple:
    """ЧИ МОЖЕ ЦЯ ЛЮДИНА ПОСТАВИТИ ЗАДАЧУ ОЦІЙ. (можна, причина словами).

    ⭐ Задача СОБІ дозволена завжди — цю можливість Андрій прямо заборонив
    відбирати (02.08.2026): постановник має право записати задачу собі як
    нагадування."""
    a, t = _s(author_id), _s(target_id)
    if not t or a == t:
        return True, ""
    perm = zone(a, t)
    if allows(a, perm):
        return True, ""
    r = role_of(a)
    return False, ("Ваша роль «%s» не дозволяє: %s. Змінити це може той, хто "
                   "веде права доступу." % (r["name"], PERM_NAMES[perm].lower()))


def require_set_task(author_id: str, target_id: str) -> None:
    ok, why = may_set_task(author_id, target_id)
    if not ok:
        raise RoleError(why)


def matrix() -> dict:
    """Дані для екрана налаштування: ролі, дозволи, призначення."""
    st = load()
    return {"perms": [dict(p) for p in PERMS], "roles": st["roles"],
            "assign": st["assign"], "default_role": st["default_role"]}
