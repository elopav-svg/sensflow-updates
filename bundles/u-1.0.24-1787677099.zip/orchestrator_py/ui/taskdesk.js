// taskdesk.js — спільні помічники екранів Task Desk.
// Один писар звертань до сервера: кожен екран питає однаково, і помилка
// показується людині словами, а не мовчки зникає в консолі браузера.
async function tdApi(path, data){
  const opt = data === undefined
    ? {method:'GET'}
    : {method:'POST', headers:{'Content-Type':'application/json'},
       body: JSON.stringify(data)};
  const r = await fetch(path, opt);
  let body = {};
  try { body = await r.json(); } catch(e) { body = {}; }
  if(!r.ok){
    const msg = body.message || body.error || ('Помилка ' + r.status);
    // ⭐ 24.08.2026. Код відмови мусить доїхати до екрана: «ще не налаштовано»
    // лікується інакше, ніж «немає прав», і сторінка має право це розрізняти.
    const err = new Error(msg);
    err.code = body.error || '';
    err.status = r.status;
    throw err;
  }
  return body;
}
function tdEsc(s){
  return String(s === null || s === undefined ? '' : s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;');
}
function tdSay(id, text, ok){
  const el = document.getElementById(id);
  if(!el) return;
  el.textContent = text || '';
  el.className = ok ? 'td-ok' : 'td-err';
}
// Дата людині — DD.MM.YYYY (у файлі вона машинна, YYYY-MM-DD).
function tdDate(iso){
  const s = String(iso || '');
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? (m[3] + '.' + m[2] + '.' + m[1]) : '';
}
function tdWhen(iso){
  const s = String(iso || '');
  const m = s.match(/^(\d{4})-(\d{2})-(\d{2})T(\d{2}:\d{2})/);
  return m ? (m[3] + '.' + m[2] + '.' + m[1] + ' ' + m[4]) : '';
}

// ── НАБІРНИЙ ВИБІР ЛЮДИНИ — ОДИН ПИСАР НА ВЕСЬ TASK DESK ───────────────────
// Чому свій, а не <input list=…>: випадайку <datalist> малює БРАУЗЕР, а не ми.
// Її не можна ні оформити, ні показати «скільки варіантів лишилось», ні
// перевірити чеком, що вона взагалі відкрилась. Екран, якого не бачить ні
// людина, ні ворота, — це не наш екран.
var TD_PICK_MAX = 12;                 // скільки варіантів показуємо за раз

function tdFold(s){                   // одна нормалізація на всіх
  return String(s === null || s === undefined ? '' : s).toLowerCase().replace(/\s+/g, ' ').trim();
}

// Звуження — ЄДИНЕ місце, де вирішується «що підходить під набране».
// Головне правило: збіг із ПОЧАТКОМ слова. Людина набирає перші літери
// прізвища, і саме їх чекає побачити.
// Збіг усередині слова — ДРУГА ЛІНІЯ, і лише коли за початком не знайшлось
// НІКОГО. Інакше «Ко» тягнуло б за собою всіх «-енків» (Петриченко,
// Сидоренко, Ткаченко…), і набір літер майже не звужував би список —
// а це рівно те, заради чого він існує.
function tdPickMatch(people, query){
  const q = tdFold(query);
  if(!q) return people.slice();
  const head = [], inside = [];
  people.forEach(function(p){
    const label = tdFold(p.label);
    if(label.split(' ').some(function(w){ return w.indexOf(q) === 0; })) head.push(p);
    else if(label.indexOf(q) >= 0) inside.push(p);
  });
  return head.length ? head : inside;
}

function tdPicker(box, opts){
  opts = opts || {};
  const many = opts.mode === 'many';
  const uid = box.id || ('pick-' + Math.random().toString(36).slice(2));
  const self = {mode: opts.mode || 'one', people: [], one: '', list: [],
                exclude: function(){ return []; }, onChange: null};

  box.classList.add('td-pick');
  box.innerHTML =
    '<input class="td-pick-in" type="text" autocomplete="off" role="combobox"' +
    ' aria-autocomplete="list" aria-expanded="false" aria-controls="' + uid + '-list"' +
    ' placeholder="' + tdEsc(opts.placeholder || 'почніть набирати прізвище') + '">' +
    '<div class="td-pick-drop" id="' + uid + '-list" role="listbox" hidden></div>' +
    (many ? '<div class="td-picked"></div>' : '');
  const inp = box.querySelector('.td-pick-in');
  const drop = box.querySelector('.td-pick-drop');
  const chips = box.querySelector('.td-picked');
  if(opts.labelledBy) inp.setAttribute('aria-labelledby', opts.labelledBy);
  let open = false, active = -1, shown = [];

  function labels(){                  // однофамільці отримують номер — ТУТ, один раз
    const seen = {};
    self.people.forEach(function(p){ seen[p.name] = (seen[p.name] || 0) + 1; });
    return self.people.map(function(p){
      return {id: p.id, name: p.name,
              label: seen[p.name] > 1 ? (p.name + ' (' + p.id + ')') : p.name};
    });
  }
  function nameOf(id){
    const f = labels().filter(function(p){ return p.id === id; })[0];
    return f ? f.label : id;
  }
  function taken(){
    const out = (self.exclude() || []).slice();
    if(many) self.list.forEach(function(id){ out.push(id); });
    return out;
  }
  function candidates(){
    const off = taken();
    return tdPickMatch(labels().filter(function(p){ return off.indexOf(p.id) < 0; }), inp.value);
  }
  function drawChips(){
    if(!chips) return;
    chips.innerHTML = self.list.map(function(id){
      return '<span class="p">' + tdEsc(nameOf(id)) +
        '<button type="button" title="прибрати" data-drop="' + tdEsc(id) + '">×</button></span>';
    }).join('');
  }
  function close(){
    open = false; active = -1; drop.hidden = true;
    inp.setAttribute('aria-expanded', 'false');
    inp.removeAttribute('aria-activedescendant');
  }
  function draw(){
    const all = candidates();
    shown = all.slice(0, TD_PICK_MAX);
    if(!shown.length){
      // Зупинка мусить називати СВОЮ причину: «нікого не знайшов» і «усіх уже
      // додано» — це різні речі, і людина мусить бачити, яка з них сталася.
      const nobodyLeft = !inp.value.trim() && taken().length;
      drop.innerHTML = '<div class="td-pick-note">' +
        (nobodyLeft ? 'усіх, кого можна, вже додано'
                    : ('нікого не знайшов' +
                       (inp.value ? ' на «' + tdEsc(inp.value) + '»' : ''))) + '</div>';
    } else {
      drop.innerHTML = shown.map(function(p, i){
        return '<div class="td-pick-opt" role="option" id="' + uid + '-o' + i +
          '" data-id="' + tdEsc(p.id) + '"' + (i === active ? ' aria-selected="true"' : '') +
          '>' + tdEsc(p.label) + '</div>';
      }).join('') +
      (all.length > shown.length
        ? '<div class="td-pick-note">показано ' + shown.length + ' з ' + all.length +
          ' — наберіть ще літеру</div>'
        : '<div class="td-pick-note">варіантів: ' + all.length + '</div>');
    }
    drop.hidden = false; open = true;
    inp.setAttribute('aria-expanded', 'true');
    if(active >= 0) inp.setAttribute('aria-activedescendant', uid + '-o' + active);
    else inp.removeAttribute('aria-activedescendant');
  }
  function choose(id){
    if(!id) return;
    if(many){
      if(self.list.indexOf(id) < 0) self.list.push(id);
      inp.value = ''; drawChips(); draw();
    } else {
      self.one = id; inp.value = nameOf(id); close();
    }
    if(self.onChange) self.onChange();
  }

  inp.addEventListener('focus', function(){ active = -1; draw(); });
  inp.addEventListener('input', function(){
    if(!many) self.one = '';
    active = -1; draw();
    if(self.onChange) self.onChange();
  });
  inp.addEventListener('keydown', function(e){
    if(e.key === 'ArrowDown' || e.key === 'ArrowUp'){
      e.preventDefault();
      if(!open){ draw(); return; }
      if(!shown.length) return;
      active = e.key === 'ArrowDown'
        ? (active + 1 >= shown.length ? 0 : active + 1)
        : (active - 1 < 0 ? shown.length - 1 : active - 1);
      draw();
      return;
    }
    if(e.key === 'Enter'){
      e.preventDefault();
      if(shown.length) choose(shown[active >= 0 ? active : 0].id);
      return;
    }
    if(e.key === 'Escape'){ close(); return; }
    if(e.key === 'Tab'){ close(); }
  });
  drop.addEventListener('mousedown', function(e){
    const o = e.target.closest('.td-pick-opt');
    if(!o) return;
    e.preventDefault();
    choose(o.dataset.id);
  });
  if(chips) chips.addEventListener('click', function(e){
    const b = e.target.closest('button[data-drop]');
    if(!b) return;
    const i = self.list.indexOf(b.dataset.drop);
    if(i >= 0) self.list.splice(i, 1);
    drawChips();
    if(self.onChange) self.onChange();
  });
  document.addEventListener('mousedown', function(e){ if(!box.contains(e.target)) close(); });

  self.setPeople = function(list){
    self.people = (list || []).slice();
    if(!many && self.one) inp.value = nameOf(self.one);
    drawChips();
    return self;
  };
  self.setExclude = function(fn){ self.exclude = fn || function(){ return []; }; return self; };
  self.get = function(){ return many ? self.list.slice() : self.one; };
  self.set = function(v){
    if(many){ self.list = (v || []).slice(); drawChips(); }
    else { self.one = v || ''; inp.value = v ? nameOf(v) : ''; }
    return self;
  };
  self.clear = function(){ return self.set(many ? [] : ''); };
  // Текст, якого людина набрала, але нікого не вибрала — щоб сказати про це словами.
  self.stray = function(){ return (!many && !self.one && inp.value.trim()) ? inp.value.trim() : ''; };
  self.input = inp;
  return self;
}
