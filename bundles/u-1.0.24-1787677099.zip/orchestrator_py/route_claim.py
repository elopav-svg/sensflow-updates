# -*- coding: utf-8 -*-
"""route_claim.py — ПРЕТЕНЗІЯ МАРШРУТУ: яка система МАЄ вести цю задачу.

⭐⭐⭐ КОРІНЬ (Каспер, 24.08.2026). Посилання на закупівлю + «створи пакет
документів». Один порядок слів — пакет зібрався; інший — платформа обрала
Юриста, і клієнт не отримав нічого. Вибір системи робить МОЗОК: `system_id` —
це параметр інструмента `run_system`, тобто думка моделі про вільний текст.
Одна й та сама задача двома словами по-різному — два різні маршрути.

ЩО ВЖЕ БУЛО І ЧОМУ НЕ СПРАЦЮВАЛО. Ворота розуміння (`understanding`) вміють
лише «НІ»: суперечність спрацьовує ТІЛЬКИ тоді, коли ОБРАНА система сама
записала собі галузь у паспорті. У реєстрі 25 систем — галузь записана в
ОДНІЄЇ. Для решти ці ворота мовчать ЗАВЖДИ. Наш власний журнал це й показує:

    11.08.2026 18:42:44 | legal_assistant | public_procurement | evidence | conflict=False

Номер закупівлі в тексті БУВ, галузь платформа визначила правильно — і все одно
спокійно повела роботу Юристом. Це піввороти: «ні зайвому» є, «а чи не лишається
клієнт без того, що йому вже відкрито» — немає.

    ПИТАННЯ, ЯКЕ СТАВИТЬ ЦЕЙ МОДУЛЬ: не «чи згадано закупівлю», а
    «ЧИ ПРЕТЕНДУЄ ОБРАНА СИСТЕМА НА ЦЮ ТВЕРДУ ОЗНАКУ».

Різниця не косметична. «Є номер → завжди Тендерайтер» — надто грубо: юридичне
питання ПРО закупівлю законно веде Юрист. Претензія — це заява СИСТЕМИ про себе,
а не перелік слів у запиті.

ДЕ ЖИВЕ ПОЛЕ (рішення Андрія 25.08.2026). У паспорті системи в реєстрі
(`registry/systems.json`), поруч із полем `domain`:

    "claims": ["tender_id"]

⚠ НЕ в `.routing_card.json`. Паспорт призначення складає МОДЕЛЬ із промпта
системи і він має відбиток джерела: правка промпта робить його недійсним, а
службова дія перескладає його наново. Запобіжник, покладений туди, вимкнувся б
ТИХО — рівно той мертвий якір, який ми вже проходили.

⚠ ОЗНАКА ЗВЕТЬСЯ `tender_id`, А НЕ `procurement_reference`. Ім'я вже існує в
довіднику (`domains.KNOWN_EVIDENCE`), і номер розбирає один писар (`tender_ref`).
Друге ім'я тій самій межі — це та сама хвороба «межа у двох місцях».

ЧОГО ТУТ НЕМАЄ. Жодного переліку слів. Жодної моделі. Жодного рішення «казати чи
мовчати» — модуль лише КАЖЕ, що бачить; емітить той, у кого є канал до людини.
"""

import registry

# Поле паспорта. Мовчання паспорта = «не претендую», і це нормальний стан:
# 24 системи з 25 не змінюють поведінки взагалі.
FIELD = "claims"

# Хто саме обрав систему. Претензія переписує вибір МОЗКУ — і ніколи вибір
# людини. Розклад, ланцюг і телеграм — це теж вибір людини, зроблений
# заздалегідь: там правило лише КАЖЕ.
ORIGIN_BRAIN = "brain"

# Як платформа називає ознаку людині. Текст складає ПЛАТФОРМА, не модель.
_EVIDENCE_TITLE = {"tender_id": "номер закупівлі"}


def _log(msg):
    try:
        import llm
        llm._log("[route_claim] %s" % msg)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 1. ЗАКРИТИЙ ПЕРЕЛІК ОЗНАК — ОДИН ПИСАР
# ---------------------------------------------------------------------------
def known_evidence() -> tuple:
    """Дозволені імена ознак. Питаємо ДОВІДНИК, свого переліку не заводимо.

    ⛔ Перелік закритий навмисно: друкарська помилка в json не сміє тихо
    вимкнути запобіжник — незнайоме ім'я просто не існує."""
    try:
        import domains
        return tuple(domains.KNOWN_EVIDENCE)
    except Exception as e:
        _log("довідник ознак недоступний: %s" % e)
        return ()


def claims_of(system) -> tuple:
    """На що претендує ця система за своїм паспортом. Незнайомі імена відкидаємо."""
    raw = ((system or {}) if isinstance(system, dict) else {}).get(FIELD) or []
    if not isinstance(raw, (list, tuple)):
        return ()
    ok = set(known_evidence())
    return tuple(str(x).strip() for x in raw if str(x).strip() in ok)


# ---------------------------------------------------------------------------
# 2. ТВЕРДА ОЧЕВИДНІСТЬ У ТЕКСТІ — КОЖНУ ОЗНАКУ РОЗБИРАЄ ОДИН ПИСАР
# ---------------------------------------------------------------------------
def _mark_tender_id(text):
    try:
        import tender_ref
        got = tender_ref.find_all(str(text or ""))
        return got[0] if got else ""
    except Exception as e:
        _log("розбір номера закупівлі не спрацював: %s" % e)
        return ""


_FINDERS = {"tender_id": _mark_tender_id}


def evidence_in(blob) -> tuple:
    """Які тверді ознаки СПРАВДІ стоять у тексті. Порожньо — норма (мовчимо)."""
    text = str(blob or "")
    if not text.strip():
        return ()
    out = []
    for ev in known_evidence():
        fn = _FINDERS.get(ev)
        if fn and fn(text):
            out.append(ev)
    return tuple(out)


def mark_of(evidence_id, blob) -> str:
    """Сам знак (номер), щоб назвати його людині дослівно."""
    fn = _FINDERS.get(str(evidence_id or ""))
    return fn(blob) if fn else ""


# ---------------------------------------------------------------------------
# 3. ХТО ПРЕТЕНДУЄ — ТІЛЬКИ СЕРЕД СИСТЕМ, ДОСТУПНИХ КЛІЄНТУ
# ---------------------------------------------------------------------------
def claimants(evidence_id, exclude_id="") -> list:
    """⚠ Питаємо `registry.load_systems()`, а не наш повний реєстр: у клієнта
    може не бути купленої системи. Правило не сміє обіцяти те, чого в нього
    фізично немає — інакше платформа переписує маршрут у нікуди."""
    ev = str(evidence_id or "").strip()
    out = []
    try:
        for s in registry.load_systems():
            if (s or {}).get("id") == exclude_id:
                continue
            if ev in claims_of(s):
                out.append(s)
    except Exception as e:
        _log("перелік претендентів не склався: %s" % e)
    return out


# ---------------------------------------------------------------------------
# 4. РІШЕННЯ — П'ЯТЬ ВИПАДКІВ І ЖОДНОГО ШОСТОГО
# ---------------------------------------------------------------------------
def _name(system):
    s = system if isinstance(system, dict) else {}
    return s.get("name") or s.get("id") or "система"


def _silent():
    return {"action": "silent", "reason": "", "evidence": "", "mark": "",
            "to": None, "to_id": "", "line": ""}


def decide(system, blob, origin="") -> dict:
    """⭐ ГОЛОВНА ФУНКЦІЯ. Чиста і детермінована: ті самі входи — той самий вихід.

    Саме тому її можна кликати і в мозку, і в єдиній точці запуску, не заводячи
    другого писаря правди.

    action:
      silent  — нічого не сталося (ознаки немає, або обрана система претендує);
      rewrite — маршрут переписує ПРАВИЛО (претендує рівно одна інша, обрав мозок);
      say     — маршрут НЕ чіпаємо, але людина мусить це побачити.
    """
    chosen = system if isinstance(system, dict) else {}
    chosen_name = _name(chosen)
    for ev in evidence_in(blob):
        if ev in claims_of(chosen):
            continue                      # обрана система претендує — мовчимо
        title = _EVIDENCE_TITLE.get(ev, ev)
        mark = mark_of(ev, blob)
        cands = claimants(ev, exclude_id=chosen.get("id") or "")
        base = {"evidence": ev, "mark": mark, "to": None, "to_id": ""}

        if not cands:
            # Клієнт не має системи, яка веде таку роботу. Маршрут не чіпаємо,
            # але мовчати не можна: інакше він не дізнається, що роботу вели не
            # тим шляхом. Це і є «зробити помилку видимою», вбудоване в ворота.
            base.update({"action": "say", "reason": "no_claimant",
                         "line": ("⚠ У задачі %s %s — роботу веде «%s», не тендерна система."
                                  % (title, mark, chosen_name))})
            return base

        if len(cands) > 1:
            # Правило не сміє вгадувати. Кажемо і лишаємо як обрано.
            names = ", ".join("«%s»" % _name(c) for c in cands)
            base.update({"action": "say", "reason": "ambiguous",
                         "line": ("⚠ У задачі %s %s — на нього претендує кілька систем (%s). "
                                  "Веду «%s», як обрано." % (title, mark, names, chosen_name))})
            return base

        one = cands[0]
        base.update({"to": one, "to_id": one.get("id") or ""})
        if str(origin or "") == ORIGIN_BRAIN:
            base.update({"action": "rewrite", "reason": "rewritten",
                         "line": ("🔒 У задачі %s %s — веду системою «%s», а не «%s»."
                                  % (title, mark, _name(one), chosen_name))})
            return base
        # Вибір зробила ЛЮДИНА (розклад, ланцюг, налаштування) — не переписуємо.
        base.update({"action": "say", "reason": "not_brain",
                     "line": ("⚠ У задачі %s %s — роботу веде «%s», як налаштовано. "
                              "Тендерну роботу виконує «%s»."
                              % (title, mark, chosen_name, _name(one)))})
        return base
    return _silent()


def is_decision(d) -> bool:
    """Чи це справді готове рішення, а не випадковий словник.

    ⭐ Той, хто вже вирішив, ПЕРЕДАЄ рішення далі; той, хто отримав, — БЕРЕ, а
    не перевирішує. Прийом доведений живим прогоном 11.08.2026: два місця
    кликали одного писаря з РІЗНИМИ входами (мозок бачить запит людини, виконавець
    лише задачу) — і результат розходився МОВЧКИ."""
    return (isinstance(d, dict)
            and d.get("action") in ("silent", "rewrite", "say"))


def system_to_run(system, decision):
    """Система, яка СПРАВДІ побіжить після правила.

    ⚠ Викликати ПЕРЕД воротами прав. Якщо переписати маршрут після них, клієнт
    запустить систему, до якої в нього немає доступу, — ворота перевірили б не ту."""
    d = decision if isinstance(decision, dict) else {}
    if d.get("action") != "rewrite":
        return system
    return d.get("to") or system


# ---------------------------------------------------------------------------
# 5. СЛІД — ЗАВЖДИ, І КОЛИ ПРОЙШЛИ МОВЧКИ ТЕЖ
# ---------------------------------------------------------------------------
def trace(decision, system=None, actor="", origin="") -> bool:
    """Рядок у той самий журнал, куди пише слід розуміння. Один писар файла."""
    d = decision if isinstance(decision, dict) else {}
    if d.get("action") == "silent":
        return False
    try:
        import audit
        return audit.log_event({
            "kind": "route_claim",
            "event": d.get("action") or "",
            "reason": d.get("reason") or "",
            "system_id": (system or {}).get("id") if isinstance(system, dict) else "",
            "to_id": d.get("to_id") or "",
            "evidence": d.get("evidence") or "",
            "mark": d.get("mark") or "",
            "origin": str(origin or ""),
            "actor": str(actor or ""),
        })
    except Exception as e:
        _log("слід не записався: %s" % e)
        return False
