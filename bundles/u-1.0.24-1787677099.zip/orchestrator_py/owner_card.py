# -*- coding: utf-8 -*-
"""owner_card.py — КАРТКА УЧАСНИКА: читаємо файл клієнта, кладемо в базу знань.

⭐⭐⭐ 24.08.2026, зміна 209. ОБІЦЯНКА, ЯКОЇ КОД НЕ ВИКОНУВАВ.
Клієнту обіцяно: «покладіть у теку бази знань файл із даними компанії — платформа
візьме реквізити звідти й підставить у документи». Насправді код лише ЗНАХОДИВ
файл за словом у НАЗВІ і запам'ятовував шлях; вміст не читав НІХТО. Назва й
ЄДРПОУ бралися тільки з `owner.json`, якого не було ні в кого. Тому в пакеті
Каспера стояли прочерки там, де дані в нього на диску лежали.

⛒ ЗАКОН ЦЬОГО МОДУЛЯ:
  1. Витяг ДЕТЕРМІНОВАНИЙ — правила, а не модель. Той самий файл на будь-якій
     машині дає той самий результат, і це не коштує грошей.
  2. Чого в файлі немає — того НЕМАЄ. Порожня графа чесніша за вигадану адресу;
     жодного «домалювати за схожістю».
  3. Прочитане ЗБЕРІГАЄТЬСЯ в базу знань (`owner.json`) — клієнт дає файл один
     раз, а не перед кожним пакетом.
  4. Нове не затирає старе мовчки: порожнє поле з нового файла лишає те, що вже
     було, а непорожнє — оновлює і це видно в журналі.
"""

import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
PACK_DIR = os.path.join(HERE, "knowledge_packs", "tender_casper")
OWNER_FILE = os.path.join(PACK_DIR, "owner.json")

# Поля картки. Порядок = порядок показу людині в переліку «чого бракує».
FIELDS = ("name", "edrpou", "address", "phone", "email", "iban", "bank",
          "director", "director_post")

HUMAN = {
    "name": "повна назва учасника",
    "edrpou": "код ЄДРПОУ",
    "address": "юридична адреса",
    "phone": "телефон",
    "email": "e-mail",
    "iban": "рахунок IBAN",
    "bank": "банк",
    "director": "підписант (прізвище та ініціали)",
    "director_post": "посада підписанта",
}

# Слова, за якими впізнаємо, що цей файл — картка підприємства.
CARD_WORDS = ("реквізит", "rekvizyt", "картка підприємства", "картка пiдприємства",
              "картка контрагента", "картка компанії", "довідка про підприємство",
              "company card", "картка учасника")

# ⭐⭐⭐ 24.08.2026, зміна 213. КАРТКА — ЦЕ МАЛИЙ ЩІЛЬНИЙ ФАЙЛ, А НЕ БУДЬ-ЩО,
# ДЕ ТРАПИЛОСЬ СЛОВО «ЄДРПОУ».
# 🩸 Куплено власним дефектом того ж вечора: тендерна документація замовника
# теж містить «ЄДРПОУ», «юридична адреса», «МФО» — і код узяв ЇЇ за картку
# учасника. У базу знань лягло сміття: ЄДРПОУ ЗАМОВНИКА (військової частини),
# уривок абзацу замість назви, шматок таблиці замість адреси. Далі це поїхало б
# у шапку КОЖНОЇ довідки — тобто учасник подався б із чужим кодом.
# ⛒ ТРИ РУБЕЖІ, і кожен уміє сказати «ні»:
#   1. РОЗМІР: картка підприємства — це аркуш, а не документація на 200 сторінок.
#   2. ЧУЖА ФОРМА: ознаки тендерної документації забороняють читати файл як картку.
#   3. ПРАВДОПОДІБНІСТЬ ЗНАЧЕННЯ: назва, адреса й підписант мають межі довжини,
#      а сміття з таблиць («|») не є значенням.
MAX_CARD_CHARS = 20000
NOT_A_CARD = ("тендерна документація", "оголошення про проведення",
              "предмет закупівлі", "тендерна пропозиція", "замовник:",
              "додаток до тендерної", "кваліфікаційні критерії",
              "проект договору", "проєкт договору")
_LIMITS = {"name": 120, "address": 200, "director": 80, "bank": 120,
           "director_post": 40}

# 🩸 МЕЖА СЛОВА — НЕ ПРИКРАСА. Без \b форма «ДП» ловилась усередині слова
# «ПІ-ДП-РИЄМСТВА», і назвою учасника ставало «ДПРИЄМСТВА» (чек 24.08).
_ORG = re.compile(
    r"\b((?:ТОВ|ТзОВ|ПП|ПРАТ|ПрАТ|ПАТ|АТ|ТДВ|ФОП|КП|ДП|КНП)\s*[«\"']?"
    r"[^\n«»\"']{2,90}[»\"']?)",
    re.IGNORECASE)
_EDRPOU = re.compile(r"(?:ЄДРПОУ|ЕДРПОУ|код\s+ЄДРПОУ)\D{0,20}(\d{8})", re.IGNORECASE)
_EDRPOU_BARE = re.compile(r"\b(\d{8})\b")
_IBAN = re.compile(r"\b(UA\d{2}[0-9A-Z]{25})\b", re.IGNORECASE)
_EMAIL = re.compile(r"\b([A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,})\b")
_PHONE = re.compile(r"((?:\+?38)?[\s\-(]*0\d{2}[\s\-)]*\d{3}[\s\-]*\d{2}[\s\-]*\d{2})")


def _line_after(text: str, words, stop_at_colon=True) -> str:
    """Значення після назви графи в тому самому рядку або в наступному."""
    lines = [l.strip() for l in (text or "").splitlines()]
    for i, ln in enumerate(lines):
        low = ln.lower()
        for w in words:
            p = low.find(w)
            if p < 0:
                continue
            tail = ln[p + len(w):].strip(" \t:—–-|")
            if stop_at_colon:
                tail = tail.strip()
            if len(tail) >= 3:
                return tail
            for j in (i + 1, i + 2):
                if j < len(lines) and len(lines[j].strip(" \t:—–-|")) >= 3:
                    return lines[j].strip(" \t:—–-|")
    return ""


def looks_like_card(name: str, text: str = "") -> bool:
    """Чи це картка підприємства — за назвою файла АБО за вмістом.

    🩸 Правило дивилось лише на назву: «Дані компанії.docx» повз (зміна 209).
    🩸 Потім дивилось лише на слова: тендерна документація замовника пройшла
    як картка учасника (зміна 213). Тепер — три рубежі, див. коментар вище.
    """
    body = (text or "").lower()
    low = (name or "").lower()
    # ⛒ РУБІЖ 2 працює НАВІТЬ на «правильну» назву: файл, який виглядає
    # тендерною документацією, карткою не стає ніколи.
    if any(w in body for w in NOT_A_CARD):
        return False
    # ⛒ РУБІЖ 1: занадто великий файл — не картка, хай навіть так названий.
    if len(text or "") > MAX_CARD_CHARS:
        return False
    if any(w in low for w in CARD_WORDS):
        return True
    if not body:
        return False
    hits = sum(1 for w in ("єдрпоу", "iban", "юридична адреса", "місцезнаходження",
                           "розрахунковий рахунок", "мфо") if w in body)
    return hits >= 3


def blocks(files_context: str):
    """Прикріплені файли ПООДИНЦІ: [(назва, текст)].

    ⛒ Судити треба ФАЙЛ, а не злиття всього, що людина принесла в чат: саме
    злиття й дало змогу тендерній документації видати себе за картку.
    """
    out, cur_name, cur = [], "", []
    for line in (files_context or "").splitlines():
        if line.startswith("## Файл: "):
            if cur_name or cur:
                out.append((cur_name, "\n".join(cur)))
            cur_name, cur = line[len("## Файл: "):].strip(), []
        else:
            cur.append(line)
    if cur_name or cur:
        out.append((cur_name, "\n".join(cur)))
    return [(n, t) for n, t in out if (n or (t or "").strip())]


# ═══════════════════════════════════════════════════════════════════════════
# ⭐⭐⭐ 25.08.2026, ЗМІНА 221. ЖИВИЙ ПРОГІН КАСПЕРА ПОКАЗАВ ТРИ РЕЧІ ОДРАЗУ.
#
# 1. Рубрика «це картка?» не впізнала ВИТЯГ З ЄДР — найофіційніший документ про
#    реквізити в країні. Їй бракувало двох слів зі списку: у витягу поле зветься
#    «Ідентифікаційний код», а не «ЄДРПОУ», і банківських слів там немає.
# 2. Витяг «рядок після слова» дав СМІТТЯ: адреса «юридичної особи», телефон
#    «0022410816», директор «а юридичної особи та про інших осіб…». Ворота
#    правдоподібності дивились лише на довжину — і пропустили б це в документ
#    ЗАМОВНИКУ. Прочерки в Каспера — заслуга випадковості, а не захисту.
# 3. У витягах усе лежить СТРУКТУРНО: «Графа:» і значення на цьому ж або
#    наступних рядках. Читати треба структуру, а не шукати слова.
#
# ⛒ ЗАКОН: значення, яке не схоже на значення СВОГО ТИПУ, — не значення.
#    Порожня графа чесніша за вигадану адресу.
# ═══════════════════════════════════════════════════════════════════════════

#: Графи документів → наші поля. Перший збіг виграє, тому «Місцезнаходження
#: юридичної особи» стоїть попереду «Адреса» (адреси засновників ідуть нижче
#: по тексту й не мають права стати адресою компанії).
_LABELS = (
    ("name", ("найменування юридичної особи", "повне найменування",
              "найменування суб", "повна назва", "назва учасника",
              "скорочене найменування юридичної особи")),
    ("edrpou", ("ідентифікаційний код", "код за єдрпоу", "код єдрпоу", "єдрпоу")),
    ("address", ("місцезнаходження юридичної особи", "податкова адреса",
                 "юридична адреса", "місцезнаходження", "юр. адреса",
                 "адреса реєстрації", "поштова адреса")),
    ("director", ("керівник", "директор", "підписант", "уповноважена особа")),
    ("director_post", ("посада",)),
    ("bank", ("найменування банку", "назва банку", "банк")),
    ("iban", ("рахунок", "iban", "п/р", "поточний рахунок")),
    ("phone", ("телефон", "тел.", "контактний телефон")),
    ("email", ("електронна пошта", "e-mail", "email", "ел. пошта")),
)

_ORG_FORMS = ("товариство з обмеженою відповідальністю", "тов", "приватне підприємство",
              "пп", "фоп", "фізична особа - підприємець", "приватне акціонерне",
              "прат", "пат", "акціонерне товариство", "державне підприємство", "дп")

_STREET = ("вул", "просп", "бульв", "бул.", "пров", "шосе", "площ", "набережн",
           "будинок", "буд.", "квартира", "офіс")

_NOISE_WORDS = ("юридичн", "особи", "відомості", "згідно", "наявності", "інших",
                "які можуть", "вчиняти", "суб'єкт", "суб’єкт", "господарюванн",
                "відсутні", "з реєстру", "платник")


def _norm_space(v):
    return re.sub(r"\s+", " ", str(v or "")).strip(" .,;:—–-")


def _is_label_line(ln: str) -> bool:
    """Рядок-графа: закінчується двокрапкою і сам по собі не є значенням."""
    s = (ln or "").strip()
    return s.endswith(":") and len(s) <= 160


def fields_by_label(text: str) -> dict:
    """⭐ ЧИТАННЯ ЗА СТРУКТУРОЮ. «Графа:» → значення на цьому ж рядку, а якщо
    там порожньо — наступні рядки до наступної графи.

    Саме тут гинув попередній витяг: у витягу з ЄДР «Місцезнаходження юридичної
    особи:» стоїть окремим рядком, а адреса — на ДВОХ наступних. Правило
    «рядок після слова» брало хвіст самої графи й видавало «юридичної особи»."""
    lines = [l.strip() for l in (text or "").splitlines()]
    out = {}
    for i, ln in enumerate(lines):
        if ":" not in ln:
            continue
        head, _, tail = ln.partition(":")
        key = _norm_space(head).lower()
        val = _norm_space(tail)
        if not val:
            parts = []
            for j in range(i + 1, min(i + 4, len(lines))):
                nxt = lines[j].strip()
                if not nxt:
                    break
                if _is_label_line(nxt) or ":" in nxt[:40]:
                    break
                parts.append(nxt)
            val = _norm_space(", ".join(
                p.strip(" ,;") for p in parts if p.strip(" ,;")))
        if val and key not in out:
            out[key] = val
    return out


# ── ВОРОТА ПРАВДОПОДІБНОСТІ ────────────────────────────────────────────────
def _ok_edrpou(v: str) -> bool:
    return bool(re.fullmatch(r"\d{8}|\d{10}", v or ""))


def _iban_ok(v: str) -> bool:
    """UA + 27 знаків І збіжна контрольна сума (стандарт ISO 13616, mod-97)."""
    s = re.sub(r"\s+", "", (v or "").upper())
    if not re.fullmatch(r"UA\d{2}[0-9A-Z]{25}", s):
        return False
    moved = s[4:] + s[:4]
    num = "".join(str(ord(c) - 55) if c.isalpha() else c for c in moved)
    try:
        return int(num) % 97 == 1
    except Exception:
        return False


def _ok_address(v: str) -> bool:
    s = (v or "").lower()
    if len(s) < 12 or not re.search(r"\d", s):
        return False
    if not (re.search(r"\b\d{5}\b", s) or any(w in s for w in _STREET)):
        return False
    return not any(w in s for w in _NOISE_WORDS)


def normalize_phone(v: str) -> str:
    """Телефон або зводиться до +380XXXXXXXXX, або його немає."""
    d = re.sub(r"\D", "", v or "")
    if d.startswith("380") and len(d) == 12:
        d = d[2:]
    elif d.startswith("0") and len(d) == 10:
        pass
    elif len(d) == 9:
        d = "0" + d
    else:
        return ""
    if not re.fullmatch(r"0[3-9]\d{8}", d):
        return ""
    return "+38" + d


def _ok_director(v: str) -> bool:
    s = _norm_space(v)
    if any(w in s.lower() for w in _NOISE_WORDS):
        return False
    words = s.split()
    if not (2 <= len(words) <= 3):
        return False
    # ⚠ ІНІЦІАЛИ — ТЕЖ ІМʼЯ. «Подервінскас А. В.» мусить проходити, інакше
    # ворота відкинуть половину справжніх карток (спіймано власним набором
    # чеків одразу після написання воріт).
    full = 0
    for w in words:
        if not w[0].isupper():
            return False
        if not re.fullmatch(r"[^\W\d_][\w'’\-]*\.?", w, re.UNICODE) and \
           not re.fullmatch(r"(?:[^\W\d_]\.){1,2}", w, re.UNICODE):
            return False
        if len(w.rstrip(".")) >= 3:
            full += 1
    return full >= 1


def _ok_name(v: str) -> bool:
    s = _norm_space(v)
    if len(s) < 6 or any(w in s.lower() for w in _NOISE_WORDS):
        return False
    if re.search(r'[«"“”„][^«"“”„]{2,}[»"“”„]', s):
        return True
    # 🩸 25.08.2026, СПІЙМАНО ЖИВИМ ПРОГОНОМ: перевірка «починається з ТОВ»
    # пропускала слово «товару» (з назви теки «Матеріали про товар») — і воно
    # лягло в базу знань як НАЗВА УЧАСНИКА. Організаційна форма мусить стояти
    # ОКРЕМИМ СЛОВОМ, а не бути початком іншого слова.
    low = s.lower()
    for form in _ORG_FORMS:
        m = re.match(re.escape(form) + r"(?![\w'’\-])", low)
        if m:
            rest = _norm_space(s[m.end():])
            return len(rest) >= 3 and any(c.isalpha() for c in rest)
    return False


_GATES = {
    "edrpou": _ok_edrpou,
    "iban": _iban_ok,
    "address": _ok_address,
    "director": _ok_director,
    "name": _ok_name,
    "email": lambda v: bool(_EMAIL.fullmatch(v or "")),
    "phone": lambda v: bool(normalize_phone(v)),
    "bank": lambda v: 4 <= len(_norm_space(v)) <= 120 and not any(
        w in (v or "").lower() for w in _NOISE_WORDS),
    "director_post": lambda v: 3 <= len(_norm_space(v)) <= 60 and not any(
        w in (v or "").lower() for w in _NOISE_WORDS),
}


def _plausible(field: str, value: str) -> str:
    """⛒ ВОРОТА. Значення, яке не схоже на значення СВОГО ТИПУ, — не значення."""
    # ⚠ У ПІБ крапка після ініціала — ЧАСТИНА ІМЕНІ, а не пунктуація хвоста.
    # Загальна чистка її зрізала і робила «Подервінскас А. В» з «А. В.».
    if field == "director":
        v = re.sub(r"\s+", " ", str(value or "")).strip(" ,;:—–-")
    else:
        v = _norm_space(value)
    if not v or "|" in v:
        return ""
    lim = _LIMITS.get(field)
    if lim and len(v) > lim:
        return ""
    if field == "phone":
        return normalize_phone(v)
    gate = _GATES.get(field)
    if gate and not gate(v):
        return ""
    return v


def parse(text: str) -> dict:
    """Реквізити з тексту документа. Чого немає — того немає.

    Спершу СТРУКТУРА (графа: значення), потім — вільний пошук по тексту для
    того, що структурою не знайшлось. Кожне значення проходить ворота."""
    out = {k: "" for k in FIELDS}
    t = text or ""
    if not t.strip():
        return out

    labeled = fields_by_label(t)
    for field, keys in _LABELS:
        if out.get(field):
            continue
        for key in keys:
            for lab, val in labeled.items():
                if lab.startswith(key) or key in lab:
                    good = _plausible(field, val)
                    if good:
                        out[field] = good
                        break
            if out.get(field):
                break

    if not out["edrpou"]:
        m = _EDRPOU.search(t)
        if m:
            out["edrpou"] = _plausible("edrpou", m.group(1))
    if not out["name"]:
        m = _ORG.search(t)
        if m:
            out["name"] = _plausible("name", m.group(1))
    if not out["email"]:
        m = _EMAIL.search(t)
        if m:
            out["email"] = _plausible("email", m.group(1))
    if not out["phone"]:
        m = _PHONE.search(t)
        if m:
            out["phone"] = _plausible("phone", m.group(1))
    if not out["iban"]:
        m = _IBAN.search(t)
        if m:
            out["iban"] = _plausible("iban", m.group(1))
    if not out["director_post"]:
        low = t.lower()
        for post in ("генеральний директор", "директор", "керівник",
                     "уповноважена особа"):
            if post in low:
                out["director_post"] = post.capitalize()
                break
    return out


def harvest(files, exclude_edrpou: str = "") -> tuple:
    """⭐⭐⭐ КАРТКА ЗБИРАЄТЬСЯ З УСІХ ДОКУМЕНТІВ, А НЕ З ОДНОГО «ПРАВИЛЬНОГО».

    `files` — [(назва, текст)]. Повертає (картка, джерела), де джерела кажуть,
    З ЯКОГО ФАЙЛА взято кожне поле.

    🩸 Питання «чи є цей файл карткою реквізитів?» скасовано як хибне: воно
    втрачало все, що лежить у витягу з ЄДР, наказі й статуті. Питання тепер
    інше: «що з цього файла я можу ДОВЕСТИ?».

    ⛒ ЄДИНИЙ ЗАЛИШЕНИЙ РУБІЖ — тендерна документація ЗАМОВНИКА джерелом наших
    реквізитів не стає ніколи (урок змін 213 і 215), і код замовника не стає
    нашим кодом."""
    card = {k: "" for k in FIELDS}
    src = {}
    for name, text in (files or []):
        body = (text or "")
        if any(w in body.lower() for w in NOT_A_CARD):
            continue
        got = parse(body)
        for k in FIELDS:
            v = got.get(k) or ""
            if not v or card.get(k):
                continue
            if k == "edrpou" and exclude_edrpou and v == str(exclude_edrpou).strip():
                continue
            card[k] = v
            src[k] = name
    return card, src


def load() -> dict:
    """Картка з бази знань. Немає файла — порожня картка, а не аварія."""
    out = {k: "" for k in FIELDS}
    try:
        with open(OWNER_FILE, encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            for k in FIELDS:
                v = d.get(k)
                out[k] = str(v).strip() if v is not None else ""
    except Exception:
        pass
    return out


def save(card: dict) -> bool:
    """Кладе картку в базу знань. Порожнє НЕ затирає непорожнє."""
    cur = load()
    merged, changed = dict(cur), []
    for k in FIELDS:
        v = str((card or {}).get(k) or "").strip()
        if v and v != cur.get(k):
            merged[k] = v
            changed.append(k)
    if not changed:
        return False
    try:
        os.makedirs(PACK_DIR, exist_ok=True)
        with open(OWNER_FILE, "w", encoding="utf-8") as f:
            json.dump(merged, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def gaps(card: dict) -> list:
    """Чого бракує — словами клієнта, без назв наших файлів."""
    return [HUMAN[k] for k in FIELDS if not str((card or {}).get(k) or "").strip()]
