# -*- coding: utf-8 -*-
"""
notify_client_update.py — повідомити клієнта в Telegram, що вийшла нова версія.

ЧОМУ ОКРЕМИЙ СКРИПТ, А НЕ РУКАМИ.
    Клас проблеми — «другий писар правди про клієнта». Номер чату, набраний рукою
    в батнику, розійдеться з CRM тієї ж миті, коли клієнт зміниться. Тому:
      * ХТО клієнт — вирішує publish_update.canon_customer (імʼя з ліцензії через CRM);
      * КУДИ слати — бере CRM (channels.telegram_id), а не аргумент командного рядка;
      * ЯКА версія — бере config.APP_VERSION, той самий писар, що й у каналі оновлень.
    Немає привʼязки в CRM → СТОП, нічого не відправляємо (fail-closed): краще
    не надіслати, ніж надіслати чужій людині.

Текст іде через telegram_bot._send_message, тобто через ті самі ворота виходу
(вартовий tender_outbound + єдине вікно netfetch), що й решта каналу.
"""
import argparse
import sys

import config
import crm
import publish_update as pu
import telegram_bot as tb


TEXT = (
    "Андрію Володимировичу, вітаю!\n\n"
    "Для вашої програми SensFlow доступне оновлення {version}.\n\n"
    "Що змінилось:\n"
    "• Архів торгів шукає ваш товар не лише в назві тендера, а й у назві лота — "
    "торги, які раніше не потрапляли у звіт, тепер у ньому.\n"
    "• Усунуто дефект, через який довге імʼя переможця могло обірвати таблицю: "
    "кількість рядків у звіті й у файлі .xlsx тепер збігається.\n\n"
    "Щоб оновитись — відкрийте консоль і натисніть «Оновити». Це займе менше хвилини."
)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--customer", default="Casper", help="імʼя або псевдонім клієнта")
    ap.add_argument("--dry-run", action="store_true", help="показати і НЕ відправляти")
    a = ap.parse_args()

    name, why = pu.canon_customer(a.customer)
    if not name:
        print("  [X] STOP: %s" % why)
        print("      Відомі імена — у CRM (поле «Клієнт» або англійський псевдонім).")
        sys.exit(2)

    card = crm.get_client(name) or {}
    chat_id = str((card.get("channels") or {}).get("telegram_id") or "").strip()
    if not chat_id:
        print("  [X] STOP: у картці «%s» немає привʼязаного Telegram." % name)
        print("      Спершу привʼяжіть чат: crm.link_telegram(<клієнт>, <chat_id>).")
        sys.exit(2)

    text = TEXT.format(version=config.APP_VERSION)

    print("=" * 60)
    print("  Клієнт : %s" % name)
    print("  Чат    : %s" % chat_id)
    print("  Версія : %s (з config.APP_VERSION)" % config.APP_VERSION)
    print("=" * 60)
    print(text)
    print("=" * 60)

    if a.dry_run:
        print("DRY-RUN: нічого не відправлено.")
        return

    token = tb._support_token()
    if not token:
        print("  [X] STOP: не налаштований токен бота підтримки "
              "(TELEGRAM_SUPPORT_BOT_TOKEN).")
        sys.exit(2)

    tb._ctx.token = token
    tb._ctx.role = "support"
    ok = tb._send_message(chat_id, text)
    if not ok:
        print("  [X] FAILED: Telegram не прийняв повідомлення. Причина — вище.")
        sys.exit(1)

    try:
        crm.add_history(name, "outbound",
                        "Telegram: повідомлення про оновлення %s" % config.APP_VERSION)
    except Exception:
        pass
    print("OK: повідомлення надіслано клієнту «%s» (чат %s)." % (name, chat_id))


if __name__ == "__main__":
    main()
