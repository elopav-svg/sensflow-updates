# -*- coding: utf-8 -*-
"""
tender_legal.py — ⚖ ПРАВОВЕ ЯДРО ТЕНДЕРИСТА. ЄДИНЕ місце, де народжується
будь-яке твердження про СТРОК, ПРАВО чи ЗАБОРОНУ в тендері.

ЧОМУ ЦЕЙ МОДУЛЬ ІСНУЄ (Статут №15, 28.07.2026).

  КЛАС ПРОБЛЕМИ. 27.07.2026 клієнт двічі отримав від нас ХИБНІ строки.
  Не тому, що ми погано читали закон, — а тому, що ми не встановили ТИП
  ЗАКУПІВЛІ й підставили «типові» правила відкритих торгів у спрощену
  оборонну закупівлю. Клієнт міг готувати скаргу до АМКУ, якої в цій
  процедурі не існує, платити за неї 0,6 % очікуваної вартості — і при
  цьому проґавити реальне вікно, бо тут договір підписують уже наступного
  дня. Слова procurementMethodType у нашому коді не було ЖОДНОГО разу.
  Клас ширший за один тендер: «система називає правовий наслідок, не
  встановивши, який режим права діє».

  ТОЧКА РІШЕННЯ. Одна — тут. Не в складачі листа, не в чаті юриста, не в
  повідомленні сторожа. Строк не можна написати в коді: він живе лише в
  knowledge_packs\tender_law\regimes.json, разом із ДОСЛІВНОЮ цитатою,
  посиланням на статтю і датою звірки з першоджерелом.

  ВСІ КАНАЛИ. Telegram-сповіщення, DOCX-папір, відповідь у чаті системи,
  майбутній кабінет клієнта — усі беруть правову частину звідси й не
  мають права скласти її самі.

  ЧИ ПРОТЕЧЕ МАЙБУТНІЙ КАНАЛ. Так — якщо хтось напише «5 робочих днів»
  просто в тексті нового модуля. Домовленість на словах цього не втримає,
  тому tender_legal_test.py СКАНУЄ всі тендерні модулі й падає, коли
  знаходить зашитий строк або слово «АМКУ» поза ядром і базою норм.

ГОЛОВНЕ ПРАВИЛО (fail-closed):
  немає підтвердженого режиму -> ядро МОВЧИТЬ і каже, чого саме бракує.
  Мовчання коштує клієнту одного питання. Здогад коштував йому тендера.
"""
import json
import os
import re

PACK_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                         "knowledge_packs", "tender_law", "regimes.json")

# Замовники оборонного типу — для них додатково діє постанова КМУ 1275.
DEFENCE_KINDS = ("defense", "defence")
# Маркер, який має право ставити ЛИШЕ ядро: «режим права встановлено».
REGIME_MARK = "\u2696\ufe0f[режим встановлено ядром]"


class TenderLegalError(Exception):
    pass


# ---------------------------------------------------------------------------
# 0. Нормалізація тексту для звірки цитат
# ---------------------------------------------------------------------------
_APOSTROPHES = "’ʼ‘`´"
_DASHES = "‐‑‒–—―"


def normalize(text):
    """Готує текст до ДОСЛІВНОГО порівняння.

    Апостроф в українських актах трапляється щонайменше в чотирьох
    накресленнях, тире — в шести, а з .txt приїздять нерозривні пробіли.
    Без нормалізації звірка падала б на друкарні, а не на суті.
    """
    if not text:
        return ""
    out = str(text)
    for ch in _APOSTROPHES:
        out = out.replace(ch, "'")
    for ch in _DASHES:
        out = out.replace(ch, "-")
    out = out.replace(" ", " ").replace(" ", " ").replace(" ", " ")
    out = re.sub(r"\s+", " ", out)
    return out.strip().lower()


# ---------------------------------------------------------------------------
# 1. База норм
# ---------------------------------------------------------------------------
def load_pack(path=None):
    p = path or PACK_PATH
    if not os.path.exists(p):
        raise TenderLegalError("бази норм немає: %s" % p)
    with open(p, "r", encoding="utf-8") as fh:
        data = json.load(fh)
    if not isinstance(data.get("regimes"), dict):
        raise TenderLegalError("база норм зіпсована: немає розділу regimes")
    return data


def known_regimes(pack=None):
    pack = pack or load_pack()
    return sorted(pack["regimes"].keys())


# ---------------------------------------------------------------------------
# 2. Який режим права діє в цьому тендері
# ---------------------------------------------------------------------------
def regime_key(card):
    """Читає режим із КАРТКИ тендера. Нічого не вгадує.

    Повертає (ключ, подробиці). Ключ = None, якщо картка не дала
    потрібного поля — тоді викликач зобовʼязаний замовкнути.
    """
    card = card or {}
    method = (card.get("procurementMethodType") or "").strip()
    entity = card.get("procuringEntity") or {}
    kind = (entity.get("kind") or "").strip()

    details = {
        "procurementMethodType": method or None,
        "procuringEntity_kind": kind or None,
        "procuringEntity_name": entity.get("name"),
        "missing": [],
    }
    if not method:
        details["missing"].append("procurementMethodType (тип процедури)")
    if not kind:
        details["missing"].append("procuringEntity.kind (тип замовника)")
    if details["missing"]:
        return None, details

    family = "defense" if kind.lower() in DEFENCE_KINDS else "general"
    return "%s|%s" % (method, family), details


# ---------------------------------------------------------------------------
# 3. Правова позиція по тендеру — ЄДИНИЙ вихід назовні
# ---------------------------------------------------------------------------
def position(card, pack=None):
    """Правова позиція по конкретній картці тендера.

    ok=True  -> є звірений режим, можна писати строки людині.
    ok=False -> ЧЕСНИЙ СТОП: у stop лежить текст, який і показуємо людині.
                Жодних «типових» правил замість відповіді.
    """
    pack = pack or load_pack()
    key, details = regime_key(card)

    if key is None:
        return {
            "ok": False,
            "regime": None,
            "details": details,
            # ⭐ 28.07.2026: «не можу» без «ось як зробити, щоб змогла» —
            # для клієнта це просто відмова, за яку він заплатив гроші.
            "stop": ("Щоб дати строки саме по вашій закупівлі, мені потрібен її "
                     "номер у форматі UA-РРРР-ММ-ДД-XXXXXX-x. Надішліть його — і "
                     "я візьму тип процедури прямо з картки тендера й дам норми "
                     "з цитатами. Різні процедури мають різні строки, тому "
                     "називати їх навмання я не буду."),
            "norms": [],
            "not_available": [],
        }

    entry = pack["regimes"].get(key)
    if entry is None:
        return {
            "ok": False,
            "regime": key,
            "details": details,
            "stop": ("Ваша закупівля — «%s». Норм саме цього типу в моїй "
                     "звіреній базі поки немає, тому строки я не називаю.\n"
                     "ЩО ЗРОБИТИ: додати цю процедуру до бази норм — це разова "
                     "робота на нашому боці (звірка тексту закону з порталом "
                     "Ради), після неї відповідь буде миттєвою. Напишіть нам "
                     "номер цього тендера, і ми додамо процедуру.\n"
                     "Зараз я вже вмію: %s." % (key, ", ".join(known_regimes(pack)))),
            "norms": [],
            "not_available": [],
        }

    if not entry.get("verified"):
        return {
            "ok": False,
            "regime": key,
            "details": details,
            "stop": ("Ваша закупівля — %s. Норми цієї процедури вже підготовані, "
                     "але ще не звірені з першоджерелом, тому я їх не показую.\n"
                     "ЩО ЗРОБИТИ: звірка виконується автоматично під час "
                     "оновлення системи й займає секунди — попросіть оновлення, "
                     "і процедура запрацює."
                     % (entry.get("label") or key)),
            "norms": [],
            "not_available": [],
        }

    norms, dropped, dropped_live = [], [], []
    for norm in entry.get("norms") or []:
        if not (norm.get("quote") and norm.get("checked_at")):
            dropped.append(norm.get("id") or "?")
            continue
        item = dict(norm)
        state = (norm.get("live_state") or "").strip()
        if state == "missing":
            # Текст акта прочитано, а нашої цитати в ньому НЕМАЄ. Найімовірніше
            # норма змінилась. Показувати її людині небезпечніше, ніж мовчати.
            dropped_live.append("%s (цитати немає в чинному тексті, звірка %s)"
                                % (norm.get("id"), norm.get("live_checked_at") or "—"))
            continue
        if state != "found":
            item["live_note"] = ("жива звірка не вдалась%s — норма стоїть на ручній "
                                 "звірці %s" % (" " + norm["live_checked_at"]
                                                if norm.get("live_checked_at") else "",
                                                norm.get("checked_at")))
        norms.append(item)

    return {
        "ok": True,
        "regime": key,
        "label": entry.get("label"),
        "basis": entry.get("basis"),
        "details": details,
        "norms": norms,
        "not_available": list(entry.get("not_available") or []),
        "dropped": dropped,
        "dropped_live": dropped_live,
        "stop": None,
    }


def norm_value(pos, norm_id):
    """Значення однієї норми з позиції. Немає норми -> None, а не вигадка."""
    for norm in (pos or {}).get("norms") or []:
        if norm.get("id") == norm_id:
            return norm.get("value")
    return None


# ---------------------------------------------------------------------------
# 4. Звірка бази з першоджерелом (безкоштовно: мережа без моделі)
# ---------------------------------------------------------------------------
def verify_pack(fetch_text=None, pack=None):
    """Чи існують наші цитати ДОСЛІВНО в тексті актів на data.rada.gov.ua.

    fetch_text(nreg) -> текст акта. Не передали -> офлайн-режим: чесно
    кажемо «не перевірено», а не «все добре».
    """
    pack = pack or load_pack()
    if fetch_text is None:
        try:
            import legal_source_ua
            fetch_text = legal_source_ua.fetch_text
        except Exception:
            fetch_text = None

    verdicts, cache = [], {}
    for key, entry in sorted(pack["regimes"].items()):
        for norm in entry.get("norms") or []:
            row = {"regime": key, "id": norm.get("id"), "nreg": norm.get("nreg"),
                   "ref": norm.get("ref"), "quote": norm.get("quote")}
            if fetch_text is None:
                row["state"] = "unknown"
                row["note"] = "джерело недоступне (немає мережі) — НЕ вважати підтвердженим"
                verdicts.append(row)
                continue
            nreg = norm.get("nreg")
            if nreg not in cache:
                try:
                    cache[nreg] = normalize(fetch_text(nreg) or "")
                except Exception as exc:
                    cache[nreg] = ""
                    row["note"] = "помилка джерела: %s" % exc
            full = cache.get(nreg) or ""
            if not full:
                row["state"] = "unknown"
                row.setdefault("note", "текст акта не отримано")
            elif normalize(norm.get("quote")) in full:
                row["state"] = "found"
            else:
                row["state"] = "missing"
                row["note"] = "цитати НЕМАЄ в чинному тексті — норму не видавати людині"
            verdicts.append(row)
    return verdicts


def _save_pack(pack, path=None):
    with open(path or PACK_PATH, "w", encoding="utf-8") as fh:
        json.dump(pack, fh, ensure_ascii=False, indent=2)


def record_verification(verdicts, path=None):
    """Записує результат ЖИВОЇ звірки в базу норм.

    ⭐ 28.07.2026. Раніше лише проставляв live_state. Тепер жива звірка ще й
    ПІДТВЕРДЖУЄ норму: якщо цитата знайдена дослівно в тексті акта, норма
    отримує дату звірки й автора «жива звірка з першоджерелом». А режим, у
    якому кожна норма підтверджена і жодної діри, стає verified=True.
    Це прибирає ручний крок, через який цілі процедури лишались «не звіреними»
    і юрист мовчав на кожне питання клієнта.
    """
    path = path or PACK_PATH
    pack = load_pack(path)
    today = _today()
    by_key = {}
    for v in verdicts or []:
        by_key.setdefault(v.get("regime"), {})[v.get("id")] = v
    touched = 0
    for key, entry in pack.get("regimes", {}).items():
        seen = by_key.get(key) or {}
        if not seen:
            continue
        states = []
        for norm in entry.get("norms") or []:
            v = seen.get(norm.get("id"))
            if not v:
                continue
            state = v.get("state") or "unknown"
            norm["live_state"] = state
            norm["live_checked_at"] = today
            if state == "found" and not norm.get("checked_at"):
                norm["checked_at"] = today
                norm["checked_by"] = ("SensFlow — жива звірка з першоджерелом "
                                      "(data.rada.gov.ua)")
            states.append(state)
            touched += 1
        if states and all(x == "found" for x in states) and not entry.get("verified"):
            entry["verified"] = True
            entry["verified_by"] = "жива звірка всіх норм режиму, %s" % today
            entry.pop("why_not_verified", None)
    _save_pack(pack, path)
    return touched


def _today():
    import datetime
    return datetime.datetime.now().strftime("%d.%m.%Y")


def unverified(verdicts):
    """Ті норми, на які спиратись НЕ можна."""
    return [v for v in verdicts if v.get("state") != "found"]

# ── ВОРОТА СТРОКУ: день не називається, поки не встановлено режим ────────────
# ⭐ 28.07.2026. Живий прогін: на питання про строки юрист видав норми ЧУЖОЇ
# процедури — правила відкритих торгів, накладені на спрощену оборонну закупівлю.
# Це та сама помилка, проти якої будувалось це ядро, — просто ядро ніхто не
# покликав. Самі норми живуть у базі (regimes.json), а не тут; тут — лише
# правило доступу. Поки ядро не в ланцюгу, діє fail-closed: у тендерному
# контексті СТРОК У ДНЯХ без встановленого режиму не виходить як факт.
# Доказ, на якому це ловилось: test_cases\2026-07-28_wrong_regime_answer.txt
_TENDER_CTX = ("тендер", "закупівл", "прозорро", "prozorro", "намір укласти",
               "переможц", "оскарж", "скарг", "амку", "антимонопольн")

_DAY_CLAIM = re.compile(
    r"(?<![\w])(\d{1,3})\s*(?:робоч\w*\s+|календарн\w*\s+)?(дн\w*|доб\w*)",
    re.IGNORECASE)


def _has_tender_context(text):
    low = (text or "").lower()
    return any(k in low for k in _TENDER_CTX)


def deadline_claims(text):
    """Строки в днях, названі в ТЕНДЕРНОМУ контексті. Повертає список рядків
    (без дублікатів, у порядку появи). Порожній список = претензій немає."""
    if not _has_tender_context(text):
        return []
    out, seen = [], set()
    for m in _DAY_CLAIM.finditer(text or ""):
        frag = m.group(0).strip()
        key = frag.lower()
        if key not in seen:
            seen.add(key); out.append(frag)
    return out


def regime_established(text, card=None, pack=None):
    """Чи спирається текст на ВСТАНОВЛЕНИЙ режим права. Джерело істини — ядро:
    або нам дали картку тендера і position() дала норми, або в тексті стоїть
    маркер режиму, який ставить САМЕ ядро (а не модель)."""
    if card:
        try:
            pos = position(card, pack=pack)
            return bool(pos and pos.get("norms"))
        except Exception:
            return False
    return REGIME_MARK in (text or "")


def deadline_guard(text, card=None, pack=None):
    """ВОРОТА. Повертає список претензій (порожній = чисто).
    Правило одне: назвав дні в тендерному контексті — доведи режим."""
    claims = deadline_claims(text)
    if not claims:
        return []
    if regime_established(text, card=card, pack=pack):
        return []
    show = ", ".join("«%s»" % c for c in claims[:6])
    more = " та ще %d" % (len(claims) - 6) if len(claims) > 6 else ""
    return ["строк названо БЕЗ встановленого типу процедури (%s%s). "
            "Різні процедури живуть за різними нормами, і строк однієї не є "
            "строком іншої. Назвіть номер тендера (UA-…) — ядро візьме норми "
            "саме вашої процедури з бази." % (show, more)]

# ── ЯДРО В ЛАНЦЮГУ: норми до відповіді потрапляють З БАЗИ, а не з моделі ─────
# ⭐ 28.07.2026. Доти юрист відповідав із памʼяті моделі й вторинних сайтів, а це
# ядро стояло осторонь. Тепер: у питанні є номер тендера -> картка з Прозорро ->
# режим -> норми з бази. Модель лише ПЕРЕКАЗУЄ готовий блок; додати свою цифру
# вона не може — числа звіряються з базою (`numbers_outside_base`).
TENDER_ID_RE = re.compile(r"\bUA-\d{4}-\d{2}-\d{2}-\d{6}-[a-z0-9]\b", re.IGNORECASE)

_DAYS_RE = re.compile(r"(?<![\w])(\d{1,3})\s*(?:робоч\w*\s+|календарн\w*\s+)?(?:дн\w*|доб\w*)",
                      re.IGNORECASE)


def find_tender_id(text):
    m = TENDER_ID_RE.search(text or "")
    return m.group(0).upper() if m else None


def load_card(tender_id, src=None):
    """Картка тендера з офіційного API. Мережа є — модель не кличеться."""
    if src is None:
        import tender_source_ua as src
    uuid = None
    # ⭐ 01.08.2026: третій, ДОВЕДЕНИЙ шлях — картка за номером через фронтенд
    # Прозорро (`/api/tenders/<номер>/details`). Він працює для СТАРИХ тендерів,
    # яких міст не покриває, тому стоїть у черзі одразу за безкоштовним мостом.
    for getter in ("index_uuid", "card_id", "resolve"):
        fn = getattr(src, getter, None)
        if not fn:
            continue
        try:
            uuid = fn(tender_id)
        except Exception:
            uuid = None
        if isinstance(uuid, dict):
            uuid = uuid.get("uuid")
        if uuid:
            break
    if not uuid:
        return None
    try:
        return src.fetch_card(uuid)
    except Exception:
        return None


# ── ВИДИ НОРМ ────────────────────────────────────────────────────────────────
# ⭐ 28.07.2026 (зміна 19). Норма відповідає не лише на «скільки днів». Дві речі
# ми досі тримали в голові, а не в базі, — і саме вони найдорожчі:
#   basis      — ЧОМУ до цієї процедури застосовується САМЕ цей акт. Доти це була
#                моя думка; тепер це дослівна цитата акта, який прив'язку робить
#                (напр. п. 8 постанови 1275 прямо посилає оборонного замовника на
#                Особливості 1178). Думку не можна звірити з першоджерелом —
#                цитату можна.
#   effective  — КОЛИ норма діє. Особливості 1178 і постанова 1275 живуть лише на
#                час воєнного стану та 90 днів після нього. Строк без цієї умови
#                через рік стане пасткою: він виглядатиме звіреним і буде хибним.
# Обидві їдуть тим самим конвеєром, що й строки: цитата -> жива звірка з ВРУ.
KIND_BASIS = "basis"
KIND_EFFECTIVE = "effective"


def split_kinds(norms):
    """Розкладає норми на (строки, підстава акта, умова чинності)."""
    table, basis, effective = [], [], []
    for n in norms or []:
        kind = (n.get("kind") or "").strip()
        if kind == KIND_BASIS:
            basis.append(n)
        elif kind == KIND_EFFECTIVE:
            effective.append(n)
        else:
            table.append(n)
    return table, basis, effective


def render_norms(pos, tender_id="", from_thread=False):
    """Детермінований блок норм. Жодного слова від моделі.

    from_thread (28.07.2026): номер узято не з питання, а з попередніх реплік
    розмови. Людина мусить це БАЧИТИ — інакше юрист може тихо відповідати по
    старому тендеру, а клієнт думатиме, що по новому."""
    if not pos or not pos.get("norms"):
        return ""
    table, basis, effective = split_kinds(pos["norms"])
    out = ["## Норми вашої процедури (зі звіреної бази, не з памʼяті моделі)",
           "", "%s" % REGIME_MARK, ""]
    if tender_id:
        out.append("**Тендер:** %s" % tender_id)
    if from_thread:
        out.append("**Номер узято з нашої розмови** — у самому питанні його не було. "
                   "Якщо йдеться про інший тендер, напишіть його номер.")
    if pos.get("label"):
        out.append("**Процедура:** %s" % pos["label"])
    if pos.get("basis"):
        out.append("**Правова основа:** %s" % pos["basis"])
    for n in basis:
        out.append("**Чому саме цей закон:** %s" % n.get("value", ""))
    for n in effective:
        out.append("**Коли ці норми діють:** %s" % n.get("value", ""))
    out.append("")
    if table:
        out.append("| Питання | Норма | Підстава | Звірено |")
        out.append("|---|---|---|---|")
        for n in table:
            out.append("| %s | %s | %s, %s | %s |" % (
                _cell(n.get("topic", "")), _cell(n.get("value", "")), _cell(n.get("act", "")),
                _cell(n.get("ref", "")), _cell(n.get("checked_at", "—"))))
    na = pos.get("not_available") or []
    if na:
        out.append("")
        out.append("**Чого у вашій процедурі НЕМАЄ:**")
        for x in na:
            out.append("- %s — %s (%s)" % (x.get("topic", ""), x.get("value", ""),
                                           x.get("why", "")))
    out.append("")
    for n in pos["norms"]:
        if n.get("quote"):
            out.append("> «%s» — %s, %s" % (n["quote"], n.get("act", ""), n.get("ref", "")))
    return "\n".join(out)


def brief(text, src=None, pack=None, tender_id=None, from_thread=False):
    """Головна точка входу для юриста. Повертає:
    {tender_id, ok, pos, text, problem} або None, якщо номера немає.

    tender_id (28.07.2026): готовий номер від ЄДИНОГО резолвера контексту
    (`tender_context.resolve`) — коли людина питає «а далі?» без номера, його
    беруть із розмови. Свого пошуку по нитці тут НЕМАЄ: два писарі одного
    факту — головний убивця цієї системи."""
    tid = (tender_id or "").upper() or find_tender_id(text)
    if not tid:
        return None
    card = load_card(tid, src=src)
    if not card:
        return {"tender_id": tid, "ok": False, "pos": None, "text": "",
                "problem": "картку тендера %s не вдалося завантажити з Прозорро — "
                           "норми брати нізвідки" % tid}
    pos = position(card, pack=pack)
    if not pos or not pos.get("norms"):
        why = (pos or {}).get("stop") or (pos or {}).get("missing") or ""
        return {"tender_id": tid, "ok": False, "pos": pos, "text": "",
                "problem": "режим цього тендера у звіреній базі відсутній: %s" % (why or "—")}
    return {"tender_id": tid, "ok": True, "pos": pos,
            "text": render_norms(pos, tid, from_thread=from_thread), "problem": ""}


def base_numbers(pos):
    """Усі числа днів, які СПРАВДІ є у звіреній базі для цієї процедури.

    ⭐ 28.07.2026. Беруться ЛИШЕ строки. Умова чинності («90 днів після воєнного
    стану») і цитата-місток — не строки процедури; якби їхні числа потрапляли
    сюди, модель могла б написати «у вас 90 днів на оскарження» і пройти ворота.
    Білий список має бути найвужчим із можливих.
    """
    if not pos:
        return set()
    table, _basis, _eff = split_kinds(pos.get("norms") or [])
    blob = " ".join(str(n.get("value", "")) for n in table)
    blob += " " + " ".join(str(x.get("value", "")) for x in (pos.get("not_available") or []))
    return {m.group(1) for m in _DAYS_RE.finditer(blob)}


def shown_numbers(pos, tender_id="") -> set:
    """Числа днів, які платформа САМА друкує клієнту у блоці норм.

    ⭐⭐⭐ 30.07.2026 (три прогони Андрія поспіль без переліку дій — знайдено офлайн).
    Білий список `base_numbers` свідомо найвужчий (рішення 28.07): у ньому лише
    СТРОКИ, без умови чинності й без цитат. Задум правильний — модель не має права
    сказати «у вас 90 днів на оскарження».

    Але вийшло ось що. Промпт тендерного юриста ВИМАГАЄ окремим розділом писати
    «чого в цій процедурі НЕМАЄ» — а там якраз «етап документи переможця (4 дні)».
    І сам блок норм, який платформа друкує клієнту, містить «90 днів воєнного
    стану». Тобто агент, виконуючи свій промпт і повторюючи ТЕКСТ ПЛАТФОРМИ,
    гарантовано ловив вирок «вигадав число» — і його роботу викидали ЦІЛКОМ:
    ні переліку документів, ні плану дій до клієнта не доїжджало ЖОДНОГО разу.

    ⛔ ЗАБОРОНЯТИ ПОВТОРЮВАТИ ТЕ, ЩО САМ ДРУКУЄШ КЛІЄНТУ, — НЕ ВОРОТА, А ПАСТКА.
    Тому до білого списку додаємо рівно те, що людина й так бачить у нашому ж
    блоці: не всю базу, не сирий JSON — лише РЕНДЕР. Число, якого немає ні в
    строках, ні в надрукованому блоці, лишається вигадкою з тим самим наслідком.
    """
    try:
        rendered = render_norms(pos, tender_id=tender_id) or ""
    except Exception:
        return set()
    if isinstance(rendered, dict):
        rendered = rendered.get("text") or ""
    return {m.group(1) for m in _DAYS_RE.finditer(str(rendered))}


def numbers_outside_base(text, pos, tender_id=""):
    """Числа днів, які модель назвала, а в базі їх НЕМАЄ. Це і є вигадка."""
    if not pos:
        return []
    allowed = base_numbers(pos) | shown_numbers(pos, tender_id)
    seen, bad = set(), []
    for m in _DAYS_RE.finditer(text or ""):
        num = m.group(1)
        if num in allowed or num in seen:
            continue
        seen.add(num)
        bad.append(m.group(0).strip())
    return bad


def _cell(v):
    """Тонкий виклик до ОДНОГО писаря клітинки (`artifacts.table_cell`).

    ⭐⭐⭐ 02.08.2026. Тут значення з джерела йшли в таблицю НАПРЯМУ. Рівно на
    цьому в архіві торгів імʼя переможця з переносами `\r` розірвало рядок і
    тихо забрало з .xlsx усе, що було нижче. Юридична таблиця — той самий клас:
    назва акта чи цитата з переносом зробила б те саме в документі клієнта.
    """
    try:
        import artifacts as _A
        return _A.table_cell(v)
    except Exception:
        s = ("" if v is None else str(v)).replace("|", "/")
        return " ".join(s.split()) or "—"
