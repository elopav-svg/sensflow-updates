"""
tools.py — шар інструментів оркестратора (агентність як у Клода).

Розширюваний реєстр інструментів, доступних мозку й агентам. Зараз:
  - web_search: живий пошук в інтернеті з джерелами (нативний інструмент провайдера);
  - fetch_url: завантаження і читання конкретної веб-сторінки (stdlib).

Усе деградує мʼяко: якщо інструмент недоступний, повертається ok=False з поясненням,
а не виняток, щоб запуск системи не падав.
"""

import re
import time
import html as _html
import urllib.request
import urllib.error

import config
import llm
import page_render
import netfetch
import pagespeed


def _decode_response(resp, cap: int) -> str:
    """Тонка обгортка над спільним читачем netfetch — єдине місце розпакування
    (gzip/deflate/br) для ВСІХ систем платформи."""
    return netfetch.decode_response(resp, cap)


def web_search(query: str, context: str = "") -> dict:
    """Повертає {ok, text, sources:[{title,url}], note}."""
    if not config.web_search_ready():
        return {"ok": False, "text": "", "sources": [],
                "note": "веб-пошук недоступний (вимкнено або немає ключа провайдера)"}
    system = (
        "Ти — дослідник із доступом до веб-пошуку. Знайди АКТУАЛЬНУ, достовірну "
        "інформацію за запитом користувача. Дай стислий фактичний підсумок "
        "українською і спирайся на конкретні джерела. Не вигадуй фактів; якщо даних "
        "недостатньо — чесно зазнач це."
    )
    user = f"Пошуковий запит: {query}" + (f"\n\nКонтекст задачі: {context}" if context else "")
    try:
        res = llm.search_complete(system, user)
        return {"ok": True, "text": res.get("text", ""), "sources": res.get("sources", []),
                "used_search": res.get("used_search", False), "note": ""}
    except (llm.LLMError, llm.LLMNotConfigured) as e:
        return {"ok": False, "text": "", "sources": [], "note": f"пошук не вдався: {e}"}


_TAG_RE = re.compile(r"<(script|style)[^>]*>.*?</\1>", re.S | re.I)
_ANYTAG_RE = re.compile(r"<[^>]+>")


def fetch_url(url: str, max_chars: int = 8000) -> dict:
    """Завантажує http/https-сторінку і повертає очищений текст. {ok, text, note}."""
    if not (url or "").lower().startswith(("http://", "https://")):
        return {"ok": False, "text": "", "note": "дозволені лише http/https URL"}
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "AI-Orchestrator/1.0",
            "Accept-Encoding": "gzip, deflate"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            ctype = resp.headers.get("Content-Type", "")
            text = _decode_response(resp, 2_000_000)  # до 2 МБ, з розпакуванням
        # Гібрид-драбина: якщо сторінка — порожня JS-оболонка, дорендерити її
        # локальним браузером (напряму, приватно). Нема браузера — тихо лишаємось.
        if page_render.looks_js_empty_raw(text):
            _r_html, _ = page_render.render_html(url)
            if _r_html:
                text = _r_html
                ctype = "text/html"
        if "html" in ctype or "<html" in text[:500].lower():
            text = _TAG_RE.sub(" ", text)
            text = _ANYTAG_RE.sub(" ", text)
            text = _html.unescape(text)
            text = re.sub(r"[ \t]+", " ", text)
            text = re.sub(r"\n\s*\n\s*\n+", "\n\n", text)
        text = text.strip()
        if len(text) > max_chars:
            text = text[:max_chars] + "\n…[обрізано]"
        return {"ok": True, "text": text, "note": ""}
    except urllib.error.URLError as e:
        return {"ok": False, "text": "", "note": f"не вдалося завантажити: {e}"}
    except Exception as e:  # noqa
        return {"ok": False, "text": "", "note": f"помилка читання сторінки: {e}"}


def read_page_seo(url: str, max_body: int = 16000) -> dict:
    """Структуроване читання сторінки для SEO/GEO-аудиту (на відміну від fetch_url,
    що віддає плаский обрізаний текст і губить атрибути). Дістає з СИРОГО HTML:
    title, meta description, og-теги, canonical, hreflang, усі H1/H2/H3, наявні
    типи JSON-LD (schema.org), статистику alt — і основний текст (очищений від
    меню/скриптів). Сигнали завжди повні; скорочується лише «тіло». {ok, text, note}."""
    if not (url or "").lower().startswith(("http://", "https://")):
        return {"ok": False, "text": "", "note": "дозволені лише http/https URL",
                "final_url": url, "redirected": False, "thin": True}
    final_url = url
    # Стійкість до МОРГАННЯ на краю мережі (Netlify edge / атомарний передеплой):
    # один транзиторний 404/5xx/таймаут НЕ має вбивати весь SEO-прогін. Дзеркалимо
    # логіку _http_post у llm.py — до 3 спроб із короткою паузою на ТИМЧАСОВИХ збоях;
    # постійні (403/SSL/DNS/справді відсутня сторінка після повторів) — віддаємо як є.
    _TRANSIENT_HTTP = {404, 408, 425, 429, 500, 502, 503, 504, 522, 524, 529}
    src = ctype = None
    for _attempt in range(1, 4):                 # разом до 3 спроб
        try:
            req = urllib.request.Request(url, headers={
                "User-Agent": "AI-Orchestrator/1.0 (SEO audit)",
                "Accept-Encoding": "gzip, deflate"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                final_url = resp.geturl() or url   # адреса ПІСЛЯ всіх перенаправлень
                ctype = resp.headers.get("Content-Type", "")
                src = _decode_response(resp, 3_000_000)  # до 3 МБ, з розпакуванням
            break                                   # успіх — виходимо з циклу
        except urllib.error.HTTPError as e:
            # HTTPError — підклас URLError, тож ловимо його ПЕРШИМ. 404 від Netlify
            # часто транзиторний (моргання під час деплою) — тому в списку повторів.
            if e.code in _TRANSIENT_HTTP and _attempt < 3:
                time.sleep(0.5 * _attempt)
                continue
            return {"ok": False, "text": "", "note": f"не вдалося завантажити: {e}",
                    "final_url": url, "redirected": False, "thin": True}
        except urllib.error.URLError as e:
            _r = str(getattr(e, "reason", e)).lower()
            _transient = ("timed out" in _r or "timeout" in _r or "connection" in _r
                          or "reset" in _r or "temporarily" in _r or "unreachable" in _r)
            if _transient and _attempt < 3:
                time.sleep(0.5 * _attempt)
                continue
            return {"ok": False, "text": "", "note": f"не вдалося завантажити: {e}",
                    "final_url": url, "redirected": False, "thin": True}
        except Exception as e:  # noqa
            return {"ok": False, "text": "", "note": f"помилка читання сторінки: {e}",
                    "final_url": url, "redirected": False, "thin": True}

    # Чи повели нас на ІНШУ сторінку (перенаправлення / share-лінк)? М'яке порівняння:
    # ігноруємо http↔https, «www.» і хвостовий слеш — реагуємо лише на інший хост/шлях.
    def _norm_cmp(u):
        from urllib.parse import urlsplit
        p = urlsplit(u or "")
        host = (p.hostname or "").lower()
        if host.startswith("www."):
            host = host[4:]
        path = (p.path or "/").rstrip("/") or "/"
        return host, path
    redirected = _norm_cmp(url) != _norm_cmp(final_url)

    # Гібрид-драбина (Шар 2): якщо сира сторінка — порожня JS-оболонка, дорендерити
    # її локальним браузером (напряму, приватно), і далі вилучати сигнали вже з
    # готового DOM. Нема браузера/не вдалось — тихо лишаємось на сирому HTML
    # (флагман не падає, поведінка як була).
    _render_note = ""
    if page_render.looks_js_empty_raw(src):
        _r_html, _r_note = page_render.render_html(url)
        if _r_html:
            src = _r_html
            ctype = "text/html"
            _render_note = _r_note

    if not ("html" in ctype.lower() or "<html" in src[:1000].lower()):
        return {"ok": True, "text": src.strip()[:max_body], "note": "не-HTML вміст",
                "final_url": final_url, "redirected": redirected, "thin": False}

    def _one(pat):
        m = re.search(pat, src, re.I | re.S)
        return _html.unescape(m.group(1)).strip() if m else ""

    def _meta(name, attr="name"):
        m = re.search(rf'<meta[^>]+{attr}=["\']{re.escape(name)}["\'][^>]*content=["\'](.*?)["\']',
                      src, re.I | re.S)
        if not m:
            m = re.search(rf'<meta[^>]+content=["\'](.*?)["\'][^>]*{attr}=["\']{re.escape(name)}["\']',
                          src, re.I | re.S)
        return _html.unescape(m.group(1)).strip() if m else ""

    def _tags(tag):
        out = []
        for x in re.findall(rf"<{tag}[^>]*>(.*?)</{tag}>", src, re.I | re.S):
            t = _html.unescape(re.sub(r"<[^>]+>", " ", x))
            t = re.sub(r"\s+", " ", t).strip()
            if t:
                out.append(t)
        return out

    title = _one(r"<title[^>]*>(.*?)</title>")
    meta_desc = _meta("description")
    canonical = _one(r'<link[^>]+rel=["\']canonical["\'][^>]*href=["\'](.*?)["\']') \
        or _one(r'<link[^>]+href=["\'](.*?)["\'][^>]*rel=["\']canonical["\']')
    hreflangs = sorted(set(re.findall(r'<link[^>]+hreflang=["\'](.*?)["\']', src, re.I)))
    h1, h2, h3 = _tags("h1"), _tags("h2"), _tags("h3")
    ldjson = re.findall(r'<script[^>]+application/ld\+json[^>]*>(.*?)</script>', src, re.I | re.S)
    ld_types = sorted(set(re.findall(r'"@type"\s*:\s*"([^"]+)"', " ".join(ldjson))))
    imgs = re.findall(r"<img\b[^>]*>", src, re.I)
    n_noalt = sum(1 for i in imgs if not re.search(r'\balt=["\'][^"\']+["\']', i, re.I))

    body = _TAG_RE.sub(" ", src)
    body = re.sub(r"<(nav|header|footer|select|option|svg|style|script)[^>]*>.*?</\1>",
                  " ", body, flags=re.I | re.S)
    body = _ANYTAG_RE.sub(" ", body)
    body = _html.unescape(body)
    body = re.sub(r"[ \t]+", " ", body)
    body = re.sub(r"\n\s*\n\s*\n+", "\n\n", body).strip()

    def _lst(items, n):
        items = items[:n]
        return " | ".join(items) if items else "—"

    sig = [
        "== СИГНАЛИ SEO (повні, з сирого HTML) ==",
        f"URL: {url}",
        f"Title: {title or '❌ немає'}",
        f"Meta description: {meta_desc or '❌ ВІДСУТНІЙ у коді'}",
        f"OG: title={_meta('og:title','property') or '—'} | desc={_meta('og:description','property') or '—'} | image={_meta('og:image','property') or '—'}",
        f"Canonical: {canonical or '❌ не знайдено'}",
        f"hreflang: {', '.join(hreflangs) if hreflangs else '❌ немає'}",
        f"H1 ({len(h1)}): {_lst(h1, 5)}",
        f"H2 ({len(h2)}): {_lst(h2, 20)}",
        f"H3 ({len(h3)}): {_lst(h3, 25)}",
        f"JSON-LD schema.org: {', '.join(ld_types) if ld_types else '❌ НЕ ЗНАЙДЕНО (жодного @type)'}",
        f"Зображень: {len(imgs)}; без alt: {n_noalt}",
        "",
        "== ОСНОВНИЙ ТЕКСТ (очищено від меню/скриптів) ==",
    ]
    head = "\n".join(sig)
    budget = max(1200, max_body - len(head) - 60)
    if len(body) > budget:
        body = body[:budget] + "\n…[тіло скорочено; СИГНАЛИ вище — повні]"
    # Структуровані РЕАЛЬНІ факти сторінки — для детермінованого будівника schema.org
    # (schema_org.build_jsonld). Значення тільки з коду сторінки, не вигадані.
    facts = {
        "url": url,
        "title": title,
        "meta_desc": meta_desc,
        "canonical": canonical,
        "og_title": _meta("og:title", "property"),
        "og_desc": _meta("og:description", "property"),
        "og_image": _meta("og:image", "property"),
        "hreflangs": hreflangs,
        "h1": h1, "h2": h2, "h3": h3,
        "ld_types": ld_types,
        "n_imgs": len(imgs), "n_noalt": n_noalt,
    }
    # «Порожня оболонка»: навіть після спроби рендеру немає ні заголовка, ні H1, ні
    # опису, а тіло майже порожнє → сторінку по суті НЕ прочитано (JS-only / стіна входу).
    thin = (not title) and (not h1) and (not meta_desc) and len(body) < 200
    return {"ok": True, "text": head + "\n" + body, "note": _render_note, "facts": facts,
            "final_url": final_url, "redirected": redirected, "thin": thin}


_URL_RE = netfetch.URL_RE      # межа адреси — ОДИН писар (netfetch)


# ⭐⭐⭐ 09.08.2026. ЗНАЙШОВ ПОКАЖЧИК — IДИ ЗА ПОСИЛАННЯМ.
# 🩸 ЖИВИЙ ПРОВАЛ: пошук знаходив сторiнку-СПИСОК резюме (14 кандидатiв, 3939
# усього), платформа її вiдкривала — i зупинялась. У списку лише короткi пiдписи,
# а самi резюме лежать ЗА ПОСИЛАННЯМИ, куди нiхто не йшов. Модель дописувала
# «доступ закритий» i вигадувала кандидатiв.
# ⭐ СТОРIНКА-СПИСОК — ЦЕ НЕ ВIДПОВIДЬ, А ДОРОГОВКАЗ.
def page_record_links(url: str, limit: int = 6) -> list:
    """Посилання на ОКРЕМI записи зi сторiнки-покажчика (список резюме, товарiв,
    оголошень). Бере сирий HTML i лишає href того самого домену, чий шлях
    повторюється за одним шаблоном /щось/ЧИСЛО/ — саме так виглядають картки.
    Повертає [] для звичайної сторiнки: тодi нiчого зайвого не вiдкриваємо."""
    if not (url or "").lower().startswith(("http://", "https://")):
        return []
    try:
        req = urllib.request.Request(url, headers={
            "User-Agent": "AI-Orchestrator/1.0", "Accept-Encoding": "gzip, deflate"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            html_src = _decode_response(resp, 2_000_000)
    except Exception:
        return []
    from urllib.parse import urljoin, urlparse
    host = urlparse(url).netloc
    seen, out = set(), []
    for href in re.findall(r'<a[^>]+href=["\']([^"\']+)["\']', html_src, re.I):
        full = urljoin(url, href.split("#")[0])
        if urlparse(full).netloc != host:
            continue
        path = urlparse(full).path.rstrip("/")
        if not re.search(r"/\d{3,}$", path):      # картка запису: .../12518891
            continue
        if full.rstrip("/") == url.rstrip("/") or full in seen:
            continue
        seen.add(full)
        out.append(full)
        if len(out) >= limit:
            break
    return out


def fetch_urls_in_text(text: str, max_urls: int = 3) -> str:
    """Знаходить URL у тексті, завантажує їх і повертає об'єднаний контент для контексту."""
    urls = []
    for u in _URL_RE.findall(text or ""):
        u = u.rstrip(".,;")
        if u not in urls:
            urls.append(u)
        if len(urls) >= max_urls:
            break
    blocks = []
    for u in urls:
        r = fetch_url(u, max_chars=10000)
        if r.get("ok") and r.get("text"):
            blocks.append(f"## Текст за посиланням {u}\n{r['text']}")
        else:
            blocks.append(f"## Посилання {u}\n[не вдалося завантажити: {r.get('note','')}]")
    return "\n\n".join(blocks)


# ---------------------------------------------------------------------------
# Калькулятор run_python — точні числові обчислення («жодних чисел з голови»)
# ---------------------------------------------------------------------------
import ast as _ast
import os as _os
import subprocess as _subprocess
import sys as _sys
import tempfile as _tempfile

# Білий список імпортів: лише чиста математика/дані, без мережі та файлів.
_CALC_ALLOWED_IMPORTS = {
    "math", "statistics", "decimal", "fractions", "datetime", "json",
    "itertools", "functools", "collections", "random", "re", "calendar",
    "heapq", "numbers", "string",
}
_CALC_BANNED_NAMES = {
    "open", "exec", "eval", "compile", "__import__", "input",
    "globals", "locals", "vars", "breakpoint", "exit", "quit", "help",
}


def _calc_code_check(code: str):
    """Статична перевірка коду калькулятора (AST): лише безпечні імпорти,
    без файлів/мережі/службових атрибутів. Повертає (ok, пояснення)."""
    try:
        tree = _ast.parse(code)
    except SyntaxError as e:
        return False, f"синтаксична помилка в коді: {e}"
    for node in _ast.walk(tree):
        if isinstance(node, _ast.Import):
            for a in node.names:
                root = (a.name or "").split(".")[0]
                if root not in _CALC_ALLOWED_IMPORTS:
                    return False, (f"імпорт «{root}» заборонений; дозволені: "
                                   + ", ".join(sorted(_CALC_ALLOWED_IMPORTS)))
        elif isinstance(node, _ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            if root not in _CALC_ALLOWED_IMPORTS:
                return False, f"імпорт «{root}» заборонений"
        elif isinstance(node, _ast.Name) and node.id in _CALC_BANNED_NAMES:
            return False, f"«{node.id}» заборонений у калькуляторі"
        elif isinstance(node, _ast.Attribute) and str(node.attr).startswith("__"):
            return False, "доступ до службових атрибутів (__*) заборонений"
    return True, ""


def run_python(code: str, timeout_s: int = 15) -> dict:
    """Виконує короткий Python-код в ізольованому процесі. {ok, stdout, note}.
    Призначення: ТОЧНА арифметика для мозку й агентів (кредити, відсотки,
    статистика, фінмоделі). Захисти: AST-білий список (без мережі/файлів),
    окремий процес (python -I), ліміт часу, ліміт виводу. Код МУСИТЬ друкувати
    результати через print() — stdout і є відповіддю калькулятора."""
    code = (code or "").strip()
    if not code:
        return {"ok": False, "stdout": "", "note": "порожній код"}
    if len(code) > 20000:
        return {"ok": False, "stdout": "", "note": "код задовгий (понад 20К символів)"}
    ok, why = _calc_code_check(code)
    if not ok:
        return {"ok": False, "stdout": "", "note": why}
    env = dict(_os.environ)
    env["PYTHONIOENCODING"] = "utf-8"  # стабільне декодування на Windows
    try:
        with _tempfile.TemporaryDirectory() as tmp:
            # -I (ізоляція) ігнорує PYTHON*-змінні, тож кодування задаємо
            # прапорцем -X utf8 — інакше кирилиця в stdout ламається (Windows).
            proc = _subprocess.run(
                [_sys.executable, "-I", "-X", "utf8", "-c", code],
                capture_output=True, timeout=timeout_s, cwd=tmp, env=env)
    except _subprocess.TimeoutExpired:
        return {"ok": False, "stdout": "", "note": f"перевищено ліміт часу ({timeout_s} с)"}
    except Exception as e:  # noqa
        return {"ok": False, "stdout": "", "note": f"не вдалося виконати: {e}"}
    out = (proc.stdout or b"").decode("utf-8", errors="replace").strip()
    if len(out) > 12000:
        out = out[:12000] + "\n…[обрізано]"
    if proc.returncode != 0:
        err = (proc.stderr or b"").decode("utf-8", errors="replace").strip()[-1500:]
        return {"ok": False, "stdout": out, "note": f"код завершився з помилкою:\n{err}"}
    if not out:
        return {"ok": False, "stdout": "",
                "note": "код нічого не надрукував — додай print() з результатами"}
    return {"ok": True, "stdout": out, "note": ""}


def pagespeed_measure(url: str, strategy: str = "mobile") -> dict:
    """Реальна швидкість і Core Web Vitals сторінки від Google PageSpeed Insights
    (двигун Lighthouse). {ok, text, data, note}. Мʼяко деградує: нема мережі/квоти/
    даних — ok=False + людська причина, флагман не падає."""
    return pagespeed.measure(url, strategy)


def available_tools() -> list:
    """Опис інструментів для self-model і UI."""
    return [
        {"id": "web_search", "name": "Веб-пошук",
         "description": "Живий пошук в інтернеті з посиланнями на джерела.",
         "available": config.web_search_ready()},
        {"id": "fetch_url", "name": "Читання сторінки",
         "description": "Завантажити і прочитати конкретний URL.",
         "available": True},
        {"id": "run_python", "name": "Калькулятор",
         "description": "Точні числові розрахунки через ізольований Python "
                        "(жодних чисел «з голови»).",
         "available": True},
        {"id": "pagespeed_measure", "name": "Швидкість (PageSpeed)",
         "description": "Реальна швидкість і Core Web Vitals сторінки від Google "
                        "PageSpeed (Lighthouse) — вимір, а не здогад.",
         "available": pagespeed.available()},
    ]
