"""
registry.py — читання реєстру систем і стану конекторів.

Повторно використовує ваш існуючий registry/systems.json (BOM-safe) і
config/connectors/*.token.json. Нічого не переписує без явного запиту.
"""

import json
from pathlib import Path

import config


# ---------------------------------------------------------------------------
# Системи
# ---------------------------------------------------------------------------
def _read_json_bom_safe(path: Path, fallback):
    if not path.exists():
        return fallback
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return fallback


def load_registry() -> dict:
    """Повертає повний обʼєкт реєстру {schema_version, base_path, systems:[...]}."""
    data = _read_json_bom_safe(config.REGISTRY_JSON, {"systems": []})
    if isinstance(data, list):
        data = {"systems": data}
    data.setdefault("systems", [])
    return data


def load_systems() -> list:
    """⭐⭐⭐ 05.08.2026. ОДНА ТОЧКА, ДЕ НЕЗАВЕРШЕНА СИСТЕМА ЗНИКАЄ З ОЧЕЙ.

    Вимикач роботи (`features.enabled`) мусить питатися там, де систему БАЧАТЬ,
    а не там, де її вже запускають: інакше мозок обирає систему, яка в клієнта
    вимкнена, і людина дістає відмову замість роботи. Каталог для мозку,
    маршрутні проби, виконавець і телеграм читають той самий перелік — отже
    ворота стоять на всіх шляхах одразу.

    Система без прапорця видима завжди — старі системи нічого не втрачають."""
    systems = load_registry().get("systems", [])
    try:
        import features
        flagged = features.flagged_work_ids()
    except Exception:
        return systems
    if not flagged:
        return systems
    out = []
    for s in systems:
        sid = (s or {}).get("id", "")
        if sid in flagged and not features.enabled(sid):
            continue
        out.append(s)
    return out


def find_system(system_id: str):
    for s in load_systems():
        if s.get("id") == system_id:
            return s
    return None


def system_root(system: dict) -> Path:
    """Абсолютний шлях до папки системи — стійкий і на платформі, і в клієнтській збірці.

    Розкладка платформи й зібраного пакета різна (у пакеті generated_systems лежить
    у корені, без префікса з назвою кореня). Тому резолвимо за списком
    кандидатів і повертаємо ПЕРШИЙ, що реально існує:
      1) буквальний root_path відносно WORKSPACE_ROOT (стара поведінка платформи);
      2) той самий root_path відносно PLATFORM_ROOT (клієнтська розкладка);
      3) хвіст generated_systems/<...> відносно PLATFORM_ROOT;
      4) generated_systems/<id> відносно PLATFORM_ROOT (запасний за id).
    Якщо нічого не існує — повертаємо перший осмислений варіант (не падаємо)."""
    rp = (system or {}).get("root_path", "")
    sid = (system or {}).get("id", "")
    candidates = []
    if rp:
        rpp = rp.replace("\\", "/")
        p = Path(rpp)
        if p.is_absolute():
            candidates.append(p)
        else:
            candidates.append((config.WORKSPACE_ROOT / rpp).resolve())
            candidates.append((config.PLATFORM_ROOT / rpp).resolve())
            tail = rpp.split("generated_systems/", 1)[-1]
            if tail and tail != rpp:
                candidates.append((config.PLATFORM_ROOT / "generated_systems" / tail).resolve())
    if sid:
        candidates.append((config.PLATFORM_ROOT / "generated_systems" / sid).resolve())
    for c in candidates:
        if c.exists():
            return c
    if candidates:
        return candidates[0]
    return config.WORKSPACE_ROOT


def compact_system_profile(system: dict) -> dict:
    """Стислий профіль для передачі в промпт оркестратора (без зайвого шуму)."""
    return {
        "id": system.get("id"),
        "name": system.get("name"),
        "category": system.get("category"),
        "status": system.get("status"),
        "description": system.get("description"),
        "orchestration_mode": system.get("orchestration_mode"),
        "agents": system.get("agents", []),
        "sensitive": bool(system.get("sensitive", False)),
        "triggers": system.get("triggers", [])[:12],
    }


def registry_snapshot_for_prompt() -> list:
    return [compact_system_profile(s) for s in load_systems()]


def save_registry(registry: dict):
    """Записує реєстр у UTF-8 БЕЗ BOM (виправляє кореневу причину mojibake)."""
    config.REGISTRY_JSON.parent.mkdir(parents=True, exist_ok=True)
    config.REGISTRY_JSON.write_text(
        json.dumps(registry, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def add_system(entry: dict):
    """Додає нову систему в реєстр зі статусом needs_review (за контрактом білдера)."""
    reg = load_registry()
    systems = reg.get("systems", [])
    # уникнути дублю id
    existing_ids = {s.get("id") for s in systems}
    if entry.get("id") in existing_ids:
        # додати суфікс
        base = entry["id"]
        i = 2
        while f"{base}_{i}" in existing_ids:
            i += 1
        entry["id"] = f"{base}_{i}"
    systems.append(entry)
    reg["systems"] = systems
    save_registry(reg)
    return entry


def update_system_status(system_id: str, status: str) -> bool:
    reg = load_registry()
    changed = False
    for s in reg.get("systems", []):
        if s.get("id") == system_id:
            s["status"] = status
            changed = True
    if changed:
        save_registry(reg)
    return changed


# ---------------------------------------------------------------------------
# Джерело істини стану — у ПАПЦІ системи (.sf_state.json)
# ---------------------------------------------------------------------------
# Кореневий фікс оновлень (10.07.2026): реєстр — це похідний КЕШ, який
# оновлення затирає. Щоб статус і налаштування системи (особливо клієнтської)
# переживали наше оновлення, вони живуть у самій папці системи, яку оновлення
# не чіпає (generated_systems не входить у бандл). Реєстр перебудовується з
# папок + цього стану на кожному старті.
STATE_FILE = ".sf_state.json"

# Поля, які вважаємо «живим станом» системи (переживають оновлення).
_STATE_FIELDS = ("status", "triggers", "priority", "sensitive", "name", "roles")


def state_path(system: dict) -> Path:
    """Шлях до .sf_state.json у папці системи."""
    return system_root(system) / STATE_FILE


def read_folder_state(system: dict) -> dict:
    """Живий стан із папки системи. {} якщо файлу немає/не читається."""
    p = state_path(system)
    data = _read_json_bom_safe(p, {})
    return data if isinstance(data, dict) else {}


def write_folder_state(system: dict, patch: dict) -> bool:
    """Зливає patch у .sf_state.json папки системи (папка = джерело істини).
    Створює файл за потреби. Повертає True при успіху."""
    root = system_root(system)
    if not root.exists():
        return False
    state = read_folder_state(system)
    for k, v in (patch or {}).items():
        state[k] = v
    state["updated"] = _today()
    try:
        (root / STATE_FILE).write_text(
            json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False


def save_state_from_entry(system: dict) -> bool:
    """Зберігає у папку живі поля вже наявного запису реєстру (разова міграція
    для систем, у яких .sf_state.json ще немає — щоб вони теж пережили оновлення)."""
    patch = {k: system.get(k) for k in _STATE_FIELDS if system.get(k) is not None}
    return write_folder_state(system, patch)


def _today() -> str:
    try:
        from datetime import date
        return date.today().isoformat()
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# ПАСПОРТ ЗДАТНОСТЕЙ РОЛЕЙ (статичний шар контракту наміру, 10.07.2026)
# ---------------------------------------------------------------------------
# Кожна система декларує, ЩО ВМІЮТЬ її ролі (дослідник/рахувальник/критик) і які
# інструменти їм дозволені: calculator, web ("always"|"per_intent"), page_read.
# Інструмент вмикається лише на ПЕРЕТИНІ: роль вміє І контракт наміру (від мозку)
# вимагає. Паспорт живе в .sf_state.json папки системи (переживає оновлення),
# реєстр — кеш. Сіяч нижче — РАЗОВА міграція: колишні keyword-евристики executor
# виконують тут свою останню роботу й більше ніде не живуть.
# ⭐⭐⭐ 11.08.2026 (зміна 150). ТУТ СТОЯЛИ ШІСТЬ ПЕРЕЛІКІВ СЛІВ.
# `_ROLE_CRITIC_KW`, `_ROLE_COMPUTE_KW`, `_ROLE_RESEARCH_KW`, `_ROLE_EDITOR_KW`,
# `_VERIFY_ROLE_KW`, `_LEGAL_SYS_KW` — вони вгадували роль агента з його ІМЕНІ, і
# від цього залежали ІНСТРУМЕНТИ: дослідник діставав веб, рахувальник —
# калькулятор, «юридична» система — веб `always`. Тобто промах словника коштував
# і грошей клієнта, і якості. У `_LEGAL_SYS_KW` стояв корінь «прав» — його ловить
# і «управління ПРАВами доступу», і «ПРАВопис».
#
# ЧОМУ ЇХ МОЖНА ПРИБРАТИ БЕЗ ВТРАТ:
#   • Будівник ВЖЕ декларує `kind` кожного агента явно (`specs`), і декларація
#     завжди перекривала вгадування;
#   • усі наявні системи ВЖЕ мають паспорт ролей у своєму `.sf_state.json` —
#     він переживає оновлення, і його ніхто не перезасіває;
#   • право виходити у світ дає КОНТРАКТ НАМІРУ (`fresh_data=required`) будь-якій
#     ролі, а не паспорт.
# Що лишилось від «юридичного інваріанта»: ворота `live_law` з ДОВІДНИКА ГАЛУЗЕЙ.
# Ворота вмикає галузь системи, а не корінь слова в її назві.
#
# ⛔ БЕЗ ДЕКЛАРАЦІЇ І БЕЗ ПАСПОРТА МИ БІЛЬШЕ НЕ ВГАДУЄМО: роль стає `generalist`,
# інструментів немає, і в журнал іде гучний рядок. Тиха здогадка про здатність
# гірша за чесне «не знаю».


def _system_domain(entry: dict) -> str:
    """Галузь системи: явне поле паспорта, інакше — за НАШОЮ власною категорією."""
    try:
        import domains as _dm
        did = str((entry or {}).get("domain") or "").strip()
        if _dm.is_known(did):
            return did
        return _dm.domain_for_category((entry or {}).get("category"))
    except Exception:
        return ""


def _wants_live_law(entry: dict) -> bool:
    """Чи мусить ця система звіряти норми в живому офіційному джерелі ЗАВЖДИ.

    Раніше це вирішував корінь «прав» у назві. Тепер — ворота `live_law` галузі."""
    try:
        import domains as _dm
        return _dm.has_gate(_system_domain(entry), "live_law")
    except Exception:
        return False


BUILDER_ID = "system_builder"


def seed_roles(entry: dict, specs: dict = None) -> dict:
    """Сіяч паспорта ролей системи. Якщо переданий specs={aid:{kind,web}} —
    ЯВНА декларація Будівника (структурний агент) перекриває вгадування за
    назвою; евристика лишається ДРУГИМ рубежем, коли декларації нема.
    Будівник — БЕЗ інструментів (він робить системи, не контент).
    Одноагентні системи — універсал (calculator + web per_intent): воротами є
    контракт наміру від мозку, а не здогадки за словами."""
    sid = (entry or {}).get("id", "")
    legal = _wants_live_law(entry)
    blob = " ".join(str((entry or {}).get(k, "") or "")
                    for k in ("id", "category", "name")).lower()
    seo = ("seo" in blob or "geo" in blob)
    builder = (sid == BUILDER_ID)
    agents = (entry or {}).get("agents") or ["AgentMain"]
    specs = specs or {}
    _VALID_KINDS = ("research", "compute", "critic", "editor", "generalist")
    roles = {}
    for aid in agents:
        spec = specs.get(aid) if isinstance(specs.get(aid), dict) else {}
        decl_kind = str(spec.get("kind") or "").strip().lower()
        if decl_kind in _VALID_KINDS:
            kind = decl_kind          # явна декларація Будівника — єдине джерело ролі
        else:
            kind = "generalist"       # ⛔ не вгадуємо: чесне «не знаю» замість здогадки
            try:
                import llm as _llm
                _llm._log("[registry] роль агента «%s» системи «%s» не оголошена — "
                          "ставлю generalist без інструментів" % (aid, sid))
            except Exception:
                pass
        tools = {}
        if not builder:
            if len(agents) == 1:
                tools = {"calculator": True, "web": "per_intent"}
            else:
                if kind == "compute":
                    tools["calculator"] = True
                if kind == "research":
                    tools["web"] = "per_intent"
                # Юр-звірка норм — інваріант: живе офіційне джерело ЗАВЖДИ,
                # незалежно від наміру задачі (колишній _force_legal_web).
                if legal and kind in ("research", "critic"):
                    tools["web"] = "always"
            if seo:
                tools["page_read"] = True
                tools.setdefault("web", "per_intent")
                # SEO-розвідка конкурентів — інваріант (як юр-звірка норм):
                # головний продукт кроку (прогалини проти конкурентів, SERP) без
                # живого вебу неможливий, тож не лишаємо його на розсуд наміру.
                if kind == "research":
                    tools["web"] = "always"
            # ЯВНА декларація вебу від Будівника — ОСТАННЄ слово (явний контракт,
            # а не здогадка за назвою): always/per_intent вмикає, none вимикає.
            decl_web = str(spec.get("web") or "").strip().lower()
            if decl_web in ("always", "per_intent"):
                tools["web"] = decl_web
            elif decl_web in ("none", "off", "false", "no"):
                tools.pop("web", None)
        roles[aid] = {"kind": kind, "tools": tools}
    return roles


# --------------------------------------------------------------------------
# ИНВАРIАНТ ВМIННЯ (09.08.2026, задача T-000009)
# --------------------------------------------------------------------------
# КОРIНЬ: право ВIДКРИТИ знайдену сторiнку роздавалось РУКАМИ в паспортi ролей,
# тому 16 систем iз 23 мали web БЕЗ page_read. Така роль вмiє ЗНАЙТИ адресу, але
# не вмiє її ВIДКРИТИ, i мозок чесно вiдмовляв людинi («не маю можливостi
# переглядати резюме в реальному часi» — рекрутингова система, клiєнт, 09.08).
# ВМIННЯ, ЯКЕ ОБIЦЯЄ БIЛЬШЕ, НIЖ ДАЄ, — це для людини не «частково працює», а
# «не працює».
# РIШЕННЯ: правда про вмiння ОБЧИСЛЮЄТЬСЯ на ВИХОДI паспорта, а не сiється в
# трьох мiсцях. Байдуже, звiдки прийшов паспорт (кеш реєстру / стан теки / сiяч
# на льоту) — роль iз web завжди отримує page_read. Тому «забув видати» стає
# НЕМОЖЛИВИМ, а не малоймовiрним, i нова система вiд Будiвника лiкується сама.
# Два рiвнi права читати сторiнку: True - ПРОФIЛЬ системи (маршрут веде сюди),
# PAGE_READ_IMPLIED - право, дане iнварiантом (вiдкрити те, що сам знайшов).
PAGE_READ_IMPLIED = "implied"


def enforce_role_invariants(roles: dict) -> dict:
    """Єдина точка, де вмiння ролей дораховуються до правди.

    Iнварiант: хто має web (шукати) — той має page_read (вiдкрити знайдене).
    Мутує i повертає той самий словник (паспорт може йти з кешу реєстру)."""
    if not isinstance(roles, dict):
        return roles
    for _aid, r in roles.items():
        if not isinstance(r, dict):
            continue
        t = r.get("tools")
        if isinstance(t, dict) and t.get("web") and not t.get("page_read"):
            # ПРАВО, а не ПРОФIЛЬ: "implied" дає вiдкрити знайдене, але НЕ
            # робить систему адресатом задач «розбери сторiнку за адресою»
            # (це рiзнi питання; злиття їх 04.08 коштувало клiєнту аудиту).
            t["page_read"] = PAGE_READ_IMPLIED
    return roles


def get_roles(system: dict) -> dict:
    """Паспорт ролей системи: з реєстру-кешу -> з папки -> сiяч на льоту.
    Гарантує executor-у паспорт ЗАВЖДИ (навiть до мiграцiї).
    ⭐ ВСI три джерела проходять через enforce_role_invariants — щоб дiряве не
    просочилось iз старого кешу, який писався до 09.08.2026."""
    r = (system or {}).get("roles")
    if isinstance(r, dict) and r:
        return enforce_role_invariants(r)
    st = read_folder_state(system) if system else {}
    r = st.get("roles")
    if isinstance(r, dict) and r:
        return enforce_role_invariants(r)
    return enforce_role_invariants(seed_roles(system or {}))


# ---------------------------------------------------------------------------
# Конектори
# ---------------------------------------------------------------------------
# Базові сервіси платформи (за GLOBAL_ORCHESTRATOR_PROMPT) — завжди доступні логічно.
BASE_CONNECTORS = [
    {"id": "llm_runtime", "name": "LLM Runtime (мозок)", "type": "base"},
    {"id": "web_search", "name": "Веб-пошук", "type": "base"},
    {"id": "local_files", "name": "Локальні файли", "type": "base"},
    {"id": "spreadsheet_parser", "name": "Парсер таблиць CSV/XLSX/JSON", "type": "base"},
    {"id": "document_renderer", "name": "Рендер документів MD/HTML", "type": "base"},
    {"id": "artifact_store", "name": "Сховище артефактів", "type": "base"},
]

# Приватні конектори, які потребують окремої авторизації (OAuth-токени на диску).
PRIVATE_CONNECTORS = [
    {"id": "google_drive", "name": "Google Drive", "type": "private"},
    {"id": "github", "name": "GitHub", "type": "private"},
    {"id": "slack", "name": "Slack", "type": "private"},
    {"id": "telegram", "name": "Telegram", "type": "private"},
]


def _token_present(connector_id: str) -> bool:
    token_path = config.CONNECTORS_DIR / f"{connector_id}.token.json"
    if not token_path.exists():
        return False
    data = _read_json_bom_safe(token_path, {})
    return bool(data.get("access_token") or data.get("token"))


def connector_inventory() -> list:
    """Повний стан конекторів для UI. Не повертає самі токени."""
    inv = []
    # Базовий мозок залежить від наявності ключа LLM
    for c in BASE_CONNECTORS:
        status = "connected"
        if c["id"] == "llm_runtime":
            status = "connected" if config.provider_ready() else "not_configured"
        elif c["id"] == "web_search":
            status = "connected" if config.web_search_ready() else "not_configured"
        inv.append({**c, "status": status})
    for c in PRIVATE_CONNECTORS:
        inv.append({**c, "status": "connected" if _token_present(c["id"]) else "not_connected"})
    return inv
