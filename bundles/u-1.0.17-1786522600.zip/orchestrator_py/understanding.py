# -*- coding: utf-8 -*-
"""understanding.py — ОДИН ПИСАР РОЗУМІННЯ ЗАДАЧІ (11.08.2026, зміна 152, крок 4).

НАВІЩО ЦЕЙ МОДУЛЬ ІСНУЄ.
Платформа перестала вгадувати сенс запиту переліками слів і почала його
ОГОЛОШУВАТИ (зміни 150-151). Але оголошення, якого людина не бачить, — це та
сама здогадка, лише машинна: 11.08 мозок оголосив «закупівлі» на питання водія,
і клієнт дізнався про це вже з відповіді, за свої гроші.

Тому перед запуском системи платформа ПОКАЗУЄ, як вона зрозуміла задачу, і дає
виправити ОДНИМ КЛІКОМ — до витрат.

    СЕНС ДАЄ МОЗОК, НАСЛІДОК НЕСЕ КОД. ТЕКСТ КАРТКИ СКЛАДАЄ ПЛАТФОРМА.

ЩО ТУТ ЖИВЕ (і ніде більше):
  • ПОРЯДОК СИЛИ: клієнт > тверда очевидність > мозок > паспорт системи > дефолт;
  • ТЕКСТ картки — з довідника, жодного речення від моделі;
  • ВІДБИТОК контракту (щоб мовчати про те, що не змінилось);
  • СУПЕРЕЧНІСТЬ із паспортом системи — ОДИН писар, а не два;
  • СЛІД у `runs/_audit.jsonl` — і коли питали, і коли пройшли мовчки.

ЧОГО ТУТ НЕМАЄ. Жодного переліку слів. Жодного рішення «запускати чи ні» — це
робить той, хто має канал до людини. Модуль лише КАЖЕ, що зрозуміло і що
розбіжне.

⚠ ЧОМУ СУПЕРЕЧНІСТЬ СУДИТЬ ЛИШЕ ЯВНА ДЕКЛАРАЦІЯ ПАСПОРТА.
Галузь системи вміє братися з НАШОЇ категорії (`registry._system_domain`) — це
законна ЗАПАСНА підказка, коли галузь не оголошено. Але зупиняти роботу через
неї не можна: категорія `legal` дає `civil_contract`, і тоді юрист-консультант
відмовився б відповідати водієві про ПДР — рівно той дефект, який ми лікуємо,
лише з іншого боку. Зупиняє тільки те, що записано в паспорті РУКОЮ, як факт
про систему: `entry["domain"]`.
"""

import config

# Ключі рядків картки, які мають НАСЛІДОК і які клієнт може змінити.
EDITABLE = ("domain", "jurisdiction")

# Джерела значення — в порядку спадання сили.
SRC_CLIENT = "client"        # людина виправила в картці (сильніше за все)
SRC_EVIDENCE = "evidence"    # тверда очевидність у тексті (номер UA-…)
SRC_BRAIN = "brain"          # оголошення мозку в контракті наміру
SRC_PASSPORT = "passport"    # запасне: паспорт/категорія системи
SRC_DEFAULT = "default"      # дефолт збірки
SRC_NONE = "none"            # не встановлено


def _log(msg):
    try:
        import llm
        llm._log("[understanding] %s" % msg)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# 1. ПОРЯДОК СИЛИ
# ---------------------------------------------------------------------------
def _evidence_domain(blob: str) -> str:
    """Тверда очевидність у тексті: формальний номер процедури `UA-…`.

    Питаємо ОДНОГО писаря очевидності (`tender_legal`), а не заводимо свій
    регекс: межа, яку пишуть два місця, вже коштувала нам двічі."""
    if not (blob or "").strip():
        return ""
    try:
        import tender_legal as _tl
        if not _tl.TENDER_ID_RE.search(blob):
            return ""
        import domains as _dm
        return _dm.domain_with_evidence("tender_id") or ""
    except Exception as e:
        _log("тверда очевидність не спрацювала: %s" % e)
        return ""


def resolve(system=None, intent=None, blob: str = "", client=None) -> dict:
    """⭐ ГОЛОВНА ФУНКЦІЯ. Складає ОСТАТОЧНИЙ контракт розуміння.

    system — паспорт системи (може бути None);
    intent — контракт наміру від мозку (сирий або нормалізований);
    blob   — текст, у якому шукаємо ТВЕРДУ ОЧЕВИДНІСТЬ (запит людини + задача);
    client — поправка людини: {"domain": ..., "jurisdiction": ...}.

    Повертає готовий контракт із НАЗВАНИМ джерелом кожного значення. Функція
    чиста і детермінована: два виклики на тих самих вхідних даних дають той
    самий результат — саме тому її можна кликати і в мозку, і у виконавці, не
    заводячи другого писаря правди."""
    try:
        import domains as _dm
    except Exception as e:
        _dm = None
        _log("довідник не імпортується: %s" % e)

    d = intent if isinstance(intent, dict) else {}
    c = client if isinstance(client, dict) else {}
    book_ok = bool(_dm and _dm.available())
    book_problem = (_dm.problem() if _dm else "довідник галузей недоступний")

    def known(did):
        return bool(_dm and _dm.is_known(did))

    def jknown(jid):
        return bool(_dm and _dm.jurisdiction_is_known(jid))

    # ── ГАЛУЗЬ ────────────────────────────────────────────────────────────────
    domain, dsrc = "", SRC_NONE
    ev = _evidence_domain(blob)
    if known(c.get("domain")):
        domain, dsrc = str(c["domain"]).strip(), SRC_CLIENT
    elif ev:
        domain, dsrc = ev, SRC_EVIDENCE
    elif known(d.get("domain")):
        domain, dsrc = str(d["domain"]).strip(), SRC_BRAIN
    else:
        passport = ""
        try:
            import registry as _rg
            passport = _rg._system_domain(system or {})
        except Exception as e:
            _log("паспорт системи не прочитано: %s" % e)
        if known(passport):
            domain, dsrc = passport, SRC_PASSPORT
        else:
            domain, dsrc = "unknown", SRC_NONE

    # ⭐ ТВЕРДА ОЧЕВИДНІСТЬ НЕ МОВЧИТЬ, КОЛИ ПРОГРАЄ ЛЮДИНІ (рішення 13 задуму):
    # виграє клієнт, але картка окремим рядком каже про суперечність.
    ev_note = ""
    if ev and domain != ev and dsrc == SRC_CLIENT:
        ev_note = ("у тексті є номер процедури — веду так, як сказали ви")

    # ── ЮРИСДИКЦІЯ ────────────────────────────────────────────────────────────
    default_jur = (getattr(config, "DEFAULT_JURISDICTION", "UA") or "UA").upper()
    if jknown(c.get("jurisdiction")):
        jur, jsrc = str(c["jurisdiction"]).strip().upper(), SRC_CLIENT
    elif jknown(d.get("jurisdiction")):
        jur, jsrc = str(d["jurisdiction"]).strip().upper(), SRC_BRAIN
    else:
        jur, jsrc = default_jur, SRC_DEFAULT

    out = {"domain": domain or "unknown", "domain_source": dsrc,
           "jurisdiction": jur, "jurisdiction_source": jsrc,
           "evidence_note": ev_note,
           "book_ok": book_ok, "book_problem": "" if book_ok else book_problem}
    out["conflict"] = conflict_of(system, out)
    return out


# ⭐⭐⭐ 11.08.2026 (зміна 153, знайдено ЖИВИМ ПРОГОНОМ за $0.07).
# КОНТРАКТ СКЛАДАЄТЬСЯ ОДИН РАЗ І ЇДЕ ГОТОВИМ — ЙОГО НЕ ПЕРЕСКЛАДАЮТЬ.
# Дефект, який це закриває: ворота (`agent`) складали контракт ІЗ поправкою
# людини, а виконавець (`executor`) складав його ЗАНОВО — без неї. Порядок сили
# один, але входи різні, тому результат розходився МОВЧКИ: людина виправляла
# галузь у картці, а якщо в тексті стояв номер `UA-…`, тверда очевидність била
# її поправку, і робота йшла ІНШОЮ галуззю. Картка при цьому показувала людині,
# що її почули. Це «платформа не може збрехати» навиворіт.
# Ліки: той, хто вже має готовий контракт, ПЕРЕДАЄ його далі; той, хто отримав, —
# БЕРЕ, а не перескладає. Хто нічого не отримав (телеграм, розклад, ланцюг) —
# складає сам, як і раніше.
def is_contract(c) -> bool:
    """Чи це справді готовий контракт розуміння, а не випадковий словник.
    Виконавець бере ЧУЖЕ рішення лише тоді, коли впізнав його як своє."""
    return (isinstance(c, dict)
            and isinstance(c.get("domain"), str) and bool(c.get("domain"))
            and isinstance(c.get("jurisdiction"), str)
            and c.get("domain_source") in (SRC_CLIENT, SRC_EVIDENCE, SRC_BRAIN,
                                           SRC_PASSPORT, SRC_DEFAULT, SRC_NONE))


def fingerprint(contract) -> str:
    """Відбиток розуміння. Картка мовчить, доки відбиток не змінився."""
    c = contract if isinstance(contract, dict) else {}
    return "%s|%s" % (c.get("domain") or "unknown", c.get("jurisdiction") or "")


# ---------------------------------------------------------------------------
# 2. СУПЕРЕЧНІСТЬ ІЗ ПАСПОРТОМ СИСТЕМИ — ОДИН ПИСАР
# ---------------------------------------------------------------------------
def declared_domain(system) -> str:
    """Галузь, ЗАПИСАНА В ПАСПОРТІ СИСТЕМИ РУКОЮ. Не категорія, не здогадка.

    Порожньо — значить система себе галуззю не обмежує, і суперечності бути
    не може. Мовчання паспорта ніколи не зупиняє роботу."""
    did = str(((system or {}) if isinstance(system, dict) else {}).get("domain") or "").strip()
    try:
        import domains as _dm
        return did if _dm.is_known(did) else ""
    except Exception:
        return ""


def alternatives(domain_id, exclude_id="") -> list:
    """Які НАШІ системи оголосили саме цю галузь. Платформа сама називає вихід,
    а не пропонує людині вгадувати. Порожньо — так і кажемо."""
    out = []
    try:
        import registry as _rg
        for s in _rg.load_systems():
            if s.get("id") == exclude_id:
                continue
            if declared_domain(s) == str(domain_id or "").strip():
                out.append({"id": s.get("id"), "name": s.get("name") or s.get("id")})
    except Exception as e:
        _log("перелік альтернатив не склався: %s" % e)
    return out


def conflict_of(system, contract):
    """Чи оголошена галузь суперечить ЯВНІЙ декларації паспорта системи.

    Повертає None або опис суперечності з двома виходами. ОДИН писар: і коли
    галузь назвав мозок, і коли її виправив клієнт (п.2 і п.3 частини 4 задуму
    — це той самий шлях, а не два)."""
    dec = declared_domain(system)
    if not dec:
        return None
    did = str((contract or {}).get("domain") or "").strip()
    if not did or did in ("", "unknown") or did == dec:
        return None
    try:
        import domains as _dm
        sys_name = (system or {}).get("name") or (system or {}).get("id") or "система"
        return {"system_id": (system or {}).get("id") or "",
                "system_name": sys_name,
                "system_domain": dec,
                "system_domain_name": _dm.name_of(dec),
                "case_domain": did,
                "case_domain_name": _dm.name_of(did),
                "alternatives": alternatives(did, exclude_id=(system or {}).get("id") or "")}
    except Exception as e:
        _log("суперечність не склалась: %s" % e)
        return None


# ---------------------------------------------------------------------------
# 3. КАРТКА — ТЕКСТ СКЛАДАЄ ПЛАТФОРМА
# ---------------------------------------------------------------------------
_OUTPUT_NAMES = {
    "chat_answer": "відповідь у чат",
    "document": "документ",
    "estimate_sheet": "таблиця-оцінка",
    "financial_model": "фінансова модель",
    "report": "звіт",
    "system": "працююча система",
}


def card(system, contract, intent=None) -> dict:
    """Машинна картка розуміння: рядки, списки вибору і ГОТОВИЙ ТЕКСТ.

    ⭐ ЖОДНОГО РЕЧЕННЯ ВІД МОДЕЛІ. Назви беруться з довідника, назва системи —
    з реєстру, тип результату — з контракту наміру. Це і є те, чим картка
    відрізняється від «хай мозок пояснить, як він зрозумів»."""
    try:
        import domains as _dm
    except Exception:
        _dm = None
    c = contract if isinstance(contract, dict) else {}
    d = intent if isinstance(intent, dict) else {}
    dname = (_dm.name_of(c.get("domain"), "не встановлено") if _dm else "не встановлено")
    jname = (_dm.jurisdiction_name(c.get("jurisdiction"), c.get("jurisdiction") or "")
             if _dm else (c.get("jurisdiction") or ""))

    rows = [{"key": "system", "label": "Система",
             "value": (system or {}).get("name") or (system or {}).get("id") or "—"},
            {"key": "domain", "label": "Галузь", "value": dname,
             "id": c.get("domain") or "unknown",
             "choices": (_dm.choices() if _dm else [])},
            {"key": "jurisdiction", "label": "Право країни", "value": jname,
             "id": c.get("jurisdiction") or "",
             "choices": (_dm.jurisdiction_choices() if _dm else [])},
            {"key": "output", "label": "Результат",
             "value": _OUTPUT_NAMES.get(d.get("output") or "chat_answer", "відповідь у чат")}]
    if (d.get("fresh_data") or "") == "required":
        rows.append({"key": "fresh_data", "label": "Живі дані", "value": "потрібні"})
    if (d.get("computation") or "") == "required":
        rows.append({"key": "computation", "label": "Розрахунок", "value": "потрібен"})
    if (d.get("route") or "") == "required":
        rows.append({"key": "route", "label": "Маршрут", "value": "замовлено"})

    notes = []
    if not c.get("book_ok"):
        notes.append("довідник галузей недоступний — доменні запобіжники вимкнено")
    if c.get("evidence_note"):
        notes.append(c["evidence_note"])
    if (c.get("domain") or "unknown") == "unknown":
        notes.append("галузь не встановлено — доменні запобіжники не вмикаються")

    width = max(len(r["label"]) for r in rows) + 1
    lines = ["**Як я зрозумів задачу**", ""]
    for r in rows:
        lines.append("%s%s %s" % (r["label"] + ":", " " * (width - len(r["label"])), r["value"]))
    for n in notes:
        lines.append("")
        lines.append("⚠ " + n)
    return {"rows": rows, "notes": notes, "text": "\n".join(lines),
            "fingerprint": fingerprint(c)}


def conflict_text(conflict) -> str:
    """Текст зупинки на суперечності. Теж складає ПЛАТФОРМА, простими словами,
    і НАЗИВАЄ обидва виходи. Мовчазна робота «не тим юристом» — не варіант."""
    k = conflict if isinstance(conflict, dict) else {}
    alt = k.get("alternatives") or []
    t = ("**Зупинився до роботи: справа не тієї галузі**\n\n"
         "Система «%s» працює з галуззю «%s», а ця справа — «%s».\n\n"
         % (k.get("system_name") or "—", k.get("system_domain_name") or "—",
            k.get("case_domain_name") or "—"))
    if alt:
        t += ("Цю галузь у нас веде: %s.\n\n"
              % ", ".join("«%s»" % a.get("name") for a in alt))
    else:
        t += "Окремої системи саме для цієї галузі в реєстрі немає.\n\n"
    t += "Що робимо: взяти іншу систему чи все одно запустити цю?"
    return t


# ---------------------------------------------------------------------------
# 4. СЛІД — ЗАВЖДИ
# ---------------------------------------------------------------------------
def trace(event: str, system=None, contract=None, actor="", extra=None) -> bool:
    """Рядок у `runs/_audit.jsonl`. Пишеться і коли питали людину, і коли
    пройшли мовчки, і коли людину спитати нікому (автоматизація, розклад).

    ⭐ Правило 7 картки: слід лишається ЗАВЖДИ. Інакше постфактум нічим довести,
    що платформа взагалі питала — а це «тихий успіх» із переліку смертельних."""
    try:
        import audit
        c = contract if isinstance(contract, dict) else {}
        rec = {"kind": "understanding", "event": str(event or ""),
               "system_id": (system or {}).get("id") if isinstance(system, dict) else "",
               "domain": c.get("domain"), "domain_source": c.get("domain_source"),
               "jurisdiction": c.get("jurisdiction"),
               "jurisdiction_source": c.get("jurisdiction_source"),
               "book_ok": bool(c.get("book_ok")),
               "conflict": bool(c.get("conflict")),
               "actor": str(actor or "")}
        if isinstance(extra, dict):
            rec.update(extra)
        return audit.log_event(rec)
    except Exception as e:
        _log("слід не записався: %s" % e)
        return False
