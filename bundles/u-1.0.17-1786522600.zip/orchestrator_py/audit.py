"""
audit.py — append-only журнал запусків (аудит-слід).

Призначення: трасованість і комплаєнс — для кожного запуску системи фіксуємо
МЕТАДАНІ (коли, яка система, статус, чи пройдено перевірку, скільки мертвих
посилань нейтралізовано). Це аргумент для продажу (audit trail) і допомога в
розслідуванні інцидентів.

ПРИНЦИП БЕЗПЕКИ: у журнал НЕ потрапляють секрети (ключі/токени) і повний текст
результату — лише короткий прев'ю задачі та її хеш. Запис у журнал ніколи не
валить основний потік (усе обгорнуто в try/except).

Файл: runs/_audit.jsonl (по одному JSON-запису на рядок).
"""

import json
import hashlib
from datetime import datetime

import config

_PATH = config.RUNS_DIR / "_audit.jsonl"

# Маркери, схожі на секрети, — на випадок, якщо колись хтось передасть їх у task_preview.
_SECRET_HINT = ("sk-", "api_key", "apikey", "token=", "bearer ", "aiza", "ghp_")


def _scrub(text: str) -> str:
    t = (text or "")[:160]
    low = t.lower()
    if any(h in low for h in _SECRET_HINT):
        return "[приховано: можливий секрет у тексті]"
    return t


def log_run(system_id, task, status, verified, run_id="", dead_urls=0, extra=None):
    """Додає запис про завершений запуск системи. Безпечно за будь-яких помилок."""
    try:
        rec = {
            "ts": datetime.now().isoformat(timespec="seconds"),
            "run_id": run_id,
            "system_id": system_id,
            "task_preview": _scrub(task),
            "task_hash": hashlib.sha256((task or "").encode("utf-8")).hexdigest()[:12],
            "status": status,
            "verified": bool(verified),
            "dead_urls": int(dead_urls or 0),
        }
        if isinstance(extra, dict):
            for k, v in extra.items():
                rec.setdefault(k, v)
        _PATH.parent.mkdir(parents=True, exist_ok=True)
        with _PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return True
    except Exception:
        return False


def log_refusal(kind: str, system_id: str, questions=None, note: str = "") -> bool:
    """⭐⭐⭐ 01.08.2026. ОДИН ПИСАР СЛІДУ «РОБОТА НЕ ВІДБУЛАСЬ АБО ВІДБУЛАСЬ НЕ ТАК».

    Слід відмов народився 31.07 усередині `agent.py` — там, де його вперше
    забракло. Але зупиняє роботу не лише мозок: рушій теж має право не почати
    (не вдалося перевірити достатність даних) або піти далі з чесним
    застереженням. Поки писар жив в `agent`, рушій не міг ним скористатись —
    і майбутній канал протік би мовчки. Тому правда переїхала в журнал, а
    `agent._refusal_log` став тонким викликом до неї.

    Пише за перемикачем стану (`config.STATE_DIR`), щоб чеки не смітили в
    бойову теку. Ніколи не кидає: журнал не має права завалити роботу.
    """
    try:
        d = config.STATE_DIR / "runs"
        d.mkdir(parents=True, exist_ok=True)
        rec = {"ts": datetime.now().isoformat(), "kind": kind,
               "system_id": system_id or "",
               "questions": list(questions or []), "note": note}
        with (d / "_refusals.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return True
    except Exception:
        return False


def log_event(rec) -> bool:
    """⭐ ОДИН ПИСАР НЕ-ПРОГОННОГО РЯДКА АУДИТУ (11.08.2026, зміна 152).

    Журнал народився як слід ЗАВЕРШЕНОГО прогону (`log_run`). Але є
    події, які стаються ДО роботи і важать рівно стільки ж: як платформа
    зрозуміла задачу і чи питала про це людину. Щоб цей слід не завів ДРУГОГО
    писаря з власним форматом і власним шляхом до файла, він йде сюди.

    Ніколи не кидає: журнал не має права завалити роботу."""
    try:
        if not isinstance(rec, dict):
            return False
        out = {"ts": datetime.now().isoformat(timespec="seconds")}
        for k, v in rec.items():
            if k == "ts":
                continue
            out[k] = _scrub(v) if isinstance(v, str) else v
        _PATH.parent.mkdir(parents=True, exist_ok=True)
        with _PATH.open("a", encoding="utf-8") as f:
            f.write(json.dumps(out, ensure_ascii=False) + "\n")
        return True
    except Exception:
        return False


def tail(n: int = 50) -> list:
    """Останні n записів журналу (для перегляду/UI)."""
    try:
        lines = _PATH.read_text(encoding="utf-8").splitlines()[-n:]
        return [json.loads(ln) for ln in lines if ln.strip()]
    except Exception:
        return []
