# -*- coding: utf-8 -*-
"""notify_mail.py — ПОШТА ДЛЯ СПОВІЩЕНЬ ПРАЦІВНИКАМ: СКРИНЬКА ПЛАТФОРМИ І ВІДПРАВНИК
(зміна 685, 02.10.2026).

🩸 ЩО БУЛО. Працівник дізнавався про свою задачу лише з телеграма або з екрана.
Відправника пошти в рушії не було зовсім (`deal_mail.py`: «жодного smtplib»). Для
ОТУ (рішення Андрія 01–02.10.2026): Телеграм лишається — хто хоче, підключає;
решті — лист на робочу пошту через поштовий сервер компанії (Kerio Connect, SMTP).

⛒ ЗАКОНИ ЦЬОГО МОДУЛЯ:
  1. ОДИН ВІДПРАВНИК. Кожен лист платформи йде через `send` — і тема, і тіло, і
     заголовки збираються тут, а не в кожному, кому треба написати.
  2. СКРИНЬКА — ЛИШЕ ПЕРЕВІРЕНА. Зберігаємо після вдалого входу на сервер:
     скринька, з якої не можна надіслати, — обіцянка, яку ніхто не виконає.
  3. ПАРОЛЬ — СЕКРЕТ. Лежить у теці конекторів (вона не їде ні в збірку, ні в
     оновлення, ні в архів даних), не повертається на екран і в двері, не
     пишеться в журнали. Переписати налаштування можна без пароля — тоді лишається
     старий, але лише для ТІЄЇ САМОЇ адреси.
  4. ВІДКРИТИМ ТЕКСТОМ — ЛИШЕ ДО ЦІЄЇ МАШИНИ. Довіру до сертифіката знає один
     писар (`netfetch.ssl_context`, урок 623) — тут його не обходять.
  5. ВІДМОВА — СЛОВАМИ. Збій сервера, пароля чи адреси одержувача — це причина
     людською мовою, а не виняток, що валить потік доставки.
  6. ЛИСТ — АВТОМАТИЧНИЙ І ЧЕСНИЙ: `Auto-Submitted: auto-generated` (RFC 3834),
     щоб автовідповідачі не відповідали роботу, і адреса відправника — сама
     скринька платформи.
  7. ЗМІНА СКРИНЬКИ — СЛІД У ЖУРНАЛІ БЕЗПЕКИ. Куди платформа шле листи від імені
     компанії — питання безпеки, як і хто кому відкрив доступ.

⛒ Режим повної локальної ізоляції: лист іде на ПОШТОВИЙ СЕРВЕР КОМПАНІЇ, який
адміністратор назвав сам і перевірив входом. Саме збереження скриньки і є тим явним
дозволом оператора; без нього платформа не шле нікуди.

Лише stdlib + `config`, `one_writer`, `netfetch`, `security_log`.
"""
import smtplib
import socket
import ssl
import sys
from datetime import datetime
from email.headerregistry import Address
from email.message import EmailMessage
from email.utils import formatdate, make_msgid

import config
import one_writer

SETTINGS_JSON = config.CONNECTORS_DIR / "notify_mail.json"
TIMEOUT_S = 25
SEC_SSL, SEC_STARTTLS, SEC_PLAIN = "ssl", "starttls", "plain"
SECURITIES = (SEC_SSL, SEC_STARTTLS, SEC_PLAIN)
_LOCAL_HOSTS = ("127.0.0.1", "localhost", "::1")
FROM_NAME_DEFAULT = "SensFlow"

_PUBLIC = ("address", "host", "port", "security", "from_name", "enabled",
           "saved", "saved_by", "since", "last_ok", "last_error", "sent")


class MailError(Exception):
    """Відмова словами: що не так і що зробити людині."""


class RecipientError(MailError):
    """⭐ 686. Хибна адреса ОДНОГО одержувача. Скринька жива, сервер живий —
    повтор нічого не змінить, тож доставка не спиняє через це решту людей."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _now() -> str:
    try:
        import clock
        return clock.now()
    except Exception:
        return datetime.now().isoformat(timespec="seconds")


# ── СХОВИЩЕ (ОДИН ПИСАР) ─────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(SETTINGS_JSON)
    except PermissionError:
        raise
    except Exception:
        d = {}
    return d if isinstance(d, dict) else {}


def _save(d: dict) -> None:
    SETTINGS_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(SETTINGS_JSON, d)


def settings() -> dict:
    """Скринька для екрана — БЕЗ пароля за побудовою."""
    d = _load()
    out = {k: d.get(k) for k in _PUBLIC}
    out["has_password"] = bool(_s(d.get("password")))
    out["configured"] = configured(d)
    return out


def configured(d=None) -> bool:
    d = _load() if d is None else d
    return bool(d.get("enabled") and _s(d.get("address")) and _s(d.get("password"))
                and _s(d.get("host")) and int(d.get("port") or 0) > 0)


# ── ЗʼЄДНАННЯ ────────────────────────────────────────────────────────────────
def _ssl():
    import netfetch
    return netfetch.ssl_context()


def candidates(address: str, host: str = "", port=None, security: str = "") -> list:
    """Куди стукати. Названий сервер — лише він. Не названий — ПРАВИЛО домену
    (`smtp.<домен>`, `mail.<домен>`, сам домен; 465 із шифруванням, потім 587 зі
    STARTTLS), а не перелік провайдерів."""
    if _s(host):
        sec = _s(security) or SEC_SSL
        if sec not in SECURITIES:
            raise MailError("Невідомий спосіб зʼєднання «%s»." % sec)
        p = int(port or (465 if sec == SEC_SSL else 587))
        return [(_s(host), p, sec)]
    dom = _s(address).rpartition("@")[2].lower()
    if not dom or "." not in dom:
        raise MailError("Адреса «%s» не схожа на пошту." % _s(address))
    hosts = ["smtp." + dom, "mail." + dom, dom]
    return [(h, 465, SEC_SSL) for h in hosts] + [(h, 587, SEC_STARTTLS) for h in hosts]


def _open(host: str, port: int, security: str):
    if security == SEC_SSL:
        return smtplib.SMTP_SSL(host, port, context=_ssl(), timeout=TIMEOUT_S)
    if security == SEC_STARTTLS:
        c = smtplib.SMTP(host, port, timeout=TIMEOUT_S)
        c.ehlo()
        c.starttls(context=_ssl())
        c.ehlo()
        return c
    if security == SEC_PLAIN:
        # ⛔ Пароль відкритим текстом — лише до своєї машини (місцевий поштовий
        # перекладач або проба). До чужого сервера — ніколи.
        if host not in _LOCAL_HOSTS:
            raise MailError("Без шифрування підключаємось лише до цієї ж машини. "
                            "Оберіть захист SSL (порт 465) або STARTTLS (порт 587).")
        c = smtplib.SMTP(host, port, timeout=TIMEOUT_S)
        c.ehlo()
        return c
    raise MailError("Невідомий спосіб зʼєднання «%s»." % security)


def _human(ex, host: str) -> str:
    """Відмова людською мовою: ЩО сталося і ЩО зробити."""
    if isinstance(ex, MailError):
        return _s(ex)
    if isinstance(ex, smtplib.SMTPAuthenticationError):
        return ("Сервер %s не прийняв пароль скриньки. Перевірте адресу й пароль; "
                "у Kerio вхід поштою має бути дозволений для цієї скриньки." % host)
    if isinstance(ex, smtplib.SMTPNotSupportedError):
        return "Сервер %s не пропонує входу з паролем на цьому порту." % host
    if isinstance(ex, (socket.timeout, TimeoutError)):
        return "Сервер %s не відповів за %d с." % (host, TIMEOUT_S)
    if isinstance(ex, socket.gaierror):
        return "Сервера %s не знайдено в мережі." % host
    if isinstance(ex, ssl.SSLError):
        try:
            import netfetch
            why = netfetch.explain_ssl_error(ex)
            if why:
                return why
        except Exception:
            pass
        return "Шифроване зʼєднання з %s не склалось: %s" % (host, _s(ex)[:120])
    if isinstance(ex, smtplib.SMTPServerDisconnected):
        return "Сервер %s обірвав зʼєднання. Перевірте порт і спосіб захисту." % host
    if isinstance(ex, (ConnectionRefusedError, OSError)):
        return "Сервер %s не приймає зʼєднання: %s" % (host, _s(ex)[:120])
    return "Пошта %s: %s" % (host, _s(ex)[:160])


def _login(address: str, password: str, host="", port=None, security="", connect=None):
    """-> (клієнт, host, port, security). Пароль, який сервер ВІДКИНУВ, далі не
    носимо по інших серверах."""
    last = ""
    for h, p, sec in candidates(address, host, port, security):
        try:
            c = connect(h, p, sec) if connect else _open(h, p, sec)
        except MailError:
            raise
        except Exception as ex:
            last = _human(ex, h)
            continue
        try:
            _auth(c, _s(address), password)
            return c, h, p, sec
        except smtplib.SMTPAuthenticationError as ex:
            _quit(c)
            raise MailError(_human(ex, h))
        except Exception as ex:
            _quit(c)
            last = _human(ex, h)
    raise MailError(last or "Поштового сервера для «%s» не знайдено." % address)


def _b64(text: str) -> str:
    import base64
    return base64.b64encode(text.encode("utf-8")).decode("ascii")


def _auth(c, user: str, password: str) -> None:
    """Вхід на сервер.

    🩸 ЗНАЙДЕНО ПРОБОЮ 685: `smtplib.login` кодує пароль як ASCII і падає на
    кирилиці («'ascii' codec can't encode») — а пароль скриньки в Kerio може
    бути будь-яким. Тому пароль не з ASCII несемо самі, у UTF-8, як велить
    RFC 4616 (PLAIN) і як розуміють сервери (LOGIN). ASCII-пароль — звичайним
    шляхом `smtplib` (він уміє й CRAM-MD5)."""
    if (user + password).isascii():
        c.login(user, password)
        return
    c.ehlo_or_helo_if_needed()
    if not c.has_extn("auth"):
        raise smtplib.SMTPNotSupportedError("AUTH extension not supported by server.")
    methods = (c.esmtp_features.get("auth") or "").upper().split()
    if "PLAIN" in methods:
        code, resp = c.docmd("AUTH", "PLAIN " + _b64("\0%s\0%s" % (user, password)))
    elif "LOGIN" in methods:
        code, resp = c.docmd("AUTH", "LOGIN " + _b64(user))
        if code == 334:
            code, resp = c.docmd(_b64(password))
    else:
        raise smtplib.SMTPNotSupportedError(
            "Сервер не пропонує входу PLAIN чи LOGIN, а пароль не з латиниці.")
    if code not in (235, 503):
        raise smtplib.SMTPAuthenticationError(code, resp)


def _quit(c) -> None:
    try:
        c.quit()
    except Exception:
        try:
            c.close()
        except Exception:
            pass


def _check_address(a: str, what: str, err=MailError) -> str:
    a = _s(a)
    if "@" not in a or " " in a or a.startswith("@") or a.endswith("@"):
        raise err("%s «%s» не схожа на адресу пошти." % (what, a))
    return a


# ── НАЛАШТУВАННЯ ─────────────────────────────────────────────────────────────
def save(address: str, password: str = "", host: str = "", port=None, security: str = "",
         from_name: str = "", by: str = "", connect=None) -> dict:
    """Завести або змінити скриньку платформи. Спершу ВХІД, потім запис (закон 2).

    ⛒ Вхід на сервер (до TIMEOUT_S) — ПОЗА замком одного писаря: замок спільний на
    всю платформу, і повільна пошта не сміє зупиняти запис задач і угод."""
    address = _check_address(address, "Адреса скриньки").lower()
    old = _load()
    password = _s(password)
    if not password:
        if _s(old.get("address")).lower() == address and _s(old.get("password")):
            password = _s(old.get("password"))
        else:
            raise MailError("Потрібен пароль скриньки %s." % address)
    try:
        port = int(port) if _s(port) else None
    except (TypeError, ValueError):
        raise MailError("Порт «%s» — не число." % _s(port))
    c, h, p, sec = _login(address, password, host, port, security, connect=connect)
    _quit(c)
    _commit(address, password, h, p, sec, from_name, by)
    _trace("скриньку для сповіщень збережено: %s через %s:%d (%s)" % (address, h, p, sec))
    return settings()


@one_writer.guard("NOTIFY_MAIL_JSON")
def _commit(address, password, h, p, sec, from_name, by) -> None:
    old = _load()
    now = _now()
    # ⭐ 686: «з якого моменту ця скринька» — межа для доставки: події, що сталися
    # ДО неї, листами не йдуть (без зливи старого). Правка тієї самої скриньки
    # (імʼя, сервер, пароль) межу НЕ рухає — інакше черга, що чекала полагодженого
    # пароля, мовчки б пропала.
    same = _s(old.get("address")).lower() == address and _s(old.get("since"))
    new = {"address": address, "password": password, "host": h, "port": p,
           "security": sec, "from_name": _s(from_name) or FROM_NAME_DEFAULT,
           "enabled": True, "saved": now, "saved_by": _s(by),
           "since": _s(old.get("since")) if same else now,
           "last_ok": old.get("last_ok") or "", "last_error": "",
           "sent": int(old.get("sent") or 0)}
    _save(new)
    _journal(old, new)


@one_writer.guard("NOTIFY_MAIL_JSON")
def remove(by: str = "") -> dict:
    old = _load()
    if not old:
        return settings()
    _save({})
    _journal(old, {})
    _trace("скриньку для сповіщень відключено")
    return settings()


def _journal(old: dict, new: dict) -> None:
    """Рядок у журналі безпеки: було → стало. Пароля тут немає — лише факт зміни."""
    fields = (("address", "Скринька"), ("host", "Сервер"), ("port", "Порт"),
              ("security", "Захист"), ("from_name", "Імʼя відправника"))
    chs = [(label, _s(old.get(k)), _s(new.get(k))) for k, label in fields
           if _s(old.get(k)) != _s(new.get(k))]
    if _s(old.get("password")) != _s(new.get("password")) and new:
        chs.append(("Пароль", "", "змінено"))
    note = ("скриньку відключено" if not new else
            ("скриньку заведено" if not old else "налаштування змінено"))
    try:
        import security_log
        security_log.notify_mail_event(chs, note=note)
    except Exception as ex:
        _trace("зміну скриньки не записано в журнал безпеки: %s" % type(ex).__name__)


# ── ВІДПРАВНИК (ОДИН НА ВСЮ ПЛАТФОРМУ) ──────────────────────────────────────
def _message(d: dict, to: str, subject: str, body: str, attachments=None) -> EmailMessage:
    m = EmailMessage()
    user, _at, dom = _s(d.get("address")).partition("@")
    m["From"] = Address(_s(d.get("from_name")) or FROM_NAME_DEFAULT, user, dom)
    m["To"] = to
    m["Subject"] = " ".join(_s(subject).split())[:200] or "SensFlow"
    m["Date"] = formatdate(localtime=True)
    m["Message-ID"] = make_msgid(domain=dom or "sensflow.local")
    m["Auto-Submitted"] = "auto-generated"
    m["X-Auto-Response-Suppress"] = "All"
    m.set_content(_s(body) + "\n", charset="utf-8")
    # ⭐ 696: вкладення (ключ офісу в листі доступу). Той самий відправник — другого
    # збирача листів поруч не заводимо. Вкладення: (імʼя файла, байти, тип/підтип).
    for name, data, mime in (attachments or ()):
        maintype, _sl, subtype = _s(mime or "application/octet-stream").partition("/")
        raw = data if isinstance(data, (bytes, bytearray)) else _s(data).encode("utf-8")
        m.add_attachment(bytes(raw), maintype=maintype or "application",
                         subtype=subtype or "octet-stream", filename=_s(name) or "file")
    return m


@one_writer.guard("NOTIFY_MAIL_JSON")
def _mark(ok: bool, err: str = "") -> None:
    try:
        d = _load()
        if not d:
            return
        if ok:
            d["last_ok"], d["last_error"] = _now(), ""
            d["sent"] = int(d.get("sent") or 0) + 1
        else:
            d["last_error"] = "%s · %s" % (_now(), _s(err)[:300])
        _save(d)
    except Exception:
        pass


def send(to: str, subject: str, body: str, connect=None, attachments=None) -> bool:
    """Надіслати ОДИН лист від скриньки платформи. Відмова — `MailError` словами."""
    d = _load()
    if not configured(d):
        raise MailError("Пошта для сповіщень не налаштована: адміністратор заводить "
                        "скриньку платформи на сторінці «Пошта для сповіщень».")
    to = _check_address(to, "Адреса одержувача", RecipientError)
    msg = _message(d, to, subject, body, attachments)
    host = _s(d.get("host"))
    try:
        c, _h, _p, _sec = _login(_s(d.get("address")), _s(d.get("password")), host,
                                 d.get("port"), _s(d.get("security")), connect=connect)
    except MailError as ex:
        _mark(False, _s(ex))
        raise
    try:
        refused = c.send_message(msg)
    except smtplib.SMTPRecipientsRefused:
        _mark(True)                       # скринька жива, хибна лише адреса
        raise RecipientError("Сервер %s не прийняв адресу одержувача %s." % (host, to))
    except Exception as ex:
        why = _human(ex, host)
        _mark(False, why)
        raise MailError(why)
    finally:
        _quit(c)
    if refused:
        raise RecipientError("Сервер %s не прийняв адресу одержувача %s." % (host, to))
    _mark(True)
    return True


def test(to: str, by: str = "", connect=None) -> dict:
    """Перевірочний лист — щоб адміністратор побачив, що пошта справді доходить."""
    send(to, "SensFlow: перевірка пошти для сповіщень",
         "Це перевірочний лист платформи SensFlow.\n\n"
         "Якщо ви його отримали, сповіщення про задачі працівникам доходитимуть поштою.\n"
         "Надіслав: %s · %s" % (_s(by) or "адміністратор", _now()), connect=connect)
    return settings()


def _trace(note: str) -> None:
    """Слід у виводі сервера — без пароля за побудовою (його сюди не передають)."""
    try:
        sys.stderr.write("[пошта сповіщень] %s\n" % note)
    except Exception:
        pass
