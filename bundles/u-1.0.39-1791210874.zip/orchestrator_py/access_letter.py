# -*- coding: utf-8 -*-
"""access_letter.py — ЛИСТ ДОСТУПУ НОВОМУ ПРАЦІВНИКУ (зміна 696, 05.10.2026).

🩸 ЩО БУЛО. Завів адміністратор запис — і далі сам, руками, кожному писав: адресу
платформи, логін, пароль, файл ключа офісу і як його ставити. В ОТУ це ~600 людей; пароль
ішов чужими руками відкритим текстом. Слово Андрія 05.10.2026: пакет іде працівнику САМ
при натисканні «Завести запис», без окремої дії.

⛒ ЗАКОНИ:
  1. ПАРОЛЯ В ЛИСТІ НЕМАЄ НІКОЛИ. Замість нього — разове посилання «встановити свій
     пароль» (`password_link`: 24 год, один раз). Навіть пароль, який ввів адміністратор,
     у лист не йде: людина ставить свій, і чужий перестає діяти.
  2. ТОКЕН — У «#»-ЧАСТИНІ АДРЕСИ. Цю частину браузер не шле на сервер, тож токен не
     осідає в журналах проксі (NPM в ОТУ) і в журналах платформи.
  3. ЛИСТ ІДЕ САМ (`after_create`), якщо є пошта в картці, пошта сповіщень і адреса для
     працівників. Чого бракує — перевіряється ДО видачі посилання: не пішов лист — не
     згасло й попереднє посилання. Не пішов — екран каже ЧОМУ і дає «надіслати ще раз».
  4. КЛЮЧ ОФІСУ — ЛИШЕ КОЛИ ЛЮДИ ЗАХОДЯТЬ ПРЯМО НА ПЛАТФОРМУ (порт адреси = порт
     платформи: браузер бачить НАШ сертифікат). За проксі зі своїм сертифікатом (NPM)
     ключ не потрібен і не їде. Файл — той самий, що на екрані «Шифрування»
     (`https_access.ca_public_pem`): другого джерела ключа немає.
  5. АДРЕСА І ДОВІРЕНИЙ ПРОКСІ — ОДИН ПИСАР (`save_settings`): перевіряє словами, кладе в
     `.env.local` (переживе перезапуск) І в памʼять процесу (діє одразу), пише в журнал
     безпеки «було → стало».
  6. ВІДПРАВНИК ОДИН — `notify_mail.send`. Слід кожного листа — у журналі безпеки
     (кому, пішов чи ні); токена там немає.

Лише stdlib + модулі платформи.
"""
import ipaddress
from datetime import datetime
from urllib.parse import urlsplit

import clock
import config
import one_writer
import taskdesk_identity as identity
import taskdesk_people as people

config.refuse_live_state_for_checks(__name__)
LETTERS_JSON = identity.DESK_DIR / "access_letters.json"
KEY_URL = "SENSFLOW_PUBLIC_URL"
KEY_PROXY = "TRUSTED_PROXY"          # той самий ключ, що читає `client_addr` (695)
PAGE = "/set_password"
KEY_FILE = "SensFlow_office_key.crt"
SUBJECT = "SensFlow: ваш доступ до робочої платформи"


class LetterError(Exception):
    """Відмова словами."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _dmy(iso: str) -> str:
    try:
        return datetime.fromisoformat(_s(iso)).strftime("%d.%m.%Y %H:%M")
    except ValueError:
        return _s(iso)


# ── АДРЕСА ДЛЯ ПРАЦІВНИКІВ І ДОВІРЕНИЙ ПРОКСІ ───────────────────────────────
def _norm_url(raw: str) -> str:
    """Адреса, яку набирають працівники: https://хост[:порт], без шляху."""
    v = _s(raw)
    if not v:
        return ""
    bad = ("Адреса для працівників «%s» не підходить: потрібна адреса виду "
           "https://sensflow.компанія.ua або https://10.1.1.69:%d — без шляху й параметрів."
           % (v, int(getattr(config, "PORT", 7799))))
    try:
        u = urlsplit(v)
        port = u.port                                 # кидає ValueError на сміття
    except ValueError:
        raise LetterError(bad)
    if u.scheme != "https":
        raise LetterError(bad + " Лише https: працівник вводить у неї пароль.")
    if not u.hostname or u.query or u.fragment or u.path not in ("", "/") \
            or u.username or u.password:
        raise LetterError(bad)
    host = u.hostname
    if ":" in host:
        host = "[%s]" % host
    return "https://%s%s" % (host, (":%d" % port) if port else "")


def _norm_proxies(raw: str) -> str:
    """Перелік довірених проксі: адреси або підмережі через кому. Сміття — відмова."""
    out = []
    for part in _s(raw).replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            net = ipaddress.ip_network(part, strict=False)
        except ValueError:
            raise LetterError("Довірений проксі «%s» — не адреса і не підмережа. Пишіть "
                              "адресу проксі (наприклад 10.1.1.10) або підмережу "
                              "(10.1.1.0/24), кілька — через кому." % part)
        out.append(str(net.network_address) if net.num_addresses == 1 else str(net))
    return ", ".join(out)


def public_url() -> str:
    """Адреса для працівників: названа адміністратором, а якщо ні — адреса платформи в
    мережі (коли мережу відкрито). Порожньо — адреси немає, лист не піде."""
    named = _s(config.ENV.get(KEY_URL))
    if named:
        try:
            return _norm_url(named)
        except LetterError:
            return ""
    return _auto_url()


def _auto_url() -> str:
    try:
        import network_access
        st = network_access.state()
        return _s(st.get("url_lan")) if st.get("is_open") else ""
    except Exception:
        return ""


def needs_office_key(url: str) -> bool:
    """Закон 4: браузер бачить НАШ сертифікат лише тоді, коли йде прямо на порт платформи."""
    try:
        u = urlsplit(_s(url))
        port = u.port or (443 if u.scheme == "https" else 80)
    except ValueError:
        return False
    return bool(u.hostname) and port == int(getattr(config, "PORT", 7799))


def save_settings(public_url_raw: str, trusted_proxy_raw: str) -> dict:
    """Закон 5. Повертає новий огляд для екрана."""
    url = _norm_url(public_url_raw)
    proxies = _norm_proxies(trusted_proxy_raw)
    was_url, was_px = _s(config.ENV.get(KEY_URL)), _s(config.ENV.get(KEY_PROXY))
    changes = []
    if was_url != url:
        changes.append(("адреса для працівників", was_url or "—", url or "—"))
    if was_px != proxies:
        changes.append(("довірений проксі", was_px or "—", proxies or "—"))
    if changes:
        config.update_env_local({KEY_URL: url, KEY_PROXY: proxies})
        config.ENV[KEY_URL] = url
        config.ENV[KEY_PROXY] = proxies
        import security_log
        security_log.access_settings(changes)
    return overview()


# ── СТАН ЛИСТІВ ─────────────────────────────────────────────────────────────
def _letters() -> dict:
    if not LETTERS_JSON.exists():
        return {}
    try:
        raw = one_writer.read_json(LETTERS_JSON)
    except PermissionError:
        raise
    except Exception:
        return {}
    return {k: v for k, v in ((raw or {}).get("accounts") or {}).items() if isinstance(v, dict)}


@one_writer.guard("LETTERS_JSON")
def _remember(acc_id: str, rec: dict) -> None:
    st = _letters()
    st[_s(acc_id)] = rec
    live = {a["id"] for a in identity.accounts()}
    st = {k: v for k, v in st.items() if k in live}       # прибраний запис — без сліду
    LETTERS_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(LETTERS_JSON, {"accounts": st})


def _mail_ready() -> bool:
    try:
        import notify_mail
        return bool(notify_mail.configured())
    except Exception:
        return False


def overview() -> dict:
    """Що бачить екран «Доступи»: адреса, проксі, пошта, стан листа кожного запису."""
    import password_link
    url = public_url()
    return {"public_url": url,
            "public_url_named": _s(config.ENV.get(KEY_URL)),
            "public_url_auto": _auto_url(),
            "trusted_proxy": _s(config.ENV.get(KEY_PROXY)),
            "mail_ready": _mail_ready(),
            "office_key_in_letter": needs_office_key(url) if url else False,
            "link_hours": password_link.TTL_HOURS,
            "accounts": _letters()}


# ── САМ ЛИСТ ────────────────────────────────────────────────────────────────
KEY_STEPS = (
    "Ключ офісу. До листа додано файл %s. Без нього браузер покаже попередження "
    "про небезпечне зʼєднання. Встановіть його один раз на кожному компʼютері, з якого "
    "заходите:\n"
    "\n"
    "Chrome і Edge (Windows):\n"
    "  1. Збережіть файл %s з листа на компʼютер і відкрийте його подвійним клацанням.\n"
    "  2. Натисніть «Установити сертифікат…» (Install Certificate…), оберіть «Поточний "
    "користувач» → «Далі».\n"
    "  3. Оберіть «Помістити всі сертифікати в таке сховище» → «Огляд…» → «Довірені "
    "кореневі центри сертифікації» → «OK» → «Далі» → «Готово».\n"
    "  4. На попередження Windows про безпеку натисніть «Так».\n"
    "  5. Закрийте всі вікна браузера і відкрийте адресу платформи знову.\n"
    "\n"
    "Firefox (має власне сховище, тому окремо):\n"
    "  1. Меню → «Налаштування» → «Приватність і безпека» → внизу розділ «Сертифікати» → "
    "«Переглянути сертифікати…».\n"
    "  2. Вкладка «Центри сертифікації» → «Імпортувати…» → оберіть файл %s.\n"
    "  3. Поставте позначку «Довіряти цьому CA ідентифікацію вебсайтів» → «OK».\n"
    % (KEY_FILE, KEY_FILE, KEY_FILE))


def compose(acc: dict, emp: dict, url: str, token: str, expires_iso: str,
            with_key: bool) -> tuple:
    """(тема, текст). Закон 1: пароля тут немає — його сюди просто не передають."""
    link = "%s%s#t=%s" % (url, PAGE, token)
    lines = [
        "Добрий день, %s!" % (_s(emp.get("full_name")) or _s(acc.get("login"))),
        "",
        "Для вас заведено доступ до робочої платформи SensFlow.",
        "",
        "Адреса платформи: %s" % url,
        "Ваш логін: %s" % _s(acc.get("login")),
        "",
        "Пароль ви встановлюєте самі — за цим посиланням:",
        link,
        "",
        "Посилання спрацьовує один раз і діє до %s." % _dmy(expires_iso),
        "Пароль — не коротший за %d знаків. Нікому його не повідомляйте: адміністратор "
        "вашого пароля не знає і ніколи його не спитає." % identity.MIN_PASSWORD,
        "",
        "Після цього відкривайте адресу платформи і входьте зі своїм логіном і паролем.",
    ]
    if with_key:
        lines += ["", KEY_STEPS.rstrip("\n")]
    lines += [
        "",
        "Посилання не відкривається або строк вийшов — зверніться до адміністратора "
        "платформи: він надішле новий лист доступу.",
        "",
        "Цей лист надіслано автоматично, відповідати на нього не потрібно.",
    ]
    return SUBJECT, "\n".join(lines)


def _why_not(acc: dict, emp: dict, url: str) -> str:
    """Чого бракує, щоб лист пішов. Порожньо — усе є (закон 3: до видачі посилання)."""
    if not acc:
        return "облікового запису немає"
    if not acc["active"] or not acc["employee_active"]:
        return "запис заблоковано або працівника звільнено — лист доступу не надсилається"
    if not _s((emp or {}).get("email")):
        return ("у картці працівника немає пошти — впишіть її в картку і натисніть "
                "«Надіслати лист доступу»")
    if not _mail_ready():
        return ("Пошта для сповіщень не налаштована — заведіть скриньку платформи на "
                "сторінці «Пошта для сповіщень», потім «Надіслати лист доступу»")
    if not url:
        return ("не названо адресу для працівників — впишіть її в картці «Лист доступу» "
                "на цьому екрані, потім «Надіслати лист доступу»")
    if needs_office_key(url):
        import https_access
        if not _s(https_access.ca_public_pem()):
            return ("люди заходять прямо на платформу, а ключа офісу ще немає — створіть "
                    "сертифікат у картці «Шифрування», потім «Надіслати лист доступу»")
    return ""


def send_for(acc_id: str) -> dict:
    """Надіслати лист доступу. Відповідь — стан для екрана (пішов / ні і чому)."""
    import notify_mail
    import password_link
    import security_log
    acc = identity.account(acc_id)
    if not acc:
        raise LetterError("облікового запису «%s» немає" % _s(acc_id))
    emp = people.employee(acc["employee_id"]) or {}
    to = _s(emp.get("email"))
    url = public_url()
    rec = {"at": clock.now(), "to": to, "ok": False, "reason": "", "until": "",
           "with_key": False}
    why = _why_not(acc, emp, url)
    if not why:
        with_key = needs_office_key(url)
        token = password_link.issue(acc["id"])
        until = password_link.expires_of(token)
        subject, body = compose(acc, emp, url, token, until, with_key)
        att = []
        if with_key:
            import https_access
            att.append((KEY_FILE, https_access.ca_public_pem().encode("utf-8"),
                        "application/x-x509-ca-cert"))
        try:
            notify_mail.send(to, subject, body, attachments=att)
            rec.update(ok=True, until=until, with_key=with_key)
        except notify_mail.MailError as e:
            why = "лист не пішов: %s" % _s(e)
    rec["reason"] = why
    _remember(acc["id"], rec)
    security_log.access_letter(acc, to, rec["ok"], why)
    out = dict(rec)
    out["sent"] = rec["ok"]
    return out


def after_create(acc: dict) -> dict:
    """Закон 3: лист іде САМ при заведенні запису. Ніколи не валить заведення."""
    try:
        return send_for(acc["id"])
    except Exception as e:                            # noqa: BLE001
        return {"sent": False, "ok": False, "reason": "лист не пішов: %s" % _s(e)}
