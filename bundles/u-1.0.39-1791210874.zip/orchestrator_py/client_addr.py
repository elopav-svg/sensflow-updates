# -*- coding: utf-8 -*-
"""client_addr.py — ЗВІДКИ ПРИЙШОВ ЗАПИТ (зміна 695, 05.10.2026).

🩸 ЗНАЙДЕНО НА РОЗГОРТАННІ ОТУ. ІТ ставлять платформу за Nginx Proxy Manager: домен із їхнім
сертифікатом на проксі, далі https на адресу сервера. Платформа брала адресу ЛИШЕ зі
зʼєднання — тож за проксі всі люди мали одну адресу, адресу проксі. Захист від підбору (665)
за двадцять помилок по всьому офісу закривав вхід УСІМ, а журнал безпеки (663) бачив лише
проксі.

⛒ ЗАКОНИ:
  1. ВІДПОВІДЬ ОДНА. Сервер питає тут (`server._client_ip`), і звідти адреса йде в контекст
     протоколу, журнал безпеки і суддю паузи — другого місця, де її вгадують, немає.
  2. ЗАГОЛОВКУ ВІРИМО ЛИШЕ ВІД ДОВІРЕНОГО ПРОКСІ. X-Forwarded-For пише той, хто стукає;
     правдою він стає тільки тоді, коли САМЕ ЗʼЄДНАННЯ прийшло з адреси, яку адміністратор
     назвав проксі (`TRUSTED_PROXY` у `.env.local`: адреси або підмережі через кому).
     Порожньо — заголовків не читаємо зовсім, як до 695.
  3. У ЛАНЦЮЖКУ БЕРЕМО ПРАВУ АДРЕСУ, ЩО НЕ Є НАШИМ ПРОКСІ. Ліву частину дописує клієнт.
  4. СМІТТЯ — НЕ АДРЕСА. Не розібралось як IP — лишається адреса зʼєднання.
  5. НАЛАШТУВАННЯ ЧИТАЄТЬСЯ НА КОЖНОМУ ЗАПИТІ — екран міняє його без перезапуску.
"""
import ipaddress

import config

KEY = "TRUSTED_PROXY"


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _ip(v):
    try:
        return ipaddress.ip_address(_s(v))
    except ValueError:
        return None


def _nets(raw: str) -> list:
    out = []
    for part in _s(raw).replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            out.append(ipaddress.ip_network(part, strict=False))
        except ValueError:
            continue                      # сміття в переліку не ламає справжніх адрес
    return out


def trusted_list() -> list:
    """Довірені проксі словами — для екрана «Доступи» і вікна запуску."""
    return [str(n.network_address) if n.num_addresses == 1 else str(n)
            for n in _nets(config.ENV.get(KEY))]


def _trusted(addr, nets) -> bool:
    a = _ip(addr)
    return bool(a) and any(a.version == n.version and a in n for n in nets)


def real_ip(peer: str, headers) -> str:
    """Адреса людини. `peer` — адреса зʼєднання; `headers` — заголовки запиту (має .get)."""
    peer = _s(peer)
    nets = _nets(config.ENV.get(KEY))
    if not nets or not _trusted(peer, nets):
        return peer
    get = getattr(headers, "get", None)
    if not callable(get):
        return peer
    chain = [x.strip() for x in _s(get("X-Forwarded-For")).split(",") if x.strip()]
    for hop in reversed(chain):
        if _ip(hop) is None:
            return peer                   # ланцюжок зіпсовано — не вгадуємо далі
        if not _trusted(hop, nets):
            return str(_ip(hop))
    real = _ip(get("X-Real-IP"))
    if real is not None and not chain:
        return str(real)
    return peer
