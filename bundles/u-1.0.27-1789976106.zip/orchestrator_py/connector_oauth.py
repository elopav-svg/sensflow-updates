# -*- coding: utf-8 -*-
"""ДВЕРІ ДО ЧУЖОГО СЕРВІСУ (OAuth) — ОДИН ПИСАР.

⭐⭐⭐ 12.08.2026 (зміна 163). Крок 2 конекторів.

Зміна 162 навчила платформу ЧЕСНО КАЗАТИ, що входу немає
(`registry.REQUIRABLE_INPUTS`). Цей модуль дає САМ ВХІД: спосіб отримати
згоду людини на її ж пошту/календар і зберегти токен так, щоб його побачили
ворота, які вже стоять.

⛒ ЧОМУ ОДИН ПИСАР. Правда про двері складається з чотирьох речей, і кожна
вміє розійтися зі своїм близнюком:
  • ФОРМА АДРЕСИ ПОВЕРНЕННЯ — її будує і кнопка «Підключити», і обробник
    повернення. Різні рядки = `redirect_uri_mismatch` (клас «два писарі
    однієї правди»).
  • ШЛЯХ ФАЙЛА ТОКЕНА — сюди ПИШЕ цей модуль, а ЧИТАЄ `registry`
    (`connector_ready` → ворота збірки, запуску і самомодель). Писар шляху
    тут один: `token_path()`.
  • ПРАВА (scopes) — що саме дозволила людина.
  • МЕЖА ПРОВАЙДЕРА — те, чого ми не можемо змінити (див. `caveat`).

⛒ НОВИЙ КОНЕКТОР = НОВИЙ РЯДОК У `DOORS`, і більше нічого правити не треба:
ендпоінти сервера і картка в консолі загальні, по `id`.

Жодних зовнішніх залежностей.
"""

import json
import secrets
import time
import urllib.parse
import urllib.request

import config
import features


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЦЕ ПЛАТНИЙ РІВЕНЬ (слово Андрія 12.08.2026)
# ---------------------------------------------------------------------------
# «Конектори — частина Task Desk і окремий рівень автоматизації, і тому поїде до
# клієнта виключно за гроші. Робимо на моїй машині, на клієнтів не поширюємо.»
#
# ⛒ ВИМКНЕНА РІЧ НЕ МУСИТЬ СВІТИТИСЬ У КЛІЄНТА НАВІТЬ КАРТКОЮ. Побачити двері,
# яких у тебе немає, — це та сама обіцянка відсутнього, від якої лікувалась
# зміна 162, і водночас безкоштовний показ платного.
# ⛒ Вимикач НЕ свій: той самий один писар, що тримає Task Desk
# (`features.enabled`), і за замовчуванням ВИМКНЕНО скрізь, включно з еталоном.
WORK_ID = "connectors_oauth"


def enabled() -> bool:
    """ЄДИНА відповідь «чи цей рівень куплено/увімкнено»."""
    return features.enabled(WORK_ID)


# ---------------------------------------------------------------------------
# ПРОВАЙДЕРИ — чиї це двері й де вони стоять
# ---------------------------------------------------------------------------
PROVIDERS = {
    "google": {
        "name": "Google",
        "auth_endpoint": "https://accounts.google.com/o/oauth2/v2/auth",
        "token_endpoint": "https://oauth2.googleapis.com/token",
        "client_id_key": "GOOGLE_OAUTH_CLIENT_ID",
        "client_secret_key": "GOOGLE_OAUTH_CLIENT_SECRET",
        # Що зробити людині, якщо ключів немає. Пишемо ДІЮ, а не назву біди.
        "setup": ("У Google Cloud створіть OAuth-клієнт типу «Desktop app», "
                  "увімкніть потрібні API і впишіть GOOGLE_OAUTH_CLIENT_ID та "
                  "GOOGLE_OAUTH_CLIENT_SECRET у файл .env.local у корені платформи."),
        # 🩸 МЕЖА, ПРО ЯКУ ПЛАТФОРМА МУСИТЬ СКАЗАТИ САМА, а не показати через
        # тиждень порожньою скринькою. Джерело — документація Google
        # (developers.google.com/identity/protocols/oauth2, розділ про строк
        # життя): застосунок зі статусом «Testing» і зовнішнім типом
        # користувача отримує refresh-токен, який живе 7 днів. Також згода
        # злітає, коли людина міняє пароль Google (для прав Gmail).
        "caveat": ("Поки застосунок у Google має статус «Testing», згода живе 7 днів — "
                   "після цього підключення треба буде повторити. Згода також злітає, "
                   "якщо змінити пароль Google."),
    },
}


# ---------------------------------------------------------------------------
# ДВЕРІ — який конектор які права просить
# ---------------------------------------------------------------------------
# ⛒ Права просимо НАЙВУЖЧІ, які покривають обіцянку. «Прочитати листи» — це
# `gmail.readonly`: платформа не може ні надіслати, ні видалити нічого.
DOORS = {
    "google_mail": {
        "provider": "google",
        "scopes": ["https://www.googleapis.com/auth/gmail.readonly"],
        "grants": "читати ваші листи (надсилати чи видаляти платформа не зможе)",
    },
    "google_calendar": {
        "provider": "google",
        "scopes": ["https://www.googleapis.com/auth/calendar.events"],
        "grants": "бачити і створювати події у вашому календарі",
    },
}


# ---------------------------------------------------------------------------
# Шляхи на диску (ОДИН писар)
# ---------------------------------------------------------------------------
def token_path(connector_id: str, owner: str):
    """Де лежить токен конектора. ⭐ Той самий шлях ЧИТАЄ `registry`.

    ⭐⭐⭐ 617. ВЛАСНИК — ОБОВʼЯЗКОВИЙ АРГУМЕНТ, а не зручність. Доти шлях
    складався з самої назви конектора, і «ресурс без власника» неможливо було
    навіть помітити. Тепер кожен, хто йде до токена, мусить спершу відповісти
    «чий», а відповідь на це питання має рівно одного писаря
    (`connector_owner.owner_of`).
    ⛒ Порожній власник — це СПІЛЬНИЙ файл (компанійський конектор або
    одноосібна збірка), і він лежить рівно там, де лежав завжди: робота
    клієнта з одним господарем не змінюється ні на байт."""
    who = "" if owner is None else str(owner).strip()
    name = "%s.token.json" % connector_id
    if who:
        return config.CONNECTORS_DIR / "employees" / who / name
    return config.CONNECTORS_DIR / name


# ⛒⛒⛒ 617. ПОЗНАЧКА БЕЗПЕКИ ІМЕНУЄТЬСЯ САМА СОБОЮ, А НЕ КОНЕКТОРОМ.
# Доти файл звався «<конектор>.oauth_state.json» — один на конектор. Двоє
# менеджерів, що натиснули «Підключити» одночасно, затирали позначку одне
# одному, і другий отримував «позначку не впізнано» на рівному місці.
# А головне: позначка — це ЄДИНЕ місце, де записано, ХТО САМЕ давав згоду.
# Тому вона зберігає власника, і саме з неї його бере `finish`: людина, яка
# лише відкрила зворотню адресу, чужої згоди собі не забирає.
def _state_dir():
    return config.CONNECTORS_DIR / "oauth_state"


def _state_file(state: str):
    safe = "".join(ch for ch in str(state or "") if ch.isalnum())
    return _state_dir() / ("%s.json" % safe)


def _read_json(path, default=None):
    try:
        raw = path.read_text(encoding="utf-8-sig")
        return json.loads(raw)
    except Exception:
        return default


def _write_json(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# Стан дверей
# ---------------------------------------------------------------------------
def has_door(connector_id: str) -> bool:
    """Чи вміє платформа взагалі відмикати цей конектор."""
    return str(connector_id or "") in DOORS


def _provider(connector_id: str):
    door = DOORS.get(str(connector_id or ""))
    if not door:
        return None, None
    return door, PROVIDERS.get(door["provider"])


def credentials(connector_id: str):
    """(client_id, client_secret) з .env.local. Порожньо = дверей ще нема чим відмикати."""
    door, prov = _provider(connector_id)
    if not prov:
        return "", ""
    cid = str(config.ENV.get(prov["client_id_key"], "") or "").strip()
    sec = str(config.ENV.get(prov["client_secret_key"], "") or "").strip()
    return cid, sec


def configured(connector_id: str) -> bool:
    cid, sec = credentials(connector_id)
    return bool(cid and sec)


def redirect_uri(connector_id: str) -> str:
    """⭐ ОДИН ПИСАР ФОРМИ АДРЕСИ ПОВЕРНЕННЯ.

    Її мусять однаково знати троє: кнопка (тут), обробник повернення в сервері
    і сам Google. Порт беремо з `config.PORT`, а не з голови: у клієнта він
    може бути інший. Саме тому OAuth-клієнт узятий типу «Desktop» — Google для
    адреси 127.0.0.1 НЕ звіряє порт (перевірено живим 12.08.2026).
    """
    return "http://127.0.0.1:%d/api/connectors/%s/oauth/callback" % (
        int(config.PORT), connector_id)


def caveat(connector_id: str) -> str:
    _door, prov = _provider(connector_id)
    return (prov or {}).get("caveat", "")


def grants(connector_id: str) -> str:
    door, _prov = _provider(connector_id)
    return (door or {}).get("grants", "")


def setup_hint(connector_id: str) -> str:
    _door, prov = _provider(connector_id)
    return (prov or {}).get("setup", "")


def connected_at(connector_id: str, owner: str = None) -> str:
    who = _owner(connector_id, owner)[0]
    return str((_read_json(token_path(connector_id, who), {}) or {}).get("connected_at") or "")


def _owner(connector_id: str, owner=None):
    """(власник, відмова). ⭐ Питаємо ОДНОГО писаря — `connector_owner`."""
    if owner is not None:
        return str(owner).strip(), ""
    try:
        import connector_owner
        return connector_owner.owner_of(connector_id)
    except Exception:
        return "", ""


# ---------------------------------------------------------------------------
# КРОК 1: почати
# ---------------------------------------------------------------------------
def start(connector_id: str):
    """→ (адреса згоди, помилка). Помилка — ТЕКСТ ЛЮДИНІ, не код."""
    if not enabled():
        return "", "Цей рівень автоматизації у вашій збірці не підключено."
    door, prov = _provider(connector_id)
    if not door:
        return "", "Платформа не вміє підключати «%s»." % connector_id
    client_id, client_secret = credentials(connector_id)
    if not (client_id and client_secret):
        return "", ("Підключення не налаштоване. %s" % prov["setup"])

    owner, why = _owner(connector_id)
    if why:
        return "", why

    state = secrets.token_hex(24)
    _write_json(_state_file(state),
                {"state": state, "created_at": _now(),
                 "connector_id": connector_id, "owner": owner})

    params = {
        "client_id": client_id,
        "redirect_uri": redirect_uri(connector_id),
        "response_type": "code",
        "scope": " ".join(door["scopes"]),
        # ⛒ offline + consent: без них Google не дасть refresh-токена, і зв'язок
        # помре через годину — тихо, вже після того, як ми сказали «підключено».
        "access_type": "offline",
        "prompt": "consent",
        "include_granted_scopes": "true",
        "state": state,
    }
    return (prov["auth_endpoint"] + "?" + urllib.parse.urlencode(params)), ""


# ---------------------------------------------------------------------------
# КРОК 2: завершити
# ---------------------------------------------------------------------------
def finish(connector_id: str, code: str, state: str, error: str = ""):
    """→ (ok, текст людині). Пише токен рівно туди, куди дивляться ворота."""
    if not enabled():
        return False, "Цей рівень автоматизації у вашій збірці не підключено."
    door, prov = _provider(connector_id)
    if not door:
        return False, "Платформа не вміє підключати «%s»." % connector_id
    if error:
        return False, "Авторизацію не завершено: %s." % error

    stored = _read_json(_state_file(state), None) or {}
    if (stored and str(stored.get("connector_id") or "") != str(connector_id)):
        stored = {}                 # позначка від ІНШИХ дверей — не приймаємо
    if not code or not state or stored.get("state") != state:
        # ⛒ Не «щось пішло не так»: називаємо ПРИЧИНУ і що робити.
        return False, ("Позначку безпеки (state) не впізнано — можливо, вікно згоди "
                       "провисіло надто довго або відкривалось двічі. Натисніть "
                       "«Підключити» ще раз.")
    # ⭐ ХТО ДАВАВ ЗГОДУ — ЛЕЖИТЬ У ПОЗНАЧЦІ, а не в тому, хто відкрив
    # зворотню адресу. Це та сама різниця, що між «я підписав» і «я приніс
    # конверт».
    owner = str(stored.get("owner") or "").strip()

    # Позначка одноразова: другий раз тим самим кодом уже не зайти.
    try:
        _state_file(state).unlink()
    except Exception:
        pass

    client_id, client_secret = credentials(connector_id)
    ok, payload = _post_form(prov["token_endpoint"], {
        "code": code,
        "client_id": client_id,
        "client_secret": client_secret,
        "redirect_uri": redirect_uri(connector_id),
        "grant_type": "authorization_code",
    })
    if not ok:
        return False, payload
    if not payload.get("access_token"):
        return False, "Сервіс не повернув ключа доступу — підключення не відбулось."
    if not payload.get("refresh_token"):
        # ⛒ Без refresh-токена «підключено» протримається годину і тихо помре.
        # Краще чесна відмова зараз, ніж мовчазна поломка завтра.
        return False, ("Сервіс не повернув ключа для продовження доступу. "
                       "Відкрийте myaccount.google.com/permissions, приберіть доступ "
                       "застосунку і натисніть «Підключити» ще раз.")
    _save_token(connector_id, owner, payload)
    return True, ""


def _save_token(connector_id: str, owner: str, payload: dict, keep_refresh: str = "",
                keep_refresh_expires_at: int = 0):
    data = dict(payload or {})
    if keep_refresh and not data.get("refresh_token"):
        # Google віддає refresh-токен ЛИШЕ першого разу — при оновленні його
        # треба донести самим, інакше наступне оновлення нічим буде робити.
        data["refresh_token"] = keep_refresh
    now = int(time.time())
    try:
        data["expires_at"] = now + int(data.get("expires_in") or 0)
    except Exception:
        data["expires_at"] = 0
    # ⛒ ПРОДОВЖЕННЯ КЛЮЧА НЕ ПОЧИНАЄ ЗГОДУ ЗАНОВО. Сім днів рахуються від
    # миті, коли людина натиснула «дозволити», а не від останнього оновлення:
    # інакше строк згоди «самооновлювався» б до нескінченності на папері й
    # помирав би мовчки в житті.
    try:
        kept = int(keep_refresh_expires_at or 0)
    except Exception:
        kept = 0
    if kept:
        data["refresh_expires_at"] = kept
    else:
        try:
            life = int(data.get("refresh_token_expires_in") or 0)
        except Exception:
            life = 0
        if life:
            data["refresh_expires_at"] = now + life
    data.pop("revoked_at", None)
    data["connector_id"] = connector_id
    data["owner"] = str(owner or "")
    data["connected_at"] = _now()
    _write_json(token_path(connector_id, owner), data)
    return data


# ---------------------------------------------------------------------------
# ⭐⭐⭐ 18.09.2026 (зміна 610). ОДИН ПИСАР ПРАВДИ ПРО СТАН ДВЕРЕЙ.
#
# КОРІНЬ: правду про приватний конектор писав рядок «у файлі є access_token».
# Тому 18.09.2026 платформа місяць казала «підключено 12.08.2026» про згоду,
# яка вмерла 19.08: ключ доступу живе годину, а ЗГОДА в режимі «Testing» —
# сім днів. Ворота збірки й запуску пропускали роботу, самомодель мовчала про
# межу, а на картці не було кнопки «підключити заново».
#
# ⛒ КЛЮЧ, ЯКИЙ БІЛЬШЕ НЕ ПОВЕРТАЄ ЗАМОК, — НЕ КЛЮЧ. Питання про двері одне,
#   і відповідає на нього ТІЛЬКИ `liveness`. Хто питає інакше — бреше.
# ⛒ ІНШИЙ БІК: здогадкою живе не вбиваємо. Конектор, про строк якого нам
#   нічого не відомо (github), лишається придатним зі станом `unknown` —
#   чесне «не знаю» замість вигаданої смерті.
# ---------------------------------------------------------------------------
CONSENT_DEAD_MARK = "Підключіть конектор заново."


def _epoch(stamp) -> int:
    """Мить із запису «2026-08-12T16:20:23» (або з «...Z»). 0 = не прочитали."""
    raw = str(stamp or "").strip()
    if not raw:
        return 0
    raw = raw.replace("Z", "")
    if "." in raw:
        raw = raw.split(".", 1)[0]
    try:
        return int(time.mktime(time.strptime(raw, "%Y-%m-%dT%H:%M:%S")))
    except Exception:
        return 0


def consent_deadline(data: dict) -> int:
    """Мить, коли вмирає ЗГОДА ЛЮДИНИ (не ключ доступу). 0 = строку не оголошено.

    ⭐ Два джерела, бо на диску живуть файли обох поколінь: новий пише строк
    прямо (`refresh_expires_at`), старий — лише тривалість від миті згоди."""
    if not isinstance(data, dict):
        return 0
    try:
        direct = int(data.get("refresh_expires_at") or 0)
    except Exception:
        direct = 0
    if direct:
        return direct
    base = _epoch(data.get("connected_at"))
    try:
        life = int(data.get("refresh_token_expires_in") or 0)
    except Exception:
        life = 0
    return (base + life) if (base and life) else 0


def human_day(moment: int) -> str:
    """День у форматі DD.MM.YYYY — так, як його читає власник."""
    try:
        return time.strftime("%d.%m.%Y", time.localtime(int(moment)))
    except Exception:
        return ""


def liveness(connector_id: str, owner=None) -> dict:
    """ЄДИНА правда про двері: {state, usable, until, why}.

    state: absent | live | renewable | expired | unknown
    usable: чи має платформа право обіцяти цю роботу ПРЯМО ЗАРАЗ.

    ⭐ 617. Питання «чи є конектор» більше не існує окремо від питання «У
    КОГО». Власника називає один писар; коли назвати його нікому (компанія
    вже багатокористувацька, а дія безіменна) — це ВІДМОВА, а не спільна
    скринька."""
    cid = str(connector_id or "")
    who, why_owner = _owner(cid, owner)
    if why_owner:
        return {"state": "absent", "usable": False, "until": "", "why": why_owner}
    data = _read_json(token_path(cid, who), None) or {}
    if not (data.get("access_token") or data.get("token")):
        return {"state": "absent", "usable": False, "until": "",
                "why": _absent_why(cid, who)}

    deadline = consent_deadline(data)
    until = human_day(deadline) if deadline else ""

    revoked = str(data.get("revoked_at") or "").strip()
    if revoked:
        return {"state": "expired", "usable": False, "until": until,
                "why": "Згода протермінована — сервіс відмовив у продовженні "
                       "доступу. Підключіть конектор заново."}

    now = int(time.time())
    try:
        expires_at = int(data.get("expires_at") or 0)
    except Exception:
        expires_at = 0
    if expires_at > now + 60:
        return {"state": "live", "usable": True, "until": until, "why": ""}

    refresh = str(data.get("refresh_token") or "")
    if not refresh:
        if not expires_at:
            # Строку не оголошено взагалі (напр. довічний ключ github).
            return {"state": "unknown", "usable": True, "until": "",
                    "why": "Строку дії цього доступу сервіс не оголошує."}
        return {"state": "expired", "usable": False, "until": until,
                "why": "Доступ протух, а ключа для продовження немає. "
                       "Підключіть конектор заново."}
    if deadline and deadline <= now:
        return {"state": "expired", "usable": False, "until": until,
                "why": "Згода протермінована %s. Підключіть конектор заново." % until}
    return {"state": "renewable", "usable": True, "until": until, "why": ""}


def legacy_present(connector_id: str) -> bool:
    """⭐⭐⭐ 617. ЧИ ЛЕЖИТЬ НА ЦІЙ МАШИНІ СПІЛЬНА ЗГОДА, ДАНА ДО ПОЯВИ ВЛАСНИКІВ.

    ⛒ МОВЧАЗНА СМЕРТЬ СТАРОЇ ЗГОДИ — ЦЕ ВАДА 610 НАВИВОРІТ. Після цієї зміни
    особистий конектор шукає токен у теці СВОГО працівника, а старий спільний
    файл лишається лежати. Не сказати про це означає дати людині «не
    підключено» там, де вона вчора працювала, і жодної підказки чому.
    ⛒ І НЕ ПРИВЛАСНИТИ: хто саме давав ту згоду, не записав ніхто — тому вона
    нічия, і вгадувати власника ми не станемо. Чесна відповідь одна: підключіть
    заново своїм іменем."""
    data = _read_json(token_path(connector_id, ""), None) or {}
    return bool(data.get("access_token") or data.get("token"))


def _absent_why(connector_id: str, owner: str) -> str:
    """Відмова НАЗИВАЄ людину. «Конектор не підключено» у компанії з пʼятьма
    менеджерами не каже нічого: не підключено В КОГО?"""
    try:
        import connector_owner
        return connector_owner.absent_why(connector_id, owner)
    except Exception:
        return "Конектор не підключено."


def _mark_revoked(connector_id: str, owner: str = "") -> None:
    """Слід відмови сервісу — щоб наступний, хто спитає, не почув «підключено».

    ⛒ Ставиться ЛИШЕ коли відмовив САМ сервіс. Обірвана мережа — це «не знаю»,
    а не «згоди немає»: вбити згоду через чужий збій означає послати людину
    на зайве перепідключення."""
    path = token_path(connector_id, owner)
    data = _read_json(path, None)
    if not data:
        return
    data["revoked_at"] = _now()
    _write_json(path, data)


# ---------------------------------------------------------------------------
# КРОК 3: живий ключ для інструментів
# ---------------------------------------------------------------------------
def access_token(connector_id: str, owner=None):
    """→ (ключ, помилка). Сам продовжує доступ, коли той протух.

    ⛒ Інструменти НЕ читають файл токена самі: інакше кожен новий інструмент
    мусив би пам'ятати про строк життя — і той, хто забуде, стане дірою.
    ⭐ 617: і про власника теж — тому «чий ключ» вирішується ТУТ, один раз.
    """
    door, prov = _provider(connector_id)
    if not door:
        return "", "Платформа не вміє підключати «%s»." % connector_id
    who, why_owner = _owner(connector_id, owner)
    if why_owner:
        return "", why_owner
    data = _read_json(token_path(connector_id, who), None)
    if not data or not data.get("access_token"):
        return "", _absent_why(connector_id, who)
    # 60 секунд запасу: ключ, що протухне в польоті, — та сама поломка.
    if int(data.get("expires_at") or 0) > int(time.time()) + 60:
        return str(data["access_token"]), ""

    # ⭐ 610: чи варто взагалі стукати — вирішує той самий писар, що й UI.
    state = liveness(connector_id, who)
    if not state.get("usable"):
        return "", state.get("why") or "Конектор не підключено."
    refresh = str(data.get("refresh_token") or "")
    if not refresh:
        return "", "Доступ протух, а ключа для продовження немає — підключіть конектор заново."
    client_id, client_secret = credentials(connector_id)
    ok, payload = _post_form(prov["token_endpoint"], {
        "refresh_token": refresh,
        "client_id": client_id,
        "client_secret": client_secret,
        "grant_type": "refresh_token",
    })
    if not ok:
        # ⛒ ВІДМОВУ САМОГО СЕРВІСУ ЗАПИСУЄМО, чужий збій мережі — НІ.
        if CONSENT_DEAD_MARK in str(payload or ""):
            _mark_revoked(connector_id, who)
        return "", payload
    fresh = _save_token(connector_id, who, payload, keep_refresh=refresh,
                        keep_refresh_expires_at=consent_deadline(data))
    return str(fresh.get("access_token") or ""), ""


# ---------------------------------------------------------------------------
# Вихід назовні (один прохід, зі слідом)
# ---------------------------------------------------------------------------
def _post_form(url: str, form: dict):
    """→ (ok, дані) або (False, ТЕКСТ ЛЮДИНІ).

    ⛒ Сирий текст помилки сервісу зберігаємо в журналі виходів, а людині
    віддаємо зрозуміле речення (урок 11.08: спершу сирий текст, потім порада).
    """
    body = urllib.parse.urlencode(form).encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST", headers={
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept": "application/json",
    })
    raw, status = "", 0
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            status = int(getattr(resp, "status", 200) or 200)
            raw = resp.read().decode("utf-8", "replace")
    except Exception as exc:
        raw = getattr(exc, "read", lambda: b"")()
        try:
            raw = raw.decode("utf-8", "replace")
        except Exception:
            raw = ""
        status = int(getattr(exc, "code", 0) or 0)
        _trace(url, status, raw or str(exc))
        return False, _human_error(status, raw, str(exc))
    _trace(url, status, "ok")
    try:
        return True, json.loads(raw)
    except Exception:
        return False, "Сервіс відповів не тим, чого ми чекали — підключення не відбулось."


def _human_error(status: int, raw: str, fallback: str) -> str:
    code = ""
    try:
        code = str((json.loads(raw) or {}).get("error") or "")
    except Exception:
        code = ""
    if code == "invalid_grant":
        return ("Google більше не приймає цю згоду (найчастіше — вона протухла: "
                "у режимі «Testing» згода живе 7 днів). " + CONSENT_DEAD_MARK)
    if code == "redirect_uri_mismatch":
        return ("Google не впізнав адресу повернення. Перевірте, що OAuth-клієнт "
                "має тип «Desktop app».")
    if code in ("invalid_client", "unauthorized_client"):
        return "Google не впізнав наш застосунок — перевірте ключі в .env.local."
    if status:
        return "Сервіс відмовив (код %d)%s." % (status, (": " + code) if code else "")
    return "Не вдалося звʼязатися з сервісом: %s." % fallback


def _trace(url: str, status: int, note: str):
    try:
        import egress_guard
        egress_guard.log("connector_oauth", {"url": url, "status": status,
                                             "note": (note or "")[:300]})
    except Exception:
        pass


def _now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S")
