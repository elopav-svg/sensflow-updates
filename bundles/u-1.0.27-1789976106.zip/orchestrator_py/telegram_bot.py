"""
telegram_bot.py — Telegram-вхід до SensFlow.

ДВА НЕЗАЛЕЖНІ БОТИ (обидва через long-polling, лише stdlib/urllib):
  • Оркестратор  (роль "orchestrator") — токен TELEGRAM_BOT_TOKEN.
      Приватний: лише власник(и) з TELEGRAM_ALLOWED_CHAT_IDS. Приймає задачі →
      engine.handle_message → відповідь + готові файли назад у чат.
  • Підтримка    (роль "support")      — токен TELEGRAM_SUPPORT_BOT_TOKEN.
      Клієнти (схвалені в консолі) → support_brain; складне ескалює власнику.
      Реагує лише коли TELEGRAM_SUPPORT_MODE=1 (тумблер «підтримка увімкнена»).

Кожен бот — свій фоновий потік-поллер зі своїм токеном і роллю (thread-local
контекст `_ctx`). Жодних вхідних портів: боти самі опитують Telegram.

Запуск:
  • автоматично — фоновими потоками із server.py (start_in_background);
  • окремо — `python telegram_bot.py`.
"""

import io
import json
import sys
import time
import threading
import urllib.request
import urllib.parse
import urllib.error

import config
import engine
import netfetch          # ЄДИНЕ вікно назовні: телеграм більше не ходить у мережу сам
import tender_outbound   # вартовий: тендерний текст без печатки не виходить
import threads as threadstore
import filetext
import telegram_access
import support_brain
import inbound

_API = "https://api.telegram.org/bot{token}/{method}"
_FILE_API = "https://api.telegram.org/file/bot{token}/{file_path}"

# Сумісність зі старим кодом: токен «за замовчуванням» = оркестратор.
_TOKEN = (config.ENV.get("TELEGRAM_BOT_TOKEN") or "").strip()

# Контекст поточного поллера — свій у кожному потоці-боті (який токен, яка роль).
_ctx = threading.local()


def _tok() -> str:
    return getattr(_ctx, "token", "") or (config.ENV.get("TELEGRAM_BOT_TOKEN") or "").strip()


def _role() -> str:
    return getattr(_ctx, "role", "orchestrator")


def _orch_token() -> str:
    return (config.ENV.get("TELEGRAM_BOT_TOKEN") or "").strip()


def _support_token() -> str:
    return (config.ENV.get("TELEGRAM_SUPPORT_BOT_TOKEN") or "").strip()


def _tasks_token() -> str:
    return (config.ENV.get("TELEGRAM_TASKS_BOT_TOKEN") or "").strip()


ROLES = ("orchestrator", "support", "tasks")

# ⭐⭐⭐ ЩО МИ ВЗАГАЛІ ПРОСИМО В ТЕЛЕГРАМА. Доти тут було лише "message" — і це
# означало, що кнопки під повідомленням ФІЗИЧНО МЕРТВІ: натискання до бота не
# доходить взагалі. Тримати це значенням, а не рядком усередині циклу, треба
# для того, щоб чек міг його спитати, а не вишукувати в тексті коду.
POLL_UPDATES = ("message", "callback_query")
_TOKEN_OF = {"orchestrator": _orch_token, "support": _support_token, "tasks": _tasks_token}


def _run_as(role: str, fn):
    """ОДИН перемикач бота. Токен лежить у контексті ПОТОКУ (`_ctx`), а не в
    глобальній змінній: рот доставляє зі свого потоку, поки поллери в своїх —
    і жоден не забирає в іншого його бота."""
    role = ("" if role is None else str(role)).strip()
    get = _TOKEN_OF.get(role)
    if get is None:
        raise ValueError("Невідома роль бота «%s». Відомі: %s"
                         % (role, ", ".join(ROLES)))
    tok = get()
    if not tok:
        raise ValueError("Бот ролі «%s» не налаштований: немає токена." % role)
    old = getattr(_ctx, "token", None)
    old_role = getattr(_ctx, "role", None)
    _ctx.token, _ctx.role = tok, role
    try:
        return fn()
    finally:
        _ctx.token, _ctx.role = old, old_role


def send_as(role: str, chat_id, text: str, markup=None) -> bool:
    """ЄДИНИЙ ВИХІД У ТЕЛЕГРАМ ДЛЯ ЧУЖОГО КОДУ.

    ⭐ Рот задач не має власного дроту назовні: він просить цей файл, а той
    ходить через `netfetch` — те саме вікно, під тими самими воротами виходу.
    Другого шляху в телеграм у продукті немає й не буде.

    ⭐ `markup` — кнопки під повідомленням. Вони ПЕРСОНАЛЬНІ: рот рахує їх на
    кожного адресата окремо, бо постановник і виконавець можуть різне."""
    return _run_as(role, lambda: _send_message(chat_id, text, markup))


def answer_callback_as(role: str, callback_id, text: str = "") -> bool:
    """Погасити годинник у людини після натискання.

    ⭐ ОБОВʼЯЗКОВО І ЗАВЖДИ, навіть на відмові: телеграм крутить годинник, поки
    бот не відповів, і людина тисне ще раз — а це вже друга дія."""
    return _run_as(role, lambda: _answer_callback(callback_id, text))


def edit_markup_as(role: str, chat_id, message_id, markup=None) -> bool:
    """Прибрати (або замінити) кнопки під уже надісланим повідомленням.

    ⭐ `message_id` телеграм приносить сам у натисканні, тож зберігати його
    ніде не треба — і не зʼявляється ще один стан."""
    return _run_as(role, lambda: _edit_markup(chat_id, message_id, markup))


_RICH_EXT = (".docx", ".xlsx", ".pptx", ".pdf", ".csv")
_MAX_MSG = 3800          # запас під ліміт Telegram у 4096 символів
_CHAT_THREADS = {}       # (role, chat_id) -> thread_id (мапінг у памʼяті процесу)


# ДОСТУП ДО БОТІВ — ОДИН СПИСОК НА ОБИДВА (31.07.2026).
# Було ДВА писарі однієї правди: сторінка «Авторизовані користувачі» писала у
# свій файл, а бот-оркестратор питав owner_ids() — лише .env.local. Клієнт
# додавав себе кнопкою, кнопка казала «додано», бот не пускав. Кнопка, яка
# спрацювала і нічого не зробила, — брехня на екрані.
#  • обидва боти пускають за telegram_access.is_allowed() = .env.local + консоль;
#  • owner_ids() лишається ВЛАСНИКОМ (ескалації, мовчання в групі) — це інша роль.
def _is_allowed(chat_id) -> bool:
    return telegram_access.is_allowed(chat_id)


def _sender_name(msg) -> str:
    f = msg.get("from") or {}
    name = " ".join(x for x in (f.get("first_name"), f.get("last_name")) if x).strip()
    if f.get("username"):
        name = (name + f" (@{f['username']})").strip()
    return name


def _signal_inbound(msg, chat_id):
    """Фаза 4: вхідне від клієнта → позначка «потребує уваги» на його картці CRM.
    У приваті ідентифікатор = chat_id; у групі = відправник (from_id). Повідомлення
    власника НЕ рахуємо за інбаунд. Тиха, відмово-стійка операція (не ламає відповідь)."""
    try:
        chat = msg.get("chat") or {}
        is_group = (chat.get("type") or "private") in ("group", "supergroup")
        frm = msg.get("from") or {}
        from_id = frm.get("id")
        signal_id = from_id if is_group else chat_id
        if signal_id is None or signal_id in telegram_access.owner_ids():
            return
        text = (msg.get("text") or msg.get("caption") or "").strip()
        inbound.from_telegram(signal_id, username=(frm.get("username") or ""),
                              name=_sender_name(msg), text=text)
    except Exception as e:
        sys.stderr.write(f"[tg] inbound-сигнал: {e}\n")


def ready() -> bool:
    return any(_TOKEN_OF[r]() for r in ROLES)


# ── Низькорівневі виклики Bot API (токен = поточний бот через _tok()) ────────
def _api(method, params=None, timeout=60):
    """Виклик Telegram API через ЄДИНЕ вікно назовні (netfetch).

    ЧОМУ НЕ urllib НАПРЯМУ (як було до 27.07.2026). Телеграм — це канал, яким
    факти виходять до людини. Власний urllib означав, що цей канал обходить
    ворота виходу: у режимі максимального збереження / Стелс дані пішли б
    назовні непоміченими, і жоден МАЙБУТНІЙ мережевий канал не був би прикритий
    автоматично. Тіло на дроті лишилось те саме (form-urlencoded).
    """
    url = _API.format(token=_tok(), method=method)
    body = urllib.parse.urlencode(params or {}).encode("utf-8")
    raw = netfetch.post_json(
        url, payload=body, timeout=timeout,
        extra_headers={"Content-Type": "application/x-www-form-urlencoded"})
    return json.loads(raw)


def _split(text, n=_MAX_MSG):
    text = text or ""
    if len(text) <= n:
        return [text] if text.strip() else []
    out, cur = [], ""
    for line in text.split("\n"):
        while len(line) > n:                       # дуже довгий рядок ріжемо жорстко
            if cur:
                out.append(cur); cur = ""
            out.append(line[:n]); line = line[n:]
        if len(cur) + len(line) + 1 > n:
            if cur:
                out.append(cur)
            cur = line
        else:
            cur += (("\n" if cur else "") + line)
    if cur.strip():
        out.append(cur)
    return out


def _send_message(chat_id, text, markup=None):
    # ⭐ ВАРТОВИЙ НА ВИХОДІ. Стоїть ДО нарізки на шматки — інакше перевіряли б
    # уламки тексту, а не повідомлення. Тендерний текст без печатки складача
    # (tender_message.build) сюди не проходить: замість нього піде чесна відмова.
    text = tender_outbound.guard(text)
    ok = False
    chunks = _split(text)
    for i, chunk in enumerate(chunks):
        params = {"chat_id": chat_id, "text": chunk,
                  "disable_web_page_preview": "true"}
        # Кнопки — під ОСТАННІМ шматком: довгий текст ріжеться, а дії в людини
        # мають бути наприкінці, а не посеред розповіді.
        if markup and i == len(chunks) - 1:
            params["reply_markup"] = json.dumps(markup, ensure_ascii=False)
        try:
            _api("sendMessage", params)
            ok = True
        except Exception as e:
            sys.stderr.write(f"[tg] sendMessage: {e}\n")
            return False
    # ⚠ Повертаємо ПРАВДУ про відправку: сторож позначає тендер «надісланим»
    # лише коли він реально пішов. Інакше тендер зникне назавжди — його вже
    # не покажуть удруге, а людина його ніколи не бачила.
    return ok


def _answer_callback(callback_id, text=""):
    """Коротка спливашка у відповідь на натискання."""
    try:
        _api("answerCallbackQuery",
             {"callback_query_id": callback_id, "text": (text or "")[:190]})
        return True
    except Exception as e:
        sys.stderr.write(f"[tg] answerCallbackQuery: {e}\n")
        return False


def _edit_markup(chat_id, message_id, markup=None):
    """Порожня розмітка = кнопок більше немає (дію вже зроблено)."""
    try:
        _api("editMessageReplyMarkup",
             {"chat_id": chat_id, "message_id": message_id,
              "reply_markup": json.dumps(markup or {"inline_keyboard": []},
                                         ensure_ascii=False)})
        return True
    except Exception as e:
        sys.stderr.write(f"[tg] editMessageReplyMarkup: {e}\n")
        return False


def _send_chat_action(chat_id, action="typing"):
    try:
        _api("sendChatAction", {"chat_id": chat_id, "action": action})
    except Exception:
        pass


def _send_document(chat_id, path, filename):
    try:
        with open(path, "rb") as f:
            content = f.read()
    except Exception as e:
        sys.stderr.write(f"[tg] read file {path}: {e}\n")
        return
    boundary = "----orx" + str(int(time.time() * 1000))
    body = io.BytesIO()

    def w(s):
        body.write(s.encode("utf-8") if isinstance(s, str) else s)

    w(f"--{boundary}\r\nContent-Disposition: form-data; name=\"chat_id\"\r\n\r\n{chat_id}\r\n")
    w(f"--{boundary}\r\nContent-Disposition: form-data; name=\"document\"; "
      f"filename=\"{filename}\"\r\n")
    w("Content-Type: application/octet-stream\r\n\r\n")
    w(content)
    w(f"\r\n--{boundary}--\r\n")
    try:
        netfetch.post_json(
            _API.format(token=_tok(), method="sendDocument"),
            payload=body.getvalue(), timeout=180,
            extra_headers={"Content-Type": f"multipart/form-data; boundary={boundary}"})
    except Exception as e:
        sys.stderr.write(f"[tg] sendDocument {filename}: {e}\n")


def _download_file(file_id):
    info = _api("getFile", {"file_id": file_id})
    fp = (info.get("result") or {}).get("file_path")
    if not fp:
        return None, None
    url = _FILE_API.format(token=_tok(), file_path=fp)
    return fp.split("/")[-1], netfetch.get_bytes(url, timeout=180)


# ── Обробка повідомлень ────────────────────────────────────────────────────
def _thread_for(chat_id):
    key = (_role(), chat_id)
    tid = _CHAT_THREADS.get(key)
    if tid and threadstore.get(tid):
        return tid
    tid = threadstore.create(title=f"Telegram {chat_id}")["id"]
    _CHAT_THREADS[key] = tid
    return tid


def _handle_callback(cb):
    """Натиснули кнопку під повідомленням.

    ⭐ Кнопки має лише бот задач. Але чужа роль мусить хоча б погасити годинник:
    мовчання виглядає як «зламалось», і людина тисне ще раз."""
    if _role() != "tasks":
        _answer_callback((cb or {}).get("id"), "")
        return
    import taskdesk_tg_input as _ear
    _ear.on_press(cb)


def _chat_of_update(upd) -> str:
    """Чий це чат — однаково для натискання кнопки й для повідомлення."""
    cb = (upd or {}).get("callback_query") or {}
    msg = cb.get("message") or (upd or {}).get("message") \
        or (upd or {}).get("edited_message") or {}
    return str(((msg.get("chat") or {}).get("id")) or "")


def _open_step(upd) -> None:
    """⭐ ДВЕРІ НАЗИВАЮТЬ СЕБЕ (зміна 172, 13.08.2026).

    КОРІНЬ. Живий прогін 13.08 показав: відповідь Андрія З ТЕЛЕГРАМА лягла в
    загальний протокол БЕЗ ДЖЕРЕЛА — на питання «звідки береться робота» цілий
    канал мовчав. Двері консолі назвали себе ще в 171, а двері телеграма — ні.
    ⛒ Джерело й діяча ставить ТОЙ, ХТО КРОК ВІДКРИВАЄ (закон зміни 169): писарі
    протоколу сидять поверхом нижче й про канал не знають.

    ⚠ `clear()` перед `bind()`: вухо телеграма — один потік на всі чати, і без
    очистки контекст попереднього повідомлення мовчки приписав би роботу не тій
    людині. ⚠ Ніколи не кидає: журнал не сміє валити бота."""
    try:
        import protocol as _proto
        import entity as _ent
        _proto.clear()
        _proto.bind(source=_proto.S_TELEGRAM)
        if _role() != "tasks":
            return                     # інші роботи бота задач не заводять
        import taskdesk_tg_input as _ear
        who = _ent.person_of_employee(_ear.actor_of(_chat_of_update(upd)))
        if who:
            _proto.bind(actor=who)
    except Exception:
        pass


def _handle_update(upd):
    _open_step(upd)
    cb = upd.get("callback_query")
    if cb:
        _handle_callback(cb)
        return
    msg = upd.get("message") or upd.get("edited_message")
    if not msg:
        return
    chat_id = (msg.get("chat") or {}).get("id")
    if chat_id is None:
        return

    role = _role()

    # ── БОТ ПІДТРИМКИ (@TechCareSF) ──────────────────────────────────────────
    if role == "support":
        if not config.TELEGRAM_SUPPORT_MODE:
            return  # підтримку призупинено тумблером у консолі
        # Шлагбаум: обслуговуємо лише авторизованих; решта → черга заявок власнику.
        if not _is_allowed(chat_id):
            try:
                telegram_access.record_pending(chat_id, _sender_name(msg))
            except Exception:
                pass
            _send_message(chat_id,
                          "🔒 Це приватний бот. Ваш запит на доступ надіслано власнику.\n"
                          f"Ваш Telegram ID: {chat_id}\n"
                          "Щойно власник схвалить його в консолі — ви зможете користуватися ботом.")
            sys.stderr.write(f"[tg/support] заявка неавторизованому chat_id={chat_id}\n")
            return
        # Інбаунд-сигнал: клієнт написав → бейдж «уваги» на його картці CRM.
        _signal_inbound(msg, chat_id)
        chat_type = (msg.get("chat") or {}).get("type") or "private"
        is_group = chat_type in ("group", "supergroup")
        if is_group:
            from_id = (msg.get("from") or {}).get("id")
            # У групі бот МОВЧИТЬ на повідомлення власника — відповідає сам Андрій.
            if from_id is not None and from_id in telegram_access.owner_ids():
                return
        _handle_support(chat_id, msg, is_group=is_group)
        return

    # ── БОТ ЗАДАЧ (Task Desk) ────────────────────────────────────────────────
    # Це РОТ: він приносить людині її задачі. Роботу з нього не запускають —
    # для цього є бот-оркестратор, і змішувати їх не можна: у бота задач сидять
    # УСІ працівники клієнта, а платні прогони запускають не всі.
    if role == "tasks":
        _handle_tasks(chat_id, msg)
        return

    # ── БОТ ОРКЕСТРАТОРА (@SFAIO) — приватний ────────────────────────────────
    # Пускає ТОЙ САМИЙ список, що й бот підтримки: .env.local + схвалені в консолі.
    from_id = (msg.get("from") or {}).get("id")
    is_owner = _is_allowed(chat_id) or (from_id is not None and _is_allowed(from_id))
    if not is_owner:
        # Відмова МУСИТЬ давати шлях усередину: інакше замкнене коло — щоб додати
        # себе, треба знати свій номер, а дізнатись його ніде (баг 31.07.2026).
        try:
            telegram_access.record_pending(chat_id, _sender_name(msg))
        except Exception:
            pass
        _send_message(chat_id,
                      "🔒 Це приватний бот-оркестратор SensFlow. "
                      "Ваш запит на доступ надіслано власнику.\n"
                      f"Ваш Telegram ID: {chat_id}\n"
                      "Щойно власник схвалить його в консолі — ви зможете користуватися ботом.")
        sys.stderr.write(f"[tg/orch] заявка неавторизованому chat_id={chat_id}\n")
        return

    text = (msg.get("text") or msg.get("caption") or "").strip()

    if text in ("/start", "/help"):
        _send_message(chat_id,
                      "Вітаю! Я ваш AI-оркестратор. Надішліть задачу людською мовою або "
                      "прикріпіть файл (docx, xlsx, pdf, csv, txt) — я визначу потрібну "
                      "систему, виконаю її, перевірю результат і поверну готові файли.")
        return

    # Прикріплений документ → витяг тексту в контекст
    files_context = ""
    doc = msg.get("document")
    if doc:
        try:
            name, raw = _download_file(doc.get("file_id"))
            if raw:
                fname = doc.get("file_name") or name or "файл"
                extracted = filetext.extract_text(fname, raw)
                if extracted and extracted.strip():
                    files_context = f"## ДОДАНИЙ ФАЙЛ: {fname}\n{extracted}"
        except Exception as e:
            sys.stderr.write(f"[tg] download/extract: {e}\n")
            _send_message(chat_id, "Не вдалося прочитати прикріплений файл. "
                                   "Спробуйте інший формат (docx, xlsx, pdf, csv, txt).")

    if not text and not files_context:
        _send_message(chat_id, "Порожнє повідомлення. Напишіть задачу або прикріпіть файл.")
        return

    tid = _thread_for(chat_id)
    rec = threadstore.get(tid) or {}
    history = rec.get("messages", [])
    inherited_fc = files_context or threadstore.latest_files_context(tid)

    _send_chat_action(chat_id)
    _ack = {"t": time.time()}

    def emit(label):
        # Тримаємо «друкує…», але не спамимо повідомленнями.
        now = time.time()
        if now - _ack["t"] > 7:
            _ack["t"] = now
            _send_chat_action(chat_id)

    # ⭐⭐⭐ ВОРОТА 4 «ХТО ПИШЕ В ТЕЛЕГРАМ» (крок 1.5, 06.08.2026).
    # Телеграм — окремий вхід у ту саму роботу. Хто діє, вирішує не бот: він
    # питає єдиного відповідача, а привʼязку чату до людини робить адміністратор.
    import taskdesk_identity as _tdid
    _who = _tdid.resolve_actor(_tdid.account_by_telegram(chat_id))
    if _who is None:
        _send_message(chat_id,
                      "Цей чат ще не привʼязаний до працівника, тому запускати роботу "
                      "з нього не можна. Попросіть адміністратора привʼязати ваш "
                      "телеграм до вашого облікового запису в розділі «Доступи».")
        return

    try:
        res = engine.handle_message(_who,
                                    text or "(прикріплений файл)",
                                    history=history,
                                    files_context=inherited_fc,
                                    emit=emit)
    except Exception as e:
        sys.stderr.write(f"[tg] engine: {e}\n")
        _send_message(chat_id, f"Сталася помилка під час виконання: {e}")
        return

    reply = (res.get("reply") or "Готово.").strip()
    _send_message(chat_id, reply)

    # Згенеровані файли: надсилаємо «насичені» (docx/xlsx/pptx/pdf/csv),
    # а якщо таких немає — лишаємо md як запасний.
    result = res.get("result") or {}
    arts = [a for a in (result.get("artifacts") or []) if isinstance(a, dict) and a.get("path")]
    rich = [a for a in arts if a.get("filename", "").lower().endswith(_RICH_EXT)]
    to_send = rich or [a for a in arts if a.get("filename", "").lower().endswith(".md")][:1]
    if to_send:
        _send_chat_action(chat_id, "upload_document")
    for a in to_send:
        _send_document(chat_id, a["path"], a.get("filename", "result"))

    # Зберігаємо хід у thread (для контексту наступних повідомлень)
    try:
        threadstore.append(tid, "user", text or "(прикріплений файл)",
                           files_context=files_context or None)
        threadstore.append(tid, "assistant", reply)
    except Exception as e:
        sys.stderr.write(f"[tg] thread append: {e}\n")


# ── Бот задач (Task Desk): привʼязка чату до працівника ─────────────────────
def _handle_tasks(chat_id, msg):
    """ВЕСЬ ШЛЮЗ ЦЬОГО БОТА — РАЗОВИЙ КОД. Списку дозволених тут немає й не
    треба: чат, який не назвав коду, не привʼязаний ні до кого, а значить не
    існує для задач. Ворота 4 («немає привʼязки — немає актора») лишаються ті
    самі, просто тепер їх є чим відчинити."""
    import taskdesk_identity as _tdid
    import taskdesk_telegram as _mouth
    text = (msg.get("text") or msg.get("caption") or "").strip()
    cmd = text.split("@", 1)[0] if text.startswith("/") else ""
    acc = _tdid.account_by_telegram(chat_id)
    # ВЛАСНИЙ ВХІД. Постійні кнопки під полем вводу — це те, з чого людина
    # починає, не гортаючи історію чату. Реєстр меню один (`_mouth.MENU`).
    menu = _mouth.menu_markup()

    if cmd in ("/start", "/help"):
        if acc:
            _send_message(chat_id,
                          "Цей чат підключено до працівника: %s.\n"
                          "Знизу — дві кнопки: «Мої задачі» і «Поставити задачу».\n"
                          "Дії із задачею — кнопками під повідомленням про неї.\n"
                          "Відключити — команда /stop."
                          % (acc.get("employee_name") or acc.get("login")), menu)
        else:
            _send_message(chat_id,
                          "Вітаю! Я приношу задачі SensFlow.\n\n"
                          "Щоб підключити цей чат, відкрийте свою картку працівника "
                          "в розділі «Люди», натисніть «Підключити телеграм» і "
                          "надішліть сюди код із екрана.")
        return

    if cmd == "/stop":
        if not acc:
            _send_message(chat_id, "Цей чат і так ні до кого не підключений.")
            return
        try:
            _tdid.unlink_telegram(acc["id"])
        except Exception as e:
            _send_message(chat_id, "Не вдалося відключити: %s" % e)
            return
        _send_message(chat_id, "Відключено. Задачі сюди більше не приходитимуть. "
                               "Щоб підключити знову — візьміть новий код у своїй картці.")
        return

    if acc is None:
        if not text:
            _send_message(chat_id, "Надішліть код підключення з вашої картки працівника.")
            return
        try:
            linked = _tdid.link_by_code(text, chat_id)
        except Exception as e:
            # Відмова називає ПРИЧИНУ — інакше людина не знає, що робити далі.
            _send_message(chat_id, str(e))
            return
        _send_message(chat_id,
                      "Готово, %s. Цей чат підключено — новини про ваші задачі "
                      "приходитимуть сюди.\n"
                      "Знизу зʼявились кнопки «Мої задачі» і «Поставити задачу».\n"
                      "Відключити — команда /stop."
                      % (linked.get("employee_name") or linked.get("login")), menu)
        sys.stderr.write("[tg/tasks] чат %s привʼязано до %s\n"
                         % (chat_id, linked.get("id")))
        return

    # Бот міг щось спитати («напишіть результат») — тоді це ВІДПОВІДЬ, а не
    # команда. Питання живе на диску, тож перезапуск сервера його не губить.
    try:
        import taskdesk_tg_input as _ear
        if _ear.on_message(chat_id, text).get("taken"):
            return
    except Exception as e:
        sys.stderr.write("[tg/tasks] діалог: %s\n" % e)

    # ⭐⭐⭐ ЧЕСНА ЗАГЛУШКА. Раніше тут стояло «дії із задачею — на екрані задач
    # у SensFlow». Це НЕПРАВДИВА ПІДКАЗКА: екран стоїть на 127.0.0.1, і з
    # телефона до нього шляху немає. «Не можу» без «ось як зможу» — і ще й із
    # хибним напрямком — гірше за мовчання.
    _send_message(chat_id,
                  "Я приношу задачі й приймаю дії кнопками.\n"
                  "Знизу — «Мої задачі» (список із переходами) і «Поставити "
                  "задачу». Дії з конкретною задачею — кнопками під "
                  "повідомленням про неї.\n"
                  "Екран задач SensFlow працює лише на робочому компʼютері "
                  "(адреса 127.0.0.1) — із телефона він недосяжний, тому все "
                  "потрібне робиться тут кнопками.\n"
                  "/stop — відключити цей чат.", menu)


# ── Режим техпідтримки («Клод» / TechCareSF) ───────────────────────────────
def _download_photo(msg):
    """Найбільший розмір фото (скріншот) → (media_type, bytes) або (None, None)."""
    photos = msg.get("photo") or []
    if not photos:
        return None, None
    big = photos[-1]
    try:
        _name, raw = _download_file(big.get("file_id"))
        if raw:
            return "image/jpeg", raw
    except Exception as e:
        sys.stderr.write(f"[tg] download photo: {e}\n")
    return None, None


def _notify_owners(text):
    """Надсилає повідомлення власнику(ам) — для ескалацій підтримки."""
    try:
        owners = telegram_access.owner_ids()
    except Exception:
        owners = []
    for oid in owners:
        try:
            _send_message(oid, text)
        except Exception as e:
            sys.stderr.write(f"[tg] notify owner {oid}: {e}\n")


def _handle_support(chat_id, msg, is_group=False):
    """Техпідтримка: відповідь «Клод» з бази знань; невідоме/невпевнене → ескалація власнику.
    У групі (is_group): відповідає лише клієнту; повідомлення власника сюди не доходять (фільтр вище)."""
    text = (msg.get("text") or msg.get("caption") or "").strip()
    _cmd = text.split("@", 1)[0] if text.startswith("/") else text
    if _cmd in ("/start", "/help"):
        _send_message(chat_id,
                      f"Вітаю! Я {config.SUPPORT_BOT_NAME}, технічна підтримка SensFlow. "
                      "Опишіть проблему словами або надішліть скріншот — допоможу із запуском і "
                      "налаштуванням. Складні випадки передам Андрію.")
        return

    images = []
    mt, raw = _download_photo(msg)
    if raw:
        images.append({"media_type": mt, "data": raw})

    extra_text = ""
    doc = msg.get("document")
    if doc:
        fname = (doc.get("file_name") or "")
        mime = (doc.get("mime_type") or "")
        is_img = mime.startswith("image/") or fname.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))
        try:
            _n, draw = _download_file(doc.get("file_id"))
        except Exception as e:
            draw = None
            sys.stderr.write(f"[tg] support doc: {e}\n")
        if draw and is_img:
            images.append({"media_type": mime or "image/png", "data": draw})
        elif draw:
            try:
                ex = filetext.extract_text(fname or "файл", draw)
                if ex and ex.strip():
                    extra_text = f"\n\n[Вміст файлу {fname}]\n{ex[:4000]}"
            except Exception as e:
                sys.stderr.write(f"[tg] support extract: {e}\n")

    if not text and not images and not extra_text:
        if not is_group:   # у групі не шумимо на не-текстові події
            _send_message(chat_id, "Напишіть, будь ласка, питання або надішліть скріншот — і я допоможу.")
        return

    tid = _thread_for(chat_id)
    rec = threadstore.get(tid) or {}
    history = rec.get("messages", [])
    _send_chat_action(chat_id)
    try:
        res = support_brain.answer((text + extra_text).strip(), history=history,
                                   images=images or None)
    except Exception as e:
        sys.stderr.write(f"[tg] support_brain: {e}\n")
        _send_message(chat_id, "Вибачте, стався технічний збій. Передаю Андрію — він відповість.")
        _notify_owners(f"⚠️ Збій підтримки у боті: {e}\nКлієнт chat_id {chat_id}.")
        return

    reply = (res.get("reply") or "Готово.").strip()
    _send_message(chat_id, reply)

    if res.get("escalate"):
        who = _sender_name(msg) or str(chat_id)
        note = res.get("owner_note") or ""
        # У групі Андрій присутній — досить відповіді в чаті. У 1:1 — окремий DM власнику.
        if not is_group:
            _notify_owners(f"🆘 Ескалація від клієнта {who} (chat_id {chat_id}):\n{note}\n\n"
                           f"Клієнту вже відповіли «передаю Андрію». Дайте відповідь — він чекає.")

    try:
        threadstore.append(tid, "user", text or "(зображення)")
        threadstore.append(tid, "assistant", reply)
    except Exception as e:
        sys.stderr.write(f"[tg] support thread append: {e}\n")


def _net_note(role: str, text: str, state: dict) -> str:
    """ЩО САМЕ СКАЗАТИ ПРО МЕРЕЖЕВУ БІДУ — І ЧИ ГОВОРИТИ ВЗАГАЛІ.

    ⛒ 519: біда, що повторюється кожні пʼять секунд, за годину дає 720
    однакових рядків. Вікно (а під службою — файл журналу) перетворюється
    на стіну, у якій не видно нічого іншого, і людина перестає туди
    дивитись. Кажемо ТРИ речі: коли почалось, зрідка — що досі триває, і
    коли скінчилось. Порожній `text` означає «звʼязок відновився».

    Повертає готовий рядок або порожньо. Стан живе в переданому словнику,
    тобто в кожного бота свій — і чиста функція судиться чеком.
    """
    prev = state.get("last") or ""
    if not text:
        n = int(state.get("same") or 0)
        state["last"] = ""
        state["same"] = 0
        if prev:
            return "[tg/%s] мережа: звʼязок відновився%s\n" % (
                role, (" (змовчав про %d однакових)" % n) if n else "")
        return ""
    if text != prev:
        state["last"] = text
        state["same"] = 0
        return "[tg/%s] %s\n" % (role, text)
    n = int(state.get("same") or 0) + 1
    state["same"] = n
    if n in (12, 120, 1200):
        return "[tg/%s] те саме повторилось %d разів поспіль\n" % (role, n)
    return ""


# ── Цикл long-polling (по одному на кожен бот) ──────────────────────────────
def _loop(token, role):
    _ctx.token = token
    _ctx.role = role
    sys.stderr.write(f"[tg/{role}] бот запущено (long-polling)\n")
    offset = None
    # 519: памʼять про те, що вже сказано, щоб не повторювати одне й те саме.
    _noise = {"last": "", "same": 0}
    while True:
        try:
            params = {"timeout": 50,
                      "allowed_updates": json.dumps(list(POLL_UPDATES))}
            if offset is not None:
                params["offset"] = offset
            resp = _api("getUpdates", params, timeout=65)
            _say = _net_note(role, "", _noise)   # 519: звʼязок є
            if _say:
                sys.stderr.write(_say)
            for upd in resp.get("result", []):
                offset = upd["update_id"] + 1
                try:
                    _handle_update(upd)
                except Exception as e:
                    sys.stderr.write(f"[tg/{role}] update: {e}\n")
        except urllib.error.URLError as e:
            # ⛒ 519: 409 — це НЕ мережа. Це друга копія SensFlow, що
            # опитує того самого бота. Кажемо і код, і що він означає.
            _msg = "мережа: %s; пауза 5с" % (e,)
            if getattr(e, "code", 0) == 409:
                _msg = ("мережа: HTTP 409 — цього бота вже опитує ІНША копія "
                        "SensFlow. Працювати має лише одна; пауза 5с")
            _say = _net_note(role, _msg, _noise)
            if _say:
                sys.stderr.write(_say)
            time.sleep(5)
        except Exception as e:
            _say = _net_note(role, "loop: %s; пауза 5с" % (e,), _noise)
            if _say:
                sys.stderr.write(_say)
            time.sleep(5)


_threads = {}   # role -> Thread


def _running(role) -> bool:
    t = _threads.get(role)
    return t is not None and t.is_alive()


def is_running() -> bool:
    return any(_running(r) for r in ROLES)


def _start_one(role, token) -> bool:
    """Запускає бота вказаної ролі (ідемпотентно). True, якщо працює."""
    if not token:
        return False
    if _running(role):
        return True
    th = threading.Thread(target=_loop, args=(token, role), daemon=True,
                          name=f"telegram-{role}")
    th.start()
    _threads[role] = th
    return True


def start_in_background() -> bool:
    """Запускає обидва боти (у кого є токен) фоновими демон-потоками. True, якщо хоч один працює."""
    started = [_start_one(r, _TOKEN_OF[r]()) for r in ROLES]
    return any(started)


def set_token(token: str) -> dict:
    """Зберігає токен ОРКЕСТРАТОРА у .env.local й запускає його бот — без рестарту."""
    global _TOKEN
    token = (token or "").strip()
    try:
        config.update_env_local({"TELEGRAM_BOT_TOKEN": token})
    except Exception as e:
        sys.stderr.write(f"[tg] збереження токена оркестратора: {e}\n")
    config.ENV["TELEGRAM_BOT_TOKEN"] = token
    _TOKEN = token
    started = _start_one("orchestrator", token) if token else False
    return {"has_token": bool(token), "running": _running("orchestrator"), "started": started}


def set_support_token(token: str) -> dict:
    """Зберігає токен ПІДТРИМКИ у .env.local й запускає її бот — без рестарту."""
    token = (token or "").strip()
    try:
        config.update_env_local({"TELEGRAM_SUPPORT_BOT_TOKEN": token})
    except Exception as e:
        sys.stderr.write(f"[tg] збереження токена підтримки: {e}\n")
    config.ENV["TELEGRAM_SUPPORT_BOT_TOKEN"] = token
    started = _start_one("support", token) if token else False
    return {"has_token": bool(token), "running": _running("support"), "started": started}


def set_tasks_token(token: str) -> dict:
    """Зберігає токен БОТА ЗАДАЧ і піднімає його — без рестарту.

    ⭐ ТУТ ЖЕ ПИТАЄМО В ТЕЛЕГРАМА ІМʼЯ БОТА. Без нього людина не знає, кому
    надсилати код підключення, і кнопка в картці веде в нікуди. Питаємо ОДИН
    раз — на кожному відкритті картки в мережу не ходять."""
    token = (token or "").strip()
    try:
        config.update_env_local({"TELEGRAM_TASKS_BOT_TOKEN": token})
    except Exception as e:
        sys.stderr.write(f"[tg] збереження токена задач: {e}\n")
    config.ENV["TELEGRAM_TASKS_BOT_TOKEN"] = token

    username, why = "", ""
    if token:
        old = getattr(_ctx, "token", None)
        _ctx.token = token
        try:
            me = _api("getMe", {}, timeout=20)
            username = ((me.get("result") or {}).get("username") or "").strip()
        except Exception as e:
            why = str(e)
            sys.stderr.write(f"[tg/tasks] getMe: {e}\n")
        finally:
            _ctx.token = old
    try:
        config.update_env_local({"TELEGRAM_TASKS_BOT_USERNAME": username})
    except Exception as e:
        sys.stderr.write(f"[tg] збереження імені бота задач: {e}\n")
    config.ENV["TELEGRAM_TASKS_BOT_USERNAME"] = username

    started = _start_one("tasks", token) if token else False
    mouth = False
    try:
        import taskdesk_telegram as _mouth
        mouth = _mouth.start_in_background()
    except Exception as e:
        sys.stderr.write(f"[tg/tasks] доставку не запущено: {e}\n")
    return {"has_token": bool(token), "running": _running("tasks"),
            "started": started, "username": username, "delivery": mouth,
            "why": why}


def status() -> dict:
    return {
        "has_token": ready(),
        "running": is_running(),
        "orchestrator": {"has_token": bool(_orch_token()), "running": _running("orchestrator")},
        "support": {"has_token": bool(_support_token()), "running": _running("support")},
        "tasks": {"has_token": bool(_tasks_token()), "running": _running("tasks")},
    }


if __name__ == "__main__":
    if not start_in_background():
        print("Немає жодного токена (TELEGRAM_BOT_TOKEN / TELEGRAM_SUPPORT_BOT_TOKEN / "
              "TELEGRAM_TASKS_BOT_TOKEN) у .env.local — бот не запущено.")
        sys.exit(1)
    while True:
        time.sleep(3600)
