# -*- coding: utf-8 -*-
"""project_doors.py — ОДНЕ МІСЦЕ ПРАВДИ ПРО ТЕ, ДЕ В ТЕЦІ «Проект ИИ» ЖИВІ
ДВЕРІ, ДЕ АРХІВ І ДЕ ЛЕЖАТЬ ЖУРНАЛИ (зміна 649, 26.09.2026).

🩸 Досі три перевірки знали це кожна по-своєму: суддя батників судив архів як
живі двері; проба «направлено» шукала батник публікації лише в корені й за одним
іменем; писар журналу клав журнали в корінь. Тому будь-який порядок у теці —
перенести кнопки Каспера в його теку, відпрацьоване в архів — робив набір
червоним або сліпим, а корінь заростав сам.

⛒ Правило тепер одне:
  * тека, в імені якої є «архів» або «backup», — сховище, а не двері;
  * кнопки клієнта живуть у теці клієнта (напр. «Каспер») і судяться як двері;
  * батник публікації — той, що кличе `publish_update.py`, де б він не лежав у
    корені чи в теках клієнтів (з їхніми архівами); тека платформи й бекапи
    кнопок публікації не тримають;
  * журнали прогонів — у `_Журнали прогонів`.
"""
import os
from pathlib import Path

LOG_DIR_NAME = "_Журнали прогонів"
ARCHIVE_WORDS = ("архів", "backup")
# Теки, де кнопок публікації не буває: машинне відділення, бекапи, службове.
_NOT_DOOR_HOMES = ("AI_Orchestrator_Platform", "node_modules", "__pycache__")
_BACKUP_PREFIXES = ("Бекапи", "_бекап")


def is_archive_dir(name: str) -> bool:
    """Архів — сховище відпрацьованого, а не двері."""
    low = (name or "").lower()
    return any(w in low for w in ARCHIVE_WORDS)


def _walk(root: Path, max_depth: int, keep_dir):
    root = Path(root)
    root_parts = len(root.parts)
    for cur, dirs, files in os.walk(root):
        here = Path(cur)
        if len(here.parts) - root_parts >= max_depth:
            dirs[:] = []
        else:
            dirs[:] = [d for d in dirs if not d.startswith(".") and keep_dir(d)]
        for f in sorted(files):
            if f.lower().endswith(".bat"):
                yield here / f


def walk_bats(root, max_depth=3, skip=()):
    """Живі двері: усі батники до глибини `max_depth`, крім архівів і `skip`."""
    skip = set(skip)
    return _walk(root, max_depth, lambda d: d not in skip and not is_archive_dir(d))


def publish_bats(root, max_depth=3):
    """Батники публікації в корені й теках клієнтів — разом з архівами (там
    лежить зразок, з якого пишеться наступний)."""
    def keep(d):
        return d not in _NOT_DOOR_HOMES and not d.startswith(_BACKUP_PREFIXES)
    out = []
    for p in _walk(root, max_depth, keep):
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if "publish_update.py" in txt:
            out.append(p)
    return out


def newest_publish_bat(root):
    """Найсвіжіший батник публікації або None, якщо його немає ніде."""
    bats = publish_bats(root)
    return max(bats, key=lambda p: p.stat().st_mtime) if bats else None
