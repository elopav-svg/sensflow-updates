# -*- coding: utf-8 -*-
"""owner_card.py — КАРТКА УЧАСНИКА: читаємо файл клієнта, кладемо в базу знань.

⭐⭐⭐ 24.08.2026, зміна 209. ОБІЦЯНКА, ЯКОЇ КОД НЕ ВИКОНУВАВ.
Клієнту обіцяно: «покладіть у теку бази знань файл із даними компанії — платформа
візьме реквізити звідти й підставить у документи». Насправді код лише ЗНАХОДИВ
файл за словом у НАЗВІ і запам'ятовував шлях; вміст не читав НІХТО. Назва й
ЄДРПОУ бралися тільки з `owner.json`, якого не було ні в кого. Тому в пакеті
Каспера стояли прочерки там, де дані в нього на диску лежали.

⛒ ЗАКОН ЦЬОГО МОДУЛЯ:
  1. Витяг ДЕТЕРМІНОВАНИЙ — правила, а не модель. Той самий файл на будь-якій
     машині дає той самий результат, і це не коштує грошей.
  2. Чого в файлі немає — того НЕМАЄ. Порожня графа чесніша за вигадану адресу;
     жодного «домалювати за схожістю».
  3. Прочитане ЗБЕРІГАЄТЬСЯ в базу знань (`owner.json`) — клієнт дає файл один
     раз, а не перед кожним пакетом.
  4. Нове не затирає старе мовчки: порожнє поле з нового файла лишає те, що вже
     було, а непорожнє — оновлює і це видно в журналі.
"""

import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
PACK_DIR = os.path.join(HERE, "knowledge_packs", "tender_casper")
OWNER_FILE = os.path.join(PACK_DIR, "owner.json")

# Поля картки. Порядок = порядок показу людині в переліку «чого бракує».
FIELDS = ("name", "edrpou", "address", "phone", "email", "iban", "bank",
          "director", "director_post")

HUMAN = {
    "name": "повна назва учасника",
    "edrpou": "код ЄДРПОУ",
    "address": "юридична адреса",
    "phone": "телефон",
    "email": "e-mail",
    "iban": "рахунок IBAN",
    "bank": "банк",
    "director": "підписант (прізвище та ініціали)",
    "director_post": "посада підписанта",
}

# Слова, за якими впізнаємо, що цей файл — картка підприємства.
CARD_WORDS = ("реквізит", "rekvizyt", "картка підприємства", "картка пiдприємства",
              "картка контрагента", "картка компанії", "довідка про підприємство",
              "company card", "картка учасника")

# ⭐⭐⭐ 24.08.2026, зміна 213. КАРТКА — ЦЕ МАЛИЙ ЩІЛЬНИЙ ФАЙЛ, А НЕ БУДЬ-ЩО,
# ДЕ ТРАПИЛОСЬ СЛОВО «ЄДРПОУ».
# 🩸 Куплено власним дефектом того ж вечора: тендерна документація замовника
# теж містить «ЄДРПОУ», «юридична адреса», «МФО» — і код узяв ЇЇ за картку
# учасника. У базу знань лягло сміття: ЄДРПОУ ЗАМОВНИКА (військової частини),
# уривок абзацу замість назви, шматок таблиці замість адреси. Далі це поїхало б
# у шапку КОЖНОЇ довідки — тобто учасник подався б із чужим кодом.
# ⛒ ТРИ РУБЕЖІ, і кожен уміє сказати «ні»:
#   1. РОЗМІР: картка підприємства — це аркуш, а не документація на 200 сторінок.
#   2. ЧУЖА ФОРМА: ознаки тендерної документації забороняють читати файл як картку.
#   3. ПРАВДОПОДІБНІСТЬ ЗНАЧЕННЯ: назва, адреса й підписант мають межі довжини,
#      а сміття з таблиць («|») не є значенням.
MAX_CARD_CHARS = 20000
NOT_A_CARD = ("тендерна документація", "оголошення про проведення",
              "предмет закупівлі", "тендерна пропозиція", "замовник:",
              "додаток до тендерної", "кваліфікаційні критерії",
              "проект договору", "проєкт договору")
_LIMITS = {"name": 120, "address": 200, "director": 80, "bank": 120,
           "director_post": 40}

# 🩸 МЕЖА СЛОВА — НЕ ПРИКРАСА. Без \b форма «ДП» ловилась усередині слова
# «ПІ-ДП-РИЄМСТВА», і назвою учасника ставало «ДПРИЄМСТВА» (чек 24.08).
_ORG = re.compile(
    r"\b((?:ТОВ|ТзОВ|ПП|ПРАТ|ПрАТ|ПАТ|АТ|ТДВ|ФОП|КП|ДП|КНП)\s*[«\"']?"
    r"[^\n«»\"']{2,90}[»\"']?)",
    re.IGNORECASE)
_EDRPOU = re.compile(r"(?:ЄДРПОУ|ЕДРПОУ|код\s+ЄДРПОУ)\D{0,20}(\d{8})", re.IGNORECASE)
_EDRPOU_BARE = re.compile(r"\b(\d{8})\b")
_IBAN = re.compile(r"\b(UA\d{2}[0-9A-Z]{25})\b", re.IGNORECASE)
_EMAIL = re.compile(r"\b([A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,})\b")
_PHONE = re.compile(r"((?:\+?38)?[\s\-(]*0\d{2}[\s\-)]*\d{3}[\s\-]*\d{2}[\s\-]*\d{2})")


def _line_after(text: str, words, stop_at_colon=True) -> str:
    """Значення після назви графи в тому самому рядку або в наступному."""
    lines = [l.strip() for l in (text or "").splitlines()]
    for i, ln in enumerate(lines):
        low = ln.lower()
        for w in words:
            p = low.find(w)
            if p < 0:
                continue
            tail = ln[p + len(w):].strip(" \t:—–-|")
            if stop_at_colon:
                tail = tail.strip()
            if len(tail) >= 3:
                return tail
            for j in (i + 1, i + 2):
                if j < len(lines) and len(lines[j].strip(" \t:—–-|")) >= 3:
                    return lines[j].strip(" \t:—–-|")
    return ""


def looks_like_card(name: str, text: str = "") -> bool:
    """Чи це картка підприємства — за назвою файла АБО за вмістом.

    🩸 Правило дивилось лише на назву: «Дані компанії.docx» повз (зміна 209).
    🩸 Потім дивилось лише на слова: тендерна документація замовника пройшла
    як картка учасника (зміна 213). Тепер — три рубежі, див. коментар вище.
    """
    body = (text or "").lower()
    low = (name or "").lower()
    # ⛒ РУБІЖ 2 працює НАВІТЬ на «правильну» назву: файл, який виглядає
    # тендерною документацією, карткою не стає ніколи.
    if any(w in body for w in NOT_A_CARD):
        return False
    # ⛒ РУБІЖ 1: занадто великий файл — не картка, хай навіть так названий.
    if len(text or "") > MAX_CARD_CHARS:
        return False
    if any(w in low for w in CARD_WORDS):
        return True
    if not body:
        return False
    hits = sum(1 for w in ("єдрпоу", "iban", "юридична адреса", "місцезнаходження",
                           "розрахунковий рахунок", "мфо") if w in body)
    return hits >= 3


def blocks(files_context: str):
    """Прикріплені файли ПООДИНЦІ: [(назва, текст)].

    ⛒ Судити треба ФАЙЛ, а не злиття всього, що людина принесла в чат: саме
    злиття й дало змогу тендерній документації видати себе за картку.
    """
    out, cur_name, cur = [], "", []
    for line in (files_context or "").splitlines():
        if line.startswith("## Файл: "):
            if cur_name or cur:
                out.append((cur_name, "\n".join(cur)))
            cur_name, cur = line[len("## Файл: "):].strip(), []
        else:
            cur.append(line)
    if cur_name or cur:
        out.append((cur_name, "\n".join(cur)))
    return [(n, t) for n, t in out if (n or (t or "").strip())]


def _plausible(field: str, value: str) -> str:
    """Значення, яке не схоже на значення, — це не значення."""
    v = (value or "").strip()
    if not v or "|" in v:
        return ""
    lim = _LIMITS.get(field)
    if lim and len(v) > lim:
        return ""
    return v


def parse(text: str) -> dict:
    """Реквізити з тексту картки. Чого немає — того немає (порожній рядок)."""
    out = {k: "" for k in FIELDS}
    t = text or ""
    if not t.strip():
        return out

    m = _EDRPOU.search(t)
    if m:
        out["edrpou"] = m.group(1)

    m = _ORG.search(t)
    if m:
        out["name"] = re.sub(r"\s+", " ", m.group(1)).strip(" .,;:")
    else:
        cand = _line_after(t, ("повна назва", "найменування", "назва учасника", "назва:"))
        if cand:
            out["name"] = re.sub(r"\s+", " ", cand).strip(" .,;:")

    addr = _line_after(t, ("юридична адреса", "місцезнаходження", "юр. адреса",
                           "адреса реєстрації", "поштова адреса", "адреса"))
    if addr:
        out["address"] = re.sub(r"\s+", " ", addr).strip(" .,;:")

    m = _EMAIL.search(t)
    if m:
        out["email"] = m.group(1)
    m = _PHONE.search(t)
    if m:
        out["phone"] = re.sub(r"\s{2,}", " ", m.group(1)).strip(" -()")
    m = _IBAN.search(t)
    if m:
        out["iban"] = m.group(1).upper()

    bank = _line_after(t, ("найменування банку", "банк:", "у банку", "назва банку", "мфо"))
    if bank and not _IBAN.search(bank):
        out["bank"] = re.sub(r"\s+", " ", bank).strip(" .,;:")

    who = _line_after(t, ("в особі директора", "директор", "керівник", "підписант",
                          "уповноважена особа"))
    if who:
        who = re.sub(r"\s+", " ", who).strip(" .,;:")
        out["director"] = who[:80]
        low = t.lower()
        for post in ("генеральний директор", "директор", "керівник",
                     "уповноважена особа", "president"):
            if post in low:
                out["director_post"] = post.capitalize()
                break
    # ⛒ РУБІЖ 3: сміття з таблиці або абзац замість значення — це не значення.
    for k in FIELDS:
        out[k] = _plausible(k, out.get(k))
    return out


def load() -> dict:
    """Картка з бази знань. Немає файла — порожня картка, а не аварія."""
    out = {k: "" for k in FIELDS}
    try:
        with open(OWNER_FILE, encoding="utf-8") as f:
            d = json.load(f)
        if isinstance(d, dict):
            for k in FIELDS:
                v = d.get(k)
                out[k] = str(v).strip() if v is not None else ""
    except Exception:
        pass
    return out


def save(card: dict) -> bool:
    """Кладе картку в базу знань. Порожнє НЕ затирає непорожнє."""
    cur = load()
    merged, changed = dict(cur), []
    for k in FIELDS:
        v = str((card or {}).get(k) or "").strip()
        if v and v != cur.get(k):
            merged[k] = v
            changed.append(k)
    if not changed:
        return False
    try:
        os.makedirs(PACK_DIR, exist_ok=True)
        with open(OWNER_FILE, "w", encoding="utf-8") as f:
            json.dump(merged, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def gaps(card: dict) -> list:
    """Чого бракує — словами клієнта, без назв наших файлів."""
    return [HUMAN[k] for k in FIELDS if not str((card or {}).get(k) or "").strip()]
