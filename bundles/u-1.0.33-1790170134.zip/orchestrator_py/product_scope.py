# -*- coding: utf-8 -*-
"""product_scope.py — СУДДЯ СКЛАДУ ПОСТАВКИ (зміна 561в, 11.09.2026).

⭐⭐⭐ НАВІЩО ОКРЕМИЙ МОДУЛЬ. Відповідь на два питання — «що взагалі є в
продукті» і «що саме куплено цим клієнтом» — має ОДНОГО писаря, і його питають
двоє: складальник клієнтського пакета і сервер (двері CRM). Доти писар жив
УСЕРЕДИНІ складальника, і тому клієнтський сервер тягнув у себе весь наш
інструмент публікації: складальник → ворота складу релізу → канал оновлень.
Ворота чистоти пакета чесно називали це багом.

⛒ КЛАС: СУДДЯ ЖИВЕ ВСЕРЕДИНІ ІНСТРУМЕНТА, ТОМУ ІНСТРУМЕНТ ЇДЕ ТУДИ, КУДИ
ПОТРІБЕН ЛИШЕ СУДДЯ.

⛔ ЦЕЙ МОДУЛЬ НЕ ЗНАЄ НІЧОГО ПРО ПУБЛІКАЦІЮ. Він не імпортує ні реєстру наших
робіт, ні каналу оновлень, ні складальника — і не сміє почати. Саме в цьому
його користь: він може їхати клієнту, бо в ньому немає нашої кухні.
"""


# ── Білий список ПРОДУКТОВИХ систем ──────────────────────────────────────
# ТІЛЬКИ ці системи їдуть клієнту. Решта (окремі проєкти: agro, garmin,
# logistics; тестові як route_object_search) — НЕ входять у продукт.
# Безпечно за замовчуванням: нова система НЕ поїде, доки її сюди не додати.
PRODUCT_SYSTEMS = {
    "legal_assistant",
    "excel_financial_modeling",
    "recruiting",
    "hr_dashboard_analytics",
    "biznes_analityka_audyt_i_optymizatsiya_protsesiv",
    "instructions_profiles_duties",
    "product_search",
    "prompt_instruction_generator",
    "system_builder",
    "route_object_search",
    "diy_operations_excel",
    "founder_dashboard",
    "marketing_content",
    "marketing_dashboard",
    "seo_geo_strateg",
    "copywriter",
    "konkurentnyy_heartbeat_monitorynh_i_zvitnist",
    "software_development",
    # ⭐⭐⭐ 24.08.2026. ТЕНДЕРАЙТЕРА ЗАБУЛИ ВНЕСТИ В ПРОДУКТ, І ЦЕ КОШТУВАЛО
    # КЛІЄНТУ ПРОГОНУ. Каспер попросив «створи пакет документів для цього
    # тендеру» — а система, яка САМЕ це й робить, у його збірці була відсутня
    # (18 тек у `generated_systems`, `tender_writer` серед них немає; бандл
    # 1.0.21 віз ті самі 18). Запит пішов у Юриста-асистента (у нього ловляться
    # слова «тендер», «закупівля»), той не мав повного тексту документації
    # замовника і чесно зупинився на контролі якості.
    # ⛒ УРОК: ДЕФЕКТ БУВ НЕ В ПРОГОНІ, А В СКЛАДІ ПОСТАВКИ. Тендерний клієнт
    # місяць працював без тендерної системи, і жоден чек цього не бачив, бо
    # чеки судять ЗБІРКУ, а не питання «чи їде клієнту те, що йому продали».
    "tender_writer",
}

# ── ⭐⭐⭐ 07.08.2026, ЕТАП 4. ОДИН АВТОР НАБОРУ СИСТЕМ КЛІЄНТА ──────────────
# Бізнес-модель (узгоджена 07.08) продає СИСТЕМАМИ: платформа окремо, кожна
# система окремо. Отже «що поїде цьому клієнту» — це не властивість продукту, а
# властивість КЛІЄНТА, і жити вона мусить в ОДНОМУ місці. Місце назване в
# рішенні етапу 4: КАРТКА CRM (реєстр один, клієнтів багато). Ліцензійний ключ
# набору НЕ дублює — інакше буде два писарі однієї правди.
#
# ЧОМУ «НЕМАЄ ПОЛЯ» = ВЕСЬ ПРОДУКТ, А НЕ ПОРОЖНЬО (і чому це не суперечить
# воротам оплати, де «немає поля» = зупинка). Там ішлось про ПРАВО ПРАЦЮВАТИ:
# мовчання не сміє відкривати доступ. Тут — про СКЛАД ПОСТАВКИ живому клієнту:
# мовчання не сміє ВІДІБРАТИ те, що людина вже має. У Каспера в картці поля
# немає, і його збірка мусить лишитись такою самою до останнього байта.
# Порожній СПИСОК — це вже сказане слово: «платформа без систем» (Task Desk як
# окрема позиція прайсу). Тому None і [] означають різне НАВМИСНО.
# ── ⭐⭐⭐ 622в (21.09.2026). СИСТЕМИ САМОЇ ПЛАТФОРМИ ────────────────────────
# 🩸 Консультант платформи (`platform_consultant`) — це не ТОВАР, а частина
# продукту: він відповідає на питання про саму платформу і живе з її мануала.
# Але складу поставки про це ніхто не сказав, і в набір клієнта він не входив.
# Наслідок бачив клієнт 21.09.2026: кнопка «Запитати оркестратора» на екрані
# «Інструкція» відповідала «консультанта немає в реєстрі систем цієї збірки».
# ⛒ Набір клієнта = куплені СИСТЕМИ + системи ПЛАТФОРМИ. Другого переліку
# заводити не можна: саме через два переліки магазин приїхав без каталогу.
PLATFORM_SYSTEMS = {
    "platform_consultant",
}


class EntitlementError(Exception):
    """Набір клієнта названий, але не сходиться з продуктом. Мовчки не буває."""


def client_systems(customer: str = "", card=None):
    """Набір систем цього клієнта. `None` = увесь продукт (сьогоднішня поведінка).

    Джерело — поле `systems` картки CRM. Валідність судиться ТУТ, один раз, і
    обидва шляхи до клієнта (повна збірка й канал оновлень) питають саме це."""
    if card is None:
        if not customer:
            return None
        try:
            import crm as _crm
            card = _crm.get_client(_crm.resolve(customer) or customer)
        except Exception:
            card = None
    if not isinstance(card, dict):
        return None
    if "systems" not in card:
        return None                      # мовчання картки нічого не відбирає
    raw = card.get("systems")
    if raw is None:
        return None
    if not isinstance(raw, (list, tuple, set)):
        raise EntitlementError(
            "поле «systems» у картці «%s» має бути списком id систем, а не %s"
            % (customer or "?", type(raw).__name__))
    wanted = {str(x).strip() for x in raw if str(x).strip()}
    unknown = sorted(wanted - set(PRODUCT_SYSTEMS) - set(PLATFORM_SYSTEMS))
    if unknown:
        raise EntitlementError(
            "у картці «%s» названі системи, яких немає в продукті: %s"
            % (customer or "?", ", ".join(unknown)))
    # ⛒ 622в: системи платформи не продаються і не відбираються мовчанням картки.
    return wanted | set(PLATFORM_SYSTEMS)


# ── ⭐⭐⭐ 631 (23.09.2026). МОДУЛІ, ЩО ПРОДАЮТЬСЯ ОКРЕМО ────────────────────
# 🩸 КЛАС: «МОДУЛЬ, ЯКОГО НЕ ПРОДАЛИ, ВСЕ ОДНО ПРАЦЮЄ». Система — це тека, і
# непродану систему просто не везуть. Модуль платформи (тренажер переговорів)
# — частина рушія: його файли їдуть КОЖНОМУ. Тому «не привезти» тут не
# працює — непроданий модуль мусить бути ВИМКНЕНИЙ, і вимкнений для всіх,
# адміністратора клієнта теж: купівля — не право в ролі.
#
# ⛒ ОДИН ПИСАР «ЩО КУПЛЕНО» — картка CRM (поле `modules`), рівно як для
# систем, і з тими самими трьома станами:
#   немає поля / None — модулі не названі: УСІ (так у кожного живого клієнта,
#                        і оновлення в нього нічого не забирає);
#   список            — рівно ці модулі;
#   порожній список   — сказане слово: без окремих модулів.
# ⛒ ЯКІ РОЗДІЛИ Й ПРАВА НАЛЕЖАТЬ МОДУЛЮ, каже не цей перелік, а СВОЇ реєстри
# (`access_sections.SECTIONS`, `taskdesk_roles.ACT_PERMS` — поле `module`).
# Другий перелік розділів тут розійшовся б із першим на першому ж новому.
PRODUCT_MODULES = {
    "trainer": "Тренажер переговорів",
}


def module_name(module_id: str) -> str:
    return PRODUCT_MODULES.get(str(module_id or ""), "")


def client_modules(customer: str = "", card=None):
    """Модулі цього клієнта. `None` = усі (мовчання картки нічого не відбирає).

    Джерело — поле `modules` картки CRM. Судиться ТУТ, один раз; питають обидва
    шляхи до клієнта (повна збірка й канал оновлень) і двері запису картки."""
    if card is None:
        if not customer:
            return None
        try:
            import crm as _crm
            card = _crm.get_client(_crm.resolve(customer) or customer)
        except Exception:
            card = None
    if not isinstance(card, dict):
        return None
    raw = card.get("modules")
    if raw is None:
        return None
    if not isinstance(raw, (list, tuple, set)):
        raise EntitlementError(
            "поле «modules» у картці «%s» має бути списком id модулів, а не %s"
            % (customer or "?", type(raw).__name__))
    wanted = {str(x).strip() for x in raw if str(x).strip()}
    unknown = sorted(wanted - set(PRODUCT_MODULES))
    if unknown:
        raise EntitlementError(
            "у картці «%s» названі модулі, яких немає в продукті: %s"
            % (customer or "?", ", ".join(unknown)))
    return wanted


def delivered_modules():
    """ЩО ДОСТАВЛЕНО В ЦЮ ІНСТАЛЯЦІЮ. `None` = усі модулі.

    ⛒ У нас (еталон) — усі: Андрій бачить увесь продукт. У клієнта —
    похідний знімок прапорців, покладений тим самим писарем на обох
    шляхах доставки. Правила читання знімка живуть у `features`."""
    import features as _ft
    if _ft.is_master():
        return None
    return _ft.delivered_modules()


def module_on(module_id: str) -> bool:
    """ЄДИНА відповідь «чи цей модуль увімкнений тут»."""
    mid = str(module_id or "").strip()
    if mid not in PRODUCT_MODULES:
        return False
    got = delivered_modules()
    return True if got is None else (mid in got)


def closed_modules() -> set:
    return {m for m in PRODUCT_MODULES if not module_on(m)}


def closed_sections() -> set:
    """Розділи платформи, які належать НЕДОСТАВЛЕНИМ модулям."""
    off = closed_modules()
    if not off:
        return set()
    import access_sections as _sec
    return {s["id"] for s in _sec.SECTIONS if s.get("module") in off}


def closed_perms() -> set:
    """Усі дозволи матриці прав (розділи й дії), що належать недоставленим."""
    off = closed_modules()
    if not off:
        return set()
    import taskdesk_roles as _roles
    return {p["id"] for p in _roles.ALL_PERMS if p.get("module") in off}


def section_delivered(section_id: str) -> bool:
    return str(section_id or "") not in closed_sections()


def not_delivered(section_id: str) -> dict:
    """ВІДМОВА, ЯКА КАЖЕ, ДЕ ВЗЯТИ, а не «помилка» (правило власника про
    відмови в продукті: людину цікавить результат, а не чесність системи)."""
    import access_sections as _sec
    mod = next((s.get("module") for s in _sec.SECTIONS
                if s["id"] == str(section_id or "")), "")
    name = module_name(mod) or _sec.name_of(section_id) or "Цей розділ"
    return {"error": "module_not_delivered", "module": mod,
            "message": ("«%s» не входить у поставку вашої компанії. Його можна "
                        "додати: замовте модуль у розділі «Магазин» або "
                        "напишіть нам у підтримку." % name)}
