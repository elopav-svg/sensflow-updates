# -*- coding: utf-8 -*-
"""features.py — ВИМИКАЧ НЕЗАВЕРШЕНОЇ РОБОТИ (етап 2 воріт складу, 05.08.2026).

НАВІЩО. Етап 1 не пускає до клієнта НЕНАЗВАНІ файли. Але дві дірки лишались:
  • ланцюги полізуть усередину файлів, які їдуть у будь-якому разі — діф не
    ріже файл навпіл;
  • повна збірка новому клієнту порівнювати не має з чим.
Отже незавершена робота мусить бути ВИМКНЕНА, а не просто «не привезена».

ОДИН ПИСАР. Питання «чи ця робота ввімкнена» має рівно одну відповідь —
`features.enabled(work_id)`. Хто читає прапорець повз цю функцію, той стає
другим писарем, і рано чи пізно вони розійдуться.

ДЖЕРЕЛА, І ЧОМУ ЇХ ДВА, А НЕ ОДНЕ:
  • У КЛІЄНТА джерело РІВНО ОДНЕ — `features.json` поруч із рушієм. Це похідне
    від реєстру робіт, зроблене при складанні, з відбитком джерела. Немає
    файла — вимкнено все (fail-closed: мовчазна відсутність не вмикає).
  • У НАС (еталон) `features.json` не читається взагалі: там джерело —
    `SENSFLOW_FEATURES` у `.env.local`. Еталон упізнається за наявністю
    `release_works.json`, який за побудовою клієнту НЕ ЇДЕ.
  • ЗА ЗАМОВЧУВАННЯМ ВИМКНЕНО СКРІЗЬ, включно з еталоном: щоб ми бачили рівно
    те, що бачить клієнт, і не дізнавались про різницю від нього.

ТРИ СТАНИ РОБОТИ (22.08.2026), а не два:
  • немає вимикача       — робота живе завжди, її не вимикають;
  • вимикач + "done"     — завершена, їде увімкненою всім і назавжди;
  • вимикач + "pilot"    — ВІДКРИТО НА ВИПРОБУВАННЯ: ще не завершена, але
                           свідомо ввімкнена, щоб пілот міг подивитись.
Третій стан з'явився, бо двома його роблять лише брехнею — позначкою "done"
на недоробленому. Відповідь на «чи їде увімкненою» дає один `ships_on()`.
"""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FEATURES_JSON = HERE / "features.json"
WORKS_JSON = HERE / "release_works.json"

_ENV_KEY = "SENSFLOW_FEATURES"


def is_master() -> bool:
    """Це еталон розробки (у клієнта реєстру робіт немає — він не їде)."""
    return WORKS_JSON.exists()


def _from_env() -> set:
    try:
        import config
        raw = str(config.ENV.get(_ENV_KEY) or "")
    except Exception:
        raw = ""
    return {x.strip() for x in raw.replace(";", ",").split(",") if x.strip()}


def _from_file() -> set:
    try:
        data = json.loads(FEATURES_JSON.read_text(encoding="utf-8"))
    except Exception:
        return set()          # немає/зламаний файл -> вимкнено все
    got = data.get("enabled")
    if not isinstance(got, list):
        return set()
    return {str(x).strip() for x in got if str(x).strip()}


# ⭐⭐⭐ 24.08.2026. ПИТАННЯ «ЧИ ПОЇДЕ ВОНА ХОЧ КОМУСЬ» — ЦЕ НЕ ТЕ САМЕ, ЩО
# «ЧИ ПОЇДЕ ВОНА ЦЬОМУ КЛІЄНТУ». Ворота складу питають перше (їм важливо, чи
# взагалі є кому), знімок прапорців — друге. Раніше обидва питання мали одну
# відповідь, і саме тому випробування текло всім. Сентинел названий вголос,
# щоб жоден новий виклик не міг «випадково» спитати не те.
ANYONE = "*будь-кому*"


def who(name) -> str:
    """ОДНЕ НАПИСАННЯ ІМЕНІ КЛІЄНТА для порівняння.

    Імʼя приходить із CRM (ліцензія) і з рук людини в батнику. Подвійний
    пробіл або інший регістр не сміють вирішувати, чи клієнт дістане модуль."""
    return " ".join(str(name or "").split()).casefold()


def pilot_names(work) -> tuple:
    """КОМУ ця робота відкрита на випробування. Порожньо — нікому.

    ⛒ `"pilot": true` — це стара форма «відкрито всім», і вона тут ПАДАЄ, а не
    тлумачиться. Мовчазне тлумачення старого запису як «всім» — рівно та
    дірка, заради якої писався цей код."""
    raw = (work or {}).get("pilot")
    if raw is True:
        raise ValueError(
            "«pilot: true» більше не приймається: випробування називає ІМʼЯ "
            "клієнта — \"pilot\": [\"<імʼя з ліцензії>\"]")
    if not raw:
        return ()
    if isinstance(raw, str):
        raw = [raw]
    return tuple(str(x) for x in raw if str(x).strip())


def ships_on(work, customer) -> bool:
    """⭐⭐⭐ 22.08.2026. ОДИН СУДДЯ «ЧИ ЦЯ РОБОТА ЇДЕ КЛІЄНТУ УВІМКНЕНОЮ».

    ДВА СТАНИ БУЛО ЗАМАЛО. Досі відповідь була «має вимикач І завершена». Але
    життя попросило третього стану: робота ЩЕ НЕ завершена, а показати її
    названому пілотові треба вже сьогодні. Двома станами це роблять лише
    брехнею в реєстрі — позначкою "done" на недоробленому. Тому з'явився
    "pilot": ВІДКРИТО НА ВИПРОБУВАННЯ. Реєстр каже правду, а клієнт бачить
    роботу.

    ⛒ ЗРІЛІСТЬ І ВІДКРИТІСТЬ — РІЗНІ РЕЧІ. "done" каже «робота завершена й
    така для всіх назавжди», "pilot" — «ще ні, але свідомо відкрито». Перше
    ніколи не ставиться заради другого.

    ⭐⭐⭐ 24.08.2026. ІМʼЯ КЛІЄНТА ПРИНЕСЕНО СЮДИ — саме так, як обіцяв
    попередній коментар. Тепер «відкрито на випробування» — це не стан
    продукту, а стан ПАРИ «робота + клієнт»: у реєстрі стоїть перелік імен,
    кому вона відкрита. Немає імені в переліку — блок вимкнений, і жодна
    збірка не може ввімкнути його «випадково».

    ⛒ `customer` — БЕЗ ЗАМОВЧУВАННЯ НАВМИСНО. Новий виклик фізично не
    напишеться, доки автор не відповість на питання «кому саме». Замовчування
    тут означало б повернути ту саму дірку тихцем.

    `customer = ANYONE` відповідає на інше питання — «чи поїде вона хоч
    комусь». Це потрібно воротам складу («увімкнена робота без свого коду»),
    і там обережність працює в правильний бік: краще перевірити зайве.

    Раніше цю саму відповідь писали ДВОЄ: `snapshot()` тут і `enabled_has_code`
    у воротах складу. Два писарі одного правила рано чи пізно розходяться —
    тепер писар один, і обидва питають його.
    """
    w = work or {}
    if not w.get("flag"):
        return False                       # немає вимикача — нічого вмикати
    if w.get("done"):
        return True                        # завершена — їде всім і назавжди
    names = pilot_names(w)
    if not names:
        return False                       # ще не готова і нікому не відкрита
    if customer is ANYONE or customer == ANYONE:
        return True                        # «хоч комусь» — так
    return who(customer) in {who(n) for n in names}


def _done_flagged_ids() -> set:
    """Завершені роботи, що мають вимикач. Тільки для ЕТАЛОНА: у клієнта цю
    відповідь уже втілив знімок, зроблений `ships_on()` при складанні."""
    try:
        data = json.loads(WORKS_JSON.read_text(encoding="utf-8"))
    except Exception:
        return set()
    return {str(w.get("id")).strip() for w in (data.get("works") or [])
            if isinstance(w, dict) and w.get("flag") and w.get("done")
            and w.get("id")}


def enabled(work_id) -> bool:
    """ЄДИНА відповідь на «чи ця робота ввімкнена». За замовчуванням — ні.

    ⛒⛒⛒ 561г. ЕТАЛОН МУСИТЬ БАЧИТИ ТЕ САМЕ, ЩО КЛІЄНТ — це обіцянка з шапки
    цього файла. Клієнт бачить ЗАВЕРШЕНУ роботу з вимикачем увімкненою
    (`ships_on`: done → всім і назавжди), а еталон бачив її вимкненою, доки
    хтось не впише її руками в `SENSFLOW_FEATURES`. Тобто виходило РІВНО
    НАВПАКИ до обіцянки, і помітити це було ніяк: сторож, який на цьому
    спирається, роками мовчки віддавав порожнє (див. 561б).
    🩸 Ручний перелік у `.env.local` лишається — він вмикає НЕЗАВЕРШЕНЕ, і
    тільки для нас."""
    wid = str(work_id or "").strip()
    if not wid:
        return False
    if not is_master():
        return wid in _from_file()
    return wid in _from_env() or wid in _done_flagged_ids()


def active() -> set:
    """Що зараз увімкнено (для звіту людині, не для рішень у коді)."""
    return set(_from_env() if is_master() else _from_file())


def asks_switch(work: dict, root=None) -> bool:
    """ЧИ РОБОТА СПРАВДІ ПИТАЄ СВІЙ ВИМИКАЧ.

    Вимикач, якого ніхто не питає, — декорація: файл у пакеті лежить, прапорець
    у нулі, а функція працює. Тому дивимось у ДЕРЕВО КОДУ файлів самої роботи:
    має бути виклик features.enabled("<її id>"). Рядок у тексті не рахуємо —
    він буває і в коментарі.
    """
    import ast
    base = Path(root or HERE.parent)
    wid = str(work.get("id") or "")
    files = []
    for rel in (work.get("paths") or []):
        p = base / rel
        if p.is_file() and p.suffix == ".py":
            files.append(p)
        elif p.is_dir():
            files.extend(p.rglob("*.py"))
    for f in files:
        try:
            tree = ast.parse(f.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        # ⭐ 05.08.2026. Ворота мусять розуміти й КОНСТАНТУ модуля, а не лише голий
        # рядок: `WORK_ID = "chains"` + `features.enabled(WORK_ID)` — це один писар
        # id, і вимагати від нього дублювати рядок означало б плодити другого.
        consts = {}
        for n in tree.body:
            if isinstance(n, ast.Assign) and isinstance(n.value, ast.Constant):
                for t in n.targets:
                    if isinstance(t, ast.Name) and isinstance(n.value.value, str):
                        consts[t.id] = n.value.value
        for n in ast.walk(tree):
            if not isinstance(n, ast.Call):
                continue
            name = getattr(n.func, "attr", None) or getattr(n.func, "id", None)
            if name != "enabled" or not n.args:
                continue
            a0 = n.args[0]
            if isinstance(a0, ast.Constant) and str(a0.value) == wid:
                return True
            if isinstance(a0, ast.Name) and consts.get(a0.id) == wid:
                return True
    return False


def snapshot(works: dict, customer, source_sha: str = "", built: str = "", *,
             modules) -> str:
    """ЩО КЛАСТИ КЛІЄНТОВІ. Похідне від реєстру робіт, з відбитком джерела:
    похідне значення без відбитка — початок другої правди.

    Увімкненою їде лише робота, яка МАЄ вимикач (`flag`) і або ПОЗНАЧЕНА
    завершеною (`done`), або ВІДКРИТА НА ВИПРОБУВАННЯ САМЕ ЦЬОМУ КЛІЄНТУ.
    Зрілість — властивість продукту, вона живе в реєстрі; склад релізу
    (--works) відповідає на інше питання і сюди не втручається.

    ⛒ 24.08.2026. `customer` обовʼязковий, а ANYONE тут ЗАБОРОНЕНИЙ: знімок —
    це те, що ляже на диск конкретній людині. «Комусь» на диску не буває.
    Порожнє імʼя — не помилка, а чесне «клієнта не назвали»: тоді їдуть лише
    завершені роботи (fail-closed).

    ⭐⭐⭐ 631. `modules` — ЩО З МОДУЛІВ КУПИВ ЦЕЙ КЛІЄНТ (`product_scope.
    client_modules`, писар — картка CRM). БЕЗ ЗАМОВЧУВАННЯ НАВМИСНО: новий
    виклик не напишеться, доки автор не відповість «які модулі». `None` —
    не названі (усі), множина — рівно ці.
    """
    if customer is ANYONE or customer == ANYONE:
        raise ValueError(
            "знімок прапорців робиться ДЛЯ КОНКРЕТНОГО КЛІЄНТА, "
            "а не «для будь-кого»")
    on = sorted(wid for wid, w in (works or {}).items() if ships_on(w, customer))
    # ⭐⭐⭐ 561. ЯКІ РОБОТИ ВЗАГАЛІ МАЮТЬ ВИМИКАЧ — теж у знімку.
    # Доти цю відповідь брали з НАШОГО реєстру робіт, і клієнтський рушій
    # через це тягнув наш службовий модуль `release_scope` у замикання
    # імпортів. Клієнт не читає наше джерело — він читає те, що ми йому
    # поклали.
    flagged = sorted(wid for wid, w in (works or {}).items() if w.get("flag"))
    # ⭐ Випробування називає себе вголос. Інакше через місяць ніхто (і я
    # передусім) не відрізнить «увімкнено, бо готове» від «увімкнено, бо
    # відкрито пілотові» — а це різні обіцянки перед клієнтом.
    pilot = sorted(wid for wid, w in (works or {}).items()
                   if ships_on(w, customer) and not w.get("done"))
    return json.dumps({
        "_": "ПОХІДНЕ від release_works.json. Рукою не правити: перезапишеться "
             "при наступному складанні.",
        "source_sha256": source_sha,
        "built": built,
        "enabled": on,
        "pilot": pilot,
        "flagged": flagged,
        "_flagged": "Роботи, які МАЮТЬ вимикач (не те саме, що ввімкнені).",
        "_pilot": "Роботи, ВІДКРИТІ НА ВИПРОБУВАННЯ: ще не завершені, увімкнені "
                  "свідомо, щоб пілотний клієнт міг подивитись.",
        "modules": (None if modules is None
                    else sorted({str(x).strip() for x in modules if str(x).strip()})),
        "_modules": "Модулі, які купив клієнт (писар — картка CRM). null — не "
                    "названі, отже всі; список — рівно ці.",
    }, ensure_ascii=False, indent=2)


def _flagged_from_file() -> set:
    try:
        data = json.loads(FEATURES_JSON.read_text(encoding="utf-8"))
    except Exception:
        return set()          # немає/зламаний файл -> вимикачів не знаємо
    got = data.get("flagged")
    if not isinstance(got, list):
        return set()
    return {str(x).strip() for x in got if str(x).strip()}


def flagged_work_ids() -> set:
    """Id робіт, які мають вимикач. Потрібно тим, хто вирішує ВИДИМІСТЬ
    (каталог систем), а не лише запуск.

    ⛒⛒⛒ 561. ДЖЕРЕЛО ТЕ САМЕ, ЩО Й У `enabled()`: у нас — реєстр робіт,
    у КЛІЄНТА — знімок `features.json`. Доти ця функція питала реєстр ЗАВЖДИ,
    і клієнтський рушій через неї тягнув наш службовий модуль `release_scope`
    у замикання імпортів. Ворота складу назвали це багом і мали рацію:
    клієнт читає те, що ми йому поклали, а не нашу кухню."""
    if not is_master():
        return _flagged_from_file()
    # ⛒⛒⛒ 561б. ТУТ СТОЯВ ВИКЛИК `release_scope.load_works()`, а той повертає
    # СЛОВНИК {id: робота}. Цикл брав КЛЮЧІ — рядки, — падав на `w.get(...)`,
    # і `except` віддавав ПОРОЖНЮ множину. Ворота видимості каталогу через це
    # не спрацьовували жодного разу. Читаємо реєстр прямо і правильно — і наш
    # службовий модуль більше не тягнеться в замикання імпортів клієнта.
    try:
        data = json.loads(WORKS_JSON.read_text(encoding="utf-8"))
    except Exception:
        return set()
    return {str(w.get("id")).strip() for w in (data.get("works") or [])
            if isinstance(w, dict) and w.get("flag") and w.get("id")}


def delivered_modules():
    """⭐⭐⭐ 631. ЯКІ МОДУЛІ ДОСТАВЛЕНО — з того самого знімка `features.json`.

    Закони читання — ТІ САМІ, що й для робіт у цьому файлі, плюс один:
      • знімка немає або він зламаний -> `set()`: жодного модуля (fail-closed,
        як і «немає файла — вимкнено все»);
      • ключа `modules` немає (знімок, зроблений до 631) або він null ->
        `None`: усі модулі. Оновлення не сміє мовчки відібрати в живого
        клієнта те, що в нього вже працює.
    Рішення «чи увімкнено» ухвалює `product_scope.module_on`, а не цей читач."""
    try:
        data = json.loads(FEATURES_JSON.read_text(encoding="utf-8"))
    except Exception:
        return set()
    if not isinstance(data, dict):
        return set()
    if "modules" not in data or data.get("modules") is None:
        return None
    got = data.get("modules")
    if not isinstance(got, list):
        return set()
    return {str(x).strip() for x in got if str(x).strip()}
