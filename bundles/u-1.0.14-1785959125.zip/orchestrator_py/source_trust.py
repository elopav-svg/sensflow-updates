# -*- coding: utf-8 -*-
"""source_trust.py — РЕЄСТР ФАКТІВ, У ЯКИХ Є ПІДТВЕРДЖЕНЕ ДЖЕРЕЛО.

⭐⭐⭐ НАВІЩО (04.08.2026, живий випадок клієнта).
    Вартовий на виході питав: «чи запечатаний ЦЕЙ ТЕКСТ». Печатка ставилась на
    дослівний рядок, тому будь-який ПОХІДНИЙ текст її не мав. Клієнт попросив
    правовий аналіз тендера — юрист написав номер у власному реченні, дослівного
    збігу не було, і вартовий заблокував нашу ж чесну роботу. Ворота ловили
    не брехню, а форму запису.

    ПРАВИЛЬНЕ ПИТАННЯ — не про текст, а про ФАКТ:
        «чи має цей номер закупівлі підтверджене походження?»
    Номер, картку якого платформа РЕАЛЬНО завантажила з Прозорро, — має.
    Номер, який модель написала з голови, — не має і ніколи тут не з'явиться,
    бо в джерелі його немає.

ХТО СЮДИ ПИШЕ. Лише той, хто справді сходив у джерело і отримав картку:
    `tender_legal.load_card` — єдина точка, де номер стає карткою.
    Модель сюди не пише НІКОЛИ — інакше реєстр підтверджував би сам себе.

FAIL-CLOSED. Немає сховища, побите сховище, незнайомий формат, будь-який виняток —
    трактується як «не підтверджено». Мовчазний пропуск гірший за незручність.

ЧЕСНА МЕЖА. Реєстр відповідає рівно на одне питання: «цей номер існує в джерелі,
    і ми його звідти брали». Він НЕ каже, що сума, дата чи переможець у тексті
    правильні. Проти вигадки навколо підтвердженого номера працює інше —
    `tender_fact_check` і чесний стоп у самій системі.
"""
import json
import threading
import time
from pathlib import Path

import tender_ref

try:
    import config
    _DIR = Path(config.ENGINE_DIR)
except Exception:                                    # автономний запуск тестів
    _DIR = Path(__file__).resolve().parent

_STORE = _DIR / "source_trust.json"
_LOCK = threading.RLock()

TTL_SECONDS = 48 * 3600      # стільки ж, скільки жила печатка вартового
MAX_ITEMS = 500

KIND_TENDER = "tender"


def _load() -> dict:
    with _LOCK:
        try:
            data = json.loads(_STORE.read_text(encoding="utf-8"))
        except Exception:
            return {}
        if not isinstance(data, dict):
            return {}
        now = time.time()
        out = {}
        for key, it in data.items():
            try:
                if not isinstance(it, dict):
                    continue
                if now - float(it.get("at", 0)) > TTL_SECONDS:
                    continue
                out[str(key)] = it
            except Exception:
                continue
        return out


def _save(items: dict):
    with _LOCK:
        try:
            if len(items) > MAX_ITEMS:
                pairs = sorted(items.items(), key=lambda kv: float(kv[1].get("at", 0)))
                items = dict(pairs[-MAX_ITEMS:])
            _STORE.parent.mkdir(parents=True, exist_ok=True)
            _STORE.write_text(json.dumps(items, ensure_ascii=False), encoding="utf-8")
        except Exception:
            pass          # не змогли зберегти -> наступна перевірка просто не пройде


def _key(kind: str, ref: str) -> str:
    return "%s:%s" % (kind, ref)


def confirm(ref, origin: str = "prozorro", detail=None, kind: str = KIND_TENDER) -> str:
    """Записує: цей факт МИ БРАЛИ З ДЖЕРЕЛА. Повертає нормалізований номер або "".

    Кличеться ЛИШЕ після того, як джерело справді віддало картку.
    """
    norm = tender_ref.normalize(ref) if kind == KIND_TENDER else str(ref or "").strip()
    if not norm:
        return ""
    items = _load()
    items[_key(kind, norm)] = {
        "at": time.time(),
        "origin": str(origin or "")[:64],
        "detail": str(detail or "")[:200],
    }
    _save(items)
    return norm


def is_confirmed(ref, kind: str = KIND_TENDER) -> bool:
    """Чи має цей факт підтверджене походження. Будь-яка невизначеність -> False."""
    try:
        norm = tender_ref.normalize(ref) if kind == KIND_TENDER else str(ref or "").strip()
        if not norm:
            return False
        return _key(kind, norm) in _load()
    except Exception:
        return False


def origin_of(ref, kind: str = KIND_TENDER) -> dict:
    """Відбиток походження: звідки і коли. Порожньо -> {}."""
    try:
        norm = tender_ref.normalize(ref) if kind == KIND_TENDER else str(ref or "").strip()
        return dict(_load().get(_key(kind, norm)) or {})
    except Exception:
        return {}


def unconfirmed(text) -> list:
    """Номери в тексті, під якими НЕМАЄ підтвердженого джерела.

    Порожній список означає: усе тендерне в тексті має походження.
    """
    return [n for n in tender_ref.find_all(text) if not is_confirmed(n)]


def forget_all():
    """Тільки для тестів."""
    _save({})
