# -*- coding: utf-8 -*-
"""
tender_pack.py — ВОРОТА ТЕНДЕРНОГО ПАКЕТА (05.08.2026).

ЩО ЦЕ І ЧОМУ ВОНО НЕ В ПРОМПТІ.
Пакет документів учасника — це папір, за яким людина заходить на торги на
сотні тисяч гривень. Різниця між нашим продуктом і «розумною моделлю, яка
гарно пише довідки» не в якості тексту, а в ДОКАЗОВОСТІ: кожен документ у
пакеті мусить мати підставу в оголошенні замовника, а жоден пункт переліку
замовника не має права зникнути. Прохання до моделі «нічого не вигадуй і
нічого не пропусти» — це прохання. Тут — ворота, які дивляться на ГОТОВИЙ
АРТЕФАКТ і вміють сказати «ні».

ТРОЄ ВОРІТ, І ВСІ ТРОЄ FAIL-CLOSED:
  1. БЕЗ ДОКУМЕНТІВ ЗАМОВНИКА НЕ ПРАЦЮЄМО. Немає оголошення й додатків,
     узятих платформою з першоджерела, — пакета не буде. Саме тут 05.08.2026
     копірайтерська система зробила «шаблони з голови», і клієнт отримав
     папір, який не спирався ні на що.
  2. ЖОДЕН ПУНКТ ПЕРЕЛІКУ НЕ ЗНИКАЄ. Кожен документ, який замовник назвав
     обовʼязковим, мусить бути або складений у пакеті, або явно винесений у
     «додає учасник» — з причиною. Мовчазний пропуск = провал на подачі.
  3. ЖОДНОГО ПУНКТУ БЕЗ ПІДСТАВИ. У реєстрі пакета кожен рядок має колонку
     «підстава» з посиланням на пункт оголошення. Порожня підстава означає,
     що документ узявся з голови моделі, — такий рядок ворота називають.

ЩО ЦЕЙ МОДУЛЬ НЕ РОБИТЬ. Не пише документів і не тлумачить вимог — це робота
агентів системи. Не ходить у мережу: документи бере той, хто вже вміє
(`source_intake` -> `tender_docs`). Не вирішує за людину, чи подаватись.
"""

import json
import os
import re

SYSTEM_ID = "tender_writer"          # система, чий артефакт судять ці ворота
WORK_ID = "tender_writer"            # та сама робота в реєстрі релізу — один писар id

# ⭐⭐⭐ 05.08.2026. КЛАС СИСТЕМ, ЧИЙ АРТЕФАКТ ІСНУЄ З ПОРОЖНІМИ ГРАФАМИ.
# Тендерний пакет — це бланки: ціни, номери договорів, банк і підписант знає лише
# учасник, і платформа їх мати не може НІКОЛИ. Тому «бракує даних» тут не привід
# зупиняти роботу й питати: питання стає РЯДКОМ У РЕЗУЛЬТАТІ («заповнити перед
# подачею»), а пакет усе одно виходить. Інакше людина платить за план і читання
# документів двічі: раз на питання, раз на відповідь.
BLANKS_OK = {"tender_writer"}


def blanks_ok(system_id) -> bool:
    """Чи цій системі порожні графи не заважають віддати результат."""
    return str(system_id or "") in BLANKS_OK
READER_AGENT = "AgentTenderRequirements"  # хто дістав перелік із оголошення
READER_ALT = "ПЕРЕЛІК ОБОВ"                # запасна мітка, якщо слід підписаний інакше

HERE = os.path.dirname(os.path.abspath(__file__))
PACK_DIR = os.path.join(HERE, "knowledge_packs", "tender_casper")
OWNER_FILE = os.path.join(PACK_DIR, "owner.json")
MATERIALS_DIR = os.path.join(PACK_DIR, "Матеріали про товар")

# Заголовок, яким `source_intake` позначає взяті платформою документи закупівлі.
SOURCE_HEADER = "## ДЖЕРЕЛО, ВЗЯТЕ ПЛАТФОРМОЮ ЗА ВКАЗІВКОЮ ЛЮДИНИ"
# Слова, якими той самий модуль позначає ЧЕСНУ НЕВДАЧУ. Наявність заголовка ще
# не означає, що документи є: блок може казати «взяти НЕ ВДАЛОСЯ».
_FAIL_MARKS = ("НЕ ВДАЛОСЯ", "не виходить", "документів не існує")

# Слова, за якими впізнаємо файл реквізитів у теці матеріалів клієнта.
_REQ_WORDS = ("реквізит", "rekvizyt", "картка підприємства", "картка пiдприємства",
              "картка_підприємства", "company card")


def enabled() -> bool:
    """Незавершена робота їде клієнту ВИМКНЕНОЮ (етап 2 воріт складу релізу).

    Питаємо вимикач ТУТ, у точці входу самої роботи, а не десь збоку: вимикач,
    якого ніхто не питає, — декорація, і ворота складу релізу її ловлять.
    Видимість системи в каталозі знімає `registry.load_systems()` тим самим
    прапорцем — щоб мозок не обирав те, чого в клієнта немає."""
    try:
        import features
        return features.enabled(WORK_ID)
    except Exception:
        return True


# ─────────────────────────── ВОРОТА 1: ДОКУМЕНТИ ЗАМОВНИКА ───────────────────
def customer_docs_present(files_context: str) -> dict:
    """Чи справді в матеріалах лежать документи закупівлі з першоджерела.

    -> {"ok": bool, "reason": str}. Fail-closed: сумнів = ні.
    """
    text = files_context or ""
    if SOURCE_HEADER not in text:
        return {"ok": False, "reason":
                "документів закупівлі немає в матеріалах: платформа їх не брала "
                "(у задачі не названо номер закупівлі або посилання на неї)"}
    block = text[text.index(SOURCE_HEADER):]
    for mark in _FAIL_MARKS:
        if mark in block[:1200]:
            return {"ok": False, "reason":
                    "платформа йшла по документи закупівлі, але не отримала їх — "
                    "працювати «за пам'яттю» тут заборонено"}
    return {"ok": True, "reason": ""}


# ─────────────────────────── РЕКВІЗИТИ УЧАСНИКА ──────────────────────────────
def requisites() -> dict:
    """Реквізити учасника з БАЗИ ЗНАНЬ КЛІЄНТА, а не з голови моделі.

    Джерело — тека, яку клієнт наповнює сам:
        knowledge_packs\\tender_casper\\  (owner.json — назва і ЄДРПОУ)
        knowledge_packs\\tender_casper\\Матеріали про товар\\  (файл реквізитів)

    -> {"name", "edrpou", "file", "gaps": [...]}. Чого немає — те названо, а не
    домальовано: порожня графа в довідці чесніша за вигадану адресу.
    """
    out = {"name": "", "edrpou": "", "file": "", "gaps": []}
    try:
        with open(OWNER_FILE, encoding="utf-8") as f:
            d = json.load(f)
        out["name"] = (d.get("name") or "").strip()
        out["edrpou"] = str(d.get("edrpou") or "").strip()
    except Exception:
        pass
    if not out["name"]:
        out["gaps"].append("назва учасника (owner.json)")
    if not out["edrpou"]:
        out["gaps"].append("код ЄДРПОУ (owner.json)")
    try:
        for nm in sorted(os.listdir(MATERIALS_DIR)):
            low = nm.lower()
            if any(w in low for w in _REQ_WORDS):
                out["file"] = os.path.join(MATERIALS_DIR, nm)
                break
    except Exception:
        pass
    if not out["file"]:
        out["gaps"].append(
            "файл реквізитів (адреса, банк, телефон, підписант) у теці "
            "«Матеріали про товар» — покладіть його туди, і пакет заповниться повністю")
    return out


# ─────────────────────────── ВОРОТА 2 і 3: ЧИТАЄМО АРТЕФАКТ ──────────────────
_ROW = re.compile(r"^\s*\|(?P<cells>.+)\|\s*$")


def _rows(markdown: str):
    """Рядки таблиць markdown -> списки клітинок. Роздільники (|---|) відкидаємо."""
    for line in (markdown or "").splitlines():
        m = _ROW.match(line)
        if not m:
            continue
        cells = [c.strip() for c in m.group("cells").split("|")]
        if not cells or all(set(c) <= set("-: ") for c in cells):
            continue
        yield cells


def registry_rows(markdown: str) -> list:
    """Рядки РЕЄСТРУ ПАКЕТА: [{"doc","source","who"}].

    Реєстр упізнаємо за шапкою, у якій є слово «підстава». Формат таблиці
    задано промптом системи; ворота перевіряють саме те, що вийшло.
    """
    head, out = None, []
    for cells in _rows(markdown):
        low = [c.lower() for c in cells]
        if head is None:
            if any("підстав" in c for c in low) and any("документ" in c for c in low):
                head = low
            continue
        rec = {"doc": cells[0] if cells else "", "source": "", "who": ""}
        for i, c in enumerate(cells):
            if i >= len(head):
                break
            if "підстав" in head[i]:
                rec["source"] = c
            elif "хто" in head[i] or "звідки" in head[i]:
                rec["who"] = c
        out.append(rec)
    return out


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", (s or "").lower().replace("ʼ", "'")).strip(" .;:")


def _match_base(text: str) -> str:
    """Текст для ЗВІРКИ: без дужкових вставок і посилань на пункт, без обрізання.
    Ключ пункту і рядок реєстру мусять нормалізуватись ОДНАКОВО — інакше ворота
    ловлять оформлення, а не пропуск (05.08.2026: довгі вимоги з Додатка №2)."""
    t = _norm(text)
    t = re.sub(r"\((?:[^()]*)\)", " ", t)
    t = re.sub(r"\bп\.?\s*\d+[\d.,\s]*", " ", t)
    return re.sub(r"\s+", " ", t).strip(" .;:,")


def _key(item: str) -> str:
    """Назва документа без оформлення: без дужкових посилань на пункт і без
    хвостів «— складено». Саме за нею звіряємо, чи дожив пункт до пакета."""
    t = _match_base(item)
    t = re.sub(r"[—–-]\s*(складено|додає|на бланку).*$", " ", t)
    return re.sub(r"\s+", " ", t).strip(" .;:,")[:40]


def check_pack(markdown: str, checklist) -> dict:
    """ВОРОТА 2 і 3 разом.

    checklist — перелік обовʼязкових документів, який агент витяг з оголошення
    (список рядків). Порожній перелік = ворота не мають з чим звірятись, і це
    теж стоп: пакет без переліку замовника — це знову «з голови».

    -> {"ok", "missing": [...], "no_source": [...], "rows": int, "reason": str}
    """
    items = [str(x) for x in (checklist or []) if str(x).strip()]
    rows = registry_rows(markdown or "")
    res = {"ok": False, "missing": [], "no_source": [], "rows": len(rows), "reason": ""}
    if not items:
        res["reason"] = ("повноту пакета НЕ ПЕРЕВІРЕНО: перелік обовʼязкових документів "
                         "із оголошення не витягнуто, тому звірити пакет із вимогами "
                         "замовника було нічим")
        return res
    if not rows:
        res["reason"] = ("у пакеті немає реєстру з колонкою «підстава» — "
                         "довести походження документів нічим")
        return res
    body = _match_base(markdown)
    for it in items:
        # ⭐ Пункт переліку приходить від агента-читача разом із посиланням на
        # оголошення («…договорів (п.7)»). Ключем для звірки має бути НАЗВА
        # документа, а не її оформлення: інакше ворота ловлять кому, а не пропуск.
        key = _key(it)
        if len(key) < 8:
            continue
        if key not in body and not any(key in _match_base(r["doc"]) for r in rows):
            res["missing"].append(it)
    for r in rows:
        if not _norm(r["source"]):
            res["no_source"].append(r["doc"] or "(рядок без назви)")
    res["ok"] = not res["missing"] and not res["no_source"]
    if not res["ok"]:
        bits = []
        if res["missing"]:
            bits.append("пропущено пунктів переліку: %d" % len(res["missing"]))
        if res["no_source"]:
            bits.append("рядків без підстави в оголошенні: %d" % len(res["no_source"]))
        res["reason"] = "; ".join(bits)
    return res


def stop_text(reason: str) -> str:
    """Чесний стоп для людини. Пакет НЕ віддається — і сказано, чому саме."""
    return ("⛔ **Пакет не сформовано.** %s.\n\n"
            "Це не збій, а запобіжник: пакет документів для подачі мусить спиратися на "
            "оголошення замовника, а не на пам'ять моделі. Що робити: вкажіть номер "
            "закупівлі (UA-…) або посилання на неї — платформа візьме оголошення й "
            "додатки з Прозорро сама." % (reason or "не виконано умову доказовості"))


def checklist_from_trace(accumulated: str) -> list:
    """ПЕРЕЛІК ЗАМОВНИКА — зі сліду агента-читача, а не з голови воріт.

    Так ворота лишаються воротами: вимоги дістає агент, який ЧИТАВ оголошення,
    а ворота лише звіряють, чи всі вони дожили до готового пакета. Якщо агент
    нічого не витяг — звіряти нема з чим, і `check_pack` це чесно скаже.
    """
    text = accumulated or ""
    mark = "### %s" % READER_AGENT
    if mark in text:
        body = text.split(mark, 1)[1]
    elif READER_ALT in text:
        # слід підписаний інакше (інша назва агента) — беремо від заголовка переліку
        body = text[text.index(READER_ALT):]
    else:
        return []
    nxt = body.find("\n### ")
    if nxt > 0:
        body = body[:nxt]
    out = []
    for line in body.splitlines():
        # ⭐ 05.08.2026: агент оформлює перелік по-різному — «1.», «1)», «- », «• ».
        # Ворота, які розуміють лише одне оформлення, — це ворота, які мовчать.
        line = line.strip().lstrip("*").strip()
        m = re.match(r"^(?:\d{1,2}[.)]|[-–—•])\s+(.{6,200})$", line)
        if m:
            item = re.sub(r"\s+", " ", m.group(1)).strip(" .;")
            if item and not item.lower().startswith(("строк", "кінцев", "гарант")):
                out.append(item)
    return out


def tender_id_in(text: str) -> str:
    """Номер закупівлі з тексту — ОДИН писар: питаємо `tender_ref`, свого розбору не пишемо."""
    try:
        import tender_ref
        got = tender_ref.find_all(str(text or ""))
        return got[0] if got else ""
    except Exception:
        return ""


# ⭐⭐⭐ 05.08.2026, ПЕРЕВІРКА ЖИВОГО ПАКЕТА. Агент-читач зібрав 13 позицій із
# ПЕРЕЛІКУ оголошення — і пропустив дві обовʼязкові вимоги, які лежали в ДОДАТКУ №2
# («оригінал або копію паспорта/сертифіката якості», «протокол випробувань дослідного
# зразка»). Без них пропозицію знімають із торгів. У промпті читача прохання «дивись і
# в додатки» стояло — і не спрацювало. Тому код читає документи САМ і додає пропущене.
_ASK_MARKS = ("повинен надати", "повинні надати", "надати в складі", "надає в складі",
              "у складі тендерної пропозиції", "у складі пропозиції надати",
              "в складі своєї пропозиції наступні документи")
_ITEM_RE = re.compile(r"^\s*(?:\d{1,2}[.)]|[-–—•])\s+(.{10,220})$")


def extra_requirements_in(files_context: str, limit: int = 12) -> list:
    """Вимоги до складу пропозиції, знайдені В САМИХ ДОКУМЕНТАХ замовника.

    Шукаємо не «документи взагалі», а місця, де замовник каже «учасник повинен
    надати», і забираємо нумерований перелік під ними. Це доповнення до переліку
    агента-читача, а не заміна: те, що знайшли обидва, зливається без дублів.
    """
    text = str(files_context or "")
    if not text:
        return []
    low = text.lower()
    out = []
    for mark in _ASK_MARKS:
        pos = 0
        while True:
            i = low.find(mark, pos)
            if i < 0:
                break
            pos = i + len(mark)
            for line in text[i:i + 1800].splitlines()[1:]:
                m = _ITEM_RE.match(line.strip())
                if not m:
                    if out and len(line.strip()) > 240:
                        break
                    continue
                item = re.sub(r"\s+", " ", m.group(1)).strip(" .;")
                if len(item) >= 10:
                    out.append(item)
                if len(out) >= limit:
                    return out
    return out


def merge_checklists(primary, extra) -> list:
    """Перелік читача + знайдене кодом. Дублі прибираємо за назвою документа."""
    seen, res = set(), []
    for it in list(primary or []) + list(extra or []):
        k = _key(it)
        if len(k) < 8 or k in seen:
            continue
        seen.add(k)
        res.append(it)
    return res
