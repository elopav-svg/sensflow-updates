# -*- coding: utf-8 -*-
"""
tender_index.py — МІСТ між двома джерелами Prozorro.

НАВІЩО. У нас два джерела, і вони не розмовляють одне з одним:
  * пошук (POST) знає СЛОВА і назви, але не знає внутрішнього коду (uuid)
    -> сліпий до глибини: учасники, ціни, скарги йому недоступні;
  * офіційний CDB знає ВСЮ глибину, але не вміє шукати словами.
Індекс `tenderID -> uuid` — єдиний міст. Він мусить бути ОДИН на всіх
(сторож, розвідник завершених, Захисник, звіряч), інакше кожен зробить свій
і кожен по-своєму збреше.

⭐ ГОЛОВНЕ АРХІТЕКТУРНЕ РІШЕННЯ: індекс зберігає не лише ДАНІ, а й МЕЖІ
ВЛАСНОГО ЗНАННЯ — які відрізки часу він реально обійшов. Без цього
«номера немає в індексі» означало б одночасно і «тендера не існує», і
«ми туди не ходили» — і система колись сказала б клієнту «скарг немає»
там, де вона просто не дивилась. Тому відповідей ТРИ, а не дві:
    found   — знайшов, ось uuid;
    absent  — відрізок обійдено ПОВНІСТЮ, номера немає (це певність);
    unknown — туди ще не ходили. Чесний стоп, а не «немає».

ЖИВА РОЗВІДКА 27.07.2026 (усе доведено GET-запитами, безкоштовно):
  * стрічка /tenders?opt_fields=tenderID віддає tenderID + id(uuid) РАЗОМ
    -> індекс будується прямим обходом, БЕЗ добору картки на кожен тендер;
  * opt_fields має білий список: title і value сервер мовчки викидає
    -> назви беруться з пошуку або з картки, тут їх не буде;
  * offset = момент часу (unix) -> можна покрити рівно потрібний відрізок,
    не обходячи 2015->2026;
  * 🔴 СПРОСТОВАНО ЖИВОЮ ПРОБОЮ 27.07.2026. Спершу я вирішив, що тендер
    лягає в стрічку В ДЕНЬ ОГОЛОШЕННЯ (проба: 93 зі 200 записів за 17.07
    мали префікс UA-2026-07-17). Це показувало, що там БАГАТО тендерів
    дня, а НЕ що там ВСІ. Обхід доби 17.07 зібрав 8708 номерів того дня —
    і 2341 номер діапазону був відсутній, серед них шуканий 002005.
    Індекс упевнено сказав "absent" про тендер, який існує.
  * ✅ ЩО ДОВЕДЕНО ЗАМІСТЬ ЦЬОГО (12500 записів, 0 порушень): тендер
    НІКОЛИ не з'являється у стрічці РАНІШЕ за дату у своєму номері, але
    може з'явитись СИЛЬНО пізніше (71% того ж дня, решта +1..+979 днів).
    Тому єдине чесне вікно певності — [дата оголошення -> горизонт
    покриття], а не "доба оголошення";
  * ?tenderID=... як фільтр НЕ працює (сервер ігнорує) — прямого резолвера
    в офіційному API немає.

ОДИН МЕХАНІЗМ. Усе тут — виклики cover(від, до) «покрити відрізок часу»:
щоденна тиха задача, добір історії під конкретний номер, разовий глибокий
прогін. Різних шляхів свідомо НЕМАЄ.

Мережа — лише через tender_source_ua (а той — лише через netfetch, спільні
ворота виходу). Власного urllib тут немає свідомо.
"""

import calendar
import os
import re
import sqlite3
import time

import tender_source_ua as src

# Дата оголошення зашита в номер: UA-2026-07-17-002005-a
_TENDER_ID_RE = re.compile(r"^UA-(\d{4})-(\d{2})-(\d{2})-")

_ISO_RE = re.compile(
    r"^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?"
    r"(?:([+-])(\d{2}):(\d{2})|Z)?$")

# Запас на часовий пояс: номер дає КИЇВСЬКУ дату, стрічка — момент у UTC.
# 6 годин з обох боків перекривають і +02:00, і +03:00 без жодних бібліотек.
_EDGE = 6 * 3600

_PAGE_LIMIT = 500      # більше сервер однаково не віддає
_FRESH = 24 * 3600     # допуск на свіжий хвіст: покриття мусить доходити сюди
_PAUSE = 0.25          # ліміт частоти: ходимо послідовно
_MAX_PAGES = 4000      # запобіжник від нескінченного гортання

_store_override = None


class IndexError_(Exception):
    """Індекс не зміг зробити роботу. Викликач робить чесний стоп."""


# ---------------------------------------------------------------------------
# Сховище
# ---------------------------------------------------------------------------
def default_store():
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(os.path.dirname(here), "tender_index", "index.sqlite")


def use_store(path):
    """Підмінити сховище (для офлайн-тестів). None -> повернути звичайне."""
    global _store_override
    _store_override = path


def store_path():
    return _store_override or default_store()


def _conn():
    p = store_path()
    d = os.path.dirname(p)
    if d and not os.path.isdir(d):
        os.makedirs(d)
    c = sqlite3.connect(p)
    c.execute("CREATE TABLE IF NOT EXISTS pairs ("
              "tender_id TEXT PRIMARY KEY, uuid TEXT NOT NULL, "
              "date_modified TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS covered ("
              "from_ts INTEGER NOT NULL, to_ts INTEGER NOT NULL)")
    return c


# ---------------------------------------------------------------------------
# Час
# ---------------------------------------------------------------------------
def iso_ts(s):
    """'2026-07-27T16:04:33.13+03:00' -> unix-секунди (або None)."""
    m = _ISO_RE.match((s or "").strip())
    if not m:
        return None
    y, mo, d, H, M, S = (int(m.group(i)) for i in range(1, 7))
    ts = calendar.timegm((y, mo, d, H, M, S, 0, 0, 0))
    if m.group(7):
        off = int(m.group(8)) * 3600 + int(m.group(9)) * 60
        ts = ts - off if m.group(7) == "+" else ts + off
    return ts


def window_of(tender_id):
    """Відрізок часу, в якому МУСИТЬ лежати перша поява цього номера
    у стрічці змін. -> (від, до) в unix-секундах або None."""
    m = _TENDER_ID_RE.match((tender_id or "").strip().upper())
    if not m:
        return None
    y, mo, d = int(m.group(1)), int(m.group(2)), int(m.group(3))
    base = calendar.timegm((y, mo, d, 0, 0, 0, 0, 0, 0))
    return (base - _EDGE, base + 24 * 3600 + _EDGE)


# ---------------------------------------------------------------------------
# Межі знання
# ---------------------------------------------------------------------------
def _merge(segs):
    out = []
    for a, b in sorted(segs):
        if out and a <= out[-1][1]:
            out[-1] = (out[-1][0], max(out[-1][1], b))
        else:
            out.append((a, b))
    return out


def covered_segments():
    """Відрізки часу, які індекс РЕАЛЬНО обійшов (злиті)."""
    c = _conn()
    try:
        rows = [(int(a), int(b)) for a, b in
                c.execute("SELECT from_ts, to_ts FROM covered")]
    finally:
        c.close()
    return _merge(rows)


def is_covered(a, b):
    for x, y in covered_segments():
        if x <= a and b <= y:
            return True
    return False


def mark_covered(a, b):
    """Записати ЧЕСНО пройдений відрізок: якщо обхід обірвався,
    сюди йде тільки те, докуди дійшли."""
    a, b = int(a), int(b)
    if b <= a:
        return covered_segments()
    c = _conn()
    try:
        c.execute("INSERT INTO covered (from_ts, to_ts) VALUES (?, ?)", (a, b))
        rows = [(int(x), int(y)) for x, y in
                c.execute("SELECT from_ts, to_ts FROM covered")]
        merged = _merge(rows)
        c.execute("DELETE FROM covered")
        c.executemany("INSERT INTO covered (from_ts, to_ts) VALUES (?, ?)",
                      merged)
        c.commit()
    finally:
        c.close()
    return merged


def remember(rows):
    """rows: [(tender_id, uuid, date_modified)] -> скільки НОВИХ номерів."""
    if not rows:
        return 0
    c = _conn()
    try:
        before = c.execute("SELECT COUNT(*) FROM pairs").fetchone()[0]
        c.executemany("INSERT OR REPLACE INTO pairs "
                      "(tender_id, uuid, date_modified) VALUES (?, ?, ?)",
                      rows)
        c.commit()
        after = c.execute("SELECT COUNT(*) FROM pairs").fetchone()[0]
    finally:
        c.close()
    return after - before


# ---------------------------------------------------------------------------
# ОДИН МЕХАНІЗМ: покрити відрізок часу
# ---------------------------------------------------------------------------
def cover(from_ts, to_ts, pause=_PAUSE, limit=_PAGE_LIMIT,
          max_pages=_MAX_PAGES, on_page=None):
    """Пройти стрічку змін від from_ts до to_ts і дописати пари в індекс.

    Це ЄДИНИЙ спосіб наповнити індекс. Щоденна задача, добір історії під
    конкретний номер і разовий глибокий прогін — усе це виклики цієї функції
    з різними межами.

    Позначку «покрито» ставить ТІЛЬКИ фактично пройдений шматок: обірвався
    на пів дорозі -> межа знання зсунеться рівно туди, докуди дійшли.
    """
    from_ts, to_ts = int(from_ts), int(to_ts)
    if to_ts <= from_ts:
        raise IndexError_("порожній відрізок: %s..%s" % (from_ts, to_ts))
    offset, pages, added, seen = from_ts, 0, 0, 0
    reached, complete, stop = from_ts, False, ""
    while pages < max_pages:
        page = src.feed_page(offset=offset, limit=limit, fields=("tenderID",))
        pages += 1
        items = page.get("items") or []
        seen += len(items)
        rows = []
        for it in items:
            tid = (it.get("tenderID") or "").strip().upper()
            uid = (it.get("id") or "").strip()
            dm = it.get("dateModified") or ""
            if tid and uid:
                rows.append((tid, uid, dm))
            t = iso_ts(dm)
            if t and t > reached:
                reached = t
        added += remember(rows)
        if on_page:
            on_page(pages, seen, added, reached)
        if reached >= to_ts:
            complete, stop, reached = True, "дійшли до кінця відрізка", to_ts
            break
        if not items:
            complete, stop, reached = True, "стрічка скінчилась", to_ts
            break
        nxt = page.get("next_offset")
        if not nxt:
            complete, stop, reached = True, "стрічка скінчилась", to_ts
            break
        offset = nxt
        if pause:
            time.sleep(pause)
    if not complete:
        stop = "уперлись у стелю сторінок (max_pages=%d)" % max_pages
    mark_covered(from_ts, reached)
    return {"from": from_ts, "to": to_ts, "reached": reached,
            "pages": pages, "seen": seen, "added": added,
            "complete": complete, "stop": stop}


def find_uuid(tender_id, max_pages=_MAX_PAGES, pause=_PAUSE):
    """ЗНАЙТИ код КОНКРЕТНОГО номера — не претендуючи на певність про ВІДСУТНІСТЬ.

    ⭐⭐⭐ 01.08.2026 (живий прогін у клієнта: 42 порожні рядки з 54). Глибина
    архіву торгів ходила через `cover_since_announced` — суцільний обхід ВІД
    дати оголошення ДО СЬОГОДНІ. Для тендера з грудня 2025 це вісім місяців
    стрічки; за прогін недосяжно, тому переможець і сума перемоги лишались
    порожніми там, де на Прозорро вони є.

    РІЗНИЦЯ, ЯКОЇ БРАКУВАЛО: **знайти ≠ довести відсутність.**
      • «absent» вимагає СУЦІЛЬНОГО обходу — інакше ми збрехали б «немає»;
      • «found» вимагає лише дійти до запису — і можна зупинитись ОДРАЗУ.
    Тому ця функція йде від дати оголошення вперед і зупиняється на першому ж
    збігу. Порожня відповідь тут означає «не знайшов за стелею сторінок», а НЕ
    «тендера не існує» — і викликач мусить сказати саме так.

    ⚠ `mark_covered` тут НЕ викликається СВІДОМО: частковий обхід не дає права
    називати відрізок покритим. Саме на цьому 27.07.2026 індекс упевнено сказав
    «absent» про тендер, який існує.

    Усе, що трапилось дорогою, лягає в індекс (`remember`) — обхід не марний:
    наступні номери того ж періоду резолвяться безкоштовно.

    -> (uuid, {"pages", "via"}); uuid == "" якщо не знайшли.
    """
    want = (tender_id or "").strip().upper()
    w = window_of(want)
    if not w:
        raise IndexError_("номер не схожий на UA-РРРР-ММ-ДД-...: %r" % tender_id)
    known = lookup(want)
    if known.get("status") == "found":
        return known.get("uuid") or "", {"pages": 0, "via": "індекс уже знав"}
    start = w[0]
    for a_, b_ in covered_segments():
        if a_ <= start <= b_:
            start = max(start, b_)
            break
    offset, pages = start, 0
    while pages < int(max_pages):
        page = src.feed_page(offset=offset, limit=_PAGE_LIMIT, fields=("tenderID",))
        pages += 1
        items = page.get("items") or []
        rows, found = [], ""
        for it in items:
            tid = (it.get("tenderID") or "").strip().upper()
            uid = (it.get("id") or "").strip()
            if tid and uid:
                rows.append((tid, uid, it.get("dateModified") or ""))
                if tid == want:
                    found = uid
        remember(rows)
        if found:
            return found, {"pages": pages, "via": "обхід стрічки від дати оголошення"}
        if not items or not page.get("next_offset"):
            return "", {"pages": pages, "via": "стрічка скінчилась, номер не трапився"}
        offset = page["next_offset"]
        if pause:
            time.sleep(pause)
    return "", {"pages": pages, "via": "стеля сторінок (%s)" % max_pages}


def horizon():
    """Найсвіжіший момент, до якого індекс узагалі щось знає. 0 — порожній."""
    segs = covered_segments()
    return segs[-1][1] if segs else 0


def cover_since_announced(tender_id, until=None, **kw):
    """Покрити стрічку ВІД дати оголошення цього номера ДО «тепер».

    🔴 Саме тут була моя помилка 27.07.2026: спершу тут стояло cover_day_of —
    обхід самої лише доби оголошення. Доба НЕ дає певності: тендер лягає в
    стрічку не раніше своєї дати, але може лягти й через тижні (доведено на
    12500 записах). Обхід доби зібрав 8708 номерів дня і не мав 2341 інших —
    і індекс сказав "absent" про тендер, який існує.

    Уже покритий шматок не переобходимо: якщо в індексі є суцільний відрізок
    від дати оголошення, стартуємо з його кінця.
    """
    w = window_of(tender_id)
    if not w:
        raise IndexError_("номер не схожий на UA-РРРР-ММ-ДД-...: %r" % tender_id)
    start = w[0]
    for a, b in covered_segments():
        if a <= start <= b:
            start = max(start, b)
            break
    end = int(until if until is not None else time.time())
    if end <= start:
        return {"from": start, "to": end, "reached": start, "pages": 0,
                "seen": 0, "added": 0, "complete": True,
                "stop": "вже покрито до кінця"}
    return cover(start, end, **kw)


# ---------------------------------------------------------------------------
# Три чесні відповіді
# ---------------------------------------------------------------------------
def lookup(tender_id, now=None):
    """found / absent / unknown — і НІКОЛИ не «немає» замість «не знаю».

    ⭐ ЩО САМЕ ДАЄ ПРАВО СКАЗАТИ «absent» (переписано 27.07.2026 після живої
    проби). Не «ми обійшли добу оголошення» і навіть не «ми обійшли до
    власного горизонту» — обидва визначення дозволяли назвати певністю
    обхід на п'ять хвилин. Право дає ЛИШЕ суцільне покриття від дати
    оголошення до СЬОГОДНІ (з добовим допуском на свіжий хвіст). Тендер
    лягає в стрічку не раніше своєї дати, але може лягти й через тижні —
    отже поки не дійшли до сьогодні, «немає» сказати нема з чого.

    now — момент «зараз» (для тестів). За замовчуванням системний час.
    """
    tid = (tender_id or "").strip().upper()
    if not tid:
        return {"status": "unknown", "tender_id": tid,
                "why": "порожній номер"}
    c = _conn()
    try:
        row = c.execute("SELECT uuid FROM pairs WHERE tender_id = ?",
                        (tid,)).fetchone()
    finally:
        c.close()
    if row:
        return {"status": "found", "tender_id": tid, "uuid": row[0]}
    w = window_of(tid)
    if not w:
        return {"status": "unknown", "tender_id": tid,
                "why": "номер не схожий на UA-РРРР-ММ-ДД-..., дату взяти нізвідки"}
    edge = int(now if now is not None else time.time()) - _FRESH
    if edge > w[0] and is_covered(w[0], edge):
        return {"status": "absent", "tender_id": tid, "window": (w[0], edge),
                "why": "стрічку обійдено суцільно від дати оголошення до %s — "
                       "такого номера там немає" % _human(edge)}
    return {"status": "unknown", "tender_id": tid, "window": w,
            "why": "немає суцільного обходу від дати оголошення (%s) до "
                   "сьогодні; обійдено лише %.1f год — я не знаю, чи він є"
                   % (_human(w[0]), sum(b - a for a, b in covered_segments()) / 3600.0)}


def resolve_uuid(tender_id, autofill=False, **kw):
    """Номер -> uuid. autofill=True дозволяє добрати добу з мережі.

    Свідомо autofill=False за замовчуванням: похід у мережу — це час і
    трафік, і вирішувати про нього має той, хто кличе, а не міст.
    """
    _now2 = kw.pop("now", None)
    res = lookup(tender_id, now=_now2)
    if res["status"] == "unknown" and autofill and res.get("window"):
        res["filled"] = cover_since_announced(tender_id, **kw)
        res2 = lookup(tender_id, now=_now2)
        res2["filled"] = res["filled"]
        return res2
    return res


def _human(ts):
    return time.strftime("%d.%m.%Y %H:%M", time.gmtime(int(ts))) + " UTC"


def stats():
    c = _conn()
    try:
        n = c.execute("SELECT COUNT(*) FROM pairs").fetchone()[0]
    finally:
        c.close()
    segs = covered_segments()
    return {"pairs": n, "segments": segs, "store": store_path(),
            "covered_hours": round(sum(b - a for a, b in segs) / 3600.0, 1)}
