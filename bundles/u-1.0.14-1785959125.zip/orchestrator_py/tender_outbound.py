# -*- coding: utf-8 -*-
"""
tender_outbound.py — ВАРТОВИЙ НА ВИХОДІ (27.07.2026).

КЛАС ПРОБЛЕМИ, який лікуємо.
    Тендерний факт виходить до людини НЕ одним шляхом, а щонайменше чотирма:
    Telegram, чат, файл-звіт, інтерфейс. Ворота правди (tender_message.build)
    стоять у СКЛАДАЧА — але ніщо не заважає будь-якому відправнику скласти
    тендерний текст самотужки й відправити його повз ворота. Один прикритий
    шлях із чотирьох — це ілюзія прикриття, а не прикриття.

ТОЧКА РІШЕННЯ.
    Не «навчити кожен відправник кликати ворота» (це латка: п'ятий відправник,
    доданий за рік, про ворота не знатиме). Замість цього — ДВА кроки:
      1. складач СТАВИТЬ ПЕЧАТКУ на текст, який він сам зібрав і сам звірив;
      2. вартовий на виході дивиться на текст, що йде до людини: якщо в ньому є
         ознаки тендера (номер UA-…, посилання на Прозоро), кожна така ознака
         має бути ВСЕРЕДИНІ запечатаного шматка. Немає печатки — не випускаємо.
    Правило живе в ОДНОМУ файлі. Новий канал підключається одним рядком,
    а не переписуванням правила.

FAIL-CLOSED.
    Будь-яка невизначеність (немає сховища печаток, побите сховище, незнайомий
    формат) трактується як «печатки немає» → текст НЕ виходить. Мовчазний
    пропуск гірший за незручність.

ЧЕСНА МЕЖА.
    Вартовий закриває ті канали, які його кличуть. Мережеві канали додатково
    прикриті тим, що всі вони ходять назовні через netfetch (одне вікно).
    Локальні канали (файл, інтерфейс) треба підключати явно — жоден скрипт не
    змусить майбутній локальний канал згадати про вартового сам.
"""
import json
import re
import threading
import time
from pathlib import Path

import source_trust
import tender_ref

try:
    import config
    _DIR = Path(config.ENGINE_DIR)
except Exception:                                    # автономний запуск тестів
    _DIR = Path(__file__).resolve().parent

_STORE = _DIR / "tender_outbound_seals.json"
_LOCK = threading.RLock()

SEAL_TTL_SECONDS = 48 * 3600      # печатка живе 2 доби — довше вона не потрібна
MAX_SEALS = 200                   # обмежене сховище: старі витісняються

# Ознаки того, що в тексті є ТЕНДЕРНИЙ ФАКТ (а не просто слово «тендер»).
_MARKERS = (
    # 04.08.2026: формат номера НЕ живе тут. У платформі було чотири різні
    # регулярки на одну річ; своя знала лише ВЕЛИКІ літери, тому посилання
    # клієнта «.../ua-2026-08-04-003201-a» цей вартовий не бачив узагалі.
    re.compile(tender_ref.PATTERN, re.IGNORECASE),
    re.compile(r"prozorro\.gov\.ua/tender/", re.IGNORECASE),
)

REFUSAL_TEXT = (
    "⚠ Повідомлення про тендери НЕ надіслано.\n"
    "Текст містив тендерні дані, які не пройшли через ворота звірки з Прозоро, "
    "тому платформа його не випустила.\n"
    "Це не збій зв'язку — це запобіжник проти неперевірених фактів. "
    "Покажіть це повідомлення розробнику."
)


# ── службове ───────────────────────────────────────────────────────────────
def _norm(text) -> str:
    """Нормалізує текст для порівняння: пробіли/переноси не мають значення."""
    return re.sub(r"\s+", " ", str(text or "")).strip()


def has_tender_markers(text) -> bool:
    """Чи є в тексті ознака тендерного факту."""
    t = str(text or "")
    return any(rx.search(t) for rx in _MARKERS)


def _load() -> list:
    with _LOCK:
        try:
            data = json.loads(_STORE.read_text(encoding="utf-8"))
        except Exception:
            return []
        if not isinstance(data, list):
            return []
        now = time.time()
        out = []
        for it in data:
            try:
                if not isinstance(it, dict):
                    continue
                if now - float(it.get("at", 0)) > SEAL_TTL_SECONDS:
                    continue
                if not it.get("text"):
                    continue
                out.append({"at": float(it["at"]), "text": str(it["text"])})
            except Exception:
                continue
        return out


def _save(items: list):
    with _LOCK:
        try:
            _STORE.parent.mkdir(parents=True, exist_ok=True)
            _STORE.write_text(json.dumps(items[-MAX_SEALS:], ensure_ascii=False),
                              encoding="utf-8")
        except Exception:
            pass          # не змогли зберегти -> наступна перевірка просто не пройде


# ── публічне ───────────────────────────────────────────────────────────────
def seal(text) -> str:
    """Ставить печатку на текст, зібраний і звірений воротами складача.

    Кличе ЛИШЕ tender_message.build()/build_analytics() — більше ніхто.
    Повертає текст без змін (печатка живе поруч, а не в тексті: інакше її можна
    було б скопіювати в підроблене повідомлення).
    """
    n = _norm(text)
    if not n:
        return text
    items = _load()
    if not any(i["text"] == n for i in items):
        items.append({"at": time.time(), "text": n})
        _save(items)
    return text


def check(text):
    """Головна перевірка виходу.

    -> (ok: bool, safe_text: str, reason: str)
       ok=True  — випускати можна (текст повертається без змін);
       ok=False — випускати НЕ можна; safe_text = чесна відмова для людини.
    """
    raw = str(text or "")
    if not has_tender_markers(raw):
        return True, raw, ""                       # не тендерний текст — не наша справа

    # 04.08.2026. ПИТАННЯ ЗМІНИЛОСЬ: не «чи запечатаний цей РЯДОК», а «чи має
    # цей ФАКТ підтверджене джерело». Стара перевірка вимагала дослівного збігу,
    # тому похідний текст (правовий висновок, де номер стоїть у реченні юриста)
    # печатки не мав — і вартовий блокував нашу ж чесну роботу. Живий випадок:
    # клієнт попросив підстави для скарги і не отримав нічого.
    # Вигадці це нічого не відкриває: номера, якого немає в Прозорро, у реєстрі
    # не буде — туди пише лише той, кому джерело справді віддало картку.
    rest = _norm(raw)
    for _n in tender_ref.find_all(rest):
        if source_trust.is_confirmed(_n):
            rest = re.sub(re.escape(_n), " ", rest, flags=re.IGNORECASE)

    # Другий шлях до того самого джерела — печатка складача (сторож тендерів сам
    # звіряє дані й сам її ставить). Дві двері в одну кімнату, не два писарі.
    for it in _load():
        if it["text"] and it["text"] in rest:
            rest = rest.replace(it["text"], " ")   # цей шматок прикритий печаткою

    if has_tender_markers(rest):
        reason = ("тендерні дані без печатки складача: "
                  + _norm(rest)[:160])
        try:
            import egress_guard
            egress_guard.log("tender_unsealed_blocked", {"sample": _norm(rest)[:200]})
        except Exception:
            pass
        return False, REFUSAL_TEXT, reason

    return True, raw, ""


def guard(text) -> str:
    """Зручна обгортка для відправників: повертає або текст, або чесну відмову.
    Ніколи не кидає виняток — відправник не має падати через вартового."""
    try:
        ok, safe, _ = check(text)
        return safe if not ok else text
    except Exception:
        return REFUSAL_TEXT if has_tender_markers(text) else text


def forget_all():
    """Тільки для тестів: очистити сховище печаток."""
    _save([])
