# -*- coding: utf-8 -*-
"""notify_client_update.py — повідомити клієнта в Telegram, що вийшла нова версія.

ЧОМУ ОКРЕМИЙ СКРИПТ, А НЕ РУКАМИ.
    Клас проблеми — «другий писар правди про клієнта». Номер чату, набраний рукою
    в батнику, розійдеться з CRM тієї ж миті, коли клієнт зміниться. Тому:
      * ХТО клієнт — вирішує publish_update.canon_customer (імʼя з ліцензії через CRM);
      * КУДИ слати — бере CRM (channels.telegram_id), а не аргумент командного рядка;
      * ЯК звертатись — бере CRM (salutation), а не рядок у коді;
      * ЩО ЗМІНИЛОСЬ — бере МАНІФЕСТ КЛІЄНТА, тобто рівно той текст, який людина
        побачить у своїй консолі біля кнопки «Оновити».
    Немає привʼязки в CRM → СТОП, нічого не відправляємо (fail-closed): краще
    не надіслати, ніж надіслати чужій людині.

⭐⭐⭐ 04.08.2026 — ЧОМУ ОПИС ЗМІН БІЛЬШЕ НЕ ЖИВЕ В ЦЬОМУ ФАЙЛІ.
    Тут стояв текст листа, вбитий у код. Версію він підставляв живу
    (config.APP_VERSION), а перелік змін лишався той, що вписали рукою під 1.0.6.
    04.08, на 1.0.8, цей канал відправив би клієнту «доступне оновлення 1.0.8» і
    під ним зміни від 1.0.6. Це рівно «ДВА ПИСАРІ ОДНІЄЇ ПРАВДИ»: канал оновлень
    розповідав одне, лист — інше, і розходились вони мовчки, при кожному випуску.
    Тепер писар ОДИН — маніфест клієнта. Що клієнт читає в консолі, те й у листі.

⭐ ЛИСТ ПОКРИВАЄ ВСІ ПРОПУЩЕНІ ВЕРСІЇ, А НЕ ЛИШЕ ОСТАННЮ.
    Клієнту востаннє писали про 1.0.6, а вийшли 1.0.7 і 1.0.8 — отже в листі
    мають бути обидві. Від якої версії рахувати — видно з нашого ж журналу в CRM
    (запис «outbound» цього самого скрипта), а не з памʼяті людини.
"""
import argparse
import json
import sys
from pathlib import Path

import config
import crm
import publish_update as pu
import telegram_bot as tb


# Формат запису в журналі CRM. ОДИН на запис і на читання — інакше журнал,
# який ми самі й пишемо, стає для нас нечитабельним.
HIST_PREFIX = "Telegram: повідомлення про оновлення "

GREETING = "{salutation}, вітаю!"
LEAD = "Для вашої програми SensFlow доступне оновлення {version}."
CHANGES_TITLE = "Що змінилось:"
HOWTO = ("Щоб оновитись — відкрийте консоль і натисніть «Оновити». "
         "Це займе менше хвилини.")


class Stop(Exception):
    """Зупинка, яка називає себе вголос і нічого не відправляє."""


def default_repo() -> Path:
    return Path(__file__).resolve().parent.parent / "sensflow-updates"


def last_notified(card: dict) -> str:
    """Про яку версію цьому клієнту писали востаннє (з нашого ж журналу)."""
    seen = ""
    for h in (card.get("history") or []):
        if h.get("type") != "outbound":
            continue
        note = str(h.get("note") or "")
        if note.startswith(HIST_PREFIX):
            seen = note[len(HIST_PREFIX):].strip()
    return seen


def load_manifest(name: str, repo: Path) -> dict:
    mpath = Path(repo) / "manifests" / ("%s.json" % pu.cust_hash(name))
    if not mpath.exists():
        raise Stop("немає маніфесту %s — цій людині ще нічого не публікували."
                   % mpath.name)
    try:
        return json.loads(mpath.read_text(encoding="utf-8"))
    except Exception as e:
        raise Stop("маніфест %s не читається (%s)." % (mpath.name, e))


def pick_updates(man: dict, since: str) -> list:
    """Записи, про які клієнту ще не писали: (since, APP_VERSION]."""
    lo = pu._vtuple(since) if since else ()
    hi = pu._vtuple(config.APP_VERSION)
    out = []
    for u in (man.get("updates") or []):
        v = str(u.get("version") or "")
        if not v:
            continue
        t = pu._vtuple(v)
        if t > hi:
            continue
        if lo and t <= lo:
            continue
        out.append(u)
    out.sort(key=lambda u: pu._vtuple(str(u.get("version") or "")))
    return out


def build_note(name: str, card: dict, repo: Path, since: str = "") -> tuple:
    """Збирає текст листа. Будь-яка діра — Stop, а не лист із дірою."""
    salutation = str(card.get("salutation") or "").strip()
    if not salutation:
        raise Stop("у картці «%s» немає поля «salutation» (звертання).\n"
                   "      Заповніть: crm.ensure_client(<клієнт>, "
                   "salutation='Імʼя По-батькові у кличному відмінку')." % name)

    man = load_manifest(name, repo)
    mver = str(man.get("version") or "")
    if mver != config.APP_VERSION:
        raise Stop("маніфест клієнта на версії %s, а збірка — %s.\n"
                   "      Спершу опублікуйте оновлення, потім пишіть клієнту."
                   % (mver or "?", config.APP_VERSION))

    ups = pick_updates(man, since)
    if not ups:
        raise Stop("клієнту вже писали про версію %s — нового для нього немає."
                   % (since or config.APP_VERSION))

    blocks = []
    for u in ups:
        notes = str(u.get("notes") or "").strip()
        if not notes:
            raise Stop("у записі %s порожній опис — клієнт отримав би лист "
                       "без пояснення." % u.get("id"))
        blocks.append(notes)

    text = "\n\n".join([
        GREETING.format(salutation=salutation),
        LEAD.format(version=config.APP_VERSION),
        CHANGES_TITLE,
        "\n\n".join(blocks),
        HOWTO,
    ])
    return text, [str(u.get("version")) for u in ups]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--customer", default="Casper", help="імʼя або псевдонім клієнта")
    ap.add_argument("--repo", default="", help="локальна копія репозиторію оновлень")
    ap.add_argument("--since", default="",
                    help="від якої версії рахувати (за замовч. — з журналу CRM)")
    ap.add_argument("--dry-run", action="store_true", help="показати і НЕ відправляти")
    a = ap.parse_args()

    name, why = pu.canon_customer(a.customer)
    if not name:
        print("  [X] STOP: %s" % why)
        print("      Відомі імена — у CRM (поле «Клієнт» або англійський псевдонім).")
        sys.exit(2)

    card = crm.get_client(name) or {}
    chat_id = str((card.get("channels") or {}).get("telegram_id") or "").strip()
    if not chat_id:
        print("  [X] STOP: у картці «%s» немає привʼязаного Telegram." % name)
        print("      Спершу привʼяжіть чат: crm.link_telegram(<клієнт>, <chat_id>).")
        sys.exit(2)

    since = a.since or last_notified(card)
    repo = Path(a.repo) if a.repo else default_repo()

    try:
        text, covered = build_note(name, card, repo, since)
    except Stop as e:
        print("  [X] STOP: %s" % e)
        sys.exit(2)

    print("=" * 60)
    print("  Клієнт : %s" % name)
    print("  Чат    : %s" % chat_id)
    print("  Версія : %s (з config.APP_VERSION)" % config.APP_VERSION)
    print("  Востаннє писали: %s" % (since or "— (не писали жодного разу)"))
    print("  У листі версії : %s (джерело — маніфест клієнта)" % ", ".join(covered))
    print("=" * 60)
    print(text)
    print("=" * 60)

    if a.dry_run:
        print("DRY-RUN: нічого не відправлено.")
        return

    token = tb._support_token()
    if not token:
        print("  [X] STOP: не налаштований токен бота підтримки "
              "(TELEGRAM_SUPPORT_BOT_TOKEN).")
        sys.exit(2)

    tb._ctx.token = token
    tb._ctx.role = "support"
    ok = tb._send_message(chat_id, text)
    if not ok:
        print("  [X] FAILED: Telegram не прийняв повідомлення. Причина — вище.")
        sys.exit(1)

    try:
        crm.add_history(name, "outbound", HIST_PREFIX + config.APP_VERSION)
    except Exception:
        pass
    print("OK: повідомлення надіслано клієнту «%s» (чат %s)." % (name, chat_id))


if __name__ == "__main__":
    main()
