# -*- coding: utf-8 -*-
"""
tender_skeleton.py — КІСТЯК ТЕНДЕРНОГО ПАКЕТА БУДУЄ КОД, А НЕ МОДЕЛЬ (05.08.2026).

КОРІНЬ, ЯКИЙ ТУТ ЗАКРИТО. Три платні прогони поспіль закінчились «роботи не зроблено»:
агенти самі відмовлялись складати пакет, бо «більшість інформації відсутня» — у них не
було реквізитів і цін учасника. Спроба полікувати це текстом у промпті («порожня графа —
не заглушка») не змінила нічого: рішення ухвалює модель, а прохання в промпті — це
прохання, а не ворота. Той самий закон, який ми довели сьогодні на маршруті й на файлах.

РІШЕННЯ АРХІТЕКТУРНЕ, А НЕ ВМОВЛЯННЯ. Кістяк пакета — детермінований:
    перелік замовника (його витягує агент-читач)  ->  структура пакета БУДУЄТЬСЯ КОДОМ
Кожен пункт переліку отримує СВІЙ розділ, шапку учасника з реквізитів бази знань, явні
порожні графи `______` там, де даних немає, і рядок у реєстрі з підставою. Модель після
цього не вирішує, БУТИ пакету чи ні — пакет уже є. Вона лише наповнює розділи словами.

НАСЛІДОК, ЗАРАДИ ЯКОГО ЦЕ ЗРОБЛЕНО: відмова моделі більше не може знищити результат.
Найгірше, що може статись, — пакет із порожніми графами. Це чесний і придатний до роботи
папір, а не «⛔ роботи не зроблено».

ЩО ЦЕЙ МОДУЛЬ НЕ РОБИТЬ. Не вигадує вимог (усе — з переліку замовника), не вигадує
реквізитів (лише з бази знань клієнта), не тлумачить закон, не ходить у мережу.
"""

import re

# Слова, за якими КОД (а не модель) вирішує, хто виробляє документ.
# Порядок важливий: перший збіг виграє.
_BY_PARTICIPANT = ("копі", "витяг", "виписк", "статут", "паспорт", "ліценз", "дозвіл",
                   "накладн", "сертифікат", "протокол випроб", "свідоцтв", "довіреніст",
                   "наказ про призначення")
_BY_CUSTOMER_FORM = ("додатк", "форм", "цінова пропозиц", "анкет")

SIGN_LINE = "______________________"


def _clean(item: str) -> str:
    """Назва документа без хвостів-посилань на пункт: «(п.7)», «п. 8»."""
    t = re.sub(r"\s+", " ", str(item or "")).strip(" .;:")
    t = re.sub(r"\((?:[^()]*)\)\s*$", "", t).strip(" .;:,")
    return t


def source_of(item: str) -> str:
    """Підстава — те, що агент-читач приписав пункту в дужках, або «перелік оголошення».

    Своєї підстави ми НЕ вигадуємо: якщо читач не назвав пункт, так і пишемо —
    «перелік оголошення». Порожньої підстави в реєстрі не буває.
    """
    m = re.search(r"\(([^()]*)\)\s*$", str(item or "").strip())
    if m and m.group(1).strip():
        return m.group(1).strip()
    return "перелік оголошення"


def who_makes(item: str) -> str:
    """«учасник» — копії й видані документи · «форма замовника» · «система» — довідки."""
    low = _clean(item).lower()
    for w in _BY_PARTICIPANT:
        if w in low:
            return "учасник"
    for w in _BY_CUSTOMER_FORM:
        if w in low:
            return "форма замовника"
    return "система"


def _head(req: dict) -> list:
    """Шапка учасника з бази знань. Чого немає — порожня графа, а не вигадка."""
    name = (req or {}).get("name") or SIGN_LINE
    edrpou = (req or {}).get("edrpou") or SIGN_LINE
    return [
        "**%s**" % name,
        "код ЄДРПОУ %s" % edrpou,
        "Адреса: %s   тел.: %s   e-mail: %s" % (SIGN_LINE, SIGN_LINE, SIGN_LINE),
        "",
        "Вих. № ______ від «___» __________ 20__ р.",
        "",
    ]


def _sign(req: dict) -> list:
    return ["", "Директор                    ____________________        %s"
            % ((req or {}).get("director") or SIGN_LINE), ""]


def document_section(item: str, req: dict, facts: dict) -> str:
    """Один готовий документ пакета — кістяк, який модель може лише наповнити."""
    name = _clean(item)
    who = who_makes(item)
    tender = (facts or {}).get("tender_id") or ""
    subject = (facts or {}).get("subject") or ""
    tail = (" %s%s" % (tender, (" — «%s»" % subject) if subject else "")).rstrip()

    lines = ["## %s" % name, ""]
    if who == "учасник":
        lines += [
            "> Цей документ **додає учасник** — його видали державні органи або він уже існує "
            "в учасника. Платформа його не складає і не підробляє.",
            "",
            "**Що подати:** %s." % name,
            "**Вимога:** %s." % source_of(item),
            "**Формат:** скан у PDF, завірений підписом (і печаткою за наявності).",
        ]
    elif who == "форма замовника":
        lines += [
            "> Заповнюється **на бланку Замовника** (%s). Своєю формою замінювати не можна."
            % source_of(item),
            "",
            "**Що заповнити:** усі графи форми замовника.",
            "**Дані, яких у платформи немає:** ціна за одиницю, загальна сума, строки — "
            "проставляє учасник.",
        ]
    else:
        lines += _head(req)
        lines += [
            "### ДОВІДКА",
            "### %s" % name,
            "",
            "Видана для участі у закупівлі%s." % (tail or ""),
            "**Підстава вимоги:** %s." % source_of(item),
            "",
            "Цим підтверджуємо: %s" % SIGN_LINE,
            "",
            "_(текст довідки — нижче; порожні графи заповнює учасник перед подачею)_",
        ]
        lines += _sign(req)
    return "\n".join(lines)


def registry_table(checklist) -> str:
    """РЕЄСТР ПАКЕТА. Будує КОД: кожен пункт переліку отримує рядок із підставою.

    Саме тому реєстр не може «загубитись», якщо модель про нього забула."""
    rows = ["| Документ | Підстава (пункт оголошення) | Хто додає |",
            "|---|---|---|"]
    for it in (checklist or []):
        rows.append("| %s | %s | %s |" % (_clean(it), source_of(it), who_makes(it)))
    return "\n".join(rows)


def to_fill(checklist, req: dict) -> str:
    """Чесний перелік того, що людина мусить проставити руками."""
    gaps = list((req or {}).get("gaps") or [])
    lines = ["## ЗАПОВНИТИ ПЕРЕД ПОДАЧЕЮ", ""]
    if gaps:
        lines.append("**Реквізити, яких немає в базі знань:**")
        lines += ["- " + g for g in gaps]
        lines.append("")
    own = [_clean(i) for i in (checklist or []) if who_makes(i) == "учасник"]
    if own:
        lines.append("**Документи, які додає учасник своїми файлами:**")
        lines += ["- " + o for o in own]
        lines.append("")
    forms = [_clean(i) for i in (checklist or []) if who_makes(i) == "форма замовника"]
    if forms:
        lines.append("**Форми Замовника (заповнюються на його бланку):**")
        lines += ["- " + f for f in forms]
        lines.append("")
    lines.append("**Дані, яких платформа не має і мати не може:** ціни, номери й дати "
                 "договорів, банківські реквізити, підписант.")
    return "\n".join(lines)


def build(checklist, req: dict = None, facts: dict = None) -> str:
    """ПОВНИЙ КІСТЯК ПАКЕТА. Порожній перелік -> порожній рядок (нема з чого будувати)."""
    items = [str(x) for x in (checklist or []) if str(x).strip()]
    if not items:
        return ""
    facts = facts or {}
    tender = facts.get("tender_id") or ""
    subject = facts.get("subject") or ""
    head = ["# ПАКЕТ ДОКУМЕНТІВ ДЛЯ УЧАСТІ У ЗАКУПІВЛІ"]
    if tender or subject:
        head.append("## %s%s" % (tender, (" — «%s»" % subject) if subject else ""))
    for k, label in (("customer", "Замовник"), ("deadline", "Кінцевий строк подання"),
                     ("quantity", "Кількість")):
        if facts.get(k):
            head.append("**%s:** %s" % (label, facts[k]))
    head.append("")
    head.append("Пакет складено за переліком обовʼязкових документів з оголошення замовника: "
                "**%d позицій**. Кожен документ нижче має підставу в реєстрі." % len(items))
    head.append("")
    parts = ["\n".join(head)]
    for it in items:
        parts.append(document_section(it, req or {}, facts))
    parts.append("## РЕЄСТР ПАКЕТА\n\n" + registry_table(items))
    parts.append(to_fill(items, req or {}))
    return "\n\n---\n\n".join(parts)


def _looks_like_registry(block: str) -> bool:
    """Свій реєстр модель теж любить складати. Двох реєстрів у пакеті не буває:
    правда про склад пакета — одна, і її пише код (у ній є підстава). Тому
    модельний реєстр із тексту прибираємо, а не кладемо поруч."""
    low = (block or "").lower()
    if "|" not in low:
        return False
    return ("реєстр" in low[:200]) or ("найменування документа" in low and "|" in low)


def merge_model_text(skeleton: str, model_md: str, checklist) -> str:
    """КІСТЯК — ОСНОВА, текст моделі — наповнення.

    Для кожного пункту шукаємо в тексті моделі розділ із такою назвою і, якщо він
    змістовний, вставляємо його ПІД кістяковим розділом. Нічого не викидаємо: модель
    може додати корисне, але не може прибрати обовʼязкове.
    """
    if not skeleton:
        return model_md or ""
    if not (model_md or "").strip():
        return skeleton
    blocks = [b for b in re.split(r"\n(?=#{1,3}\s)", model_md)
              if not _looks_like_registry(b)]
    out = skeleton
    added = []
    for it in (checklist or []):
        key = _clean(it).lower()[:32]
        if len(key) < 8:
            continue
        for b in blocks:
            if key in b.lower() and len(b.strip()) > 220:
                added.append(b.strip())
                break
    if added:
        out += ("\n\n---\n\n## ТЕКСТ ДОКУМЕНТІВ, СКЛАДЕНИЙ СИСТЕМОЮ\n\n"
                + "\n\n".join(added))
    return out
