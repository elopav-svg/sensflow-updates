# -*- coding: utf-8 -*-
"""build_routing_cards.py — скласти ПАСПОРТИ ПРИЗНАЧЕННЯ для всіх систем.

Обслуговна дія, не гарячий шлях. Один раз на систему, найдешевшою моделлю драбини.
Паспорт лягає в теку самої системи (.routing_card.json) і має відбиток джерела:
змінили мозок/опис/ролі — паспорт сам стає недійсним, і його треба скласти знову.

Запуск: python build_routing_cards.py            (тільки ті, у кого паспорта немає)
        python build_routing_cards.py --all      (перескласти всім)
        python build_routing_cards.py --only id  (одна система)
"""
import sys
import registry
import routing_card

args = sys.argv[1:]
force = "--all" in args
only = ""
if "--only" in args:
    i = args.index("--only")
    only = args[i + 1] if i + 1 < len(args) else ""

systems = registry.load_systems()
if only:
    systems = [s for s in systems if s.get("id") == only]

print("=" * 64)
print("ПАСПОРТИ ПРИЗНАЧЕННЯ СИСТЕМ")
print("=" * 64)
made = skipped = failed = 0
for s in systems:
    sid = s.get("id")
    if not force and routing_card.load(s):
        print("  =  %-52s паспорт уже є" % sid)
        skipped += 1
        continue
    try:
        card = routing_card.build(s)
        print("  +  %-52s складено" % sid)
        print("       для задач: " + "; ".join(card["for_tasks"])[:150])
        print("       на вхід  : " + card["input"][:150])
        print("       на вихід : " + card["output"][:150])
        print("       НЕ для   : " + "; ".join(card["not_for"])[:150])
        made += 1
    except Exception as e:
        print("  !  %-52s НЕ СКЛАДЕНО: %s" % (sid, str(e)[:120]))
        failed += 1
print("=" * 64)
print("складено: %d · уже було: %d · не вдалося: %d" % (made, skipped, failed))
if failed:
    print("НЕ ВСІ ПАСПОРТИ Є — у каталозі такі системи позначені попередженням.")
    sys.exit(1)
print("ГОТОВО.")
