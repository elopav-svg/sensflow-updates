"""
update.py — механіка оновлень клієнтської інсталяції SensFlow (Фаза 1).

Дизайн (DESIGN_Оновлення_та_Сервіс-центр.md):
  • Перевірка: тягне PER-CLIENT маніфест (за хешем імені клієнта), перевіряє HMAC-підпис
    секретом ліцензії (LICENSE_SIGNING_SECRET) — без нової PKI. Гейт — активна ліцензія.
  • Застосування по кліку: для кожного нового оновлення →
      завантажити бандл (zip) → звірити SHA-256 → БЕКАП → розпакувати поверх коду
      → пост-перевірка (py_compile) → при збої ВІДКАТ із бекапу → журнал.
  • НІКОЛИ не чіпає: .env.local, runs/, threads/, _backups/ (ключі й дані клієнта).

Тільки stdlib (urllib). Підтримує https:// і file:// (для офлайн-тесту).
"""

import json
import hmac
import hashlib
import shutil
import zipfile
import tempfile
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime

import config

# Файли/теки, які застосування ніколи не перезаписує (відносно кореня платформи).
_PROTECTED = (
    "orchestrator_py/.env.local",
    "orchestrator_py/.env",
    "orchestrator_py/runs/",
    "orchestrator_py/threads/",
    "_backups/",
)

# ⭐⭐⭐ 04.08.2026. ДРУГИЙ ЗАМОК — НА БОЦІ КЛІЄНТА.
# Перелік вище — це імена, які ми згадали. Але оновлення розпаковується ПОВЕРХ,
# і будь-який файл стану, що випадково потрапив у бандл, затирає ЖИВУ памʼять
# машини клієнта. Так сторож тендерів після оновлення забував, що вже надсилав.
# Ми прибрали стан із бандла (publish_update), але це наш бік і наша уважність.
# Тут стоїть замок, який тримає навіть тоді, коли ми помилились: клас «стан»
# знає state_files — один писар на всі три шляхи.
try:
    import state_files as _state_files
except Exception:                                    # старий пакет без модуля
    _state_files = None

_JOURNAL = config.RUNS_DIR / "_updates.json"


# ── Версії ───────────────────────────────────────────────────────────────────
def current_version() -> str:
    j = _journal_load()
    return j.get("version") or config.APP_VERSION


def _parse(v):
    out = []
    for part in str(v or "0").strip().split("."):
        num = "".join(ch for ch in part if ch.isdigit())
        out.append(int(num) if num else 0)
    return tuple(out) or (0,)


def _newer(latest, current) -> bool:
    return _parse(latest) > _parse(current)


# ── Журнал застосованих оновлень ─────────────────────────────────────────────
def _journal_load() -> dict:
    try:
        d = json.loads(_JOURNAL.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    d.setdefault("version", config.APP_VERSION)
    d.setdefault("applied", [])
    return d


def _journal_save(d: dict):
    try:
        _JOURNAL.parent.mkdir(parents=True, exist_ok=True)
        _JOURNAL.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


# ── Підпис маніфесту (HMAC секретом ліцензії) ────────────────────────────────
def _secret() -> bytes:
    return (config.ENV.get("LICENSE_SIGNING_SECRET")
            or "SensFlow-license-signing-2026-change-me").encode("utf-8")


def _canon(manifest_body: dict) -> bytes:
    """Канонічний JSON тіла маніфесту (без поля sig) для підпису."""
    body = {k: v for k, v in manifest_body.items() if k != "sig"}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def manifest_sig(manifest_body: dict, secret=None) -> str:
    """HMAC-SHA256 (hex) тіла маніфесту. Спільне для перевірки (клієнт) і публікації (підтримка).
    secret: per-client секрет (None = секрет цієї збірки). Клієнт перевіряє своїм секретом
    зі своєї .env.local; публікатор підписує секретом клієнта з CRM."""
    key = _secret() if secret is None else (secret.encode("utf-8") if isinstance(secret, str) else secret)
    return hmac.new(key, _canon(manifest_body), hashlib.sha256).hexdigest()


def _verify_sig(manifest: dict) -> bool:
    sig = str(manifest.get("sig") or "")
    if not sig:
        return False
    return hmac.compare_digest(sig, manifest_sig(manifest))


# ── Адреса маніфесту (per-client за хешем імені) ─────────────────────────────
def _customer() -> str:
    try:
        import license as licensing
        return licensing.status().get("customer", "") or ""
    except Exception:
        return ""


def manifest_url() -> str:
    """Прямий UPDATE_URL (override) АБО per-client: <UPDATE_BASE_URL>/<hash(customer)>.json."""
    if config.UPDATE_URL:
        return config.UPDATE_URL
    if config.UPDATE_BASE_URL:
        h = hashlib.sha256((_customer() or "anon").encode("utf-8")).hexdigest()[:16]
        return f"{config.UPDATE_BASE_URL}/{h}.json"
    return ""


# ── Низькорівневе завантаження (https / file) ────────────────────────────────
def _fetch_bytes(url: str, timeout: int = 30, headers: dict = None) -> bytes:
    req = urllib.request.Request(url, headers=headers or {})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read()


def _fetch_json(url: str, timeout: int = 12) -> dict:
    headers = {"Accept": "application/json", "User-Agent": f"SensFlow/{current_version()}"}
    if config.LICENSE_KEY:
        headers["x-license-key"] = config.LICENSE_KEY
    return json.loads(_fetch_bytes(url, timeout=timeout, headers=headers).decode("utf-8"))


# ── Перевірка наявності оновлень ─────────────────────────────────────────────
def check_for_update(timeout: int = 12) -> dict:
    """Стан без жодних змін у системі:
    {current, latest, available, gated, message, updates:[...], notes}."""
    cur = current_version()
    base = {"current": cur, "latest": cur, "available": False, "gated": False,
            "message": "", "updates": [], "notes": ""}

    # Гейт підписки
    import license as licensing
    lic = licensing.status()
    if not lic.get("valid"):
        base["gated"] = True
        base["message"] = ("Оновлення доступні за активною підпискою. "
                           "Активуйте ліцензію (Про систему → Ліцензія) або зверніться до підтримки.")
        if config.LICENSE_KEY:
            base["message"] = (f"Оновлення недоступні: ліцензія — {lic.get('reason','недійсна')}. "
                               "Зверніться до підтримки SensFlow.")
        return base

    url = manifest_url()
    if not url:
        base["message"] = "Сервер оновлень не налаштований (UPDATE_BASE_URL/UPDATE_URL)."
        return base

    try:
        manifest = _fetch_json(url, timeout=timeout)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            base["gated"] = True
            base["message"] = "Підписку не підтверджено. Зверніться до підтримки SensFlow."
        elif e.code == 404:
            base["message"] = "У вас найновіша версія."
        else:
            base["message"] = f"Не вдалося перевірити оновлення (HTTP {e.code})."
        return base
    except Exception:
        base["message"] = "Сервер оновлень недоступний. Спробуйте пізніше."
        return base

    if not _verify_sig(manifest):
        base["message"] = "Підпис маніфесту оновлень недійсний — застосування заблоковано (безпека)."
        return base

    journal = _journal_load()
    applied = set(journal.get("applied", []))
    ups = [u for u in (manifest.get("updates") or []) if isinstance(u, dict) and u.get("id")]
    new = [u for u in ups if u["id"] not in applied]
    new.sort(key=lambda u: _parse(u.get("version")))

    base["latest"] = str(manifest.get("version") or cur)
    base["notes"] = str(manifest.get("notes") or "")
    base["updates"] = new
    base["available"] = bool(new)
    base["message"] = (f"Доступно оновлень: {len(new)}." if new else "У вас найновіша версія.")
    return base


# ── Безпечне застосування ────────────────────────────────────────────────────
def _is_protected(rel: str) -> bool:
    rel = rel.replace("\\", "/")
    if rel.startswith("/") or ".." in rel.split("/"):
        return True  # захист від виходу за межі
    if any(rel == p.rstrip("/") or rel.startswith(p) for p in _PROTECTED):
        return True
    # Живий стан клієнта не затирається НІКОЛИ, навіть якщо ми поклали свій у бандл.
    if _state_files is not None:
        try:
            return bool(_state_files.is_state(rel))
        except Exception:
            return False
    return False


def _post_check(engine_dir: Path) -> list:
    """py_compile усіх .py движка. Повертає список битих (порожній = ок)."""
    import py_compile
    bad = []
    for f in engine_dir.rglob("*.py"):
        if "__pycache__" in f.parts:
            continue
        try:
            py_compile.compile(str(f), doraise=True)
        except Exception:
            bad.append(str(f.relative_to(engine_dir)))
    return bad


def _apply_one(u: dict, root: Path) -> dict:
    """Застосовує одне оновлення з бекапом і відкатом. root — корінь платформи."""
    uid = u.get("id")
    res = {"id": uid, "version": u.get("version"), "ok": False, "message": ""}
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_dir = root / "_backups" / f"{ts}_{uid}"
    overwritten, added = [], []
    tmpzip = None
    try:
        # 1) завантажити бандл
        raw = _fetch_bytes(str(u.get("bundle_url") or ""), timeout=120)
        # 2) SHA-256
        got = hashlib.sha256(raw).hexdigest()
        want = str(u.get("sha256") or "").lower()
        if want and got != want:
            res["message"] = "SHA-256 бандла не збігається — застосування скасовано."
            return res
        tmpzip = Path(tempfile.gettempdir()) / f"sf_update_{uid}.zip"
        tmpzip.write_bytes(raw)

        with zipfile.ZipFile(tmpzip) as z:
            members = [m for m in z.namelist() if not m.endswith("/")]
            # 3) бекап того, що перезапишемо; реєстрація нових файлів
            backup_dir.mkdir(parents=True, exist_ok=True)
            for m in members:
                if _is_protected(m):
                    continue
                target = root / m
                if target.exists():
                    dst = backup_dir / m
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, dst)
                    overwritten.append(m)
                else:
                    added.append(m)
            (backup_dir / "_changeset.json").write_text(
                json.dumps({"overwritten": overwritten, "added": added}, ensure_ascii=False),
                encoding="utf-8")
            # 4) розпакувати поверх (крім захищеного)
            for m in members:
                if _is_protected(m):
                    continue
                target = root / m
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(m) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out)

        # 5) пост-перевірка
        bad = _post_check(root / "orchestrator_py")
        if bad:
            _rollback(root, backup_dir, overwritten, added)
            res["message"] = f"Пост-перевірка не пройшла ({len(bad)} битих файлів) — відкат виконано, лишились на старій версії."
            return res

        res["ok"] = True
        res["message"] = f"Оновлення {u.get('version')} застосовано."
        return res
    except Exception as e:
        # будь-який збій → відкат
        try:
            _rollback(root, backup_dir, overwritten, added)
        except Exception:
            pass
        res["message"] = f"Збій застосування ({e}) — відкат виконано."
        return res
    finally:
        try:
            if tmpzip and tmpzip.exists():
                tmpzip.unlink()
        except Exception:
            pass


def _rollback(root: Path, backup_dir: Path, overwritten: list, added: list):
    """Відновлює перезаписані файли з бекапу й видаляє щойно додані."""
    for m in overwritten:
        src = backup_dir / m
        if src.exists():
            dst = root / m
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
    for m in added:
        try:
            (root / m).unlink()
        except Exception:
            pass


def apply_updates(ids=None, root: Path = None) -> dict:
    """Застосовує нові оновлення (всі або зі списку ids). root за замовчуванням — корінь платформи.
    Повертає {ok, applied:[...], failed:[...], message, restart_suggested}."""
    root = Path(root) if root else config.PLATFORM_ROOT
    state = check_for_update()
    if state.get("gated"):
        return {"ok": False, "applied": [], "failed": [], "message": state.get("message", "Немає доступу")}
    todo = [u for u in state.get("updates", []) if (ids is None or u.get("id") in set(ids))]
    if not todo:
        return {"ok": True, "applied": [], "failed": [], "message": "Немає чого застосовувати."}

    applied, failed = [], []
    journal = _journal_load()
    for u in todo:
        r = _apply_one(u, root)
        if r["ok"]:
            applied.append(r)
            if u.get("id") not in journal["applied"]:
                journal["applied"].append(u.get("id"))
            journal["version"] = str(u.get("version") or journal.get("version"))
            _journal_save(journal)
        else:
            failed.append(r)
            break  # зупиняємось на першому збої (вже відкочено)

    ok = bool(applied) and not failed
    msg = (f"Застосовано {len(applied)} оновлень." if applied else "")
    if failed:
        msg = (msg + " " + failed[-1]["message"]).strip()
    return {"ok": ok, "applied": applied, "failed": failed,
            "message": msg or "Готово.", "restart_suggested": bool(applied)}


# Фаза 1 — ядро механіки оновлень (per-client маніфест, підпис, apply+rollback+журнал).

