# -*- coding: utf-8 -*-
"""
tender_docs.py — ПРОЧИТАТИ ТЕНДЕРНУ ДОКУМЕНТАЦІЮ ЗАМОВНИКА, 30.07.2026.

НАВІЩО (живий випадок 30.07.2026). Оркестратор пообіцяв клієнту: «відкриємо
тендер UA-2026-07-25-000428-a, витягнемо вимоги з тендерної документації
замовника і складемо перелік документів під нього». Клієнт погодився. А вміння
читати файли документації в платформі НЕ БУЛО — і документ чесно написав
«мені не було передано вміст тендерної документації». Обіцянка вже прозвучала.
Тому тут не новий шар, а СКЛЕЙКА того, що вже є:

    номер UA-…  ->  tender_legal.load_card  (свій резолвер писати заборонено)
    картка      ->  tender_source_ua.documents  (перелік файлів)
    файл        ->  netfetch.get_bytes          (ЄДИНЕ вікно назовні, ворота егресу)
    текст       ->  filetext.extract_text       (pdf/docx/xlsx/csv, стеля MAX_CHARS)

ГОЛОВНЕ ПРАВИЛО — FAIL-CLOSED. Не дістали номер, картку чи перелік файлів ->
ok=False і ПРИЧИНА СЛОВАМИ. Порожній перелік — це НЕ помилка: замовник міг
нічого не оприлюднити, і сказати про це чесно важливіше, ніж вдати, що шукали
погано. Формат, який ми не читаємо (скан-картинка, архів), НЕ вигадуємо —
він іде в `skipped` з причиною, а `complete` стає False.

Нічого не кешуємо і нічого не пишемо на диск: документація тендера змінюється
(замовник викладає нові версії), і вчорашня копія — це тихо застаріла правда.
"""

# ⭐ 04.08.2026. КОНТЕЙНЕРИ ЕЛЕКТРОННОГО ПІДПИСУ — НЕ ДОКУМЕНТИ.
# Замовник кладе їх поруч із документацією (`sign.p7s` і подібні). Читати в них
# нічого: підпис засвідчує файл, а не описує вимоги. Якщо рахувати їх «непрочитаними»,
# кожен правовий висновок нестиме фальшиве «це не вся документація».
_SIGNATURE_EXT = {".p7s", ".p7b", ".p7m", ".sig", ".asics", ".asice", ".cer", ".crt", ".pkcs7"}

MAX_FILES_DEFAULT = 6          # стеля файлів за один прогін (контекст не гумовий)
_UA = "AI-Orchestrator/1.0 (SensFlow tender docs)"
_TIMEOUT = 60                  # файли важчі за json — час більший, ніж у картки

# Формати, які ми ВМІЄМО перетворити на текст (дивись filetext.extract_text).
# Список ДОЗВОЛЕНИХ, а не заборонених, свідомо: це fail-closed. Невідоме
# розширення краще чесно пропустити, ніж завантажити мегабайти і віддати сміття.
# .doc/.xls (старий Word/Excel) сюди НЕ входять — filetext їх не розбирає.
_READABLE_EXT = {
    ".pdf", ".docx", ".xlsx", ".xlsm", ".csv", ".tsv",
    ".txt", ".md", ".json", ".xml", ".html", ".yaml", ".yml", ".log",
}

# Тип із поля `format` (mime) -> розширення. Потрібно, коли в назві файлу
# розширення немає взагалі — таке в Прозорро трапляється.
_MIME_EXT = {
    "application/pdf": ".pdf",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": ".docx",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": ".xlsx",
    "application/vnd.ms-excel": ".xls",
    "application/msword": ".doc",
    "text/plain": ".txt",
    "text/csv": ".csv",
    "text/html": ".html",
    "application/json": ".json",
    "application/xml": ".xml",
    "text/xml": ".xml",
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/tiff": ".tif",
    "application/zip": ".zip",
}


def _ext_of(title, fmt):
    """Розширення файлу: спершу з назви, потім із mime-типу. '' — не визначили."""
    name = (title or "").strip()
    if "." in name:
        ext = "." + name.rsplit(".", 1)[-1].lower()
        if len(ext) <= 6:                    # «.pdf» так, «.документація» ні
            return ext
    return _MIME_EXT.get((fmt or "").strip().lower(), "")


def _stamp(doc):
    """Момент життя документа для порівняння версій. Дати в Прозорро — ISO,
    тому звичайне порівняння рядків працює як порівняння часу."""
    d = doc or {}
    return (d.get("datePublished") or d.get("dateModified") or "")


def _latest_only(docs):
    """Лишити ЛИШЕ останні версії документів. -> (список, скільки прибрано).

    ЯК ВЕРСІЇ ВІДРІЗНЯЮТЬСЯ. У Прозорро документ версіонується: нова редакція
    приходить ОКРЕМИМ записом із тим самим `id` і свіжішою `datePublished`.
    Певності, що так буде завжди (і що субресурс не віддасть кожну версію під
    своїм `id`), у нас НЕМАЄ — живою розвідкою це не перевірено. Тому робимо
    два проходи, як велить обережність:
      1) за `id` — беремо найсвіжіший запис у кожній групі;
      2) за `title` — те саме ще раз, бо ЯКЩО версії мають різні `id`, їх
         усе одно тримає купи однакова назва.
    Ціна другого проходу: два РІЗНІ документи з ОДНАКОВОЮ назвою зіллються в
    один. У Прозорро однакова назва майже завжди й означає версії того самого
    файлу, а показати стару редакцію вимог як чинну — дорожче за цю втрату.
    Скільки записів прибрано — повертаємо числом, щоб звуження було ВИДИМЕ.
    """
    def _fold(items, key_of):
        best, order = {}, []
        for d in items:
            key = key_of(d)
            if key not in best:
                best[key] = d
                order.append(key)
            elif _stamp(d) >= _stamp(best[key]):
                best[key] = d
        return [best[k] for k in order]

    src = [d for d in (docs or []) if isinstance(d, dict)]
    by_id = _fold(src, lambda d: (d.get("id") or "").strip()
                  or "назва:" + (d.get("title") or "").strip().lower())
    by_title = _fold(by_id, lambda d: (d.get("title") or "").strip().lower()
                     or "ід:" + (d.get("id") or "").strip())
    return by_title, len(src) - len(by_title)


def _is_placeholder(text):
    """filetext на нечитабельному файлі віддає не текст, а помітку в дужках
    («[pdf без текстового шару…]», «[формат .x не підтримується…]»). Прийняти
    її за вміст документа означало б показати клієнту порожнечу як вимоги."""
    t = (text or "").strip()
    return bool(t) and t.startswith("[") and t.endswith("]") and "\n" not in t


def _fail(tender_id, reason, uuid=""):
    """Один вигляд чесного стопу — щоб причина ніде не загубилась."""
    return {"ok": False, "tender_id": (tender_id or "").strip(), "uuid": uuid,
            "files": [], "skipped": [], "reason": reason, "complete": False}


def read_docs(tender_id, max_files=MAX_FILES_DEFAULT):
    """Номер тендера UA-… -> тексти файлів тендерної документації замовника.

    -> {ok, tender_id, uuid, files, skipped, reason, complete}
       files    — [{title, format, url, chars, text}] у порядку джерела;
       skipped  — [{title, why}]: формат не читаємо / файл не взявся / ліміт;
       complete — False, якщо хоч щось у skipped (ми бачили НЕ ВСЕ).

    Мережа — тільки через netfetch (ворота егресу). Кешу і запису на диск немає.
    """
    tid = (tender_id or "").strip()
    if not tid:
        return _fail(tid, "не сказано, який тендер читати: потрібен номер UA-…")
    try:
        max_files = max(1, int(max_files))
    except (TypeError, ValueError):
        max_files = MAX_FILES_DEFAULT

    # Імпорти всередині функції: реєстр робіт тримає модулі лінивими, а
    # tender_legal/джерело не мають знати одне про одного через кільце імпортів.
    try:
        import netfetch
        import filetext
        import tender_legal
        import tender_source_ua as src
    except Exception as e:
        return _fail(tid, "не завантажились складники читання документації (%s: %s)"
                          % (type(e).__name__, e))

    # Номер -> картка. Свого резолвера НЕ пишемо: load_card уже ходить
    # tender_source_ua.index_uuid (міст) і .resolve (пошук у джерелі).
    try:
        card = tender_legal.load_card(tid)
    except Exception as e:
        return _fail(tid, "джерело тендерів не відповіло (%s: %s)" % (type(e).__name__, e))
    if not isinstance(card, dict) or not card:
        return _fail(tid, "не вдалося дістати картку тендера %s: джерело не знає цього "
                          "номера або зараз недоступне. Перевірте номер або спробуйте "
                          "пізніше — вигадувати вміст документації я не буду" % tid)

    uuid = str(card.get("id") or "").strip()

    # Перелік файлів: основний шлях — прямо з картки (вона повна), запасний —
    # субресурс /documents (його вмикає сам tender_source_ua.documents).
    try:
        raw_docs = src.documents(uuid, card=card)
    except Exception as e:
        return _fail(tid, "перелік файлів документації не прочитався (%s: %s)"
                          % (type(e).__name__, e), uuid=uuid)
    if not isinstance(raw_docs, list):
        return _fail(tid, "джерело віддало перелік файлів у незрозумілому вигляді", uuid=uuid)

    if not raw_docs:
        # Порожньо — це ВІДПОВІДЬ, а не помилка. Замовник міг нічого не додати.
        return {"ok": True, "tender_id": tid, "uuid": uuid, "files": [], "skipped": [],
                "reason": "документів не додано", "complete": True}

    fresh, dropped_versions = _latest_only(raw_docs)

    files, skipped, signatures = [], [], []
    for d in fresh:
        title = (d.get("title") or "").strip() or "без назви"
        url = (d.get("url") or "").strip()
        fmt = (d.get("format") or "").strip()
        if len(files) >= max_files:
            skipped.append({"title": title,
                            "why": "ліміт: за один раз читаємо не більше %d файлів" % max_files})
            continue
        if not url:
            skipped.append({"title": title, "why": "у записі немає посилання на файл"})
            continue
        ext = _ext_of(title, fmt)
        if ext in _SIGNATURE_EXT:
            # ⭐ 04.08.2026 (живий прогін на UA-2026-08-04-003201-A). НЕ ВСЯКИЙ
            # ФАЙЛ У КАРТЦІ — ДОКУМЕНТ. Замовник докладає до документації
            # контейнер електронного підпису (`sign.p7s`). Змісту в ньому немає:
            # він засвідчує підпис, а не описує вимоги. Раніше він падав у
            # «пропущено», і кожен правовий висновок ніс застереження «це не вся
            # документація» — тобто клієнт платив сумнівом за файл, у якому
            # нічого читати. Тепер підпис відомий як підпис і дірою не рахується.
            signatures.append({"title": title, "format": fmt or ext, "url": url})
            continue
        if ext not in _READABLE_EXT:
            # Скани-картинки, архіви, старі .doc/.xls. Вигадувати їхній вміст
            # заборонено: краще чесно назвати файл, який ми не прочитали.
            skipped.append({"title": title,
                            "why": "формат %s ми читати не вміємо (скан-картинка, архів "
                                   "або старий формат) — вміст не вигадуємо"
                                   % (ext or fmt or "невідомий")})
            continue
        try:
            raw = netfetch.get_bytes(url, ua=_UA, timeout=_TIMEOUT)
        except Exception as e:
            skipped.append({"title": title,
                            "why": "файл не завантажився (%s: %s)" % (type(e).__name__, e)})
            continue
        # filetext дивиться на розширення В НАЗВІ — якщо його там немає,
        # підставляємо те, що дало поле format, інакше pdf піде «як текст».
        name = title if "." in title else (title + ext)
        try:
            text = filetext.extract_text(name, raw) or ""
        except Exception as e:
            skipped.append({"title": title,
                            "why": "текст із файлу не витягся (%s: %s)" % (type(e).__name__, e)})
            continue
        if not text.strip():
            skipped.append({"title": title, "why": "файл порожній — тексту в ньому немає"})
            continue
        if _is_placeholder(text):
            skipped.append({"title": title, "why": text.strip().strip("[]")})
            continue
        files.append({"title": title, "format": fmt or ext, "url": url,
                      "chars": len(text), "text": text})

    bits = ["прочитано файлів: %d" % len(files)]
    if dropped_versions:
        bits.append("старих версій документів прибрано: %d" % dropped_versions)
    if signatures:
        bits.append("файлів електронного підпису (без змісту): %d" % len(signatures))
    if skipped:
        bits.append("пропущено файлів: %d (кожен із причиною)" % len(skipped))
    if not files and skipped:
        bits.append("тексту вимог у мене НЕМАЄ — жоден файл не прочитався")
    return {"ok": True, "tender_id": tid, "uuid": uuid, "files": files,
            "skipped": skipped, "signatures": signatures,
            "reason": "; ".join(bits), "complete": not skipped}


def read_docs_job(tender_id="", max_files=MAX_FILES_DEFAULT, **_ignored):
    """Вхід для реєстру тихих задач (data_jobs) -> {status, summary}.

    Номер тендера приїздить ЧЕРЕЗ kwargs: `data_jobs.run(job, **kwargs)` уже
    передає їх сюди. Планувальник кличе run(job) БЕЗ аргументів — тому в
    tender_id стоїть порожній усталений, і робота тоді чесно каже, чого бракує,
    а не мовчить і не вигадує номер. Зайві kwargs ковтаємо (**_ignored), щоб
    новий виклик звідкись іще не завалив прогін.
    """
    tid = (tender_id or "").strip()
    if not tid:
        return {"status": "failed",
                "summary": "не сказано, ЯКИЙ тендер читати. Потрібен номер UA-…: "
                           "виклич цю роботу з tender_id=\"UA-РРРР-ММ-ДД-NNNNNN-a\". "
                           "Сама я номер не вигадую."}
    res = read_docs(tid, max_files=max_files)
    if not res.get("ok"):
        return {"status": "failed", "summary": "%s — %s" % (tid, res.get("reason") or "причина невідома")}

    files, skipped = res.get("files") or [], res.get("skipped") or []
    lines = ["Тендер %s — тендерна документація замовника (%s)." % (tid, res.get("reason") or "")]
    if not files and not skipped:
        lines.append("Замовник не оприлюднив жодного файлу документації. "
                     "Вимог узяти нізвідки — так і скажи людині.")
    # ⚠ ТЕКСТ ІДЕ ЦІЛКОМ. Саме через його брак документ 30.07.2026 написав
    # «мені не було передано вміст тендерної документації». Обсяг уже обмежений
    # двічі: стеля файлів (max_files) і стеля символів на файл (filetext.MAX_CHARS),
    # і кожне обрізання filetext позначає в самому тексті — тихого урізання немає.
    for f in files:
        lines.append("\n=== ДОКУМЕНТ: %s (%d символів) ===\n%s"
                     % (f.get("title"), f.get("chars") or 0, f.get("text") or ""))
    for s in skipped:
        lines.append("• НЕ прочитано: %s — %s" % (s.get("title"), s.get("why")))
    if not res.get("complete"):
        lines.append("Це НЕ повна картина: частину файлів прочитати не вдалося — "
                     "не видавай перелік вимог за вичерпний, назви пропущені файли.")
    return {"status": "completed", "summary": "\n".join(lines)}
