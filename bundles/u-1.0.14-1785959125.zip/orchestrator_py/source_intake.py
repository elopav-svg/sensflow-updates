# -*- coding: utf-8 -*-
"""source_intake.py — ПРИЙОМ ДЖЕРЕЛА: людина вказала — платформа пішла і взяла.

⭐⭐⭐ ЖИВИЙ ВИПАДОК 04.08.2026. Клієнт надіслав посилання на картку закупівлі й
попросив підстави для скарги. Платформа не зробила НІЧОГО: посилання для неї
було просто адресою, а робота, яка вміє взяти картку і документи з Прозорро,
чекала, поки її покличуть на імʼя з номером у параметрі. Андрій: «чому
оркестратор не пройшов по посиланню, не витягнув документи і не організував
юридичний аналіз».

ЗВІДКИ ЦЕЙ КРОК СТОЇТЬ ПЕРЕД МОЗКОМ, А НЕ В ПРОМПТІ.
    Прохання до моделі «якщо бачиш номер — поклич роботу» — це прохання, а не
    ворота: воно провалюється рівно тоді, коли модель поспішає. Тому матеріал
    береться ДЕТЕРМІНОВАНО, до того як мозок почав обирати систему. Мозок
    отримує задачу вже З ДОКУМЕНТАМИ на руках і думає про суть, а не про те,
    яку роботу викликати першою.

ЩО САМЕ РОБИТЬ.
    Знаходить у задачі номер закупівлі (у тексті або всередині посилання на
    БУДЬ-ЯКИЙ майданчик — назв майданчиків ми свідомо не вчимо), іде до
    ПЕРШОДЖЕРЕЛА (Прозорро) і кладе картку та документи замовника в матеріали
    задачі. Прогін безкоштовний: модель тут не питається жодного разу.

ЧОГО НЕ РОБИТЬ.
    Не тлумачить документи, не робить висновків, не обирає систему. Не мовчить
    при невдачі: якщо джерело не відповіло — так і пише в матеріалах, щоб
    система не вирішила, ніби документів просто не існує.
"""
import tender_ref

MAX_FILES = 12
MAX_CHARS = 60000          # межа матеріалу, щоб не роздути вартість прогону

HEADER = "## ДЖЕРЕЛО, ВЗЯТЕ ПЛАТФОРМОЮ ЗА ВКАЗІВКОЮ ЛЮДИНИ"


def refs_in(message, files_context="") -> list:
    """Номери закупівель, на які вказала людина. Порядок збережено."""
    return tender_ref.find_all("%s\n%s" % (message or "", files_context or ""))


def fetch_tender(tid: str, max_files: int = MAX_FILES) -> dict:
    """Картка + документи замовника з Прозорро. -> {ok, tender_id, text, note}."""
    tid = tender_ref.normalize(tid)
    if not tid:
        return {"ok": False, "tender_id": "", "text": "", "note": "не схоже на номер закупівлі"}
    try:
        import tender_docs
    except Exception as e:
        return {"ok": False, "tender_id": tid, "text": "",
                "note": "модуль читання документації недоступний (%s)" % type(e).__name__}
    try:
        res = tender_docs.read_docs(tid, max_files=max_files)
    except Exception as e:
        return {"ok": False, "tender_id": tid, "text": "",
                "note": "джерело не відповіло (%s: %s)" % (type(e).__name__, e)}
    if not isinstance(res, dict) or not res.get("ok"):
        note = (res or {}).get("reason") or "джерело не віддало картку"
        return {"ok": False, "tender_id": tid, "text": "", "note": str(note)}

    parts = []
    for f in (res.get("files") or []):
        name = str(f.get("title") or f.get("filename") or "документ")
        body = str(f.get("text") or "").strip()
        if body:
            parts.append("### %s\n%s" % (name, body))
    skipped = res.get("skipped") or []
    gaps = []
    for sk in skipped:
        if isinstance(sk, dict):
            gaps.append("%s — %s" % (sk.get("title") or "документ",
                                     sk.get("why") or "причина невідома"))
    signs = [str((sg or {}).get("title") or "підпис")
             for sg in (res.get("signatures") or []) if isinstance(sg, dict)]
    return {"ok": True, "tender_id": tid, "uuid": res.get("uuid") or "",
            "text": "\n\n".join(parts), "files": len(parts), "skipped": len(skipped),
            "gaps": gaps, "signatures": signs,
            "complete": bool(res.get("complete", True)), "note": ""}


def collect(message, files_context="", max_refs: int = 2) -> str:
    """Матеріал для задачі або "" якщо вказівок на джерело немає.

    Невдача НЕ мовчить: вона потрапляє в матеріал окремим рядком, щоб система
    бачила межу свого знання, а не вважала, що документів не існує.
    """
    refs = refs_in(message, files_context)[:max_refs]
    if not refs:
        return ""
    blocks = []
    for tid in refs:
        got = fetch_tender(tid)
        if got.get("ok"):
            head = ("Закупівля %s — картка і документація замовника, взяті з Прозорро "
                    "(першоджерело) під час цього запиту. Файлів прочитано: %d."
                    % (got["tender_id"], got.get("files", 0)))
            # ⭐ ЧОГО САМЕ МИ НЕ БАЧИЛИ — НАЗВАТИ ПОІМЕННО.
            # Для правового висновку «прочитано 2 з 3» без назви третього — це
            # прихована діра: юрист не знає, про що мовчить, і клієнт теж.
            if not got.get("complete", True) or got.get("skipped"):
                head += ("\n\nУВАГА, ЦЕ НЕ ВСЯ ДОКУМЕНТАЦІЯ. Не прочитано файлів: %d. "
                         "Про їхній зміст висновків робити НЕ МОЖНА, і в результаті це "
                         "треба сказати людині прямо:\n%s"
                         % (got.get("skipped", 0),
                            "\n".join("  • " + g for g in (got.get("gaps") or []))
                            or "  • (назви невідомі)"))
            body = got.get("text") or "(перелік файлів порожній: замовник не додав документів)"
            blocks.append("%s\n\n%s" % (head, body))
        else:
            blocks.append("Закупівля %s: документи взяти НЕ ВДАЛОСЯ — %s. "
                          "Це межа знання, а не відсутність документів: висновків про "
                          "їх зміст робити не можна." % (tid, got.get("note") or "причина невідома"))
    out = "%s\n\n%s" % (HEADER, "\n\n---\n\n".join(blocks))
    return out[:MAX_CHARS]
