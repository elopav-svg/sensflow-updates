# -*- coding: utf-8 -*-
"""routing_card.py — ПАСПОРТ ПРИЗНАЧЕННЯ СИСТЕМИ: за чим мозок обирає маршрут.

⭐⭐⭐ КОРІНЬ 04.08.2026 (живий випадок у клієнта, двічі за день).
Запит «проаналізуй сайт як досвідчений маркетолог» + адреса двічі пішов у
«Бізнес-аналітику»: спершу вона написала звіт із памʼяті моделі (аудит сайту
американського бренду матраців Casper), потім — чесно, але шістьма етапами
консалтингу за ~$3 замість маркетингового аудиту сторінки.

ЧОМУ МОЗОК ОБИРАВ ТАК. Каталог, який він читає перед вибором, розповідав, ЯК
система влаштована всередині: «послідовний шестиетапний конвеєр», «4 агенти
передають артефакти через файлову систему», «цикл критик→стратег до вердикту».
Це технічний переказ пайплайну. Ніде не було сказано ДЛЯ ЧОГО систему брати,
ЩО подають на вхід, ЩО вийде і ЧОГО вона НЕ робить (поле «межі» — порожнє в усіх
22 системах). Виграє завжди той опис, який звучить найширше, — а не той, що
підходить. Спроба полагодити це позначкою в каталозі й наказом у промпті
провалилась наживо: правило, яке живе в промпті, — це прохання, а не ворота.

РІШЕННЯ (Андрій, 04.08.2026: «мені не потрібна релейна шафа, яка спрацьовує по
тригерах»). Заборон за ключовими ознаками не ставимо — вони лікують один запит,
а не клас. Натомість мозок отримує СТРУКТУРОВАНИЙ ПАСПОРТ кожної системи з
чотирьох полів і обирає, зіставляючи задачу зі ВХОДОМ і ВИХОДОМ:
    ДЛЯ ЯКИХ ЗАДАЧ · ЩО НА ВХОДІ · ЩО НА ВИХОДІ · ЧОГО НЕ РОБИТЬ

ОДИН ПИСАР. Паспорт складається з власного мозку системи (кореневий промпт +
паспорт ролей), лежить у теці системи (`.routing_card.json`, поруч із
`.orchestration_plan.json`) і має ВІДБИТОК джерела. Змінився мозок, опис чи ролі —
відбиток не збігається, паспорт вважається застарілим і в каталог НЕ йде. Похідне
значення на диску без відбитка = друга правда; тут її немає.

ГРОШІ. Складання паспорта — окрема обслуговна дія (`build_routing_cards.py`),
найдешевшою моделлю драбини, ОДИН раз на систему. У гарячому шляху чату паспорт
НІКОЛИ не будується: немає паспорта — каталог чесно каже про це, а не мовчить.
"""

import hashlib
import json

import config
import llm
import registry

CARD_FILE = ".routing_card.json"
FIELDS = ("for_tasks", "input", "output", "not_for")


def _brain_text(system: dict) -> str:
    """Кореневий промпт системи (той самий, що читає виконавець)."""
    try:
        root = registry.system_root(system)
        for name in ("CLAUDE.md", "PROMPT.md"):
            p = root / name
            if p.exists():
                return p.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        pass
    return ""


def fingerprint(system: dict) -> str:
    """Відбиток ДЖЕРЕЛА паспорта: імʼя, опис, ролі, кореневий промпт.
    Змінилось будь-що з цього — старий паспорт більше не дійсний."""
    roles = registry.get_roles(system) or {}
    parts = [
        str((system or {}).get("name") or ""),
        str((system or {}).get("description") or ""),
        json.dumps({k: sorted(((v or {}).get("tools") or {}).keys())
                    for k, v in sorted(roles.items())}, ensure_ascii=False, sort_keys=True),
        _brain_text(system)[:8000],
    ]
    return hashlib.md5("\n<>\n".join(parts).encode("utf-8")).hexdigest()[:16]


def _path(system: dict):
    return registry.system_root(system) / CARD_FILE


def load(system: dict) -> dict:
    """Дійсний паспорт або {} — якщо його немає чи джерело змінилось.
    НІКОЛИ не будує сам: гарячий шлях чату не витрачає гроші користувача."""
    try:
        p = _path(system)
        if not p.exists():
            return {}
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return {}
    if not isinstance(data, dict):
        return {}
    if data.get("fingerprint") != fingerprint(system):
        return {}          # джерело змінилось — паспорт застарів, у каталог не йде
    card = data.get("card") or {}
    if not isinstance(card, dict) or not card.get("input") or not card.get("output"):
        return {}
    return card


_SYS = (
    "Ти складаєш ПАСПОРТ ПРИЗНАЧЕННЯ мультиагентської системи для каталогу, за яким "
    "оркестратор обирає, кому віддати задачу користувача. Тебе цікавить НЕ будова "
    "системи (скільки агентів, як передають файли, чи є критик) — це в каталозі "
    "непотрібне. Тебе цікавить ЛИШЕ: для яких задач її брати, що подають на вхід, що "
    "вона віддає на виході і чого вона НЕ робить.\n"
    "Пиши простою мовою замовника, без маркетингу й без загальних слів на кшталт "
    "«комплексний аналіз» чи «повний цикл». Кожен рядок має допомагати ВІДРІЗНИТИ цю "
    "систему від сусідньої в каталозі.\n"
    "Поле not_for — це справжні межі: назви задачі, схожі на цю, які цій системі "
    "віддавати НЕ можна. Порожнім його лишати не можна.\n"
    'Поверни РІВНО ОДИН JSON: {"for_tasks":["",""],"input":"","output":"","not_for":["",""]}. '
    "for_tasks — 2-4 короткі типові задачі. input — що саме подають (напр. «адреса "
    "сторінки і мета», «сира ідея бізнесу», «вже наявні внутрішні дані»). output — що "
    "виходить на руки. not_for — 2-4 пункти."
)


def build(system: dict, model: str = None) -> dict:
    """Складає паспорт мозком системи і кладе поруч із нею. Повертає паспорт.
    Кидає виняток, якщо судження не вдалося — мовчазної порожнечі тут немає."""
    roles = registry.get_roles(system) or {}
    tools_by_role = {k: sorted(((v or {}).get("tools") or {}).keys()) for k, v in roles.items()}
    user = (
        f"НАЗВА: {system.get('name')}\n"
        f"ID: {system.get('id')}\n"
        f"ОПИС З РЕЄСТРУ: {system.get('description') or '—'}\n"
        f"РОЛІ ТА ЇХНІ ІНСТРУМЕНТИ: {json.dumps(tools_by_role, ensure_ascii=False)}\n"
        f"(page_read = вміє відкрити й розібрати сторінку за адресою; "
        f"web = живий пошук в інтернеті; calculator = рахує калькулятором)\n\n"
        f"КОРЕНЕВИЙ ПРОМПТ СИСТЕМИ (її власний мозок):\n{_brain_text(system)[:6000]}"
    )
    data = llm.judge_json(_SYS, user, model=model or config.worker_model(),
                          purpose="routing_card/%s" % system.get("id"))
    card = {
        "for_tasks": [str(x).strip() for x in (data.get("for_tasks") or []) if str(x).strip()][:4],
        "input": str(data.get("input") or "").strip(),
        "output": str(data.get("output") or "").strip(),
        "not_for": [str(x).strip() for x in (data.get("not_for") or []) if str(x).strip()][:4],
    }
    if not (card["input"] and card["output"] and card["for_tasks"] and card["not_for"]):
        raise ValueError("паспорт неповний: %s" % json.dumps(card, ensure_ascii=False))
    p = _path(system)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"fingerprint": fingerprint(system), "card": card},
                            ensure_ascii=False, indent=2), encoding="utf-8")
    return card


def render_lines(card: dict) -> list:
    """Паспорт у рядки каталогу мозку. Порожній паспорт → порожній список."""
    if not card:
        return []
    out = ["    для задач: " + "; ".join(card.get("for_tasks") or []),
           "    на вхід: " + str(card.get("input") or ""),
           "    на вихід: " + str(card.get("output") or "")]
    if card.get("not_for"):
        out.append("    НЕ для: " + "; ".join(card["not_for"]))
    return out
