# -*- coding: utf-8 -*-
"""
tender_legal_export.py — ВИКЛАСТИ базу звірених норм у базу знань юриста.

НАВІЩО. Система-юрист має власне правило: правові висновки — ЛИШЕ з
Database/Wiki, інтернетом не користуватись. Отже найнадійніший спосіб
не дати моделі вигадати строк — покласти їй у Wiki ФАЙЛ, зібраний кодом
із бази звірених норм, із цитатами й датами звірки.

ГОЛОВНЕ. Файл СКЛАДАЄТЬСЯ КОДОМ і перезаписується. Руками його не
правлять: єдине джерело — knowledge_packs\\tender_law\\regimes.json.

Запуск: python tender_legal_export.py
"""
import io
import os

import tender_legal

WIKI = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                    "generated_systems", "legal_assistant", "Database", "Wiki")
FILE_NAME = "ТЕНДЕРНІ_НОРМИ_звірені.md"

HEAD = """# ТЕНДЕРНІ НОРМИ — ЗВІРЕНІ З ПЕРШОДЖЕРЕЛОМ

> ⚠ ЦЕЙ ФАЙЛ СКЛАДАЄ КОД. Руками не правити — при наступному вивантаженні
> правки зникнуть. Джерело: база норм платформи.

## ЗАЛІЗНЕ ПРАВИЛО ДЛЯ ТЕБЕ, ЮРИСТЕ

1. Строк, право чи заборону в тендері ти називаєш ЛИШЕ тоді, коли знаєш
   ТИП ЗАКУПІВЛІ (режим) і цей режим є нижче в цьому файлі.
2. Немає режиму в цьому файлі — ти НЕ підставляєш «типові» правила і НЕ
   міркуєш за аналогією. Ти кажеш прямо: «тип закупівлі не встановлено
   (або норми для нього ще не звірені), тому строки назвати не можу».
3. Причина правила не теоретична: 27.07.2026 клієнт двічі отримав строки
   ЧУЖОЇ процедури, бо тип закупівлі ніхто не перевірив. Ціна помилки —
   готувати скаргу до органу, якого в цій процедурі не існує, і проґавити
   реальне вікно на дію.
4. Кожну норму цитуй разом із її статтею й датою звірки — так, як вона
   записана нижче.
"""


def render(pack=None):
    pack = pack or tender_legal.load_pack()
    out = [HEAD, ""]
    out.append("Оновлено: %s" % (pack.get("_updated") or "—"))
    out.append("")
    for key, entry in sorted(pack["regimes"].items()):
        out.append("## Режим: `%s` — %s" % (key, entry.get("label") or ""))
        out.append("")
        if not entry.get("verified"):
            out.append("**НЕ ЗВІРЕНО.** %s" % (entry.get("why_not_verified") or ""))
            out.append("")
            out.append("Для цього режиму строки НЕ називати.")
            out.append("")
            continue
        out.append("Правова основа: %s" % (entry.get("basis") or "—"))
        out.append("")
        out.append("| Що | Строк / правило | Норма | Дослівна цитата | Звірено |")
        out.append("|---|---|---|---|---|")
        for n in entry.get("norms") or []:
            out.append("| %s | %s | %s, %s | «%s» | %s |"
                       % (_cell(n.get("topic")), _cell(n.get("value")), _cell(n.get("act")),
                          _cell(n.get("ref")), _cell(n.get("quote")), _cell(n.get("checked_at"))))
        out.append("")
        if entry.get("not_available"):
            out.append("### Чого в цьому режимі НЕМАЄ")
            out.append("")
            for n in entry["not_available"]:
                out.append("- **%s — %s.** Чому: %s%s"
                           % (n.get("topic"), n.get("value"), n.get("why"),
                              (" Замість цього: " + n["instead"]) if n.get("instead") else ""))
            out.append("")
    out.append("## Режими, яких тут немає")
    out.append("")
    out.append(pack.get("_unverified_note") or "")
    out.append("")
    return "\n".join(out)


def export(folder=None, pack=None):
    folder = folder or WIKI
    if not os.path.isdir(folder):
        os.makedirs(folder)
    path = os.path.join(folder, FILE_NAME)
    with io.open(path, "w", encoding="utf-8") as fh:
        fh.write(render(pack=pack))
    return path


if __name__ == "__main__":
    p = export()
    print("Вивантажено: %s" % p)
    print("Розмір: %d байт" % os.path.getsize(p))


def _cell(v):
    """Тонкий виклик до ОДНОГО писаря клітинки (`artifacts.table_cell`).

    ⭐⭐⭐ 02.08.2026. Тут значення з джерела йшли в таблицю НАПРЯМУ. Рівно на
    цьому в архіві торгів імʼя переможця з переносами `\r` розірвало рядок і
    тихо забрало з .xlsx усе, що було нижче. Юридична таблиця — той самий клас:
    назва акта чи цитата з переносом зробила б те саме в документі клієнта.
    """
    try:
        import artifacts as _A
        return _A.table_cell(v)
    except Exception:
        s = ("" if v is None else str(v)).replace("|", "/")
        return " ".join(s.split()) or "—"
