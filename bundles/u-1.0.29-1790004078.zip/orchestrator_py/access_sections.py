# -*- coding: utf-8 -*-
"""access_sections.py — РЕЄСТР РОЗДІЛІВ ПЛАТФОРМИ (зміна 588, 16.09.2026).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ. Право в платформі мало рівно дві поділки —
«адміністратор» і «ніхто». 15.09.2026 у Каспера менеджер не зміг завести
контрагента: уся CRM — і читання, і запис — стояла в адмінському переліку, а
ролі «менеджер з продажу» не існувало. Обхід того дня (зробити всіх
адміністраторами правкою `accounts.json`) віддав кожному менеджеру ліцензію,
мережу, Telegram і будову карток.

⭐ РІШЕННЯ. Кожні адмінські двері дістають НАЗВУ РОЗДІЛУ. Розділ — це дозвіл у
тій самій матриці «роль × дозвіл», яка вже живе в `taskdesk_roles`: другого
писаря правди про повноваження не заводимо. Роль — названий набір прав, і
вішається вона на працівника АБО на підрозділ, як і раніше.

⛒ ПЕРЕЛІК ЯВНИЙ, БЕЗ ПРАВИЛ ЗА ПРЕФІКСОМ. Спокуса написати «усе, що
починається з /api/crm/, — це CRM» економить рядки й коштує класу: двері,
дописані завтра під тим самим префіксом, мовчки дістали б чужий розділ, і
сторож цього не побачив би. Тому кожні двері названі рукою, а проба
(`sections_access_test.py`) звіряє реєстр із переліками сервера в обидва боки:
двері без розділу — діра, розділ без дверей — брехня.

⛒ ЧОГО ТУТ НЕМАЄ. Тут немає видимості сутностей («лише свої / свої +
підрозділ / усі») — це ДРУГА вісь і другий клас вад, вона живе окремо. І тут
немає меню: право судиться на вході в сервер, а не малюванням кнопок.
"""

# ─────────────────────────────── РОЗДІЛИ ───────────────────────────────────
SEC_CRM = "sec_crm"
SEC_GOODS = "sec_goods"
SEC_FILES = "sec_files"
SEC_CARDS = "sec_cards"
SEC_SETTINGS = "sec_settings"
SEC_AUTOMATIONS = "sec_automations"
SEC_LICENSE = "sec_license"
SEC_NETWORK = "sec_network"
SEC_TELEGRAM = "sec_telegram"
SEC_SUPPORT = "sec_support"
SEC_UPDATE = "sec_update"
SEC_TENDER = "sec_tender"
# ⭐ 616: магазин — це ГРОШІ компанії, тому окремий розділ, а не
# «десь у налаштуваннях». Право замовляти в розробника дають тому,
# хто за це платить, а не кожному, хто має доступ до платформи.
SEC_SHOP = "sec_shop"

# ⛒ Назви — словами людини, а не іменами файлів: цей перелік бачить керівник
# на екрані прав, і «sec_crm» йому нічого не каже.
SECTIONS = [
    {"id": SEC_CRM, "section": "Розділи платформи",
     "name": "Клієнти, угоди й воронка (CRM)"},
    {"id": SEC_GOODS, "section": "Розділи платформи",
     "name": "Товари і послуги"},
    {"id": SEC_FILES, "section": "Розділи платформи",
     "name": "Сховище файлів"},
    {"id": SEC_CARDS, "section": "Розділи платформи",
     "name": "Будова карток"},
    {"id": SEC_TENDER, "section": "Розділи платформи",
     "name": "Розбір тендерів"},
    {"id": SEC_SHOP, "section": "Розділи платформи",
     "name": "Магазин і замовлення розробнику"},
    {"id": SEC_AUTOMATIONS, "section": "Обслуговування",
     "name": "Автоматизації й розклад"},
    {"id": SEC_SETTINGS, "section": "Обслуговування",
     "name": "Ключі API й налаштування моделей"},
    {"id": SEC_TELEGRAM, "section": "Обслуговування",
     "name": "Telegram-бот"},
    {"id": SEC_NETWORK, "section": "Обслуговування",
     "name": "Мережа й сертифікат офісу"},
    {"id": SEC_LICENSE, "section": "Обслуговування",
     "name": "Ліцензія збірки"},
    {"id": SEC_UPDATE, "section": "Обслуговування",
     "name": "Оновлення платформи"},
    {"id": SEC_SUPPORT, "section": "Обслуговування",
     "name": "Звернення в підтримку"},
]
SECTION_IDS = tuple(s["id"] for s in SECTIONS)
SECTION_NAMES = {s["id"]: s["name"] for s in SECTIONS}


# ──────────────────────── ДВЕРІ НА ЧИТАННЯ (GET) ───────────────────────────
GET_SECTION = {
    "/api/crm/board": SEC_CRM,
    "/api/crm/card": SEC_CRM,
    "/api/crm/channels": SEC_CRM,
    "/api/crm/deal_card": SEC_CRM,
    "/api/crm/deal_docs": SEC_CRM,
    "/api/crm/deals": SEC_CRM,
    "/api/crm/entity_card": SEC_CRM,
    "/api/crm/inbox": SEC_CRM,
    "/api/crm/list": SEC_CRM,
    "/api/crm/parties": SEC_CRM,
    "/api/crm/party_card": SEC_CRM,
    "/api/crm/party_search": SEC_CRM,
    "/api/crm/pipeline": SEC_CRM,
    "/api/crm/products": SEC_CRM,
    "/api/crm/spread": SEC_CRM,

    "/api/goods/card": SEC_GOODS,
    "/api/goods/list": SEC_GOODS,
    "/goods": SEC_GOODS,
    "/goods.html": SEC_GOODS,

    "/api/shop/offer": SEC_SHOP,
    "/shop": SEC_SHOP,
    "/shop.html": SEC_SHOP,

    "/api/files/storage": SEC_FILES,
    "/files": SEC_FILES,
    "/files.html": SEC_FILES,

    "/cards": SEC_CARDS,
    "/cards.html": SEC_CARDS,

    "/setup": SEC_SETTINGS,
    "/setup.html": SEC_SETTINGS,

    "/telegram": SEC_TELEGRAM,
    "/telegram.html": SEC_TELEGRAM,
    # ⭐⭐⭐ 625 (21.09.2026): ДВЕРІ, ЯКІ 624 ЗАБУЛА НАЗВАТИ РОЗДІЛОМ.
    # 🩸 Екран автоматизацій і перелік людей бота стали під замок
    # адміністратора, але в реєстрі розділів їх не було — а реєстр і є той
    # єдиний суддя, за яким рівні доступу роздають права. Двері без розділу
    # — це право, якого не існує: власник не може ні дати його, ні забрати.
    "/automations": SEC_AUTOMATIONS,
    "/automations.html": SEC_AUTOMATIONS,
    "/api/automations/jobs": SEC_AUTOMATIONS,
    "/api/telegram/users": SEC_TELEGRAM,

    "/api/license/admin": SEC_LICENSE,
    "/api/support": SEC_SUPPORT,
    "/api/taskdesk/https/office_key": SEC_NETWORK,
    "/api/tender/diagnose": SEC_TENDER,
}

# ──────────────────────── ДВЕРІ НА ЗАПИС (POST) ────────────────────────────
POST_SECTION = {
    "/api/crm/bulk_apply": SEC_CRM,
    "/api/crm/bulk_preview": SEC_CRM,
    "/api/crm/comm": SEC_CRM,
    "/api/crm/contact": SEC_CRM,
    "/api/crm/contact_remove": SEC_CRM,
    "/api/crm/deal_action_done": SEC_CRM,
    "/api/crm/deal_amount": SEC_CRM,
    "/api/crm/deal_archive": SEC_CRM,
    "/api/crm/deal_attention": SEC_CRM,
    "/api/crm/deal_client": SEC_CRM,
    "/api/crm/deal_delete": SEC_CRM,
    "/api/crm/deal_doc_add": SEC_CRM,
    "/api/crm/deal_kp": SEC_CRM,        # ⭐ 613: КП з картки угоди
    "/api/crm/deal_doc_remove": SEC_CRM,
    "/api/crm/deal_doc_restate": SEC_CRM,   # ⭐ 625: нова редакція паперу
    "/api/crm/deal_item_add": SEC_CRM,
    "/api/crm/deal_item_remove": SEC_CRM,
    "/api/crm/deal_item_save": SEC_CRM,
    "/api/crm/deal_manager": SEC_CRM,
    "/api/crm/deal_mail": SEC_CRM,
    "/api/crm/deal_mail_sent": SEC_CRM,
    "/api/crm/deal_name": SEC_CRM,
    "/api/crm/deal_new": SEC_CRM,
    "/api/crm/deal_next_action": SEC_CRM,
    "/api/crm/deal_note": SEC_CRM,
    "/api/crm/deal_person": SEC_CRM,
    "/api/crm/deal_person_remove": SEC_CRM,
    "/api/crm/deal_stage": SEC_CRM,
    "/api/crm/dossier": SEC_CRM,
    "/api/crm/history": SEC_CRM,
    "/api/crm/inbound": SEC_CRM,
    "/api/crm/inbox_attach": SEC_CRM,
    "/api/crm/inbox_clear": SEC_CRM,
    "/api/crm/note": SEC_CRM,
    "/api/crm/party": SEC_CRM,
    "/api/crm/party_delete": SEC_CRM,
    "/api/crm/party_manager": SEC_CRM,
    "/api/crm/party_new": SEC_CRM,
    "/api/crm/pin": SEC_CRM,
    "/api/crm/profile": SEC_CRM,
    "/api/crm/promote": SEC_CRM,
    "/api/crm/spread_assign": SEC_CRM,
    "/api/crm/spread_drop": SEC_CRM,
    # ⭐ 618: «чий це лист» — та сама черга, той самий розділ.
    "/api/crm/spread_owner": SEC_CRM,
    "/api/crm/systems": SEC_CRM,

    "/api/goods/archive": SEC_GOODS,
    "/api/goods/new": SEC_GOODS,
    "/api/goods/save": SEC_GOODS,

    "/api/shop/quote": SEC_SHOP,
    "/api/shop/order": SEC_SHOP,
    "/api/shop/handed": SEC_SHOP,

    "/api/files/ack": SEC_FILES,
    "/api/files/recount": SEC_FILES,
    "/api/files/remove": SEC_FILES,

    "/api/cards/field_active": SEC_CARDS,
    "/api/cards/field_depends": SEC_CARDS,
    "/api/cards/field_choices": SEC_CARDS,
    "/api/cards/field_many": SEC_CARDS,
    "/api/cards/field_new": SEC_CARDS,
    "/api/cards/field_save": SEC_CARDS,

    "/api/automations/create": SEC_AUTOMATIONS,   # ⭐ 625: завести регулярну роботу
    "/api/automations/delete": SEC_AUTOMATIONS,
    "/api/automations/run_now": SEC_AUTOMATIONS,
    "/api/automations/schedule": SEC_AUTOMATIONS,
    "/api/automations/toggle": SEC_AUTOMATIONS,

    "/api/discover": SEC_SETTINGS,
    "/api/llm/config": SEC_SETTINGS,
    "/api/llm/demo": SEC_SETTINGS,
    "/api/llm/stealth": SEC_SETTINGS,
    "/api/setup": SEC_SETTINGS,
    "/api/setup/local": SEC_SETTINGS,
    "/api/system/status": SEC_SETTINGS,

    "/api/telegram/support_mode": SEC_TELEGRAM,
    "/api/telegram/tasks_token": SEC_TELEGRAM,
    "/api/telegram/token": SEC_TELEGRAM,

    "/api/taskdesk/https/action": SEC_NETWORK,
    "/api/taskdesk/network/action": SEC_NETWORK,

    "/api/license": SEC_LICENSE,
    "/api/support/log": SEC_SUPPORT,
    "/api/update/apply": SEC_UPDATE,
}


def section_of(method: str, path: str) -> str:
    """ЯКИЙ РОЗДІЛ ЗА ЦИМИ ДВЕРИМА. Порожньо — розділу немає.

    ⛒ Порожня відповідь НЕ означає «можна»: сервер, діставши її на дверях, що
    стоять в адмінському переліку, лишає старий замок — адміністратор і край.
    Тобто забута двері не відчиняються, а лишаються найсуворішими."""
    m = str(method or "").upper()
    p = str(path or "")
    if m == "GET":
        return GET_SECTION.get(p, "")
    if m == "POST":
        return POST_SECTION.get(p, "")
    return ""


def name_of(section_id: str) -> str:
    return SECTION_NAMES.get(str(section_id or ""), "")
