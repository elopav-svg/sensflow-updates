# -*- coding: utf-8 -*-
"""
legal_citation_check.py — ДЕТЕРМІНОВАНИЙ ЗВІРЯЧ ЦИТАТ (ворота проти фальшивої звірки).
Код не довіряє самозаяві моделі: знімає «звірено», сам тягне офіційну назву кожної
статті з ВРУ й ставить печатку. Незвірено/розбіжність → «перевірте» (fail-closed).
Загартовано 24.07.2026 живим прогоном: діапазони «N-M», дедуплікація, чистка таблиць.
"""
import re
import legal_source_ua

# ⭐ 28.07.2026. ДРУГИЙ ПИСАР УБИТО. Тут жив ВЛАСНИЙ список актів — лише 4 кодекси.
# Через це звіряч на «ст. 18 Закону про публічні закупівлі» казав «невідомий кодекс»,
# і неперевірена норма виходила до клієнта. Тепер джерело одне: реєстр актів у
# legal_source_ua (модуль-джерело) + усе, що вже стоїть у звіреній базі тендерних норм.
# Свій список тут лишається ТІЛЬКИ для коротких розмовних форм («цк», «кк»).
_SHORT_FORMS = {
    "цк": "435-15", "цку": "435-15", "цивільному кодексі": "435-15",
    "кк": "2341-14", "кзпп": "322-08", "ск": "2947-14",
    # 671: лише тут, окремим словом — як підрядок «пку» сидить у «закупку».
    "пку": "2755-17", "кпк": "4651-17",
    # 673: «ГК» — Господарський кодекс (нечинний з 28.08.2025; звіряч скаже це сам).
    "гк": "436-15",
}


def _build_cite_codes():
    """Єдиний реєстр: акти з legal_source_ua + акти зі звіреної бази норм."""
    out = dict(_SHORT_FORMS)
    try:
        import legal_source_ua as _src
        out.update(getattr(_src, "ACT_NREG", None) or getattr(_src, "CODE_NREG", {}))
    except Exception:
        pass
    try:
        import tender_legal as _tl
        pack = _tl.load_pack()
        for blk in (pack.get("regimes") or {}).values():
            for n in (blk.get("norms") or []):
                act, nreg = (n.get("act") or "").strip(), (n.get("nreg") or "").strip()
                if act and nreg:
                    out.setdefault(_norm(act), nreg)
    except Exception:
        pass
    # Ключі шукаються у ВЖЕ нормалізованому тексті (без дефісів і лапок),
    # тому нормалізуємо і самі ключі: «922-VIII» -> «922 viii».
    return {_norm(k): v for k, v in out.items() if _norm(k)}


CITE_CODES = None      # будується лениво: _norm() визначено нижче
_CODE_KEYS = ()


def _codes():
    global CITE_CODES, _CODE_KEYS
    if CITE_CODES is None:
        CITE_CODES = _build_cite_codes()
        _CODE_KEYS = sorted(CITE_CODES, key=len, reverse=True)
    return CITE_CODES


# ⛒⛒⛒ 672, 01.10.2026. АКТ СТАТТІ ВИЗНАЧАЄ ТЕКСТ, А НЕ ЛИШЕ НАШ ПЕРЕЛІК.
# 🩸 Консультація ФОП (14:52): закон у тексті БУВ — «Закон про ЄСВ № 2464-VI»,
# «Податковий кодекс України (далі — ПКУ)», «| ПКУ | п. 291.4 ст. 291 |», — а
# звіряч казав «акт не розпізнано», бо знав лише свій перелік і лише сусіда
# впритул. Андрій: «платформа з живим пошуком не може не звірити норму». Закон
# названо — отже його можна взяти з порталу Ради. Два ключі дає САМ ДОКУМЕНТ:
#   • номер закону -> реєстраційний номер порталу (правило скликань);
#   • скорочення «(далі — X)» одразу після назви чи номера відомого акта.
# Реєстр лишається для назв без номера; документ доповнює його, а не підміняє.
_ROMAN = {"III": 3, "IV": 4, "V": 5, "VI": 6, "VII": 7, "VIII": 8, "IX": 9,
          "XII": 12, "XIV": 14}
_LOOKALIKE = str.maketrans({"І": "I", "і": "I", "Х": "X", "х": "X"})
_ACT_NUM_RE = re.compile(r"(?<![\d/])(\d{1,5}(?:/\d{2})?)\s*[-‑–]\s*(ВР|вр|[IVXІХivxіх]{1,4})(?![\w])")
_ALIAS_RE = re.compile(r"\(\s*далі\s*[—–-]+\s*([^()\n]{1,40}?)\s*\)", re.IGNORECASE)


def nreg_from_number(num, mark):
    """«2464-VI» -> «2464-17». На порталі Ради номер закону скликань III–IX
    пишеться числом скликання +11 (IV -> 15, VIII -> 19, IX -> 20); XII і XIV —
    як є; «ВР» (1994–1998) — як є. Незнайома позначка — None: не вигадуємо."""
    n = str(num or "").strip()
    m = str(mark or "").strip()
    if not n or not m:
        return None
    if m.lower() == "вр":
        return "%s-вр" % n
    r = _ROMAN.get(m.translate(_LOOKALIKE).upper())
    if r is None:
        return None
    return "%s-%d" % (n, r + 11 if 3 <= r <= 9 else r)


def doc_act_keys(text) -> dict:
    """Ключі актів, які оголосив САМ документ: {нормалізований ключ: nreg}."""
    out = {}
    for m in _ACT_NUM_RE.finditer(text or ""):
        nreg = nreg_from_number(m.group(1), m.group(2))
        key = _norm(m.group(0))
        if nreg and key:
            out.setdefault(key, nreg)
    keys = dict(_codes())
    keys.update(out)
    order = sorted(keys, key=len, reverse=True)
    for m in _ALIAS_RE.finditer(text or ""):
        alias = _norm(m.group(1))
        if not alias or alias in keys:
            continue
        head = _norm((text or "")[max(0, m.start() - 250):m.start()].split("\n")[-1])
        for key in order:
            for pos in _find_key(head, key):
                if _BEFORE_TAIL_RE.match(head[pos + len(key):]):
                    for form in _alias_forms(alias):
                        out.setdefault(form, keys[key])
                    break
            if alias in out:
                break
    return out


def _alias_forms(alias):
    """«Закон 4015» оголошено, а пишуть «ст. 7 Закону 4015». Відмінюємо ПЕРШЕ
    слово скорочення за закінченням (не за переліком слів): приголосний —
    +у/+ом/+і; «-а» — и/і/ою. Решта слів скорочення — як оголошено."""
    words = alias.split()
    if len(words) < 2 or not words[0].isalpha():
        return [alias]
    w, tail = words[0], " ".join(words[1:])
    if w.endswith("а"):
        forms = [w, w[:-1] + "и", w[:-1] + "і", w[:-1] + "ою"]
    elif w[-1] not in "аеєиіїоуюяь":
        forms = [w, w + "у", w + "ом", w + "і"]
    else:
        forms = [w]
    return ["%s %s" % (f, tail) for f in forms]


def _keyset(extra=None):
    """(усі ключі, порядок від довшого) — реєстр плюс ключі документа."""
    codes = _codes()
    if not extra:
        return codes, _CODE_KEYS
    allk = dict(codes)
    for k, v in extra.items():
        allk.setdefault(k, v)
    return allk, sorted(allk, key=len, reverse=True)

_ART_RE = re.compile(r"(статт[іяювео]\w*|\bст\.?)\s*№?\s*(\d+)", re.IGNORECASE)
_HEAD_RE = re.compile(r"(?m)Стаття\s+(\d+)\.?\s*([^\n]{0,80})")
_GENERIC = {"товар", "товару", "товарів", "договір", "договору", "договором",
            "сторони", "сторін", "кодекс", "кодексу", "стаття", "статті", "положення",
            "право", "права", "щодо", "про", "та", "і", "й", "у", "в", "за"}


def _norm(s):
    s = (s or "").lower().replace("’", "'").replace("`", "'")
    s = re.sub(r"[«»\"'().,:;—–\-]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def _tokens(s):
    return [w for w in _norm(s).split() if len(w) >= 4]


def _head_word(title):
    for w in _tokens(title):
        if w not in _GENERIC:
            return w
    return None


def _clean_claimed(s):
    """Приписана назва без markdown/таблиць. Сміття (|, **, провідна цифра) → None."""
    if not s:
        return None
    s = s.replace("*", "").strip()
    if "|" in s:
        s = s.split("|")[0].strip()
    if len(s) < 3 or s[0].isdigit():
        return None
    return s


def _find_key(hay, key):
    """Позиції всіх входжень назви акта. Коротка форма — лише окремим словом.

    ⭐ 28.07.2026, ЖИВИЙ ПРОГІН. Короткі форми («ск», «цк», «кк») шукались
    ЯК ПІДРЯДОК — і «ск» знайшлось усередині слова «оскарження». Через це
    ст. 18 Закону про закупівлі була оголошена статтею СІМЕЙНОГО кодексу."""
    if len(key) <= 4:
        return [m.start() for m in
                re.finditer(r"(?<![^\W\d_])%s(?![^\W\d_])" % re.escape(key), hay)]
    return [m.start() for m in re.finditer(re.escape(key), hay)]


def code_from_context(before, after, extra=None):
    """Якому АКТУ належить ця стаття.

    ⭐⭐⭐ 11.08.2026 (зміна 150). ТУТ ВИГРАВАЛА НАЙДОВША НАЗВА, А НЕ НАЙБЛИЖЧА.
    Перелік ключів відсортовано за довжиною, і перший збіг вигравав. У реченні
    «ст. 122 КУпАП, а також ст. 18 Закону «Про Національну поліцію»» стаття 122
    діставала номер ЗАКОНУ ПРО ПОЛІЦІЮ — бо його назва довша за «купап».
    Наслідок: звіряч перевіряв статтю не в тому акті й чесно казав «не
    знайдено», а вся консультація лічилась незвіреною.
    🔥 КЛАС: МЕЖУ ВИЗНАЧАЄ ФОРМА (довжина рядка), А НЕ ВІДСТАНЬ ДО ПРЕДМЕТА.
    Лікуємо відстанню: акт статті — той, чия назва стоїть НАЙБЛИЖЧЕ до неї;
    за однакової відстані виграє довша назва (вона конкретніша)."""
    codes, order = _keyset(extra)
    n_after, n_before = _norm(after), _norm(before)
    best = None                      # (відстань, -довжина ключа, ключ)
    for key in order:
        for pos in _find_key(n_after, key):
            cand = (pos, -len(key), key)
            if best is None or cand < best:
                best = cand
        for pos in _find_key(n_before, key):
            # у «before» найближчий — той, що ближче до КІНЦЯ вікна
            dist = max(0, len(n_before) - (pos + len(key)))
            cand = (dist, -len(key), key)
            if best is None or cand < best:
                best = cand
    if best is None:
        return None, None
    return codes[best[2]], best[2]


# ⛔ 30.07.2026, ДРУГИЙ ЖИВИЙ ПРОГІН. Учора тут зʼявився перелік слів-введень
# («закон|кодекс|постанов|особливост»). Модель написала «ст.2 ЗУ «Про публічні
# закупівлі»» — скорочення в переліку не було, і звіряч знову оголосив фальшиву
# «РОЗБІЖНІСТЬ». Перелік слів не є воротами: завтра буде «ЗУ України», «п. 8
# ПКМУ», «Наказ Мінекономіки».
# КЛАС: назву акта знає НАШ ЄДИНИЙ РЕЄСТР АКТІВ (_codes() — legal_source_ua +
# звірена база норм). Що реєстр знає як АКТ — те не може бути темою статті,
# хоч би яким словом його ввели. Перелік введень лишається ДРУГОЮ лінією —
# для актів, яких у реєстрі ще немає.
_ACT_INTRO_RE = re.compile(
    r"(закон|кодекс|постанов|особливост|наказ|розпорядж|директив|угод|"
    r"\bзу\b|\bз\.\s?у\.|\bпкму\b|\bкму\b|\bпку\b|\bгку\b|\bцку\b)",
    re.IGNORECASE)


def _is_known_act_name(quoted):
    """Чи цей рядок — НАЗВА АКТА з нашого єдиного реєстру актів."""
    key = _norm(quoted or "")
    if not key:
        return False
    codes = _codes()
    if key in codes:
        return True
    if len(key) >= 10:
        for k in codes:
            if len(k) >= 10 and (key in k or k in key):
                return True
    return False


def _quoted_is_act(quoted, before):
    """НАЗВА ЗАКОНУ — ЦЕ НЕ НАЗВА СТАТТІ. True -> темою статті не звіряємо."""
    return bool(_is_known_act_name(quoted) or _ACT_INTRO_RE.search(before or ""))


# ⭐⭐⭐ 11.08.2026 (зміна 153), ТРИ КОРЕНІ, КУПЛЕНІ ЖИВИМ ПРОГОНОМ ЗА $0.07.
# Клієнт отримав юридичний документ, у якому:
#   ⚠ «ст. 124 ПРАВИЛ ДОРОЖНЬОГО РУХУ — не знайдено» (а ст. 124 — це КУпАП, і
#      вона тут же звірена ✅), і
#   ✅ «ст. 22 КУПАП — стаття чинна… «Можливість звільнення від відповідальності
#      при малозначності»» — тоді як мова про ст. 22 Закону про ОСЦПВ.
# Тобто ВПЕВНЕНА НІСЕНІТНИЦЯ ІЗ ЗЕЛЕНОЮ ГАЛОЧКОЮ. Коренів три:
#
# 1. ⛔ ЗВІРЯЧ ЇВ ВЛАСНИЙ ХВІСТ. Наш же блок «## Звірка норм із першоджерелом»
#    і рядок «Норми, що потребують звірки…» лишаються в документі, а на
#    наступному проході читаються як ЦИТАТИ. Кожна наша примітка народжувала
#    нову фальшиву «норму». ВЛАСНИЙ ВИХІД — НЕ ЧУЖИЙ ТЕКСТ: розбираємо документ
#    БЕЗ нього.
# 2. ⛔ ВІКНО КОНТЕКСТУ ПЕРЕСТРИБУВАЛО РЯДКИ Й КОМІРКИ ТАБЛИЦЬ — і стаття з
#    однієї комірки брала акт із сусідньої. Акт статті мусить стояти в ТОМУ Ж
#    рядку і близько, а не «десь поруч у ±80 знаках».
# 3. ⛔ НАЗВА АКТА ВПІЗНАВАЛАСЬ У ЗВИЧАЙНОМУ ТЕКСТІ: офіційна назва ст. 124
#    КУпАП містить слова «правил дорожнього руху» — і опис ставав «актом ПДР».
#    Той самий клас, що ми лікували сьогодні в класі B: ПЕРЕЛІК СЛІВ ЛОВИТЬ
#    БУКВУ, А НЕ ЗМІСТ. Поріг близькості робить опис неможливим кандидатом.
# ⚠ І ПЕРЕЛІК СТАТЕЙ ОДНОГО АКТА («ст. 22, 33, 35, 37 Закону про ОСЦПВ») ділить
#    ОДИН акт: він стоїть після ВСЬОГО переліку, а не після першого номера.
_OWN_BLOCK_RE = re.compile(r"\n##\s*Звірка норм із першоджерелом.*?(?=\n##\s|\Z)", re.S)
_OWN_NEED_RE = re.compile(r"\n\*\*Норми, що потребують звірки перед використанням:\*\*[^\n]*")
# Перелік статей одного акта: «22, 33, 35, 37» після «ст.».
_ART_LIST_RE = re.compile(r"^\s*(?:,\s*\d{1,3}(?:\s*[-–—]\s*\d{1,3})?)+")
# ⚠ МЕЖУ КОНТЕКСТУ ЗАДАЄ НЕ ВІДСТАНЬ, А РОЗДІЛЬНИК. Спроба лікувати це порогом
# «N знаків» ламала законні звороти («ст. 2 Закону «Про публічні закупівлі»»,
# де назва акта довга) і водночас пропускала опис. Судимо МЕЖУ, а не довжину.
# ПІСЛЯ статті акт живе до кінця своєї комірки й до роздільника думки:
# «ст. 124 КУпАП (штраф…)» — акт є; «стаття 124 — порушення … правил
# дорожнього руху» — після тире вже ОПИС, а не посилання на акт.
_AFTER_STOP_RE = re.compile(r"[|—–;:(]|\s[-]\s")
# ПЕРЕД статтею акт зараховується лише ВПРИТУЛ: «| КУпАП | Ст. 124» — так,
# «ст. 124 КУпАП **та** ст. 22» — ні (між ними стоїть слово, тобто це вже
# ІНША норма іншого акта). Саме цей випадок віддав клієнту ✅ «ст. 22 КУпАП».
_BEFORE_TAIL_RE = re.compile(r"[\s,;:|«»\"'\)\.]*$")
# ⛒ 671. Між актом і статтею може стояти ЇЇ Ж адреса, а не інша норма:
# «ПКУ, п. 293.3 ст. 293», «Закон про ЄСВ, пункт 4 частини першої статті 1», «ПКУ: ст. 291–299,
# ст. 181». Пункт, частина, абзац і сусідні номери статей того самого переліку —
# це впритул. Будь-яке слово («та», «а також», назва іншого акта) — ні.
# Судиться НОРМАЛІЗОВАНИЙ текст (`_norm`: розділові знаки -> один пробіл), тож
# кожен токен відділено пробілом — і вираз однозначний (без вибухового відкату).
# ⛒ 672: судимо ТОКЕНИ, а не вираз. Адреса статті — це числа, слова-рівні
# (пункт, підпункт, частина, абзац, стаття), «№», межа клітинки таблиці «|» і
# літера підпункту одразу після слова-рівня («пп. «б»»). Будь-що інше — слово,
# а слово між актом і статтею означає ІНШУ норму.
_ADDR_WORD_RE = re.compile(r"^(?:п|пп|підп|ч|абз|пункт\w*|підпункт\w*|частин\w*|абзац\w*|"
                           r"ст|статт\w*|№|\|)$")
_LETTER_AFTER = ("п", "пп", "підп")


def _tail_is_address(tail) -> bool:
    prev = ""
    for t in str(tail or "").split():
        if not (t.isdigit() or _ADDR_WORD_RE.match(t)
                or (len(t) == 1 and t.isalpha()
                    and (prev in _LETTER_AFTER or prev.startswith("підпункт")))):
            return False
        prev = t
    return True


def act_window(before, after):
    """ОДИН ПИСАР МЕЖ КОНТЕКСТУ СТАТТІ. -> (before_вікно, after_вікно)."""
    b = str(before or "").split("\n")[-1]
    a = str(after or "").split("\n")[0]
    _lst = _ART_LIST_RE.match(a)          # «ст. 22, 33, 35, 37 Закону …»
    if _lst:
        a = a[_lst.end():]
    _stop = _AFTER_STOP_RE.search(a)
    if _stop:
        a = a[:_stop.start()]
    return b, a


def _act_touches(before_win, key):
    """Чи стоїть акт ВПРИТУЛ перед статтею (між ними лише розділові знаки)."""
    n = _norm(before_win)
    for pos in _find_key(n, key):
        if _BEFORE_TAIL_RE.match(n[pos + len(key):]) or _tail_is_address(n[pos + len(key):]):
            return True
    return False


# ⛒ 672. РЯДОК З ОДНИМ АКТОМ. «Правова основа — Закон про ЄСВ; строки — у ст. 9»:
# акт не стоїть впритул, але в рядку він ОДИН і іншого акта рядок не згадує.
# Межа обережності (урок 11.08, ✅ «ст. 22 КУпАП»): якщо поза впізнаними актами
# у рядку є бодай згадка акта — закон, кодекс, конституція, постанова, наказ… —
# ми не вгадуємо, чий це номер.
_LINE_OTHER_ACT_RE = re.compile(
    r"(закон|кодекс|конституц|постанов|наказ|розпорядж|указ|регламент|директив|"
    r"правил|положенн|порядк|інструкц|рішенн|договор|угод|\bзу\b|\bпкму\b|\bкму\b)")
_OWNER_AFTER_RE = re.compile(r"^\s*[A-ZА-ЯІЇЄҐ]")
# Слово-вступ одразу перед впізнаним актом («Закону про ЄСВ») — частина ЙОГО згадки.
_INTRO_BEFORE_RE = re.compile(r"(?:^|\s)(?:закон\w*|кодекс\w*)\s*$")


def line_act(text, at, extra=None):
    """(nreg, ключ) єдиного акта рядка, де стоїть стаття; інакше (None, None)."""
    t = text or ""
    s0 = t.rfind("\n", 0, at) + 1
    s1 = t.find("\n", at)
    line = _norm(t[s0:(s1 if s1 >= 0 else len(t))])
    codes, order = _keyset(extra)
    found, spans = {}, []
    for key in order:
        for pos in _find_key(line, key):
            if any(a <= pos < b or a < pos + len(key) <= b for a, b in spans):
                continue
            intro = _INTRO_BEFORE_RE.search(line[:pos])
            spans.append((intro.start() if intro else pos, pos + len(key)))
            found.setdefault(codes[key], key)
    if len(found) != 1:
        return None, None
    rest = line
    for a, b in sorted(spans, reverse=True):
        rest = rest[:a] + " " + rest[b:]
    if _LINE_OTHER_ACT_RE.search(rest):
        return None, None
    (nreg, key), = found.items()
    return nreg, key


def strip_own_verification(text):
    """Прибрати НАШ ВЛАСНИЙ блок звірки з тексту перед розбором цитат.
    Писар не сміє читати власний вихід як чужі дані."""
    t = _OWN_BLOCK_RE.sub("\n", text or "")
    return _OWN_NEED_RE.sub("", t)


def parse_citations(text):
    """Цитати: {article, second(діапазон), nreg, code_key, claimed}. Дублі (той самий
    кодекс+стаття+діапазон) прибираються — щоб блок звірки не мав повторів."""
    out, seen = [], set()
    text = strip_own_verification(text)
    extra = doc_act_keys(text)          # 672: ключі, які оголосив сам документ
    for m in _ART_RE.finditer(text or ""):
        art = m.group(2)
        rng = re.match(r"\s*[-–—]\s*(\d+)", text[m.end():m.end() + 12])
        second = rng.group(1) if rng else None
        # ⚠ СИРЕ ВІКНО НАВМИСНО ШИРОКЕ: межі задає `act_window` (рядок, комірка,
        # роздільник), а не довжина. Раніше тут стояло 40 знаків — і назва акта
        # в сусідній комірці таблиці («| Кодекс України про адміністративні
        # правопорушення | Ст. 124 |») просто НЕ ВЛАЗИЛА у вікно.
        a, b = max(0, m.start() - 220), min(len(text), m.end() + 220)
        before, after = text[a:m.start()], text[m.end():b]
        before_act, after_act = act_window(before, after)
        nreg, key = code_from_context(before_act, after_act, extra)
        # Акт із «before» береться лише впритул — інакше це акт СУСІДНЬОЇ норми.
        if key and not _find_key(_norm(after_act), key) and not _act_touches(before_act, key):
            nreg, key = None, None
        # 672: рядок, де названо рівно один акт. Але «ст. 6 Контракту», «ст. 5
        # Статуту» — у статті ВЛАСНИЙ господар (назва з великої одразу після неї),
        # і акт рядка на неї не переходить.
        if not nreg and not _OWNER_AFTER_RE.match(after_act):
            nreg, key = line_act(text, m.start(), extra)
        claimed = None
        if not second:  # у діапазону нема єдиної назви — темою не звіряємо
            # Тема статті живе поруч із нею: для неї вікно лишається вузьким.
            zone = re.split(r"[;\n|]|статт|\bст\.", after[:80])[0]
            mq = re.search(r"[«\"]([^»\"]{3,60})[»\"]", zone)
            if mq:
                # ⛔ 30.07.2026, ЖИВИЙ ПРОГІН. У лапках після статті стоїть НАЗВА
                # АКТА («ст. 2 Закону "Про публічні закупівлі"»), а звіряч брав її
                # як ТЕМУ СТАТТІ і порівнював з офіційним заголовком («Замовники»)
                # -> фальшива «РОЗБІЖНІСТЬ», через яку прогін ішов у
                # «непідтверджено». Назва акта — не твердження про зміст статті.
                # ⛔ НАЗВА ЗАКОНУ — ЦЕ НЕ НАЗВА СТАТТІ.
                if not _quoted_is_act(mq.group(1), zone[:mq.start()]):
                    claimed = _clean_claimed(mq.group(1))
            else:
                md = re.search(r"^\s*(?:[а-яіїєґ']+\s+)?[—–\-:]\s*([^.;\n(«|]{3,60})", zone, re.IGNORECASE)
                if md:
                    claimed = _clean_claimed(md.group(1))
        dk = (nreg, art, second)
        if dk in seen:
            continue
        seen.add(dk)
        out.append({"article": art, "second": second, "nreg": nreg,
                    "code_key": key, "claimed": claimed})
    return out


def official_title(full_text, article):
    seg = legal_source_ua.extract_article(full_text, article)
    if not seg:
        return None
    m = re.match(r"\s*Стаття\s+\d+\.?\s*([^\n]{0,90})", seg)
    return (m.group(1).strip() if m else None) or None


def _find_article_for(full_text, head_word):
    if not head_word:
        return None
    for m in _HEAD_RE.finditer(full_text or ""):
        if head_word in _tokens(m.group(2)):
            return m.group(1)
    return None


# ⛒⛒⛒ 673, 01.10.2026. ЗВІРЕНО — ЦЕ ЩЕ Й ЧИННО.
# 🩸 Живий прогін Каспера: консультація станом на 01.10.2026 спиралась на ст. 230–233
# Господарського кодексу про штрафні санкції, а кодекс ВТРАТИВ ЧИННІСТЬ (Закон
# № 4196-IX від 09.01.2025). Звіряч перевіряв лише, чи стаття є в тексті порталу, — а
# текст нечинного кодексу на порталі лишається. Портал сам пише це в шапці акта
# («{Кодекс втратив чинність …}») і біля статті («{Статтю … виключено …}») — читаємо.
_REPEALED_RE = re.compile(r"\{[^{}]{0,40}втрати\w*\s+чинн\w*", re.IGNORECASE)
_EXCLUDED_RE = re.compile(r"(?:^|\{)\s*(?:статт\w*\s+\d+[-\d]*\s+)?виключено", re.IGNORECASE)


def act_repealed(full_text) -> bool:
    """Шапка акта на порталі каже «втратив чинність» — акт нечинний цілком."""
    head = str(full_text or "")[:1500]
    first = head.split("(Відомості", 1)[0]          # до вихідних даних — сама шапка
    return bool(_REPEALED_RE.search(first))


def article_excluded(full_text, article, title="") -> bool:
    """Стаття виключена (назва «Виключено» або дужка «{Статтю N виключено …}»)."""
    if "виключено" in str(title or "").lower():
        return True
    seg = legal_source_ua.extract_article(full_text, article) or ""
    body = seg.split("\n", 1)[1] if "\n" in seg else ""
    return bool(_EXCLUDED_RE.search(body[:300]))


def verify(text, get_code_text):
    """Звіряє цитати. status: match/exists/range/mismatch/not_found/no_source/unknown_code/
    repealed (акт втратив чинність)/excluded (стаття виключена)."""
    verdicts, cache = [], {}
    for c in parse_citations(text):
        v = dict(c)
        if not c["nreg"]:
            v["status"] = "unknown_code"; verdicts.append(v); continue
        if c["nreg"] not in cache:
            try:
                cache[c["nreg"]] = get_code_text(c["nreg"]) or ""
            except Exception:
                cache[c["nreg"]] = ""
        full = cache[c["nreg"]]
        if not full:
            v["status"] = "no_source"; verdicts.append(v); continue
        title = official_title(full, c["article"])
        # ⭐⭐⭐ 11.08.2026 (зміна 150). КОДЕКС МОЖЕ ЛЕЖАТИ НА ПОРТАЛІ ЧАСТИНАМИ.
        # КУпАП розбито надвоє: ст. 122 у частині 80731-10, а ст. 256, 268, 287,
        # 289 — у частині 80732-10. Без цього звіряч на половині статей чесно
        # казав би «не знайдено» — і вся консультація водієві лічилась би
        # незвіреною. Пробуємо решту частин ТОГО САМОГО акта.
        if not title:
            try:
                import legal_source_ua as _lsu
                _alts = [n for n in _lsu.alt_nregs(c["nreg"]) if n != c["nreg"]]
            except Exception:
                _alts = []
            for _alt in _alts:
                if _alt not in cache:
                    try:
                        cache[_alt] = get_code_text(_alt) or ""
                    except Exception:
                        cache[_alt] = ""
                if not cache[_alt]:
                    continue
                title = official_title(cache[_alt], c["article"])
                if title:
                    v["nreg"] = _alt
                    break
        v["official_title"] = title
        if not title:
            v["status"] = "not_found"; verdicts.append(v); continue
        # ⛒ 673: ЧИННІСТЬ — ЧАСТИНА ЗВІРКИ. Стаття нечинного акта чи виключена
        # стаття існує в тексті порталу, але застосовувати її не можна.
        if act_repealed(cache.get(v["nreg"]) or full):
            v["status"] = "repealed"; verdicts.append(v); continue
        if article_excluded(cache.get(v["nreg"]) or full, c["article"], title):
            v["status"] = "excluded"; verdicts.append(v); continue
        if c["second"]:  # діапазон норм — звіряємо лише чинність, не тему
            v["status"] = "range"; verdicts.append(v); continue
        if not c["claimed"]:
            v["status"] = "exists"; verdicts.append(v); continue
        hw = _head_word(c["claimed"])
        if hw and hw in _tokens(title):
            v["status"] = "match"
        else:
            v["status"] = "mismatch"
            v["should_be"] = _find_article_for(full, hw)
        verdicts.append(v)
    ok = bool(verdicts) and all(v["status"] in ("match", "exists", "range") for v in verdicts)
    bad = [v for v in verdicts if v["status"] not in ("match", "exists", "range")]
    return verdicts, {"ok": ok, "checked": len(verdicts), "flagged": len(bad)}


_MODEL_SEAL_RE = re.compile(
    r"[✅✔☑]?\s*(?<!не )звірено з першоджерел\w*(?:\s*\([^)]*\))?\.?", re.IGNORECASE)


def strip_model_seal(text):
    return _MODEL_SEAL_RE.sub("", text or "")


# ⛒ 671, 01.10.2026. КОЖНА СТАТТЯ НАЗВАНА — АЛЕ ОДИН РЯДОК НА ПРИЧИНУ.
# 🩸 Консультація ФОП дала клієнтові 30 однакових рядків «не звірено
# (невідомий кодекс) — ПЕРЕВІРТЕ вручну». Чесність — у тому, що названо кожну
# статтю, а не в тому, скільки разів повторено одну причину.
_GROUPED = {"unknown_code": "акт не розпізнано", "no_source": "офіційне джерело недоступне"}


def build_report(verdicts, date_str):
    lines = ["## Звірка норм із першоджерелом (автоматична, ВРУ)"]
    need = []
    grouped = {k: [] for k in _GROUPED}
    for v in verdicts:
        if v.get("status") in grouped:
            num = f"{v['article']}–{v['second']}" if v.get("second") else v["article"]
            loc = f"ст. {num}" + (f" {v['code_key'].upper()}" if v.get("code_key") else "")
            if loc not in grouped[v["status"]]:
                grouped[v["status"]].append(loc)
            # у підсумковий перелік не дублюємо: згрупований рядок уже називає статтю
    for st, locs in grouped.items():
        if locs:
            lines.append(f"- ⚠ Не звірено автоматично ({_GROUPED[st]}): "
                         + ", ".join(locs) + " — перевірте вручну.")
    for v in verdicts:
        if v.get("status") in grouped:
            continue
        num = f"{v['article']}–{v['second']}" if v.get("second") else v["article"]
        loc = f"ст. {num}" + (f" {v['code_key'].upper()}" if v.get("code_key") else "")
        t = v.get("official_title")
        if v["status"] == "match":
            lines.append(f"- ✅ {loc} — звірено з першоджерелом ({date_str}); офіційна назва: «{t}».")
        elif v["status"] == "exists":
            lines.append(f"- ✅ {loc} — стаття чинна, звірено ({date_str}); офіційна назва: «{t}».")
        elif v["status"] == "range":
            lines.append(f"- ✅ {loc} — діапазон норм; статті чинні, звірено ({date_str}).")
        elif v["status"] == "mismatch":
            hint = f" Тему «{v['claimed']}» насправді регулює ст. {v['should_be']}." if v.get("should_be") else ""
            lines.append(f"- ⚠ {loc} — РОЗБІЖНІСТЬ: приписано «{v['claimed']}», а офіційна назва — «{t}».{hint} ПЕРЕВІРТЕ.")
            need.append(loc)
        elif v["status"] == "not_found":
            lines.append(f"- ⚠ {loc} — статті з таким номером в офіційному тексті не знайдено. ПЕРЕВІРТЕ вручну.")
            need.append(loc)
        elif v["status"] == "repealed":
            lines.append(f"- ⛔ {loc} — акт втратив чинність (так позначено на порталі Верховної "
                         f"Ради, {date_str}). Норма не застосовується — ПЕРЕВІРТЕ, що діє замість неї.")
            need.append(loc)
        elif v["status"] == "excluded":
            lines.append(f"- ⛔ {loc} — статтю виключено з акта (портал Верховної Ради, {date_str}). "
                         f"Норма не застосовується — ПЕРЕВІРТЕ.")
            need.append(loc)
        else:
            why = "невідомий кодекс" if v["status"] == "unknown_code" else "офіційне джерело недоступне"
            lines.append(f"- ⚠ {loc} — не звірено ({why}) — ПЕРЕВІРТЕ вручну.")
            need.append(loc)
    if need:
        lines.append("")
        lines.append("**Норми, що потребують звірки перед використанням:** " + ", ".join(need) + ".")
    return "\n".join(lines)

# ⭐ 28.07.2026. ДІРКА, ЯКУ ЦЕ ЗАКРИВАЄ. Живий прогін видав клієнту документ, де
# поруч стояли дві правди: «Вердикт: PASS — відповідь повна й вичерпна» (написала
# МОДЕЛЬ) і «⚠ ст. 18 — не звірено, ст. 41 — не звірено» (порахувала МАШИНА).
# Людина читає вердикт, а не примітку внизу. Тому: самозаявлений вердикт моделі
# знімається, а вердикт пише КОД — за фактом звірки.
# ⛔ 30.07.2026. Тут стояв ЛИШЕ ПОЗИТИВНИЙ перелік (PASS/ЗВІРЕНО/…), і модель
# спокійно ставила собі НЕГАТИВНИЙ вердикт «REVISE» — клієнт отримував документ,
# який сам себе оголошував «умовно придатним». Вердикт про придатність пише
# машина; модель не пише жодного — ні доброго, ні поганого.
_MODEL_VERDICT_RE = re.compile(
    r"(Вердикт\s*\**\s*[|:\-–]?\s*\|?\s*\**\s*)"
    r"(PASS|ПРОЙДЕНО|OK|ЗВІРЕНО|ПІДТВЕРДЖЕНО|REVISE|FAIL|НЕ ПРОЙДЕНО|"
    r"ПОТРЕБУЄ ДООПРАЦЮВАННЯ|УМОВНО[^\n.]{0,20})(\**)",
    re.IGNORECASE)



# ======================= ОДИН ПИСАР СТАТУСУ ЗВІРКИ (30.07.2026) =======================
# ⛔ ДВА ПИСАРІ ОДНІЄЇ ПРАВДИ. Прогін 22:07: угорі «Звірено 27.07.2026» (наша база),
# унизу «⚠ Не звірено з першоджерелом» (модель) — про ОДНУ І ТУ САМУ норму.
# Правило: статус звірки — це ВЛАСТИВІСТЬ БАЗИ, а не думка моделі. Заяви моделі про
# звірку знімаються; замість них документ отримує ОДИН блок від бази, який чесно
# каже і про звірене, і про те, чого система не звіряла.
_VERIF_CLAIM_RE = re.compile(
    r"(не\s+звірено|не\s+підтверджено\s+живим|підляга\w*\s+звірц\w*|"
    r"потребу\w*\s+звірки|обов'?язков\w*\s+звірк\w*|причина\s+вердикту|"
    r"як\s+остаточно\s+підтверджен)", re.IGNORECASE)
_VERIF_HEAD_RE = re.compile(
    r"^\s{0,3}#{1,6}\s*.*(потребу\w*\s+звірки|статус\s+звірки)", re.IGNORECASE)
# ⚠ Тільки «Статус звірки» — заголовок МОДЕЛІ. Колонку «Звірено» таблиці БАЗИ
# знімач не має права зачепити навіть теоретично: база — писар, а не підсудний.
_STATUS_COL_RE = re.compile(r"статус\s+звірки", re.IGNORECASE)
_TABLE_ROW_RE = re.compile(r"^\s*\|.*\|\s*$")


def _drop_status_column(lines):
    """Колонку «Статус звірки» знімаємо з таблиці, саму таблицю лишаємо:
    перелік актів і того, що вони регулюють, — корисний клієнту."""
    out, i = [], 0
    while i < len(lines):
        if not _TABLE_ROW_RE.match(lines[i]):
            out.append(lines[i]); i += 1; continue
        j = i
        while j < len(lines) and _TABLE_ROW_RE.match(lines[j]):
            j += 1
        table = lines[i:j]
        head = [c.strip() for c in table[0].strip().strip("|").split("|")]
        col = next((k for k, c in enumerate(head) if _STATUS_COL_RE.search(c)), None)
        if col is None:
            out.extend(table)
        else:
            for row in table:
                cells = row.strip().strip("|").split("|")
                if len(cells) > col:
                    del cells[col]
                out.append("|" + "|".join(cells) + "|")
        i = j
    return out


def strip_model_verification_claims(text):
    """Знімає з тексту моделі ЇЇ заяви про звірку норм. Абзаци про повноту
    ДЖЕРЕЛА («Додаток № 4 відсутній», «sign.p7s не читався») не чіпаємо — це не
    статус звірки, а факт про матеріал, і клієнту він потрібен."""
    lines = _drop_status_column((text or "").split("\n"))
    out, i = [], 0
    while i < len(lines):
        ln = lines[i]
        if _VERIF_HEAD_RE.match(ln):          # цілий розділ «…потребують звірки…»
            i += 1
            while i < len(lines) and not re.match(r"^\s{0,3}(#{1,6}\s|---\s*$)", lines[i]):
                i += 1
            continue
        if _VERIF_CLAIM_RE.search(ln):        # окремий абзац/пункт із заявою
            i += 1
            continue
        out.append(ln); i += 1
    res = re.sub(r"\n{3,}", "\n\n", "\n".join(out))
    return res.strip() + "\n"


# ======================= 675: СТАТУС НОРМИ ПИШЕ ЗВІРЯЧ, А НЕ МОДЕЛЬ =======================
# 🩸 Живий висновок юриста для Каспера 01.10.2026: шапка «⚠ Норми нижче не звірені з
# офіційним джерелом» — при сорока звірених ✅; у тексті біля ст. 549, 551, 625 ЦК, які
# звіряч звірив, — модельні «⚠ не звірено з першоджерелом» і легенда «⚠ — не звірено».
# Клієнт читав на одній сторінці дві протилежні правди про ту саму норму.
# ⛒ ПРАВИЛО (те саме, що 30.07 для бази закупівель, тепер — для будь-якої галузі): статус
# норми — властивість звірки. Знімаються ЛИШЕ модельні ПОЗНАЧКИ статусу: колонка статусу
# таблиці (якщо в ній самі значки й теги), легенда значків і значок ПІСЛЯ тексту.
# ⚠ на ПОЧАТКУ рядка чи клітинки — це попередження про суть («⚠ Увага: …»), воно лишається.
_STATUS_HEAD_RE = re.compile(r"^\s*\**\s*(статус(\s+звірки)?|звірка|звірено|перевірка)\s*\**\s*$",
                             re.IGNORECASE)
_STATUS_ONLY_RE = re.compile(r"[⚠✅⛔✔☑❌️\s*/,;—–-]|\[[^\]]{0,40}\]")
_LEGEND_RE = re.compile(r"^\s*(?:[-*•]\s*)?[⚠✅⛔✔]+️?\s*[—–-]\s")
_LEGEND_INTRO_RE = re.compile(r"(позначен|статус)", re.IGNORECASE)
# ⛒ 681б: `Статус\s*:` — а не дослівна мітка. Цей модуль мітку ЗНІМАЄ, а не пише;
# дослівна мітка в коді — ознака складача тендерного тексту (tender_honesty, правило 10).
_STATUS_WORD_RE = re.compile(r"\s*Статус\s*:\s*[⚠✅⛔]+️?\.?")
_TRAIL_MARK_RE = re.compile(r"(?<=[^\s|])[ \t]*⚠+️?")


def _status_only(cell) -> bool:
    return not _STATUS_ONLY_RE.sub("", cell or "")


def _drop_glyph_status_column(lines):
    out, i = [], 0
    while i < len(lines):
        if not _TABLE_ROW_RE.match(lines[i]):
            out.append(lines[i]); i += 1; continue
        j = i
        while j < len(lines) and _TABLE_ROW_RE.match(lines[j]):
            j += 1
        table = lines[i:j]
        head = [c.strip() for c in table[0].strip().strip("|").split("|")]
        body = [r.strip().strip("|").split("|") for r in table[2:]]
        col = next((k for k, c in enumerate(head) if _STATUS_HEAD_RE.match(c)
                    and body and all(len(r) > k and _status_only(r[k]) for r in body)), None)
        if col is None:
            out.extend(table)
        else:
            for row in table:
                cells = row.strip().strip("|").split("|")
                if len(cells) > col:
                    del cells[col]
                out.append("|" + "|".join(cells) + "|")
        i = j
    return out


def strip_model_status_marks(text):
    """Знімає з тексту моделі її ПОЗНАЧКИ статусу норм (675). Зміст не чіпає."""
    lines = _drop_glyph_status_column((text or "").split("\n"))
    out = []
    for ln in lines:
        if _LEGEND_RE.match(ln):
            # легенда значків іде геть, а з нею — вступ «… позначені так:»
            k = len(out) - 1
            while k >= 0 and not out[k].strip():
                k -= 1
            if k >= 0 and out[k].rstrip().endswith(":") and _LEGEND_INTRO_RE.search(out[k]):
                del out[k:]
            continue
        ln = _STATUS_WORD_RE.sub("", ln)
        out.append(_TRAIL_MARK_RE.sub("", ln))
    return re.sub(r"\n{3,}", "\n\n", "\n".join(out))


def status_counts(verdicts):
    """(звірено, усього) — один писар цих двох чисел для шапки документа."""
    ok = sum(1 for v in (verdicts or []) if v.get("status") in ("match", "exists", "range"))
    return ok, len(verdicts or [])


def base_status_block(pos, date_str=""):
    """ЄДИНИЙ статус звірки в документі — від бази. Пишемо і про звірене, і про
    те, чого система НЕ звіряла: мовчання про межу — це теж друга правда."""
    norms = (pos or {}).get("norms") or []
    if not norms:
        return ""
    def _key(d):                      # DD.MM.YYYY -> сортовний ключ
        p = (d or "").split(".")
        return tuple(reversed(p)) if len(p) == 3 else (d,)
    dates = sorted({(n.get("checked_at") or "").strip()
                    for n in norms if n.get("checked_at")}, key=_key)
    when = dates[0] if dates else (date_str or "")   # найраніша = найчесніша
    acts = []
    for n in norms:
        a = (n.get("act") or "").strip()
        if a and a not in acts:
            acts.append(a)
    return ("## Статус звірки норм\n\n"
            "**Звірено SensFlow:** %d норм вашої процедури%s. Джерело — оригінали "
            "актів (%s) на zakon.rada.gov.ua. Саме ці норми наведені в таблиці на "
            "початку документа.\n\n"
            "**Не звірено:** будь-яка інша норма, згадана в цьому документі, "
            "системою не звірялась — перед поданням її має перевірити ваш юрист."
            % (len(norms), (" станом на %s" % when) if when else "", "; ".join(acts[:4])))

def strip_model_verdict(text):
    """Знімає вердикт, який модель поставила САМА СОБІ. Не видаляє блок цілком —
    лишає слід, щоб людина бачила, що вердикт було знято, а не загублено.

    ⭐⭐⭐ 11.08.2026 (зміна 153), ЖИВИЙ ПРОГІН. Тут стояли ДВА дефекти в одному
    рядку, і обидва бачив КЛІЄНТ у своєму юридичному документі:
      1. закриваючі зірочки (`group(3)`) відкидались — і документ діставав
         незакрите `**`, тобто ПОЛАМАНУ РОЗМІТКУ від нашого ж запобіжника;
      2. на їх місце їхала наша ВНУТРІШНЯ КУХНЯ — «вердикт пише машина, не
         модель». Клієнт не наймав ані машину, ані модель: для нього це слова
         про поломку. Слід має лишитись, але сказаний ЙОГО мовою.
    🔥 КЛАС: ЧЕСНИЙ ЗАПОБІЖНИК, ЯКИЙ ЛАМАЄ РОЗМІТКУ Й ГОВОРИТЬ НАШОЮ КУХНЕЮ,
    читається як поломка платформи."""
    return _MODEL_VERDICT_RE.sub(
        lambda m: (m.group(1) + "знято — придатність документа оцінює звірка норм "
                   "із першоджерелом (нижче)" + (m.group(3) or "")), text or "")


def machine_verdict(problems, checked=0, date_str=""):
    """ЗАЛИШЕНО ДЛЯ СУМІСНОСТІ. Машинних вироків клієнтові більше не показуємо.
    ⭐ 28.07.2026: рядок «система щось не звірила» в документі клієнта — це
    одразу питання до продавця «навіщо я платив гроші». Не звірено -> просто
    НЕ показуємо, а не показуємо з лякалкою."""
    return client_notice(bool(problems))


def client_notice(has_problems):
    """Коротке ділове повідомлення замість машинної скарги. Порожньо = мовчимо."""
    if not has_problems:
        return ""
    return ("> **Нижче наведено норми саме вашої процедури — зі звіреної бази.**\n"
            "> Інші строки, що трапляються в публічних джерелах, стосуються "
            "інших типів закупівель і до вашого тендера не застосовуються.")
