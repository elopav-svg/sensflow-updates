# -*- coding: utf-8 -*-
"""second_factor.py — ДВОФАКТОРНИЙ ВХІД (зміна 666, 30.09.2026).

🩸 ЩО БУЛО. Вхід — лише пароль. Підглянутий чи вкрадений пароль означав повний
доступ до бази продажів. ОТУ (лист ІТ/СБ 30.09.2026, п. 3) вимагає другий
фактор. 665 зупинив перебір пароля; тут закривається крадіжка пароля.

⛒ ДЕ СТОЇТЬ. Другий крок — у ТИХ САМИХ дверях входу (`taskdesk_identity.login`,
`login_light`): пароль прийнято → сесії ще немає, є разовий квиток на
`TICKET_MIN` хвилин. Сесію відкриває лише `taskdesk_identity.login_second`
правильним кодом. Цей модуль — суддя кодів, сховище таємниць і вимога; сесій
він не відкриває і журналу входів не пише (це робота дверей).

⛒ СТАНДАРТ, А НЕ ВИНАХІД. Код — TOTP (RFC 6238: HMAC-SHA1, 6 цифр, крок 30 с),
його читає Google Authenticator і будь-яка сумісна програма. Стандартна
бібліотека Python — у закритому контурі клієнта сторонніх пакетів немає.
QR — свій (`qr_code`).

⛒⛒⛒ ТАЄМНИЦЯ — СЕКРЕТ МАШИНИ, А НЕ ДАНІ ЛЮДИНИ (той самий клас, що 571б).
Таємниця й резервні коди лежать у `second_factor/` — окремо від облікових
записів. Тека оголошена в `state_files.SECRET_DIRS`: в архів даних не йде,
клієнту не їде, оновлення її не затирає. 🩸 Інакше архів на флешці чи в хмарі
віз би другий фактор кожного працівника поруч із хешами паролів — і витік
архіву знищував би саме те, заради чого 2FA вмикали. Втрата ж ЛІКУЄТЬСЯ:
адміністратор скидає, людина підключає наново.
Вимога («для всіх» / «для ролей») — навпаки, налаштування клієнта: лежить у
`taskdesk/` і їде в архів. Відновились на новій машині — вимога та сама,
люди підключають телефони наново.

⛒ ЗАХИСТ САМОГО КОДУ.
  • Невдалий код — невдала спроба входу (пише двері): той самий лічильник
    паузи 665, перебір коду зупиняється так само, як перебір пароля.
  • Використаний код не приймається вдруге (`last_step`): підглянутий через
    плече код за ті ж 30 секунд не спрацює.
  • Вікно ±1 крок — годинник телефона може відстати на півхвилини.
  • Квиток прив'язаний до адреси, живе `TICKET_MIN` хв і згорає після
    `TICKET_TRIES` хибних кодів.
  • Резервні коди — лише хешами; показуються один раз.

⛒ СХОВИЩЕ НЕ ЧИТАЄТЬСЯ — ВХІД ЗАКРИТО (fail-closed), на відміну від 665: там
відмова лічильника — лише на хвилину без захисту від перебору, тут — вхід
самим паролем повз другий фактор. Людина бачить причину; поломка — у журналі.
"""

import base64
import hashlib
import hmac
import secrets
import struct
import threading
import time
import urllib.parse

import clock
import config
import one_writer
import protocol
import qr_code
import security_log

# ⛒ ДРУГИЙ ЗАМОК: проба, завантажена не через файл, по бойових таємницях не ходить.
config.refuse_live_state_for_checks(__name__)

STORE_DIR = config.STATE_DIR / "second_factor"          # СЕКРЕТ машини
STORE_JSON = STORE_DIR / "store.json"
POLICY_JSON = config.STATE_DIR / "taskdesk" / "second_factor_policy.json"   # дані клієнта

ISSUER = "SensFlow"
STEP = 30              # секунд на код
DIGITS = 6
WINDOW = 1             # ± кроків (годинник телефона)
BACKUP_N = 10
BACKUP_ALPHABET = "abcdefghjkmnpqrstuvwxyz23456789"     # без 0/o, 1/l/i
BACKUP_ROUNDS = 20_000
TICKET_MIN = 5
TICKET_TRIES = 5

POLICY_OFF, POLICY_ALL, POLICY_ROLES = "off", "all", "roles"
POLICY_MODES = (POLICY_OFF, POLICY_ALL, POLICY_ROLES)
POLICY_NAMES = {POLICY_OFF: "вимкнено", POLICY_ALL: "для всіх",
                POLICY_ROLES: "для ролей"}

STEP_CODE, STEP_ENROLL = "code", "enroll"

TICKET_GONE = "Час на код минув. Увійдіть ще раз."
CODE_DENY = "Код не підходить."


class SecondFactorError(Exception):
    """Відмова словами для людини."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _unix() -> float:
    """⛒ ЕПОХА, А НЕ ЧАС ЗАПИСУ. `clock.now` — київський настінний час для
    журналів (і без бази часових зон — зі сталим зсувом +3, тобто взимку на
    годину хибний). Код із телефона рахується від справжньої епохи UTC, тож
    тут — саме вона. Проба підміняє цю функцію, як `clock.now`."""
    return time.time()


# ─────────────────────────── TOTP (RFC 6238) ───────────────────────────────
def _key_bytes(secret: str) -> bytes:
    k = _s(secret).replace(" ", "").upper()
    return base64.b32decode(k + "=" * ((-len(k)) % 8))


def totp(secret: str, unix_time: float) -> str:
    counter = int(unix_time // STEP)
    mac = hmac.new(_key_bytes(secret), struct.pack(">Q", counter), hashlib.sha1).digest()
    off = mac[-1] & 0x0F
    val = struct.unpack(">I", mac[off:off + 4])[0] & 0x7FFFFFFF
    return str(val % (10 ** DIGITS)).zfill(DIGITS)


def new_secret() -> str:
    return base64.b32encode(secrets.token_bytes(20)).decode("ascii")


def _pretty(key: str) -> str:
    """Для ручного введення: групи по 4 знаки."""
    k = _s(key).replace(" ", "")
    return " ".join(k[i:i + 4] for i in range(0, len(k), 4))


def otpauth_uri(login: str, secret: str) -> str:
    label = urllib.parse.quote("%s:%s" % (ISSUER, _s(login)), safe=":@")
    return ("otpauth://totp/%s?secret=%s&issuer=%s&algorithm=SHA1&digits=%d&period=%d"
            % (label, _s(secret).replace(" ", ""), urllib.parse.quote(ISSUER),
               DIGITS, STEP))


def _enroll_view(login: str, key: str) -> dict:
    """Що бачить людина на підключенні. ⛒ Поле зветься `manual_key`, а не
    `secret`: двері таємниць сервера (`secrets_gate`) правильно вирізають будь-
    яке `secret` з відповіді браузеру. Тут таємницю людина МУСИТЬ побачити —
    рівно один раз, на підключенні; після нього вона з машини не виходить."""
    return {"qr_svg": qr_code.svg(qr_code.encode(otpauth_uri(login, key))),
            "manual_key": _pretty(key)}


# ─────────────────────────── СХОВИЩЕ (СЕКРЕТ) ──────────────────────────────
def _load() -> dict:
    """ЄДИНИЙ ЧИТАЧ таємниць. Немає файла — ніхто не підключав. Файл є, але не
    читається — відмова (fail-closed): мовчки вважати «ніхто не підключав»
    означало б пустити паролем повз другий фактор."""
    if not STORE_JSON.exists():
        return {"accounts": {}}
    try:
        raw = one_writer.read_json(STORE_JSON)
    except PermissionError:
        raise
    except Exception as e:
        raise SecondFactorError("сховище двофакторного входу не читається (%s) — "
                                "зверніться до адміністратора" % type(e).__name__)
    if not isinstance(raw, dict) or not isinstance(raw.get("accounts"), dict):
        raise SecondFactorError("сховище двофакторного входу пошкоджене — зверніться "
                                "до адміністратора")
    return raw


def _save(st: dict):
    """ЄДИНЕ місце, де таємниці лягають на диск."""
    STORE_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(STORE_JSON, st)


def _rec(st, acc_id) -> dict:
    r = st["accounts"].get(_s(acc_id))
    return r if isinstance(r, dict) else {}


def enrolled(acc_id: str) -> bool:
    return bool(_rec(_load(), acc_id).get("key"))


# ─────────────────────────── ВИМОГА (ДАНІ КЛІЄНТА) ─────────────────────────
def policy() -> dict:
    """Вимога адміністратора. Немає файла — вимкнено (живу роботу не міняємо).
    Побитий файл — «для всіх»: помилка в налаштуванні безпеки не сміє мовчки
    зняти захист; поломка — у файл невдач журналу."""
    if not POLICY_JSON.exists():
        return {"mode": POLICY_OFF, "roles": []}
    try:
        raw = one_writer.read_json(POLICY_JSON)
        mode = _s(raw.get("mode"))
        if mode not in POLICY_MODES:
            raise ValueError("невідомий режим «%s»" % mode)
        return {"mode": mode,
                "roles": sorted({_s(x) for x in (raw.get("roles") or []) if _s(x)})}
    except PermissionError:
        raise
    except Exception as e:
        security_log._lost("вимога двофакторного входу не читається — діє «для всіх»", e)
        return {"mode": POLICY_ALL, "roles": []}


def _policy_words(p) -> str:
    if p["mode"] != POLICY_ROLES:
        return POLICY_NAMES[p["mode"]]
    names = _role_names()
    return "для ролей: " + (", ".join(names.get(r, r) for r in p["roles"]) or "жодної")


def _role_names() -> dict:
    import taskdesk_roles as roles
    return {r["id"]: r.get("name") or r["id"] for r in roles.roles()}


@one_writer.guard("POLICY_JSON")
def set_policy(mode: str, role_ids=None) -> dict:
    mode = _s(mode)
    if mode not in POLICY_MODES:
        raise SecondFactorError("невідомий режим «%s»: буває %s"
                                % (mode, ", ".join("«%s»" % POLICY_NAMES[m] for m in POLICY_MODES)))
    ids = sorted({_s(x) for x in (role_ids or []) if _s(x)})
    known = _role_names()
    bad = [r for r in ids if r not in known]
    if bad:
        raise SecondFactorError("таких ролей немає: %s" % ", ".join(bad))
    if mode == POLICY_ROLES and not ids:
        raise SecondFactorError("«для ролей» без жодної ролі — це те саме, що "
                                "«вимкнено»; оберіть ролі або «вимкнено»")
    before = policy()
    new = {"mode": mode, "roles": ids if mode == POLICY_ROLES else []}
    POLICY_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(POLICY_JSON, new)
    was, now = _policy_words(before), _policy_words(new)
    if was != now:
        security_log.second_factor_event(
            protocol.A_TFA_POLICY, None, changes=[("вимога", was, now)],
            note="діє з наступного входу кожного")
    return new


def required(acc: dict) -> bool:
    p = policy()
    if p["mode"] == POLICY_ALL:
        return True
    if p["mode"] == POLICY_ROLES:
        import taskdesk_roles as roles
        eid = _s((acc or {}).get("employee_id"))
        return bool(eid) and roles.role_of(eid)["id"] in p["roles"]
    return False


def status(acc: dict) -> dict:
    """Стан для екрана людини й консолі. Жодної таємниці."""
    r = _rec(_load(), (acc or {}).get("id"))
    return {"enrolled": bool(r.get("key")), "since": _s(r.get("since")),
            "backup_left": len(r.get("backup") or []) if r.get("key") else 0,
            "required": required(acc), "policy": policy()["mode"]}


# ─────────────────────────── РЕЗЕРВНІ КОДИ ─────────────────────────────────
def _new_backup() -> tuple:
    codes, hashed = [], []
    while len(codes) < BACKUP_N:
        c = "".join(secrets.choice(BACKUP_ALPHABET) for _ in range(8))
        if c in codes:
            continue
        codes.append(c)
        salt = secrets.token_hex(8)
        hashed.append({"s": salt, "h": _backup_hash(c, salt)})
    return ["%s-%s" % (c[:4], c[4:]) for c in codes], hashed


def _backup_hash(code: str, salt: str) -> str:
    return hashlib.pbkdf2_hmac("sha256", code.encode("ascii"), bytes.fromhex(salt),
                               BACKUP_ROUNDS).hex()


def _norm_backup(code) -> str:
    return "".join(ch for ch in _s(code).lower() if ch.isalnum())


def _norm_digits(code) -> str:
    c = "".join(ch for ch in _s(code) if not ch.isspace())
    return c if len(c) == DIGITS and c.isdigit() else ""


# ─────────────────────────── СУДДЯ КОДУ ────────────────────────────────────
def _match_totp(key: str, code: str, last_step: int) -> int:
    """Крок, якому відповідає код, або -1. Кроки не новіші за `last_step` —
    уже використані: той самий код удруге не приймається."""
    d = _norm_digits(code)
    if not d or not key:
        return -1
    now_step = int(_unix() // STEP)
    for step in range(now_step - WINDOW, now_step + WINDOW + 1):
        if step > last_step and hmac.compare_digest(totp(key, step * STEP), d):
            return step
    return -1


@one_writer.guard("STORE_JSON")
def _use_code(acc_id: str, code: str, allow_backup: bool = True) -> str:
    """Перевірити код підключеної людини і «погасити» його. Повертає, ЧИМ
    увійшли (для журналу), або "" — не підходить."""
    st = _load()
    r = _rec(st, acc_id)
    if not r.get("key"):
        return ""
    step = _match_totp(r["key"], code, int(r.get("last_step") or -1))
    if step >= 0:
        r["last_step"] = step
        _save(st)
        return "другий крок: код із програми"
    b = _norm_backup(code)
    if allow_backup and len(b) == 8:
        for item in list(r.get("backup") or []):
            if hmac.compare_digest(_backup_hash(b, item.get("s", "00")), _s(item.get("h"))):
                r["backup"].remove(item)
                _save(st)
                return "другий крок: резервний код, лишилось %d" % len(r["backup"])
    return ""


@one_writer.guard("STORE_JSON")
def _commit(acc: dict, key: str, step: int, who_self: bool) -> list:
    """Підключення стало фактом: таємниця, крок і нові резервні коди."""
    st = _load()
    codes, hashed = _new_backup()
    st["accounts"][acc["id"]] = {"key": _s(key).replace(" ", ""), "since": clock.now(),
                                 "last_step": step, "backup": hashed}
    _save(st)
    security_log.second_factor_event(
        protocol.A_TFA_ON, acc, actor_self=who_self,
        note="Google Authenticator; видано %d резервних кодів" % BACKUP_N)
    return codes


# ─────────────────────────── САМА ЛЮДИНА (ЕКРАН) ───────────────────────────
@one_writer.guard("STORE_JSON")
def begin_enroll(acc: dict) -> dict:
    """Нова таємниця «на підключенні». Діє, лише коли людина підтвердить її
    кодом із програми (`confirm_enroll`): до того вхід не змінюється."""
    st = _load()
    if _rec(st, acc["id"]).get("key"):
        raise SecondFactorError("двофакторний вхід уже підключено; щоб підключити "
                                "інший телефон — спершу вимкніть його або попросіть "
                                "адміністратора скинути")
    key = new_secret()
    r = st["accounts"].setdefault(acc["id"], {})
    r["pending"] = key
    r["pending_at"] = clock.now()
    _save(st)
    return _enroll_view(acc.get("login"), key)


def confirm_enroll(acc: dict, code: str) -> dict:
    with one_writer.hold():
        st = _load()
        r = _rec(st, acc["id"])
        key = _s(r.get("pending"))
        if r.get("key"):
            raise SecondFactorError("двофакторний вхід уже підключено")
        if not key:
            raise SecondFactorError("спершу почніть підключення — покажіть QR-код")
        step = _match_totp(key, code, -1)
        if step < 0:
            raise SecondFactorError("код не підходить — перевірте, що в програмі "
                                    "саме цей запис, і введіть свіжий код")
        return {"backup_codes": _commit(acc, key, step, who_self=True)}


def regen_backup(acc: dict, code: str) -> dict:
    """Нові резервні коди замість старих — за свіжим кодом із програми."""
    with one_writer.hold():
        if not _use_code(acc["id"], code, allow_backup=False):
            raise SecondFactorError("потрібен свіжий код із програми")
        st = _load()
        codes, hashed = _new_backup()
        _rec(st, acc["id"])["backup"] = hashed
        _save(st)
    security_log.second_factor_event(protocol.A_TFA_CODES, acc, actor_self=True,
                                     note="старі резервні коди більше не діють")
    return {"backup_codes": codes}


def disable(acc: dict, code: str) -> dict:
    if required(acc):
        raise SecondFactorError("двофакторний вхід для вас вимагає адміністратор — "
                                "вимкнути його може лише він (скиданням)")
    with one_writer.hold():
        if not _use_code(acc["id"], code):
            raise SecondFactorError("потрібен код із програми або резервний код")
        st = _load()
        st["accounts"].pop(acc["id"], None)
        _save(st)
    security_log.second_factor_event(protocol.A_TFA_OFF, acc, actor_self=True,
                                     note="вимкнула сама людина")
    return {"enrolled": False}


# ─────────────────────────── АДМІНІСТРАТОР ─────────────────────────────────
@one_writer.guard("STORE_JSON")
def reset(acc: dict, note: str = "скинув адміністратор") -> bool:
    """Скидання: таємниця і резервні коди зникають. Сесії людини закриває
    ДВЕРНИК сесій (`taskdesk_identity.reset_second_factor`), не тут."""
    st = _load()
    r = st["accounts"].pop(acc["id"], None)
    if not (r or {}).get("key") and not (r or {}).get("pending"):
        raise SecondFactorError("у «%s» двофакторний вхід не підключено — скидати "
                                "нічого" % _s(acc.get("login")))
    _save(st)
    security_log.second_factor_event(protocol.A_TFA_OFF, acc, note=note)
    return True


# ─────────────────────────── КВИТКИ ДРУГОГО КРОКУ ──────────────────────────
# ⛒ У памʼяті, а не у файлі: квиток живе 5 хвилин; перезапуск служби просто
# попросить ще раз ввести пароль. Файл квитків був би ще одним секретом на
# диску без жодної користі.
_TICKETS = {}
_LOCK = threading.Lock()


def _ip() -> str:
    return _s(protocol.context().get("ip"))


def _prune(now):
    for k in [k for k, t in _TICKETS.items() if t["until"] <= now]:
        _TICKETS.pop(k, None)


def gate(acc: dict, how: str = "") -> dict:
    """Кличуть двері входу, коли ПАРОЛЬ УЖЕ ПРИЙНЯТО. Повертає None — сесію
    можна відкривати; інакше — другий крок: {"ticket", "step", "data"}."""
    if enrolled(acc["id"]):
        step, key, data = STEP_CODE, "", {}
    elif required(acc):
        key = new_secret()
        step, data = STEP_ENROLL, _enroll_view(acc.get("login"), key)
    else:
        return None
    ticket = secrets.token_urlsafe(24)
    now = _unix()
    with _LOCK:
        _prune(now)
        _TICKETS[ticket] = {"acc_id": acc["id"], "step": step, "key": key, "how": _s(how),
                            "ip": _ip(), "until": now + TICKET_MIN * 60, "fails": 0}
    return {"ticket": ticket, "step": step, "data": data}


def ticket(tk: str) -> dict:
    """Живий квиток з цієї ж адреси — або None."""
    with _LOCK:
        _prune(_unix())
        t = _TICKETS.get(_s(tk))
        if not t or t["ip"] != _ip():
            return None
        return dict(t, id=_s(tk))


def drop(tk: str):
    with _LOCK:
        _TICKETS.pop(_s(tk), None)


def failed(tk: str) -> bool:
    """Хибний код у квитку. True — квиток згорів."""
    with _LOCK:
        t = _TICKETS.get(_s(tk))
        if not t:
            return True
        t["fails"] += 1
        if t["fails"] >= TICKET_TRIES:
            _TICKETS.pop(_s(tk), None)
            return True
        return False


def check(t: dict, acc: dict, code: str) -> tuple:
    """Суддя другого кроку. -> (чим увійшли словами | "", резервні коди нового
    підключення | [])."""
    if t["step"] == STEP_ENROLL:
        with one_writer.hold():
            if _rec(_load(), acc["id"]).get("key"):
                return "", []                    # хтось уже підключив інший телефон
            step = _match_totp(t["key"], code, -1)
            if step < 0:
                return "", []
            codes = _commit(acc, t["key"], step, who_self=True)
        return "другий крок: підключено й підтверджено кодом", codes
    return _use_code(acc["id"], code), []


# ─────────────────────────── НА МАШИНІ СЕРВЕРА ─────────────────────────────
def local_reset(login: str) -> str:
    """Єдиний адміністратор загубив і телефон, і резервні коди. Скидання —
    лише з машини, де стоїть платформа (доступ до неї і є повноваження)."""
    import taskdesk_identity as identity
    acc = identity.account_by_login(login)
    if not acc:
        raise SecondFactorError("облікового запису «%s» немає" % _s(login))
    identity.reset_second_factor(acc["id"], note="скинуто на машині сервера (локально)")
    return "двофакторний вхід «%s» скинуто; при наступному вході — підключення наново" \
           % acc["login"]


if __name__ == "__main__":
    import sys
    if len(sys.argv) == 3 and sys.argv[1] == "--reset":
        try:
            print(local_reset(sys.argv[2]))
        except Exception as e:
            print("НЕ СКИНУТО: %s" % e)
            sys.exit(1)
    else:
        print("Використання: python second_factor.py --reset ЛОГІН")
        sys.exit(2)
