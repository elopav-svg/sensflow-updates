# -*- coding: utf-8 -*-
"""support_escalations.py — ЖУРНАЛ ЕСКАЛАЦІЙ БОТА ТЕХПІДТРИМКИ (зміна 691, 02.10.2026).

🩸 ЩО БУЛО. Бот техпідтримки передавав складне звернення ЛИШЕ повідомленням власнику в
Телеграм — і ніде його не записував. Пропущене повідомлення = загублене звернення, а строк
реакції за договором (1 робочий день) іде. Те саме — гілка «збій моделі» («передаю Андрію»).

⛒ ЛІК: кожна ескалація і кожен збій — рядок у журналі (JSON на рядок) у теці стану платформи.
Журнал — живий стан (у ньому дані клієнтів): не їде ні в збірку, ні в оновлення, ні в журнал
версій коду. Хто й що робить із ним далі — не справа продукту (в нас його приймає черга Офісу).

⛒ ЗАПИС НІКОЛИ НЕ ВАЛИТЬ БОТА: немає місця, зайнятий файл — `False`, і бот відповідає далі.
"""
import json
import sys
import threading
import uuid
from datetime import datetime
from pathlib import Path

import config

_LOCK = threading.Lock()
MAX_Q, MAX_NOTE = 3000, 2000


def log_path() -> Path:
    return Path(config.STATE_DIR) / "state" / "support_escalations.jsonl"


def record(who, chat_id, question, note: str = "", kind: str = "ескалація", group: bool = False,
           at: str = "") -> bool:
    """Дописати ескалацію. `False` — не вдалося (бот від цього не падає)."""
    try:
        rec = {"id": uuid.uuid4().hex[:12],
               "at": at or datetime.now().isoformat(timespec="seconds"),
               "kind": str(kind or "ескалація"), "who": str(who or "").strip(),
               "chat_id": str(chat_id or ""), "group": bool(group),
               "question": str(question or "").strip()[:MAX_Q],
               "note": str(note or "").strip()[:MAX_NOTE]}
        p = log_path()
        with _LOCK:
            p.parent.mkdir(parents=True, exist_ok=True)
            with open(p, "a", encoding="utf-8", newline="\n") as fh:
                fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return True
    except Exception as ex:
        try:
            sys.stderr.write("[ескалації] не записано: %s\n" % type(ex).__name__)
        except Exception:
            pass
        return False


def read_all(path=None) -> list:
    """Усі цілі записи журналу (битий рядок пропускається)."""
    p = Path(path) if path else log_path()
    out = []
    try:
        lines = p.read_text(encoding="utf-8").splitlines()
    except OSError:
        return out
    for ln in lines:
        try:
            r = json.loads(ln)
        except ValueError:
            continue
        if isinstance(r, dict) and r.get("id"):
            out.append(r)
    return out
