# -*- coding: utf-8 -*-
"""security_log.py — ЖУРНАЛ БЕЗПЕКИ (зміна 663, 30.09.2026).

🩸 ЩО БУЛО. Вхід, невдала спроба і вихід не лишали жодного сліду. Зміни
облікових записів і ролей лягали куцим списком усередині файлів облікових
записів і ролей: без «хто», без «звідки», без «було → стало», лише 200 останніх.
ОТУ (лист ІТ/СБ 30.09.2026) питає саме про це.

⛒ ЦЕ НЕ ДРУГИЙ ЖУРНАЛ. Рядки лягають у загальний протокол дій (`protocol`)
родиною дієслів `protocol.SECURITY_ACTIONS`: той самий писар, той самий
чистильник секретів, той самий файл невдач. Тут живе лише ПЕРЕКЛАД фактів
безпеки в рядки протоколу.

⛒ ХТО КЛИЧЕ. Не кнопки. Зміни облікових записів і ролей повідомляє ЄДИНИЙ
ПИСАР їхнього файла (`taskdesk_identity.save`, `taskdesk_roles.save`),
віддаючи сюди те, що лежало на диску, і те, що лягає. Нова дія, яка завтра
змінить запис, пройти повз журнал не зможе — її зміну побачить писар.
Вхід, невдачу і вихід повідомляють двері входу (`login`, `login_light`,
`logout`) — одні на всі канали.

⛒ ЖУРНАЛ НЕ СМІЄ ЗАВАЛИТИ РОБОТУ — але й мовчати не сміє. Уся робота тут
загорнута: поломка перекладу лягає у файл невдач протоколу, а зміна людини
лишається зробленою.

⭐ 664: тут же живе ОДИН ЧИТАЧ для екрана журналу (`journal`, `status`) —
фільтри людини, виду події й дат судяться тут, а не в сторінці.

⛒ СЕКРЕТИ. Пароль, хеш і сіль сюди не приходять як значення ніколи: зміна
пароля — своє дієслово БЕЗ «було → стало». Номер телеграм-чату — теж ні:
журнал каже «підключено / не підключено».
"""

import entity
import protocol

YES, NO = "так", "ні"
UNSET = "не призначено"


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _lost(what: str, err) -> None:
    """Поломка перекладу — голосно у файл невдач протоколу, а не в тишу."""
    try:
        protocol._fail("журнал безпеки: %s — %s: %s" % (what, type(err).__name__, err),
                       {"action": "security_log", "subject": what})
    except Exception:
        pass


# ─────────────────────────── ОБЛІКОВІ ЗАПИСИ ───────────────────────────────
def _yn(v) -> str:
    return YES if v else NO


def _layers(v) -> str:
    return ", ".join(sorted({_s(x) for x in (v or []) if _s(x)})) or "жодного"


def _orch(v) -> str:
    o = v if isinstance(v, dict) else {}
    mode = _s(o.get("mode")) or "none"
    if mode == "all":
        return "уся платформа"
    if mode == "systems":
        return "системи: " + (", ".join(sorted(_s(x) for x in (o.get("systems") or []))) or "—")
    return "нічого"


def _tg(v) -> str:
    return "підключено" if _s(v) else "не підключено"


def _emp(v) -> str:
    eid = _s(v)
    if not eid:
        return "—"
    try:
        import taskdesk_people as people
        return _s((people.employee(eid) or {}).get("full_name")) or eid
    except Exception:
        return eid


# Що саме судимо в записі і якими словами. Пароль (хеш, сіль) тут свідомо
# ВІДСУТНІЙ: для нього своє дієслово без значень.
ACCOUNT_FIELDS = (
    ("login", "логін", _s),
    ("employee_id", "працівник", _emp),
    ("is_admin", "адміністратор", _yn),
    ("active", "вхід дозволено", _yn),
    ("layers", "розділи", _layers),
    ("orchestrator", "доступ до систем", _orch),
    ("telegram_chat_id", "телеграм", _tg),
)
SECRET_FIELDS = ("pwd_hash", "salt")


def person_of(acc: dict) -> str:
    """Про кого рядок: людина запису (через працівника; без нього — сам запис)."""
    a = acc or {}
    ident = _s(a.get("employee_id")) or _s(a.get("id"))
    return entity.ref(entity.KIND_PERSON, ident) if ident else ""


def _summary(acc: dict) -> str:
    return "; ".join("%s: %s" % (label, fmt(acc.get(key)))
                     for key, label, fmt in ACCOUNT_FIELDS
                     if key not in ("employee_id", "telegram_chat_id"))


def account_events(before, after, reason: str = "") -> list:
    """Що змінилось між двома переліками записів — рядками журналу.

    Чиста функція: нічого не пише, лише каже. Порядок — порядок записів."""
    old = {_s(a.get("id")): a for a in (before or []) if isinstance(a, dict)}
    new = {_s(a.get("id")): a for a in (after or []) if isinstance(a, dict)}
    why = _s(reason)
    out = []
    for aid, a in new.items():
        if aid not in old:
            out.append({"action": protocol.A_ACC_CREATED, "subject": person_of(a),
                        "changes": [], "note": "; ".join(x for x in (why, _summary(a)) if x)})
            continue
        b = old[aid]
        chs = []
        for key, label, fmt in ACCOUNT_FIELDS:
            was, now = fmt(b.get(key)), fmt(a.get(key))
            if was != now:
                chs.append((label, was, now))
        if chs:
            out.append({"action": protocol.A_ACC_CHANGED, "subject": person_of(a),
                        "changes": chs, "note": why})
        if any(_s(b.get(k)) != _s(a.get(k)) for k in SECRET_FIELDS):
            out.append({"action": protocol.A_ACC_PASSWORD, "subject": person_of(a),
                        "changes": [], "note": why})
    for aid, b in old.items():
        if aid not in new:
            out.append({"action": protocol.A_ACC_REMOVED, "subject": person_of(b),
                        "changes": [],
                        "note": "; ".join(x for x in (why, "логін «%s»" % _s(b.get("login"))) if x)})
    return out


def accounts_changed(before, after, reason: str = "") -> int:
    """Кличе ЄДИНИЙ писар облікових записів після запису на диск. Не кидає."""
    try:
        evs = account_events(before, after, reason)
    except Exception as e:
        _lost("не вдалося порівняти облікові записи", e)
        return 0
    return _write_all(evs)


# ─────────────────────────────── РОЛІ ──────────────────────────────────────
def _role_names():
    try:
        import taskdesk_roles as roles
        return dict(roles.ALL_PERM_NAMES)
    except Exception:
        return {}


def _holder(key: str) -> str:
    """«emp:X» → людина X, «unit:Y» → підрозділ Y."""
    kind, _sep, ident = _s(key).partition(":")
    if kind == "emp":
        return entity.ref(entity.KIND_PERSON, ident)
    if kind == "unit":
        return entity.ref(entity.KIND_UNIT, ident)
    return ""


def role_events(before, after, reason: str = "") -> list:
    """Що змінилось у ролях: нова роль, клітинка матриці, назва, призначення."""
    b = before if isinstance(before, dict) else {}
    a = after if isinstance(after, dict) else {}
    why = _s(reason)
    names = _role_names()
    old = {_s(r.get("id")): r for r in (b.get("roles") or []) if isinstance(r, dict)}
    new = {_s(r.get("id")): r for r in (a.get("roles") or []) if isinstance(r, dict)}

    def rname(rid):
        r = new.get(rid) or old.get(rid) or {}
        return _s(r.get("name")) or _s(rid) or UNSET

    out = []
    for rid, r in new.items():
        subj = entity.ref(entity.KIND_ROLE, rid)
        if rid not in old:
            out.append({"action": protocol.A_ROLE_CREATED, "subject": subj, "changes": [],
                        "note": "; ".join(x for x in (why, "«%s»" % rname(rid)) if x)})
            continue
        o = old[rid]
        chs = []
        if _s(o.get("name")) != _s(r.get("name")):
            chs.append(("назва", _s(o.get("name")), _s(r.get("name"))))
        op, np_ = o.get("perms") or {}, r.get("perms") or {}
        for p in sorted(set(op) | set(np_)):
            if bool(op.get(p)) != bool(np_.get(p)):
                chs.append((names.get(p) or p, _yn(op.get(p)), _yn(np_.get(p))))
        if chs:
            out.append({"action": protocol.A_ROLE_CHANGED, "subject": subj,
                        "changes": chs, "note": why})
    for rid in old:
        if rid not in new:
            # Прибирача ролей у платформі немає; якщо роль усе ж зникла —
            # це факт, а не тиша.
            out.append({"action": protocol.A_ROLE_CHANGED,
                        "subject": entity.ref(entity.KIND_ROLE, rid),
                        "changes": [("роль існує", YES, NO)], "note": why})

    oa, na = b.get("assign") or {}, a.get("assign") or {}
    for key in sorted(set(oa) | set(na)):
        was, now = _s(oa.get(key)), _s(na.get(key))
        if was == now:
            continue
        subj = _holder(key)
        if not subj:
            continue
        about = [entity.ref(entity.KIND_ROLE, x) for x in (now, was) if x][:1]
        out.append({"action": protocol.A_ROLE_ASSIGNED, "subject": subj, "about": about,
                    "changes": [("роль", rname(was) if was else UNSET,
                                 rname(now) if now else UNSET)], "note": why})
    od, nd = _s(b.get("default_role")), _s(a.get("default_role"))
    if b and od != nd:
        out.append({"action": protocol.A_ROLE_ASSIGNED,
                    "subject": entity.ref(entity.KIND_ORG, entity.ORG_COMPANY),
                    "about": [entity.ref(entity.KIND_ROLE, nd)] if nd else [],
                    "changes": [("роль за замовчуванням", rname(od), rname(nd))],
                    "note": why})
    return out


def roles_changed(before, after, reason: str = "") -> int:
    """Кличе ЄДИНИЙ писар ролей після запису на диск. Не кидає."""
    try:
        evs = role_events(before, after, reason)
    except Exception as e:
        _lost("не вдалося порівняти ролі", e)
        return 0
    return _write_all(evs)


def _write_all(evs) -> int:
    n = 0
    for ev in evs:
        if protocol.write(ev["action"], ev["subject"], about=ev.get("about"),
                          changes=ev.get("changes"), note=ev.get("note", "")):
            n += 1
    return n


# ─────────────────────────── ВХІД І ВИХІД ──────────────────────────────────
# ⛒ Тут контекст запиту беремо ЛИШЕ «звідки» і «яким каналом». «Хто» кажемо
# самі: у людини, що тільки стукає, ще немає імені, а господар машини в
# одноосібному режимі стуканням не займався — приписати йому чужу невдалу
# спробу означало б збрехати саме там, де журнал читають найуважніше.
def _door(action, subject, actor="", outcome=protocol.OUT_OK, note="") -> bool:
    try:
        ctx = protocol.context()
        return protocol.write(action, subject, actor=actor, outcome=outcome,
                              source=_s(ctx.get("source")), ip=_s(ctx.get("ip")),
                              note=note, use_context=False)
    except Exception as e:
        _lost("вхід не записано", e)
        return False


def login_ok(acc: dict, how: str = "") -> bool:
    who = person_of(acc)
    return _door(protocol.A_AUTH_LOGIN, who, actor=who,
                 note="; ".join(x for x in ("логін «%s»" % _s((acc or {}).get("login")),
                                            _s(how)) if x))


def login_failed(login_name, acc, why: str) -> bool:
    """Невдала спроба: про людину, під чиїм логіном стукали, або — якщо такого
    логіна немає — про компанію. Діяча НЕМАЄ: хто стукав, невідомо."""
    subj = person_of(acc) if acc else entity.ref(entity.KIND_ORG, entity.ORG_COMPANY)
    return _door(protocol.A_AUTH_FAILED, subj, actor="",
                 outcome="%s: %s" % (protocol.OUT_REFUSED, _s(why)),
                 note="логін «%s»" % _s(login_name)[:64])


def logout(acc: dict) -> bool:
    who = person_of(acc)
    return _door(protocol.A_AUTH_LOGOUT, who, actor=who,
                 note="логін «%s»" % _s((acc or {}).get("login")))


# ─────────────────────── ДВОФАКТОРНИЙ ВХІД (зміна 666) ─────────────────────
def second_factor_event(action, acc, changes=None, note="", actor_self=False) -> bool:
    """Підключено / вимкнено чи скинуто / нові резервні коди / вимогу змінено.
    Про людину запису (або про компанію — для вимоги). Діяч — з контексту
    запиту (адміністратор за екраном); людина, що підключає САМА, — вона ж.
    ⛒ Ні таємниці, ні коду тут не буває: їх сюди просто не передають."""
    try:
        subj = person_of(acc) if acc else entity.ref(entity.KIND_ORG, entity.ORG_COMPANY)
        return protocol.write(action, subj, actor=subj if actor_self else "",
                              changes=changes or [], note=_s(note))
    except Exception as e:
        _lost("подію двофакторного входу не записано", e)
        return False


# ─────────────────────── ВИВАНТАЖЕННЯ ДАНИХ (зміна 669) ────────────────────
def data_export(what: str, rows=0, note: str = "", refused: str = "") -> bool:
    """Вивантаження (або відмова в ньому): ЩО, СКІЛЬКИ РЯДКІВ і за якими умовами.
    Діяч і «про кого» — людина з контексту запиту: вивантажила вона, і фільтр
    «Людина» на екрані журналу мусить її знаходити. Самих даних рядок не несе.
    `refused` — чому не пустили (тоді рядок позначено «відмовлено»)."""
    try:
        ctx = protocol.context()
        who = _s(ctx.get("actor"))
        subj = (who if who.startswith(entity.KIND_PERSON + ":")
                else entity.ref(entity.KIND_ORG, entity.ORG_COMPANY))
        try:
            n = int(rows or 0)
        except (TypeError, ValueError):
            n = 0
        text = "; ".join(x for x in (_s(what), "рядків: %d" % n, _s(note)) if x)
        out = ("%s: %s" % (protocol.OUT_REFUSED, _s(refused))) if refused else protocol.OUT_OK
        return protocol.write(protocol.A_DATA_EXPORT, subj, outcome=out, note=text[:600])
    except Exception as e:
        _lost("вивантаження не записано", e)
        return False


# ─────────────────────── ПОШТА ДЛЯ СПОВІЩЕНЬ (зміна 685) ───────────────────
def notify_mail_event(changes=None, note: str = "") -> bool:
    """Скриньку платформи заведено, змінено чи відключено: було → стало.
    Про компанію (скринька — її), діяч — з контексту запиту.
    ⛒ Пароля тут не буває: його сюди просто не передають."""
    try:
        subj = entity.ref(entity.KIND_ORG, entity.ORG_COMPANY)
        return protocol.write(protocol.A_NOTIFY_MAIL, subj, changes=changes or [],
                              note=_s(note)[:300])
    except Exception as e:
        _lost("зміну пошти для сповіщень не записано", e)
        return False


# ─────────────────────── ЛИСТ ДОСТУПУ І АДРЕСА (зміна 696) ─────────────────
def access_letter(acc: dict, to: str, ok: bool, why: str = "") -> bool:
    """Лист доступу працівнику: кому, пішов чи ні і чому. Про людину запису,
    діяч — з контексту запиту (адміністратор за екраном).
    ⛒ Токена посилання тут не буває: його сюди просто не передають."""
    try:
        out = protocol.OUT_OK if ok else "%s: %s" % (protocol.OUT_FAILED, _s(why)[:300])
        return protocol.write(protocol.A_ACC_LETTER, person_of(acc), outcome=out,
                              note=("лист на %s" % _s(to)) if _s(to) else "адреси немає")
    except Exception as e:
        _lost("лист доступу не записано", e)
        return False


def access_settings(changes=None, note: str = "") -> bool:
    """Адреса для працівників і довірений проксі: було → стало. Про компанію."""
    try:
        subj = entity.ref(entity.KIND_ORG, entity.ORG_COMPANY)
        return protocol.write(protocol.A_ACCESS_SETTINGS, subj, changes=changes or [],
                              note=_s(note)[:300])
    except Exception as e:
        _lost("зміну адреси для працівників не записано", e)
        return False


# ─────────────────────── ЧИТАЧ ДЛЯ ЕКРАНА (зміна 664) ──────────────────────
# ⭐⭐⭐ 664. Екран журналу безпеки питає ОДНОГО читача. Фільтри — людина, вид
# події, дати — судяться тут, а не в сторінці: сторінка отримує вже готову
# сторінку рядків і слова, а не сирий файл.
# ⛒ Невідомий вид чи дата, що не є датою, — відмова словами, а не «покажу
# усе»: адміністратор, що шукає невдалі спроби, не сміє мовчки отримати інше.
class JournalError(Exception):
    """Відмова читача з причиною словами."""


KINDS = (
    ("logins", "Входи й виходи", (protocol.A_AUTH_LOGIN, protocol.A_AUTH_LOGOUT)),
    ("failed", "Невдалі спроби входу", (protocol.A_AUTH_FAILED, protocol.A_AUTH_LOCKED)),
    ("accounts", "Облікові записи", (protocol.A_ACC_CREATED, protocol.A_ACC_CHANGED,
                                     protocol.A_ACC_PASSWORD, protocol.A_ACC_REMOVED,
                                     protocol.A_ACC_LETTER)),
    ("roles", "Ролі й права", (protocol.A_ROLE_CREATED, protocol.A_ROLE_CHANGED,
                              protocol.A_ROLE_ASSIGNED)),
    ("second_factor", "Двофакторний вхід", (protocol.A_TFA_ON, protocol.A_TFA_OFF,
                                            protocol.A_TFA_CODES, protocol.A_TFA_POLICY)),
    ("exports", "Вивантаження даних", (protocol.A_DATA_EXPORT,)),
    ("notify_mail", "Пошта для сповіщень", (protocol.A_NOTIFY_MAIL,)),
    ("access_settings", "Адреса для працівників і проксі", (protocol.A_ACCESS_SETTINGS,)),
)
KIND_OF = {a: k for k, _n, acts in KINDS for a in acts}
PAGE = 100
PAGE_MAX = 500
# Скільки невдалих спроб за добу — привід сказати про це на домашній.
# Те саме число, що й межа захисту від підбору (665): п'ять — уже не помилка
# пальців. ⛒ Одне число, а не два однакових: `LOCK_AFTER` нижче.


def _iso_day(v, what) -> str:
    s = _s(v)
    if not s:
        return ""
    import re
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", s) or None
    if not m:
        m2 = re.match(r"^(\d{2})\.(\d{2})\.(\d{4})$", s)
        if not m2:
            raise JournalError("«%s» (%s) не є датою: потрібно ДД.ММ.РРРР." % (s[:20], what))
        s = "%s-%s-%s" % (m2.group(3), m2.group(2), m2.group(1))
    import datetime as _dt
    try:
        _dt.date.fromisoformat(s)
    except ValueError:
        raise JournalError("Дати «%s» (%s) не існує." % (_s(v)[:20], what))
    return s


def _dmy(iso) -> str:
    s = _s(iso)
    return "%s.%s.%s" % (s[8:10], s[5:7], s[0:4]) if len(s) >= 10 else s


def journal(who: str = "", kind: str = "", date_from: str = "", date_to: str = "",
            offset=0, limit=PAGE) -> dict:
    """Сторінка журналу безпеки для екрана адміністратора. Свіжіші — першими.

    who  — посилання на людину («person:…»): рядки, де вона ДІЯЛА або ПРО неї;
    kind — вид події з `KINDS` (порожньо — усі);
    date_from / date_to — межі днів включно (ДД.ММ.РРРР або РРРР-ММ-ДД)."""
    kinds = {k: acts for k, _n, acts in KINDS}
    kd = _s(kind)
    if kd and kd not in kinds:
        raise JournalError("Невідомий вид події «%s». Буває: %s."
                           % (kd[:30], ", ".join(n for _k, n, _a in KINDS)))
    wref = _s(who)
    if wref:
        try:
            wref = entity.norm(wref)
        except Exception:
            raise JournalError("«%s» не є посиланням на людину." % wref[:40])
    d1, d2 = _iso_day(date_from, "з"), _iso_day(date_to, "по")
    if d1 and d2 and d1 > d2:
        raise JournalError("Початок періоду (%s) пізніший за кінець (%s)." % (_dmy(d1), _dmy(d2)))
    try:
        off = max(0, int(offset or 0))
        lim = max(1, min(PAGE_MAX, int(limit or PAGE)))
    except (TypeError, ValueError):
        raise JournalError("Номер сторінки має бути числом.")

    rows = [r for r in protocol.read(security=True) if r.get("action") in KIND_OF]
    people = {}
    for r in rows:
        for ref in (_s(r.get("actor")), _s(r.get("subject"))):
            if ref.startswith(entity.KIND_PERSON + ":") and ref not in people:
                people[ref] = ""
    hits = []
    # ⛒ Свіжіші — першими ЗА ЧАСОМ ПОДІЇ, а не за місцем у файлі: рядок,
    # дописаний пізніше (перенесений, відновлений з копії), не сміє стати
    # «найсвіжішим» лише тому, що ліг останнім.
    for r in sorted(rows, key=lambda x: _s(x.get("at")), reverse=True):
        day = _s(r.get("at"))[:10]
        if kd and r.get("action") not in kinds[kd]:
            continue
        if wref and wref not in (_s(r.get("actor")), _s(r.get("subject"))):
            continue
        if d1 and day < d1:
            continue
        if d2 and day > d2:
            continue
        hits.append(r)
    names = {}

    def name(ref):
        if not ref:
            return ""
        if ref not in names:
            try:
                names[ref] = entity.title(ref) or ref
            except Exception:
                names[ref] = ref
        return names[ref]

    page = []
    for r in hits[off:off + lim]:
        at = _s(r.get("at"))
        page.append({
            "at": at, "date": _dmy(at), "time": at[11:19],
            "action": r.get("action"), "kind": KIND_OF.get(r.get("action"), ""),
            "what": protocol.ACTIONS.get(r.get("action"), r.get("action")),
            "refused": r.get("outcome") == protocol.OUT_REFUSED,
            "who": name(_s(r.get("actor"))), "who_ref": _s(r.get("actor")),
            "about": name(_s(r.get("subject"))), "about_ref": _s(r.get("subject")),
            "ip": _s(r.get("ip")), "reason": _s(r.get("reason")),
            "note": _s(r.get("note")), "source": _s(r.get("source")),
            "changes": list(r.get("changes") or []),
        })
    plist = sorted(({"ref": ref, "name": name(ref)} for ref in people),
                   key=lambda x: x["name"].lower())
    return {"rows": page, "total": len(hits), "offset": off, "limit": lim,
            "more": off + lim < len(hits),
            "kinds": [{"id": k, "name": n} for k, n, _a in KINDS],
            # ⛒ Дати фільтра повертаються РРРР-ММ-ДД: саме так їх бере поле дати
            # в браузері; на екрані людина бачить їх у своєму форматі.
            "people": plist, "filters": {"who": wref, "kind": kd, "from": d1, "to": d2},
            "status": status(rows)}


def status(rows=None) -> dict:
    """Коротко для домашньої: скільки невдалих спроб і входів за останню добу."""
    import datetime as _dt
    import clock
    now = _dt.datetime.fromisoformat(clock.now())
    edge = (now - _dt.timedelta(hours=24)).isoformat(timespec="seconds")
    rs = rows if rows is not None else protocol.read(security=True)
    fresh = [r for r in rs if _s(r.get("at")) >= edge]
    failed = [r for r in fresh if r.get("action") == protocol.A_AUTH_FAILED]
    return {"failed_24h": len(failed),
            "logins_24h": len([r for r in fresh if r.get("action") == protocol.A_AUTH_LOGIN]),
            "last_failed_at": _s(failed[-1].get("at")) if failed else "",
            "warn": len(failed) >= FAILED_WARN, "warn_at": FAILED_WARN}


# ─────────────────────── ЗАХИСТ ВІД ПІДБОРУ (зміна 665) ────────────────────
# ⭐⭐⭐ 665. ЛІЧИЛЬНИК — ЦЕ САМ ЖУРНАЛ. Невдалі спроби вже лежать тут з адресою
# і людиною; окремий файл лічильника був би другою правдою про те саме, яка
# розійдеться з першою. Суддя читає лише хвіст за останні `LOCK_MIN` хвилин
# (`protocol.read_since`) і тому однаково швидкий і в перший день, і через рік.
# ⛒ КЛЮЧ — «АДРЕСА + ЛЮДИНА». За самим логіном чужий міг би з будь-якої машини
# заблокувати директора. Невідомі логіни з однієї адреси — спільний кошик
# (компанія): відповідь та сама, що й для відомих, список логінів не вивчити.
# ⛒ АДРЕСА ЗАГАЛОМ — `IP_LOCK_AFTER`: інакше перебір ішов би по всіх логінах
# по черзі, по чотири спроби на кожен.
# ⛒ ЖУРНАЛ НЕ ЧИТАЄТЬСЯ — ВХІД НЕ ЗАМИКАЄТЬСЯ (fail-open), але голосно:
# поломка лягає у файл невдач. Замкнути всю компанію через побитий рядок —
# гірше, ніж на хвилину лишитись без лічильника.
LOCK_AFTER = 5          # невдач поспіль з однієї адреси на одну людину
LOCK_MIN = 15           # скільки триває пауза, хвилин
IP_LOCK_AFTER = 20      # невдач з однієї адреси на будь-кого за `LOCK_MIN`
FAILED_WARN = LOCK_AFTER


def _now_dt():
    import datetime as _dt
    import clock
    return _dt.datetime.fromisoformat(clock.now())


def _at(r):
    import datetime as _dt
    try:
        return _dt.datetime.fromisoformat(_s(r.get("at")))
    except Exception:
        return None


def _door_key(acc) -> tuple:
    ip = _s(protocol.context().get("ip"))
    subj = person_of(acc) if acc else entity.ref(entity.KIND_ORG, entity.ORG_COMPANY)
    return ip, subj


def _recent(now):
    import datetime as _dt
    edge = (now - _dt.timedelta(minutes=LOCK_MIN)).isoformat(timespec="seconds")
    return protocol.read_since(edge, security=True)


def _left_min(since_dt, now) -> int:
    """Хвилин до кінця паузи, що почалась у `since_dt` (вгору, не менше 1)."""
    import math
    secs = LOCK_MIN * 60 - (now - since_dt).total_seconds()
    return max(1, int(math.ceil(secs / 60.0))) if secs > 0 else 0


def _state(acc):
    now = _now_dt()
    ip, subj = _door_key(acc)
    mine = [r for r in _recent(now) if _s(r.get("ip")) == ip]
    return now, ip, subj, mine


def pause_left(acc) -> int:
    """Скільки хвилин ще триває пауза для цієї людини з цієї адреси (або для
    всієї адреси). 0 — входити можна. Питають двері входу ДО перевірки пароля."""
    try:
        now, ip, subj, mine = _state(acc)
        locks = [r for r in mine if r.get("action") == protocol.A_AUTH_LOCKED
                 and _s(r.get("subject")) == subj and _at(r)]
        if locks:
            left = _left_min(_at(locks[-1]), now)
            if left:
                return left
        fails = sorted((r for r in mine if r.get("action") == protocol.A_AUTH_FAILED and _at(r)),
                       key=lambda r: _s(r.get("at")))
        if len(fails) >= IP_LOCK_AFTER:
            return _left_min(_at(fails[len(fails) - IP_LOCK_AFTER]), now)
        return 0
    except Exception as e:
        _lost("суддя паузи не прочитав журнал (вхід не замкнено)", e)
        return 0


def after_failure(acc) -> int:
    """Кличуть двері входу ПІСЛЯ запису невдачі. Якщо це межа — один рядок
    «вхід призупинено» і хвилини паузи; інакше 0."""
    try:
        now, ip, subj, mine = _state(acc)
        # Рахунок пари — від останнього вдалого входу цієї людини з цієї адреси.
        # ⛒ Пауза триває рівно `LOCK_MIN` — стільки ж, скільки вікно
        # лічильника: до її кінця всі невдачі, що її поставили, вже поза
        # вікном, тож окремої мітки «після паузи» не треба.
        mark = ""
        for r in mine:
            if _s(r.get("subject")) == subj and r.get("action") == protocol.A_AUTH_LOGIN:
                mark = max(mark, _s(r.get("at")))
        pair = [r for r in mine if r.get("action") == protocol.A_AUTH_FAILED
                and _s(r.get("subject")) == subj and _s(r.get("at")) > mark]
        every = [r for r in mine if r.get("action") == protocol.A_AUTH_FAILED]
        if len(pair) >= LOCK_AFTER:
            why = "%d невдалих спроб поспіль з цієї адреси — пауза %d хв" % (len(pair), LOCK_MIN)
            _door(protocol.A_AUTH_LOCKED, subj, actor="",
                  outcome="%s: %s" % (protocol.OUT_REFUSED, why))
            return LOCK_MIN
        if len(every) == IP_LOCK_AFTER:
            why = ("%d невдалих спроб з цієї адреси за %d хв на різних людей — пауза для "
                   "всієї адреси" % (len(every), LOCK_MIN))
            _door(protocol.A_AUTH_LOCKED,
                  entity.ref(entity.KIND_ORG, entity.ORG_COMPANY), actor="",
                  outcome="%s: %s" % (protocol.OUT_REFUSED, why))
            return LOCK_MIN
        return 0
    except Exception as e:
        _lost("суддя паузи не прочитав журнал (пауза не поставлена)", e)
        return 0
