"""
store.py — збереження запусків (runs) і артефактів. UTF-8 без BOM.
"""

import json
import re
import time
import uuid
from datetime import datetime
from pathlib import Path

import config

# Транслітерація укр/рос → латиниця для читабельних імен файлів і тек.
_TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "h", "ґ": "g", "д": "d", "е": "e", "є": "ie",
    "ж": "zh", "з": "z", "и": "y", "і": "i", "ї": "i", "й": "i", "к": "k", "л": "l",
    "м": "m", "н": "n", "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u",
    "ф": "f", "х": "kh", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "shch", "ь": "",
    "ю": "iu", "я": "ia", "ё": "e", "ы": "y", "э": "e", "ъ": "",
}


def slugify(text: str, maxlen: int = 48) -> str:
    """Читабельний слаг латиницею: «Стратегія розвитку» -> 'strategiia-rozvytku'."""
    s = (text or "").strip().lower()
    s = "".join(_TRANSLIT.get(ch, ch) for ch in s)
    s = re.sub(r"[^a-z0-9]+", "-", s).strip("-")
    return s[:maxlen].strip("-")


def new_run_id(label: str = "") -> str:
    ts = datetime.now().strftime("%Y-%m-%dT%H-%M-%S")
    slug = slugify(label, 40)
    if slug:
        return f"run-{ts}-{slug}-{uuid.uuid4().hex[:4]}"
    return f"run-{ts}-{uuid.uuid4().hex[:6]}"


# ⛒⛒⛒ 670 (01.10.2026). ОДИН ПИСАР ШЛЯХУ ПРОГОНУ.
# 🩸 Двері `/artifacts/<прогін>/<файл>` складали шлях `RUNS_DIR / прогін / файл`:
# ім'я файла чистилось, а номер прогону — ні. `/artifacts/../top.txt` віддавав
# файл із теки стану, а на Windows `..\taskdesk\accounts.json` — будь-який
# файл стану (облікові записи, ключі другого фактора, уся CRM повз видимість)
# кожному, хто увійшов. Тому номер прогону — із закритого алфавіту, ім'я файла —
# лише ім'я без розділювачів. ⛒ Охорона ОДНА (алфавіт), без «про всяк випадок»
# поруч: подвійна охорона ховає дірку — жодна мутація не довела б, що друга
# працює (урок 594). Хто складає `RUNS_DIR / …` повз цього писаря — судить
# `run_artifacts_670_test`.
_RUN_ID_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,200}")
_FILE_BAD = set('/\\:*?"<>|' + "".join(chr(c) for c in range(32)))


class StoreError(ValueError):
    """Номер прогону чи ім'я файла не з дозволеного алфавіту."""


def _run_path(run_id: str, filename=None) -> Path:
    rid = str(run_id or "")
    if not _RUN_ID_RE.fullmatch(rid):
        raise StoreError("Номер прогону «%s» не з дозволеного алфавіту." % rid[:60])
    base = (config.RUNS_DIR / rid)
    if filename is not None:
        name = str(filename or "")
        if (not name or name in (".", "..") or any(ch in _FILE_BAD for ch in name)):
            raise StoreError("Ім'я файла «%s» — не просто ім'я." % name[:60])
        base = base / name
    return base


def run_dir(run_id: str) -> Path:
    d = _run_path(run_id)
    d.mkdir(parents=True, exist_ok=True)
    return d


def run_exists(run_id: str) -> bool:
    """Чи є такий прогін. Нічого не створює; поганий номер — «ні»."""
    try:
        return _run_path(run_id).is_dir()
    except StoreError:
        return False


def write_artifact(run_id: str, filename: str, content: str) -> dict:
    d = run_dir(run_id)
    path = d / filename
    path.write_text(content, encoding="utf-8")
    return {
        "filename": filename,
        "path": str(path),
        "url": f"/artifacts/{run_id}/{filename}",
    }


def save_run(record: dict):
    run_id = record.get("run_id") or new_run_id()
    record["run_id"] = run_id
    record.setdefault("created_at", datetime.now().isoformat())
    path = run_dir(run_id) / "run.json"
    path.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    return record


def list_runs(limit: int = 60) -> list:
    if not config.RUNS_DIR.exists():
        return []
    runs = []
    for d in sorted(config.RUNS_DIR.iterdir(), reverse=True):
        rj = d / "run.json"
        if rj.exists():
            try:
                data = json.loads(rj.read_text(encoding="utf-8"))
                runs.append(
                    {
                        "run_id": data.get("run_id"),
                        "created_at": data.get("created_at"),
                        "status": data.get("status"),
                        "system_id": data.get("system_id"),
                        "task": (data.get("task") or "")[:160],
                    }
                )
            except Exception:
                continue
        if len(runs) >= limit:
            break
    return runs


def artifact_path(run_id: str, filename: str) -> Path:
    """Шлях до результату прогону. Поганий номер чи ім'я — `StoreError` (670)."""
    return _run_path(run_id, filename)


def list_artifacts(run_id: str) -> list:
    """Файли-результати запуску (без службового run.json) з посиланнями на завантаження."""
    try:
        d = _run_path(run_id)
    except StoreError:
        return []
    if not d.exists():
        return []
    out = []
    for p in sorted(d.iterdir()):
        if not p.is_file() or p.name == "run.json":
            continue
        out.append({"filename": p.name, "path": str(p), "url": f"/artifacts/{run_id}/{p.name}"})
    return out
