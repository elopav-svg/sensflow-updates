# -*- coding: utf-8 -*-
"""data_copy.py — ЩОДЕННА КОПІЯ ДАНИХ У ТЕКУ КОМПАНІЇ (зміна 687, 02.10.2026).

🩸 ОБІЦЯНКА БЕЗ МЕХАНІЗМУ. Лист ОТУ 30.09.2026, п. 2: «платформа будет ежедневно
сама складывать копию своих данных в указанную вами сетевую папку». У продукті був
лише ручний архів кнопкою («Забрати свої дані», `client_export`).

⛒ ЗАКОНИ ЦЬОГО МОДУЛЯ:
  1. КОПІЯ — ТОЙ САМИЙ АРХІВ, ЩО Й «ЗАБРАТИ СВОЇ ДАНІ». Що є даними клієнта, каже
     один суддя (`client_export` → `state_files`); другого переліку тут немає.
     Секретів у копії немає за тією ж побудовою.
  2. ТЕКА ПЕРЕВІРЯЄТЬСЯ ЗАПИСОМ ОДРАЗУ — тим самим процесом (служба платформи),
     що потім писатиме копію вночі. Мережева тека, куди служба не має права
     писати, — відмова словами при збереженні, а не тиша о 01:00.
  3. ОДНА ЩОДЕННА РОБОТА БЕЗ МОДЕЛІ на 01:00 (`scheduler.create_data_sync` сам не
     дає дубля). Коштує $0.
  4. ТРИМАЄМО ОСТАННІ N КОПІЙ — лише свої (за префіксом архіву); чужих файлів у
     теці не чіпаємо.
  5. ВІДМОВА — СЛОВАМИ, НЕ ПАДІННЯ. Зникла тека, повний диск — причина в звіті
     роботи, який видно на екрані «Автоматизації».

Налаштування — у `.env.local` (`DATA_COPY_DIR`, `DATA_COPY_KEEP`): це місце машини,
воно не їде ні в збірку, ні в оновлення.
"""
import os
from datetime import datetime, timedelta
from pathlib import Path

import config

KEY_DIR, KEY_KEEP = "DATA_COPY_DIR", "DATA_COPY_KEEP"
KEEP_DEFAULT, KEEP_MAX = 14, 365
JOB = "data_copy"
JOB_NAME = "Щоденна копія даних"
RUN_AT = "01:00"


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _keep() -> int:
    try:
        n = int(_s(config.ENV.get(KEY_KEEP)) or KEEP_DEFAULT)
    except ValueError:
        n = KEEP_DEFAULT
    return max(1, min(KEEP_MAX, n))


def settings() -> dict:
    folder = _s(config.ENV.get(KEY_DIR))
    return {"folder": folder, "keep": _keep(), "configured": bool(folder), "run_at": RUN_AT}


def _check_folder(folder: str) -> str:
    """-> порожньо, якщо в теку можна писати; інакше причина словами (закон 2)."""
    if not folder:
        return "Теку для щоденної копії не задано."
    p = Path(folder)
    try:
        if not p.is_dir():
            return ("Теки «%s» не видно з сервера платформи. Для мережевої теки перевірте "
                    "шлях (\\\\сервер\\тека) і що комп'ютер платформи має до неї доступ." % folder)
        probe = p / (".sensflow_probe_%d.tmp" % os.getpid())
        probe.write_bytes(b"sensflow")
        probe.unlink()
    except OSError as ex:
        return ("У теку «%s» служба платформи не може писати (%s). Дайте комп'ютеру "
                "платформи право запису в цю теку." % (folder, ex.strerror or ex))
    return ""


def ready():
    """(готова?, чому ні) — для реєстру робіт без моделі (`data_jobs`)."""
    s = settings()
    if not s["folder"]:
        return (False, "теку для копії ще не задано (екран «Автоматизації», картка «%s»)" % JOB_NAME)
    return (True, "")


def _next_run() -> str:
    now = datetime.now()
    h, m = (int(x) for x in RUN_AT.split(":"))
    at = now.replace(hour=h, minute=m, second=0, microsecond=0)
    if at <= now:
        at += timedelta(days=1)
    return at.strftime("%Y-%m-%dT%H:%M")


def save_settings(folder: str, keep=None) -> dict:
    """Задати теку і скільки копій тримати. Спершу перевірка записом, потім збереження."""
    folder = _s(folder)
    try:
        keep = int(keep) if _s(keep) else _keep()
    except (TypeError, ValueError):
        return {"ok": False, "message": "Скільки копій тримати — це число від 1 до %d." % KEEP_MAX}
    if not 1 <= keep <= KEEP_MAX:
        return {"ok": False, "message": "Скільки копій тримати — від 1 до %d, а не %d." % (KEEP_MAX, keep)}
    why = _check_folder(folder)
    if why:
        return {"ok": False, "message": why}
    config.update_env_local({KEY_DIR: folder, KEY_KEEP: str(keep)})
    config.ENV[KEY_DIR], config.ENV[KEY_KEEP] = folder, str(keep)
    import scheduler
    rec = scheduler.create_data_sync(JOB_NAME, JOB, "щодня")
    if rec and rec.get("id"):
        scheduler.set_schedule(rec["id"], next_run_at=_next_run())
    return {"ok": True, "message": "Теку збережено. Копія робитиметься щодня о %s." % RUN_AT,
            "settings": settings()}


def _ours(p: Path) -> bool:
    import client_export
    return p.is_file() and p.name.startswith(client_export.ARCHIVE_PREFIX) and p.suffix == ".zip"


def run_job(root=None) -> dict:
    """Робота за розкладом: покласти копію в теку і лишити останні N. Ніколи не кидає."""
    import client_export
    s = settings()
    why = _check_folder(s["folder"])
    if why:
        return {"status": "failed", "summary": "Копію не зроблено. " + why}
    dest = Path(s["folder"])
    stamp = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    out = dest / ("%s%s.zip" % (client_export.ARCHIVE_PREFIX, stamp))
    n = 2
    while out.exists():
        out = dest / ("%s%s_%d.zip" % (client_export.ARCHIVE_PREFIX, stamp, n))
        n += 1
    try:
        res = client_export.export(root=root, out_path=out)
    except Exception as ex:
        return {"status": "failed", "summary": "Копію не зроблено: %s" % ex}
    if not res.get("ok"):
        return {"status": "failed", "summary": "Копію не зроблено. %s" % _s(res.get("message"))}
    removed = 0
    mine = sorted((p for p in dest.iterdir() if _ours(p)), key=lambda p: (p.stat().st_mtime, p.name))
    for old in mine[:-s["keep"]] if len(mine) > s["keep"] else []:
        try:
            old.unlink()
            removed += 1
        except OSError:
            pass
    return {"status": "completed",
            "summary": ("Копію даних збережено: %s (файлів %d, %.1f МБ). У теці лишено "
                        "останніх копій: %d%s."
                        % (out, res.get("files", 0), res.get("bytes", 0) / 1048576.0,
                           min(len(mine), s["keep"]),
                           ("; старих прибрано: %d" % removed) if removed else "")),
            "path": str(out)}
