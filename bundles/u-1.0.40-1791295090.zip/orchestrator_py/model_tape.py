# -*- coding: utf-8 -*-
"""model_tape.py — ЗАПИС ВІДПОВІДЕЙ МОДЕЛІ В ЖИВИХ ПРОГОНАХ (674).

⛒⛒ 674, 01.10.2026. ПЛАТНИЙ ПРОГІН МАЄ БУТИ ПІДТВЕРДЖЕННЯМ, А НЕ ТЕСТОМ.
🩸 Андрій: «Ти впевнений, що прогін за гроші буде лише підтвердженням, а не тестом на
нові вади?» Живий прогін Каспера (~16:45, $1,84) знайшов ваду воріт — і щоб довести
лік, довелось би платити ще раз: відповіді моделі ніде не лишились.
⛒ ПРАВИЛО. На машині розробки (еталон: є реєстр робіт) кожна відповідь моделі
пишеться на стрічку — ЩО питала платформа і ЩО відповіла модель. Репетиція
(`chain_rehearsal_674_test.py --tape <файл>`) відтворює живий прогін через новий код
БЕЗКОШТОВНО, скільки завгодно разів. У КЛІЄНТА стрічки НЕМАЄ: там реєстру робіт
немає, і чужі відповіді моделі ми на його машині не накопичуємо.
"""
import hashlib
import json
import time

_CAP = 300000          # більше однієї великої відповіді моделі не буває


def enabled() -> bool:
    try:
        import features
        return bool(features.is_master())
    except Exception:
        return False


def _text(x) -> str:
    if isinstance(x, list):
        return "".join(str(s) for s in x if s)
    return str(x or "")


def sha(x) -> str:
    return hashlib.sha256(_text(x).encode("utf-8", errors="replace")).hexdigest()[:16]


def path():
    """Стрічка живе в `state/` — у теці, яку `state_files` уже оголошує живим станом:
    клієнту вона не їде і оновленням не затирається."""
    import config
    from pathlib import Path
    return (Path(config.STATE_DIR) / "state" / "model_tape"
            / ("%s.jsonl" % time.strftime("%Y-%m-%d")))


def record(kind: str, model: str, system, user, out, extra=None) -> None:
    """Один запис стрічки. Ніколи не валить прогін: стрічка — допомога, не ворота."""
    if not enabled():
        return
    try:
        p = path()
        p.parent.mkdir(parents=True, exist_ok=True)
        rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S"), "kind": kind, "model": str(model or ""),
               "sys_sha": sha(system), "sys_head": _text(system)[:300],
               "user_head": _text(user)[:300], "out": out if isinstance(out, dict)
               else _text(out)[:_CAP]}
        if extra:
            rec["extra"] = extra
        with open(p, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass


def load(file) -> list:
    out = []
    with open(file, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                try:
                    out.append(json.loads(line))
                except Exception:
                    continue
    return out
