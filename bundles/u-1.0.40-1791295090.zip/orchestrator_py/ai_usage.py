# -*- coding: utf-8 -*-
"""ai_usage.py — ОБЛІК ВИТРАТ ШІ І БЮДЖЕТ АДМІНІСТРАТОРА (зміна 659, 30.09.2026).

🩸 ЗВІДКИ ЦЕ. Питання ОТУ 30.09.2026: «як адміністратор контролюватиме витрату
токенів у комплекті, де немає чату з оркестратором?». Код відповідав — ніяк:
  • гроші рахувались (`costs.record`), але сума жила в памʼяті процесу й
    показувалась лише на екрані чату; перезапуск сервера — нуль;
  • ХТО і НА ЩО витратив — не лягало нікуди: мозок Task Desk думає в окремому
    потоці, де не було ні прогону, ні людини (сотні рядків «КАНАЛ БЕЗ
    ЛІЧИЛЬНИКА: complete» у журналах сервера);
  • межі жили в `.env.local` на сервері — адміністратор клієнта до них не
    дістається.
Слово Андрія: «цей екран маст хев для всіх і це наше упущення».

⛒ КЛАС: ГРОШІ КЛІЄНТА БЕЗ ОБЛІКУ, ЯКИЙ БАЧИТЬ І КЕРУЄ ЙОГО АДМІНІСТРАТОР.

⭐⭐⭐ АРХІТЕКТУРНІ РІШЕННЯ (і чому саме так):

1. ОДИН ЛІЧИЛЬНИК ГРОШЕЙ ЛИШАЄТЬСЯ ОДИН — `costs`. Цей модуль його НЕ
   дублює: він — книга, в яку `costs.record` кладе рядок у ту саму мить, коли
   рахує гроші. Кличе `note()` лише `costs.record` (закон проби 659). Другого
   місця, де «вирішують, скільки коштував виклик», немає.

2. РЯДОК = ОДИН ПЛАТНИЙ ВИКЛИК: коли · хто · на що · модель · токени · гроші.
   ХТО — з контексту протоколу (його називають двері запиту, телеграм, розклад);
   НА ЩО — назва функції з ЗАКРИТОГО словника `FEATURES`, яку оголошує прогін
   (`costs.run_scope(..., feature=ai_usage.F_…)`). Прогін без назви не
   губиться: він лягає рядком з порожньою функцією й сирим каналом і на екрані
   видний як «Інше» — невідоме не ховаємо у фон.

3. ЧОМУ НЕ ПРОТОКОЛ. Протокол — «одна дія людини чи системи = один рядок», і
   гроші в нього вже кладуться ціною КРОКУ, коли є до чого їх прикласти. Облік
   відповідає на інше питання («скільки, хто, на що за місяць») і пишеться на
   КОЖЕН виклик — тисячі рядків на місяць у компанії на 600 людей. У протоколі
   це витіснило б дії людей; тут це і є зміст.

4. ФАЙЛ НА МІСЯЦЬ, ЛИШЕ ДОПИСУВАННЯ. `state/ai_usage/РРРР-ММ.jsonl` — тека
   живого стану (`state_files.STATE_DIRS`): клієнту з оновленням не їде і його
   власний не затирає. Місячна сума рахується з диска ПРИРОСТОМ за розміром
   файла — тому її бачить і сервер, і скрипт в окремому процесі, і перезапуск.

5. МЕЖА — ЦЕ РІШЕННЯ АДМІНІСТРАТОРА КЛІЄНТА, А НЕ НАШЕ. Місячна межа в
   доларах (у доларах рахує постачальник моделі; курс ми не вигадуємо) і
   вимикачі функцій лежать у `state/ai_usage/budget.json`, змінюються лише
   дверима з розділу прав `sec_ai_costs`, і кожна зміна — рядок у протоколі з
   людиною. Суддя — `stop_reason()`; питає його `llm._budget_stop`, тобто
   місце, де платять: обійти межу новим входом неможливо.
   ⛒ Межа зупиняє ВСЕ платне, чат теж: це бюджет, який власник поставив
   собі сам. Технічна денна межа автоматизацій (29.07.2026) лишається як була.
   ⛒ Чат оркестратора вимикачем не вимикається: вимкнути модуль — це питання
   поставки, а не бюджету.

6. ЧЕСНІСТЬ ЦИФРИ. Невідома ціна — не нуль (`usd: null`, екран каже, що сума
   занижена); локальна модель — чесний нуль із позначкою. Облік не пише (диск)
   — робота людини йде далі, а невдача видна на екрані. Зіпсований файл
   бюджету не блокує роботу, а кричить на екрані: зупинити всю компанію через
   битий файл налаштувань гірше, ніж не порахувати межу до повторного
   збереження.
"""

import calendar
import json
import threading
from pathlib import Path

# ─────────────────────── ЗАКРИТИЙ СЛОВНИК ФУНКЦІЙ ────────────────────────────
# Нова платна функція заводиться ТУТ, свідомо, з людською назвою: цей перелік
# бачить адміністратор клієнта. Прогін у продукті без назви звідси — червоне
# на пробі 659 (закон Г).
F_CHAT = "chat"
F_AUTOMATION = "automation"
F_TD_DUE = "taskdesk.due"
F_TD_ACCEPT = "taskdesk.accept"
F_TD_MATCH = "taskdesk.match"
F_TRAINER = "trainer"
F_PING = "ping"

FEATURES = {
    F_CHAT: {"name": "Оркестратор: чат і системи", "group": "Оркестратор",
             "switchable": False,
             "fixed_why": "чат оркестратора — ядро платформи; вимикається він "
                          "складом поставки, а не бюджетом"},
    F_AUTOMATION: {"name": "Автоматизації за розкладом", "group": "Оркестратор",
                   "switchable": True},
    F_TD_DUE: {"name": "Task Desk: новий термін із коментаря", "group": "Task Desk",
               "switchable": True},
    F_TD_ACCEPT: {"name": "Task Desk: пропозиція критерію приймання",
                  "group": "Task Desk", "switchable": True},
    F_TD_MATCH: {"name": "Task Desk: звірка результату з критерієм",
                 "group": "Task Desk", "switchable": True},
    F_TRAINER: {"name": "Тренажер переговорів", "group": "Академія",
                "switchable": True},
    # ⭐ 659 (живий прогін 30.09.2026): перший рядок обліку на машині власника
    # прийшов «без назви» — це перевірка ключа під час запуску сервера.
    # Названа тут; бюджет її не зупиняє (`llm.BUDGET_EXEMPT`), бо інакше
    # скінчились гроші — скінчилась і можливість зрозуміти, чому.
    F_PING: {"name": "Перевірка зв’язку з моделлю", "group": "Обслуговування",
             "switchable": False,
             "fixed_why": "діагностика ключа під час запуску й у налаштуваннях; без "
                          "неї не видно, чи працює ключ"},
}
OTHER_NAME = "Інше (канал без назви)"
NOBODY_NAME = "Без імені (сама платформа)"

WARN_PCT = 80                     # з якого відсотка межі екран попереджає
MAX_MONTH_USD = 1000000.0         # межа понад це — описка, а не рішення

# ⭐ ОДНЕ ДЖЕРЕЛО ДЛЯ ТЕКСТУ І ДЛЯ ЙОГО РОЗПІЗНАВАННЯ. `failure` класифікує
# збої за словами тексту; якби слова жили у двох місцях, вони розійшлися б на
# першій же правці, і людина отримала б «збій постачальника» замість «бюджет
# вичерпано».
MONTH_MARK = "Місячний бюджет ШІ"
OFF_MARK = "вимкнено адміністратором"

ESTIMATE_NOTE = ("Суми — оцінка платформи за прайсом постачальника моделі × "
                 "токени з кожної відповіді. Точний рахунок — у кабінеті "
                 "постачальника (ключ ваш, рахунок теж ваш).")

_MONTHS_UA = ("", "січень", "лютий", "березень", "квітень", "травень", "червень",
              "липень", "серпень", "вересень", "жовтень", "листопад", "грудень")


class AiUsageError(Exception):
    """Відмова з причиною словами (для дверей і екрана)."""


_lock = threading.Lock()
_cache = {}                        # місяць -> {"size", "usd", "calls", "unknown", "free"}
_fails = {"n": 0, "last": ""}


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _dir() -> Path:
    """Тека обліку. Шлях питаємо щоразу: чек відводить стан ДО імпорту config."""
    import config
    return Path(config.STATE_DIR) / "state" / "ai_usage"


def _path(month: str) -> Path:
    return _dir() / ("%s.jsonl" % month)


def _budget_path() -> Path:
    return _dir() / "budget.json"


def _now() -> str:
    import clock                    # ОДИН ПИСАР ЧАСУ
    return clock.now()


def this_month() -> str:
    return _now()[:7]


def _valid_month(m) -> bool:
    m = _s(m)
    return (len(m) == 7 and m[4] == "-" and m[:4].isdigit() and m[5:].isdigit()
            and 1 <= int(m[5:]) <= 12)


def month_title(m: str) -> str:
    try:
        return "%s %s" % (_MONTHS_UA[int(m[5:7])], m[:4])
    except Exception:
        return m


def feature_name(fid: str) -> str:
    return (FEATURES.get(_s(fid)) or {}).get("name") or OTHER_NAME


# ═══════════════════════════════ ЗАПИС ═══════════════════════════════════════
def note(model, in_tok, out_tok, usd, price_known, free, channel="", kind="",
         feature="") -> bool:
    """ОДИН ПИСАР РЯДКА. Кличе його лише `costs.record` — у ту саму мить, коли
    рахує гроші. НІКОЛИ не кидає: облік не має права зупинити роботу людини.
    Але й не мовчить: невдача рахується й видна на екрані."""
    try:
        try:
            import protocol
            ctx = protocol.context()
            src = protocol.norm_source(ctx.get("source"))[0]
        except Exception:
            ctx, src = {}, ""
        at = _now()
        rec = {
            "at": at,
            "feature": _s(feature) if _s(feature) in FEATURES else "",
            "channel": _s(channel)[:80],
            "kind": _s(kind),
            "actor": _s(ctx.get("actor")),
            "source": src,
            "model": _s(model)[:80],
            "in": int(in_tok or 0),
            "out": int(out_tok or 0),
            "usd": (round(float(usd or 0.0), 8) if price_known else None),
            "price_known": bool(price_known),
            "free": bool(free),
        }
        if _s(feature) and not rec["feature"]:
            # Незнана назва не підміняється сусідньою — вона видна як є.
            rec["feature_raw"] = _s(feature)[:60]
        line = json.dumps(rec, ensure_ascii=False) + "\n"
        p = _path(at[:7])
        with _lock:
            p.parent.mkdir(parents=True, exist_ok=True)
            with p.open("a", encoding="utf-8") as f:
                f.write(line)
        return True
    except Exception as e:                      # noqa: BLE001
        with _lock:
            _fails["n"] += 1
            _fails["last"] = str(e)[:200]
        try:
            print("[ai_usage] НЕ ЗАПИСАНО рядок витрат: %s" % e, flush=True)
        except Exception:
            pass
        return False


def write_failures() -> int:
    with _lock:
        return int(_fails["n"])


# ═══════════════════════════════ ЧИТАННЯ ═════════════════════════════════════
def _parse(text: str) -> list:
    out = []
    for ln in text.splitlines():
        ln = ln.strip()
        if not ln:
            continue
        try:
            v = json.loads(ln)
        except Exception:
            continue                    # битий рядок не валить читання решти
        if isinstance(v, dict):
            out.append(v)
    return out


def rows(month: str = "") -> list:
    """Усі рядки місяця (свіжіші — в кінці)."""
    m = month if _valid_month(month) else this_month()
    try:
        return _parse(_path(m).read_text(encoding="utf-8"))
    except Exception:
        return []


def _add(acc: dict, r: dict) -> None:
    acc["calls"] += 1
    if r.get("price_known") is False or r.get("usd") is None:
        acc["unknown"] += 1
    else:
        acc["usd"] += float(r.get("usd") or 0.0)
    if r.get("free"):
        acc["free"] += 1


def month_spent(month: str = "") -> dict:
    """Скільки витрачено за місяць — З ДИСКА, приростом за розміром файла.

    ⭐ Тому суму бачить будь-який процес (сервер, скрипт, розклад) і вона
    переживає перезапуск. Дочитуємо лише повні рядки: рядок, який інший процес
    саме дописує, порахується наступного разу, а не наполовину."""
    m = month if _valid_month(month) else this_month()
    p = _path(m)
    try:
        size = p.stat().st_size
    except Exception:
        size = 0
    with _lock:
        c = _cache.get(m)
        if c is None or size < c["size"]:
            c = {"size": 0, "usd": 0.0, "calls": 0, "unknown": 0, "free": 0}
        if size > c["size"]:
            try:
                with p.open("rb") as f:
                    f.seek(c["size"])
                    chunk = f.read(size - c["size"])
                cut = chunk.rfind(b"\n")
                if cut >= 0:
                    body = chunk[:cut + 1]
                    for r in _parse(body.decode("utf-8", errors="replace")):
                        _add(c, r)
                    c["size"] += len(body)
            except Exception:
                pass
        _cache[m] = c
        return {"month": m, "usd": round(c["usd"], 8), "calls": c["calls"],
                "unknown": c["unknown"], "free": c["free"]}


# ═══════════════════════════════ БЮДЖЕТ ══════════════════════════════════════
def _default_budget() -> dict:
    return {"month_usd": 0.0, "off": [], "broken": False,
            "changed_at": "", "changed_by": ""}


def budget() -> dict:
    """Межа й вимикачі. Файла немає — межі немає, усе увімкнено.

    ⛒ Битий файл НЕ блокує роботу (див. рішення 6), але `broken=True` — і
    екран каже про це вголос."""
    p = _budget_path()
    if not p.exists():
        return _default_budget()
    try:
        import one_writer
        # ⛒ Читання того, що можуть саме підміняти, — теж одним писарем:
        # зайнятий на мить файл — це не «бюджет зіпсовано».
        raw = json.loads(one_writer.read_text(p))
        if not isinstance(raw, dict):
            raise ValueError("не словник")
        lim = float(raw.get("month_usd") or 0.0)
        if lim < 0:
            raise ValueError("відʼємна межа")
        off = [x for x in (raw.get("off") or []) if _s(x) in FEATURES
               and FEATURES[_s(x)].get("switchable")]
        return {"month_usd": lim, "off": off, "broken": False,
                "changed_at": _s(raw.get("changed_at")),
                "changed_by": _s(raw.get("changed_by"))}
    except Exception:
        b = _default_budget()
        b["broken"] = True
        return b


def set_budget(actor: str, month_usd=None, off=None) -> dict:
    """ЄДИНИЙ писар бюджету. Кличуть його лише двері з розділу `sec_ai_costs`.

    Відмова — словами людини; кожна зміна — рядок у протоколі з тим, хто змінив."""
    cur = budget()
    new_lim = cur["month_usd"]
    new_off = list(cur["off"])
    if month_usd is not None:
        try:
            new_lim = float(str(month_usd).replace(",", ".").strip() or 0)
        except Exception:
            raise AiUsageError("Межа «%s» — не число. Вкажіть суму в доларах, "
                               "наприклад 50; 0 — без межі." % month_usd)
        if new_lim < 0:
            raise AiUsageError("Межа не може бути відʼємною. 0 — без межі.")
        if new_lim > MAX_MONTH_USD:
            raise AiUsageError("Межа $%.0f схожа на описку: це більше за $%.0f на "
                               "місяць." % (new_lim, MAX_MONTH_USD))
        new_lim = round(new_lim, 6)
    if off is not None:
        if not isinstance(off, (list, tuple)):
            raise AiUsageError("Перелік вимкнених функцій має бути переліком.")
        clean = []
        for x in off:
            fid = _s(x)
            if fid not in FEATURES:
                raise AiUsageError("Функції «%s» у платформі немає. Відомі: %s."
                                   % (fid, ", ".join(v["name"] for v in FEATURES.values())))
            if not FEATURES[fid].get("switchable"):
                raise AiUsageError("«%s» вимкнути тут не можна: %s."
                                   % (FEATURES[fid]["name"],
                                      FEATURES[fid].get("fixed_why") or "ядро платформи"))
            if fid not in clean:
                clean.append(fid)
        new_off = clean
    rec = {"month_usd": new_lim, "off": new_off, "changed_at": _now(),
           "changed_by": _s(actor)}
    # ⛒ Атомарний запис — ОДНИМ писарем продукту (`one_writer`): свій
    # тимчасовий файл і терпляча підміна, яка на Windows не падає, коли файл
    # саме читають (закон 563, суддя `origin_test`).
    import one_writer
    one_writer.write_json(_budget_path(), rec, indent=1)
    try:
        import protocol
        was = "без межі" if not cur["month_usd"] else money(cur["month_usd"])
        now = "без межі" if not new_lim else money(new_lim)
        offn = ", ".join(FEATURES[f]["name"] for f in new_off) or "нічого"
        protocol.write(protocol.A_AI_BUDGET, "org:company", actor=_s(actor),
                       note="межа на місяць: %s → %s; вимкнено: %s" % (was, now, offn))
    except Exception:
        pass
    return budget()


def feature_on(fid: str) -> bool:
    """Чи не вимкнув адміністратор цю функцію. Функція без назви — увімкнена."""
    try:
        return _s(fid) not in budget()["off"]
    except Exception:
        return True


def money(v) -> str:
    """Гроші для людини: центи, а дрібніше за цент — чотири знаки (інакше
    «$0.00 із $0.00» при справжніх витратах читалось би як поломка)."""
    v = float(v or 0.0)
    return "$%.2f" % v if (v == 0 or v >= 0.01) else "$%.4f" % v


def _month_reason(spent: float, limit: float, month: str) -> str:
    return ("%s вичерпано: за %s витрачено %s із межі %s. Межу встановлює "
            "адміністратор вашої компанії на екрані «Витрати ШІ»; до нового місяця "
            "або до підняття межі платні дії ШІ не виконуються, решта платформи "
            "працює як завжди." % (MONTH_MARK, month_title(month), money(spent),
                                   money(limit)))


def stop_reason(feature: str = "") -> str:
    """ОДИН СУДДЯ «чи можна зараз платити за цю функцію». Порожньо — можна.

    Питає його `llm._budget_stop` перед КОЖНИМ платним викликом, а Task Desk —
    ще до того, як запускати мозок, щоб людина почула причину, а не «мозок не
    відповів». Поломка судді не зупиняє роботу (рішення 6)."""
    try:
        b = budget()
        fid = _s(feature)
        if fid and fid in b["off"]:
            return ("Функцію ШІ «%s» %s. Увімкнути її можна на екрані «Витрати ШІ»."
                    % (feature_name(fid), OFF_MARK))
        lim = float(b["month_usd"] or 0.0)
        if lim > 0:
            ms = month_spent()
            if ms["usd"] >= lim:
                return _month_reason(ms["usd"], lim, ms["month"])
    except Exception:
        return ""
    return ""


def status(month: str = "") -> dict:
    """Короткий стан для домашньої сторінки й екрана."""
    b = budget()
    ms = month_spent(month)
    lim = float(b["month_usd"] or 0.0)
    pct = round(ms["usd"] / lim * 100.0, 1) if lim > 0 else None
    blocked = bool(lim > 0 and ms["usd"] >= lim)
    return {"month": ms["month"], "month_title": month_title(ms["month"]),
            "spent": ms["usd"], "calls": ms["calls"], "limit": lim, "pct": pct,
            "warn": bool(pct is not None and pct >= WARN_PCT), "blocked": blocked,
            "reason": _month_reason(ms["usd"], lim, ms["month"]) if blocked else "",
            "unknown_calls": ms["unknown"], "broken": b["broken"],
            "warn_pct": WARN_PCT}


# ═══════════════════════════════ ЗВІТ ════════════════════════════════════════
def _person_name(ref: str) -> str:
    if not ref:
        return NOBODY_NAME
    try:
        import entity
        return entity.title(ref) or ref
    except Exception:
        return ref


def months() -> list:
    try:
        got = sorted((p.stem for p in _dir().glob("*.jsonl") if _valid_month(p.stem)),
                     reverse=True)
    except Exception:
        got = []
    cur = this_month()
    if cur not in got:
        got.insert(0, cur)
    return got


def report(month: str = "") -> dict:
    """Повний звіт місяця для екрана «Витрати ШІ». Суми за функціями, людьми,
    моделями й днями сходяться із загальною — це судить проба."""
    m = month if _valid_month(month) else this_month()
    rs = rows(m)
    tot = {"usd": 0.0, "calls": 0, "in": 0, "out": 0, "unknown_calls": 0,
           "free_calls": 0}
    feat, pers, mods, days = {}, {}, {}, {}
    for r in rs:
        known = r.get("price_known") is not False and r.get("usd") is not None
        usd = float(r.get("usd") or 0.0) if known else 0.0
        tot["calls"] += 1
        tot["usd"] += usd
        tot["in"] += int(r.get("in") or 0)
        tot["out"] += int(r.get("out") or 0)
        if not known:
            tot["unknown_calls"] += 1
        if r.get("free"):
            tot["free_calls"] += 1
        fid = _s(r.get("feature"))
        f = feat.setdefault(fid, {"id": fid, "name": feature_name(fid),
                                  "group": (FEATURES.get(fid) or {}).get("group", ""),
                                  "usd": 0.0, "calls": 0, "channels": {}})
        f["usd"] += usd
        f["calls"] += 1
        if not fid:
            ch = _s(r.get("channel")) or "?"
            f["channels"][ch] = f["channels"].get(ch, 0) + 1
        who = _s(r.get("actor"))
        p = pers.setdefault(who, {"ref": who, "usd": 0.0, "calls": 0, "feat": {}})
        p["usd"] += usd
        p["calls"] += 1
        p["feat"][fid] = p["feat"].get(fid, 0.0) + usd + 1e-12
        md = _s(r.get("model")) or "?"
        x = mods.setdefault(md, {"model": md, "usd": 0.0, "calls": 0, "in": 0, "out": 0,
                                 "price_known": True, "free": bool(r.get("free"))})
        x["usd"] += usd
        x["calls"] += 1
        x["in"] += int(r.get("in") or 0)
        x["out"] += int(r.get("out") or 0)
        if not known:
            x["price_known"] = False
        d = _s(r.get("at"))[:10]
        y = days.setdefault(d, {"date": d, "usd": 0.0, "calls": 0})
        y["usd"] += usd
        y["calls"] += 1

    def _share(v):
        return round(v / tot["usd"] * 100.0, 1) if tot["usd"] > 0 else 0.0

    by_feature = []
    for f in sorted(feat.values(), key=lambda z: (-z["usd"], -z["calls"])):
        f["usd"] = round(f["usd"], 8)
        f["share"] = _share(f["usd"])
        f["channels"] = [{"channel": k, "calls": v} for k, v in
                         sorted(f["channels"].items(), key=lambda kv: -kv[1])]
        by_feature.append(f)
    by_person = []
    for p in sorted(pers.values(), key=lambda z: (-z["usd"], -z["calls"])):
        top = max(p["feat"].items(), key=lambda kv: kv[1])[0] if p["feat"] else ""
        by_person.append({"ref": p["ref"], "name": _person_name(p["ref"]),
                          "usd": round(p["usd"], 8), "calls": p["calls"],
                          "share": _share(p["usd"]), "top_feature": feature_name(top)})
    by_model = []
    for x in sorted(mods.values(), key=lambda z: (-z["usd"], -z["calls"])):
        x["usd"] = round(x["usd"], 8)
        by_model.append(x)
    by_day = [dict(v, usd=round(v["usd"], 8)) for _k, v in sorted(days.items())]

    today = _now()[:10]
    t_day = days.get(today) or {"usd": 0.0, "calls": 0}
    st = status(m)
    b = budget()
    forecast = None
    if m == this_month():
        try:
            dim = calendar.monthrange(int(m[:4]), int(m[5:7]))[1]
            day = max(1, int(today[8:10]))
            forecast = round(tot["usd"] / day * dim, 6)
        except Exception:
            forecast = None
    notes = []
    if tot["unknown_calls"]:
        notes.append("%d викликів моделлю без відомої ціни — сума в доларах занижена "
                     "на їхню вартість. Ціни моделей звіряє розробник платформи."
                     % tot["unknown_calls"])
    if b["broken"]:
        notes.append("Файл бюджету пошкоджений — межу й вимикачі зараз НЕ "
                     "застосовано. Збережіть межу на цьому екрані заново.")
    fails = write_failures()
    if fails:
        notes.append("%d витрат не вдалося записати в облік (диск). Суми на екрані "
                     "занижені; причина: %s" % (fails, _fails.get("last") or "невідома"))
    feats = [{"id": k, "name": v["name"], "group": v["group"],
              "switchable": bool(v.get("switchable")), "on": k not in b["off"],
              "fixed_why": v.get("fixed_why", "")} for k, v in FEATURES.items()]
    return {
        "month": m, "month_title": month_title(m), "months": months(),
        "total": dict(tot, usd=round(tot["usd"], 8)),
        "today": {"date": today, "usd": round(float(t_day["usd"]), 8),
                  "calls": int(t_day["calls"])} if m == this_month() else None,
        "budget": dict(st, month_usd=b["month_usd"], off=b["off"],
                       forecast_usd=forecast, changed_at=b["changed_at"],
                       changed_by=_person_name(b["changed_by"]) if b["changed_by"] else ""),
        "by_feature": by_feature, "by_person": by_person, "by_model": by_model,
        "by_day": by_day,
        "recent": [{"at": _s(r.get("at")), "who": _person_name(_s(r.get("actor"))),
                    "feature": feature_name(_s(r.get("feature"))),
                    "model": _s(r.get("model")), "in": int(r.get("in") or 0),
                    "out": int(r.get("out") or 0), "usd": r.get("usd"),
                    "free": bool(r.get("free"))} for r in reversed(rs[-40:])],
        "features": feats,
        "notes": notes,
        "write_failures": fails,
        "estimate_note": ESTIMATE_NOTE,
    }


def _reset_for_probe() -> None:
    """Лише для проб: чистий облік у відведеному стані."""
    import config
    if not getattr(config, "STATE_SANDBOXED", False):
        raise AiUsageError("Скидати облік можна лише у відведеному стані проби.")
    with _lock:
        _cache.clear()
        _fails["n"] = 0
        _fails["last"] = ""
    d = _dir()
    if d.exists():
        for p in d.glob("*.jsonl"):
            try:
                p.unlink()
            except Exception:
                pass
