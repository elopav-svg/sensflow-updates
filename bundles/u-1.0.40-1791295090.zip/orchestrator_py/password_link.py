# -*- coding: utf-8 -*-
"""password_link.py — РАЗОВЕ ПОСИЛАННЯ «ВСТАНОВИТИ СВІЙ ПАРОЛЬ» (зміна 696, 05.10.2026).

🩸 ЩО БУЛО. Пароль працівникові ставив адміністратор і передавав його людині сам —
поштою, месенджером, на папірці. Змінити його людина не могла взагалі: писар пароля
один (`taskdesk_identity.set_password`), і кнопка до нього — лише в адміністратора.
В ОТУ це ~600 паролів, що пройшли через чужі руки відкритим текстом.

⛒ ЗАКОНИ:
  1. НА ДИСКУ — ЛИШЕ ВІДБИТОК. Лежить sha256 токена, а не токен: копія стану, архів
     даних чи чужі очі над файлом не дають нікому встановити чужий пароль.
  2. ОДИН РАЗ І 24 ГОДИНИ. Скористались — посилання мертве; строк вийшов — мертве.
  3. НОВЕ ГАСИТЬ СТАРЕ. На запис дійсне не більше одного посилання: повторний лист
     доступу робить попередній лист порожнім.
  4. ПАРОЛЬ СТАВИТЬ ЄДИНИЙ ПИСАР (`set_password`) — з тією ж межею довжини і тим же
     обривом чужих сесій; журнал безпеки пише «за разовим посиланням», діяч — сама
     людина.
  5. ЗАБЛОКОВАНИЙ ЧИ ЗВІЛЬНЕНИЙ — НЕ ВІДЧИНЯЄТЬСЯ. Посилання не обходить рішення
     адміністратора: воно ставить пароль, а не повертає доступ.
  6. ВІДМОВА — СЛОВАМИ (`LinkError`), без підказки, чи існує такий логін.

Лише stdlib + `clock`, `config`, `one_writer`, `taskdesk_identity`.
"""
import hashlib
import secrets
from datetime import datetime, timedelta

import clock
import config
import entity
import one_writer
import protocol
import taskdesk_identity as identity

config.refuse_live_state_for_checks(__name__)
LINKS_JSON = identity.DESK_DIR / "password_links.json"
TTL_HOURS = 24
KEEP_DAYS = 30                # мертві відбитки тримаємо місяць — для «вже скористались»

DEAD = ("Посилання недійсне. Попросіть адміністратора платформи надіслати новий "
        "лист доступу.")
USED = ("Цим посиланням уже скористались — пароль встановлено. Увійдіть зі своїм "
        "паролем; якщо ви його не памʼятаєте, попросіть адміністратора надіслати новий "
        "лист доступу.")
EXPIRED = ("Строк дії посилання вийшов (воно діє %d годин). Попросіть адміністратора "
           "надіслати новий лист доступу." % TTL_HOURS)
REPLACED = ("Це посилання замінене новішим: адміністратор надіслав новий лист доступу — "
            "скористайтесь посиланням із нього.")
CLOSED = ("Вхід для цього запису закритий адміністратором. Зверніться до нього.")


class LinkError(Exception):
    """Відмова словами."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _digest(token: str) -> str:
    return hashlib.sha256(_s(token).encode("utf-8")).hexdigest()


def _now() -> datetime:
    return datetime.fromisoformat(clock.now())


def _load() -> list:
    if not LINKS_JSON.exists():
        return []
    try:
        raw = one_writer.read_json(LINKS_JSON)
    except PermissionError:
        raise
    except Exception:
        return []
    return [x for x in ((raw or {}).get("links") or []) if isinstance(x, dict)]


def _save(links: list) -> None:
    edge = (_now() - timedelta(days=KEEP_DAYS)).isoformat(timespec="seconds")
    links = [x for x in links if _s(x.get("issued_at")) >= edge]
    LINKS_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(LINKS_JSON, {"links": links})


@one_writer.guard("LINKS_JSON")
def issue(acc_id: str) -> str:
    """Нове посилання для запису. Повертає ТОКЕН — його бачить лише лист."""
    acc = identity.account(acc_id)
    if not acc:
        raise LinkError("облікового запису «%s» немає" % _s(acc_id))
    now = _now()
    links = _load()
    for x in links:                                  # закон 3: нове гасить старе
        if x.get("acc_id") == acc["id"] and not x.get("used_at") and not x.get("replaced_at"):
            x["replaced_at"] = now.isoformat(timespec="seconds")
    token = secrets.token_urlsafe(32)
    links.append({"hash": _digest(token), "acc_id": acc["id"],
                  "issued_at": now.isoformat(timespec="seconds"),
                  "expires_at": (now + timedelta(hours=TTL_HOURS)).isoformat(timespec="seconds"),
                  "used_at": "", "replaced_at": ""})
    _save(links)
    return token


def expires_of(token: str) -> str:
    """До коли діє посилання (ISO) — для тексту листа."""
    h = _digest(token)
    for x in _load():
        if x.get("hash") == h:
            return _s(x.get("expires_at"))
    return ""


def _find(token: str):
    """(запис посилання, обліковий запис) або відмова словами."""
    tok = _s(token)
    if len(tok) < 20:
        raise LinkError(DEAD)
    h = _digest(tok)
    rec = next((x for x in _load() if secrets.compare_digest(_s(x.get("hash")), h)), None)
    if rec is None:
        raise LinkError(DEAD)
    if rec.get("used_at"):
        raise LinkError(USED)
    if rec.get("replaced_at"):
        raise LinkError(REPLACED)
    if _s(rec.get("expires_at")) <= clock.now():
        raise LinkError(EXPIRED)
    acc = identity.account(rec.get("acc_id"))
    if not acc:
        raise LinkError(DEAD)
    if not acc["active"] or not acc["employee_active"]:     # закон 5
        raise LinkError(CLOSED)
    return rec, acc


def check(token: str) -> dict:
    """Чи дійсне посилання — і чий це запис (логін, імʼя, до коли)."""
    rec, acc = _find(token)
    return {"login": acc["login"], "name": acc["employee_name"],
            "expires_at": _s(rec.get("expires_at")), "min_length": identity.MIN_PASSWORD}


@one_writer.guard("LINKS_JSON")
def use(token: str, password: str) -> dict:
    """Встановити пароль за посиланням. Посилання гасне лише ПІСЛЯ вдалого запису."""
    rec, acc = _find(token)
    if len(_s(password)) < identity.MIN_PASSWORD:
        raise LinkError("Пароль коротший за %d знаків — так вхід не захищений."
                        % identity.MIN_PASSWORD)
    # Закон 4: діяч — сама людина (вхід у неї ще не відкритий, тож сесії нема з
    # чого взяти; її називає дійсне посилання). Адресу «звідки» лишає контекст дверей.
    try:
        with protocol.step(actor=entity.person_of_actor(acc), source="ui"):
            identity.set_password(acc["id"], password,
                                  reason="працівник встановив пароль за разовим посиланням")
    except identity.IdentityError as e:
        raise LinkError(str(e))
    links = _load()
    for x in links:
        if x.get("hash") == rec.get("hash"):
            x["used_at"] = clock.now()
    _save(links)
    return {"ok": True, "login": acc["login"]}
