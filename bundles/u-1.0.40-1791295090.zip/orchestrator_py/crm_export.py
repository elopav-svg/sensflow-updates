# -*- coding: utf-8 -*-
"""crm_export.py — ВИВАНТАЖЕННЯ КЛІЄНТСЬКОЇ БАЗИ В XLSX (669, 01.10.2026).

⭐⭐⭐ ЗАКОН ЦЬОГО ФАЙЛА — ТОЙ САМИЙ, ЩО Й У ЗАДАЧ: **ЩО НА ЕКРАНІ — ТЕ Й У
ФАЙЛІ.** Він не відбирає і не складає рядків сам: умови відбору перевіряє, а
рядки складає `party_search` (`export_rows`) — той самий писар, яким
намальовано список «Клієнти». Тому файл не може розійтися з тим, що людина
бачила, коли натискала кнопку.

Що він робить сам: аркуш, шапку, ширину колонок і підпис — хто, коли і за
якими умовами вивантажив, скільки клієнтів у файлі. Без підпису таблиця через
тиждень бреше: незрозуміло, це вся база чи вибірка.

⛒ Файл лягає в теку, яку дає той, хто його віддає (двері `/api/crm/export`), і
та тека прибирається одразу після того, як файл поїхав у браузер. На сервері
вивантаження не лишається. Право «Вивантаження» і рядок у журналі безпеки —
на дверях (`taskdesk_api.require_export`, `security_log.data_export`).

⚠ Мозок (LLM) сюди не ходить.
"""
import re
from datetime import datetime
from pathlib import Path

import origin
import parties
import party_search

# (заголовок, ширина, як дістати з рядка списку)
COLUMNS = (
    ("Назва", 38, lambda r: r.get("name", "")),
    ("Тип", 16, lambda r: r.get("kind_name", "")),
    ("Роль", 20, lambda r: ", ".join(r.get("role_names") or [])),
    ("Хто веде", 24, lambda r: (r.get("manager") or {}).get("name", "")),
    ("Телефон", 22, lambda r: ", ".join((r.get("handles") or {}).get(parties.H_PHONE) or [])),
    ("Пошта", 28, lambda r: ", ".join((r.get("handles") or {}).get(parties.H_EMAIL) or [])),
    ("ЄДРПОУ", 12, lambda r: ", ".join((r.get("handles") or {}).get(parties.H_EDRPOU) or [])),
    ("Останній контакт", 16, lambda r: (r.get("last_contact") or {}).get("date", "")),
    ("Номер картки", 12, lambda r: r.get("id", "")),
)


class ExportError(Exception):
    """Відмова з причиною словами."""


def _require_openpyxl():
    try:
        import openpyxl                                    # noqa: F401
        return openpyxl
    except Exception:
        raise ExportError(
            "Для вивантаження в Excel потрібна бібліотека openpyxl, а її тут немає. "
            "Встановіть її одним рядком у командному рядку: "
            "python -m pip install openpyxl — і натисніть «Вивантажити» ще раз.")


def _cell(v):
    # ⛒ Клітинка, що починається з «=», Excel виконав би як формулу: назву
    # клієнта «=HYPERLINK(...)» ми віддаємо текстом, а не командою.
    s = "" if v is None else str(v)
    return ("'" + s) if s[:1] in ("=", "+", "-", "@") else s


def build(crit: dict, who_name: str = "", folder=None) -> dict:
    """Складає файл у теку `folder` і каже, що поклав. Нічого не надсилає."""
    if not folder:
        raise ExportError("Вивантаженню не дали теки: файл бази на сервері не лишається.")
    try:
        crit = party_search.criteria(**{k: (crit or {}).get(k, "") for k in
                                        ("query", "filter", "sort", "dir", "state", "manager")})
    except party_search.SearchError as e:
        raise ExportError(str(e))
    rows = party_search.export_rows(crit)
    openpyxl = _require_openpyxl()
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Клієнти"
    ws.append([h for h, _w, _f in COLUMNS])
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="173A44")
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    for r in rows:
        ws.append([_cell(f(r)) for _h, _w, f in COLUMNS])
    for i, (_h, w, _f) in enumerate(COLUMNS, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    stamp = datetime.now().strftime("%d.%m.%Y %H:%M")
    ws.append([])
    ws.append(["Вивантажив: %s · %s" % (who_name or "—", stamp)])
    ws.append(["Відбір: %s" % party_search.describe(crit)])
    ws.append(["Клієнтів у файлі: %d" % len(rows)])
    note = Font(italic=True, color="5F6B70")
    for r in range(ws.max_row - 2, ws.max_row + 1):
        ws.cell(row=r, column=1).font = note

    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    name = "Клієнти SensFlow %s.xlsx" % datetime.now().strftime("%d-%m-%Y %H-%M-%S")
    path = folder / re.sub(r'[\\/:*?"<>|]+', "-", name)
    wb.save(str(path))
    origin.stamp(path)   # ⛒ 583: ОДИН писар походження на всі виходи
    return {"ok": True, "path": str(path), "folder": str(folder), "name": path.name,
            "rows": len(rows), "criteria": crit,
            "criteria_name": party_search.describe(crit)}
