# -*- coding: utf-8 -*-
"""taskdesk_email.py — ЛИСТИ ПРО ЗАДАЧІ: ДРУГИЙ РОТ TASK DESK (зміна 686, 02.10.2026).

🩸 ЩО БУЛО. Подію задачі доносив лише телеграм. Людина без телеграма мовчки
лишалась поза новинами своєї задачі (`stat["no_chat"]`), і ніякого іншого шляху
не було. Для ОТУ (рішення Андрія 01–02.10.2026): Телеграм лишається — хто хоче,
підключає; решті — лист на робочу пошту через скриньку компанії (685).

⛒ ЗАКОНИ ЦЬОГО РОТА:
  1. ОДИН СУДДЯ КАНАЛУ — `channel_of`. Підключений телеграм (і бот задач
     заведений) — телеграм; інакше пошта з картки працівника; інакше тиша з
     причиною. Дублів «і туди, і туди» немає: кого чути в телеграмі, тому листа
     не шлемо. Цього суддю питають і доставка, і ранкове зведення, і екран
     «хто дізнається» (`taskdesk_telegram.reach`).
  2. ОДИН ЖУРНАЛ ПОДІЙ, СВІЙ КУРСОР (`events.register(SINK)`). Одержувачі — ті
     самі, що в події (`tasks.audience`); другого судді аудиторії тут немає.
  3. ОДИН ПИСАР ТЕКСТУ ПОДІЇ — `taskdesk_telegram.text_for`. Лист бере той
     самий текст; тема — його перший рядок без значка.
  4. КУРСОР ЛИШЕ ВПЕРЕД І ЛИШЕ ПІСЛЯ ДОСТАВКИ. Збій сервера — курсор стоїть;
     після MAX_ATTEMPTS — слід у `events_lost.log` і черга далі.
  5. ХИБНА АДРЕСА ОДНОГО — НЕ ЗБІЙ ВСІХ. Сервер відкинув адресу людини — слід і
     далі; інші отримують своє, і хибну адресу щохвилини не повторюємо.
  6. БЕЗ ЗЛИВИ СТАРОГО. Події, що сталися ДО заведення скриньки (`since`),
     листами не йдуть.
  7. ПОСИЛАННЯ — ЛИШЕ ЧЕСНЕ. Ставимо його з адреси, за якою справді заходять
     працівники (699: `access_letter.public_url` — «Адреса для працівників» або
     адреса платформи у відкритій мережі); адреси немає — посилання немає, бо
     `127.0.0.1` нікуди б не вів.
  8. ФОНОВИЙ ПОТІК НЕ ПАДАЄ і не мовчить: кожна невдача — у виводі сервера.
"""
import sys
import threading
import time

import notify_mail
import taskdesk_events as events
import taskdesk_people as people
import taskdesk_telegram as tg

SINK = "email"
TICK_SEC = 30                  # як часто рот заглядає в чергу
BATCH = 100                    # скільки подій за один захід
MAX_ATTEMPTS = 5               # скільки разів пробувати ту саму подію при збої сервера

CH_TELEGRAM, CH_EMAIL = "telegram", "email"
WHY_GONE = "працівник звільнений"
WHY_NO_ADDRESS = "немає ні підключеного телеграма, ні пошти в картці"
WHY_NO_BOX = "скринька платформи для сповіщень не налаштована"

FOOTER = ("—\nЦей лист платформа SensFlow надіслала автоматично. Відповідати на нього не "
          "потрібно: коментар залиште в самій задачі.")


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def enabled() -> bool:
    """Рот листів живий, коли скринька платформи налаштована (685)."""
    try:
        return notify_mail.configured()
    except Exception:
        return False


# ---------------------------------------------------------------------------
# ОДИН СУДДЯ КАНАЛУ
# ---------------------------------------------------------------------------
def channel_of(emp_id: str) -> tuple:
    """-> (канал, адреса, чому тиша). Канал: «telegram», «email» або «» (тиша)."""
    emp = people.employee(_s(emp_id)) or {}
    if not emp or emp.get("active") is False or _s(emp.get("dismissed_at")):
        return ("", "", WHY_GONE)
    if tg.enabled():
        chat = tg.chat_of(emp_id)
        if chat:
            return (CH_TELEGRAM, chat, "")
    mail = _s(emp.get("email"))
    if not mail:
        return ("", "", WHY_NO_ADDRESS)
    if not enabled():
        return ("", mail, WHY_NO_BOX)
    return (CH_EMAIL, mail, "")


# ---------------------------------------------------------------------------
# ЛИСТ
# ---------------------------------------------------------------------------
def _link(task_id: str) -> str:
    """Посилання на задачу (закон 7).

    ⭐⭐⭐ 699: АДРЕСУ БЕРЕМО ТАМ, ДЕ ЛЮДИ СПРАВДІ ЗАХОДЯТЬ. 🩸 Доти — адреса машини
    (`url_lan`, https://IP:7799) і лише при відкритій мережі. В ОТУ люди заходять через
    проксі компанії на субдомен: посилання на IP вело повз проксі (попередження про
    сертифікат, без TRUSTED_PROXY), а поки мережу не відкрито — посилання не було зовсім.
    Відповідь «за якою адресою заходять працівники» одна — `access_letter.public_url`
    (названа адміністратором, інакше адреса платформи в мережі); шлях до картки — писар
    адрес екранів `entity.screen`. Адреси немає — посилання немає."""
    try:
        import access_letter
        import entity
        base = _s(access_letter.public_url()).rstrip("/")
        path = entity.screen(entity.ref(entity.KIND_TASK, _s(task_id))) if _s(task_id) else ""
        if base and path:
            return base + path
    except Exception as ex:
        sys.stderr.write("[листи] посилання на задачу не склалось: %s\n" % ex)
    return ""


def letter_for(group: list) -> tuple:
    """(тема, текст) листа з групи подій. Текст події — той самий писар, що й телеграм."""
    text = tg.text_for(group)
    if not text:
        return ("", "")
    first = text.split("\n", 1)[0]
    head, _sp, rest = first.partition(" ")
    marks = set(tg.MARK.values()) | {"•"}
    line = rest if head in marks and rest else first
    subject = "SensFlow: " + line
    body = [text]
    link = _link(_s((group or [{}])[0].get("task_id")))
    if link:
        body.append("Відкрити задачу: " + link)
    body.append(FOOTER)
    return (subject, "\n\n".join(body))


# ---------------------------------------------------------------------------
# ДОСТАВКА
# ---------------------------------------------------------------------------
_attempts = {}          # id події -> скільки разів уже пробували (лише в памʼяті)


def deliver(send=None, limit: int = BATCH) -> dict:
    """Донести листами те, чого цей рот ще не доніс."""
    send = send or notify_mail.send
    events.register(SINK)                 # новий рот не отримує всю історію
    stat = {"events": 0, "sent": 0, "telegram": 0, "no_address": 0, "bad_address": 0,
            "failed": 0, "dropped": 0, "before_box": 0, "groups": 0, "stopped": ""}
    if not enabled():
        stat["stopped"] = WHY_NO_BOX
        return stat                       # курсор стоїть: почнемо, коли скринька зʼявиться
    since = _s(notify_mail.settings().get("since"))
    evs = events.pending(SINK, limit)
    stat["events"] = len(evs)
    for g in events.coalesce(evs):
        stat["groups"] += 1
        last_id = max(int(e["id"]) for e in g)
        if since and all(_s(e.get("at")) < since for e in g):
            events.ack(SINK, last_id)     # закон 6: сталось до скриньки
            stat["before_box"] += len(g)
            continue
        to = []
        for e in g:
            for emp in (e.get("to") or []):
                if emp not in to:
                    to.append(emp)
        subject, body = letter_for(g)
        failed = False
        for emp in to:
            kind, addr, _why = channel_of(emp)
            if kind == CH_TELEGRAM:
                stat["telegram"] += 1
                continue
            if kind != CH_EMAIL:
                stat["no_address"] += 1
                continue
            try:
                send(addr, subject, body)
                stat["sent"] += 1
            except notify_mail.RecipientError as ex:
                stat["bad_address"] += 1
                events.lost({"sink": SINK, "event_ids": [int(e["id"]) for e in g],
                             "task_id": _s(g[0].get("task_id")), "to": [emp]},
                            "лист не прийнято: %s" % _s(ex))
            except Exception as ex:
                failed = True
                stat["failed"] += 1
                sys.stderr.write("[листи] %s: %s\n" % (emp, ex))
                break                     # сервер не відповідає — решті теж не дійде
        if not failed:
            _attempts.pop(last_id, None)
            events.ack(SINK, last_id)
            continue
        n = _attempts.get(last_id, 0) + 1
        _attempts[last_id] = n
        if n >= MAX_ATTEMPTS:
            events.lost({"sink": SINK, "event_ids": [int(e["id"]) for e in g],
                         "task_id": _s(g[0].get("task_id")), "to": to},
                        "листи не пішли за %d спроб — подію пропущено" % n)
            _attempts.pop(last_id, None)
            events.ack(SINK, last_id)
            stat["dropped"] += len(g)
            continue
        stat["stopped"] = ("доставка листів спинилась на події %d (спроба %d з %d)"
                           % (last_id, n, MAX_ATTEMPTS))
        break
    return stat


def snapshot() -> dict:
    try:
        pend = len(events.pending(SINK, 10_000))
    except Exception:
        pend = -1
    return {"enabled": enabled(), "sink": SINK, "cursor": events.cursor(SINK),
            "pending": pend, "tick_sec": TICK_SEC}


# ---------------------------------------------------------------------------
# ФОНОВИЙ ЦИКЛ
# ---------------------------------------------------------------------------
_thread = None


def _loop():
    sys.stderr.write("[листи] доставку задач поштою запущено (кожні %d с)\n" % TICK_SEC)
    while True:
        try:
            if enabled():
                deliver()
        except Exception as ex:
            sys.stderr.write("[листи] захід не вдався: %s\n" % ex)
        time.sleep(TICK_SEC)


def is_running() -> bool:
    return _thread is not None and _thread.is_alive()


def start_in_background() -> bool:
    """Запускає доставку окремим потоком (ідемпотентно). Потік живе завжди:
    скриньку можна завести на ходу, без перезапуску платформи."""
    global _thread
    if is_running():
        return True
    _thread = threading.Thread(target=_loop, daemon=True, name="taskdesk-email")
    _thread.start()
    return True
