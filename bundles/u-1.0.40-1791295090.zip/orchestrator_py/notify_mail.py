# -*- coding: utf-8 -*-
"""notify_mail.py — ПОШТА ДЛЯ СПОВІЩЕНЬ ПРАЦІВНИКАМ: СКРИНЬКА ПЛАТФОРМИ І ВІДПРАВНИК
(зміна 685, 02.10.2026).

🩸 ЩО БУЛО. Працівник дізнавався про свою задачу лише з телеграма або з екрана.
Відправника пошти в рушії не було зовсім (`deal_mail.py`: «жодного smtplib»). Для
ОТУ (рішення Андрія 01–02.10.2026): Телеграм лишається — хто хоче, підключає;
решті — лист на робочу пошту через поштовий сервер компанії (Kerio Connect, SMTP).

⛒ ЗАКОНИ ЦЬОГО МОДУЛЯ:
  1. ОДИН ВІДПРАВНИК. Кожен лист платформи йде через `send` — і тема, і тіло, і
     заголовки збираються тут, а не в кожному, кому треба написати.
  2. СКРИНЬКА — ЛИШЕ ПЕРЕВІРЕНА. Зберігаємо після вдалого входу на сервер:
     скринька, з якої не можна надіслати, — обіцянка, яку ніхто не виконає.
  3. ПАРОЛЬ — СЕКРЕТ. Лежить у теці конекторів (вона не їде ні в збірку, ні в
     оновлення, ні в архів даних), не повертається на екран і в двері, не
     пишеться в журнали. Переписати налаштування можна без пароля — тоді лишається
     старий, але лише для ТІЄЇ САМОЇ адреси.
  4. ВІДКРИТИМ ТЕКСТОМ — ЛИШЕ ДО ЦІЄЇ МАШИНИ. Довіру до сертифіката знає один
     писар (`netfetch.ssl_context`, урок 623) — тут його не обходять.
  5. ВІДМОВА — СЛОВАМИ. Збій сервера, пароля чи адреси одержувача — це причина
     людською мовою, а не виняток, що валить потік доставки.
  6. ЛИСТ — АВТОМАТИЧНИЙ І ЧЕСНИЙ: `Auto-Submitted: auto-generated` (RFC 3834),
     щоб автовідповідачі не відповідали роботу, і адреса відправника — сама
     скринька платформи.
  7. ЗМІНА СКРИНЬКИ — СЛІД У ЖУРНАЛІ БЕЗПЕКИ. Куди платформа шле листи від імені
     компанії — питання безпеки, як і хто кому відкрив доступ.
  8. ⭐ 700. ЧЕКАЄМО СЕРВЕР ЗА СТАНДАРТОМ (RFC 5321 §4.5.3.2). Дістатися до сервера —
     коротко (CONNECT_S: мертва адреса не тримає людину 5 хв); відповіді сервера —
     привітання, MAIL, RCPT — щонайменше 5 хв (REPLY_S), кінець листа — 10 хв
     (DATA_END_S). 🩸 Kerio ОТУ (Spam Eliminator) вітається через 30 с, а межа була
     одна на все — 25 с: скринька не зберігалась, ІТ ОТУ правили наш файл руками.
  9. ⭐ 700. ОДНА ЛІНІЯ. Листи йдуть через одне зʼєднання, поки воно живе: наступний
     лист бере відкрите (перевірене NOOP), неживе замінюється новим, після KEEP_S
     тиші лінію закрито чемно (QUIT). Змінили чи відключили скриньку — стара лінія
     закривається. 🩸 Доти кожен лист відкривав нове зʼєднання: з Kerio ОТУ 600 листів
     доступу = 600 × 30 с ≈ 5 год.

⛒ Режим повної локальної ізоляції: лист іде на ПОШТОВИЙ СЕРВЕР КОМПАНІЇ, який
адміністратор назвав сам і перевірив входом. Саме збереження скриньки і є тим явним
дозволом оператора; без нього платформа не шле нікуди.

Лише stdlib + `config`, `one_writer`, `netfetch`, `security_log`.
"""
import smtplib
import socket
import ssl
import sys
import threading
import time
from datetime import datetime
from email.headerregistry import Address
from email.message import EmailMessage
from email.utils import formatdate, make_msgid

import config
import one_writer

SETTINGS_JSON = config.CONNECTORS_DIR / "notify_mail.json"
CONNECT_S = 25          # дістатися до сервера (TCP)
REPLY_S = 300           # закон 8: привітання, MAIL, RCPT — RFC 5321 §4.5.3.2: 5 хв
DATA_END_S = 600        # закон 8: відповідь на кінець листа — §4.5.3.2.6: 10 хв
KEEP_S = 60             # закон 9: скільки тиші лінія чекає наступного листа
SEC_SSL, SEC_STARTTLS, SEC_PLAIN = "ssl", "starttls", "plain"
SECURITIES = (SEC_SSL, SEC_STARTTLS, SEC_PLAIN)
_LOCAL_HOSTS = ("127.0.0.1", "localhost", "::1")
FROM_NAME_DEFAULT = "SensFlow"

_PUBLIC = ("address", "host", "port", "security", "from_name", "enabled",
           "saved", "saved_by", "since", "last_ok", "last_error", "sent")


class MailError(Exception):
    """Відмова словами: що не так і що зробити людині."""


class RecipientError(MailError):
    """⭐ 686. Хибна адреса ОДНОГО одержувача. Скринька жива, сервер живий —
    повтор нічого не змінить, тож доставка не спиняє через це решту людей."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _now() -> str:
    try:
        import clock
        return clock.now()
    except Exception:
        return datetime.now().isoformat(timespec="seconds")


# ── СХОВИЩЕ (ОДИН ПИСАР) ─────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(SETTINGS_JSON)
    except PermissionError:
        raise
    except Exception:
        d = {}
    return d if isinstance(d, dict) else {}


def _save(d: dict) -> None:
    SETTINGS_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(SETTINGS_JSON, d)


def settings() -> dict:
    """Скринька для екрана — БЕЗ пароля за побудовою."""
    d = _load()
    out = {k: d.get(k) for k in _PUBLIC}
    out["has_password"] = bool(_s(d.get("password")))
    out["configured"] = configured(d)
    out["wait_s"] = REPLY_S              # 700: екран каже, скільки чекаємо сервер
    return out


def configured(d=None) -> bool:
    d = _load() if d is None else d
    return bool(d.get("enabled") and _s(d.get("address")) and _s(d.get("password"))
                and _s(d.get("host")) and int(d.get("port") or 0) > 0)


# ── ЗʼЄДНАННЯ ────────────────────────────────────────────────────────────────
def _ssl():
    import netfetch
    return netfetch.ssl_context()


def candidates(address: str, host: str = "", port=None, security: str = "") -> list:
    """Куди стукати. Названий сервер — лише він. Не названий — ПРАВИЛО домену
    (`smtp.<домен>`, `mail.<домен>`, сам домен; 465 із шифруванням, потім 587 зі
    STARTTLS), а не перелік провайдерів."""
    if _s(host):
        sec = _s(security) or SEC_SSL
        if sec not in SECURITIES:
            raise MailError("Невідомий спосіб зʼєднання «%s»." % sec)
        p = int(port or (465 if sec == SEC_SSL else 587))
        return [(_s(host), p, sec)]
    dom = _s(address).rpartition("@")[2].lower()
    if not dom or "." not in dom:
        raise MailError("Адреса «%s» не схожа на пошту." % _s(address))
    hosts = ["smtp." + dom, "mail." + dom, dom]
    return [(h, 465, SEC_SSL) for h in hosts] + [(h, 587, SEC_STARTTLS) for h in hosts]


class NoRoute(OSError):
    """До сервера не дістались за CONNECT_S — інша причина, ніж мовчазний сервер."""


class _SMTP(smtplib.SMTP):
    """Закон 8: зʼєднання — за CONNECT_S, далі кожна відповідь сервера — за REPLY_S
    (у `smtplib` межа одна на все: її й кладемо REPLY_S), кінець листа — за DATA_END_S."""

    def _get_socket(self, host, port, timeout):
        try:
            sock = socket.create_connection((host, port), CONNECT_S, self.source_address)
        except (socket.timeout, TimeoutError):
            raise NoRoute(host, port)
        sock.settimeout(REPLY_S)
        return sock

    def data(self, msg):
        if self.sock:
            self.sock.settimeout(DATA_END_S)
        try:
            return super().data(msg)
        finally:
            if self.sock:
                self.sock.settimeout(REPLY_S)


class _SMTPS(smtplib.SMTP_SSL, _SMTP):
    """SSL з тими самими межами: `SMTP_SSL` загортає сокет, який відкрив `_SMTP`."""


def _open(host: str, port: int, security: str):
    if security == SEC_SSL:
        return _SMTPS(host, port, context=_ssl(), timeout=REPLY_S)
    if security == SEC_STARTTLS:
        c = _SMTP(host, port, timeout=REPLY_S)
        c.ehlo()
        c.starttls(context=_ssl())
        c.ehlo()
        return c
    if security == SEC_PLAIN:
        # ⛔ Пароль відкритим текстом — лише до своєї машини (місцевий поштовий
        # перекладач або проба). До чужого сервера — ніколи.
        if host not in _LOCAL_HOSTS:
            raise MailError("Без шифрування підключаємось лише до цієї ж машини. "
                            "Оберіть захист SSL (порт 465) або STARTTLS (порт 587).")
        c = _SMTP(host, port, timeout=REPLY_S)
        c.ehlo()
        return c
    raise MailError("Невідомий спосіб зʼєднання «%s»." % security)


def _human(ex, host: str) -> str:
    """Відмова людською мовою: ЩО сталося і ЩО зробити."""
    if isinstance(ex, MailError):
        return _s(ex)
    if isinstance(ex, smtplib.SMTPAuthenticationError):
        return ("Сервер %s не прийняв пароль скриньки. Перевірте адресу й пароль; "
                "у Kerio вхід поштою має бути дозволений для цієї скриньки." % host)
    if isinstance(ex, smtplib.SMTPNotSupportedError):
        return "Сервер %s не пропонує входу з паролем на цьому порту." % host
    if isinstance(ex, smtplib.SMTPServerDisconnected) and \
            isinstance(ex.__context__, (socket.timeout, TimeoutError)):
        ex = ex.__context__               # 700: `smtplib` видає мовчання сервера за обрив
    if isinstance(ex, NoRoute):
        return ("До сервера %s не вдалося зʼєднатися за %d с. Перевірте адресу сервера, "
                "порт і чи відкрито його з цієї машини." % (host, CONNECT_S))
    if isinstance(ex, (socket.timeout, TimeoutError)):
        return ("Сервер %s не відповів за %d с (чекали, скільки велить стандарт пошти)."
                % (host, REPLY_S))
    if isinstance(ex, socket.gaierror):
        return "Сервера %s не знайдено в мережі." % host
    if isinstance(ex, ssl.SSLError):
        try:
            import netfetch
            why = netfetch.explain_ssl_error(ex)
            if why:
                return why
        except Exception:
            pass
        return "Шифроване зʼєднання з %s не склалось: %s" % (host, _s(ex)[:120])
    if isinstance(ex, smtplib.SMTPServerDisconnected):
        return "Сервер %s обірвав зʼєднання. Перевірте порт і спосіб захисту." % host
    if isinstance(ex, (ConnectionRefusedError, OSError)):
        return "Сервер %s не приймає зʼєднання: %s" % (host, _s(ex)[:120])
    return "Пошта %s: %s" % (host, _s(ex)[:160])


def _login(address: str, password: str, host="", port=None, security="", connect=None):
    """-> (клієнт, host, port, security). Пароль, який сервер ВІДКИНУВ, далі не
    носимо по інших серверах."""
    last = ""
    for h, p, sec in candidates(address, host, port, security):
        try:
            c = connect(h, p, sec) if connect else _open(h, p, sec)
        except MailError:
            raise
        except Exception as ex:
            last = _human(ex, h)
            continue
        try:
            _auth(c, _s(address), password)
            return c, h, p, sec
        except smtplib.SMTPAuthenticationError as ex:
            _quit(c)
            raise MailError(_human(ex, h))
        except Exception as ex:
            _close(c)                     # сервер мовчить чи впав — QUIT не чекаємо
            last = _human(ex, h)
    raise MailError(last or "Поштового сервера для «%s» не знайдено." % address)


def _b64(text: str) -> str:
    import base64
    return base64.b64encode(text.encode("utf-8")).decode("ascii")


def _auth(c, user: str, password: str) -> None:
    """Вхід на сервер.

    🩸 ЗНАЙДЕНО ПРОБОЮ 685: `smtplib.login` кодує пароль як ASCII і падає на
    кирилиці («'ascii' codec can't encode») — а пароль скриньки в Kerio може
    бути будь-яким. Тому пароль не з ASCII несемо самі, у UTF-8, як велить
    RFC 4616 (PLAIN) і як розуміють сервери (LOGIN). ASCII-пароль — звичайним
    шляхом `smtplib` (він уміє й CRAM-MD5)."""
    if (user + password).isascii():
        c.login(user, password)
        return
    c.ehlo_or_helo_if_needed()
    if not c.has_extn("auth"):
        raise smtplib.SMTPNotSupportedError("AUTH extension not supported by server.")
    methods = (c.esmtp_features.get("auth") or "").upper().split()
    if "PLAIN" in methods:
        code, resp = c.docmd("AUTH", "PLAIN " + _b64("\0%s\0%s" % (user, password)))
    elif "LOGIN" in methods:
        code, resp = c.docmd("AUTH", "LOGIN " + _b64(user))
        if code == 334:
            code, resp = c.docmd(_b64(password))
    else:
        raise smtplib.SMTPNotSupportedError(
            "Сервер не пропонує входу PLAIN чи LOGIN, а пароль не з латиниці.")
    if code not in (235, 503):
        raise smtplib.SMTPAuthenticationError(code, resp)


def _quit(c) -> None:
    """Чемно попрощатись. Відповідь на QUIT чекаємо коротко: лист уже пішов, і
    мовчазний сервер не сміє тримати лінію (закон 9) ще 5 хв."""
    try:
        if getattr(c, "sock", None):
            c.sock.settimeout(min(CONNECT_S, 10))
        c.quit()
    except Exception:
        _close(c)


def _close(c) -> None:
    try:
        c.close()
    except Exception:
        pass


def _check_address(a: str, what: str, err=MailError) -> str:
    a = _s(a)
    if "@" not in a or " " in a or a.startswith("@") or a.endswith("@"):
        raise err("%s «%s» не схожа на адресу пошти." % (what, a))
    return a


# ── НАЛАШТУВАННЯ ─────────────────────────────────────────────────────────────
def save(address: str, password: str = "", host: str = "", port=None, security: str = "",
         from_name: str = "", by: str = "", connect=None) -> dict:
    """Завести або змінити скриньку платформи. Спершу ВХІД, потім запис (закон 2).

    ⛒ Вхід на сервер (до TIMEOUT_S) — ПОЗА замком одного писаря: замок спільний на
    всю платформу, і повільна пошта не сміє зупиняти запис задач і угод."""
    address = _check_address(address, "Адреса скриньки").lower()
    old = _load()
    password = _s(password)
    if not password:
        if _s(old.get("address")).lower() == address and _s(old.get("password")):
            password = _s(old.get("password"))
        else:
            raise MailError("Потрібен пароль скриньки %s." % address)
    try:
        port = int(port) if _s(port) else None
    except (TypeError, ValueError):
        raise MailError("Порт «%s» — не число." % _s(port))
    c, h, p, sec = _login(address, password, host, port, security, connect=connect)
    try:
        _commit(address, password, h, p, sec, from_name, by)
    except Exception:
        _quit(c)
        raise
    # Закон 9: перевірене зʼєднання не викидаємо — перевірочний лист і перші листи
    # працівникам підуть ним, без другого очікування привітання.
    _line_adopt(c, _line_key({"address": address, "password": password, "host": h,
                              "port": p, "security": sec}))
    _trace("скриньку для сповіщень збережено: %s через %s:%d (%s)" % (address, h, p, sec))
    return settings()


@one_writer.guard("NOTIFY_MAIL_JSON")
def _commit(address, password, h, p, sec, from_name, by) -> None:
    old = _load()
    now = _now()
    # ⭐ 686: «з якого моменту ця скринька» — межа для доставки: події, що сталися
    # ДО неї, листами не йдуть (без зливи старого). Правка тієї самої скриньки
    # (імʼя, сервер, пароль) межу НЕ рухає — інакше черга, що чекала полагодженого
    # пароля, мовчки б пропала.
    same = _s(old.get("address")).lower() == address and _s(old.get("since"))
    new = {"address": address, "password": password, "host": h, "port": p,
           "security": sec, "from_name": _s(from_name) or FROM_NAME_DEFAULT,
           "enabled": True, "saved": now, "saved_by": _s(by),
           "since": _s(old.get("since")) if same else now,
           "last_ok": old.get("last_ok") or "", "last_error": "",
           "sent": int(old.get("sent") or 0)}
    _save(new)
    _journal(old, new)


def remove(by: str = "") -> dict:
    # Лінію закриваємо ПІСЛЯ замка писаря: відправник під замком лінії сам іде до
    # писаря (`_mark`) — вкладені навхрест замки дали б взаємне очікування.
    if _remove():
        _line_drop(polite=True)
        _trace("скриньку для сповіщень відключено")
    return settings()


@one_writer.guard("NOTIFY_MAIL_JSON")
def _remove() -> bool:
    old = _load()
    if not old:
        return False
    _save({})
    _journal(old, {})
    return True


def _journal(old: dict, new: dict) -> None:
    """Рядок у журналі безпеки: було → стало. Пароля тут немає — лише факт зміни."""
    fields = (("address", "Скринька"), ("host", "Сервер"), ("port", "Порт"),
              ("security", "Захист"), ("from_name", "Імʼя відправника"))
    chs = [(label, _s(old.get(k)), _s(new.get(k))) for k, label in fields
           if _s(old.get(k)) != _s(new.get(k))]
    if _s(old.get("password")) != _s(new.get("password")) and new:
        chs.append(("Пароль", "", "змінено"))
    note = ("скриньку відключено" if not new else
            ("скриньку заведено" if not old else "налаштування змінено"))
    try:
        import security_log
        security_log.notify_mail_event(chs, note=note)
    except Exception as ex:
        _trace("зміну скриньки не записано в журнал безпеки: %s" % type(ex).__name__)


# ── ВІДПРАВНИК (ОДИН НА ВСЮ ПЛАТФОРМУ) ──────────────────────────────────────
def _message(d: dict, to: str, subject: str, body: str, attachments=None) -> EmailMessage:
    m = EmailMessage()
    user, _at, dom = _s(d.get("address")).partition("@")
    m["From"] = Address(_s(d.get("from_name")) or FROM_NAME_DEFAULT, user, dom)
    m["To"] = to
    m["Subject"] = " ".join(_s(subject).split())[:200] or "SensFlow"
    m["Date"] = formatdate(localtime=True)
    m["Message-ID"] = make_msgid(domain=dom or "sensflow.local")
    m["Auto-Submitted"] = "auto-generated"
    m["X-Auto-Response-Suppress"] = "All"
    m.set_content(_s(body) + "\n", charset="utf-8")
    # ⭐ 696: вкладення (ключ офісу в листі доступу). Той самий відправник — другого
    # збирача листів поруч не заводимо. Вкладення: (імʼя файла, байти, тип/підтип).
    for name, data, mime in (attachments or ()):
        maintype, _sl, subtype = _s(mime or "application/octet-stream").partition("/")
        raw = data if isinstance(data, (bytes, bytearray)) else _s(data).encode("utf-8")
        m.add_attachment(bytes(raw), maintype=maintype or "application",
                         subtype=subtype or "octet-stream", filename=_s(name) or "file")
    return m


@one_writer.guard("NOTIFY_MAIL_JSON")
def _mark(ok: bool, err: str = "") -> None:
    try:
        d = _load()
        if not d:
            return
        if ok:
            d["last_ok"], d["last_error"] = _now(), ""
            d["sent"] = int(d.get("sent") or 0) + 1
        else:
            d["last_error"] = "%s · %s" % (_now(), _s(err)[:300])
        _save(d)
    except Exception:
        pass


# ── ОДНА ЛІНІЯ (закон 9) ─────────────────────────────────────────────────────
_LINE = threading.Lock()
_line = {"c": None, "key": None, "used": 0.0, "timer": None}


def _line_key(d: dict) -> tuple:
    """Чия лінія: та сама скринька, пароль і сервер. Змінилось будь-що — лінія інша."""
    return (_s(d.get("address")).lower(), _s(d.get("password")), _s(d.get("host")),
            int(d.get("port") or 0), _s(d.get("security")))


def _alive(c) -> bool:
    """Лінія, що лежала, ще жива? NOOP з короткою межею: сервер, який закрив тихе
    зʼєднання, відповідає одразу (або обриває), а не за 5 хв."""
    try:
        if getattr(c, "sock", None):
            c.sock.settimeout(min(CONNECT_S, 10))
        ok = c.noop()[0] == 250
        if getattr(c, "sock", None):
            c.sock.settimeout(REPLY_S)
        return ok
    except Exception:
        return False


def _line_take(d: dict, connect=None):
    """Під замком `_LINE`. Жива лінія тієї самої скриньки — вона; інакше нова (вхід на
    сервер). Сервер, що закрив тихе зʼєднання, на NOOP відповідає 421 або обривом —
    лист не йде в мертву лінію."""
    key = _line_key(d)
    c = _line["c"]
    if c is not None and _line["key"] == key and _alive(c):
        return c
    _line_drop_locked(polite=False)
    c, _h, _p, _sec = _login(_s(d.get("address")), _s(d.get("password")), _s(d.get("host")),
                             d.get("port"), _s(d.get("security")), connect=connect)
    _line.update(c=c, key=key)
    return c


def _line_keep() -> None:
    """Лист пішов — лінія чекає наступного KEEP_S, потім закривається чемно."""
    _line["used"] = time.monotonic()
    t = _line.get("timer")
    if t is not None:
        t.cancel()
    t = threading.Timer(KEEP_S, _line_idle)
    t.daemon = True
    _line["timer"] = t
    t.start()


def _line_idle() -> None:
    with _LINE:
        if _line["c"] is not None and time.monotonic() - _line["used"] >= KEEP_S - 0.05:
            _line_drop_locked(polite=True)


def _line_drop_locked(polite: bool) -> None:
    c = _line["c"]
    t = _line.get("timer")
    if t is not None:
        t.cancel()
    _line.update(c=None, key=None, timer=None)
    if c is not None:
        (_quit if polite else _close)(c)


def _line_drop(polite: bool = True) -> None:
    with _LINE:
        _line_drop_locked(polite)


def _line_adopt(c, key: tuple) -> None:
    """Перевірене входом зʼєднання (`save`) стає лінією."""
    with _LINE:
        _line_drop_locked(polite=True)
        _line.update(c=c, key=key)
        _line_keep()


def send(to: str, subject: str, body: str, connect=None, attachments=None) -> bool:
    """Надіслати ОДИН лист від скриньки платформи — лінією (закон 9). Відмова —
    `MailError` словами. Слід у стані скриньки (`_mark`) — ПІСЛЯ замка лінії."""
    d = _load()
    if not configured(d):
        raise MailError("Пошта для сповіщень не налаштована: адміністратор заводить "
                        "скриньку платформи на сторінці «Пошта для сповіщень».")
    to = _check_address(to, "Адреса одержувача", RecipientError)
    msg = _message(d, to, subject, body, attachments)
    host = _s(d.get("host"))
    ok, err, bad_to = _send_on_line(d, msg, host, connect)
    _mark(ok, err)
    if bad_to:
        raise RecipientError("Сервер %s не прийняв адресу одержувача %s." % (host, to))
    if not ok:
        raise MailError(err)
    return True


def _send_on_line(d: dict, msg, host: str, connect=None) -> tuple:
    """-> (скринька жива?, причина збою, адресу одержувача відкинуто?)."""
    with _LINE:
        try:
            c = _line_take(d, connect)
        except MailError as ex:
            return False, _s(ex), False
        try:
            refused = c.send_message(msg)
        except smtplib.SMTPRecipientsRefused:
            _line_keep()                      # скринька й лінія живі, хибна лише адреса
            return True, "", True
        except Exception as ex:
            _line_drop_locked(polite=False)   # лист не пішов — лінії не довіряємо
            return False, _human(ex, host), False
        _line_keep()
        return True, "", bool(refused)


def test(to: str, by: str = "", connect=None) -> dict:
    """Перевірочний лист — щоб адміністратор побачив, що пошта справді доходить."""
    send(to, "SensFlow: перевірка пошти для сповіщень",
         "Це перевірочний лист платформи SensFlow.\n\n"
         "Якщо ви його отримали, сповіщення про задачі працівникам доходитимуть поштою.\n"
         "Надіслав: %s · %s" % (_s(by) or "адміністратор", _now()), connect=connect)
    return settings()


def _trace(note: str) -> None:
    """Слід у виводі сервера — без пароля за побудовою (його сюди не передають)."""
    try:
        sys.stderr.write("[пошта сповіщень] %s\n" % note)
    except Exception:
        pass
