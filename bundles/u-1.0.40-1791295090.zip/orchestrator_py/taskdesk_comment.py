# -*- coding: utf-8 -*-
"""taskdesk_comment.py — ОДИН ПИСАР КОМЕНТАРЯ В ЗАДАЧУ (650, 28.09.2026).

🩸 КОРІНЬ. Мозок Task Desk читає коментар (новий термін, названий словами) і
звіряє зданий результат із критерієм приймання. Доти це жило в дверях екрана
(`taskdesk_api._comment`), а бот задач писав `tasks.comment` напряму — повз
мозок. Той самий працівник, та сама задача, той самий текст: з екрана — з
пропозицією й звіркою, з телефона — мовчки. Чотири писарі, дві поведінки.

⛒ ТЕПЕР КОМЕНТАР ПИШЕ ЛИШЕ ЦЕЙ МОДУЛЬ. Екран, бот і будь-які майбутні двері
(пошта, голос) кличуть `write()`. Закон тримає `comment_door_650_test.py`:
`tasks.comment(` у робочому коді зустрічається лише тут.

Закони мозку не змінились (див. `taskdesk_ai.py`): коментар зберігається
ЗАВЖДИ і ДО мозку; мозок лише пропонує; не встиг — кажемо вголос.
"""

import taskdesk_ai as ai
import taskdesk_tasks as tasks


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def match_for(tid: str, result_text: str):
    """Звірка результату з критерієм приймання — або порожньо й причина словами.

    ⛔ Мозок тут НІЧОГО не вирішує: він кладе поруч «що просили · що здали ·
    чого не видно». Приймає людина."""
    if not ai.enabled():
        return {}, ""
    try:
        t = tasks.task(tid)
    except tasks.TaskError:
        return {}, ""
    crit = t.get("acceptance") or ""
    if not crit:
        return {}, ""          # звіряти нема з чим — і це не помилка
    try:
        return ai.compare_result_soon(crit, result_text)
    except Exception as e:
        return {}, str(e)


def _ddmmyyyy(iso: str) -> str:
    d = _s(iso)[:10]
    if len(d) == 10 and d[4] == "-" and d[7] == "-":
        return "%s.%s.%s" % (d[8:10], d[5:7], d[:4])
    return d


def write(tid: str, actor_id: str, text: str, as_result: bool = False,
          is_admin: bool = False) -> dict:
    """Записати коментар (або результат) і дати мозку його прочитати.

    Повертає задачу. Поверх неї:
      • `ai_note` — "ok", коли мозок додав пропозицію; інакше причина словами;
      • `ai_said` — один рядок для людини, яка не бачить екрана (бот).
    """
    text = text or ""
    # ⛒ ЗВІРКА РАХУЄТЬСЯ ДО ЗАПИСУ Й ЛЯГАЄ В ТОЙ САМИЙ ЗАПИС. Порахувати її
    # після означало б другий запис у ту саму задачу — і другого писаря того
    # самого файла. Не встиг мозок — результат однаково здано.
    m, m_note = match_for(tid, text) if as_result else ({}, "")
    t = dict(tasks.comment(tid, actor_id, text, as_result, is_admin, match=m))
    if m_note:
        t["ai_note"] = m_note
        t["ai_said"] = "Увага: %s" % m_note
        return t
    if m:
        t["ai_said"] = ("ШІ звірив результат із критерієм приймання — звірка в задачі; "
                        "рішення приймає постановник.")
    if not ai.enabled() or not ai.might_hold_a_date(text):
        return t
    cid = ""
    for c in reversed(t.get("feed") or []):
        if c.get("kind") == "comment":
            cid = c["id"]
            break
    found, note = ai.read_comment_soon(t.get("title", ""), text)
    if note:
        t["ai_note"] = note
        t["ai_said"] = "Увага: %s" % note
        return t
    if not found:
        return t
    try:
        t = dict(tasks.add_proposal(tid, found["kind"], found["date"], found.get("why", ""),
                                    found.get("quote", ""), cid))
        t["ai_note"] = "ok"
        t["ai_said"] = ("ШІ побачив у коментарі новий термін — %s; пропозиція чекає "
                        "рішення постановника." % _ddmmyyyy(found["date"]))
    except tasks.TaskError as e:
        t["ai_note"] = str(e)
        t["ai_said"] = "Увага: %s" % e
    return t
