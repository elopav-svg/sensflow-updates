# -*- coding: utf-8 -*-
"""doc_numbers.py — ОДИН ПИСАР НОМЕРІВ ДОКУМЕНТІВ (зміна 585, 16.09.2026).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ. Номер договору набирався руками. Другий договір того
самого дня рано чи пізно дістав би збіг або пропуск — і помітив би це
бухгалтер, а не ми. Номер, який видають дві руки, — це два різні номери
одного дня.

⭐ ФОРМАТ — ТОЙ, ЩО ВЖЕ ПІШОВ У БУХГАЛТЕРІЮ (рішення Андрія 13.09.2026):
`ДД.ММ-N`, де N — порядковий У МЕЖАХ ДНЯ: `14.09-1`, того ж дня `14.09-2`,
наступного дня знову `15.09-1`. Наскрізної нумерації «1, 2, 3» тут не буде:
номер `14.09-1` УЖЕ стоїть у рахунку й акті, підписаних 14.09.2026, і зміна
формату означала б розійтися з бухгалтером на першому ж документі.

⛒ РІК У САМОМУ НОМЕРІ НЕ ЖИВЕ — його там немає у формі, яку обрав клієнт.
Тому рік живе в РЕЄСТРІ: номер без року читається як номер поточного року.
Це названо вголос, щоб через рік ніхто не гадав, чому `14.09-1` не збігся.

⛒ РЕЄСТР ЛИШЕ РОСТЕ. Виданий номер не видається вдруге НІКОЛИ — навіть якщо
документ, якому його дали, потім прибрали. Інакше «номер договору» перестає
бути тим, чим він є: незмінним посиланням у чужих паперах.

⛒ НАШ НОМЕР З ПАПЕРУ ЗАВОДИТЬСЯ ЯК ФАКТ (`reserve`). Перший запис реєстру — це
те, що вже сталося: `14.09-1` для ТОВ «КАСПЕР УКРАЇНА». Платформа не вдає, ніби
світ почався з неї.

⭐⭐⭐ 662 (30.09.2026). НОМЕР, ЯКИЙ ВИДАЛИ НЕ МИ, — ФАКТ, ЗАПИСАНИЙ ДОСЛІВНО
(`foreign`). 🩸 ОТУ підписав договір № «30/09-26»: номер поставив КОНТРАГЕНТ.
Реєстр знав лише нашу форму, тож номер паперу завести було неможливо; у картку
лягло вигадане «30.09-26», а наш реєстр дістав номер, якого ми не видавали.
⛒ У двох видавців нумерації незалежні: чужий номер у наш реєстр не йде, наш
лічильник дня не штовхає і з нашими номерами не зіштовхується — навіть якщо
контрагент написав його в нашій формі («14.09-1»). Хто видав — каже людина, а
не форма рядка. Помилковий запис у реєстрі не звільняється, а називається
(`void`): виданий номер не видається вдруге НІКОЛИ.
"""
import re

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import one_writer

config.refuse_live_state_for_checks(__name__)

DIR = config.CRM_DIR
NUMBERS_JSON = DIR / "doc_numbers.json"

# `ДД.ММ-N`: день, крапка, місяць, дефіс, порядковий номер дня.
NUMBER_RE = re.compile(r"^(\d{2})\.(\d{2})-(\d+)$")
DATE_RE = re.compile(r"^(\d{2})\.(\d{2})\.(\d{4})$")


class NumberError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def today() -> str:
    """Сьогодні у вигляді ДД.ММ.РРРР — тим самим писарем часу, що й усе інше."""
    iso = clock.now()[:10]                    # РРРР-ММ-ДД
    y, m, d = iso.split("-")
    return "%s.%s.%s" % (d, m, y)


def check_date(date_str) -> str:
    """Дата у вигляді ДД.ММ.РРРР — або відмова словами."""
    ds = _s(date_str) or today()
    m = DATE_RE.match(ds)
    if not m:
        raise NumberError("Дата «%s» не схожа на ДД.ММ.РРРР — так номер не "
                          "видається." % ds)
    d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    if not (1 <= d <= 31 and 1 <= mo <= 12 and 2000 <= y <= 2100):
        raise NumberError("Дата «%s» не існує." % ds)
    return ds


def check_number(number) -> str:
    """Номер у вигляді ДД.ММ-N — або відмова словами."""
    ns = _s(number)
    if not NUMBER_RE.match(ns):
        raise NumberError("Номер «%s» не схожий на ДД.ММ-N (наприклад, 14.09-1). "
                          "Так реєстр його не прийме." % ns)
    return ns


# ⛒ 662: стеля чужого номера. Номер — це позначка паперу, а не текст про папір.
FOREIGN_MAX = 64


def foreign(number, required: bool = True) -> str:
    """⭐⭐⭐ 662. НОМЕР ЧУЖОГО ПАПЕРУ — ДОСЛІВНО, АБО ВІДМОВА СЛОВАМИ.

    ⛒ Реєстр не читається і не пишеться: номер контрагента НАШИХ номерів не
    палить. Форму ми не судимо (вона чужа), судимо лише, що це справді номер:
    один рядок, без керівних знаків, не довший за `FOREIGN_MAX`.
    `required=False` — папір, який буває без номера (статут, витяг)."""
    ns = _s(number)
    if not ns:
        if required:
            raise NumberError("Номер контрагента не названо. Впишіть його так, як "
                              "він стоїть у папері (наприклад, 30/09-26).")
        return ""
    if any(ch in ns for ch in "\r\n") or any(ord(ch) < 32 for ch in ns):
        raise NumberError("Номер «%s» — не один рядок. Номер паперу — це один "
                          "рядок, як у шапці документа." % ns.replace("\n", " ").replace("\r", " "))
    if len(ns) > FOREIGN_MAX:
        raise NumberError("Номер на %d знаків — це вже текст, а не номер (стеля — %d "
                          "знаків). Пояснення покладіть у нотатку угоди."
                          % (len(ns), FOREIGN_MAX))
    return ns


def _short(date_str: str, n: int) -> str:
    d, mo, _y = date_str.split(".")
    return "%s.%s-%d" % (d, mo, int(n))


def _year_of(date_str: str) -> str:
    return date_str.split(".")[2]


def _key(year: str, number: str) -> str:
    """Ключ реєстру: рік плюс номер. Рік у номері не живе — він живе тут."""
    return "%s:%s" % (year, number)


# ───────────────────────── ОДИН ЧИТАЧ / ОДИН ПИСАР ─────────────────────────
def _load() -> dict:
    raw = one_writer.read_json(NUMBERS_JSON, default={}) or {}
    taken = {}
    for k, v in (raw.get("taken") or {}).items():
        k = _s(k)
        if k:
            taken[k] = _s(v)
    return {"taken": taken}


def _save(d: dict) -> None:
    DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(NUMBERS_JSON, {"taken": d.get("taken") or {}})


def taken(number, date_str: str = "") -> bool:
    """Чи цей номер уже зайнятий. Рік — із дати, а без дати — поточний."""
    ns = check_number(number)
    year = _year_of(check_date(date_str)) if _s(date_str) else today().split(".")[2]
    return _key(year, ns) in _load()["taken"]


@one_writer.guard("NUMBERS_JSON")
def reserve(number, date_str: str = "", what: str = "") -> str:
    """ЗАВЕСТИ ЧУЖИЙ НОМЕР ЯК ФАКТ. Зайнятий номер удруге не віддається."""
    ns = check_number(number)
    ds = check_date(date_str) if _s(date_str) else today()
    year = _year_of(ds)
    st = _load()
    key = _key(year, ns)
    if key in st["taken"]:
        raise NumberError("Номер «%s» за %s рік уже виданий (%s). Двом "
                          "документам один номер не дається."
                          % (ns, year, st["taken"][key] or "без пояснення"))
    st["taken"][key] = _s(what) or clock.now()
    _save(st)
    return ns


VOID_MARK = "НЕ НАШ НОМЕР"


@one_writer.guard("NUMBERS_JSON")
def void(number, date_str: str = "", why: str = "") -> str:
    """⭐⭐⭐ 662. ПОМИЛКОВИЙ ЗАПИС РЕЄСТРУ — НАЗВАТИ, АЛЕ НЕ ЗВІЛЬНИТИ.

    🩸 30.09.2026 номер договору ОТУ «30/09-26» лягав лише як «30.09-26» — і наш
    реєстр записав його як НАШ. Ми такого номера не видавали.
    ⛒ Запис не стирається: номер лишається зайнятим (виданий номер не
    видається вдруге НІКОЛИ, і наш лічильник дня назад не йде). Міняється лише
    пояснення — реєстр чесно каже, що це не наш номер і чому."""
    ns = check_number(number)
    ds = check_date(date_str) if _s(date_str) else today()
    year = _year_of(ds)
    st = _load()
    key = _key(year, ns)
    if key not in st["taken"]:
        raise NumberError("Номера «%s» за %s рік у реєстрі немає — назвати "
                          "помилковим нічого." % (ns, year))
    old = st["taken"][key]
    if old.startswith(VOID_MARK):
        return ns
    st["taken"][key] = "%s (запис помилковий, номер лишається зайнятим): %s; був: %s" % (
        VOID_MARK, _s(why) or "без пояснення", old or "без пояснення")
    _save(st)
    return ns


@one_writer.guard("NUMBERS_JSON")
def issue(date_str: str = "", what: str = "") -> str:
    """ВИДАТИ НАСТУПНИЙ НОМЕР ДНЯ. Рахує від реєстру, а не від переліку
    документів: прибраний документ не звільняє свого номера.

    ⛒ ЛІЧИЛЬНИК ДНЯ НЕ ХОДИТЬ НАЗАД. Беремо НАЙБІЛЬШИЙ виданий за цей день і
    додаємо одиницю, а не першу вільну дірку. Якщо в реєстр завели чужий номер
    `13.09-7`, це означає, що в паперах той день дійшов принаймні до сьомого, —
    і видати після цього `13.09-1` означало б наздогнати паперовий номер, якого
    ми не бачили. Пропуск у нумерації нікому не шкодить; збіг шкодить усім."""
    ds = check_date(date_str)
    year = _year_of(ds)
    st = _load()
    day = "%s.%s-" % tuple(ds.split(".")[:2])
    top = 0
    for k in st["taken"]:
        y, _, num = k.partition(":")
        if y == year and num.startswith(day):
            try:
                top = max(top, int(num[len(day):]))
            except ValueError:
                continue
    ns = _short(ds, top + 1)
    st["taken"][_key(year, ns)] = _s(what) or clock.now()
    _save(st)
    return ns


def registry() -> list:
    """Реєстр для екрана: що видано, коли й кому. Найновіше — згори."""
    out = []
    for k, v in _load()["taken"].items():
        year, _, number = k.partition(":")
        out.append({"year": year, "number": number, "what": v})
    out.sort(key=lambda x: (x["year"], x["number"]), reverse=True)
    return out
