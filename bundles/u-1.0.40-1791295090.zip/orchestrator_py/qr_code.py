# -*- coding: utf-8 -*-
"""qr_code.py — QR-КОД СВОЇМ КОДОМ (зміна 666, 30.09.2026).

⭐ НАВІЩО СВІЙ. Двофакторний вхід підключається скануванням QR-коду телефоном
(Google Authenticator). На машині клієнта сторонніх пакетів немає і не буде:
закритий контур, установка без інтернету. Малювати QR у браузері бібліотекою з
мережі — теж ні: екран підключення мусить працювати в офісі без інтернету.
Тому кодер — тут, на стандартній бібліотеці.

ЩО ВМІЄ (рівно те, що треба, і не більше):
  • режим «байти» (UTF-8), рівень корекції M (15 % пошкоджень), версії 1–15
    (до 412 байтів — посилання для програми займає ~100);
  • вибір маски за штрафом стандарту (ISO/IEC 18004, 7.8.3) — щоб телефон
    читав код з першого разу, а не з п'ятого;
  • SVG з самих прямокутників: жоден знак рядка в розмітку не потрапляє.

⛒ ПРАВДУ КОДЕРА СУДИТЬ НЕ ВІН САМ. Проба 666 звіряє Reed-Solomon із
незалежним зразком (Thonky, «HELLO WORLD» 1-M), а матриці — із золотими
зразками, які незалежний декодер (jsQR) прочитав назад у той самий рядок.
"""


class QrError(Exception):
    """Відмова кодера словами."""


# Рівень M: (байтів корекції на блок, [(скільки блоків, байтів даних у блоці)]).
_BLOCKS_M = {
    1: (10, [(1, 16)]),
    2: (16, [(1, 28)]),
    3: (26, [(1, 44)]),
    4: (18, [(2, 32)]),
    5: (24, [(2, 43)]),
    6: (16, [(4, 27)]),
    7: (18, [(4, 31)]),
    8: (22, [(2, 38), (2, 39)]),
    9: (22, [(3, 36), (2, 37)]),
    10: (26, [(4, 43), (1, 44)]),
    11: (30, [(1, 50), (4, 51)]),
    12: (22, [(6, 36), (2, 37)]),
    13: (22, [(8, 37), (1, 38)]),
    14: (24, [(4, 40), (5, 41)]),
    15: (24, [(5, 41), (5, 42)]),
}
_ALIGN = {
    1: [], 2: [6, 18], 3: [6, 22], 4: [6, 26], 5: [6, 30], 6: [6, 34],
    7: [6, 22, 38], 8: [6, 24, 42], 9: [6, 26, 46], 10: [6, 28, 50],
    11: [6, 30, 54], 12: [6, 32, 58], 13: [6, 34, 62], 14: [6, 26, 46, 66],
    15: [6, 26, 48, 70],
}
_REMAINDER_BITS = {1: 0, 2: 7, 3: 7, 4: 7, 5: 7, 6: 7, 7: 0, 8: 0, 9: 0, 10: 0,
                   11: 0, 12: 0, 13: 0, 14: 3, 15: 3}
_LEVEL_M_BITS = 0          # два біти рівня у форматі: L=01, M=00, Q=11, H=10
MAX_VERSION = max(_BLOCKS_M)


def _data_capacity(v) -> int:
    return sum(n * k for n, k in _BLOCKS_M[v][1])


# ─────────────────────────── REED-SOLOMON У GF(256) ─────────────────────────
def _gf_mul(x, y) -> int:
    z = 0
    for i in range(7, -1, -1):
        z = (z << 1) ^ ((z >> 7) * 0x11D)
        z ^= ((y >> i) & 1) * x
    return z


def _rs_divisor(degree) -> list:
    out = [0] * (degree - 1) + [1]
    root = 1
    for _ in range(degree):
        for j in range(len(out)):
            out[j] = _gf_mul(out[j], root)
            if j + 1 < len(out):
                out[j] ^= out[j + 1]
        root = _gf_mul(root, 0x02)
    return out


def rs_remainder(data, degree) -> list:
    """Байти корекції для блоку даних (остача від ділення на породжувач)."""
    div = _rs_divisor(degree)
    out = [0] * degree
    for b in data:
        factor = b ^ out.pop(0)
        out.append(0)
        for i, coef in enumerate(div):
            out[i] ^= _gf_mul(coef, factor)
    return out


# ─────────────────────────── ДАНІ → КОДОВІ СЛОВА ────────────────────────────
def _version_for(nbytes) -> int:
    for v in range(1, MAX_VERSION + 1):
        count_bits = 8 if v <= 9 else 16
        if 4 + count_bits + 8 * nbytes <= 8 * _data_capacity(v):
            return v
    raise QrError("рядок задовгий для QR-коду: %d байтів, найбільше — %d"
                  % (nbytes, _data_capacity(MAX_VERSION) - 3))


def _codewords(raw: bytes, v: int) -> list:
    bits = []

    def put(val, n):
        bits.extend((val >> i) & 1 for i in range(n - 1, -1, -1))
    put(0b0100, 4)                                   # режим «байти»
    put(len(raw), 8 if v <= 9 else 16)
    for b in raw:
        put(b, 8)
    cap = 8 * _data_capacity(v)
    put(0, min(4, cap - len(bits)))                  # термінатор
    put(0, (-len(bits)) % 8)
    data = [int("".join(map(str, bits[i:i + 8])), 2) for i in range(0, len(bits), 8)]
    pad = 0xEC
    while len(data) < _data_capacity(v):
        data.append(pad)
        pad ^= 0xEC ^ 0x11
    # Блоки, корекція і перемежування.
    ec_len, groups = _BLOCKS_M[v]
    blocks, pos = [], 0
    for n, k in groups:
        for _ in range(n):
            blocks.append(data[pos:pos + k])
            pos += k
    ecc = [rs_remainder(b, ec_len) for b in blocks]
    out = []
    for i in range(max(len(b) for b in blocks)):
        for b in blocks:
            if i < len(b):
                out.append(b[i])
    for i in range(ec_len):
        for e in ecc:
            out.append(e[i])
    return out


# ─────────────────────────── МАТРИЦЯ ────────────────────────────────────────
class _Grid:
    def __init__(self, v):
        self.v = v
        self.n = 17 + 4 * v
        self.m = [[False] * self.n for _ in range(self.n)]
        self.f = [[False] * self.n for _ in range(self.n)]   # службові модулі

    def fn(self, x, y, dark):
        self.m[y][x] = bool(dark)
        self.f[y][x] = True

    def draw_function(self):
        n = self.n
        for i in range(n):
            self.fn(6, i, i % 2 == 0)
            self.fn(i, 6, i % 2 == 0)
        for cx, cy in ((3, 3), (n - 4, 3), (3, n - 4)):
            for dy in range(-4, 5):
                for dx in range(-4, 5):
                    x, y = cx + dx, cy + dy
                    if 0 <= x < n and 0 <= y < n:
                        self.fn(x, y, max(abs(dx), abs(dy)) not in (2, 4))
        pos = _ALIGN[self.v]
        last = len(pos) - 1
        for i, ay in enumerate(pos):
            for j, ax in enumerate(pos):
                if (i, j) in ((0, 0), (0, last), (last, 0)):
                    continue
                for dy in range(-2, 3):
                    for dx in range(-2, 3):
                        self.fn(ax + dx, ay + dy, max(abs(dx), abs(dy)) != 1)
        self.draw_format(0)
        self.draw_version()

    def draw_format(self, mask):
        data = (_LEVEL_M_BITS << 3) | mask
        rem = data
        for _ in range(10):
            rem = (rem << 1) ^ ((rem >> 9) * 0x537)
        bits = ((data << 10) | rem) ^ 0x5412
        n = self.n

        def bit(i):
            return (bits >> i) & 1
        for i in range(6):
            self.fn(8, i, bit(i))
        self.fn(8, 7, bit(6))
        self.fn(8, 8, bit(7))
        self.fn(7, 8, bit(8))
        for i in range(9, 15):
            self.fn(14 - i, 8, bit(i))
        for i in range(8):
            self.fn(n - 1 - i, 8, bit(i))
        for i in range(8, 15):
            self.fn(8, n - 15 + i, bit(i))
        self.fn(8, n - 8, True)                       # темний модуль

    def draw_version(self):
        if self.v < 7:
            return
        rem = self.v
        for _ in range(12):
            rem = (rem << 1) ^ ((rem >> 11) * 0x1F25)
        bits = (self.v << 12) | rem
        for i in range(18):
            b = (bits >> i) & 1
            a, c = self.n - 11 + i % 3, i // 3
            self.fn(a, c, b)
            self.fn(c, a, b)

    def draw_codewords(self, words):
        n, i, total = self.n, 0, len(words) * 8
        right = n - 1
        while right >= 1:
            if right == 6:
                right = 5
            for vert in range(n):
                for j in range(2):
                    x = right - j
                    upward = ((right + 1) & 2) == 0
                    y = n - 1 - vert if upward else vert
                    if not self.f[y][x] and i < total:
                        self.m[y][x] = bool((words[i >> 3] >> (7 - (i & 7))) & 1)
                        i += 1
            right -= 2

    def apply_mask(self, mask):
        for y in range(self.n):
            for x in range(self.n):
                if self.f[y][x]:
                    continue
                if mask == 0:
                    inv = (x + y) % 2 == 0
                elif mask == 1:
                    inv = y % 2 == 0
                elif mask == 2:
                    inv = x % 3 == 0
                elif mask == 3:
                    inv = (x + y) % 3 == 0
                elif mask == 4:
                    inv = (x // 3 + y // 2) % 2 == 0
                elif mask == 5:
                    inv = x * y % 2 + x * y % 3 == 0
                elif mask == 6:
                    inv = (x * y % 2 + x * y % 3) % 2 == 0
                else:
                    inv = ((x + y) % 2 + x * y % 3) % 2 == 0
                self.m[y][x] ^= inv

    def penalty(self) -> int:
        """Штраф стандарту: довгі смуги, квадрати 2×2, схожість на пошуковий
        квадрат, перекіс темного й світлого."""
        n, m, score = self.n, self.m, 0
        lines = [row for row in m] + [[m[y][x] for y in range(n)] for x in range(n)]
        finder_a = [True, False, True, True, True, False, True, False, False, False, False]
        finder_b = finder_a[::-1]
        for line in lines:
            run, prev = 0, None
            for c in line:
                if c == prev:
                    run += 1
                else:
                    if run >= 5:
                        score += run - 2
                    run, prev = 1, c
            if run >= 5:
                score += run - 2
            for i in range(n - 10):
                seg = line[i:i + 11]
                if seg == finder_a or seg == finder_b:
                    score += 40
        for y in range(n - 1):
            for x in range(n - 1):
                c = m[y][x]
                if c == m[y][x + 1] == m[y + 1][x] == m[y + 1][x + 1]:
                    score += 3
        dark = sum(sum(1 for c in row if c) for row in m)
        total = n * n
        k = (abs(dark * 20 - total * 10) + total - 1) // total - 1
        score += max(0, k) * 10
        return score


def encode(text) -> list:
    """Рядок → квадратна матриця модулів (True — темний), без тихої зони."""
    raw = text.encode("utf-8") if isinstance(text, str) else bytes(text)
    v = _version_for(len(raw))
    words = _codewords(raw, v)
    best, best_score = None, None
    for mask in range(8):
        g = _Grid(v)
        g.draw_function()
        g.draw_codewords(words)
        g.apply_mask(mask)
        g.draw_format(mask)
        s = g.penalty()
        if best_score is None or s < best_score:
            best, best_score = g, s
    return best.m


def svg(matrix, module_px: int = 6, quiet: int = 4) -> str:
    """Матриця → SVG. Лише прямокутники одного шляху; тиха зона — 4 модулі
    (менше стандарт не дозволяє: телефон не знайде межу коду)."""
    n = len(matrix)
    size = (n + 2 * quiet) * module_px
    parts = []
    for y, row in enumerate(matrix):
        for x, c in enumerate(row):
            if c:
                parts.append("M%d %dh1v1h-1z" % (x + quiet, y + quiet))
    return ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 %d %d" width="%d" '
            'height="%d" shape-rendering="crispEdges" role="img" aria-label="QR-код">'
            '<rect width="100%%" height="100%%" fill="#fff"/>'
            '<path fill="#000" d="%s"/></svg>'
            % (n + 2 * quiet, n + 2 * quiet, size, size, "".join(parts)))

