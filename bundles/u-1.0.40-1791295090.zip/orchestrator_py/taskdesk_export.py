# -*- coding: utf-8 -*-
"""
taskdesk_export.py — ВИВАНТАЖЕННЯ НАЛАШТОВАНОГО СПИСКУ ЗАДАЧ У XLSX.

⭐⭐⭐ ЗАКОН ЦЬОГО ФАЙЛА: **ЩО НА ЕКРАНІ — ТЕ Й У ФАЙЛІ.** Він не знає жодного
поля, жодної колонки й жодного правила фільтрації — усе це він питає в
`taskdesk_fields`, того самого реєстру, з якого малюється список. Тому файл
фізично не може розійтися з тим, що людина бачила, коли натискала кнопку.

Що він робить сам: кладе аркуш, шапку, ширину колонок, заморожує перший рядок і
дописує підпис — хто, коли і за яким фільтром вивантажив. Підпис потрібен, бо
таблиця без нього через тиждень бреше: незрозуміло, це всі задачі чи вибірка.

⛒⛒ 669 (01.10.2026): ФАЙЛ ЇДЕ ЛЮДИНІ В БРАУЗЕР, А НЕ В ТЕКУ НА СЕРВЕРІ.
🩸 Досі файл лягав у теку «Вивантаження задач» поруч із платформою, а
провідник відкривався на машині СЕРВЕРА: людина за своїм комп'ютером не
отримувала нічого, а файли з даними компанії копились у чужій теці. Тепер
теку дає той, хто віддає файл (двері `/api/taskdesk/export`), і прибирає її
одразу після того, як файл поїхав. Право на вивантаження і слід у журналі —
`taskdesk_api.export_tasks`.

⚠ Мозок (LLM) сюди не ходить.
"""

import origin
import re
from datetime import datetime
from pathlib import Path

import taskdesk_fields as fields


class ExportError(Exception):
    """Відмова з причиною словами."""


def _safe(name: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "-", str(name or "")).strip() or "Задачі"


def _filter_words(flt, ctx) -> str:
    """Фільтр — словами, щоб підпис у файлі читала людина, а не програміст."""
    if not flt:
        return "без фільтра — усе, що видно"
    parts = []
    for fid, cond in flt.items():
        f = fields.BY_ID.get(fid)
        if not f:
            continue
        if f["filter"] == "set":
            if f["kind"] == "person":
                vals = [ctx["names"].get(v, v) for v in (cond or [])]
            elif f["id"] == "stage":
                import taskdesk_tasks as _t
                vals = [_t.STAGE_NAMES.get(v, v) for v in (cond or [])]
            else:
                vals = list(cond or [])
            if vals:
                parts.append("%s: %s" % (f["label"], ", ".join([str(v) for v in vals])))
        elif f["filter"] == "text" and str(cond or "").strip():
            parts.append('%s містить «%s»' % (f["label"], cond))
        elif f["filter"] == "date":
            lo, hi = (cond or {}).get("from"), (cond or {}).get("to")
            if lo or hi:
                parts.append("%s: %s — %s" % (f["label"], lo or "…", hi or "…"))
        elif f["filter"] == "flag" and cond not in (None, "", "any"):
            yes = cond in (True, "true", "1", 1, "так")
            parts.append("%s: %s" % (f["label"], "так" if yes else "ні"))
    return " · ".join(parts) or "без фільтра — усе, що видно"


def _require_openpyxl():
    try:
        import openpyxl                                    # noqa: F401
        return openpyxl
    except Exception:
        raise ExportError(
            "Для вивантаження в Excel потрібна бібліотека openpyxl, а її тут немає. "
            "Встановіть її одним рядком у командному рядку: "
            "python -m pip install openpyxl — і натисніть «Вивантажити» ще раз.")


def build(tasks_list, columns, ctx, who_name: str = "", flt=None,
          scope_name: str = "", query: str = "", folder=None) -> dict:
    """Складає файл у теку `folder` (її дає той, хто віддає файл) і каже, що
    поклав. Нічого нікуди не надсилає."""
    if not folder:
        raise ExportError("Вивантаженню не дали теки: файл задач на сервері не лишається.")
    openpyxl = _require_openpyxl()
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    cols = fields.normalize_columns(columns)
    heads = [fields.field(c)["label"] for c in cols]

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Задачі"

    ws.append(heads)
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="173A44")
        cell.alignment = Alignment(vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"

    late = Font(color="B3261E", bold=True)
    for t in tasks_list:
        ws.append(fields.row(t, cols, ctx))
        if t.get("overdue"):
            for cell in ws[ws.max_row]:
                cell.font = late

    for i, c in enumerate(cols, start=1):
        ws.column_dimensions[get_column_letter(i)].width = fields.field(c)["w"]

    stamp = datetime.now().strftime("%d.%m.%Y %H:%M")
    ws.append([])
    ws.append(["Вивантажив: %s · %s" % (who_name or "—", stamp)])
    ws.append(["Показано: %s" % (scope_name or "усі видимі задачі")])
    ws.append(["Фільтр: %s" % _filter_words(flt, ctx)])
    # Файл каже ПРАВДУ про те, як його звузили: без цього рядка вивантаження
    # з пошуком читалось би як «всі задачі» — те саме мовчазне обрізання.
    ws.append(["Пошук: %s" % (str(query or "").strip() or "не задавали")])
    ws.append(["Задач у файлі: %d" % len(tasks_list)])
    note = Font(italic=True, color="5F6B70")
    for r in range(ws.max_row - 4, ws.max_row + 1):
        ws.cell(row=r, column=1).font = note

    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    name = "%s %s.xlsx" % (_safe("Задачі SensFlow"),
                           datetime.now().strftime("%d-%m-%Y %H-%M-%S"))
    path = folder / name
    wb.save(str(path))
    origin.stamp(path)   # ⛒ 583: ОДИН писар походження на всі виходи
    return {"ok": True, "path": str(path), "folder": str(folder), "name": name,
            "rows": len(tasks_list), "columns": cols,
            "bytes": path.stat().st_size if path.exists() else 0}

