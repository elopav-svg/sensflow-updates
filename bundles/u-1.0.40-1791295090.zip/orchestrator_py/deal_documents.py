# -*- coding: utf-8 -*-
"""deal_documents.py — ДОКУМЕНТИ УГОДИ (зміна 585, 16.09.2026).

⛒ ЗАКОН, ЗАРАДИ ЯКОГО ЦЕ НАПИСАНО. Слово Андрія 13.09.2026:
«Жодна угода без договору, який причеплений до цієї угоди, не може вважатися
успішно завершеною.»

Це НЕ поле в картці. Це ПРАВИЛО ЗАКРИТТЯ УГОДИ, а поле — лише те, чим правило
вміє себе довести. Тому тут живе САМ ДОКУМЕНТ як сутність (тип · номер · дата ·
сума · файл), а ворота стадії стоять там, де стоять усі ворота стадій, — у
`deals.check_stage_ready`. Другого сторожа поруч не заводимо.

🩸 ЩО БУЛО ДО ЦЬОГО. Картка угоди d0014 («Каспер») знала суму й стадію, але не
знала, що договір узагалі існує: номер `14.09-1` жив лише в документах
бухгалтера і в теці на робочому столі. Через півроку питання «за яким договором
ми йому щось винні» розвʼязувалось би пошуком по диску.

⛒ ОКРЕМЕ СХОВИЩЕ, А НЕ ПОЛЕ В УГОДІ — з тієї ж причини, що й позиції:
`deals.json` читає кожен екран списку й кожна воронка.

⛒ ФАЙЛ КОПІЮЄТЬСЯ В СХОВИЩЕ ПЛАТФОРМИ (`file_store`), а не лишається
посиланням на чужий диск. Картка не має ламатись від того, що хтось переклав
файл у себе на робочому столі. Оригінал людини ми не чіпаємо.

⛒ НОМЕР ВИДАЄ ОДИН ПИСАР (`doc_numbers`). Номер, набраний руками, рано чи
пізно збігається з чужим. Але номер, який УЖЕ стоїть у паперах бухгалтера,
заводиться як факт — платформа не вдає, ніби світ почався з неї.

⛒ ОБОВʼЯЗКОВИЙ — ДОГОВІР. Рахунок і акт живуть у тій самій картці, але
шлагбаумом не є: не роздуваємо правило ширше, ніж його назвав власник.
"""
import config
import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import deals
import doc_numbers as numbers     # ОДИН ПИСАР НОМЕРІВ
import entity                     # спільне імʼя сутності на всю платформу
import file_store                 # ОДИН рушій файлового сховища
import one_writer
import parties                    # 648: власник документа може бути клієнтом
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій

config.refuse_live_state_for_checks(__name__)

DIR = config.CRM_DIR
DOCS_JSON = DIR / "deal_documents.json"

KIND_CONTRACT = "contract"
KIND_INVOICE = "invoice"
KIND_ACT = "act"
KIND_OTHER = "other"
# ⭐⭐⭐ 615 (20.09.2026). ЧОТИРИ СЛОТИ ДОГОВОРУ — СЛОВО АНДРІЯ, З ПРИЦІЛОМ НА
# МАЙБУТНІЙ РЕПОЗИТОРІЙ ДОГОВОРІВ: «Проект договору», «Додатки» (кілька),
# «Підписаний договір з додатками» (кілька), «Дата підписання».
# ⛒ Це НЕ нові поля збоку. Власні поля картки поруч із цим реєстром дали б
# ДВОХ ПИСАРІВ однієї правди, і репозиторій збирався б із двох джерел, які
# розійдуться. Тому слоти — це ТИПИ в тому самому реєстрі, множинність у
# ньому вже є за побудовою (документів до угоди може бути скільки завгодно),
# а «дата підписання» — це дата підписаного договору (`signed_at`), а не
# друге поле з тією самою датою.
# ⛒ І правило 585 не розхитується: закриває угоду ЛИШЕ підписаний договір.
# Проект і додаток — ні, і саме тому вони окремі типи, а не «договір».
KIND_DRAFT = "draft_contract"
KIND_ANNEX = "annex"

# ⭐⭐⭐ 648 (26.09.2026). ДОКУМЕНТИ САМОГО КЛІЄНТА — статут, витяг з ЄДР,
# довіреність, ліцензія/дозвіл. Каспер: «документи — щоб були в картці клієнта».
# ⛒ ТОЙ САМИЙ РЕЄСТР, ІНШИЙ ВЛАСНИК. Рядок належить угоді (`deal`) АБО клієнтові
# (`party`). Друге сховище «документів контрагента» поруч дало б двох писарів
# однієї правди: той самий статут лежав би двічі й розходився.
# ⛒ Папір клієнта — ФАКТ, який видав не він у нас: номер пишеться як є (або не
# пишеться), наш реєстр номерів (`doc_numbers`) не палиться.
KIND_STATUTE = "statute"
KIND_EXTRACT = "extract"
KIND_POWER = "power"
KIND_PERMIT = "permit"
PARTY_KINDS = (KIND_STATUTE, KIND_EXTRACT, KIND_POWER, KIND_PERMIT, KIND_OTHER)

# ⭐⭐⭐ 651 (28.09.2026). ТТН — ПАПІР ФОРМИ ОПЛАТИ «НАКЛАДЕНИЙ ПЛАТІЖ». Каспер:
# «до угоди потрібно підтягнути ТТН». Це папір ПЕРЕВІЗНИКА: номер у нього вже є,
# і наш реєстр номерів він не палить — так само, як статут чи витяг клієнта.
KIND_TTN = "ttn"
# ⛒ ЧУЖИЙ ПАПІР — ОДИН ПЕРЕЛІК. Номер такого паперу пишеться як є; наш писар
# номерів його не бачить. Доти це правило жило умовою «тип клієнта, крім
# іншого» прямо в `add()`, і ТТН туди не влазила б без другої умови поруч.
EXTERNAL_KINDS = (KIND_STATUTE, KIND_EXTRACT, KIND_POWER, KIND_PERMIT, KIND_TTN)

# ⭐⭐⭐ 662 (30.09.2026). ЧИЙ НОМЕР — ФАКТ ДОКУМЕНТА, А НЕ ФОРМА РЯДКА.
# 🩸 ОТУ підписав договір № «30/09-26» — номер поставив КОНТРАГЕНТ. Підписаний
# договір — наш тип, тож номер ішов у НАШ реєстр і не лягав: у картці d0019
# опинилось «30.09-26», якого немає в жодному папері.
# ⛒ Хто видав номер — питання не типу, а паперу: договір, рахунок, акт бувають і
# наші, і контрагента. Тому номер несе позначку `number_by`. Наш номер видає і
# стереже `doc_numbers` (issue / reserve); номер контрагента пишеться ДОСЛІВНО
# (`doc_numbers.foreign`), наш реєстр не палить і з нашими не зіштовхується.
# Папір, що за природою чужий (EXTERNAL_KINDS, документи клієнта), — завжди
# «контрагента»; для решти людина каже сама, а без слова — «наш», як і було.
NUMBER_OURS = "ours"
NUMBER_THEIRS = "theirs"
NUMBER_BYS = (NUMBER_OURS, NUMBER_THEIRS)
# Назви короткі: це варіанти вибору у вузькому полі форми; пояснення — у підказці.
NUMBER_BY_NAMES = {
    NUMBER_OURS: "наш",
    NUMBER_THEIRS: "контрагента",
}

# ⛒ ПЕРЕЛІК ЗАКРИТИЙ: невідомий тип — відмова, а не тихий запис «other».
# Угода приймає і свої типи, і папери клієнта (взяті з його картки).
KINDS = (KIND_DRAFT, KIND_ANNEX, KIND_CONTRACT, KIND_INVOICE, KIND_ACT, KIND_TTN,
         KIND_STATUTE, KIND_EXTRACT, KIND_POWER, KIND_PERMIT, KIND_OTHER)
KIND_NAMES = {
    KIND_DRAFT: "проект договору",
    KIND_ANNEX: "додаток до договору",
    KIND_CONTRACT: "підписаний договір з додатками",
    KIND_INVOICE: "рахунок",
    KIND_ACT: "акт",
    KIND_TTN: "ТТН (накладна перевізника)",
    KIND_STATUTE: "статут",
    KIND_EXTRACT: "витяг з ЄДР",
    KIND_POWER: "довіреність",
    KIND_PERMIT: "ліцензія або дозвіл",
    KIND_OTHER: "інший документ",
}


class DealDocError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ───────────────────────── ОДИН ЧИТАЧ / ОДИН ПИСАР ─────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(DOCS_JSON)
    except PermissionError:
        raise                      # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("docs", {})
    d.setdefault("seq", 0)
    return d


def _save(d: dict) -> None:
    DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(DOCS_JSON, d)


def _new_id(d: dict) -> str:
    seq = int(d.get("seq") or 0) + 1
    while ("doc%04d" % seq) in d["docs"]:
        seq += 1
    d["seq"] = seq
    return "doc%04d" % seq


def _to_protocol(action: str, did: str, what: str) -> None:
    """Хто зберігає — той і звітує. Слід іде в журнал УГОДИ.
    ⚠ Ніколи не валить роботу: реєстр — актив, журнал — його тінь."""
    try:
        about = []
        pid = deals.client_of(did)
        if pid:
            about.append(entity.ref(entity.KIND_PARTY, pid))
        protocol.write(action, entity.ref(entity.KIND_DEAL, _s(did)),
                       about=about, note=what)
    except Exception:
        pass


def check_kind(kind) -> str:
    k = _s(kind)
    if k not in KINDS:
        raise DealDocError("Невідомий тип документа «%s». Угода знає: %s."
                           % (k, ", ".join("%s (%s)" % (KIND_NAMES[x], x)
                                           for x in KINDS)))
    return k


def number_by_of(row: dict) -> str:
    """⭐⭐⭐ 662. ЧИЙ НОМЕР У ЦЬОГО ДОКУМЕНТА — ОДИН ЧИТАЧ НА ВСІ МІСЦЯ.

    Позначка рядка — старша. Рядки до 662 її не мають, і для них правда та сама,
    що тоді вирішувала, куди піде номер: чужий за природою папір (EXTERNAL_KINDS),
    папір із картки клієнта і взятий звідти в угоду — контрагента; решта — наш."""
    nb = _s(row.get("number_by"))
    if nb in NUMBER_BYS:
        return nb
    if _s(row.get("kind")) in EXTERNAL_KINDS:
        return NUMBER_THEIRS
    if _s(row.get("from_doc")) or (_s(row.get("party")) and not _s(row.get("deal"))):
        return NUMBER_THEIRS
    return NUMBER_OURS


def check_number_by(kind: str, number_by) -> str:
    """Хто видав номер цього паперу — або відмова словами. Без слова — природа типу."""
    nb = _s(number_by)
    if not nb:
        return NUMBER_THEIRS if kind in EXTERNAL_KINDS else NUMBER_OURS
    if nb not in NUMBER_BYS:
        raise DealDocError("Невідомо, чий це номер («%s»). Номер буває: %s."
                           % (nb, "; ".join("%s (%s)" % (NUMBER_BY_NAMES[x], x)
                                            for x in NUMBER_BYS)))
    if nb == NUMBER_OURS and kind in EXTERNAL_KINDS:
        raise DealDocError("«%s» — чужий папір (його видав контрагент, держава або "
                           "перевізник): нашого номера в нього не буває."
                           % KIND_NAMES.get(kind, kind))
    return nb


def said(row: dict) -> str:
    """Як документ звучить у журналі й на екрані — ОДНИМ писарем на всі місця."""
    out = KIND_NAMES.get(_s(row.get("kind")), "документ")
    if _s(row.get("number")):
        out += " № " + _s(row.get("number"))
    if _s(row.get("date")):
        out += " від " + _s(row.get("date"))
    if _s(row.get("amount")):
        out += " на " + _s(row.get("amount"))
    return out


# ───────────────────────────────── ЧИТАННЯ ─────────────────────────────────
def get(doc_id) -> dict:
    return dict(_load()["docs"].get(_s(doc_id)) or {}) or {}


def exists(doc_id) -> bool:
    return bool(get(doc_id))


def documents_of(did) -> list:
    """Документи однієї угоди, у порядку додавання.

    ⭐ 592: СУМА ДОКУМЕНТА — ТЕЖ ГРОШІ УГОДИ. Сам факт «договір № такий-то від
    такої дати є» лишається видимим — на ньому тримається правило 585 («угода
    без договору не закривається»), і колега мусить бачити, що папір існує.
    А скільки в тому папері — справа відповідального й керівника."""
    key = _s(did)
    out = [dict(v) for v in _load()["docs"].values() if _s(v.get("deal")) == key]
    for x in out:
        x["number_by"] = number_by_of(x)      # 662: і старий рядок їде з правдою «чий номер»
    out.sort(key=lambda x: (_s(x.get("created")), _s(x.get("id"))))
    try:
        import entity_scope as _vs592d
        return _vs592d.hide_money(out, ("amount",), did=key)
    except Exception:
        return out


def contracts_of(did) -> list:
    return [x for x in documents_of(did) if _s(x.get("kind")) == KIND_CONTRACT]


def has_contract(did) -> bool:
    """⭐⭐⭐ ВІДПОВІДЬ, ЯКУ ПИТАЮТЬ ВОРОТА СТАДІЇ. Одна, і живе вона тут."""
    return bool(contracts_of(did))


def has_kind(did, kind, skip: str = "") -> bool:
    """⭐⭐⭐ 651. Чи є в угоді папір цього типу — ОДНА відповідь для воріт стадії.

    `skip` — документ, якого вже «немає»: так ворота судять стан ПІСЛЯ
    відчеплення, не відчіпляючи насправді (прибрати й повернути — це два
    записи й вікно, в якому угода стоїть без паперу)."""
    k, sk = _s(kind), _s(skip)
    return any(_s(x.get("kind")) == k and _s(x.get("id")) != sk
               for x in documents_of(did))


def annexes_of(did) -> list:
    """Додатки до договору. Їх може бути скільки завгодно."""
    return [x for x in documents_of(did) if _s(x.get("kind")) == KIND_ANNEX]


def drafts_of(did) -> list:
    """Проекти договору — те, що ще не підписано."""
    return [x for x in documents_of(did) if _s(x.get("kind")) == KIND_DRAFT]


def signed_at(did) -> str:
    """⭐⭐⭐ 615. ДАТА ПІДПИСАННЯ — ОДИН ПИСАР, І ВІН ТУТ.

    ⛒ Це НЕ окреме поле, яке хтось заповнює вдруге: це дата ПІДПИСАНОГО
    договору. Друге поле з тією самою датою означало б, що завтра вони
    розійдуться, і репозиторій договорів не знатиме, якому вірити.
    ⛒ Немає підписаного договору — немає й дати. Дату проекту ми не видаємо
    за дату підписання: це рівно та тиха брехня, від якої лікувались 609.
    """
    dates = [_s(x.get("date")) for x in contracts_of(did) if _s(x.get("date"))]
    return dates[-1] if dates else ""


# ───────────────────────────────── ЗАПИС ───────────────────────────────────
def add(did, kind, src=None, name: str = "", date: str = "", amount: str = "",
        number: str = "", by: str = "", file_id: str = "",
        number_by: str = "") -> dict:
    """Причепити документ до угоди.

    `number` порожній — номер видає платформа; названий — заводиться як ФАКТ,
    що вже стався (папір бухгалтера). Обидва шляхи ведуть через одного писаря
    номерів, тому два документи одного дня не зіткнуться.

    ⭐ 662: `number_by="theirs"` — номер поставив контрагент: пишеться дослівно,
    наш реєстр не палить. Без слова — наш (для чужого за природою паперу — чужий).

    ⛒ СПЕРШУ ПЕРЕВІРЯЄМО ВСЕ, ПОТІМ ПИШЕМО. Половини не буває: файл у сховищі
    без запису в реєстрі — це сирота, а запис без файла — брехня в картці."""
    dk = _s(did)
    if not deals.exists(dk):
        raise DealDocError("Угоди %s немає." % (dk or "«»"))
    k = check_kind(kind)
    ds = numbers.check_date(date) if _s(date) else numbers.today()
    what = "%s, угода %s" % (KIND_NAMES[k], dk)
    # ⛒ 662: чий номер і чи він справді номер — ДО файла: чужий номер нічого не
    # палить, тож судиться першим, і невдала спроба не лишає сироти у сховищі.
    nb = check_number_by(k, number_by)
    theirs_num = ""
    if nb == NUMBER_THEIRS:
        try:
            theirs_num = numbers.foreign(number, required=(k not in EXTERNAL_KINDS))
        except numbers.NumberError as ex:
            raise DealDocError(str(ex))

    # ⛒ ПОРЯДОК КРОКІВ НЕ ВИПАДКОВИЙ. Спершу файл, потім номер.
    # Номер із реєстру не повертається НІКОЛИ (у цьому його сенс), тому взяти
    # його першим означало б палити номер на кожній невдалій спробі: диск
    # скінчився, файл завеликий — а в реєстрі вже дірка, якої ніхто не пояснить.
    # Файл, навпаки, прибрати можна, і нижче ми це й робимо, якщо номер не ліг.

    # 1. Файл у сховищі платформи. Оригінал людини не чіпаємо.
    # ⛒ ЗАВАНТАЖУВАЧ НА ПЛАТФОРМІ ОДИН (`/api/files/upload` -> `file_store`).
    # Екран кладе файл ним і приносить сюди готовий `file_id`; другого шляху
    # для тих самих байтів ми не заводимо. `src` лишається для проб і для
    # роботи з коду, де HTTP немає.
    if _s(file_id):
        blob = file_store.info(_s(file_id))
        if not blob:
            raise DealDocError("Файла %s немає у сховищі — документ без файла "
                               "не чіпляється." % _s(file_id))
    else:
        if src is None:
            raise DealDocError("Документ без файла не чіпляється: договір — це "
                               "папір, а не запис про папір.")
        try:
            blob = file_store.put(src, name, by=by)
        except Exception as ex:
            raise DealDocError("Документ не збережено: %s" % ex)

    # 2. Номер. Якщо він не ліг, а файл клали МИ — прибираємо за собою:
    # половини не буває, і сироти в сховищі теж.
    try:
        if nb == NUMBER_THEIRS:
            num = theirs_num          # ⛒ 648/651/662: чужий номер — факт, наших номерів не палить
        else:
            num = (numbers.reserve(number, ds, what) if _s(number)
                   else numbers.issue(ds, what))
    except Exception:
        if not _s(file_id):
            try:
                file_store.remove(_s(blob.get("id")))
            except Exception:
                pass
        raise

    d = _load()
    doc_id = _new_id(d)
    row = {
        "id": doc_id,
        "deal": dk,
        "kind": k,
        "number": num,
        "number_by": nb,
        "date": ds,
        # ⛒ Сума лежить ТЕКСТОМ, як її ввела людина: платформа нічого не рахує
        # (те саме рішення, що й у позиціях угоди).
        "amount": _s(amount),
        "file_id": _s(blob.get("id")),
        "file_name": _s(blob.get("name")) or _s(name),
        "by": _s(by),
        "created": clock.now(),
    }
    d["docs"][doc_id] = row
    _save(d)
    _to_protocol(protocol.A_DEAL_DOC_ADDED, dk, "причеплено: " + said(row))
    return dict(row)


@one_writer.guard("DEAL_DOCS_JSON")
def restate(doc_id, src=None, name: str = "", file_id: str = "",
            amount=None, date=None, by: str = "") -> dict:
    """ЗАМІНИТИ ПАПІР ДОКУМЕНТА. Документ лишається ТИМ САМИМ.

    🩸 ЧОМУ ЦЕ ОКРЕМА ДІЯ, А НЕ «ВІДЧЕПИТИ + ПРИЧЕПИТИ». 21.09.2026 договір із
    Каспером переукладено новою редакцією: той самий номер, та сама дата,
    інший текст. Через відчеплення це НЕ робиться за побудовою — номер із
    реєстру не повертається ніколи (`doc_numbers.issue`), тому документ із тим
    самим номером удруге не заводиться. Лишалось правити JSON руками повз усіх
    писарів або вигадувати номер, якого немає в паперах. Обидва шляхи — брехня
    в картці.

    ⛒ НОМЕР І ТИП НЕ МІНЯЮТЬСЯ ТУТ НІКОЛИ. Інший номер або інший тип — це
    ІНШИЙ документ, і заводиться він через `add`. Заміна паперу міняє рівно
    те, що змінилось у житті: файл, а за потреби — суму й дату.

    ⛒ ЩО НЕ НАЗВАЛИ — ТОГО НЕ ЧІПАЄМО. `amount=None` означає «сума лишається»,
    а не «сума порожня»: інакше кожна заміна файла тихо стирала б гроші.

    ⛒ СПЕРШУ ПЕРЕВІРЯЄМО ВСЕ, ПОТІМ ПИШЕМО — і прибираємо СТАРИЙ файл лише
    після того, як запис уже ліг. Половини не буває: ні документа без файла,
    ні сироти у сховищі.

    ⛒ І ОДНЕ ПРО ВОРОНКУ. `remove` свідомо не віддає договір з-під успішної
    стадії. Заміна паперу — віддає, бо угода договору НЕ втрачає: вимагати
    зсунути живого клієнта назад по воронці заради нової редакції означало б
    лікувати папером людину."""
    key = _s(doc_id)
    d = _load()
    row = d["docs"].get(key)
    if not row:
        raise DealDocError("Документа %s немає в угоді." % (key or "«»"))

    # 1. Дата — через одного писаря дат, ДО будь-якого запису.
    ds = _s(row.get("date"))
    if date is not None and _s(date):
        ds = numbers.check_date(date)      # сміття замість дати — відмова словами

    # 2. Новий файл. Або вже покладений завантажувачем, або кладемо тут.
    if _s(file_id):
        blob = file_store.info(_s(file_id))
        if not blob:
            raise DealDocError("Файла %s немає у сховищі — заміняти папір "
                               "нема на що." % _s(file_id))
    elif src is not None:
        try:
            blob = file_store.put(src, name, by=by)
        except Exception as ex:
            raise DealDocError("Нову редакцію не збережено: %s" % ex)
    else:
        raise DealDocError("Заміна паперу без нового файла не буває: міняємо "
                           "саме ПАПІР, а не запис про нього.")

    old_fid = _s(row.get("file_id"))
    new_row = dict(row)
    new_row["date"] = ds
    if amount is not None:
        new_row["amount"] = _s(amount)
    new_row["file_id"] = _s(blob.get("id"))
    new_row["file_name"] = _s(blob.get("name")) or _s(name)
    new_row["restated"] = clock.now()
    new_row["restated_by"] = _s(by)

    d["docs"][key] = new_row
    _save(d)

    # 3. Старий файл більше нікому не належить.
    if old_fid and old_fid != new_row["file_id"]:
        try:
            file_store.remove(old_fid)
        except Exception:
            pass
    _to_protocol(protocol.A_DEAL_DOC_RESTATED, _s(row.get("deal")),
                 "нова редакція: " + said(new_row))
    return dict(new_row)


@one_writer.guard("DEAL_DOCS_JSON")
def correct_number(doc_id, number, number_by: str = NUMBER_THEIRS, by: str = "") -> dict:
    """⭐⭐⭐ 662. ВИПРАВИТИ ЗАПИС НОМЕРА: ПАПІР ТОЙ САМИЙ, НОМЕР — КОНТРАГЕНТА.

    🩸 Живий випадок 30.09.2026: договір ОТУ № «30/09-26» лежав у картці d0019
    як «30.09-26» — наш реєстр інакше не пускав. Папір, файл, дата й сума —
    правдиві; хибний лише ЗАПИС номера. Це не нова редакція (`restate`: папір не
    мінявся) і не інший документ (`add`: інший номер — інший папір — тут не так).

    ⛒ ЛИШЕ В БІК «КОНТРАГЕНТА». Наш номер видає тільки наш реєстр і тільки
    під час `add`; «виправити» на наш номер означало б видати номер повз писаря.
    ⛒ Хибний запис у НАШОМУ реєстрі не звільняється, а називається помилковим
    (`doc_numbers.void`): виданий номер не видається вдруге ніколи.
    ⛒ Слід — у журнал угоди, своїм дієсловом: було → стало."""
    key = _s(doc_id)
    d = _load()
    row = d["docs"].get(key)
    if not row or not _s(row.get("deal")):
        # Папір із картки клієнта наш реєстр не палив ніколи: хибний номер там
        # лікується звичайно — прибрати й покласти заново.
        raise DealDocError("Документа угоди %s немає." % (key or "«»"))
    if _s(number_by) != NUMBER_THEIRS:
        raise DealDocError("Виправити запис можна лише на номер КОНТРАГЕНТА. Наш номер "
                           "видає реєстр платформи, коли документ заводять, — повз "
                           "нього номер не з'являється.")
    try:
        num = numbers.foreign(number, required=True)
    except numbers.NumberError as ex:
        raise DealDocError(str(ex))
    old_num, old_by = _s(row.get("number")), number_by_of(row)
    if old_num == num and old_by == NUMBER_THEIRS:
        return dict(row)
    fixed = dict(row)
    fixed["number"] = num
    fixed["number_by"] = NUMBER_THEIRS
    fixed["renumbered"] = clock.now()
    fixed["renumbered_by"] = _s(by)
    fixed["number_was"] = old_num
    d["docs"][key] = fixed
    _save(d)
    # Хибний запис у нашому реєстрі — назвати (номер лишається зайнятим).
    if old_by == NUMBER_OURS and old_num:
        try:
            numbers.void(old_num, _s(row.get("date")),
                         "документ %s — номер контрагента «%s»" % (key, num))
        except numbers.NumberError:
            pass              # у нашому реєстрі такого запису не було — називати нічого
    what = "запис номера виправлено: був № %s (%s), став № %s (%s) — %s" % (
        old_num or "—", "наш" if old_by == NUMBER_OURS else "контрагента", num,
        "контрагента", said(fixed))
    _to_protocol(protocol.A_DEAL_DOC_RENUMBERED, _s(row.get("deal")), what)
    return dict(fixed)


@one_writer.guard("DEAL_DOCS_JSON")
def remove(doc_id, by: str = "") -> bool:
    """Відчепити документ від угоди — разом із його файлом у сховищі.

    ⛔ ДОГОВІР НЕ ВІДЧІПЛЯЄТЬСЯ З-ПІД УГОДИ, ЯКА СТОЇТЬ НА УСПІШНІЙ СТАДІЇ.
    Інакше правило обходилось би за два кроки: причепив — перевів — відчепив.
    ⛒ І ми свідомо НЕ повертаємо угоду назад самі: мовчки зсунути живого
    клієнта з «Активних» на «Перемовини» гірше, ніж чесно сказати людині, що
    спершу треба повернути угоду. Стадія — рішення людини, а не наслідок
    прибирання файла."""
    key = _s(doc_id)
    d = _load()
    row = d["docs"].get(key)
    if not row:
        raise DealDocError("Документа %s немає в угоді." % (key or "«»"))
    if not _s(row.get("deal")) and _s(row.get("party")):
        return _remove_party_doc(d, key, row, by=by)
    dk = _s(row.get("deal"))
    # ⛒ 651: ЧИ МОЖНА ВІДЧЕПИТИ — СУДЯТЬ ТІ САМІ ВОРОТА СТАДІЇ, що й перехід.
    # Доти тут жила своя копія правила «договір + успішна стадія»; з формами
    # оплати вона пропускала б рахунок, ТТН і будь-який майбутній папір.
    cur = deals.get(dk) or {}
    stage = _s(cur.get("stage"))
    try:
        deals.check_stage_ready(deals._row(cur), stage, skip_doc=key)
    except deals.DealError:
        raise DealDocError(
            "Угода стоїть на стадії «%s», а ця стадія без цього паперу не "
            "буває (%s). Спершу поверніть угоду на попередню стадію, потім "
            "відчіплюйте." % (stage, KIND_NAMES.get(_s(row.get("kind")), "документ")))
    del d["docs"][key]
    _save(d)
    _drop_file_if_orphan(d, row)
    _to_protocol(protocol.A_DEAL_DOC_REMOVED, dk, "відчеплено: " + said(row))
    return True


# ═══════════════════════════════════════════════════════════════════════════
# ⭐⭐⭐ 648 (26.09.2026). ДОКУМЕНТИ КЛІЄНТА В ЙОГО КАРТЦІ.
# ═══════════════════════════════════════════════════════════════════════════
def _drop_file_if_orphan(d: dict, row: dict) -> None:
    """Файл прибирається зі сховища ЛИШЕ коли ним більше не володіє жоден рядок.

    🩸 До 648 файл належав рівно одному документу, і відчеплення прибирало його
    завжди. Тепер статут клієнта й його копія в угоді — ОДИН файл: прибрати його
    з-під угоди означало б тихо вбити документ у картці клієнта (і навпаки).
    ⛒ Інший бік теж тримаємо: коли файл не належить нікому — сироти не лишаємо."""
    fid = _s(row.get("file_id"))
    if not fid:
        return
    if any(_s(v.get("file_id")) == fid for v in d["docs"].values()):
        return
    try:
        file_store.remove(fid)
    except Exception:
        pass


def _party_protocol(action: str, pid: str, what: str) -> None:
    try:
        protocol.write(action, entity.ref(entity.KIND_PARTY, _s(pid)), note=what)
    except Exception:
        pass


def check_party_kind(kind) -> str:
    k = _s(kind)
    if k == KIND_CONTRACT or k in (KIND_DRAFT, KIND_ANNEX, KIND_INVOICE, KIND_ACT):
        raise DealDocError(
            "«%s» — документ угоди, а не клієнта: договір, рахунок і акт живуть у "
            "картці угоди (без договору угода не закривається). Відкрийте угоду й "
            "причепіть його там." % KIND_NAMES.get(k, k))
    if k not in PARTY_KINDS:
        raise DealDocError("Невідомий тип документа клієнта «%s». Відомі: %s."
                           % (k, ", ".join("%s (%s)" % (KIND_NAMES[x], x)
                                           for x in PARTY_KINDS)))
    return k


@one_writer.guard("DEAL_DOCS_JSON")
def add_for_party(pid, kind, src=None, name: str = "", number: str = "",
                  date: str = "", by: str = "", file_id: str = "") -> dict:
    """Покласти документ САМОГО КЛІЄНТА в його картку (статут, витяг, довіреність).

    ⛒ Спершу все перевіряємо, потім пишемо; наш реєстр номерів не чіпаємо."""
    pk = _s(pid)
    if not pk or not parties.exists(pk):
        raise DealDocError("Контрагента %s немає в базі." % (pk or "«»"))
    k = check_party_kind(kind)
    ds = numbers.check_date(date) if _s(date) else ""
    try:
        num = numbers.foreign(number, required=False)   # 662: той самий писар чужого номера
    except numbers.NumberError as ex:
        raise DealDocError(str(ex))
    if _s(file_id):
        blob = file_store.info(_s(file_id))
        if not blob:
            raise DealDocError("Файла %s немає у сховищі — документ без файла "
                               "не кладеться." % _s(file_id))
    else:
        if src is None:
            raise DealDocError("Документ без файла не кладеться: статут — це "
                               "папір, а не запис про папір.")
        try:
            blob = file_store.put(src, name, by=by)
        except Exception as ex:
            raise DealDocError("Документ не збережено: %s" % ex)
    d = _load()
    doc_id = _new_id(d)
    row = {
        "id": doc_id,
        "deal": "",
        "party": pk,
        "kind": k,
        "number": num,
        "number_by": NUMBER_THEIRS,
        "date": ds,
        "amount": "",
        "file_id": _s(blob.get("id")),
        "file_name": _s(blob.get("name")) or _s(name),
        "by": _s(by),
        "created": clock.now(),
    }
    d["docs"][doc_id] = row
    _save(d)
    _party_protocol(protocol.A_PARTY_DOC_ADDED, pk, "покладено: " + said(row))
    return dict(row)


def _remove_party_doc(d: dict, key: str, row: dict, by: str = "") -> bool:
    del d["docs"][key]
    _save(d)
    _drop_file_if_orphan(d, row)
    _party_protocol(protocol.A_PARTY_DOC_REMOVED, _s(row.get("party")),
                    "прибрано: " + said(row))
    return True


def own_documents_of_party(pid) -> list:
    key = _s(pid)
    out = [dict(v) for v in _load()["docs"].values()
           if _s(v.get("party")) == key and not _s(v.get("deal"))]
    out.sort(key=lambda x: (_s(x.get("created")), _s(x.get("id"))))
    return out


def documents_of_party(pid) -> dict:
    """ЩО БАЧИТЬ КАРТКА КЛІЄНТА: власні документи + документи ВСІХ його угод.

    ⛒ Документи угод — ПОХІДНІ: читаються з угод цього клієнта тим самим
    читачем, що й картка угоди (разом із його правилом про гроші), а не
    копіюються сюди. Угоди — з того самого писаря, що дає їх картці клієнта."""
    key = _s(pid)
    rows = []
    try:
        dls = deals.deals_of_party(key, archived=None)
    except Exception:
        dls = []
    for dl in dls:
        did = _s(dl.get("id"))
        for doc in documents_of(did):
            doc = dict(doc)
            doc["deal_name"] = _s(dl.get("name"))
            rows.append(doc)
    return {"party": key, "own": own_documents_of_party(key), "deals": rows}


@one_writer.guard("DEAL_DOCS_JSON")
def take_into_deal(doc_id, did, by: str = "") -> dict:
    """ВЗЯТИ документ клієнта в угоду — тим самим файлом, без другої копії.

    ⛒ Лише в угоду ЦЬОГО Ж клієнта: статут однієї компанії в угоді іншої — це
    не зручність, а підміна учасника. Удруге в ту саму угоду — відмова."""
    key, dk = _s(doc_id), _s(did)
    d = _load()
    src = d["docs"].get(key)
    if not src or _s(src.get("deal")) or not _s(src.get("party")):
        raise DealDocError("Документа клієнта %s немає." % (key or "«»"))
    if not deals.exists(dk):
        raise DealDocError("Угоди %s немає." % (dk or "«»"))
    owner = _s(deals.client_of(dk))
    if owner != _s(src.get("party")):
        raise DealDocError(
            "Угода %s належить іншому клієнтові — документ «%s» туди не береться."
            % (dk, KIND_NAMES.get(_s(src.get("kind")), "документ")))
    if any(_s(v.get("deal")) == dk and _s(v.get("from_doc")) == key
           for v in d["docs"].values()):
        raise DealDocError("Цей документ уже взято в угоду %s." % dk)
    if not file_store.exists(_s(src.get("file_id"))):
        raise DealDocError("Файла документа немає у сховищі — брати нічого.")
    new_id = _new_id(d)
    row = {
        "id": new_id,
        "deal": dk,
        "kind": _s(src.get("kind")),
        "number": _s(src.get("number")),
        "number_by": number_by_of(src),
        "date": _s(src.get("date")),
        "amount": "",
        "file_id": _s(src.get("file_id")),
        "file_name": _s(src.get("file_name")),
        "from_doc": key,
        "by": _s(by),
        "created": clock.now(),
    }
    d["docs"][new_id] = row
    _save(d)
    _to_protocol(protocol.A_DEAL_DOC_TAKEN, dk, "взято з картки клієнта: " + said(row))
    return dict(row)
