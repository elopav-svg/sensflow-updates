# -*- coding: utf-8 -*-
"""judge_view.py — ЩО БАЧИТЬ СУДДЯ ЧИ КОРЕКТОР ДОКУМЕНТА. ОДИН ПИСАР (673).

⛒⛒⛒ 673, 01.10.2026. СУДДЯ, ЯКИЙ БАЧИТЬ УРИВОК, СУДИТЬ УРИВОК.
🩸 Живий прогін Каспера (~16:45, $1,84): приймальник ланцюга отримував перші 6 000
знаків юридичного висновку і двічі сказав «текст обірвався посередині таблиці, немає
ПДВ і чекліста». Не обривався: обрізали МИ, а розділи про ПДВ і чекліст стояли далі
(журнал звіряча тієї ж роботи звірив ст. 192 ПКУ і ст. 627, 651 ЦК). Ланцюг зупинився
на чужій ваді. Той самий клас — у коректора Excel: перші 6 000 знаків тексту, з якого
він мав брати параметри, і обрізаний JSON попередньої спеки.

⛒ ПРАВИЛО. Документ іде судді ЦІЛКОМ. Якщо він не влазить у межу — голова, ПОВНИЙ
перелік розділів і хвіст, а пропуск названо прямо, щоб суддя не сплутав наше
обрізання з обривом автора. Сама межа — тут і лише тут.
"""
import json
import re

# ≈ 20–25 тис. токенів: великий висновок чи книга влазять цілком, а випадковий
# мегабайт сміття не зʼїдає бюджет судді.
JUDGE_LIMIT = 90000

OMIT_MARK = "ПЛАТФОРМА ПРОПУСТИЛА СЕРЕДИНУ ДОКУМЕНТА"


# ⛒⛒ 675, 01.10.2026. СЛУЖБОВИЙ БЛОК КНИГИ СУДДЯ БАЧИТЬ ЯК КНИГУ, А НЕ ЯК JSON.
# 🩸 Живий прогін Каспера 19:03: суддя якості отримав увесь текст разом із JSON-спекою
# книги і написав «формули мають синтаксичні проблеми ({P1:Вхідні дані}) — дадуть #REF!
# або #NAME?». Плейсхолдери — це контракт платформи: адреси підставляє код, і формули
# книги вже пройшли детерміновані ворота (598–606). Суддя-модель судив те, чого не
# знає, — і разом із нулями бухгалтера (675) це дало вирок «роботи не зроблено».
# ⛒ Тепер замість блоку — позначка з назвами аркушів. Сам блок бачить лише той, чия
# це робота: коректор Excel отримує його ОКРЕМО, поза цим вікном.
_XLSX_FENCE_RE = re.compile(r"```xlsxmodel\s*\n?(.*?)```", re.S)
SERVICE_MARK = "СЛУЖБОВИЙ БЛОК EXCEL-КНИГИ"


def _labels(items, n=14) -> str:
    out = [str(x).strip()[:60] for x in items if str(x or "").strip()
           and not str(x).strip().startswith("=")]
    more = len(out) - n
    return "; ".join(out[:n]) + ((" … (ще %d)" % more) if more > 0 else "")


def _book_outline(raw: str) -> list:
    """Склад книги для судді — те, що людина побачить у файлі: аркуші, вхідні
    параметри, колонки, назви рядків. Формул і плейсхолдерів тут немає."""
    try:
        spec = json.loads(raw)
    except Exception:
        return []
    sheets = spec.get("sheets") if isinstance(spec, dict) else None
    sheets = sheets if isinstance(sheets, list) else [spec]
    out = []
    for s in sheets:
        if not isinstance(s, dict):
            continue
        nm = s.get("sheet") or s.get("name") or s.get("title") or "аркуш"
        parts = []
        prm = [p.get("name") for p in (s.get("params") or []) if isinstance(p, dict)]
        if prm:
            parts.append("вхідні: " + _labels(prm))
        if s.get("columns"):
            parts.append("колонки: " + _labels(s.get("columns")))
        rows = [r[0] for r in (s.get("rows") or []) if isinstance(r, list) and r]
        if rows:
            parts.append("рядки: " + _labels(rows))
        out.append("- аркуш «%s»%s" % (str(nm)[:31], (" — " + " | ".join(parts)) if parts else ""))
    return out


def service_view(text) -> str:
    """Текст, у якому службовий блок книги замінено складом книги без формул."""
    t = str(text or "")
    if "```xlsxmodel" not in t:
        return t

    def _one(m):
        outline = _book_outline((m.group(1) or "").strip())
        return ("[%s: у файлі стане Excel-книгою. Формули й адреси книги перевіряє код "
                "платформи; JSON-спеку тут не показано. Склад книги:\n%s\n]"
                % (SERVICE_MARK, "\n".join(outline) if outline else "- (склад не прочитано)"))
    return _XLSX_FENCE_RE.sub(_one, t)


def judge_view(text, limit: int = JUDGE_LIMIT) -> str:
    """Документ для судді: цілком, або голова + розділи + хвіст із названим пропуском."""
    text = service_view(text)          # 675: службовий блок книги — позначкою
    t = str(text or "")
    if len(t) <= limit:
        return t
    heads = [ln.strip() for ln in t.splitlines() if ln.lstrip().startswith("#")]
    toc = "\n".join(heads)[: max(0, limit // 10)]
    keep = max(1000, (limit - len(toc) - 600) // 2)
    note = ("\n\n[... %s: %d знаків пропущено, щоб документ уліз у перевірку. Це НЕ "
            "обрив тексту автором — документ повний. Усі розділи документа по порядку:\n"
            "%s\n...]\n\n" % (OMIT_MARK, len(t) - 2 * keep, toc))
    return t[:keep] + note + t[-keep:]
