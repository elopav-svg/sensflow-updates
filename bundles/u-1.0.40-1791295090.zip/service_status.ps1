﻿# ============================================================================
#  SensFlow — СТАН СЛУЖБИ (зміна 517, 05.09.2026).
#  Відповідає на три питання одним екраном: чи заведено автозапуск · чи жива
#  платформа зараз · що сказав останній запуск. Прав адміністратора не треба.
# ============================================================================
. (Join-Path (Split-Path -Parent $PSCommandPath) "service_common.ps1")

Sf-Head "SensFlow: стан служби"

$port = Sf-Port
$task = Sf-Task

# ⭐⭐⭐ 520: НЕ БРЕХАТИ ЧЕРЕЗ БРАК ПРАВ. Windows не показує завдання, що
# працює від SYSTEM, тому, хто не має прав адміністратора, — і екран стану
# сказав би «автозапуску немає», коли він насправді є. Тому «не знайшов» без
# прав — це не відповідь, а привід перепитати з правами.
if ((-not $task) -and (-not (Sf-IsAdmin))) {
    Sf-Line "Не бачу завдання без прав адміністратора — перепитую з ними..."
    Sf-Trace ("стан: без прав завдання не видно (" + $SfTaskWhy + ")")
    if (-not (Sf-NeedAdmin -ScriptPath $PSCommandPath)) { exit }
}

if (-not $task) {
    Sf-Trace ("стан: завдання НЕ знайдено (" + $SfTaskWhy + ")")
    Sf-Line "Автозапуск     : НЕ ЗАВЕДЕНО"
    Sf-Line "                 (платформа піднімається лише кнопкою вручну)"
} else {
    $info = $null
    try { $info = Get-ScheduledTaskInfo -TaskName $SfTask } catch {}
    Sf-Line "Автозапуск     : заведено"
    Sf-Line "Стан завдання  : $($task.State)"
    if ($info) {
        Sf-Line "Останній запуск: $($info.LastRunTime)"
        $code = $info.LastTaskResult
        $words = "код $code"
        if ($code -eq 0) { $words = "без помилок" }
        elseif ($code -eq 267009) { $words = "працює просто зараз" }
        Sf-Line "Чим скінчився  : $words"
        Sf-Line "Наступний старт: $($info.NextRunTime)"
    }
}

Sf-Line ""
if (Sf-Alive -Port $port -Seconds 1) {
    Sf-Line "Платформа      : ВІДПОВІДАЄ на http://127.0.0.1:$port"
} else {
    Sf-Line "Платформа      : МОВЧИТЬ на порту $port"
}

Sf-Line ""
if (Test-Path $SfLog) {
    $size = [math]::Round((Get-Item $SfLog).Length / 1KB, 1)
    Sf-Line "Журнал запуску : service.log, $size КБ. Останні рядки:"
    Sf-Line ("-" * 66)
    Get-Content $SfLog -Tail 25 -Encoding UTF8 | ForEach-Object { Write-Host "  $_" }
    Sf-Line ("-" * 66)
} else {
    Sf-Line "Журнал запуску : ще порожній (служба не запускалась)"
}

Sf-Line ""
Read-Host "Натисни Enter, щоб закрити"
