@echo off
rem ============================================================
rem  SensFlow: perezapusk platformy. Odna knopka na dva svity -
rem  sluzhba (bez vikna) i vikno konsoli. Yakym same shliakhom
rem  ity, vyrishuie service_restart.ps1: vin sam pytaie, yak
rem  platforma zhyve zaraz. ASCII only.
rem ============================================================
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0service_restart.ps1"
