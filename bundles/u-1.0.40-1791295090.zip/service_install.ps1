﻿# ============================================================================
#  SensFlow — ВСТАНОВИТИ АВТОЗАПУСК (зміна 517, 05.09.2026).
#
#  Що робить: заводить у Планувальнику завдань Windows завдання
#  «SensFlow Orchestrator», яке піднімає платформу ПРИ СТАРТІ МАШИНИ —
#  ще до того, як хтось увійшов у Windows, — і піднімає її знову, якщо вона
#  впала.
#
#  ⛒ ВІД ІМЕНІ SYSTEM І БЕЗ ЖОДНОГО ЗБЕРЕЖЕНОГО ПАРОЛЯ. Другий шлях
#  («запускати від імені користувача, навіть коли він не увійшов») змусив би
#  Windows зберегти пароль людини. Клієнт іде на державну експертизу саме на
#  відсутність недокументованих можливостей — збережений пароль там зайвий.
# ============================================================================
. (Join-Path (Split-Path -Parent $PSCommandPath) "service_common.ps1")

Sf-Head "SensFlow: встановлення автозапуску"

# ⭐ 697: лежимо не там — словами і нічого не робимо (ні прав, ні завдання).
if (-not (Sf-RequireEngine)) { exit 2 }

# ⭐⭐⭐ 523: СТАРИЙ АВТОЗАПУСК ПРИБИРАЄМО ДО ПОХОДУ ПО ПРАВА.
# Тека автозавантаження і гілка HKCU належать ТОМУ, ХТО ЗАПУСТИВ. Після
# підвищення прав Windows може дати нам ІНШИЙ профіль — і ми чистили б
# автозапуск не тієї людини. Тому «своє» беремо тут, а машинне — нижче,
# коли права вже є.
Sf-RemoveLegacyAutostart -Scope User | Out-Null

if (-not (Sf-NeedAdmin -ScriptPath $PSCommandPath)) { exit }

Sf-RemoveLegacyAutostart -Scope Machine | Out-Null

$port = Sf-Port
Sf-Line "Тека платформи : $SfRoot"
Sf-Line "Порт           : $port"
Sf-Line ""

# ── 1. ЗНАЙТИ PYTHON ────────────────────────────────────────────────────────
# Служба працює від імені SYSTEM, а в нього СВОЯ змінна PATH. Тому шлях до
# python шукаємо ЗАРАЗ і записуємо повністю: «python» без шляху в службі
# найчастіше просто не знаходиться, і платформа мовчки не піднімається.
Sf-Line "Шукаю Python..."
$cands = New-Object System.Collections.Generic.List[string]
foreach ($c in (Get-Command python.exe -All -ErrorAction SilentlyContinue)) {
    if ($c.Source) { $cands.Add($c.Source) }
}
foreach ($hive in @("HKLM:\SOFTWARE\Python\PythonCore",
                    "HKLM:\SOFTWARE\WOW6432Node\Python\PythonCore",
                    "HKCU:\SOFTWARE\Python\PythonCore")) {
    if (Test-Path $hive) {
        foreach ($k in (Get-ChildItem $hive -ErrorAction SilentlyContinue)) {
            $ip = Join-Path $k.PSPath "InstallPath"
            if (Test-Path $ip) {
                $pr = Get-ItemProperty $ip -ErrorAction SilentlyContinue
                $exe = $null
                if ($pr.ExecutablePath) { $exe = $pr.ExecutablePath }
                elseif ($pr.'(default)') { $exe = Join-Path $pr.'(default)' "python.exe" }
                if ($exe) { $cands.Add($exe) }
            }
        }
    }
}
try {
    & py -0p 2>$null | ForEach-Object {
        if ($_ -match "([A-Za-z]:\\[^\r\n]*python\.exe)") { $cands.Add($Matches[1]) }
    }
} catch {}

$py = $null
foreach ($c in $cands) {
    if (-not $c) { continue }
    # Заглушка з Microsoft Store виглядає як python.exe, а відкриває магазин.
    if ($c -like "*\WindowsApps\*") { continue }
    if (-not (Test-Path $c)) { continue }
    try {
        $v = (& $c -c "import sys;print(sys.version_info[0])" 2>$null | Out-String).Trim()
        if ($v -eq "3") { $py = $c; break }
    } catch {}
}
if (-not $py) {
    Sf-Line ""
    Sf-Line "НЕ ЗНАЙШОВ Python. Автозапуск не заведено — і це правильно:"
    Sf-Line "служба, яка не може запустити платформу, гірша за її відсутність."
    Sf-Line "Скажи мені про це, розберемось разом."
    Read-Host "Натисни Enter"
    exit 1
}
Sf-Line "Python         : $py"

# ── 2. ЩО ВМІЄ ЦЕЙ PYTHON ───────────────────────────────────────────────────
# Артефакти (docx, xlsx, pdf, pptx) живуть окремими бібліотеками. Якщо їх
# поставили «тільки для мене», SYSTEM їх НЕ ПОБАЧИТЬ — і платформа під службою
# втратить половину вміння, нічого про це не сказавши.
$probe = Join-Path $env:TEMP "sf_probe.py"
@'
import json, site, sys
out = {"user_site": ""}
try:
    out["user_site"] = site.getusersitepackages() or ""
except Exception:
    pass
mods = {}
for name, pkg in (("docx", "python-docx"), ("openpyxl", "openpyxl"),
                  ("pypdf", "pypdf"), ("pptx", "python-pptx"),
                  ("pypdfium2", "pypdfium2"), ("PIL", "Pillow")):
    try:
        mods[pkg] = getattr(__import__(name), "__file__", "") or ""
    except Exception:
        mods[pkg] = ""
out["mods"] = mods
print(json.dumps(out))
'@ | Set-Content -Path $probe -Encoding UTF8

$need = @()
try {
    $info = (& $py -X utf8 $probe 2>$null | Out-String).Trim() | ConvertFrom-Json
    $us = "" + $info.user_site
    foreach ($pkg in @("python-docx", "openpyxl", "pypdf", "python-pptx", "pypdfium2", "Pillow")) {
        $where = "" + $info.mods.$pkg
        if (-not $where) { $need += $pkg }
        elseif ($us -and $where.StartsWith($us)) { $need += $pkg }
    }
} catch {
    $need = @("python-docx", "openpyxl", "pypdf", "python-pptx", "pypdfium2", "Pillow")
}
Remove-Item $probe -ErrorAction SilentlyContinue

if ($need.Count -gt 0) {
    Sf-Line "Доставляю для служби: $($need -join ', ')"
    try { & $py -m pip install --quiet $need 2>&1 | Out-Null } catch {}
    Sf-Line "Готово."
} else {
    Sf-Line "Бібліотеки артефактів : на місці для всіх"
}

# ── 3. ЗАПАМʼЯТАТИ ШЛЯХ ДЛЯ ЗАПУСКАЧА ───────────────────────────────────────
# Кодування OEM: цей файл читає командний рядок Windows, а не PowerShell.
$pyCmd = Join-Path $SfRoot "_service_python.cmd"
"set ""SF_PY=$py""" | Out-File -FilePath $pyCmd -Encoding oem -Force

# ── 4. ЗАВЕСТИ ЗАВДАННЯ ─────────────────────────────────────────────────────
Sf-Line ""
Sf-Line "Заводжу завдання «$SfTask»..."
$action  = New-ScheduledTaskAction -Execute $SfRunner -WorkingDirectory $SfRoot
# ⭐⭐⭐ 523: ДВА ТРИГЕРИ, А НЕ ОДИН. «Швидкий запуск» Windows увімкнений
# за замовчуванням, а з ним вимкнення машини — це сон ядра, а не
# вимкнення. Тому тригер «при старті машини» при звичайному
# вимкненні/увімкненні НЕ спрацьовує. Другий тригер — «при вході в
# систему». Двох копій це не породить: нижче стоїть
# -MultipleInstances IgnoreNew, тож поки платформа працює, Windows
# новий запуск просто ігнорує.
$trigStart = New-ScheduledTaskTrigger -AtStartup
$trigStart.Delay = "PT1M"        # хвилина на те, щоб мережа й диски піднялись
$trigLogon = New-ScheduledTaskTrigger -AtLogOn
$trigLogon.Delay = "PT30S"
$trigger = @($trigStart, $trigLogon)
$principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" `
             -LogonType ServiceAccount -RunLevel Highest
$settings = New-ScheduledTaskSettingsSet `
            -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
            -StartWhenAvailable `
            -RestartInterval (New-TimeSpan -Minutes 1) -RestartCount 99 `
            -ExecutionTimeLimit ([TimeSpan]::Zero) `
            -MultipleInstances IgnoreNew
Register-ScheduledTask -TaskName $SfTask -Action $action -Trigger $trigger `
    -Principal $principal -Settings $settings -Force `
    -Description "SensFlow: platforma pidnimaietsia pry starti mashyny" | Out-Null
Sf-Line "Завдання заведено."

# ── 5. ЗВІЛЬНИТИ ПОРТ І ПЕРЕДАТИ РОБОТУ СЛУЖБІ ──────────────────────────────
# Якщо консоль уже працює, служба не візьме порт — і людина вирішить, що
# автозапуск не працює. Тому закриваємо вікно так само, як це робить кнопка
# «Перезапустити сервер».
Sf-Line ""
Sf-Line "Звільняю порт $port (закриваю вікно консолі, якщо воно відкрите)..."
& taskkill /f /t /fi "WINDOWTITLE eq SensFlow Orchestrator" 2>$null | Out-Null
try {
    Get-NetTCPConnection -LocalPort ([int]$port) -State Listen -ErrorAction Stop |
        ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
} catch {
    & netstat -ano | Select-String ":$port\s" | Select-String "LISTENING" | ForEach-Object {
        $pid2 = ($_ -split "\s+")[-1]
        if ($pid2 -match "^\d+$") { & taskkill /f /pid $pid2 2>$null | Out-Null }
    }
}
Start-Sleep -Seconds 3

Sf-Line "Запускаю службу..."
Start-ScheduledTask -TaskName $SfTask
if (Sf-Alive -Port $port -Seconds 60) {
    Sf-Head "ГОТОВО. Платформа працює службою"
    Sf-Line "Адреса         : http://127.0.0.1:$port"
    Sf-Line "Вікна більше немає — платформа працює у фоні."
    Sf-Line "Журнал запуску : service.log (поруч із цим файлом)"
    Sf-Line ""
    Sf-Line "Тепер вона піднімається САМА при вмиканні машини, ще до входу"
    Sf-Line "в Windows, і піднімається знову, якщо впаде."
    Sf-Line ""
    Sf-Line "Перевірити стан  — «Служба - стан.bat»"
    Sf-Line "Прибрати назад   — «Служба - зняти автозапуск.bat»"
} else {
    Sf-Head "ЗАВДАННЯ ЗАВЕДЕНО, АЛЕ ПЛАТФОРМА НЕ ВІДПОВІЛА"
    Sf-Line "Не вгадуватиму причину — вона в журналі:"
    Sf-Line "  $SfLog"
    Sf-Line "Покажи мені цей файл, розберемось."
}
Sf-Line ""
Read-Host "Натисни Enter, щоб закрити"
