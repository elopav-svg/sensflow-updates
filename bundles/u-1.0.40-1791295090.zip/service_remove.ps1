﻿# ============================================================================
#  SensFlow — ЗНЯТИ АВТОЗАПУСК (зміна 517, 05.09.2026).
#  Прибирає завдання з Планувальника й зупиняє платформу, яку воно тримало.
#  Після цього платформа піднімається лише кнопкою «Start AI Orchestrator».
# ============================================================================
. (Join-Path (Split-Path -Parent $PSCommandPath) "service_common.ps1")

Sf-Head "SensFlow: зняти автозапуск"

if (-not (Sf-NeedAdmin -ScriptPath $PSCommandPath)) { exit }

$port = Sf-Port
$task = Sf-Task
if (-not $task) {
    Sf-Line "Автозапуск і не був заведений — прибирати нічого."
    Sf-Line ""
    Read-Host "Натисни Enter, щоб закрити"
    exit
}

try { Stop-ScheduledTask -TaskName $SfTask -ErrorAction SilentlyContinue } catch {}
Unregister-ScheduledTask -TaskName $SfTask -Confirm:$false
Sf-Line "Завдання прибрано з Планувальника."

# Платформа, яку тримала служба, лишається в памʼяті — зупиняємо і її, інакше
# порт буде зайнятий, а вікна, щоб закрити, немає.
try {
    Get-NetTCPConnection -LocalPort ([int]$port) -State Listen -ErrorAction Stop |
        ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
    Sf-Line "Платформу зупинено, порт $port вільний."
} catch {
    Sf-Line "На порту $port нічого не слухало."
}

Sf-Line ""
Sf-Line "Тепер платформа піднімається лише кнопкою «Start AI Orchestrator»."
Sf-Line "Повернути автозапуск — «Служба - встановити автозапуск.bat»."
Sf-Line ""
Read-Host "Натисни Enter, щоб закрити"
