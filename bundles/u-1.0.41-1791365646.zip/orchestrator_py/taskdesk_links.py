# -*- coding: utf-8 -*-
"""ЗВʼЯЗКИ ЗАДАЧ — ПИСАР ФОРМУЛЮВАНЬ ДЛЯ ЕКРАНА (зміна 172 → крок B2, 14.08.2026).

⭐ ЩО ЗМІНИЛОСЬ У B2. Цей файл народився в зміні 172 і тримав ДВІ речі одразу:
ПРАВИЛА звʼязку (словник видів, «лише між задачами», «один батько», кільце) і
СЛОВА, якими звʼязок читається людині. У B2 факт звʼязку переїхав із поля задачі
у власний реєстр (`links.py`) — і правила поїхали ТУДИ, до факту, бо це правила
ЗВʼЯЗКУ, а не задачі: угода ↔ контакт судиться тими самими воротами, а про
`taskdesk_*` вона нічого не знає.

⛒ ТУТ ЛИШИЛОСЬ РІВНО ОДНЕ: **як звʼязок називається людині** — на картці, у
стрічці й у телеграмі. Один писар формулювань: інакше екран і чат назвали б те
саме різними реченнями. Прецедент той самий, що з `agent._refusal_log` →
`audit.log_refusal`: правило — до власника правди, слова — до того, хто говорить.

⚠ СЛОВНИК ВИДІВ НЕ ДУБЛЮЄТЬСЯ, А ПЕРЕПОЗИЧАЄТЬСЯ з `links.py`. Другий список
видів розійшовся б із першим за тиждень — рівно та біда, від якої нас лікували
зміни 167 і 172.
"""

import entity
import links

# ── ПЕРЕПОЗИЧЕНЕ З РЕЄСТРУ (не копія — те саме) ──────────────────────────────
LinkError = links.LinkError

REL_SUBTASK_OF = links.REL_SUBTASK_OF
REL_BLOCKS = links.REL_BLOCKS
REL_ABOUT = links.REL_ABOUT
REL_WORKS_AT = links.REL_WORKS_AT
RELS = links.RELS
REL_NAMES = links.REL_NAMES
TASK_ONLY = links.TASK_ONLY
PARTY_ONLY = links.PARTY_ONLY
ONE_PARENT = links.ONE_PARENT
TASK_NUM = links.TASK_NUM

check_rel = links.check_rel
check_ref = links.check_ref
has = links.has
refs_of = links.refs_of


def incoming(self_ref: str, tasks=None) -> list:
    """Хто вказує НА цю сутність.

    ⭐⭐⭐ РАНІШЕ ЦЕ БУВ ПЕРЕБІР УСІХ ЗАДАЧ (другий параметр — саме їх перелік).
    Тепер це ОДИН запит до реєстру. Параметр `tasks` лишений і СВІДОМО
    ігнорується: старий викликач не мусить ламатись, але й другого джерела
    правди більше не існує."""
    return links.incoming(self_ref)


# ── СЛОВА, ЯКИМИ ЗВʼЯЗОК ЧИТАЄТЬСЯ ЛЮДИНІ ────────────────────────────────────
# Як звʼязок читається З БОКУ ЦІЄЇ задачі і з боку ТІЄЇ. Два різні речення на
# одну стрічку: інакше зворотний бік довелось би вигадувати на екрані.
REL_BACK_NAMES = {
    REL_SUBTASK_OF: "містить підзадачу",
    REL_BLOCKS: "чекає на",
    # 🩸 БУЛО «згадана в задачі» — і слово «задача» стояло в самій назві
    # звʼязку. На картці контакту це ще читалось, але щойно зʼявиться угода,
    # вийшло б «згадана в задачі: угода «…»» — пряма неправда на екрані. Вид
    # сутності підставляє `phrase`, а не назва звʼязку (крок B3, 14.08.2026).
    REL_ABOUT: "згадується в",
    # Крок B5: з боку людини — «працює в», з боку компанії — «тут працює».
    REL_WORKS_AT: "тут працює",
}


def _s(v) -> str:
    return "" if v is None else str(v).strip()


def phrase(rel, ref, back: bool = False, limit: int = 60) -> str:
    """ЗВʼЯЗОК СЛОВАМИ — ОДИН ПИСАР ФОРМУЛЮВАННЯ на картку, стрічку, телеграм і
    протокол. Інакше те саме назвали б чотирма різними реченнями.

    ⚠ Двокрапка замість узгодження відмінків навмисно: «стосується контрагента»
    і «стосується прогону» вимагали б граматики на кожен вид сутності, а
    граматика в коді — це та сама зашита форма, що ламається на новому виді.
    Задача — свій рід сутності на екрані задач, тому її вид не називаємо."""
    r = _s(rel)
    names = REL_BACK_NAMES if back else REL_NAMES
    value = _s(ref)
    title = _s(entity.title(value)) if entity.is_ref(value) else ""
    if len(title) > limit:
        title = title[:limit - 1] + "…"
    kind = entity.kind_of(value) if entity.is_ref(value) else ""
    what = "" if kind == entity.KIND_TASK else entity.KIND_NAMES.get(kind, "")
    tail = "«%s» (%s)" % (title, entity.ident_of(value)) if title else value
    return "%s: %s%s" % (names.get(r, r), (what + " ") if what else "", tail)


def decorate(links_list, back: bool = False, seen_tasks=None) -> list:
    """Звʼязок словами для екрана й для телеграма. ОДИН писар формулювань:
    інакше картка й чат назвали б те саме різними словами.

    ⭐⭐⭐ КРОК B4 (14.08.2026): ТУТ ЖЕ ЛЕЖИТЬ І АДРЕСА ПЕРЕХОДУ. Досі картка
    задачі складала її сама (`'/task?id=' + номер`) — і саме тому вміла вести
    лише на задачу: контрагент у тому самому переліку лишався мертвим текстом.
    Адресу знає `entity.screen`, а тут вона просто приїжджає до екрана разом зі
    словами. Новий шар (угода, заявка) стане клікабельним у КОЖНОМУ переліку
    звʼязків одразу, без правки жодного екрана.
    ⛒ І ТУТ ЖЕ — ПРАВДА ПРО ЖИТТЯ СУТНОСТІ: посилання на видалену картку не
    дається НІДЕ, а не лише в картці контакту. Правило, яке живе в одному
    шляху, — наш найдорожчий клас помилок.
    ⛒ 708: І ПРАВДА ПРО ВИДИМІСТЬ. `seen_tasks` — номери задач, які глядач бачить
    (`visible_ids`); задачу поза ними називаємо лише номером, без назви й без
    переходу. Доти звʼязок розкривав назву чужої задачі тому, кому її не видно, — а з
    етапами (кожен — підзадача головної) це стало б щоденним."""
    out = []
    for l in (links_list or []):
        rel = _s(l.get("rel"))
        names = REL_BACK_NAMES if back else REL_NAMES
        ref = _s(l.get("ref"))
        alive = bool(entity.exists(ref)) if ref else False
        if (seen_tasks is not None and entity.is_ref(ref)
                and entity.kind_of(ref) == entity.KIND_TASK
                and entity.ident_of(ref) not in seen_tasks):
            out.append({"ref": ref, "alive": alive, "href": "", "rel": rel,
                        "rel_name": names.get(rel, rel), "title": "", "hidden": True,
                        "human": entity.ident_of(ref), "kind": entity.KIND_TASK,
                        "phrase": "%s: %s (задача вам не видна)" % (names.get(rel, rel),
                                                                   entity.ident_of(ref)),
                        "note": _s(l.get("note")),
                        "closed": bool(entity.closed(ref)) if alive else False,
                        "at": _s(l.get("at")), "by": _s(l.get("by"))})
            continue
        out.append({
            "ref": ref,
            "alive": alive,
            "href": entity.screen(ref) if alive else "",
            "rel": rel,
            "rel_name": names.get(rel, rel),
            "title": entity.title(l.get("ref")),
            "human": entity.human(l.get("ref")),
            "kind": entity.kind_of(l.get("ref")) if entity.is_ref(l.get("ref")) else "",
            "phrase": phrase(l.get("rel"), l.get("ref"), back=back),
            # ⭐ Крок B5: підпис звʼязку (посада) їде до екрана разом зі словами.
            # Він живе на ЗВʼЯЗКУ, тому й показувати його має той, хто показує
            # звʼязок, а не картка людини.
            "note": _s(l.get("note")),
            # ⭐⭐⭐ ЗМІНА 242: ЧИ ТА РІЧ УЖЕ ЗАКІНЧЕНА. Без цього рядка екран
            # умів сказати лише «її тримає інша робота» — і не знав, чи та
            # робота ще жива. Правду про закінчення знає `entity`, а показує
            # той, хто показує звʼязок: інакше кожен екран рахував би її сам.
            "closed": bool(entity.closed(ref)) if alive else False,
            "at": _s(l.get("at")),
            "by": _s(l.get("by")),
        })
    return out
