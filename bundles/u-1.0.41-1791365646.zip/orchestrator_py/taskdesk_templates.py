# -*- coding: utf-8 -*-
"""taskdesk_templates.py — ШАБЛОНИ ПОЯСНЕНЬ І ЗАПИТІВ (зміна 707, 06.10.2026).

Проєкт розробки Task Desk для ОТУ, частина 4, п. 3.7 (і 4.5 — перші шаблони).

⭐⭐⭐ КОРІНЬ. Один напише «не встиг», інший — сторінку тексту. Такі пояснення не
порівняти й не порахувати: керівник бачить слова, а не причини. Шаблон — назва і
перелік полів; причину ВИБИРАЮТЬ зі списку, а «Інше» пишуть своїми словами. Тоді
причини рахуються, а «Інше», якого забагато, каже, що шаблон треба доповнити.

⛒ ОДИН ПИСАР І ОДИН СУДДЯ. Довідник, перевірку відповідей і текст, у який вони
складаються, тримає цей файл. Екран, бот і задача питають його, а не перевіряють
поля самі: другий суддя розійшовся б із першим на першому ж новому виді поля.

⛒ ДВА ПРИЗНАЧЕННЯ. Шаблон для коментаря («Додати за шаблоном» на картці) і шаблон
пояснення провалу перевірки (706: «Пояснити й повернути в роботу» — лише за ним).
Останній шаблон пояснення провалу з вибору не прибирається: інакше провал нема чим
пояснити, і задача застрягла б у «Не пройшла перевірку».

⚠ ПЕРШІ ШАБЛОНИ — НАШІ, З ПРИКЛАДІВ ПОГОДЖЕНОГО ДОКУМЕНТА (4.5), поки клієнт не назвав
свої; кладуться рівно раз, коли довідника ще немає. Далі їх правлять, прибирають і
доповнюють самі. (Для типів роботи заготовок немає — рішення 26.08.2026; тут без
одного шаблону пояснення провалу обовʼязкове пояснення було б неможливим.)

⛒ ВИДАЛЕННЯ НЕМАЄ: шаблон прибирають з вибору — на нього вже посилаються коментарі.
"""

import re
import uuid

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import one_writer

DESK_DIR = config.STATE_DIR / "taskdesk"

# ⛒ ДРУГИЙ ЗАМОК: чек, завантажений не через файл, не сміє працювати по бойовому стану.
config.refuse_live_state_for_checks(__name__)
TEMPLATES_JSON = DESK_DIR / "templates.json"

PURPOSE_ANY = "any"        # коментар у задачі
PURPOSE_FAIL = "fail"      # пояснення до «Не пройшла перевірку»
PURPOSE_EARLY = "early"    # ⭐ 708: чому етап почато раніше попереднього (4.4 Б)
PURPOSE_NAMES = {PURPOSE_ANY: "Коментар у задачі",
                 PURPOSE_FAIL: "Пояснення провалу перевірки",
                 PURPOSE_EARLY: "Пояснення раннього початку етапу"}
# ⛒ Призначення, без шаблону яких дія неможлива: останній чинний шаблон такого призначення
# з вибору не прибирається і на інше не переробляється. Слова — чого без нього не зробити.
REQUIRED = {PURPOSE_FAIL: "провал нема чим пояснити",
            PURPOSE_EARLY: "етап раніше попереднього не почати"}

KIND_CHOICE = "choice"
KIND_TEXT = "text"
KIND_DATE = "date"
KIND_NAMES = {KIND_CHOICE: "вибір зі списку", KIND_TEXT: "текст", KIND_DATE: "дата"}

OTHER = "Інше"             # є в кожному виборі, завжди останнім
OTHER_SUFFIX = "__other"   # ключ відповіді «своїми словами» для поля вибору

MAX_FIELDS = 6
MAX_OPTIONS = 15
MAX_LABEL = 80
MAX_NAME = 120
MAX_ANSWER = 1000
AUDIT_KEEP = 200

_REASONS = ["Немає матеріалів", "Чекаю іншу задачу", "Змінились вимоги", "Захворів"]
# 4.5: «Причина зриву строку» (немає матеріалів; чекаю іншу задачу; змінились вимоги;
# захворів; інше), «Прохання продовжити строк», «Прохання уточнити задачу».
STARTERS = [
    {"name": "Причина зриву строку", "purpose": PURPOSE_ANY, "fields": [
        {"label": "Причина", "kind": KIND_CHOICE, "options": list(_REASONS), "required": True},
        {"label": "Подробиці", "kind": KIND_TEXT, "required": False}]},
    {"name": "Прохання продовжити строк", "purpose": PURPOSE_ANY, "fields": [
        {"label": "Новий строк", "kind": KIND_DATE, "required": True},
        {"label": "Причина", "kind": KIND_CHOICE, "options": list(_REASONS), "required": True},
        {"label": "Подробиці", "kind": KIND_TEXT, "required": False}]},
    {"name": "Прохання уточнити задачу", "purpose": PURPOSE_ANY, "fields": [
        {"label": "Що незрозуміло", "kind": KIND_TEXT, "required": True}]},
    {"name": "Пояснення до провалу перевірки", "purpose": PURPOSE_FAIL, "fields": [
        {"label": "Причина", "kind": KIND_CHOICE, "required": True,
         "options": ["Не зрозумів вимоги", "Бракувало матеріалів чи даних",
                     "Помилка у виконанні", "Змінились вимоги", "Не встиг перевірити сам"]},
        {"label": "Що робите далі", "kind": KIND_TEXT, "required": True}]},
    # ⭐ 708 (3.5, 4.4 Б): наступний етап раніше — лише з поясненням за шаблоном.
    {"name": "Чому етап почато раніше", "purpose": PURPOSE_EARLY, "fields": [
        {"label": "Причина", "kind": KIND_CHOICE, "required": True,
         "options": ["Терміново потрібно замовнику", "Частини роботи незалежні",
                     "Попередній етап майже завершено", "Рішення керівника"]},
        {"label": "Подробиці", "kind": KIND_TEXT, "required": False}]},
]


class TemplateError(Exception):
    """Відмова, названа людськими словами. Тиші тут не буває."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _new_id(prefix: str) -> str:
    return "%s-%s" % (prefix, uuid.uuid4().hex[:8])


# ---------------------------------------------------------------------------
# ПОЛЯ
# ---------------------------------------------------------------------------
def _options(raw) -> list:
    out = []
    for o in raw or []:
        o = _s(o)[:MAX_LABEL]
        if o and o.casefold() != OTHER.casefold() and o not in out:
            out.append(o)
    return out[:MAX_OPTIONS] + [OTHER]


def _norm_field(raw, i: int) -> dict:
    raw = raw if isinstance(raw, dict) else {}
    kind = _s(raw.get("kind")) or KIND_TEXT
    f = {"id": _s(raw.get("id")) or ("f%d" % (i + 1)), "label": _s(raw.get("label"))[:MAX_LABEL],
         "kind": kind if kind in KIND_NAMES else KIND_TEXT,
         "required": bool(raw.get("required"))}
    if f["kind"] == KIND_CHOICE:
        f["options"] = _options(raw.get("options"))
    return f


def _check_fields(raw) -> list:
    """Поля від людини — або відмова з назвою того, що не так."""
    if not isinstance(raw, list) or not raw:
        raise TemplateError("У шаблоні має бути хоча б одне поле.")
    if len(raw) > MAX_FIELDS:
        raise TemplateError("Полів не більше %d: довгий шаблон перестають заповнювати." % MAX_FIELDS)
    out, used = [], set()
    for i, r in enumerate(raw):
        f = _norm_field(r, i)
        if not f["label"]:
            raise TemplateError("Поле %d без назви: напишіть, що в ньому питають." % (i + 1))
        if f["kind"] == KIND_CHOICE and len(f["options"]) < 2:
            raise TemplateError("У полі «%s» немає жодного варіанта: напишіть хоча б один, "
                                "«Інше» додається само." % f["label"])
        while f["id"] in used:
            f["id"] = "f%d" % (len(used) + i + 2)
        used.add(f["id"])
        out.append(f)
    return out


# ---------------------------------------------------------------------------
# ДОВІДНИК НА ДИСКУ
# ---------------------------------------------------------------------------
def _norm_tpl(raw) -> dict:
    raw = raw if isinstance(raw, dict) else {}
    purpose = _s(raw.get("purpose"))
    return {"id": _s(raw.get("id")), "name": _s(raw.get("name"))[:MAX_NAME],
            "purpose": purpose if purpose in PURPOSE_NAMES else PURPOSE_ANY,
            "fields": [_norm_field(f, i) for i, f in enumerate(raw.get("fields") or [])],
            "active": raw.get("active") is not False,
            "created_at": _s(raw.get("created_at"))}


def _starter(s: dict, now: str) -> dict:
    return dict(_norm_tpl({"id": _new_id("tp"), "name": s["name"], "purpose": s["purpose"],
                           "fields": _check_fields(s["fields"])}), created_at=now)


def _seed() -> dict:
    now = clock.now()
    return {"templates": [_starter(s, now) for s in STARTERS],
            "seeded": list(PURPOSE_NAMES),
            "audit": [{"at": now, "what": "перші шаблони з прикладів погодженого документа (4.5)"}]}


def _seed_new_purposes(raw: dict) -> bool:
    """⭐ 708. НОВЕ ПРИЗНАЧЕННЯ ДОХОДИТЬ І В НАЯВНИЙ ДОВІДНИК — РІВНО РАЗ. Довідник, засіяний
    до появи призначення, без цього лишився б без шаблону, а дія, якій шаблон обовʼязковий,
    — неможливою. `seeded` — які призначення вже засіяно; файл без нього (707) засіяв ті, що
    тоді були. Шаблон, який людина потім прибрала, назад не повертається. True — є що записати."""
    tpls = [x for x in (raw.get("templates") or []) if isinstance(x, dict)]
    seeded = raw.get("seeded")
    if not isinstance(seeded, list):
        seeded = [PURPOSE_ANY, PURPOSE_FAIL]          # усе, що засівав 707
    todo = [p for p in PURPOSE_NAMES if p not in seeded]
    if not todo and isinstance(raw.get("seeded"), list):
        return False
    now = clock.now()
    for p in todo:
        add = [_starter(s, now) for s in STARTERS if s["purpose"] == p]
        if add:
            tpls.extend(add)
            raw["audit"] = list(raw.get("audit") or []) + [
                {"at": now, "what": "додано шаблон «%s» для нового призначення «%s»"
                                    % (add[0]["name"], PURPOSE_NAMES[p])}]
        seeded = list(seeded) + [p]
    raw["templates"], raw["seeded"] = tpls, list(seeded)
    return True


def load() -> dict:
    """Довідник. Немає файла — кладемо перші шаблони РІВНО РАЗ (на диск, а не в памʼять:
    інакше кожне читання народжувало б нові номери). Побитий файл не затирається:
    причина їде словами, і в нього нічого не пишеться."""
    if not TEMPLATES_JSON.exists():
        st = _seed()
        DESK_DIR.mkdir(parents=True, exist_ok=True)
        one_writer.write_json(TEMPLATES_JSON, st)
    try:
        raw = one_writer.read_json(TEMPLATES_JSON)
    except PermissionError:
        raise                       # ⛒ зайнятий файл — не порожній
    except Exception as e:
        return {"templates": [], "audit": [], "seeded": [], "unreadable_reason": str(e)}
    raw = raw if isinstance(raw, dict) else {}
    if _seed_new_purposes(raw):
        one_writer.write_json(TEMPLATES_JSON, raw)
    return {"templates": [t for t in (_norm_tpl(x) for x in raw.get("templates") or []) if t["id"]],
            "seeded": list(raw.get("seeded") or []),
            "audit": [a for a in (raw.get("audit") or []) if isinstance(a, dict)][-AUDIT_KEEP:]}


def _save(st: dict, what: str) -> dict:
    if st.get("unreadable_reason"):
        raise TemplateError("Довідник шаблонів на диску не читається (%s): поки так, "
                            "платформа в нього не пише." % st["unreadable_reason"])
    st = {"templates": st["templates"], "seeded": list(st.get("seeded") or []),
          "audit": (st.get("audit") or [])[-AUDIT_KEEP:]}
    st["audit"].append({"at": clock.now(), "what": what[:300]})
    one_writer.write_json(TEMPLATES_JSON, st)
    return st


def templates(include_hidden: bool = False, purpose: str = None) -> list:
    return [t for t in load()["templates"]
            if (include_hidden or t["active"]) and (purpose is None or t["purpose"] == purpose)]


def template(tid: str) -> dict:
    for t in load()["templates"]:
        if t["id"] == _s(tid):
            return t
    return {}


def _find(st: dict, tid: str) -> dict:
    for t in st["templates"]:
        if t["id"] == _s(tid):
            return t
    raise TemplateError("Такого шаблону немає.")


def _check_name(st: dict, name: str, skip: str = "") -> str:
    name = _s(name)[:MAX_NAME]
    if not name:
        raise TemplateError("Напишіть назву шаблону, наприклад «Причина зриву строку».")
    for t in st["templates"]:
        if t["id"] != skip and t["name"].casefold() == name.casefold():
            raise TemplateError("Шаблон «%s» уже є — оберіть іншу назву." % name)
    return name


def _check_purpose(p) -> str:
    p = _s(p) or PURPOSE_ANY
    if p not in PURPOSE_NAMES:
        raise TemplateError("Невідоме призначення шаблону «%s»." % p)
    return p


def _last_fail_guard(st: dict, t: dict, active: bool, purpose: str) -> None:
    """Останній чинний шаблон обовʼязкового призначення (`REQUIRED`: пояснення провалу; 708 —
    ранній початок етапу) не зникає з вибору й не переробляється на інше."""
    own = t["purpose"]
    if own not in REQUIRED or not t["active"]:
        return
    if active and purpose == own:
        return
    others = [x for x in st["templates"] if x["id"] != t["id"]
              and x["active"] and x["purpose"] == own]
    if not others:
        raise TemplateError("Це останній шаблон «%s»: без нього %s. Спершу заведіть інший "
                            "такий шаблон." % (PURPOSE_NAMES[own].lower(), REQUIRED[own]))


def add(name: str, purpose: str = PURPOSE_ANY, fields=None) -> dict:
    st = load()
    t = _norm_tpl({"id": _new_id("tp"), "name": _check_name(st, name),
                   "purpose": _check_purpose(purpose), "fields": _check_fields(fields)})
    t["created_at"] = clock.now()
    st["templates"].append(t)
    _save(st, "заведено шаблон «%s»" % t["name"])
    return t


def update(tid: str, name=None, purpose=None, fields=None) -> dict:
    st = load()
    t = _find(st, tid)
    new_purpose = _check_purpose(purpose) if purpose is not None else t["purpose"]
    _last_fail_guard(st, t, True, new_purpose)
    if name is not None:
        t["name"] = _check_name(st, name, skip=t["id"])
    if fields is not None:
        t["fields"] = _check_fields(fields)
    t["purpose"] = new_purpose
    _save(st, "змінено шаблон «%s»" % t["name"])
    return t


def set_active(tid: str, on: bool) -> dict:
    st = load()
    t = _find(st, tid)
    _last_fail_guard(st, t, bool(on), t["purpose"])
    t["active"] = bool(on)
    _save(st, "шаблон «%s» %s" % (t["name"], "повернуто у вибір" if on else "прибрано з вибору"))
    return t


# ---------------------------------------------------------------------------
# ЗАПОВНЕННЯ: відповіді → впорядкований запис і текст
# ---------------------------------------------------------------------------
_DATE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})$")
_HUMAN_DATE = re.compile(r"^(\d{1,2})\.(\d{1,2})\.(\d{4})$")


def _date(v: str) -> str:
    v = _s(v)
    m = _HUMAN_DATE.match(v)
    if m:
        v = "%s-%02d-%02d" % (m.group(3), int(m.group(2)), int(m.group(1)))
    if not _DATE.match(v):
        return ""
    try:
        from datetime import date
        date(int(v[:4]), int(v[5:7]), int(v[8:10]))
    except ValueError:
        return ""
    return v


def fill(template_id: str, answers, purpose: str = PURPOSE_ANY) -> dict:
    """Відповіді людини → {"record": впорядковані відповіді, "text": як їх прочитає людина}.
    Будь-яка вада — відмова з назвою поля. Шаблон мусить бути чинним і саме цього
    призначення: пояснення провалу в коментар не йде, і навпаки."""
    t = template(template_id)
    if not t:
        raise TemplateError("Такого шаблону немає.")
    if not t["active"]:
        raise TemplateError("Шаблон «%s» прибрано з вибору." % t["name"])
    if t["purpose"] != purpose:
        raise TemplateError("Шаблон «%s» — для іншого: %s." % (t["name"],
                                                             PURPOSE_NAMES[t["purpose"]].lower()))
    answers = answers if isinstance(answers, dict) else {}
    rec, lines = [], ["«%s»" % t["name"]]
    for f in t["fields"]:
        v = _s(answers.get(f["id"]))[:MAX_ANSWER]
        other, shown = False, v
        if f["kind"] == KIND_CHOICE and v:
            if v not in f["options"]:
                raise TemplateError("У полі «%s» такого варіанта немає: «%s»." % (f["label"], v))
            if v == OTHER:
                words = _s(answers.get(f["id"] + OTHER_SUFFIX))[:MAX_ANSWER]
                if not words:
                    raise TemplateError("У полі «%s» обрано «Інше» — напишіть своїми словами."
                                        % f["label"])
                other, shown = True, "%s: %s" % (OTHER, words)
                v = words
        elif f["kind"] == KIND_DATE and v:
            d = _date(v)
            if not d:
                raise TemplateError("У полі «%s» не дата: «%s». Напишіть ДД.ММ.РРРР." % (f["label"], v))
            v, shown = d, "%s.%s.%s" % (d[8:10], d[5:7], d[:4])
        if not v:
            if f["required"]:
                raise TemplateError("Заповніть поле «%s»." % f["label"])
            continue
        rec.append({"field": f["id"], "label": f["label"], "kind": f["kind"],
                    "value": OTHER if other else v, "other": other,
                    "text": v if other else ""})
        lines.append("%s: %s" % (f["label"], shown))
    return {"record": {"id": t["id"], "name": t["name"], "answers": rec},
            "text": "\n".join(lines)}


def reasons_of(record) -> list:
    """Лише вибори (причини) із запису — те, що рахує дзеркало."""
    out = []
    for a in ((record or {}).get("answers") or []):
        if isinstance(a, dict) and a.get("kind") == KIND_CHOICE:
            out.append({"label": _s(a.get("label")), "value": _s(a.get("value")),
                        "other": bool(a.get("other")), "text": _s(a.get("text"))[:300]})
    return out


# ---------------------------------------------------------------------------
# ОДИН РЯДОК (телеграм): «номер варіанта і слова»
# ---------------------------------------------------------------------------
_LINE = re.compile(r"^\s*(\d{1,2})(?:\s*[.,:;)\-–—]\s*|\s+|$)(.*)$", re.S)


def prompt(t: dict) -> str:
    """Що бот питає: варіанти першого вибору номерами."""
    ch = [f for f in t.get("fields") or [] if f["kind"] == KIND_CHOICE]
    if not ch:
        return "Напишіть відповідь."
    rows = ["%d. %s" % (i + 1, o) for i, o in enumerate(ch[0]["options"])]
    return ("«%s». %s — напишіть номер і далі своїми словами (для «%s» — обовʼязково):\n%s"
            % (t["name"], ch[0]["label"], OTHER, "\n".join(rows)))


def answers_from_line(t: dict, line: str) -> dict:
    """«3 переробляю розділ 2» → відповіді шаблону: номер — перший вибір, слова — перше
    текстове поле (або «Інше»). Інші обовʼязкові поля з телефона не заповнити — тоді
    відмова з адресою: на екрані."""
    m = _LINE.match(_s(line))
    ch = [f for f in t.get("fields") or [] if f["kind"] == KIND_CHOICE]
    if not ch or not m:
        raise TemplateError("Почніть із номера варіанта, наприклад: «2 візьму дані завтра».")
    n, rest = int(m.group(1)), _s(m.group(2))
    opts = ch[0]["options"]
    if not 1 <= n <= len(opts):
        raise TemplateError("Такого номера немає: варіанти від 1 до %d." % len(opts))
    out = {ch[0]["id"]: opts[n - 1]}
    texts = [f for f in t["fields"] if f["kind"] == KIND_TEXT]
    if opts[n - 1] == OTHER:
        out[ch[0]["id"] + OTHER_SUFFIX] = rest
        if texts:
            out[texts[0]["id"]] = rest
    elif texts:
        out[texts[0]["id"]] = rest
    for f in t["fields"]:
        if f["required"] and f["id"] not in out and f is not ch[0]:
            raise TemplateError("Шаблон «%s» має поле «%s» — його заповніть на екрані задачі."
                                % (t["name"], f["label"]))
    return out
