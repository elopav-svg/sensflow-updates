# -*- coding: utf-8 -*-
"""taskdesk_projects.py — проєкти в самому Task Desk (зміна 705, 06.10.2026).

Звідки. Проєкт розробки Task Desk для ОТУ від 06.10.2026, погоджений того ж дня,
частина 2 (пп. 3.1, 3.2) з варіантами «пропонуємо» розділу 4.

Що тут. ОДИН суддя всього, що стосується проєкту в Task Desk: хто його бачить,
хто ним керує, хто може попросити доступ, які стани бувають і що кожен із них
означає. Запис лежить там само, де й завжди (`projects.py`, тека проєктів) —
проєкт із консолі оркестратора і проєкт із Task Desk це той самий запис.

⛒ ВИДИМІСТЬ (4.2 В). Проєкт бачать: адміністратор · власник · учасники ·
керівники вгору по структурі від власника й від кожного учасника · кожен, хто
бачить хоч одну задачу цього проєкту (виконавцю не треба окремо просити доступ
до проєкту своєї задачі, а його керівник бачить задачу підлеглого вже й так).
Решта бачить лише назву й власника в «Попросити доступ»; власник погоджує.
Підлеглий власника САМ проєкт не бачить — так погоджено (до 705 бачив).

⛒ ВІДКРИТИЙ ПРОЄКТ бачать усі: «Управління» (керівні й загальні задачі, 4.3) і
проєкти з консолі без власника — ті поводяться, як досі.

⛒ СТАНИ. «Активний» — пропонується в нових задачах. «Неактивний» — не
пропонується, але все в ньому живе і правиться. «В архіві» — зникає з робочих
екранів; задачі відкриваються, назва каже «в архіві». Нічого не стирається.

Цей модуль НЕ читає задач (інакше коло імпортів із `taskdesk_tasks`): те, які
проєкти людина бачить через свої задачі, йому передає той, хто питає
(`Viewer.task_projects`).

⛒⛒ 709 (3.3). КОЛОНКИ ДОШКИ ВЕДЕ ВЛАСНИК ПРОЄКТУ. Колонка — назва і місце на дошці
ВСЕРЕДИНІ однієї з чотирьох основних стадій (Нова, У роботі, На перевірці, Завершена),
а не нова стадія: права, сповіщення, строки й статистика й далі живуть стадією, тож
працюють однаково в усіх проєктах. Основна колонка кожної стадії є завжди (її можна
перейменувати, не прибрати); власні стоять у межах своєї стадії; прибрати — лише
порожню. «Не пройшла перевірку» — повернення з перевірки, колонкою туди не ходять.
Скільки задач у колонці, цей модуль не рахує (задач не читає) — передає той, хто питає.
"""
import uuid

import clock
import projects
import taskdesk_people as people


class ProjectError(Exception):
    """Відмова словами — екран показує її людині як є."""


ST_ACTIVE = "active"
ST_INACTIVE = "inactive"
ST_ARCHIVED = "archived"
STATUS_NAMES = {ST_ACTIVE: "Активний", ST_INACTIVE: "Неактивний", ST_ARCHIVED: "В архіві"}

# ⭐ «Управління» — один на компанію, тому id сталий: друге заведення (два входи
# одночасно) пише той самий файл, а не дубль.
MANAGEMENT_ID = "prj-upravlinnia"
MANAGEMENT_NAME = "Управління"

NAME_MAX = 80
DESC_MAX = 1000
NOTE_MAX = 300
HISTORY_MAX = 300

REFUSE_MANAGE = ("Керувати проєктом може його власник, керівник власника або "
                 "адміністратор.")

# ⭐ 709: межа власних колонок на дошці — щоб дошка лишалась дошкою, а не стрічкою.
COLUMNS_MAX = 12
COLUMN_NAME_MAX = 40
COLUMN_PREFIX = "col-"


def _s(v) -> str:
    return str(v or "").strip()


def column_stages() -> tuple:
    """Стадії, до яких належать колонки, — основна лінія платформи. Писар стадій ОДИН
    (`taskdesk_tasks`); імпорт лінивий, бо той модуль імпортує цей."""
    import taskdesk_tasks as _tasks
    return tuple(_tasks.STAGES_MAIN)


def _stage_names() -> dict:
    import taskdesk_tasks as _tasks
    return dict(_tasks.STAGE_NAMES)


def _shape_board(raw) -> list:
    """Колонки в порядку дошки: стадія за стадією, усередині — як поставив власник.
    Основна колонка стадії є завжди (з назвою або без — тоді назва стадії)."""
    stages = column_stages()
    by_stage = {st: [] for st in stages}
    seen = set()
    for c in raw or []:
        if not isinstance(c, dict):
            continue
        cid, st = _s(c.get("id")), _s(c.get("stage"))
        name = _s(c.get("name"))[:COLUMN_NAME_MAX]
        if st not in by_stage or cid in seen:
            continue
        if cid != st and not (cid.startswith(COLUMN_PREFIX) and name):
            continue
        seen.add(cid)
        by_stage[st].append({"id": cid, "stage": st, "name": name})
    for st in stages:
        if st not in seen:
            by_stage[st].insert(0, {"id": st, "stage": st, "name": ""})
    return [c for st in stages for c in by_stage[st]]


def _columns_view(board: list) -> list:
    names = _stage_names()
    return [{"id": c["id"], "stage": c["stage"], "base": c["id"] == c["stage"],
             "name": c["name"] or names.get(c["stage"], c["stage"])} for c in board]


def shape(rec: dict) -> dict:
    """Запис із усіма полями Task Desk. Старі записи (до 705) читаються так:
    стан «Активний», учасників і запитів немає, без власника — відкритий."""
    r = dict(rec or {})
    r["id"] = _s(r.get("id"))
    r["name"] = _s(r.get("name")) or "Без назви"
    r["owner_id"] = _s(r.get("owner_id"))
    r["description"] = _s(r.get("description"))
    if r.get("status") not in STATUS_NAMES:
        r["status"] = ST_ACTIVE
    r["members"] = [m for m in dict.fromkeys(_s(x) for x in (r.get("members") or [])) if m]
    r["requests"] = [q for q in (r.get("requests") or [])
                     if isinstance(q, dict) and _s(q.get("employee_id"))]
    r["history"] = [h for h in (r.get("history") or []) if isinstance(h, dict)]
    r["open"] = bool(r["open"]) if "open" in r else not r["owner_id"]
    r["created_by"] = _s(r.get("created_by"))
    r["board"] = _shape_board(r.get("board"))       # ⭐ 709: колонки дошки
    return r


class Viewer:
    """Хто дивиться. Підлеглих і проєкти своїх задач рахує лише раз і лише тоді,
    коли без них не обійтись."""

    def __init__(self, emp_id: str, is_admin: bool = False, task_projects=None):
        self.id = _s(emp_id)
        self.admin = bool(is_admin)
        self._tp = task_projects            # множина або функція, що її дає
        self._subs = None

    @property
    def subs(self) -> set:
        if self._subs is None:
            self._subs = set(people.subordinates_of(self.id)) if self.id else set()
        return self._subs

    @property
    def task_projects(self) -> set:
        if callable(self._tp):
            self._tp = set(self._tp() or ())
        return set(self._tp or ())


def seen_by(rec: dict, v: Viewer) -> bool:
    r = shape(rec)
    if v.admin or r["open"]:
        return True
    if not v.id:
        return False
    if v.id == r["owner_id"] or v.id in r["members"]:
        return True
    # Керівник угору: власник або учасник — серед його підлеглих.
    if r["owner_id"] in v.subs or any(m in v.subs for m in r["members"]):
        return True
    return r["id"] in v.task_projects


def may_manage(rec: dict, v: Viewer) -> bool:
    r = shape(rec)
    if v.admin:
        return True
    if not v.id or not r["owner_id"]:
        return False
    return v.id == r["owner_id"] or r["owner_id"] in v.subs


def _get(pid: str) -> dict:
    rec = projects.get(_s(pid))
    if not rec:
        raise ProjectError("Такого проєкту немає.")
    return shape(rec)


def _require_manage(rec: dict, v: Viewer):
    if not may_manage(rec, v):
        raise ProjectError(REFUSE_MANAGE)


def _note(rec: dict, v: Viewer, what: str):
    rec["history"].append({"at": clock.now(), "by": v.id or "адміністратор", "what": what})
    rec["history"] = rec["history"][-HISTORY_MAX:]


def _emp_name(emp_id: str) -> str:
    e = people.employee(emp_id) or {}
    return e.get("full_name") or ""


def _require_employee(emp_id: str, what: str) -> str:
    e = people.employee(_s(emp_id))
    if not e or not e.get("active"):
        raise ProjectError("%s — оберіть працівника, який працює." % what)
    return e["id"]


def _check_owner(owner_id: str, v: Viewer) -> str:
    if not _s(owner_id):
        raise ProjectError("Вкажіть власника проєкту.")
    owner = _require_employee(owner_id, "Власник проєкту")
    if not v.admin and owner != v.id and owner not in v.subs:
        raise ProjectError("Власником проєкту можна зробити себе або свого підлеглого.")
    return owner


def _check_name(name: str, skip_id: str = "") -> str:
    name = _s(name)[:NAME_MAX]
    if not name:
        raise ProjectError("Вкажіть назву проєкту.")
    low = name.casefold()
    for r in projects.all_records():
        r = shape(r)
        if r["id"] != skip_id and r["status"] != ST_ARCHIVED and r["name"].casefold() == low:
            raise ProjectError("Проєкт «%s» уже є — оберіть іншу назву." % r["name"])
    return name


# ─────────────────────────────── ДІЇ ────────────────────────────────────────
def create(v: Viewer, name: str, owner_id: str, description: str = "") -> dict:
    """Право «Створювати проєкти» судить двері (`taskdesk_api`), бо воно — від
    облікового запису; тут — назва, власник і запис."""
    name = _check_name(name)
    owner = _check_owner(owner_id, v)
    rec = shape(projects.create(name, owner, description=_s(description)[:DESC_MAX],
                                created_by=v.id, open_to_all=False))
    _note(rec, v, "завів проєкт; власник — %s" % _emp_name(owner))
    return projects.write(rec)


def edit(v: Viewer, pid: str, name=None, description=None, owner_id=None) -> dict:
    rec = _get(pid)
    _require_manage(rec, v)
    if name is not None and _s(name) != rec["name"]:
        rec["name"] = _check_name(name, rec["id"])
        _note(rec, v, "назва: %s" % rec["name"])
    if description is not None and _s(description) != rec["description"]:
        rec["description"] = _s(description)[:DESC_MAX]
        _note(rec, v, "змінив опис")
    if owner_id is not None and _s(owner_id) != rec["owner_id"]:
        rec["owner_id"] = _check_owner(owner_id, v)
        rec["members"] = [m for m in rec["members"] if m != rec["owner_id"]]
        _note(rec, v, "власник: %s" % _emp_name(rec["owner_id"]))
    return projects.write(rec)


def set_status(v: Viewer, pid: str, status: str) -> dict:
    rec = _get(pid)
    _require_manage(rec, v)
    status = _s(status)
    if status not in STATUS_NAMES:
        raise ProjectError("Невідомий стан «%s». Можна: %s."
                           % (status, ", ".join(STATUS_NAMES.values())))
    if rec["id"] == MANAGEMENT_ID and status == ST_ARCHIVED:
        raise ProjectError("Проєкт «%s» — дім керівних і загальних задач; в архів він "
                           "не кладеться." % MANAGEMENT_NAME)
    if status != rec["status"]:
        if status != ST_ARCHIVED and rec["status"] == ST_ARCHIVED:
            _check_name(rec["name"], rec["id"])     # повернення не родить двійника
        rec["status"] = status
        _note(rec, v, "стан: %s" % STATUS_NAMES[status])
    return projects.write(rec)


def member_add(v: Viewer, pid: str, emp_id: str) -> dict:
    rec = _get(pid)
    _require_manage(rec, v)
    emp = _require_employee(emp_id, "Учасник")
    if emp != rec["owner_id"] and emp not in rec["members"]:
        rec["members"].append(emp)
        _note(rec, v, "додав учасника: %s" % _emp_name(emp))
    rec["requests"] = [q for q in rec["requests"] if _s(q.get("employee_id")) != emp]
    return projects.write(rec)


def member_remove(v: Viewer, pid: str, emp_id: str) -> dict:
    rec = _get(pid)
    _require_manage(rec, v)
    emp = _s(emp_id)
    if emp in rec["members"]:
        rec["members"].remove(emp)
        _note(rec, v, "прибрав учасника: %s" % _emp_name(emp))
    return projects.write(rec)


def request(v: Viewer, pid: str, note: str = "") -> dict:
    rec = _get(pid)
    if not v.id:
        raise ProjectError("Попросити доступ може працівник.")
    if rec["status"] == ST_ARCHIVED:
        raise ProjectError("Проєкт в архіві — доступ до нього не просять.")
    if seen_by(rec, v):
        raise ProjectError("Цей проєкт вам уже видно.")
    if any(_s(q.get("employee_id")) == v.id for q in rec["requests"]):
        raise ProjectError("Ви вже попросили доступ — чекайте рішення власника.")
    rec["requests"].append({"employee_id": v.id, "note": _s(note)[:NOTE_MAX],
                            "at": clock.now()})
    _note(rec, v, "попросив доступ")
    return projects.write(rec)


def decide(v: Viewer, pid: str, emp_id: str, accept: bool) -> dict:
    rec = _get(pid)
    _require_manage(rec, v)
    emp = _s(emp_id)
    if not any(_s(q.get("employee_id")) == emp for q in rec["requests"]):
        raise ProjectError("Запиту від цієї людини немає.")
    rec["requests"] = [q for q in rec["requests"] if _s(q.get("employee_id")) != emp]
    if accept:
        if emp != rec["owner_id"] and emp not in rec["members"]:
            rec["members"].append(emp)
        _note(rec, v, "погодив доступ: %s" % _emp_name(emp))
    else:
        _note(rec, v, "відхилив доступ: %s" % _emp_name(emp))
    return projects.write(rec)


# ─────────────────────────── 709: КОЛОНКИ ДОШКИ ────────────────────────────
def _find_column(rec: dict, column_id: str) -> dict:
    cid = _s(column_id)
    for c in _columns_view(rec["board"]):
        if c["id"] == cid:
            return c
    raise ProjectError("На дошці проєкту «%s» такої колонки немає — оновіть сторінку."
                       % rec["name"])


def _check_column_name(rec: dict, name: str, stage: str, skip_id: str = "") -> str:
    name = _s(name)[:COLUMN_NAME_MAX]
    if not name:
        raise ProjectError("Вкажіть назву колонки.")
    low = name.casefold()
    names = _stage_names()
    # ⛒ Колонка «Завершена» в стадії «У роботі» казала б людині неправду про задачу.
    for st, nm in names.items():
        if st != stage and nm.casefold() == low:
            raise ProjectError("«%s» — назва стадії платформи; колонка стадії «%s» так "
                               "зватись не може." % (nm, names.get(stage, stage)))
    for c in _columns_view(rec["board"]):
        if c["id"] != skip_id and c["name"].casefold() == low:
            raise ProjectError("Колонка «%s» на дошці вже є — оберіть іншу назву." % c["name"])
    return name


def column_add(v: Viewer, pid: str, name: str, stage: str) -> dict:
    rec = _get(pid)
    _require_manage(rec, v)
    stage, names = _s(stage), _stage_names()
    stages = column_stages()
    if stage not in stages:
        raise ProjectError("Колонка належить одній з основних стадій: %s."
                           % ", ".join(names[s] for s in stages))
    own = [c for c in rec["board"] if c["id"] != c["stage"]]
    if len(own) >= COLUMNS_MAX:
        raise ProjectError("На дошці вже %d власних колонок — більше не додати. Приберіть "
                           "зайву." % COLUMNS_MAX)
    name = _check_column_name(rec, name, stage)
    taken = {c["id"] for c in rec["board"]}
    cid = COLUMN_PREFIX + uuid.uuid4().hex[:8]
    while cid in taken:
        cid = COLUMN_PREFIX + uuid.uuid4().hex[:8]
    # Останньою у своїй стадії: порядок стадій на дошці тримає `_shape_board`.
    rec["board"].append({"id": cid, "stage": stage, "name": name})
    rec["board"] = _shape_board(rec["board"])
    _note(rec, v, "додав колонку «%s» (стадія «%s»)" % (name, names[stage]))
    return projects.write(rec)


def column_rename(v: Viewer, pid: str, column_id: str, name: str) -> dict:
    rec = _get(pid)
    _require_manage(rec, v)
    col = _find_column(rec, column_id)
    name = _check_column_name(rec, name, col["stage"], col["id"])
    if name != col["name"]:
        default = _stage_names().get(col["stage"], "")
        for c in rec["board"]:
            if c["id"] == col["id"]:
                c["name"] = "" if (col["base"] and name == default) else name
        _note(rec, v, "колонка «%s» → «%s»" % (col["name"], name))
    return projects.write(rec)


def column_move(v: Viewer, pid: str, column_id: str, left: bool = True) -> dict:
    """Лівіше / правіше — у межах своєї стадії: порядок стадій на дошці той самий скрізь."""
    rec = _get(pid)
    _require_manage(rec, v)
    col = _find_column(rec, column_id)
    group = [i for i, c in enumerate(rec["board"]) if c["stage"] == col["stage"]]
    k = [rec["board"][i]["id"] for i in group].index(col["id"])
    j = k - 1 if left else k + 1
    if not 0 <= j < len(group):
        raise ProjectError("Колонка «%s» уже %s у стадії «%s»: колонки стоять у межах своєї "
                           "стадії." % (col["name"], "перша" if left else "остання",
                                        _stage_names().get(col["stage"], col["stage"])))
    a, b = group[k], group[j]
    rec["board"][a], rec["board"][b] = rec["board"][b], rec["board"][a]
    _note(rec, v, "колонка «%s» — %s" % (col["name"], "лівіше" if left else "правіше"))
    return projects.write(rec)


def column_remove(v: Viewer, pid: str, column_id: str, occupied) -> dict:
    """`occupied(column_id)` — скільки задач у колонці; рахує той, хто читає задачі."""
    rec = _get(pid)
    _require_manage(rec, v)
    col = _find_column(rec, column_id)
    if col["base"]:
        raise ProjectError("Основну колонку «%s» не прибрати: це дім стадії «%s». Її можна "
                           "перейменувати." % (col["name"],
                                               _stage_names().get(col["stage"], col["stage"])))
    n = int(occupied(col["id"]) or 0)
    if n:
        raise ProjectError("У колонці «%s» задач: %d — спершу перенесіть їх в іншу колонку."
                           % (col["name"], n))
    rec["board"] = [c for c in rec["board"] if c["id"] != col["id"]]
    _note(rec, v, "прибрав колонку «%s»" % col["name"])
    return projects.write(rec)


def ensure_management(owner_id: str = "") -> dict:
    """«Управління» заводиться саме, один раз (4.3): щоб жодній керівній чи
    загальній задачі не бракувало дому. Видно всім."""
    rec = projects.get(MANAGEMENT_ID)
    if rec:
        return shape(rec)
    rec = shape(projects.create(MANAGEMENT_NAME, _s(owner_id), created_by="",
                                open_to_all=True, pid=MANAGEMENT_ID,
                                description="Керівні й загальні задачі компанії."))
    rec["history"].append({"at": clock.now(), "by": "платформа",
                           "what": "завела проєкт «%s»" % MANAGEMENT_NAME})
    return projects.write(rec)


# ─────────────────────────────── ЧИТАННЯ ────────────────────────────────────
def for_pick(v: Viewer) -> list:
    """Що людина може обрати в НОВІЙ задачі: видимі й активні."""
    out = []
    for r in projects.all_records():
        r = shape(r)
        if r["status"] == ST_ACTIVE and seen_by(r, v):
            out.append({"id": r["id"], "name": r["name"]})
    return out


def require_for_task(v: Viewer, project_id: str, keep: str = "") -> str:
    """Ворота проєкту задачі. Порожньо — дозволено (4.3 Б). Той самий проєкт,
    що вже стоїть у задачі (`keep`), — пропускаємо: правка задачі неактивного
    чи архівного проєкту не мусить ламатись."""
    pid = _s(project_id)
    if not pid or pid == _s(keep):
        return pid
    rec = projects.get(pid)
    if not rec:
        raise ProjectError("Такого проєкту немає.")
    rec = shape(rec)
    if not seen_by(rec, v):
        raise ProjectError("Цей проєкт вам не належить — оберіть зі свого переліку.")
    if rec["status"] == ST_INACTIVE:
        raise ProjectError("Проєкт «%s» неактивний — нові задачі в нього не ставлять."
                           % rec["name"])
    if rec["status"] == ST_ARCHIVED:
        raise ProjectError("Проєкт «%s» в архіві — нові задачі в нього не ставлять."
                           % rec["name"])
    return pid


def display_name(project_id: str) -> str:
    pid = _s(project_id)
    if not pid:
        return ""
    rec = projects.get(pid)
    if not rec:
        return "проєкт видалено"
    rec = shape(rec)
    return rec["name"] + (" (в архіві)" if rec["status"] == ST_ARCHIVED else "")


def board_columns(project) -> list:
    """⭐ 709: колонки дошки проєкту для екрана й для задач: id, стадія, назва, «основна».
    Немає проєкту — основні чотири: задача з видаленим проєктом не ламається."""
    rec = project if isinstance(project, dict) else projects.get(_s(project))
    return _columns_view(shape(rec or {})["board"])


def _row(r: dict, v: Viewer) -> dict:
    manage = may_manage(r, v)
    out = {"id": r["id"], "name": r["name"], "description": r["description"],
           "owner_id": r["owner_id"], "owner_name": _emp_name(r["owner_id"]),
           "status": r["status"], "status_name": STATUS_NAMES[r["status"]],
           "open": r["open"], "may_manage": manage,
           "members": [{"id": m, "name": _emp_name(m)} for m in r["members"]],
           "columns": _columns_view(r["board"])}
    if manage:
        out["requests"] = [{"employee_id": q["employee_id"],
                            "name": _emp_name(q["employee_id"]),
                            "note": _s(q.get("note")), "at": _s(q.get("at"))}
                           for q in r["requests"]]
    return out


def listing(v: Viewer) -> dict:
    """Усе, що екран проєктів показує людині: робочий перелік, архів і те, до
    чого можна попросити доступ."""
    work, archived, requestable = [], [], []
    for r in projects.all_records():
        r = shape(r)
        if seen_by(r, v):
            (archived if r["status"] == ST_ARCHIVED else work).append(_row(r, v))
        elif r["status"] != ST_ARCHIVED and v.id:
            requestable.append({"id": r["id"], "name": r["name"],
                                "owner_name": _emp_name(r["owner_id"]),
                                "requested": any(_s(q.get("employee_id")) == v.id
                                                 for q in r["requests"])})
    return {"projects": work, "archived": archived, "requestable": requestable}
