"""
agent.py — СПРАВЖНІЙ LLM-оркестратор на tool-calling (без релейного switch).

Принцип: запит потрапляє у LLM. Модель аналізує, розуміє контекст і САМА вирішує,
які інструменти викликати (можна кілька поспіль), а тоді дає користувачу фінальну
відповідь звичайним текстом. Жодних захардкоджених if-гілок між ШІ і дією —
Python лише ВИКОНУЄ інструменти, які обрала модель.

Інструменти-дії: run_system, save_writing_style, web_search, fetch_url,
list_systems, set_system_status, smoke_test_system, build_system, create_automation.
Якщо бракує даних — модель просто питає користувача текстом (це і є фінал ходу).
"""

import json

import config
import llmtools
import llm
import registry
import capabilities
import executor
import verifier
import artifacts
import store
import styles
import tools as toolbox
import management
import builder
import scheduler
import knowledge
import audit

MAX_STEPS = 8  # стеля кроків міркування, щоб не зациклитись


# ---------------------------------------------------------------------------
# Системний промпт оркестратора (філософія + самомодель + інструкція до інструментів)
# ---------------------------------------------------------------------------
def _system_prompt() -> str:
    principles = (
        "Ти — Global Orchestrator. Запит користувача потрапляє до тебе; ти його "
        "ОСМИСЛЮЄШ і ДІЄШ через інструменти.\n\n"
        "## ПАМ'ЯТЬ СЕСІЇ\n"
        "В історії можуть бути вже ЗДАНІ результати (позначені «[ЗДАНИЙ РЕЗУЛЬТАТ — вже "
        "створено й передано користувачу]») з їх змістом і файлами. Це АВТОРИТЕТНИЙ стан: "
        "такий результат РЕАЛЬНО існує й переданий. НІКОЛИ не кажи, що його не створено, і "
        "не пропонуй переробити заново без прямого прохання. На уточнення про нього (дати, "
        "цифри, джерела, переклад, скорочення) відповідай ЗА ЙОГО ЗМІСТОМ з історії. Старі "
        "обірвані/невдалі спроби НЕ скасовують пізніший зданий результат.\n\n"
        "## ЯК ДУМАТИ\n"
        "1. Зрозумій справжній намір: дію (написати/проаналізувати/побудувати) і "
        "ПРЕДМЕТ (домен, джерела істини, ризик помилки). Домен важливіший за форму: "
        "якщо предмет правовий/нормативний/безпековий — це не задача копірайтера, навіть "
        "якщо просять «просто описати».\n"
        "2. Обери шлях: відповісти напряму; виконати задачу через систему (run_system); "
        "зберегти/застосувати стиль; пошукати в інтернеті; керувати системами; або "
        "побудувати нову систему, якщо відповідної немає.\n"
        "2b. СПЕРШУ МАРШРУТ, ПОТІМ ДІЇ. Твоє ПЕРШЕ рішення — «сам чи через систему», і "
        "лише потім будь-які інструменти. Якщо задача піде в систему — НЕ виконуй її "
        "підзадачі власними інструментами: НЕ роби web_search «на розігрів», навіть якщо "
        "задача починається зі слів «досліди/знайди/проаналізуй». Системи мають ВЛАСНИЙ "
        "живий веб-пошук і дослідницьких агентів — твій попередній пошук дублює роботу, "
        "витрачає час і гроші, а його результати в систему не потрапляють. Твій web_search "
        "доречний лише у двох випадках: відповідаєш напряму сам (без системи), або без "
        "короткої перевірки одного факту неможливо обрати маршрут (рідко, один точковий "
        "запит).\n"
        "3. Маршрутизуй СЕМАНТИЧНО, а не за словами. Не запускай непідходящу систему.\n"
        "3b. ФОРМА ≠ СИСТЕМА. Формат результату (дашборд, презентація, слайди, excel, html, "
        "pdf, звіт) — це лише ДИРЕКТИВА ВИВОДУ, яку платформа застосовує АВТОМАТИЧНО поверх "
        "будь-якого результату. НІКОЛИ не обирай систему за словом форми. Спершу визнач СУТЬ "
        "роботи (що по змісту треба зробити), і маршрутизуй за суттю; форму платформа віддасть "
        "сама. Системи-«дашборди»/«excel-звіти» (категорія dashboard, позначені [форма-звітність]) "
        "— це ВНУТРІШНЯ звітність за ВЖЕ НАЯВНИМИ даними, НЕ для зовнішнього дослідження. Якщо "
        "потрібне дослідження ринку/конкурентів/галузі — обери систему, що РОБИТЬ ринкове "
        "дослідження з живим веб-пошуком (напр. суть «ринкове дослідження», «оцінка ринку та "
        "конкурентів»), а вже її результат за потреби покажи дашбордом/презентацією.\n"
        "4. Перед запуском ЧУТЛИВОЇ системи (юридичної, фінансової, медичної, безпекової) "
        "або перед побудовою нової — спитай у користувача коротке підтвердження.\n"
        "5. Якщо бракує КРИТИЧНИХ даних (немає файлу/предмета) — стисло спитай користувача, "
        "перш ніж запускати систему. Дрібниці припускай сам, не допитуй. АЛЕ: МАТЕРІАЛЬНІ "
        "параметри результату НЕ вигадуй і не «зашивай» у задачу мовчки — спитай користувача. "
        "Це зокрема (особливо для права/договорів/фінансів): які саме МОВИ для дво-/багатомовного "
        "документа; застосовне право (governing law) і підсудність; юрисдикція; тип документа; "
        "дата (підписання/актуальності). Якщо такий параметр прямо не заданий — постав коротке "
        "уточнювальне питання, а не обирай за користувача.\n"
        "6. Source-first для безпеки/права/фінансів/маршрутів: не вигадуй факти; "
        "за потреби спершу пошукай (web_search) або попроси джерела/файл.\n\n"
        "## ЯК НЕ СПІТКНУТИСЬ (важливо)\n"
        "• Кожен запуск системи АВТОМАТИЧНО створює усі формати файлів одразу: "
        ".md, .docx, .html, .xlsx (а презентації — .pptx). Тому коли користувач просить "
        "«дай docx», «надай у форматі excel», «покажи файл» того, що ТИ ВЖЕ створив у "
        "цьому діалозі — цей файл УЖЕ доступний для завантаження вище в чаті. Просто "
        "підтверди це звичайним текстом. НЕ запускай run_system повторно заради вже "
        "готового результату — це марно витрачає час і ліміти.\n"
        "• «ДАЙ ПОСИЛАННЯ / ЛІНК НА ЗАВАНТАЖЕННЯ»: файли вже показані під відповіддю як "
        "клікабельні кнопки-посилання (⬇ назва файлу) — натисни, щоб завантажити чи "
        "відкрити. НІКОЛИ не відповідай «не можу дати посилання»: коротко скеруй користувача "
        "до цих кнопок під повідомленням (вони лишаються доступними і після перезавантаження "
        "чату). Якщо потрібного файлу в цьому діалозі ще немає — скористайся find_results.\n"
        "• Викликай run_system ЛИШЕ для НОВОЇ змістовної роботи. Тривіальні дії "
        "(дати готовий файл, відповісти на просте питання, пояснити вже зроблене, "
        "невелика правка тексту) роби сам у фінальній відповіді, без запуску системи.\n"
        "• СЕРЙОЗНІ ДОМЕНИ — ЗАВЖДИ ЧЕРЕЗ СИСТЕМУ. Юридичні/договірні питання, аналіз чи "
        "складання документів, фінмоделі, бізнес-стратегія, податкові питання — виконуй "
        "ЛИШЕ через відповідну систему (run_system), навіть якщо питання здається простим. "
        "Саме там — звірка норм і джерел, уточнювальні питання за браку даних і готовий "
        "перевірений файл. НЕ відповідай на такі запити напряму текстом: пряма відповідь "
        "обрізається лімітом, не має звірки й не створює документ. Якщо для якісної роботи "
        "бракує даних — НЕ відмовляйся й не вгадуй: запусти систему, вона сама поставить "
        "користувачу короткі уточнювальні питання. Сумніваєшся «система чи сам?» для права/"
        "фінансів/договорів — обирай систему.\n"
        "• ЗОВНІШНІЙ КОНТЕНТ — ЗАВЖДИ ЧЕРЕЗ КОПІРАЙТЕРСЬКУ СИСТЕМУ. Будь-який текст для "
        "публікації назовні (пост, стаття, допис для Telegram/LinkedIn/Facebook, розсилка, "
        "лендинг, карусель) — виконуй ЛИШЕ через run_system копірайтерської системи, навіть "
        "якщо текст короткий і здається дрібницею. Саме в системі — голос автора, база знань "
        "(анти-slop, структури платформ), критик і захист від повторів; твій прямий текст "
        "цього всього не має. НІКОЛИ не пиши публікаційний контент сам. Якщо користувач каже "
        "«не питай мене / згенеруй сам / без уточнень» — це означає ЛИШЕ «без уточнювальних "
        "питань»: все одно запусти систему, а в task додай «користувач просить без "
        "інтервʼю/уточнень — генеруй з наявного». Це НЕ дозвіл оминути систему. Сам, без "
        "системи, роби тільки дрібні правки ВЖЕ створеного тексту.\n"
        "• Якщо стався збій інструмента (ліміт/мережа) — не вигадуй фейкові виправдання; "
        "коротко й чесно поясни і запропонуй конкретний наступний крок.\n"
        "• " + config.NO_FABRICATION_NOTE + "\n"
        "• " + config.INJECTION_GUARD_NOTE + "\n"
        "• ГЛИБИНА run_system: став depth='quick' для простих/коротких задач (короткий "
        "допис, проста вибірка, чернетка одного розділу, дрібна правка через систему) — "
        "це швидше й економить ліміти. Лиши depth='full' (за замовчуванням) для серйозного: "
        "аналіз, юридичні/договірні задачі, дослідження, багатоскладові результати, де "
        "важлива максимальна якість.\n\n"
        "## ЯК ДІЯТИ\n"
        "Викликай інструменти, коли треба (можна кілька поспіль — напр. спершу "
        "save_writing_style, потім run_system у цьому стилі). Інструменти самі бачать "
        "прикріплені файли/посилання/вставлений текст — не копіюй великі тексти в "
        "аргументи. Коли задача виконана — дай користувачу ФІНАЛЬНУ відповідь звичайним "
        "текстом (без JSON, без службових міток). Якщо ставиш питання — це теж фінал ходу.\n\n"
        "## ЯК ОФОРМИТИ ФІНАЛЬНУ ВІДПОВІДЬ (КРИТИЧНО — стисло!)\n"
        "• Коли спрацювала система і є готовий результат — твоя фінальна відповідь у чат "
        "МАЄ БУТИ ГРАНИЧНО КОРОТКОЮ: 1–2 речення, що саме готове. Сам результат і файли "
        "показуються користувачу ОКРЕМО — не дублюй їх.\n"
        "• ЗАБОРОНЕНО: перелічувати зміст по пунктах/слайдах, переказувати документ, "
        "вставляти повний текст результату, цитувати свій план чи ці інструкції, писати "
        "«що увійшло», «структура така», службові примітки. Жодного промпта й ходу думок у "
        "фінальній відповіді.\n"
        "• Приклад доброї відповіді: «Готово — аналітичний звіт із 12 розділів. Файли нижче.» "
        "І все. Для простої прямої відповіді без системи — відповідай по суті, без вступів і "
        "самоопису.\n"
    )
    return principles + "\n" + capabilities.self_model_prompt()


# ---------------------------------------------------------------------------
# Схеми інструментів (нейтральні; конвертуються під провайдера)
# ---------------------------------------------------------------------------
def _tool_schemas() -> list:
    sys_ids = [s.get("id") for s in registry.load_systems()]
    style_names = [s.get("name") for s in styles.list_styles()]
    _schemas = [
        {"name": "run_system",
         "description": "Виконати мультиагентську систему оркестру на задачі користувача. "
                        "Повертає готовий результат і артефакти.",
         "parameters": {"type": "object", "properties": {
             "system_id": {"type": "string", "description": "id системи з реєстру", "enum": sys_ids or None},
             "task": {"type": "string", "description": "чітке формулювання задачі для системи (з усіма відомими параметрами)"},
             "style_name": {"type": "string", "description": "(необов.) назва збереженого стилю письма"},
             "depth": {"type": "string", "enum": ["quick", "full"], "description":
                       "Глибина: 'quick' — швидко, без раундів критика (прості/короткі задачі: короткий допис, проста вибірка, чернетка одного розділу). 'full' — повний цикл якості (за замовчуванням; для аналізу, юридичних/договірних, дослідницьких, багатоскладових результатів)."}
         }, "required": ["system_id", "task"]}},
        {"name": "save_writing_style",
         "description": "Проаналізувати наданий текст-зразок (з прикріпленого файлу/посилання/повідомлення) "
                        "і зберегти авторський стиль як іменований пресет для подальшого використання.",
         "parameters": {"type": "object", "properties": {
             "name": {"type": "string", "description": "назва стилю, напр. «Жванецький»"}
         }, "required": ["name"]}},
        {"name": "web_search",
         "description": "Живий пошук в інтернеті з джерелами. Для актуальних фактів/новин/ринку.",
         "parameters": {"type": "object", "properties": {
             "query": {"type": "string"}}, "required": ["query"]}},
        {"name": "fetch_url",
         "description": "Завантажити і прочитати текст конкретної веб-сторінки.",
         "parameters": {"type": "object", "properties": {
             "url": {"type": "string"}}, "required": ["url"]}},
        {"name": "list_systems",
         "description": "Отримати актуальний перелік систем оркестру з їхніми статусами.",
         "parameters": {"type": "object", "properties": {}}},
        {"name": "find_results",
         "description": "Знайти РАНІШЕ згенеровані результати (минулі запуски) і повернути їхні файли "
                        "для завантаження. Використовуй, коли користувач просить дати/знайти результат "
                        "чи файл, який вже робили раніше («дай ту аналітику договору», «де презентація з "
                        "минулого разу»). Без query повертає найсвіжіші запуски.",
         "parameters": {"type": "object", "properties": {
             "query": {"type": "string", "description": "ключові слова з опису минулої задачі (тема/тип документа)"},
             "system_id": {"type": "string", "description": "(необов.) обмежити певною системою"},
             "limit": {"type": "integer", "description": "скільки результатів повернути (типово 5)"}
         }}},
        {"name": "add_knowledge",
         "description": "«Навчити» конкретну систему: додати матеріал із прикріпленого файлу/вставленого тексту до її бази знань. "
                        "Використовуй, коли користувач просить додати методологію, фреймворки чи довідку до системи "
                        "(напр. «додай це до бази знань Бізнес-аналітика»). Зміст береться з прикріплених матеріалів — "
                        "не копіюй великий текст в аргументи.",
         "parameters": {"type": "object", "properties": {
             "system_id": {"type": "string", "description": "id системи, яку навчаємо", "enum": sys_ids or None},
             "title": {"type": "string", "description": "коротка назва матеріалу (напр. «CEO-фреймворки Eric Partaker»)"},
             "source": {"type": "string", "description": "(необов.) джерело: автор / файл / посилання"}
         }, "required": ["system_id", "title"]}},
        {"name": "set_system_status",
         "description": "Активувати або деактивувати систему (active|inactive).",
         "parameters": {"type": "object", "properties": {
             "system_id": {"type": "string"}, "status": {"type": "string", "enum": ["active", "inactive"]}
         }, "required": ["system_id", "status"]}},
        {"name": "smoke_test_system",
         "description": "Прогнати smoke-тест системи (перевірити, що вона працює).",
         "parameters": {"type": "object", "properties": {
             "system_id": {"type": "string"}}, "required": ["system_id"]}},
        {"name": "build_system",
         "description": "Створити НОВУ мультиагентську систему, якщо відповідної немає.",
         "parameters": {"type": "object", "properties": {
             "name": {"type": "string"}, "goal": {"type": "string"},
             "agents": {"type": "array", "items": {"type": "object", "properties": {
                 "name": {"type": "string"}, "role": {"type": "string"}}}}
         }, "required": ["name", "goal"]}},
        {"name": "create_automation",
         "description": "Створити регулярну (heartbeat) задачу за розкладом.",
         "parameters": {"type": "object", "properties": {
             "name": {"type": "string"}, "cadence": {"type": "string", "description": "напр. щодня, щотижня"},
             "task": {"type": "string"}, "target_system_id": {"type": "string"}
         }, "required": ["name", "cadence", "task"]}},
    ]
    # RBAC-lite: у режимі оператора прибираємо КЕРІВНІ інструменти (створення/зміна/
    # вимкнення систем, автоматизації, навчання) — оператор лише запускає й читає.
    try:
        import license as _lic
        if _lic.role() == "operator":
            _admin_tools = {"build_system", "set_system_status", "smoke_test_system",
                            "create_automation", "add_knowledge"}
            return [s for s in _schemas if s.get("name") not in _admin_tools]
    except Exception:
        pass
    return _schemas


# ---------------------------------------------------------------------------
# Реалізації інструментів (тонкі; беруть великий контекст з ctx)
# ---------------------------------------------------------------------------
def _emit(ctx, label):
    if ctx.get("emit"):
        try:
            ctx["emit"]("stage", label)
        except Exception:
            pass


def _impl_run_system(args, ctx):
    # Гейт підписки: працює лише за активною ліцензією АБО в межах пробного періоду.
    import license as licensing
    ent = licensing.entitlement()
    if not ent.get("active"):
        return ("⛔ " + ent.get("message", "Потрібна активна підписка.")
                + " Передай це користувачу й НЕ виконуй задачу: активувати ліцензію можна в "
                  "«Про систему → Ліцензія» або звернутись до підтримки SensFlow.")
    system = registry.find_system(args.get("system_id"))
    if not system:
        return f"Система «{args.get('system_id')}» не знайдена. Доступні: " + \
               ", ".join(s["id"] for s in registry.load_systems())
    task = args.get("task") or ctx["message"]
    style_name = args.get("style_name") or ""
    style = ""
    if style_name:
        rec = styles.find_style(style_name)
        style = styles.profile_as_prompt(rec) if rec else ""
    depth = args.get("depth") if args.get("depth") in ("quick", "full") else "full"
    _emit(ctx, f"▶ Запускаю систему «{system.get('name')}»" + (" ⚡ швидко" if depth == "quick" else "") + "…")
    # Інтерактивні уточнення: для серйозних задач (depth=full) система спершу
    # перевіряє, чи достатньо даних. Якщо ні — повертає КРИТИЧНІ питання, і мозок
    # ставить їх користувачу, перш ніж виконувати (а не вгадує й не робить наосліп).
    ex = executor.run_system(system, task, files_context=ctx["files_context"],
                             history=ctx["history"], precheck=(depth == "full"),
                             emit=ctx.get("emit"), style=style, depth=depth,
                             should_cancel=ctx.get("should_cancel"))
    if ex.get("status") == "cancelled":
        return "Роботу системи перервано на запит користувача. Файли не створювались."
    if ex.get("status") == "needs_input":
        qs = [q for q in (ex.get("questions") or []) if q]
        if qs:
            return ("Перш ніж виконати, система потребує уточнень. Постав користувачу САМЕ ці "
                    "питання (коротким списком, дружньо) і дочекайся відповідей — лише потім "
                    "запускай run_system знову. НЕ вигадуй відповіді за користувача:\n— "
                    + "\n— ".join(qs))
        # питань немає — рушаємо далі без блокування
        ex = executor.run_system(system, task, files_context=ctx["files_context"],
                                 history=ctx["history"], precheck=False, emit=ctx.get("emit"),
                                 style=style, depth=depth, should_cancel=ctx.get("should_cancel"))
    if ex.get("status") == "cancelled":
        return "Роботу системи перервано на запит користувача. Файли не створювались."
    if ex.get("status") != "completed":
        return f"Система не завершила виконання: {ex.get('status')}. {ex.get('final_markdown','')[:300]}"
    final_md = ex.get("final_markdown", "")
    sources = ex.get("sources", [])
    gate = verifier.verify(task, final_md, criteria=ex.get("success_criteria"), sources=sources)
    # Анти-галюцинація: вигадані/мертві посилання вилучаємо ще до збереження файлів.
    if gate.get("dead_urls"):
        final_md = verifier.neutralize_dead_urls(final_md, gate["dead_urls"])
        _emit(ctx, f"🚫 Вилучено недійсні посилання: {len(gate['dead_urls'])}")
    run_id = store.new_run_id(artifacts.result_title(final_md) or task)
    arts = artifacts.write_result_artifacts(run_id, final_md, task=task)
    store.save_run({"run_id": run_id, "task": task, "system_id": system.get("id"),
                    "status": ex.get("status"), "verified": gate.get("ok"), "result": final_md})
    audit.log_run(system.get("id"), task, ex.get("status"), gate.get("ok"),
                  run_id=run_id, dead_urls=len(gate.get("dead_urls") or []))
    # зібрати для фінальної відповіді користувачу.
    # Для показу в чаті прибираємо великий HTML-код (він уже став окремим .html
    # файлом), щоб у відповідь не потрапляла «стіна коду»/«розгорнутий промпт».
    display_md = final_md
    try:
        _doc, _clean = artifacts.extract_html_document(final_md)
        if _doc:
            display_md = _clean
    except Exception:
        pass
    ctx["collected"]["primary_markdown"] = display_md
    ctx["collected"]["artifacts"] = arts
    ctx["collected"]["sources"] = sources
    ctx["collected"]["verification"] = {"checks": gate.get("checks", []),
                                        "ok": gate.get("ok"), "note": gate.get("note", "")}
    ctx["collected"]["trace"] = [{"agent": t.get("agent"), "role": t.get("role", "agent"),
                                  "output": t.get("output", "")} for t in ex.get("agent_trace", [])]
    checks = "; ".join(f"{'ok' if c['ok'] else 'ні'}:{c['label']}" for c in gate.get("checks", []))
    warn = ""
    if gate.get("dead_urls"):
        warn = (f" УВАГА: у результаті були НЕДІЙСНІ/ВИГАДАНІ посилання ({', '.join(gate['dead_urls'][:3])}) — "
                f"їх вилучено. ОБОВ'ЯЗКОВО чесно попередь користувача, що оригінальне джерело не "
                f"підтверджено, і не видавай вигадку за факт.")
    return (f"Система «{system.get('name')}» виконала задачу. Перевірка якості: {checks}.{warn} "
            f"Результат ({len(final_md)} символів) і файли ВЖЕ показано користувачу окремо. "
            f"Твоя відповідь у чат — лише 1 коротке речення-супровід (що готове). "
            f"НЕ повторюй текст, НЕ перелічуй зміст/розділи, НЕ описуй структуру.")


def _impl_save_style(args, ctx):
    name = args.get("name") or "Мій стиль"
    sample = ctx["files_context"] if (ctx["files_context"] and ctx["files_context"].strip()) else ctx["message"]
    if not (sample and len(sample.strip()) > 40):
        return "Немає тексту-зразка. Попроси користувача дати текст (вставити, файлом або посиланням)."
    _emit(ctx, f"🎨 Аналізую стиль «{name}»…")
    rec = styles.analyze_and_save(name, sample)
    p = rec.get("profile", {})
    return (f"Збережено стиль «{rec.get('name')}». Профіль: {p.get('summary','')}; "
            f"тон: {p.get('tone','')}; речення: {p.get('sentence_style','')}; "
            f"прийоми: {', '.join(p.get('devices', []) if isinstance(p.get('devices'), list) else [])}.")


def _impl_web_search(args, ctx):
    _emit(ctx, "🌐 Веб-пошук…")
    r = toolbox.web_search(args.get("query", ""))
    if not r.get("ok"):
        return f"Пошук недоступний: {r.get('note')}"
    srcs = r.get("sources", [])
    ctx["collected"]["sources"].extend(srcs)
    block = r.get("text", "")
    if srcs:
        block += "\nДжерела: " + "; ".join(s.get("url", "") for s in srcs)
    return block[:4000]


def _impl_fetch_url(args, ctx):
    _emit(ctx, "🔗 Читаю сторінку…")
    r = toolbox.fetch_url(args.get("url", ""))
    return (r.get("text", "")[:6000] if r.get("ok") else f"Не вдалося: {r.get('note')}")


def _impl_find_results(args, ctx):
    _emit(ctx, "🗂 Шукаю минулі результати…")
    query = (args.get("query") or "").strip().lower()
    system_id = (args.get("system_id") or "").strip()
    try:
        limit = int(args.get("limit") or 5)
    except Exception:
        limit = 5
    runs = store.list_runs(limit=200)
    # Стеми (перші 6 літер) — щоб ловити українські словоформи: «вакансія»~«вакансію».
    stems = [w[:6] for w in query.split() if len(w) > 2]

    def score(r):
        if system_id and r.get("system_id") != system_id:
            return -1
        if not stems:
            return 0
        task = (r.get("task") or "").lower()
        return sum(1 for w in stems if w in task)

    scored = [(score(r), r) for r in runs]
    scored = [(s, r) for s, r in scored if s >= 0]
    if stems:
        matched = [(s, r) for s, r in scored if s > 0]
        if not matched:
            return "Минулих результатів за цим запитом не знайдено. Уточни ключові слова або назву системи."
        scored = matched
    scored.sort(key=lambda x: x[0], reverse=True)  # за збігом; list_runs уже за датою desc
    top = [r for _s, r in scored[:limit]]
    if not top:
        return "Минулих результатів ще немає."

    arts, lines = [], []
    for r in top:
        fs = store.list_artifacts(r["run_id"])
        arts.extend(fs)
        lines.append(f"- {(r.get('created_at') or '')[:16]} · {r.get('system_id') or '—'}: "
                     f"{(r.get('task') or '')[:90]} ({len(fs)} файл.)")
    ctx["collected"]["artifacts"].extend(arts)
    return ("Знайдено минулі результати (файли додано до відповіді — покажи користувачу посилання):\n"
            + "\n".join(lines))


def _impl_add_knowledge(args, ctx):
    system = registry.find_system(args.get("system_id"))
    if not system:
        return (f"Система «{args.get('system_id')}» не знайдена. Доступні: "
                + ", ".join(s["id"] for s in registry.load_systems()))
    content = ctx.get("files_context") or ""
    if not (content and content.strip()):
        return ("Немає матеріалу для додавання до бази знань. Попроси користувача прикріпити файл "
                "або вставити текст у повідомлення.")
    title = (args.get("title") or "Матеріал бази знань").strip()
    _emit(ctx, f"📚 Додаю в базу знань «{system.get('name')}»: {title}…")
    rec = knowledge.add(system, title, content, source=args.get("source", ""))
    return (f"Додано до бази знань системи «{system.get('name')}»: «{title}» "
            f"({rec['chars']} символів). Відтепер агенти цієї системи використовуватимуть це "
            f"як довідку під час роботи.")


def _impl_list_systems(args, ctx):
    return json.dumps([{"id": s["id"], "name": s.get("name"), "status": s.get("status"),
                        "sensitive": bool(s.get("sensitive"))} for s in registry.load_systems()],
                      ensure_ascii=False)


def _impl_set_status(args, ctx):
    if args.get("status") == "active":
        return management.activate(args.get("system_id")).get("message", "ok")
    return management.deactivate(args.get("system_id")).get("message", "ok")


def _impl_smoke(args, ctx):
    _emit(ctx, "🔎 Smoke-тест…")
    r = management.smoke_test(args.get("system_id"))
    return r.get("report", "") + (f"\n{r.get('preview','')}" if r.get("preview") else "")


def _impl_build(args, ctx):
    _emit(ctx, f"🏗️ Будую систему «{args.get('name')}»…")
    proposed = {"name": args.get("name"), "goal": args.get("goal"),
                "agents": args.get("agents", [])}
    b = builder.build_system(proposed, ctx["message"], ctx["files_context"])
    if not b.get("ok"):
        return f"Не вдалося створити: {b.get('note')}"
    return f"Створено систему «{args.get('name')}» (id={b['system_id']}, статус needs_review)."


def _impl_automation(args, ctx):
    spec = {"name": args.get("name"), "cadence": args.get("cadence")}
    rec = scheduler.create_automation(spec, args.get("task", ""), args.get("target_system_id"))
    return f"Створено автоматизацію «{rec['name']}» ({rec['cadence']}), наступний запуск {rec['next_run_at'][:16]}."


# Реєстр інструментів мозку (виконавці tool-calls).
_DISPATCH = {
    "run_system": _impl_run_system,
    "save_writing_style": _impl_save_style,
    "web_search": _impl_web_search,
    "fetch_url": _impl_fetch_url,
    "find_results": _impl_find_results,
    "add_knowledge": _impl_add_knowledge,
    "list_systems": _impl_list_systems,
    "set_system_status": _impl_set_status,
    "smoke_test_system": _impl_smoke,
    "build_system": _impl_build,
    "create_automation": _impl_automation,
}


# Людські назви інструментів для панелі «що робить мозок».
_TOOL_LABELS = {
    "run_system": ("⚙", "Запуск системи"),
    "save_writing_style": ("🎨", "Збереження стилю"),
    "web_search": ("🌐", "Веб-пошук"),
    "fetch_url": ("🔗", "Читання сторінки"),
    "list_systems": ("📋", "Перелік систем"),
    "set_system_status": ("🛠", "Зміна статусу системи"),
    "smoke_test_system": ("🧪", "Тест системи"),
    "build_system": ("🏗", "Створення системи"),
    "create_automation": ("⏰", "Автоматизація"),
}


def _tool_summary(name, args) -> str:
    a = args or {}
    if name == "run_system":
        pre = "⚡ " if a.get("depth") == "quick" else ""
        return f"{a.get('system_id', '')} · {pre}{(a.get('task') or '')[:80]}"
    if name == "web_search":
        return (a.get("query") or "")[:90]
    if name == "fetch_url":
        return (a.get("url") or "")[:90]
    if name == "save_writing_style":
        return a.get("name", "")
    if name == "set_system_status":
        return f"{a.get('system_id', '')} → {a.get('status', '')}"
    if name in ("smoke_test_system", "build_system"):
        return a.get("system_id") or a.get("name") or ""
    if name == "create_automation":
        return a.get("name", "")
    return ""


def _dispatch(name, args, ctx):
    # RBAC-lite (захист в глибину): керівні інструменти заблоковано для оператора.
    try:
        import license as _lic
        if name in ("build_system", "set_system_status", "smoke_test_system",
                    "create_automation", "add_knowledge") and _lic.role() == "operator":
            return ("Дія недоступна в режимі оператора (керування системами — лише для "
                    "адміністратора). Передай це користувачу й не виконуй.")
    except Exception:
        pass
    fn = _DISPATCH.get(name)
    if not fn:
        return f"Невідомий інструмент: {name}"
    try:
        return str(fn(args or {}, ctx))
    except Exception as e:  # інструмент не має ронити весь цикл
        import sys
        sys.stderr.write(f"[agent] інструмент {name} впав: {e}\n")
        return f"Помилка інструмента {name}: {e}"


# ---------------------------------------------------------------------------
# Агентний цикл
# ---------------------------------------------------------------------------
def run(message: str, history=None, files_context: str = "", emit=None, should_cancel=None,
        project_context: str = "") -> dict:
    if not config.provider_ready():
        return {"reply": "LLM-мозок не налаштований (немає API-ключа).",
                "decision": {"status": "error"}, "result": None, "pending": None}

    ctx = {"message": message, "files_context": files_context or "", "history": history or [],
           "emit": emit, "should_cancel": should_cancel,
           "collected": {"artifacts": [], "sources": [], "trace": [],
                         "primary_markdown": "", "brain_trace": []}}

    # Стартові повідомлення: історія + поточний запит (з матеріалами інлайн).
    messages = []
    for turn in (history or [])[-8:]:
        role = "assistant" if turn.get("role") == "assistant" else "user"
        # Обрізаємо довгі попередні повідомлення: для маршрутизації не потрібен
        # повний текст раніше згенерованих статей/договорів.
        content = (turn.get("content", "") or "")
        if len(content) > 3000:
            content = content[:3000] + "\n…[раніше згенерований результат скорочено; файли вже доступні в чаті]"
        messages.append({"role": role, "content": content})
    user_content = message
    if files_context and files_context.strip():
        user_content += ("\n\n## ДОДАНІ МАТЕРІАЛИ (файли/посилання/вставлений текст)\n"
                         + files_context[:14000])
    messages.append({"role": "user", "content": user_content})

    sys_prompt = _system_prompt()
    # Контекст проєкту: спільні факти/інструкції, які мозок має тримати в голові в
    # КОЖНОМУ чаті цього проєкту. Точкова вставка в системний промпт — логіку мозку
    # не переробляємо. Порожньо для чатів поза проєктом.
    if project_context and project_context.strip():
        sys_prompt += ("\n\n## КОНТЕКСТ ПРОЄКТУ (тримай у голові протягом усієї розмови)\n"
                       + project_context.strip()[:4000])
    schemas = _tool_schemas()

    _emit(ctx, "🧭 Аналізую запит…")
    for _step in range(MAX_STEPS):
        if should_cancel and should_cancel():
            _emit(ctx, "⏹ Зупинено на ваш запит.")
            return _final("⏹ Роботу перервано на ваш запит. Можете уточнити чи переформулювати задачу.", ctx)
        try:
            turn = llmtools.tool_turn(sys_prompt, messages, schemas,
                                      model=config.brain_model(), max_tokens=2000)
        except (llm.LLMError, llm.LLMNotConfigured) as e:
            return {"reply": f"Помилка мозку: {e}", "decision": {"status": "error"},
                    "result": None, "pending": None}

        calls = turn.get("tool_calls") or []
        if calls:
            # Думка мозку перед діями (часто пояснює, чому саме ці інструменти).
            thought = (turn.get("text") or "").strip()
            if thought:
                # живий прогрес показуємо, але у фінальну панель «Що зроблено»
                # думки-міркування НЕ зберігаємо (без промпта/ходу думок у чаті).
                _emit(ctx, "💭 " + thought[:160])
            messages.append({"role": "assistant", "content": turn.get("text") or "",
                             "tool_calls": calls})
            for tc in calls:
                nm = tc.get("name")
                icon, label = _TOOL_LABELS.get(nm, ("🔧", "Інструмент"))
                summ = _tool_summary(nm, tc.get("args"))
                _emit(ctx, f"{icon} {label}: {summ}" if summ else f"{icon} {label}")
                ctx["collected"]["brain_trace"].append(
                    {"type": "tool", "name": nm, "label": label, "icon": icon, "summary": summ})
                result = _dispatch(nm, tc.get("args"), ctx)
                messages.append({"role": "tool", "tool_call_id": tc.get("id"),
                                 "name": nm, "content": result})
            continue

        # Немає викликів інструментів -> фінальна відповідь користувачу.
        return _final(turn.get("text") or "Готово.", ctx)

    return _final("Я зробив кілька кроків, але не завершив за відведений ліміт. "
                  "Уточніть, будь ласка, задачу.", ctx)


def _final(text: str, ctx) -> dict:
    col = ctx["collected"]
    primary = col.get("primary_markdown", "")
    reply = (text or "").strip()
    # Анти-галюцинація для ПРЯМОЇ відповіді мозку (коли система не запускалась —
    # інакше посилання вже перевірені в run_system). Вигадані URL вилучаємо.
    if reply and not primary:
        try:
            known = [s.get("url") for s in col.get("sources", []) if isinstance(s, dict) and s.get("url")]
            lr = verifier.validate_urls(reply, known_urls=known, do_network=config.provider_ready())
            if lr.get("dead"):
                reply = verifier.neutralize_dead_urls(reply, lr["dead"])
                reply += ("\n\n⚠ Частина посилань виявилась недійсними — їх вилучено; "
                          "оригінальне джерело не підтверджено.")
        except Exception:
            pass
    # ЧИСТИЙ ВИВІД: коли спрацювала система, повний результат НЕ дублюємо в репліку —
    # він показується окремо (як тіло результату + файли). Репліка лишається короткою.
    if primary:
        # якщо модель таки вставила (частину) документа в репліку — прибираємо дубль
        head = primary[:80]
        if head and head in reply:
            reply = reply.split(head)[0].strip()
        # запобіжник: багатослівну преамбулу обрізаємо до кількох речень
        if len(reply) > 600:
            cut = reply[:600]
            best = max(cut.rfind(". "), cut.rfind("!\n"), cut.rfind(".\n"), cut.rfind("! "))
            if best > 200:
                cut = cut[:best + 1]
            reply = cut.strip() + " …"
        if not reply:
            reply = "Готово — результат і файли нижче."
    result = None
    if primary or col.get("artifacts") or col.get("brain_trace"):
        result = {"final_markdown": primary, "artifacts": col.get("artifacts", []),
                  "sources": col.get("sources", []),
                  "trace": col.get("trace", []),
                  "brain_trace": col.get("brain_trace", []),
                  "verification": col.get("verification")}
    return {"reply": reply, "decision": {"status": "agent"}, "result": result, "pending": None}
