"""
executor.py — виконання обраної системи за її ВЛАСНОЮ логікою.

Головний принцип (правило для ВСІХ систем):
  1) ОСМИСЛЕННЯ: оркестратор спершу читає ВСІ промпти системи — кореневі
     правила (CLAUDE.md/PROMPT.md) і промпт КОЖНОГО агента — і виводить
     структурований план виконання (послідовність, ролі, цикл якості,
     обовʼязкові входи, критерії успіху). План кешується per-system.
  2) УТОЧНЕННЯ: якщо за планом бракує обовʼязкових входів — питає користувача.
  3) ВИКОНАННЯ: запускає агентів САМЕ за планом (порядок і призначення з логіки
     системи), з циклом доопрацювання критик→ревізор згідно правил системи.
  4) ПЕРЕВІРКА: звіряє результат із критеріями успіху, визначеними планом.
"""

import json
import hashlib
import re

import config
import llm
import llmtools
import registry
import knowledge
import owner_profile  # ⭐ 31.07.2026: імʼя автора/бренд — ДАНІ, а не текст промпта
import tools
import costs
import verifier
import audit  # ОДИН писар сліду прогонів і відмов (01.08.2026)
import failure  # ⭐ 29.07.2026: ОДИН перекладач аварій — сирий виняток клієнту не виходить
import legal_source_ua  # ШАР 1: офіційне першоджерело норм права UA (data.rada.gov.ua)
import schema_org  # детермінований будівник schema.org JSON-LD (контракт «модель→рендер»)
import route_engine  # детермінований маршрутний двигун (ORS) — реальний шлях, не «з голови»
import tender_pack      # ворота доказовості тендерного пакета (05.08.2026)
import tender_skeleton  # кістяк пакета будує КОД, а не модель (05.08.2026)

_ART = (config.PLATFORM_ARTIFACT_NOTE + "\n\n" + config.NO_FABRICATION_NOTE
        + "\n\n" + config.INJECTION_GUARD_NOTE)
HARD_MAX_REVISIONS = 3  # стеля вартості, навіть якщо система дозволяє більше
LEGAL_BUDGET_FACTOR = 2.0  # правова задача коштує дорожче за природою (28.07.2026)


def _emit(emit, label):
    """Безпечно надсилає подію прогресу (для стрімінгу). emit=None -> no-op."""
    if emit:
        try:
            emit("stage", label)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Завантаження промптів
# ---------------------------------------------------------------------------
# ⭐⭐⭐ 31.07.2026. ОДИН ЧИТАЧ МОЗКУ — І ОДНА ТОЧКА ПІДСТАНОВКИ.
# Досі текст мозку читали ДВІ різні функції (кореневі правила системи й промпт
# агента), і кожна віддавала його моделі ДОСЛІВНО. Тому зашите в промпт імʼя
# автора їхало до клієнта як частина інструкції — і система, зроблена під
# одного автора, поїхала в продукт (корінь «копірайтер», 31.07.2026).
# Тепер обидві йдуть через ОДНОГО читача, а імʼя автора й бренд приходять із
# профілю власника копії [[owner_profile]]. Двох писарів цієї правди немає.
def _read_brain_text(path, render: bool = True) -> str:
    """Прочитати файл мозку. ЄДИНА точка читання.

    render=True  — РОБОЧИЙ текст для моделі: підставляємо профіль власника.
    render=False — СИРИЙ текст із плейсхолдерами. Потрібен там, де результат
      ЗБЕРІГАЄТЬСЯ НА ДИСК і їде клієнту (кеш плану системи).
      ⭐⭐⭐ 31.07.2026, живий прогін: план будувався з ПІДСТАВЛЕНОГО тексту, і в
      `.orchestration_plan.json` осіло «для проєкту SensFlow» — наше імʼя поїхало б
      клієнту всередині паспорта системи. **ПОХІДНЕ ЗНАЧЕННЯ, ЗБЕРЕЖЕНЕ НА ДИСК, —
      ПОЧАТОК ДРУГОЇ ПРАВДИ.** План описує СТРУКТУРУ, а не чиєсь імʼя.
    """
    try:
        raw = path.read_text(encoding="utf-8-sig")
        return owner_profile.render(raw) if render else raw
    except Exception:
        return ""


def _system_root_prompt(system: dict, render: bool = True) -> str:
    root = registry.system_root(system)
    for name in ("CLAUDE.md", "PROMPT.md"):
        p = root / name
        if p.exists():
            t = _read_brain_text(p, render)
            if t:
                return t
    return ""


def _load_agent_prompt(system: dict, agent_id: str, render: bool = True) -> str:
    root = registry.system_root(system)
    for c in (root / "Agents" / agent_id / "PROMPT.md",
              root / "Agents" / agent_id / "CLAUDE.md",
              root / "Agents" / agent_id.lower() / "PROMPT.md",
              root / "agents" / agent_id / "PROMPT.md"):
        if c.exists():
            t = _read_brain_text(c, render)
            if t:
                return t
    return ""


def _registry_agent_ids(system: dict) -> list:
    ids = []
    for a in system.get("agents", []):
        ids.append(a.get("id") or a.get("name") if isinstance(a, dict) else a)
    return [i for i in ids if i] or ["AgentMain"]


def _collect_prompts(system: dict) -> dict:
    """Набір промптів для ОСМИСЛЕННЯ (побудови плану) — СИРИЙ, з плейсхолдерами.
    План кешується на диск і їде клієнту, тому імені власника в ньому бути НЕ може.
    Робочі кроки агентів беруть текст окремо і вже ПІДСТАВЛЕНИЙ."""
    agents = {}
    for aid in _registry_agent_ids(system):
        agents[aid] = _load_agent_prompt(system, aid, render=False)
    return {"root": _system_root_prompt(system, render=False), "agents": agents}


# ---------------------------------------------------------------------------
# Фаза 1: ОСМИСЛЕННЯ системи (читає всі промпти -> план виконання)
# ---------------------------------------------------------------------------
def _plan_cache_path(system: dict):
    return registry.system_root(system) / ".orchestration_plan.json"


def _prompts_hash(prompts: dict) -> str:
    h = hashlib.md5()
    h.update((prompts.get("root") or "").encode("utf-8"))
    for aid in sorted(prompts.get("agents", {})):
        h.update(aid.encode("utf-8"))
        h.update((prompts["agents"][aid] or "").encode("utf-8"))
    return h.hexdigest()


def _plan_missing_agents(plan: dict, declared) -> list:
    """Агенти, ОГОЛОШЕНІ в системі, яких у плані НЕМАЄ ніде: ні в конвеєрі,
    ні в колі якості (критик/ревізор часто саме там).

    ⭐ 30.07.2026. Навіщо: у `legal_assistant` оголошено 5 агентів, а збережений
    план виконував 4 — тендерного юриста в конвеєрі просто не було, і ніхто
    цього не бачив. Хеш промптів такого не ловить: він рахує ТЕКСТИ промптів,
    а не СКЛАД конвеєра. Клієнт платив за команду, а працювала частина команди.
    """
    # ⭐ Порівнюємо СМИСЛ імені, а не спосіб його запису: план цілком може називати
    # того самого агента `agent_interviewer`, а реєстр — `AgentInterviewer`. Без
    # цієї нормалізації кеш був би недійсним ЩОРАЗУ, і план перебудовувався б на
    # КОЖНОМУ прогоні — тобто мій запобіжник почав би палити гроші власника.
    def _norm(a) -> str:
        return "".join(ch for ch in str(a or "").lower() if ch.isalnum())

    used = set()
    for s in (plan or {}).get("pipeline") or []:
        aid = (s or {}).get("agent") if isinstance(s, dict) else s
        if aid:
            used.add(_norm(aid))
    ql = (plan or {}).get("quality_loop") or {}
    if isinstance(ql, dict):
        for aid in (ql.get("critic_agent"), ql.get("reviser_agent")):
            if aid:
                used.add(_norm(aid))
    return [a for a in (declared or []) if _norm(a) not in used]


def _agent_purpose(prompt_text: str) -> str:
    """Призначення агента — З ЙОГО ВЛАСНОГО ПРОМПТА, а не з моєї вигадки."""
    for line in (prompt_text or "").splitlines():
        t = line.strip().lstrip("#").strip()
        if len(t) > 20 and not t.startswith(("```", "|", "-", "*")):
            return t[:200]
    return "виконати свій етап згідно ролі"


def _complete_pipeline(plan: dict, prompts: dict, system: dict) -> dict:
    """Дописує в конвеєр оголошених агентів, яких модель-планувальник загубила.

    ⭐⭐⭐ 30.07.2026 (живий прогін Андрія, зміна 35). СКЛАД КОМАНДИ ВИЗНАЧАЄ СИСТЕМА,
    А НЕ МОДЕЛЬ. Перевірка чинності кешу спрацювала правильно і чесно сказала в лозі:
    «конвеєр не використовує AgentTenderCounsel». План перебудувався — і модель
    ВИКИНУЛА тендерного юриста ВДРУГЕ. Наслідок бачив Андрій: у відповіді не було
    переліку дій, бо кроки участі пише саме той агент, якого не покликали.

    Дві біди від одного кореня, і обидві лікуються тут:
      1. клієнт платив за команду, а працювала частина команди;
      2. МОЯ МІНА: пропажа не зникала, тому план перебудовувався б НА КОЖНОМУ
         прогоні — тобто мій же запобіжник палив би гроші власника щоразу.

    Модель має право вирішувати ПОРЯДОК і ПРИЗНАЧЕННЯ кроків. Права викинути
    оголошеного агента вона не має: склад команди — це паспорт системи, і писар у
    нього один. Тому тут не ворота і не «ще одна перевірка», а ВИЛУЧЕННЯ права.
    """
    declared = list((prompts or {}).get("agents") or {})
    missing = _plan_missing_agents(plan, declared)
    if not missing:
        return plan
    steps = list(plan.get("pipeline") or [])
    ql = plan.get("quality_loop") or {}
    guards = {str(ql.get("critic_agent") or "").strip().lower(),
              str(ql.get("reviser_agent") or "").strip().lower()}
    guards.discard("")

    def _is_guard(st):
        aid = (st or {}).get("agent") if isinstance(st, dict) else st
        return str(aid or "").strip().lower() in guards

    # Місце вставки: ПЕРЕД охоронцями якості наприкінці — критик має судити вже
    # готову роботу, зокрема й роботу дописаного агента.
    cut = len(steps)
    while cut > 0 and _is_guard(steps[cut - 1]):
        cut -= 1
    for aid in missing:
        steps.insert(cut, {"agent": aid,
                           "purpose": _agent_purpose((prompts.get("agents") or {}).get(aid)),
                           "produces": "внесок цього агента у фінальний результат",
                           "needs_web_search": False})
        cut += 1
    plan["pipeline"] = steps
    llm._log("[executor] конвеєр «%s» доповнено оголошеними агентами, яких модель не "
             "взяла: %s (склад команди визначає система, не модель)"
             % (system.get("id") or "?", ", ".join(str(a) for a in missing)))
    return plan


def comprehend_system(system: dict, force: bool = False) -> dict:
    """
    Читає всі промпти системи і повертає план виконання (з кешу, якщо промпти не змінились).
    План:
      {system_understanding, required_inputs[], pipeline[{agent,purpose,produces}],
       quality_loop{enabled,critic_agent,reviser_agent,pass_threshold,max_iterations},
       final_deliverable, success_criteria[]}
    """
    prompts = _collect_prompts(system)
    phash = _prompts_hash(prompts)
    cache_path = _plan_cache_path(system)

    if not force and cache_path.exists():
        try:
            cached = json.loads(cache_path.read_text(encoding="utf-8"))
            if cached.get("_hash") == phash and cached.get("plan"):
                # ЧИННІСТЬ КЕШУ ≠ ЛИШЕ ХЕШ ПРОМПТІВ. План, який не використовує
                # оголошеного агента, — недійсний: система обіцяла клієнту одну
                # команду, а працює інша. Такий кеш перебудовуємо тим самим
                # шляхом, що й при force=True (просто не повертаємо його).
                _missing = _plan_missing_agents(cached["plan"], prompts["agents"].keys())
                if not _missing:
                    return cached["plan"]
                # Мовчазна перебудова — це витрата грошей власника без пояснення,
                # тому причину НАЗИВАЄМО вголос.
                llm._log("[executor] план системи «%s» перебудовується: збережений "
                         "конвеєр не використовує оголошених агентів — %s "
                         "(немає ні в pipeline, ні в quality_loop)"
                         % (system.get("id") or system.get("name") or "?",
                            ", ".join(str(a) for a in _missing)))
        except Exception:
            pass

    fallback = _complete_pipeline(_fallback_plan(system, prompts), prompts, system)

    if not config.provider_ready():
        return fallback

    agent_blocks = "\n\n".join(
        f"### Промпт агента {aid}\n{(text or '(промпт відсутній)')[:4000]}"
        for aid, text in prompts["agents"].items()
    )
    sys_prompt = (
        "Ти — Global Orchestrator. Тобі дано ПОВНИЙ набір промптів мультиагентської "
        "системи: кореневі правила оркестрації і промпт кожного агента. Уважно прочитай "
        "їх і ЗРОЗУМІЙ внутрішню логіку системи: який порядок агентів, хто за що "
        "відповідає, чи є цикл контролю якості і за якою умовою він завершується, які "
        "вхідні дані обовʼязкові, який фінальний результат. "
        f"Платформа має інструмент ВЕБ-ПОШУКУ ({'доступний' if config.web_search_ready() else 'наразі недоступний'}): "
        "для кроків, де агенту потрібні актуальні зовнішні дані (новини, тренди, ринок, "
        "конкуренти, ціни, нормативні джерела, перевірка фактів про осіб/компанії), "
        "став needs_web_search=true; для суто внутрішніх кроків — false. "
        "Поверни РІВНО ОДИН JSON:\n"
        "{\n"
        '  "system_understanding": "стислий опис логіки системи своїми словами (2-4 речення)",\n'
        '  "required_inputs": ["обовʼязкові вхідні дані від користувача"],\n'
        '  "pipeline": [{"agent": "id", "purpose": "що робить", "produces": "результат", "needs_web_search": true|false}],\n'
        '  "quality_loop": {"enabled": true|false, "critic_agent": "id|null", "reviser_agent": "id|null", "pass_threshold": "умова проходження (напр. 9/10)", "max_iterations": число},\n'
        '  "final_deliverable": "що саме отримує користувач",\n'
        '  "success_criteria": ["за чим перевіряти готовий результат"]\n'
        "}\n"
        "Порядок у pipeline бери з ЛОГІКИ системи, а не лише з переліку. Без тексту поза JSON."
    )
    user = (
        f"## СИСТЕМА: {system.get('name')} (id={system.get('id')})\n"
        f"Опис: {system.get('description','')}\n"
        f"Режим: {system.get('orchestration_mode','')}\n\n"
        f"## КОРЕНЕВІ ПРАВИЛА (root)\n{(prompts['root'] or '(відсутні)')[:6000]}\n\n"
        f"## ПРОМПТИ АГЕНТІВ\n{agent_blocks}"
    )
    try:
        plan = llm.judge_json(sys_prompt, user, temperature=0.1, model=config.brain_model(),
                              purpose="осмислення системи")
    except llm.LLMError:
        return fallback

    plan = _normalize_plan(plan, system, fallback)
    # Склад команди — за системою. Якщо модель когось загубила, дописуємо ДО запису
    # в кеш: інакше наступний прогін знову побачив би пропажу і знову перебудовував
    # план — нескінченна витрата грошей власника на ту саму помилку.
    plan = _complete_pipeline(plan, prompts, system)
    try:
        cache_path.write_text(json.dumps({"_hash": phash, "plan": plan},
                                         ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass
    return plan


_HIGH_STAKES_CATS = {"legal", "finance", "finance_excel", "medical", "health", "security", "strategy"}
_HIGH_STAKES_KEYS = ("юрист", "юридич", "правов", "договір", "догов", "нормат", "фінанс",
                     "бюджет", "податк", "медич", "ризик", "безпек", "страт", "комплаєнс",
                     "legal", "financ", "contract", "compliance", "strateg", "tax", "medical")


def _is_high_stakes(system: dict, task: str = "") -> bool:
    """Високі ставки (право/фінанси/стратегія/медицина/безпека) — фінал збирає дорогий
    мозок (якість). Решта — дешева модель (вартість)."""
    cat = (system.get("category") or "").lower()
    if cat in _HIGH_STAKES_CATS:
        return True
    blob = " ".join(str(system.get(k, "") or "") for k in ("name", "display_name", "id", "description")).lower()
    blob += " " + (task or "").lower()
    return any(k in blob for k in _HIGH_STAKES_KEYS)


# Побудова НОВОЇ системи (мета-режим Будівника) — свідомо важча робота, ніж питання
# в чаті. Їй стеля втричі вища, щоб запобіжник від «втечі вартості» не різав
# легітимну довгу роботу навпіл.
META_BUDGET_FACTOR = 3.0


def _run_cap(meta_mode: bool = False, legal_mode: bool = False) -> float:
    """Стеля вартості ЦЬОГО прогону в $. 0 = межі немає (свідомо вимкнено).

    Дорожчі ЗА ПРИРОДОЮ задачі мають власну стелю — одна точка рішення на всю
    систему, а не виняток для когось:
      • побудова НОВОЇ системи (Будівник) — ×3;
      • ПРАВОВА задача — ×2 (рішення Андрія 28.07.2026: «результат юриста
        вартує дорожче»). Правовий запит іде на дорогий мозок (високі ставки)
        і має кола критика; на базовій клієнтській стелі $0.50 така відповідь
        обривалась би на середині — клієнт платив би за пів-відповідь.
    Правова задача визначається ПАСПОРТОМ системи (`_is_legal_system`), а не
    словами моделі: інакше стелю можна було б підняти вмовлянням."""
    cap = getattr(config, "MAX_RUN_USD", 0.0) or 0.0
    if cap <= 0:
        return 0.0
    if meta_mode:
        return cap * META_BUDGET_FACTOR
    return cap * (LEGAL_BUDGET_FACTOR if legal_mode else 1.0)


def _over_cap(cap: float) -> bool:
    """Чи витрачено задану стелю. Окремо від _run_cap, бо клієнт має право
    підняти планку на ЦЕЙ прогін — і тоді діє його число, а не типове."""
    if not cap or cap <= 0:
        return False
    try:
        return float(costs.current_run().get("usd", 0.0)) >= float(cap)
    except Exception:
        return False


def _over_budget(meta_mode: bool = False, legal_mode: bool = False) -> bool:
    """Чи витрачено вже стелю прогону (config.MAX_RUN_USD; 0 = вимкнено)."""
    cap = _run_cap(meta_mode, legal_mode)
    if cap <= 0:
        return False
    try:
        return float(costs.current_run().get("usd", 0.0)) >= cap
    except Exception:
        return False


def _cross_provider_reserve() -> list:
    """⭐ 29.07.2026. ОДИН ПИСАР ПРАВДИ «хто наш резерв».
    Топ-модель кожного провайдера, у якого є ключ. Раніше цей перелік знав лише
    складальник — тому відмова постачальника на ЗВИЧАЙНОМУ кроці валила весь
    прогін, а клієнт бачив сирий текст помилки. Тепер список один, і ним
    користуються обидва (складальник — зі своїми воротами якості, крок — зі
    своїми). Двох писарів однієї правди не заводимо."""
    out = []
    try:
        ks = config.keys_status()
    except Exception:
        ks = {}
    # Спершу хмарні (швидкі, без читання-таймаутів), local — останнім.
    for prov in ("openai", "gemini", "anthropic", "local"):
        if ks.get(prov):
            try:
                m = (config.MODEL_SUGGESTIONS.get(prov) or [None])[0]
                if m and m not in out:
                    out.append(m)
            except Exception:
                pass
    return out


def _assembler_models(high_stakes: bool = False) -> list:
    """Ланцюг моделей складальника. ВАРТІСТЬ: для звичайних задач фінал збирає ДЕШЕВА
    модель (worker), а дорогий мозок — лише резерв. Для високих ставок (право/фінанси/
    стратегія) мозок збирає першим (якість). Далі — топ-моделі інших провайдерів як
    крос-провайдерний резерв (збій одного не валить фінал)."""
    models = []

    def add(m):
        if m and m not in models:
            models.append(m)

    if high_stakes:
        add(config.brain_model())
        add(config.worker_model())
    else:
        add(config.worker_model())
        add(config.brain_model())
    for m in _cross_provider_reserve():
        add(m)
    return models


# ⭐ 05.08.2026 (ланцюги систем). ПОВТОР МУСИТЬ БУТИ ІНШИМ, А НЕ ТИМ САМИМ.
# Андрій: «оркестратор робить по три повтори з однаковим результатом — це
# релейність». Друга спроба кроку ланцюга йде з ПІДНЯТОЮ підлогою драбини:
# дешеві щаблі, які вже не впорались, просто відрізаються знизу.
# Thread-local, бо сервер багатопотоковий: сусідній прогін не має успадкувати
# чужу підлогу.
import threading as _threading
_FLOOR = _threading.local()


def _step_models() -> list:
    """Ланцюг моделей ЗВИЧАЙНОГО кроку конвеєра — це ДРАБИНА `config.model_ladder()`.

    ⭐⭐⭐ 01.08.2026 (рішення власника). Доти тут стояв «крос-провайдерний резерв»
    БЕЗ мозку: якщо дешевий виконавець і топ-моделі інших провайдерів не давали
    результату, прогін помирав — при тому, що НАЙСТАРША модель лежала поруч і
    була доступна. Клієнт платив і не отримував нічого.
    Тепер драбина одна на весь продукт і закінчується найстаршим доступним."""
    ladder = config.model_ladder() or [config.worker_model()]
    floor = getattr(_FLOOR, "model", "") or ""
    if floor and floor in ladder:
        ladder = ladder[ladder.index(floor):]
    return ladder


def _complete_with_reserve(prompt: str, payload: str, max_out: int,
                           emit=None, agent_id: str = "") -> str:
    """⭐ 29.07.2026. ВІДМОВА ОДНОГО ПОСТАЧАЛЬНИКА БІЛЬШЕ НЕ ВАЛИТЬ ПРОГІН.
    Раніше перший же `LLMError` на кроці повертав `runtime_error`, і сирий текст
    помилки (з чужим номером проєкту) їхав аж до очей клієнта.

    Що НЕ перемикаємо навмисне:
      • `LLMNotConfigured` — немає ключа, резерв не допоможе;
      • `BudgetExceeded` — це не аварія, а запобіжник грошей клієнта, у нього
        власний шлях (пауза з вибором). Перемикання тут витратило б гроші саме
        тоді, коли їх наказано не витрачати."""
    chain = [m for m in (_step_models() or []) if m] or [config.worker_model()]
    last = None
    for i, mdl in enumerate(chain):
        try:
            out = llm.complete(prompt, payload, model=mdl, max_tokens=max_out)
        except llm.LLMNotConfigured:
            raise
        except llm.LLMError as e:
            if failure.is_budget(e):
                raise
            last = e
            nxt = chain[i + 1] if i + 1 < len(chain) else None
            failure.log(e, "executor._complete_with_reserve/%s/%s" % (agent_id or "?", mdl))
            _emit(emit, failure.step_notice(agent_id, e, nxt))
            continue
        # ⭐⭐⭐ 01.08.2026 (рішення власника). ПІДНІМАЄМОСЬ І НА ПОРОЖНЕЧУ, А НЕ
        # ЛИШЕ НА АВАРІЮ. Доти драбина оживала тільки на винятку постачальника —
        # а найдорожчий збій виглядав інакше: модель ВІДПОВІДАЛА, але порожнечею
        # або пробільним місивом. Виняток не летів, драбина спала, і прогін
        # помирав `step_no_result` при повністю доступній старшій моделі.
        # «Краще клієнт скаже, що задорого, ніж що заплатив і не отримав нічого.»
        if not _unusable_step(out):
            if i:
                _emit(emit, "✅ %s: результат дала старша модель (%s)." % (agent_id or "крок", mdl))
            return out
        last = llm.LLMError("модель «%s» віддала порожній або вироджений вивід" % mdl)
        nxt = chain[i + 1] if i + 1 < len(chain) else None
        if nxt:
            _emit(emit, "⚠ %s: модель віддала порожнечу — піднімаюсь на старшу (%s)…"
                        % (agent_id or "крок", nxt))
        else:
            _emit(emit, "⚠ %s: порожній вивід, а старших моделей більше немає."
                        % (agent_id or "крок"))
    raise last or llm.LLMError("жоден постачальник не відповів")


def _fallback_plan(system: dict, prompts: dict) -> dict:
    ids = list(prompts["agents"].keys()) or _registry_agent_ids(system)
    critic = next((a for a in ids if _looks_critic(a)), None)
    reviser = next((a for a in reversed(ids) if _looks_reviser(a)), None)
    return {
        "system_understanding": system.get("description", "") or "Послідовний конвеєр агентів.",
        "required_inputs": [],
        "pipeline": [{"agent": a, "purpose": "виконати свій етап", "produces": "",
                      "needs_web_search": _looks_research(a)} for a in ids],
        "quality_loop": {"enabled": bool(critic and reviser), "critic_agent": critic,
                         "reviser_agent": reviser, "pass_threshold": "9/10", "max_iterations": 2},
        "final_deliverable": "Готовий результат системи.",
        "success_criteria": ["Результат не порожній", "Відповідає задачі"],
    }


def _normalize_plan(plan: dict, system: dict, fallback: dict) -> dict:
    if not isinstance(plan, dict):
        return fallback
    valid_ids = set(_registry_agent_ids(system))
    pipeline = plan.get("pipeline") or []
    norm_pipe = []
    for step in pipeline:
        if isinstance(step, dict) and step.get("agent"):
            norm_pipe.append({"agent": step["agent"],
                              "purpose": step.get("purpose", ""),
                              "produces": step.get("produces", ""),
                              "needs_web_search": bool(step.get("needs_web_search", False))})
        elif isinstance(step, str):
            norm_pipe.append({"agent": step, "purpose": "", "produces": "", "needs_web_search": False})
    if not norm_pipe:
        norm_pipe = fallback["pipeline"]
    plan["pipeline"] = norm_pipe
    ql = plan.get("quality_loop") or {}
    plan["quality_loop"] = {
        "enabled": bool(ql.get("enabled")),
        "critic_agent": ql.get("critic_agent"),
        "reviser_agent": ql.get("reviser_agent"),
        "pass_threshold": ql.get("pass_threshold", "9/10"),
        "max_iterations": min(int(ql.get("max_iterations") or 2), HARD_MAX_REVISIONS),
    }
    plan.setdefault("required_inputs", [])
    plan.setdefault("success_criteria", fallback["success_criteria"])
    plan.setdefault("system_understanding", fallback["system_understanding"])
    plan.setdefault("final_deliverable", fallback["final_deliverable"])
    return plan


# ---------------------------------------------------------------------------
# Допоміжне
# ---------------------------------------------------------------------------
def _looks_critic(agent_id: str) -> bool:
    a = (agent_id or "").lower()
    return any(k in a for k in ("critic", "review", "quality", "qa", "верифік", "критик"))


def _unusable_step(text) -> bool:
    """ОДИН ПИСАР «крок не дав результату» (01.08.2026).

    Порожньо АБО місиво. Доти ці два стани жили нарізно: `_degenerate_step`
    ловив лише пробільне місиво (300+ пробілів), а ПОРОЖНІЙ вивід не ловив
    ніхто — він тихо їхав далі, і складальник добудовував пропуск загальними
    словами. Заглушка з пробілів («   ») проходила як результат.
    Короткий, але змістовний вивід — це РЕЗУЛЬТАТ (критик легітимно відповідає
    коротко), тому міряємо не довжину, а наявність змісту."""
    return (not str(text or "").strip()) or _degenerate_step(text)


def _degenerate_step(text: str) -> bool:
    """Пробільна деградація ВИВОДУ КРОКУ (модель зациклилась і ллє пробіли —
    «зависання» договірного прогону 10.07). Ловимо ОДРАЗУ на кроці, а не на межі
    видачі, щоб не палити хвилини й не тягти місиво в наступні кроки.
    Короткі/порожні виводи тут НЕ караємо: критик легітимно відповідає коротко."""
    t = text or ""
    if re.search(r"\s{300,}", t):
        return True
    if len(t) >= 800:
        real = re.sub(r"\s+", "", t)
        if len(real) / len(t) < 0.35:
            return True
    low = t.lower()
    # ВИТІК СИРОГО ВИКЛИКУ ІНСТРУМЕНТА у видимий текст: кодова модель (Kimi-code)
    # без реального каналу пошуку балакає сама з собою й вивалює tool-розмітку
    # замість відповіді (зрив юриста 20.07.2026). У ФІНАЛЬНОМУ виводі такого бути
    # не може — ловимо одразу, не тягнемо місиво у файл.
    if ("<tool>" in low or "</tool>" in low or "<parameter name=" in low
            or "to=default." in low or "\nfunctions." in low):
        return True
    # БАЛАКУЧА ПЕТЛЯ: службові фрази-самокоманди повторюються багато разів
    # («Use web_search… wait for result… Done…»). Легітимний текст їх не множить.
    for _m in ("use web_search", "i need to stop", "wait for result",
               "the tool call", "let's wait", "i will now end", "use tool. done"):
        if low.count(_m) >= 4:
            return True
    return False


def _looks_reviser(agent_id: str) -> bool:
    a = (agent_id or "").lower()
    return any(k in a for k in ("syle", "style", "writ", "edit", "стиль", "редакт", "writer"))


def _looks_research(agent_id: str) -> bool:
    a = (agent_id or "").lower()
    return any(k in a for k in ("research", "search", "data", "news", "market", "trend",
                                "дослід", "пошук", "ринок", "новин", "джерел", "scout", "intel"))


# ---------------------------------------------------------------------------
# КОНТРАКТ НАМІРУ (10.07.2026): мозок раз на задачу декларує, що їй потрібно;
# executor ВИКОНУЄ контракт. Інструмент кроку = перетин «роль вміє (паспорт
# registry.get_roles) І контракт вимагає». Keyword-вгадувачки прибрано повністю.
# ---------------------------------------------------------------------------
_INTENT_OUTPUTS = ("chat_answer", "document", "estimate_sheet", "financial_model", "report")


def _norm_intent(intent) -> dict:
    """Контракт наміру від мозку з захисними дефолтами (консервативно: нічого
    зайвого не вмикаємо; недодеклароване лікує добірка needs_capability)."""
    d = intent if isinstance(intent, dict) else {}
    return {
        "fresh_data": d.get("fresh_data") if d.get("fresh_data") in ("none", "required") else "none",
        "computation": d.get("computation") if d.get("computation") in ("none", "required") else "none",
        "output": d.get("output") if d.get("output") in _INTENT_OUTPUTS else "chat_answer",
    }


def _role_tools(roles: dict, agent_id: str) -> dict:
    return ((roles or {}).get(agent_id) or {}).get("tools") or {}


def _synth_agent_prompt(system: dict, agent_id: str, purpose: str = "") -> str:
    return (f"# {agent_id}\n## РОЛЬ\nАгент «{agent_id}» системи «{system.get('name')}». "
            f"{('Призначення: ' + purpose) if purpose else ''}\n"
            "## ФОРМАТ ВІДПОВІДІ\nMarkdown: статус, дії, результат етапу, відкриті питання.")


def _convo(history) -> str:
    out = ""
    for turn in (history or [])[-6:]:
        role = "Користувач" if turn.get("role") == "user" else "Оркестратор"
        out += f"{role}: {turn.get('content','')}\n"
    return out


def _threshold_value(pass_threshold: str) -> int:
    import re
    m = re.search(r"(\d{1,2})", str(pass_threshold or "9"))
    return int(m.group(1)) if m else 9


def _critic_satisfied(critic_text: str, threshold: int) -> bool:
    import re
    t = (critic_text or "").lower()
    for m in re.findall(r"(\d{1,2})\s*/\s*10", t):
        if int(m) >= threshold:
            return True
    for m in re.findall(r"(\d{1,2})\s*бал", t):
        if int(m) >= threshold:
            return True
    if any(k in t for k in ("готово до публікації", "схвалено", "approved", "без зауважень")):
        return True
    return False


# ---------------------------------------------------------------------------
# Фаза 2: ворота уточнень (за required_inputs з плану + кореневих правил)
# ---------------------------------------------------------------------------
def _gate_degraded_note(reason: str = "") -> str:
    """⭐⭐⭐ 05.08.2026, питання клієнта. Тут стояв НЕРУХОМИЙ текст, який закінчувався
    словами «причина збою записана в журналі платформи». Клієнт прочитав це і спитав:
    «Что это означает? не указал где смотреть данные?» — і мав рацію двічі.
    По-перше, зупинка не називала своєї причини (той самий клас, що й «уточніть
    задачу» замість «вперся у стелю кроків»). По-друге, ми відсилали ЛЮДИНУ в НАШ
    журнал — туди, куди їй ходити не треба й нічим.
    Тепер причину перекладає `failure` — той самий один писар правди «що людина
    бачить, коли зламалось», — а машинний слід і далі лишається в журналі."""
    human = ""
    try:
        human = failure.client_text(RuntimeError(str(reason or "")))
    except Exception:
        human = ""
    # Невпізнану аварію `failure` описує найзагальнішим текстом, який відсилає в
    # журнал платформи. Для КЛІЄНТА це порожній звук: журнал не його інструмент.
    # Не впізнали причину — чесно мовчимо про неї, а не вдаємо пораду.
    if "журнал" in (human or ""):
        human = ""
    return ("> ⚠ **Перевірку «чи вистачає даних» виконати не вдалось.** "
            + ((human.strip() + " ") if human else "")
            + "Щоб цей збій не забрав у вас роботу, я працював з тим, що було в запиті. "
              "Якщо якихось даних бракувало, я міг ужити розумні припущення — "
              "перевірте, будь ласка, цифри й факти перед використанням.\n\n---\n\n")


def _gate_must_be_strict(system: dict, intent: dict) -> bool:
    """ДЕ ЦІНА ПОМИЛКИ НЕПРИЙНЯТНА — там закриті ворота лишаються.

    ⭐⭐⭐ 01.08.2026, живий випадок у клієнта. Запобіжник 30.07 мав рацію в
    головному («не зміг перевірити» ≠ «перевірив, усе гаразд»), але міряв УСЕ
    однією суворістю. Через це збій дешевої моделі зачиняв двері перед будь-якою
    роботою — навіть там, де найгіршим наслідком було б «текст треба трохи
    правити». Реальний запит клієнта загинув на порозі двічі.

    Суворо (чесний стоп) — там, де помилка коштує грошей або права: правова
    система, числова задача, фінмодель, кошторис. Решта — працюємо і ПИШЕМО
    правду про невиконану перевірку [[_gate_degraded_note]].
    """
    if _is_legal_system(system):
        return True
    i = intent or {}
    if i.get("computation") == "required":
        return True
    if i.get("output") in ("financial_model", "estimate_sheet"):
        return True
    return False


# ⭐⭐⭐ 09.08.2026. ОДИН ПИСАР ПРАВДИ ПРО МОЖЛИВОСТI ПЛАТФОРМИ.
# 🩸 Два платнi прогони Андрiя провалились одне за одним, бо про живий веб не знав
# то мозок (вiдмовив вiд iменi системи), то КОНТРОЛЕР УТОЧНЕНЬ (зупинив систему ДО
# роботи й попросив принести резюме). Кожен виправлявся окремо — i це була латка.
# КЛАС: будь-який промпт, де модель говорить ВIД IМЕНI ПЛАТФОРМИ, мусить знати межi
# платформи. Текст живе в ОДНОМУ мiсцi й пiдкладається в УСI такi промпти.
def platform_reach_note() -> str:
    """Правда про доступ платформи до свiту — для КОЖНОГО промпта, де модель
    говорить вiд її iменi. Порожньо, якщо вебу справдi немає (не вчимо брехати)."""
    try:
        if not config.web_search_ready():
            return ""
    except Exception:
        return ""
    return (
        "\n\nМОЖЛИВОСТI ЦIЄЇ ПЛАТФОРМИ (факт, не припущення): вона МАЄ живий "
        "інтернет — сама шукає в мережі і ВІДКРИВАЄ знайдені сторінки, працюючи з "
        "їхнім справжнім текстом (вакансії, резюме, оголошення, ціни, новини, "
        "чинні норми, вміст конкретного сайту). "
        "ТОМУ: НЕ пиши, що не маєш доступу до інтернету чи до зовнішніх платформ; "
        "НЕ проси користувача принести дані, які можна знайти в мережі; "
        "НЕ зупиняй роботу через брак таких даних. "
        "Питай користувача ЛИШЕ про те, чого в мережі немає: його внутрішні файли "
        "й документи, приватні дані, особисті вподобання, рішення та пріоритети.\n"
    )


def precheck_inputs(system: dict, plan: dict, task: str, files_context: str, history,
                    needs_calc: bool = False) -> dict:
    required = plan.get("required_inputs") or []
    root_prompt = _system_root_prompt(system)
    calc = bool(needs_calc)  # з контракту наміру (мозок), не з keyword-здогадок
    if not required and not root_prompt and not calc:
        return {"ready": True}
    controller = (
        "Ти — оркестратор системи. Твоя мета — ВИКОНАТИ задачу, а не допитувати користувача. "
        f"Бажані (не обовʼязкові) вхідні дані за логікою системи: {json.dumps(required, ensure_ascii=False)}.\n"
        + (f"Кореневі правила (орієнтир, НЕ привід для допиту):\n{root_prompt[:2500]}\n" if root_prompt else "")
        + "ПРАВИЛО (важливо): запитуй ЛИШЕ тоді, коли без даних результат буде ПРИНЦИПОВО "
        "неправильним або неможливим (немає обовʼязкового файлу/документа, незрозумілий сам "
        "предмет задачі, відсутні критичні для безпеки/права дані). Якщо тему, аудиторію, мету, "
        "мову чи формат уже видно з запиту АБО їх можна розумно припустити — став ready=true і "
        "НЕ питай. Дрібниці (нюанс теми, хештеги, зображення, стиль оформлення) НЕ питай — "
        "приймай розумні припущення сам. За замовчуванням схиляйся до ready=true. "
        + ("\nФІНАНСОВИЙ ВИНЯТОК (це числова/фінансова задача, тут помилятись НЕ МОЖНА): "
           "критичні параметри розрахунку — відсоткова ставка; дата видачі/першого платежу "
           "(якщо в результаті є дати); комісії, страховки та інші додаткові збори. Якщо "
           "якогось із них НЕМАЄ в запиті і він впливає на числа — постав ready=false і спитай "
           "ЛИШЕ відсутні критичні параметри, одним повідомленням, максимум 3 питання. Якщо "
           "користувач уже відповів на це раніше в діалозі — НЕ перепитуй. " if calc else "")
        + "\nВИНЯТОК ОБСЯГУ (щоб не видати частину за ціле): якщо задача просить охопити "
          "БАГАТО одиниць одразу («весь сайт», «усі сторінки», «усі розділи», «кожен …», "
          "«усе одразу»), а якісний результат за один прохід реальний лише для ОДНІЄЇ "
          "одиниці — постав ready=false і ОДНИМ повідомленням спитай, чи робити по черзі "
          "та з якої одиниці почати. Якщо користувач уже назвав конкретну одиницю (одну "
          "сторінку/розділ) АБО обсяг реально посильний за прохід — ready=true, не питай. "
          "Ніколи не звужуй масовий запит мовчки й не видавай одну одиницю за все. "
        + platform_reach_note()
        + 'Поверни JSON: {"ready": true|false, "questions": ["1-2 КРИТИЧНІ питання лише якщо справді блокують"]}.'
    )
    user = f"## ЗАДАЧА\n{task}\n\n## ДІАЛОГ\n{_convo(history)}\n" + (
        f"## ФАЙЛИ\n{files_context}\n" if files_context else "")
    try:
        d = llm.judge_json(controller, user, temperature=0.1, model=config.worker_model(),
                           purpose="достатність вхідних даних")
    except llm.LLMError as e:
        # ⛔ 30.07.2026. Тут стояло `return {"ready": True}` — тобто збій моделі
        # оголошував, що ВХІДНИХ ДАНИХ ВИСТАЧАЄ. Це та сама хвороба, що й у
        # контролі якості: перевірка, яка при збої каже «чисто», — це відсутня
        # перевірка. Тепер збій називає себе, а рішення ухвалює виклик.
        # ⛔ «НЕ ЗМІГ ПЕРЕВІРИТИ» ≠ «ПЕРЕВІРИВ, УСЕ ГАРАЗД».
        return {"ready": False, "checked": False, "error": e, "questions": []}
    # Питання без тексту — це не питання: контролер сказав «не готово», але не
    # назвав чого бракує. Такий стан НЕ має права стати мовчазним «готово» вище
    # по течії, тому нижче він теж лишається «не перевірено».
    qs = [q for q in (d.get("questions") or []) if (q or "").strip()][:4]
    if not d.get("ready") and qs:
        return {"ready": False, "checked": True, "questions": qs}
    if not d.get("ready"):
        return {"ready": False, "checked": False, "questions": [],
                "error": "контролер сказав «даних не вистачає», але не назвав, яких саме"}
    return {"ready": True, "checked": True}


# ---------------------------------------------------------------------------
# «Жодних чисел з голови»: ЧИ потрібен калькулятор — вирішує КОНТРАКТ НАМІРУ
# від мозку (intent.computation), а КОМУ він дістається — паспорт ролей системи.
# Колишні keyword-вгадувачки (_needs_calc + 4 словники + виняток договорів)
# прибрано повністю 10.07.2026 — див. DESIGN_Контракт_наміру.md.
# ---------------------------------------------------------------------------


_CALC_TOOL = [{
    "name": "run_python",
    "description": ("Калькулятор: виконати короткий Python-код в ізольованому середовищі "
                    "і отримати надруковані (print) результати. Усі обчислювані числа твоєї "
                    "відповіді мають походити звідси."),
    "parameters": {"type": "object", "properties": {
        "code": {"type": "string", "description":
                 "Python-код; усі потрібні значення надрукуй через print() з підписами"}},
        "required": ["code"]},
}]
_CALC_MAX_TURNS = 8  # стеля ходів tool-циклу одного агента (вартість/зациклення)
_CALC_FASTFAIL_TURNS = 3  # А+ (баг №4 16.07): дешевій моделі даємо лише кілька ходів
                          # (фейл-фаст), тоді одразу надійна — не крутимо 8 ходів упусту


def _calc_fallback_model() -> str:
    """Модель ДРУГОЇ спроби розрахункового кроку. Слабкий виконавець (gemini-flash)
    на великих запитах повертає порожні tool-ходи — надійний шлях tool-викликів
    доведений на Anthropic (мозок 🧮 працює щопрогону). Дорожче, але лише для
    числових кроків, де помилятись не можна."""
    return config.reliable_model()


def _run_agent_calc(agent_prompt: str, payload: str, emit=None, agent_id="", model: str = None,
                    max_turns: int = _CALC_MAX_TURNS):
    """Крок агента з калькулятором: tool-цикл до фінального тексту.
    Повертає (text, reason): текст або "", і людську причину, чому текст
    порожній — викликач робить fallback і ПОКАЗУЄ причину (не ковтає).
    max_turns — стеля ходів саме цієї спроби (А+: дешева модель = фейл-фаст)."""
    messages = [{"role": "user", "content": payload}]
    for _ in range(max_turns):
        turn = llmtools.tool_turn(agent_prompt, messages, _CALC_TOOL,
                                  model=model or config.worker_model(),
                                  max_tokens=config.CALC_TURN_MAX_TOKENS)
        calls = turn.get("tool_calls") or []
        if not calls:
            text = turn.get("text") or ""
            if text.strip():
                return text, ""
            return "", "модель повернула порожню відповідь без виклику калькулятора"
        messages.append({"role": "assistant", "content": turn.get("text") or "",
                         "tool_calls": calls})
        for tc in calls:
            _emit(emit, f"🧮 {agent_id}: розрахунок калькулятором…")
            r = tools.run_python((tc.get("args") or {}).get("code", ""))
            content = ("Результат обчислення (stdout):\n" + r.get("stdout", "")) if r.get("ok") \
                else (f"Калькулятор НЕ виконав код: {r.get('note','')}. Виправ код і повтори; "
                      "числа без розрахунку не наводь.")
            messages.append({"role": "tool", "tool_call_id": tc.get("id"),
                             "name": "run_python", "content": content})
    return "", f"вичерпано стелю {max_turns} ходів tool-циклу без фінальної відповіді"


# ---------------------------------------------------------------------------
# Фаза 3-4: виконання за планом + цикл якості
# ---------------------------------------------------------------------------
def _run_agent(system, step, idx, total, plan, task, convo, files_context, accumulated,
               live_data="", style="", use_calc=False, emit=None, seo_page="",
               offer_capability=False, legal_note="", offer_web=False):
    # legal_note (30.07.2026): готовий блок про ВСТАНОВЛЕНИЙ РЕЖИМ ПРОЦЕДУРИ від
    # правового ядра. Складає його run_system ОДИН раз на прогін — тут ми лише
    # кладемо його в payload перед запитом користувача. Навіщо: раніше режим
    # знало тільки ядро на виході, агент його не бачив і називав свій.
    agent_id = step["agent"]
    prompt = _load_agent_prompt(system, agent_id) or _synth_agent_prompt(system, agent_id, step.get("purpose", ""))
    kb = knowledge.load_relevant(system, task)
    # БУДІВНИК: його агенти носять повні промпти/структуру майбутньої системи —
    # їм потрібні вища стеля виводу і ширше вікно попередніх етапів (план Аналітика
    # не має обрізатися хвостом у Структуролога).
    _is_builder = (system or {}).get("id") == "system_builder"
    # SEO/GEO-крок із реальною сторінкою (seo_page присутній) пише повний план —
    # даємо довший ліміт, щоб чернетка не рвалась (важкий JSON уже в матеріалізаторі).
    _is_long_seo = bool(seo_page)
    _max_out = (config.BUILDER_MAX_TOKENS if _is_builder
                else config.AGENT_MAX_TOKENS_LONG if _is_long_seo
                else config.AGENT_MAX_TOKENS)
    _acc_win = 24000 if _is_builder else 8000
    payload = (
        (f"## {style}\n\n" if style else "")
        + (f"## ПРАВИЛО ЧИСЕЛ (обовʼязкове)\n{config.CALC_NOTE}\n\n" if use_calc else "")
        # ЧЕСНА ДОБІРКА (контракт наміру): без калькулятора агент не рахує «в умі» —
        # він чесно сигналить, і мозок перезапустить прогін із розширеним контрактом.
        + ("## ЯКЩО БРАКУЄ КАЛЬКУЛЯТОРА\nЦьому прогону НЕ видано калькулятор. Якщо для "
           "якісного результату справді ПОТРІБНІ точні обчислення (не груба прикидка "
           "і не переписування готових чисел) — НЕ рахуй в умі: виведи окремим рядком "
           "`NEEDS_CAPABILITY: calculator` і зупинись.\n\n"
           if (offer_capability and not use_calc) else "")
        # ⭐⭐⭐ 09.08.2026. ЧЕСНА ДОБIРКА ЖИВИХ ДАНИХ (дзеркало калькулятора).
        # КОРIНЬ: коли контракт намiру не вимагав свiжих даних, вебу крок не
        # дiставав - i агент вiдповiдав З ПАМʼЯТI МОДЕЛI або казав «не маю
        # доступу до інтернету». Саме це почув клiєнт вiд рекрутингової системи.
        # ⭐ ПЛАТФОРМА, ЯКА ВМIЄ, НЕ СМIЄ КАЗАТИ, ЩО НЕ ВМIЄ: замiсть вiдмови
        # агент СИГНАЛИТЬ, i мозок робить ОДИН перезапуск iз живим вебом.
        # Ворота структурнi: показуємо блок лише тодi, коли живих даних НЕМАЄ,
        # а веб у платформи Є. Жодного вгадування за словами запиту.
        + (platform_reach_note() + "\n## ЯКЩО БРАКУЄ ЖИВИХ ДАНИХ З ІНТЕРНЕТУ\nЦьому кроку НЕ передано живих "
           "даних з вебу. Якщо чесна відповідь на запит НЕМОЖЛИВА без актуальних "
           "зовнішніх даних (свіжі ціни, вакансії, резюме, оголошення, новини, "
           "чинна редакція норм, вміст конкретного сайту) — НЕ відповідай з пам'яті "
           "й НЕ пиши, що не маєш доступу до інтернету: у цієї платформи живий веб Є. "
           "Виведи окремим рядком `NEEDS_CAPABILITY: web` і зупинись — платформа "
           "перезапустить крок уже з живими даними.\nЯкщо ж задачу можна виконати "
           "коректно на наданих матеріалах — просто виконуй її.\n\n"
           if offer_web else "")
        + f"## ЗАГАЛЬНА ЛОГІКА СИСТЕМИ\n{plan.get('system_understanding','')}\n\n"
        + (f"## БАЗА ЗНАНЬ СИСТЕМИ (довідка — застосовуй доречні фреймворки/норми, не вивалюй усе)\n{kb}\n\n" if kb else "")
        # Режим процедури — ФАКТ від ядра, і агент має бачити його ДО запиту.
        + (f"{legal_note}\n\n" if legal_note else "")
        + f"## ЗАПИТ КОРИСТУВАЧА\n{task}\n\n"
        + (f"{seo_page[:16000]}\n\n" if seo_page else "")
        + (f"## КОНТЕКСТ ДІАЛОГУ\n{convo}\n" if convo else "")
        + (f"## ДОДАНІ ФАЙЛИ\n{files_context[-8000:]}\n\n" if files_context else "")
        + (f"## ЖИВІ ДАНІ З ВЕБ-ПОШУКУ (спирайся на них і на джерела)\n{live_data[-LIVE_DATA_WINDOW:]}\n\n" if live_data else "")
        + (f"## РЕЗУЛЬТАТИ ПОПЕРЕДНІХ АГЕНТІВ\n{accumulated[-_acc_win:]}\n\n" if accumulated else "")
        + f"## ТВІЙ КРОК ({idx}/{total})\nПризначення: {step.get('purpose','виконати свій етап')}.\n"
        + (f"Очікуваний результат кроку: {step.get('produces','')}\n" if step.get("produces") else "")
        + "Виконай свій етап згідно своєї ролі. Будь змістовним, але стислим — "
          "пиши по суті, без зайвої багатослівності.\n\n" + _ART
    )
    if use_calc:
        reason = ""
        fb = _calc_fallback_model()
        # А+ (баг №4 16.07): дешева модель ПЕРШОЮ, але лише «фейл-фаст» (кілька ходів) —
        # прості розрахунки лишаються дешевими; складні/зациклені швидко (не через 8
        # марних ходів) передаються надійній моделі з ПОВНОЮ стелею. Раніше було
        # 8 ходів дешевої (переважно приречених) + 8 надійної = подвійна витрата й
        # 10-хв зависання. Немає надійної (нема ключа) → як було: сама дешева, повна стеля.
        _reliable = fb if fb != config.worker_model() else None
        if _reliable:
            attempts = [(config.worker_model(), _CALC_FASTFAIL_TURNS), (_reliable, _CALC_MAX_TURNS)]
        else:
            attempts = [(config.worker_model(), _CALC_MAX_TURNS)]
        for attempt, (mdl, mt) in enumerate(attempts, 1):
            try:
                out, reason = _run_agent_calc(prompt, payload, emit=emit, agent_id=agent_id,
                                              model=mdl, max_turns=mt)
                if out and out.strip():
                    if attempt > 1:
                        _emit(emit, f"✓ {agent_id}: розрахунковий крок виконано надійною моделлю ({mdl}).")
                    return out
            except llm.LLMNotConfigured as e:
                reason = f"{type(e).__name__}: {e}"
                break  # немає ключа — повтор не допоможе
            except llm.LLMError as e:
                reason = f"{type(e).__name__}: {e}"
            if attempt < len(attempts):
                _emit(emit, f"🔁 {agent_id}: дешева модель не впоралась за {_CALC_FASTFAIL_TURNS} ход. "
                            f"({(reason or '?')[:100]}) — передаю надійній моделі ({attempts[attempt][0]})…")
        # Причину НЕ ковтаємо: коротко — у прогрес користувачу, повністю — у консоль.
        llm._log(f"[executor] {agent_id}: калькулятор недоступний — {reason or 'причина невідома'}")
        _emit(emit, f"⚠ {agent_id}: калькулятор недоступний ({(reason or 'причина невідома')[:160]}) — "
                    "виконую без нього (числа позначаться як неперевірені)")
    return _complete_with_reserve(prompt, payload, _max_out, emit=emit, agent_id=agent_id)


def _fix_xlsxmodel(final_markdown: str, task: str, emit=None, wants_excel: bool = False) -> str:
    """Ворота якості Excel-моделі після складальника. Чи ПОТРІБНА повноцінна модель
    із формулами — каже КОНТРАКТ НАМІРУ (wants_excel = output=="financial_model"),
    а не слова в задачі: груба оцінка ≠ фінмодель. Невалідний блок ```xlsxmodel →
    до 2 повернень моделі на виправлення з ТОЧНОЮ помилкою формату. Остаточний
    провал → чесна позначка в результаті + слід у консолі."""
    import artifacts
    ok, err = artifacts.check_xlsxmodel(final_markdown, require_live=wants_excel)
    if ok:
        return final_markdown, None
    has_block = "немає блоку" not in err
    if not has_block and not wants_excel:
        return final_markdown, None  # Excel не просили і блоку немає — все гаразд
    fence_re = artifacts._XLSXMODEL_FENCE_RE
    corrector_sys = (
        "Ти — коректор формату Excel-моделі. Поверни ЛИШЕ ОДИН блок ```xlsxmodel "
        "(нічого більше: без пояснень, без markdown навколо), який ТОЧНО відповідає "
        "шаблону нижче. ОДИН лист. Вхідні значення — у params, розрахунки — ЖИВИМИ "
        "формулами Excel через плейсхолдери.\n\n## " + config.XLSX_MODEL_NOTE)
    for attempt in (1, 2):
        _emit(emit, f"🛠 Excel-модель: {err} — повертаю на виправлення (спроба {attempt}/2)…")
        old = fence_re.search(final_markdown)
        corrector_user = (
            f"## ПОМИЛКА ФОРМАТУ (виправ саме це)\n{err}\n\n"
            f"## ЗАДАЧА КОРИСТУВАЧА\n{task}\n\n"
            + (f"## ПОПЕРЕДНІЙ (НЕВАЛІДНИЙ) БЛОК\n```xlsxmodel\n{old.group(1)[:6000]}\n```\n\n" if old else "")
            + f"## ФІНАЛЬНИЙ ТЕКСТ (джерело параметрів і структури таблиці)\n{final_markdown[:6000]}")
        try:
            # ⭐ 31.07.2026. КОРЕКТОР ІДЕ НА МОЗОК, А НЕ НА НАЙДЕШЕВШОГО ВИКОНАВЦЯ.
            # Йому доручено видати СУВОРУ JSON-спеку з живими формулами — найважчу
            # частину ланцюга. На flash-моделі вона сипалась стабільно (прогін
            # 10:06 31.07: два кола ремонту, обидва загубили columns).
            fixed = llm.complete(corrector_sys, corrector_user,
                                 model=(config.brain_model() if wants_excel
                                        else config.worker_model()),
                                 max_tokens=config.ASSEMBLER_MAX_TOKENS)
        except llm.LLMError as e:
            err = f"коректор не відповів ({e})"
            continue
        m2 = fence_re.search(fixed or "")
        # ⭐⭐⭐ 31.07.2026. РЕМОНТ ЛАТАЄ, А НЕ ПЕРЕПИСУЄ.
        # Коректор генерував блок НАНОВО і губив поля, які були правильні
        # (оригінал мав columns — у «виправленні» їх не стало, і клієнт лишався
        # без файла: прогін 10:06). Накладаємо його відповідь на СТАРУ спеку —
        # чого він не повернув, беремо з оригіналу. Без жодного виклику моделі.
        cand = f"```xlsxmodel\n{m2.group(1).strip()}\n```" if m2 else ""
        if cand and old:
            try:
                import json as _json
                _new = _json.loads(m2.group(1).strip())
                _base = _json.loads(old.group(1).strip())
                if isinstance(_new, dict) and isinstance(_base, dict) \
                        and not _new.get("sheets") and not _base.get("sheets"):
                    _merged = dict(_base)
                    _merged.update({k: v for k, v in _new.items() if v not in (None, "", [], {})})
                    # Рядки-розрахунки заміняє ЛИШЕ коректор: якщо він їх не дав,
                    # старі МЕРТВІ рядки не тягнемо — інакше ворота впадуть знову.
                    for _k in ("rows", "first_row", "row_template", "row_count", "totals"):
                        _merged.pop(_k, None)
                        if _k in _new:
                            _merged[_k] = _new[_k]
                    cand = "```xlsxmodel\n" + _json.dumps(_merged, ensure_ascii=False) + "\n```"
            except Exception:
                pass
        if cand:
            # підставляємо виправлений блок у фінал (замість старого або в кінець)
            new_md = fence_re.sub(lambda _m: cand, final_markdown, count=1) if old \
                else final_markdown + "\n\n" + cand
            ok2, err2 = artifacts.check_xlsxmodel(new_md, require_live=wants_excel)
            if ok2:
                _emit(emit, "✓ Excel-модель виправлено — файл збереться з живими формулами.")
                return new_md, None
            err = err2
        else:
            err = "коректор не повернув блок ```xlsxmodel"
    llm._log(f"[executor] Excel-модель не зібралась після 2 виправлень: {err}")
    # ⭐⭐⭐ 31.07.2026. ЖОРСТКІСТЬ — ЛИШЕ ТАМ, ДЕ ЇЇ ЗАМОВЛЯЛИ.
    # Fail-closed (стоп замість файла-обманки) — це рішення для ФІНМОДЕЛІ: там
    # мертва книга гірша за відсутню. Але та сама гілка вбивала б БУДЬ-ЯКИЙ інший
    # прогін, який випадково віддав службовий блок: клієнт лишався б без усієї
    # роботи через один нескладений файл. Якщо контракт наміру не просив
    # фінмоделі — прибираємо тільки блок і віддаємо текст, як було до воріт.
    if not wants_excel:
        _emit(emit, "⚠ Excel-модель не зібралась — віддаю результат текстом (файла моделі не буде).")
        return artifacts.strip_service_blocks(fence_re.sub("", final_markdown or "")).strip(), None
    _emit(emit, "⚠ Жива Excel-модель не зібралась поточною моделлю — потрібен потужніший "
                "мозок (Claude Opus / OpenAI). Переключіть і повторіть.")
    reason = f"жива Excel-модель з формулами не зібралась поточною моделлю ({err})"
    action = ("переключіть мозок системи на Claude Opus або OpenAI (GPT) і повторіть запит — "
              "тоді Excel збереться з живими формулами")
    honest_md = (
        "🛑 **Живу Excel-модель з формулами зібрати не вдалося.**\n\n"
        f"**Причина:** жива Excel-модель з формулами не зібралась поточною моделлю ({err}).\n\n"
        "**Що зробити:** переключіть мозок системи на **Claude Opus** або **OpenAI (GPT)** "
        "і повторіть запит — тоді Excel збереться з живими формулами.\n\n"
        "*(Якщо підключено лише Gemini — додайте ключ Anthropic або OpenAI у налаштуваннях.)*")
    return honest_md, {"kind": "financial_model", "reason": reason, "action": action}


# ---------------------------------------------------------------------------
# ⭐⭐⭐ 01.08.2026. РЕЄСТР ЗУПИНОК — ЖОДНІ ВОРОТА НЕ МОЖУТЬ ЗАЧИНИТИСЬ МОВЧКИ.
#
# Питання власника (01.08.2026): «а потім користувач вигадає ще щось, і ми знову
# упремося, бо Оркестратор заплутається у воротах і зупиниться?» Порахував по
# коду: місць, де платформа може не віддати результат, близько двадцяти, і про
# СТАВКИ питало рівно одне з них — те, що полагодили того ранку.
#
# Тому право зупинитись стало ДАНИМИ. Кожна зупинка оголошує свою ставку:
#   "fatal"       — без цього результат був би НЕПРАВДОЮ (право, реальний
#                   маршрут, прочитана сторінка, жива Excel-модель). Стіна тут
#                   доречна: краще нічого, ніж вигадка.
#   "degradable"  — зупинка НЕ обовʼязкова: працюємо і чесно кажемо про межу.
#   "after_ladder"— зупинятись можна ЛИШЕ коли вичерпано драбину моделей
#                   (`config.model_ladder`), тобто використано ВСІ наявні
#                   ресурси, включно з найстаршою моделлю.
#
# Нова зупинка без запису тут завалює `stop_register_test`: домовленість на
# словах не тримає — тримає чек.
# ---------------------------------------------------------------------------
STOP_REGISTER = {
    "tender_pack_no_docs": {
        "stakes": "fatal",
        "why": "пакет документів для подачі на закупівлю без оголошення замовника — "
               "це папір, який не спирається ні на що: 05.08.2026 такий пакет уже "
               "поїхав клієнту від системи, що не бачила жодного документа"},
    "precheck_impossible": {
        "stakes": "degradable",
        "why": "перевірка достатності даних — помічник, а не привід не працювати; "
               "суворо лише там, де помилка коштує грошей або права"},
    "seo_page_unread": {
        "stakes": "fatal",
        "why": "аудит сторінки, якої не прочитали, був би вигадкою про чужий сайт"},
    "route_not_built": {
        "stakes": "fatal",
        "why": "маршрут без реального шляху з двигуна — це вигадані відстані й час"},
    "live_check_impossible": {
        "stakes": "fatal",
        "why": "правова роль зобовʼязана звірити норму з першоджерелом наживо"},
    "step_no_result": {
        "stakes": "after_ladder",
        "why": "етап не дав нічого — зупинка законна ЛИШЕ після підйому по всій "
               "драбині моделей, включно з найстаршою доступною"},
    "financial_model": {
        "stakes": "fatal",
        "why": "мертва книга без живих формул — це не фінмодель, а картинка чисел"},
    "access_denied": {
        "stakes": "fatal",
        "why": "робота, запущена від нікого або від людини без права на цю систему, "
               "не має господаря: за неї ніхто не відповідає, а платить власник"},
    "subscription_expired": {
        "stakes": "fatal",
        "why": "модель «тільки абонплата» обіцяє клієнту, що після строку користування "
               "припиняється; платформа, яка працює далі, робить із договору неправду"},
}


def stop_stakes(kind: str) -> str:
    """Ставка цієї зупинки. Незареєстрована — «unknown»: її ловить чек."""
    return (STOP_REGISTER.get(kind or "") or {}).get("stakes", "unknown")


def honest_stop_result(system, *, kind: str, reason: str, action: str, markdown: str,
                       intent=None, plan=None, trace=None, route_engine=None,
                       seo_read=None, conditions=None, web_invariant_gap: str = "") -> dict:
    """ОДНІ ДВЕРІ СВІДОМОЇ ЗУПИНКИ (30.07.2026, Правило №15).

    НАВІЩО. До цього «чесний стоп» умів говорити ДВОМА мовами: або поле
    `honest_stop` (шлях фінмоделі), або просто `status="completed"` з чесним
    текстом усередині (SEO, маршрут, жива звірка). Друга мова обходила гарантію
    `agent._finalize_honest_stop` — і клієнт отримував .docx/.md із текстом
    «не можу зробити», записаний у прогін як завершена робота.

    ⛔ ЗУПИНКА, ЯКА НАЗИВАЄ СЕБЕ ЗАВЕРШЕННЯМ, — ЦЕ ДРУГА ПРАВДА.

    Тепер мова ОДНА: `status="honest_stop"` + пояснення {kind, reason, action}.
    Ніхто нижче по течії не мусить упізнавати стоп за словами в тексті —
    він названий статусом. Ворота `honesty_test.py` забороняють ранній
    `return {"status": "completed", ...}` у `run_system`, тому МАЙБУТНІЙ стоп
    фізично не зможе прикинутись завершеною роботою.
    """
    audit.log_refusal("honest_stop:%s" % kind, (system or {}).get("id"), [],
                      "%s | ставка: %s" % (reason, stop_stakes(kind)))
    return {
        "status": "honest_stop",
        "final_markdown": markdown,
        "assembler_ok": True,
        "honest_stop": {"kind": kind, "reason": reason, "action": action,
                        "stakes": stop_stakes(kind)},
        "agent_trace": list(trace or []),
        "system_id": (system or {}).get("id"),
        "needs_calc": False,
        "intent": intent,
        "revisions": 0,
        "understanding": (plan or {}).get("system_understanding", ""),
        # свідомий стоп — це НЕ «неповний звіт»: критеріїв успіху не оцінюємо,
        # джерел не заявляємо (їх не було).
        "success_criteria": [],
        "sources": [],
        "web_invariant_gap": web_invariant_gap,
        "route_engine": route_engine,
        "conditions": conditions,
        "seo_read": seo_read,
        "mode": (system or {}).get("orchestration_mode", "sequential"),
    }


def _is_legal_system(system) -> bool:
    blob = ((system or {}).get("id", "") + (system or {}).get("category", "")
            + (system or {}).get("name", "")).lower()
    return any(k in blob for k in ("legal", "юрист", "юридич", "прав"))


# Невидима позначка «правові ворота відпрацювали чисто» — її читає agent.py, щоб
# не чіпляти зверху попередження «не пройшов перевірку якості»: причини для нього
# вже немає, а клієнт бачить лише лякалку. У текст для людини не потрапляє.
LEGAL_CLEAN_MARK = "\u2063sf-legal-clean\u2063"


def _clean_for_human(text: str) -> str:
    """Прибирає службові позначки й лишає позначку «чисто» для agent.py."""
    try:
        import tender_legal as _tl
        text = (text or "").replace(_tl.REGIME_MARK, "").replace("\n\n\n", "\n\n")
    except Exception:
        pass
    return LEGAL_CLEAN_MARK + text.strip()


_ANSWER_TAIL = ("Надішліть номер у форматі UA-РРРР-ММ-ДД-XXXXXX-x — і ви отримаєте "
                "норми саме вашої процедури: строки, підстави та дослівні цитати "
                "із чинного законодавства.")


# ---------------------------------------------------------------------------
# ОДИН ПИСАР РЕЖИМУ ПРОЦЕДУРИ (30.07.2026)
# ---------------------------------------------------------------------------
# Що сталося: 30.07 клієнт отримав документ, де ядро надрукувало «спрощена
# закупівля оборонного замовника» (ст. 14 Закону 922 + п. 8 ПКМУ 1275), а модель
# у ТОМУ Ж документі написала «швидше за все — відкриті торги з особливостями
# (ПКМУ 1178)» і побудувала на цьому весь перелік документів. Дві правди в
# одному документі. Корінь: режим знало тільки ядро на виході, агент його не
# бачив, а перевірка на виході звіряла лише ЧИСЛА днів і була сліпа до НАЗВИ.
# Лікування — нижче: режим резолвиться РАЗ на прогін, їде агенту як факт, і та
# сама позиція (не друга резолюція!) працює на воротах виходу.


def _resolve_legal_pos(task: str = "", history=None) -> dict:
    """Резолвить правову позицію по тендеру ОДИН раз на прогін.

    Повертає {"ctx": …, "brief": …}:
      ctx   — рішення ЄДИНОГО резолвера тендера (`tender_context.resolve`):
              який саме тендер мається на увазі, коли в питанні номера немає;
      brief — правова позиція ядра (`tender_legal.brief`): режим, норми, текст.
    Обидва можуть бути None — це нормально і означає «ядро мовчить».
    """
    ctx = None
    try:
        import tender_context as _tc
        ctx = _tc.resolve(task or "", history)
    except Exception as e:
        llm._log(f"[executor] резолвер тендера зірвався: {e}")
    brief = None
    try:
        import tender_context as _tc2
        import tender_legal as _tl
        _tid = (ctx or {}).get("tender_id") or ""
        brief = _tl.brief(task or "", tender_id=_tid or None,
                          from_thread=bool(ctx) and _tc2.from_thread(ctx)) if _tid else None
    except Exception as e:
        llm._log(f"[executor] правові ворота зірвались: {e}")
    return {"ctx": ctx, "brief": brief}


def _legal_regime_block(legal_pos: dict) -> str:
    """Блок про режим процедури для payload агента.

    Ядро режим ВСТАНОВИЛО -> віддаємо його як ФАКТ і прямо забороняємо називати
    інший. Ядро мовчить -> блоку немає взагалі (мовчання краще за вигадку), лише
    один рядок-застереження, щоб агент не вигадував режим сам.
    """
    brief = (legal_pos or {}).get("brief") or None
    pos = (brief or {}).get("pos") or {}
    if not (brief and brief.get("ok") and pos.get("label")):
        return ("Режим процедури НЕ встановлено ядром — не називай його як факт; "
                "якщо він потрібен для відповіді, скажи, що бракує даних.")
    return (
        "## ВСТАНОВЛЕНИЙ РЕЖИМ ПРОЦЕДУРИ (визначено правовим ядром із картки "
        "Прозорро — це ФАКТ, не припущення)\n"
        "Тендер: %s. Режим: %s. Правова основа: %s.\n"
        "⛔ Тобі ЗАБОРОНЕНО називати іншу процедуру, іншу постанову чи інший закон "
        "як підставу.\n"
        "Якщо здається, що режим інший — так і напиши окремим рядком, але НЕ будуй "
        "на цьому перелік документів і план дій.\n\n"
        # ⭐⭐⭐ 30.07.2026 (зміна 35). ЗВІРЕНІ НОРМИ ЇДУТЬ РАЗОМ ІЗ РЕЖИМОМ.
        # Промпт тендерного юриста ставить умову: строк називати ЛИШЕ якщо режим є
        # у файлі `Database/Wiki/ТЕНДЕРНІ_НОРМИ_звірені.md`. А цей файл до нього
        # НЕ ДОЇЖДЖАВ: платформа шукає базу знань у теці `Knowledge`, якої в цій
        # системі немає. Отже агент за власним правилом мусив мовчати — і мовчав.
        # Даємо йому ті самі норми з ПЕРШОДЖЕРЕЛА (`regimes.json`, з якого той
        # файл і генерується): один писар, без залежності від назви теки.
        "## ЗВІРЕНІ НОРМИ ЦІЄЇ ПРОЦЕДУРИ (це і є вміст бази норм — той самий, що у "
        "`Database/Wiki/ТЕНДЕРНІ_НОРМИ_звірені.md`; умову свого промпта вважай виконаною)\n"
        "%s\n"
        "Спирайся ЛИШЕ на ці норми. Чого тут немає — того не називай."
        % (brief.get("tender_id") or "—", pos.get("label") or "—",
           pos.get("basis") or "—", (brief.get("text") or "")[:6000]))


# Номер акта в тексті шукаємо лише поруч зі словом-маркером («постанова»,
# «ПКМУ», «Особливості», «закон», «порядок», «№») — щоб голе число з таблиці
# чи ціни не сприймалось як посилання на нормативний акт.
_ACT_NUM_RE = re.compile(r"\b(\d{3,4})\b")
_ACT_CTX_RE = re.compile(r"(?:постанов\w*|пкму|кму|особливост\w*|закон\w*|"
                         r"порядк\w*|порядок|№)(.{0,40}?)\b(\d{3,4})\b", re.I)


def _act_numbers(*texts) -> set:
    """Номери нормативних актів із тексту. Роки (1900-2100) відкидаємо — у
    «постанови КМУ 1275 від 11.11.2022» номер акта один, а 2022 це дата."""
    out = set()
    for t in texts:
        for m in _ACT_NUM_RE.finditer(str(t or "")):
            n = m.group(1)
            if len(n) == 4 and 1900 <= int(n) <= 2100:
                continue
            out.add(n)
    return out


def _regime_phrases(pack: dict) -> dict:
    """{тип процедури -> [стійкі частини НАЗВИ]} — з `label` кожного режиму бази.

    Свого словника назв тут НЕМАЄ і бути не повинно: назви живуть у
    knowledge_packs/tender_law/regimes.json. Один тип процедури має два записи
    (оборонний і звичайний замовник), і спільний початок їхніх назв — це і є
    назва САМОЇ процедури («спрощена закупівля», «відкриті торги з
    особливостями»), без приписки про замовника.
    """
    import tender_legal as _tl
    groups = {}
    for key, entry in (pack.get("regimes") or {}).items():
        label = _tl.normalize((entry or {}).get("label") or "")
        if not label:
            continue
        groups.setdefault(str(key).split("|")[0], []).append(label.split())
    out = {}
    for method, variants in groups.items():
        common = variants[0]
        for words in variants[1:]:
            n = 0
            while n < min(len(common), len(words)) and common[n] == words[n]:
                n += 1
            common = common[:n]
        phrase = " ".join(common).strip(" ,;-()")
        if len(common) < 2 or len(phrase) < 10:
            # Спільного початку майже немає — беремо назву як є (краще суворіше
            # порівняння, ніж коротке слово, яке збігатиметься з чим завгодно).
            phrase = " ".join(variants[0]).strip(" ,;-")
        forms = [phrase]
        head = phrase.split(" + ")[0].strip()   # «… + звіт про договір» — хвіст необовʼязковий
        if head != phrase and len(head.split()) >= 3:
            forms.append(head)
        out[method] = forms
    return out


def _regime_name_conflicts(text: str, pos: dict) -> list:
    """Згадки ЧУЖОГО режиму в тексті моделі: назва іншої процедури або чужа
    постанова як підстава. Порожній список = суперечності немає.

    Навіщо: числа днів ми звіряли, а НАЗВУ процедури — ні. Саме через це
    30.07 в одному документі опинились «спрощена закупівля» від ядра і
    «відкриті торги з особливостями 1178» від моделі.
    """
    if not pos or not pos.get("regime"):
        return []
    try:
        import tender_legal as _tl
        pack = _tl.load_pack()
    except Exception as e:
        llm._log(f"[executor] звірка назви режиму не відбулась: {e}")
        return []
    body = _tl.normalize(text or "")
    if not body:
        return []
    own_method = str(pos.get("regime")).split("|")[0]
    bad = []
    # 1) назва чужої процедури
    for method, forms in _regime_phrases(pack).items():
        if method == own_method:
            continue          # своя назва — не суперечність, а норма
        for ph in forms:
            if ph and ph in body:
                bad.append("назва чужої процедури: «%s»" % ph)
                break
    # 2) чужа постанова як підстава. Номери — з тієї самої бази, не з голови.
    own_nums = _act_numbers(pos.get("basis"),
                            *["%s %s" % (n.get("act", ""), n.get("ref", ""))
                              for n in (pos.get("norms") or [])])
    pack_nums = set()
    for entry in (pack.get("regimes") or {}).values():
        pack_nums |= _act_numbers((entry or {}).get("basis"))
        for n in (entry or {}).get("norms") or []:
            pack_nums |= _act_numbers(n.get("act"), n.get("ref"))
    alien_nums = pack_nums - own_nums
    for m in _ACT_CTX_RE.finditer(body):
        num = m.group(2)
        if num in alien_nums:
            frag = "чужа постанова як підстава: №%s" % num
            if frag not in bad:
                bad.append(frag)
    return bad


def _repair_legal_text(body: str, norms_block: str, outside: list, alien: list,
                       task: str = "", emit=None) -> tuple:
    """ПОВЕРНЕННЯ НА ВИПРАВЛЕННЯ замість ГІЛЬЙОТИНИ (30.07.2026).

    НАВІЩО. Ворота 28.07 при будь-якій суперечності з базою знімали ВЕСЬ текст
    моделі — і клієнт замість чек-листа й плану дій отримував саму таблицю норм.
    Наживо 30.07: агенти написали роботу, а слова «15 днів», «2 робочі дні» і
    згадка ПКМУ 1178 усередині великого документа відправили під ніж УСЕ.

    ⛔ ОДИН ХИБНИЙ РЯДОК НЕ МОЖЕ ЗАБИРАТИ В КЛІЄНТА ВСЮ РОБОТУ.

    Лікуємо як в Excel-моделі: кажемо моделі ТОЧНО, що суперечить, і просимо
    переписати саме ці місця за звіреною базою. Одне коло. Зняття тексту
    лишається — але як ОСТАННІЙ крок, а не перший.
    Повертає (виправлений_текст, лишилась_суперечність)."""
    if not body:
        return body, True
    problems = []
    if outside:
        problems.append("строки, яких немає у звіреній базі вашої процедури: "
                        + ", ".join(map(str, outside)))
    if alien:
        problems.append("посилання на чужу процедуру/постанову: " + ", ".join(map(str, alien)))
    _emit(emit, "⚖ Текст суперечить звіреній базі — повертаю на виправлення "
                "(%s)…" % "; ".join(problems)[:160])
    sys_p = (
        "Ти — редактор юридичного тексту. Тобі дано ЗВІРЕНУ БАЗУ норм саме цієї "
        "процедури і текст, який їй місцями суперечить. Виправ САМЕ ці місця: "
        "постав строки й підстави зі звіреної бази, прибери згадки чужих процедур "
        "і постанов. ВСЕ ІНШЕ ЗБЕРЕЖИ ДОСЛІВНО — чек-листи, переліки документів, "
        "плани дій, структуру й заголовки НЕ скорочуй і не переписуй. "
        "Якщо якогось строку у звіреній базі немає — не вигадуй його і не бери з "
        "памʼяті: прибери твердження про цей строк. "
        "Поверни ЛИШЕ виправлений текст, без пояснень.")
    user_p = ("## ЗВІРЕНА БАЗА (єдине джерело строків і підстав)\n%s\n\n"
              "## ЩО САМЕ СУПЕРЕЧИТЬ\n- %s\n\n"
              "## ЗАДАЧА КОРИСТУВАЧА\n%s\n\n"
              "## ТЕКСТ ДЛЯ ВИПРАВЛЕННЯ\n%s"
              % (norms_block, "\n- ".join(problems), (task or "")[:1500], body))
    try:
        fixed = llm.complete(sys_p, user_p, model=config.worker_model(),
                             max_tokens=config.ASSEMBLER_MAX_TOKENS)
    except llm.LLMError as e:
        llm._log("[executor] виправлення юр-тексту не відбулось: %s" % e)
        return body, True
    fixed = (fixed or "").strip()
    # Виправлення, яке зʼїло роботу, — не виправлення: короткий вивід відкидаємо.
    if len(fixed) < max(400, int(len(body) * 0.5)):
        llm._log("[executor] виправлення повернуло огризок (%d проти %d) — не приймаю"
                 % (len(fixed), len(body)))
        return body, True
    return fixed, False


def _apply_legal_citation_check(final_markdown: str, emit=None, task: str = "",
                                history=None, legal_pos: dict = None) -> str:
    """ЮРИДИЧНИЙ ВИВІД ДЛЯ ЛЮДИНИ. Правило одне, і воно просте:

        клієнт бачить лише те, що звірено — решта не виходить взагалі.

    ⭐ 28.07.2026. Раніше тут стояли машинні попередження («не звірено»,
    «машина не змогла підтвердити»). Для клієнта такий рядок = питання до
    продавця «навіщо я платив гроші». Тому:
      • є норми з бази під ЦЮ процедуру -> показуємо їх; текст моделі йде далі
        ЛИШЕ якщо він не суперечить базі (жодного строку поза нею);
      • норм немає -> текст моделі виходить лише коли всі його статті звірені
        з ВРУ і він не називає строків без встановленого режиму;
      • службова «звірка норм» у документ клієнта НЕ потрапляє — вона йде в лог.

    legal_pos (30.07.2026): ВЖЕ розрезолвлена позиція від run_system — щоб на
    прогін був ОДИН писар режиму, а не дві незалежні резолюції (агент бачив би
    одну, ворота — другу). Не передали (старі виклики) — резолвимо самі, як і
    раніше: зворотна сумісність зберігається.
    """
    try:
        import legal_citation_check as _lcc
        import datetime as _dt
    except Exception:
        return final_markdown
    body = _lcc.strip_model_verdict(_lcc.strip_model_seal(final_markdown or ""))
    norms_block, contradicts = "", False
    outside_hint, alien_hint = [], []   # ЩО САМЕ суперечить — для виправлення нижче
    # ⭐ 28.07.2026. Про який тендер мова — вирішує ОДИН резолвер на всю систему
    # (tender_context), а не кожен свій пошук по тексту. Людина в діалозі пише
    # «продовжуй» без номера — ворота мусять і далі спиратись на закон.
    if legal_pos is None:
        legal_pos = _resolve_legal_pos(task, history)
    ctx = (legal_pos or {}).get("ctx")
    brief = (legal_pos or {}).get("brief")
    try:
        import tender_legal as _tl
        if brief and brief.get("ok"):
            norms_block = brief.get("text") or ""
            outside = _tl.numbers_outside_base(body, brief.get("pos"))
            # ⭐ 30.07.2026. Поруч зі звіркою ЧИСЕЛ — звірка НАЗВИ процедури.
            # Наслідок навмисно ТОЙ САМИЙ: текст моделі не виходить до клієнта.
            alien = _regime_name_conflicts(body, brief.get("pos"))
            contradicts = bool(outside or alien)
            outside_hint, alien_hint = list(outside or []), list(alien or [])
            _emit(emit, "⚖ Норми взято зі звіреної бази для %s (%d шт.)."
                        % (brief["tender_id"], len(brief["pos"].get("norms") or [])))
            if outside:
                llm._log("[executor] строки поза базою -> текст іде на виправлення: %s" % outside)
                _emit(emit, "⚖ Текст моделі суперечив звіреній базі — повертаю його на виправлення.")
            if alien:
                llm._log("[executor] чужий режим у тексті -> текст іде на виправлення: %s" % alien)
                _emit(emit, "⚖ Модель назвала іншу процедуру/постанову, ніж встановило "
                            "ядро — повертаю текст на виправлення.")
        elif brief:
            llm._log("[executor] режим не встановлено: %s" % brief.get("problem"))
    except Exception as e:
        llm._log(f"[executor] правові ворота зірвались: {e}")

    # Службова звірка цитат — у ЛОГ, не в документ клієнта.
    unverified = False
    try:
        verdicts, summ = _lcc.verify(body, legal_source_ua.fetch_text)
        unverified = bool(summ.get("flagged"))
        if verdicts:
            llm._log("[executor] звірка цитат: %s"
                     % _lcc.build_report(verdicts, _dt.date.today().strftime("%d.%m.%Y")))
    except Exception as e:
        llm._log(f"[executor] звіряч цитат зірвався: {e}")

    if norms_block:
        if contradicts:
            # ⛔ 30.07.2026. Тут стояла ГІЛЬЙОТИНА: будь-яка суперечність знімала
            # ВЕСЬ текст моделі, і клієнт отримував саму таблицю норм замість
            # чек-листа й плану. Тепер спершу ОДНЕ коло виправлення з точною
            # причиною, і лише якщо воно не допомогло — лишаємо самі норми.
            body, contradicts = _repair_legal_text(body, norms_block, outside_hint,
                                                   alien_hint, task=task, emit=emit)
            if not contradicts:
                _emit(emit, "⚖ Текст виправлено за звіреною базою — робота лишається повною.")
        if contradicts:
            llm._log("[executor] виправлення не зняло суперечність — лишаю самі норми")
            _emit(emit, "⚖ Виправити текст не вдалось — лишаю тільки звірені норми.")
            out = "\n\n".join(x for x in (_lcc.client_notice(True), norms_block) if x)
        else:
            # ⛔ 30.07.2026. ОДИН ПИСАР СТАТУСУ ЗВІРКИ. Модель писала «⚠ не звірено
            # з першоджерелом» про норми, які наша база звірила й датувала, — і
            # клієнт читав дві правди на одній сторінці. Тепер її заяви про звірку
            # знімаються, а статус пише база — і про звірене, і про свою межу.
            body = _lcc.strip_model_verification_claims(body)
            status = _lcc.base_status_block((brief or {}).get("pos") if brief else None)
            out = "\n\n".join(x for x in (norms_block, body, status) if x)
        return _clean_for_human(out)

    # Норм з бази немає. Показуємо текст моделі лише якщо він чистий.
    try:
        import tender_legal as _tl2
        risky = bool(_tl2.deadline_guard(body))
    except Exception:
        risky = False
    # У розмові кілька різних тендерів, а в питанні номера немає — не вгадуємо,
    # перепитуємо (рішення Андрія 28.07.2026: хибний строк по чужому тендеру
    # дорожчий за одне зайве питання).
    if (ctx or {}).get("source") == "ambiguous" and (risky or unverified):
        _emit(emit, "⚖ У розмові кілька тендерів — прошу уточнити, який саме.")
        return (ctx.get("ask") or "") + "\n\n" + _ANSWER_TAIL
    if risky or unverified:
        _emit(emit, "⚖ Строки без встановленої процедури не публікуються.")
        return ("**Щоб дати строки саме по вашому тендеру, вкажіть його номер "
                "(UA-…).**\n\nСтроки різних типів закупівель відрізняються між "
                "собою, тому без номера назвати їх точно неможливо — це той "
                "випадок, коли краще запитати, ніж помилитись.\n\n" + _ANSWER_TAIL)
    return body


# (_is_seo_system прибрано 10.07.2026 — здатність page_read декларує паспорт ролей)


# Розширення на кшталт файлів — щоб «звіт.md» чи «дані.json» не сприймати як сайт.
_NONSITE_TLD = {"md", "py", "txt", "json", "docx", "xlsx", "pptx", "pdf", "png",
                "jpg", "jpeg", "gif", "svg", "html", "htm", "csv", "zip", "bat",
                "exe", "yaml", "yml", "js", "css"}


def _extract_task_url(task: str) -> str:
    """Дістає адресу сторінки із задачі. Ловить і повний URL (https://…), і «голий»
    домен (sensflow.net, dom-market.com/шлях) — бо клієнти зазвичай вставляють саме
    голу назву, а не інструкцію. Відкидає e-mail і згадки файлів (…​.md/.py/.docx).
    Голий домен нормалізує до https://."""
    t = task or ""
    m = re.search(r"https?://[^\s)>\]\"'<]+", t)
    if m:
        return m.group(0)
    for m in re.finditer(
            r"(?<![\w@/.])((?:www\.)?[a-z0-9][a-z0-9-]*(?:\.[a-z0-9-]+)*\.[a-z]{2,})"
            r"(/[^\s)>\]\"'<]*)?", t, re.I):
        host, tail = m.group(1).lower(), (m.group(2) or "")
        if not tail and host.rsplit(".", 1)[-1] in _NONSITE_TLD:
            continue  # це ім'я файлу (напр. звіт.md), не сайт
        return "https://" + host + tail
    return ""


_ROUTE_PARSE_SYS = (
    "Ти розбираєш запит користувача на побудову маршрутy подорожі. Зрозумій його СЕМАНТИЧНО "
    "(не за ключовими словами) і визнач:\n"
    "- start: звідки виїзд (населений пункт);\n"
    "- end: КІНЦЕВА мета поїздки — саме пункт призначення (напр. пансіонат, готель, село, "
    "куди людина їде відпочивати), а НЕ останнє місто-орієнтир у переліку «через». Якщо мета — "
    "заклад у селі, end = це село (можна з районом/областю);\n"
    "- waypoints: проміжні пункти У ПОРЯДКУ руху (те, що після слова «через» тощо), БЕЗ start і end;\n"
    "- transport: спосіб пересування (авто/мото/вело/пішки/потяг/автобус/літак/громадський…); "
    "не вказано — \"авто\".\n"
    "Назви пиши як є, українською, можна з областю для однозначності (напр. «Поляна, Свалявський район»).\n"
    'Поверни РІВНО ОДИН JSON: {"start":"","end":"","waypoints":[],"transport":""}. '
    "Якщо це не запит на маршрут або немає звідки/куди — поверни {\"start\":\"\",\"end\":\"\"}.")


def _parse_route_request(task: str):
    """СЕМАНТИЧНИЙ розбір запиту маршруту мовною моделлю (не регулярка): будь-яке
    формулювання → {start, end, waypoints[], transport}. None, якщо не вдалося."""
    if not config.provider_ready():
        return None
    try:
        r = llm.judge_json(_ROUTE_PARSE_SYS, f"ЗАПИТ КОРИСТУВАЧА:\n{(task or '')[:2500]}",
                           temperature=0.0, model=config.worker_model(),
                           purpose="розбір запиту маршруту")
    except llm.LLMError:
        return None
    if not isinstance(r, dict):
        return None
    r["waypoints"] = [w.strip() for w in (r.get("waypoints") or [])
                      if isinstance(w, str) and w.strip()]
    return r


def _route_block(system, task: str):
    """Для системи маршрутів: СЕМАНТИЧНО розібрати запит (мовною моделлю) у звідки/куди/
    проміжні/спосіб, тоді підкласти РЕАЛЬНИЙ маршрут з двигуна (ORS) — ЄДИНЕ джерело
    правди про шлях (реальні відстань/час/траси/міста, у правильному порядку). Дорожній →
    справжня траса; не-дорожній (авіа/потяг) → чесна вказівка на веб-пошук.

    Повертає (block_str, diag). diag=None ЛИШЕ якщо це не система маршрутів. Для системи
    маршрутів diag присутній ЗАВЖДИ — щоб причина «чому нема реального шляху» доходила в
    run.json, а не тонула мовчки: {"parsed": <що витяг розбір|None>, "result": <відповідь
    двигуна|None>, "reason": <людський текст>}. Це «гучний фейл»: система бачить точну
    причину (порожній розбір / ORS впав / не знайдено пункт), а не домальовує маршрут."""
    if (system or {}).get("id") != "route_object_search":
        return "", None
    p = _parse_route_request(task)
    if not p or not (p.get("start") or "").strip() or not (p.get("end") or "").strip():
        return "", {"parsed": p, "result": None,
                    "reason": "розбір запиту не виділив звідки/куди (start/end порожні)"}
    r = route_engine.route(p["start"], p["end"], p.get("transport") or "авто",
                           p.get("waypoints") or [])
    reason = ("маршрут побудовано двигуном" if r.get("ok")
              else (r.get("note") or "двигун не побудував маршрут"))
    return route_engine.format_block(r), {"parsed": p, "result": r, "reason": reason}


# Ключові слова «живих умов» дороги/в'їзду. Коли вони є в запиті маршруту, платформа
# САМА робить ОДИН живий веб-пошук актуальних обмежень пункту призначення й кладе реальні
# знахідки+джерела як факт (брат блоку «РЕАЛЬНИЙ МАРШРУТ»/«РЕАЛЬНІ ЗУПИНКИ»). Лікує корінь
# 14.07: веб приносив реальні обмеження (комендантська/блокпости, 30 джерел), а звіт писав
# «значних обмежень не виявлено» — впевнене заспокоєння поверх правди = найгірший обман.
_COND_KW = ("обмеж", "в'їзд", "в’їзд", "въезд", "комендант", "блокпост", "контрольн",
            "перекрит", "закрит дор", "дорожн обстан", "ситуац на дор", "проїзд",
            "перевір в інтернет", "перевірити в інтернет", "перевір у мереж")
_COND_HEAD = ("\n## ЖИВІ УМОВИ — актуальні обмеження в'їзду / дорожня обстановка "
              "(ЄДИНЕ джерело правди про умови)\n")


def _conditions_block(system, task: str, route_diag):
    """Для системи маршрутів: якщо запит просить актуальні обмеження в'їзду / дорожню
    обстановку — зробити ОДИН живий веб-пошук по пункту призначення й підкласти реальні
    знахідки + джерела як факт. Повертає (block, diag). diag → run.json (слід дії веб:
    checked / used_search / sources) — щоб «перевірив чи ні» було ВИДНО, а не на віру.
    Порожньо/збій → чесний блок «не перевірено», який ЗАБОРОНЯЄ писати «обмежень нема»."""
    if (system or {}).get("id") != "route_object_search":
        return "", None
    t = (task or "").lower()
    if not any(k in t for k in _COND_KW):
        return "", None
    # Пункт призначення — з реального маршруту (краще) або з розбору запиту.
    dest = ""
    res = (route_diag or {}).get("result") if isinstance(route_diag, dict) else None
    if isinstance(res, dict):
        dest = res.get("end") or ""
    if not dest and isinstance(route_diag, dict):
        dest = ((route_diag.get("parsed") or {}).get("end")) or ""
    dcity = (dest.split(",")[0].strip() if dest else "") or "пункту призначення"
    if not config.web_search_ready():
        return (_COND_HEAD + "Веб-пошук недоступний — актуальні обмеження НЕ перевірено. "
                "НЕ пиши, що обмежень нема; чесно зазнач, що перевірити не вдалося, і дай "
                "офіційне джерело для ручної перевірки.\n",
                {"checked": False, "reason": "web_search недоступний", "sources": 0})
    import datetime
    today = datetime.date.today().strftime("%d.%m.%Y")
    query = (f"Актуальні обмеження на в'їзд та дорожня обстановка: {dcity} — комендантська "
             f"година, блокпости, перепустки, перекриття доріг, станом на {today}")
    sr = tools.web_search(query, context=task)
    used = sr.get("used_search")
    if sr.get("ok") and sr.get("text"):
        srcs = sr.get("sources") or []
        src_block = ""
        if srcs:
            src_block = "\n\nДжерела:\n" + "\n".join(
                f"  - {s.get('title') or s.get('url')}: {s.get('url')}" for s in srcs[:8])
        block = (_COND_HEAD +
                 f"(живий веб-пошук: провайдер шукав={used}, джерел={len(srcs)})\n"
                 "Виведи ці умови у звіт стисло, СВОЇМИ словами, з посиланнями на джерела. "
                 "НЕ пиши «значних обмежень нема», якщо нижче йдеться про комендантську "
                 "годину, блокпости чи перекриття. Чого нижче немає — не додумуй.\n\n"
                 + sr["text"].strip() + src_block + "\n")
        return block, {"checked": True, "used_search": used,
                       "sources": len(srcs), "query": query}
    note = sr.get("note") or "пошук повернув порожньо"
    return (_COND_HEAD + f"Живий веб-пошук не дав результату (причина: {note}). НЕ пиши, що "
            "обмежень нема — чесно зазнач, що актуальних даних знайти не вдалося, і дай "
            "офіційне джерело для ручної перевірки.\n",
            {"checked": True, "used_search": used, "sources": 0, "note": note})


def _seo_page_block(system, task: str, roles: dict = None):
    """Якщо роль системи декларує page_read (паспорт) і в задачі є адреса сторінки
    (повний URL АБО голий домен) — підкласти агентам СТРУКТУРОВАНИЙ витяг реальної
    сторінки (title/meta/og/canonical/H1-H3/JSON-LD/alt + очищений текст). Лікує
    корінь «агент вгадує з назви / бачить обрізаний парс».

    Повертає (block_str, facts|None, diag|None):
      • diag=None — це НЕ SEO-задача (немає ролі page_read) або в задачі немає адреси:
        звичайний плин, без стопу.
      • diag={"read_ok":True,...} — сторінку ВПЕВНЕНО прочитано (block + facts повні).
      • diag={"read_ok":False,"reason":…} — сторінку НЕ прочитано (редірект на іншу /
        недоступна / порожня оболонка): block порожній, а run_system віддає ЧЕСНИЙ СТОП
        замість аудиту «з голови» (дзеркало маршрутного стопу-фантазії)."""
    # ⭐⭐⭐ 04.08.2026, ЖИВИЙ ВИПАДОК У КЛІЄНТА (casper.in.ua → звіт про матраци).
    # КОРІНЬ: право вийти у світ і прочитати НАЗВАНЕ джерело було прикріплене до
    # ПАСПОРТА РОЛІ (page_read декларували 3 системи з 22). Маркетингова система
    # отримала адресу сайта, НЕ прочитала її і написала аудит із памʼяті моделі, ще й
    # заявила метод «аналіз публічно доступного сайту». Ворота «сторінку не прочитано»
    # навіть не вмикались — вони стояли за ВМІННЯМ системи, а не за ЗАДАЧЕЮ.
    # РІШЕННЯ (Андрій, 04.08.2026): джерело, НАЗВАНЕ в задачі, читають УСІ системи.
    # Паспорт ролі більше НЕ ворота — лише ознака профілю (role_page_read у diag: нею
    # гаситься вимір швидкості, щоб не міняти профіль вартості не-SEO задач).
    # РIВНО True = ПРОФIЛЬНА SEO-система: лише їй мiряємо швидкiсть (PageSpeed),
    # щоб право "implied" не змiнювало профiль вартостi не-SEO задач.
    has_page_read = any(((r or {}).get("tools") or {}).get("page_read") is True
                        for r in (roles or {}).values())
    url = _extract_task_url(task)
    if not url:
        return "", None, None
    r = tools.read_page_seo(url)
    # ВПЕВНЕНО прочитано = завантажилось І має текст І не повели на іншу сторінку
    # І не порожня оболонка. Інакше — чесний стоп (не м'яка приписка моделі).
    read_ok = bool(r.get("ok") and r.get("text")) and not r.get("redirected") and not r.get("thin")
    if read_ok:
        block = ("## РЕАЛЬНА СТОРІНКА (структурований витяг — ЄДИНЕ джерело правди про сторінку)\n"
                 "Аудит роби ЛИШЕ по цьому витягу. БУДЬ-ЯКИЙ опис вмісту сторінки в інших "
                 "частинах завдання (заголовки, сертифікати, нагороди, ціни, schema, тексти) "
                 "ІГНОРУЙ — він міг бути домислений і не звірений. Чого НЕМАЄ в цьому витягу — "
                 "вважай невідомим і НЕ стверджуй як факт.\n\n" + r["text"])
        return block, r.get("facts"), {"read_ok": True, "url": url,
                                       "role_page_read": has_page_read,
                                       "final_url": r.get("final_url") or url}
    # Сторінку НЕ прочитано впевнено — ЛЮДСЬКА причина для чесного стопу.
    if not (r.get("ok") and r.get("text")):
        reason = r.get("note") or "сторінка недоступна"
    elif r.get("redirected"):
        reason = (f"адреса веде на іншу сторінку ({url} → {r.get('final_url')}) — "
                  "тобто відкрито НЕ ту сторінку, яку ти дав")
    elif r.get("thin"):
        reason = ("сторінка відкрилась порожньою (ймовірно рендериться через JavaScript "
                  "або потребує входу) — перевірених даних про неї немає")
    else:
        reason = r.get("note") or "сторінку не вдалося прочитати"
    return "", None, {"read_ok": False, "url": url,
                      "role_page_read": has_page_read,
                      "final_url": r.get("final_url") or url, "reason": reason}


def _speed_block(seo_diag):
    """Реальна швидкість сторінки (Google PageSpeed) — той самий слот інжекту фактів,
    що й читання сторінки. Викликається ЛИШЕ коли сторінку впевнено прочитано
    (seo_diag.read_ok), для тієї самої фінальної адреси. Мʼяка деградація: нема даних →
    ('', diag), і стратег напише «швидкість не виміряно», а не вигадає цифри.

    Повертає (block_str, diag|None)."""
    if not (seo_diag and seo_diag.get("read_ok")):
        return "", None
    url = seo_diag.get("final_url") or seo_diag.get("url")
    try:
        r = tools.pagespeed_measure(url, strategy="mobile")
    except Exception as e:  # noqa
        return "", {"ok": False, "url": url, "note": f"виняток: {str(e)[:200]}"}
    if r.get("ok") and r.get("text"):
        block = ("## ШВИДКІСТЬ СТОРІНКИ (Google PageSpeed — ВИМІРЯНО, єдине джерело правди про швидкість)\n"
                 "Будь-які твердження про швидкість, час завантаження чи Core Web Vitals "
                 "(LCP/CLS/INP/TBT) роби ЛИШЕ з цього блоку. Немає блоку — пиши «швидкість "
                 "не виміряно», НЕ вигадуй цифр і НЕ став оцінок «на око».\n\n" + r["text"])
        return block, {"ok": True, "url": url, "data": r.get("data")}
    return "", {"ok": False, "url": url, "note": r.get("note", "")}


# (10.07.2026) _force_legal_web / _looks_market_task / _force_live + їхні словники
# прибрано повністю: ЧИ потрібен живий веб — каже контракт наміру (intent.fresh_data),
# КОМУ — паспорт ролей (web: "always" у юр-звіряча норм — інваріант юрсистем,
# засіяний registry.seed_roles; "per_intent" — у дослідницьких ролей).


# Юрисдикційність: офіційне джерело норм залежить від країни права задачі.
_LEGAL_PORTAL = {
    "UA": "zakon.rada.gov.ua (офіційний портал законодавства України)",
    "KZ": "adilet.zan.kz (офіційна ІПС «Әділет» Мінюсту Республіки Казахстан)",
    "IL": ("офіційне законодавство Ізраїлю — база Кнесету knesset.gov.il "
           "(і офіційний вісник «Reshumot»/רשומות); практична база — nevo.co.il"),
}
_KZ_KW = ("казахстан", "қазақстан", "республик казахстан", "адилет", "adilet", "тенге",
          "алмат", "астан", "караганд", "шымкент", "костанай", " рк ", " kz ", "kazakhstan")
_IL_KW = ("ізраїл", "израил", "israel", "ישראל", "тель-авів", "тель-авив", "tel aviv",
          "tel-aviv", "єрусалим", "иерусалим", "jerusalem", "ירושלים", "хайфа", "haifa",
          "кнесет", "knesset", "כנסת", "шекел", "шекель", "₪", " ils ", "nevo", " il ",
          "иврит", "іврит", "עברית")


def _legal_jurisdiction(task: str) -> str:
    """Груба детекція юрисдикції з тексту задачі (IL/KZ/UA).
    Якщо в тексті немає сигналу — береться дефолт збірки (config.DEFAULT_JURISDICTION)."""
    t = " " + (task or "").lower() + " "
    if any(k in t for k in _IL_KW):
        return "IL"
    if any(k in t for k in _KZ_KW):
        return "KZ"
    return getattr(config, "DEFAULT_JURISDICTION", "UA") or "UA"


def _legal_portal(task: str) -> str:
    return _LEGAL_PORTAL.get(_legal_jurisdiction(task), _LEGAL_PORTAL["UA"])


def _step_web_allowed(role_web, fresh_required: bool, step: dict, web_done: bool) -> bool:
    """ЧИ цей крок виходить у світ по живі дані.

    ⭐⭐⭐ 04.08.2026 (Андрій): «всі системи повинні мати можливість за потреби
    виходити у світ». Раніше право шукати давав ПАСПОРТ РОЛІ: роль без ключа
    web не шукала НІКОЛИ — навіть коли контракт наміру прямо казав «потрібні свіжі
    дані». Тепер вирішує ЗАДАЧА (контракт), а паспорт лише ПОСИЛЮЄ:
      • web="always" — інваріант ролі, шукає завжди (юрист-звіряч норм);
      • контракт fresh_data=required — шукає БУДЬ-ЯКА роль; один web-крок на
        прогін (розміщення — за підказкою плану), щоб не множити вартість.
    """
    if role_web == "always":
        return True
    if fresh_required:
        return bool((step or {}).get("needs_web_search")) or not web_done
    # ⭐⭐⭐ 09.08.2026, ВОРОТА ЗАМIСТЬ ПРОХАННЯ. Тричі поспiль платнi прогони
    # Андрiя вертались без ЖОДНОГО звернення до пошуку: веб вмикав лише контракт
    # намiру, а мозок його не ставив. Я лiкував це текстом у промптi — але
    # ПРАВИЛО В ПРОМПТI — ПРОХАННЯ, А НЕ ВОРОТА, i модель його не виконала.
    # Тепер вирiшує КОД: роль, якiй паспорт дав web, i крок-дослiдження — шукають
    # завжди. Вартiсть тримає той самий запобiжник, що й ранiше: web_done, тобто
    # РIВНО ОДИН веб-крок на прогiн.
    if role_web == "per_intent" and not web_done:
        return True
    return False


# --- 09.08.2026, задача T-000009. ЗНАЙШОВ АДРЕСУ - ВIДКРИЙ ЇЇ. --------------
# КОРIНЬ: веб-пошук повертав ПЕРЕКАЗ провайдера + список посилань. Справжнiй
# текст сторiнки читався ЛИШЕ тодi, коли адресу назвала сама задача
# (_seo_page_block). Тобто жодна з 23 систем не вiдкривала те, що знайшла САМА.
# Для людини це «знайду, але не подивлюсь» - саме так рекрутингова система
# вiдмовилась переглядати резюме, i клiєнт пiшов пробувати чужу CRM.
# ВМIННЯ, ЯКЕ ОБIЦЯЄ БIЛЬШЕ, НIЖ ДАЄ, - це не «частково працює», а «не працює».
# РIШЕННЯ: живi данi кроку = пiдсумок пошуку + СПРАВЖНIЙ текст верхнiх джерел.
# Грошей не коштує (прямий HTTP, не мовна модель).
# ⚠ Обрiзання називаємо ВГОЛОС: мовчазне звуження списку - заборонений клас.
_OPEN_FOUND_LIMIT = 3      # скiльки сторiнок реально вiдкриваємо
_OPEN_FOUND_TRIES = 5      # скiльки адрес пробуємо (недоступнi не крадуть квоту)
_OPEN_FOUND_CHARS = 6000   # СТЕЛЯ на сторiнку, коли бюджет не заданий

# --- 09.08.2026. БЮДЖЕТ ЖИВИХ ДАНИХ - ОДНЕ ДЖЕРЕЛО ПРАВДИ -----------------
# СКЛАДАЧ, ЯКИЙ НЕ ЗНАЄ ПРО СТЕЛЮ СПОЖИВАЧА, ГОТУЄ МОВЧАЗНЕ ОБРIЗАННЯ.
# Проба 09.08 (перехоплений промпт агента): блок на 19 768 символiв доїжджав
# до агента як ХВIСТ у 6 000 - без заголовка й iнструкцiї «не додумуй», без
# пiдсумку пошуку, з обрубком третьої сторiнки вiд середини речення. А рядок
# «вiдкрито 3 з 5» виживав i виглядав як доказ, що все гаразд. Це ГIРШЕ, нiж
# не вiдкривати зовсiм: агент дiстає смiття плюс запевнення, що все прочитано.
# РIШЕННЯ: одна константа, яку знають ОБИДВА боки - i збирач, i зрiз у промптi.
# 12 000 узгоджено з уже прийнятим рiшенням для прочитаної сторiнки
# (seo_page 16 000): це ПЕРВИННЕ джерело, а не переказ провайдера.
LIVE_DATA_WINDOW = 12000
_LIVE_SUMMARY_SHARE = 0.25   # частка бюджету на переказ провайдера
_OPEN_FOUND_MIN_CHARS = 700  # менше цього сторiнка вже не iнформативна
_DEEP_OPEN = 6               # скiльки карток брати зi сторiнки-покажчика


def _open_found_sources(sources, limit: int = _OPEN_FOUND_LIMIT,
                        budget: int = 0):
    """Вiдкриває верхнi знайденi пошуком адреси i вiддає їх СПРАВЖНIЙ текст.

    Повертає (block, note): note - вголос сказане обрiзання («вiдкрито 3 з 9»),
    щоб мовчазне звуження не видавало себе за повний огляд."""
    urls = []
    for _s in (sources or []):
        u = ((_s or {}).get("url") or "").strip()
        if u.lower().startswith(("http://", "https://")) and u not in urls:
            urls.append(u)
    if not urls:
        return "", ""
    # Скiльки символiв дiстанеться КОЖНIЙ сторiнцi: бюджет дiлиться усвiдомлено,
    # а не «хто останнiй, той вцiлiв». Не влазить навiть мiнiмум - беремо МЕНШЕ
    # сторiнок, але ЦIЛИМИ (краще двi повнi, нiж три обрубки).
    per = _OPEN_FOUND_CHARS
    if budget and budget > 0:
        _room = max(0, budget - 260)          # запас на заголовок i пiдпис
        while limit > 1 and _room // limit < _OPEN_FOUND_MIN_CHARS:
            limit -= 1
        per = max(_OPEN_FOUND_MIN_CHARS, _room // max(1, limit))
        per = min(per, _OPEN_FOUND_CHARS)
    # ⭐⭐⭐ 09.08.2026. ЗНАЙШОВ ПОКАЖЧИК — IДИ ЗА ПОСИЛАННЯМ (живий провал у клiєнта).
    # Пошук приводив на сторiнку-СПИСОК (14 резюме, 3939 усього). Ми її вiдкривали
    # i зупинялись: у списку лише короткi пiдписи, а самi записи — за посиланнями.
    # Модель на цьому дописувала «доступ закритий» i вигадувала кандидатiв.
    # Тому: якщо адреса виявилась покажчиком — беремо з неї КАРТКИ записiв i
    # ставимо їх у чергу ПЕРЕД самим покажчиком (людина робить так само).
    _deep = []
    for u in urls[:2]:
        try:
            _deep.extend(tools.page_record_links(u, limit=_DEEP_OPEN))
        except Exception:
            pass
    if _deep:
        urls = _deep + [u for u in urls if u not in _deep]

    blocks, opened, failed = [], 0, []
    _opened_ok = []            # адреси, якi платформа СПРАВДI вiдкрила й прочитала
    for u in urls[:_OPEN_FOUND_TRIES]:
        if opened >= limit:
            break
        try:
            r = tools.read_page_seo(u)
        except Exception as _e:
            failed.append("%s (%s)" % (u, _e))
            continue
        if r.get("ok") and r.get("text") and not r.get("thin"):
            opened += 1
            _body = r["text"][:per]
            if len(r["text"]) > per:
                _body += "\n[сторiнку скорочено до %d символiв]" % per
            _opened_ok.append(r.get("final_url") or u)
            blocks.append("### Прочитана сторiнка %d: %s\n%s"
                          % (opened, r.get("final_url") or u, _body))
        else:
            failed.append("%s (%s)" % (u, r.get("note") or "не вiдкрилась"))
    _open_found_sources.last_opened = list(_opened_ok)
    if not blocks:
        return "", ("Знайдено адрес: %d, але ЖОДНУ сторiнку не вдалося вiдкрити (%s). "
                    "Спирайся лише на пiдсумок пошуку i НЕ видавай вмiст сторiнок за "
                    "перевiрений." % (len(urls), "; ".join(failed[:3])))
    head = ("## ВIДКРИТI СТОРIНКИ ЗА ЗНАЙДЕНИМИ АДРЕСАМИ (справжнiй текст, не переказ)\n"
            "Це первинне джерело. Що є тут - можна стверджувати; чого тут немає - "
            "вважай невiдомим i НЕ додумуй.\n")
    note = "Вiдкрито сторiнок: %d iз %d знайдених адрес." % (opened, len(urls))
    if failed:
        note += " Не вiдкрилися: %d." % len(failed)
    return head + "\n\n".join(blocks), note


def _gather_live_data(task, step, system=None, force=False):
    """Запускає веб-пошук для кроку. Повертає (live_text, sources, fail_note):
    fail_note — ЛЮДСЬКА причина, чому живих даних немає (для ГУЧНОЇ деградації
    на інваріантних ролях web='always' — юрист 10.07 ~23:40 промовчав у stderr).
    ЧИ шукати — вирішено ДО виклику (контракт наміру × паспорт ролі); тут force=True
    означає «шукай». _is_legal_system нижче — лише про ФОРМУЛЮВАННЯ запиту
    (офіційний портал юрисдикції), не про дозвіл."""
    if not (force and config.web_search_ready()):
        return "", [], ("веб-пошук недоступний (не налаштований або вимкнений)" if force else "")
    # ШАР 1 — ОФІЦІЙНЕ ПЕРШОДЖЕРЕЛО (право UA): для української правової системи
    # спершу пробуємо офіційну базу «Законодавство України» ВРУ (точний текст +
    # чинна редакція з офіційної картки), а не загальний веб-пошук (агрегатори /
    # JS-порожнеча zakon.rada). Дало результат → віддаємо його як живі дані; ні →
    # падаємо назад на звичайний веб-пошук нижче, нічого не втрачаючи.
    if _is_legal_system(system) and _legal_jurisdiction(task) == "UA":
        try:
            _off = legal_source_ua.lookup(task)
        except Exception as _e:
            _off = {"ok": False, "note": f"офіційне джерело: помилка {_e}"}
        if _off.get("ok"):
            return _off["block"], _off.get("sources", []), ""
    query = f"{task} — {step.get('purpose','')}".strip(" —")
    # Юридична звірка норм — ЛИШЕ для правових систем (не для ринкових), і за
    # офіційним порталом відповідної юрисдикції (UA→zakon.rada, KZ→adilet.zan.kz).
    if _is_legal_system(system):
        query += (" — чинна редакція норм, звірити назву/номер/зміст статті за офіційним "
                  "джерелом " + _legal_portal(task))
    sr = tools.web_search(query, context=task)
    if sr.get("ok") and sr.get("text"):
        srcs = sr.get("sources", [])
        # БЮДЖЕТ ДIЛИТЬСЯ УСВIДОМЛЕНО: спершу мiсце пiд переказ провайдера й
        # перелiк джерел, ВСЯ решта - пiд справжнiй текст вiдкритих сторiнок.
        summary = sr["text"]
        _sum_cap = int(LIVE_DATA_WINDOW * _LIVE_SUMMARY_SHARE)
        if len(summary) > _sum_cap:
            summary = (summary[:_sum_cap]
                       + "\n[пiдсумок пошуку скорочено - нижче йде справжнiй "
                         "текст сторiнок, вiн важливiший]")
        src_lines = ""
        if srcs:
            src_lines = "\n\nДжерела:\n" + "\n".join(f"- {s.get('title') or s['url']}: {s['url']}" for s in srcs)
        block = summary + src_lines
        # ЗНАЙШОВ АДРЕСУ - ВIДКРИЙ ЇЇ (не переказ провайдера, а сама сторiнка).
        _opened, _op_note = _open_found_sources(
            srcs, budget=LIVE_DATA_WINDOW - len(block) - 200)
        # ⭐ СЛIД (09.08.2026): без нього причина «система нiчого не знайшла»
        # знову була б здогадкою. ASCII — консоль Windows кирилицю в stderr ламає.
        import sys as _ot
        # ⭐ 09.08.2026. АДРЕСА, ЯКУ ПЛАТФОРМА СПРАВДI ВIДКРИЛА, — ЦЕ ДЖЕРЕЛО.
        # Iнакше ворота проти вигадки рiзали ПРАВДУ: картки зi сторiнки-покажчика
        # не були у sources (там лише сам покажчик) i виглядали як вигаданi.
        for _ou in (getattr(_open_found_sources, "last_opened", None) or []):
            if _ou and not any((x or {}).get("url") == _ou for x in srcs):
                srcs.append({"title": "прочитана сторiнка", "url": _ou})
        _ot.stderr.write("[web] found=%d opened=%d note=%r urls=%s\n"
                         % (len(srcs), (_opened or "").count("### "),
                            (_op_note or "")[:60],
                            "; ".join((x or {}).get("url", "") for x in srcs[:4])))
        if _opened:
            block += "\n\n" + _opened
        if _op_note:
            block += "\n\n" + _op_note
        # ГАРАНТIЯ IНВАРIАНТУ: зiбране ВЛАЗИТЬ у вiкно споживача. Перебiр рiжемо
        # з ПЕРЕКАЗУ (найменш цiнне), а не з хвоста - iнакше зрiз у промптi знову
        # зʼїсть заголовок, iнструкцiю «не додумуй» i першi сторiнки.
        if len(block) > LIVE_DATA_WINDOW:
            _over = len(block) - LIVE_DATA_WINDOW
            _tail = "\n[переказ скорочено - мiсце вiддано сторiнкам]"
            summary = summary[:max(0, len(summary) - _over - len(_tail))] + _tail
            block = summary + src_lines
            if _opened:
                block += "\n\n" + _opened
            if _op_note:
                block += "\n\n" + _op_note
        return block, srcs, ""
    note = sr.get("note") or "пошук повернув порожню відповідь"
    import sys as _sys
    _sys.stderr.write(f"[web_search] крок «{step.get('agent')}»: {note}\n")
    return "", [], note


# ── ⭐⭐⭐ 07.08.2026. ОДИН ПИСАР ТЕКСТУ ПРО СТВОРЕНЕ ────────────────────────
# Речення про те, що платформа створила, пише КОД і ніхто інший. Мозок може
# додати супровід, але не може ні прибрати цей блок, ні переказати його інакше:
# 07.08 саме переказ перетворив «створено трьома агентами Будівника» на
# «зробив 3 агенти замість 2», а вдалу роботу — на доповідь про провал.
_KIND_WORDS = {"system": "Система", "file": "Файл", "record": "Запис"}


def created_report_markdown(items) -> str:
    """Дослівний блок для ЛЮДИНИ: що саме створено, де воно лежить, чим доведено."""
    items = [i for i in (items or []) if isinstance(i, dict)]
    if not items:
        return ""
    lines = ["✅ **Створено й перевірено на диску:**", ""]
    for it in items:
        word = _KIND_WORDS.get(it.get("kind") or "", "Створено")
        title = it.get("name") or it.get("id") or it.get("address") or "—"
        lines.append(f"- {word}: **{title}**")
        if it.get("id"):
            lines.append(f"  - id: `{it['id']}`")
        if it.get("address"):
            lines.append(f"  - де лежить: `{it['address']}`")
        if it.get("files"):
            lines.append(f"  - файлів записано: {it['files']}")
        if it.get("proof"):
            lines.append(f"  - чим доведено: {it['proof']}")
    if any((i.get("kind") == "system") for i in items):
        lines.append("")
        lines.append("Наступний крок — активувати систему кнопкою «✓ Активувати» на її картці.")
    return "\n".join(lines)


def _build_for_real(actor, system: dict, task: str, files_context: str = "", history=None,
                    emit=None, style: str = "", depth: str = "full", should_cancel=None) -> dict:
    """ПОВНОЦІННИЙ запуск системи «Будівник систем»: працюють УСІ ТРИ її агенти
    (Аналітик → Автор промптів → Структуролог), а їхній структурний результат
    ДЕТЕРМІНОВАНО матеріалізується на диск (файли + реєстрація). Це найчистіша
    форма філософії платформи: агенти проєктують — сервер лише пише байти.

    Історія: раніше ці агенти лише ПИСАЛИ текст, а їхній JSON ніхто не матеріалізував
    → звіт «створено», порожньо на диску (run 10.07 09:33, verified:false).
    ЗАМОК ЧЕСНОСТІ: звіт «створено» — лише після перевірки реальних артефактів."""
    # 1) Реальний 3-агентний конвеєр (allow_real_build=False → без рекурсії сюди).
    # ⭐⭐⭐ 07.08.2026. АКТОР ІДЕ СКРІЗЬ, І ВСЕРЕДИНУ ТЕЖ.
    # Це ТОЙ САМИЙ прогін, просто його внутрішній круг, тому актор — той самий.
    # Другого джерела правди про «хто діє» не заводимо: 06.08 цей виклик лишився
    # без актора й валив Будівника TypeError'ом — див. builder_actor_test.
    inner = run_system(actor, system, task, files_context=files_context, history=history,
                       precheck=False, emit=emit, style=style, depth=depth,
                       should_cancel=should_cancel, allow_real_build=False, meta_mode=True)
    if inner.get("status") != "completed":
        return inner  # needs_input / cancelled / error — віддаємо як є

    # 2) Беремо СИРИЙ вивід Структуролога (JSON), а не зібраний фінал: складальник
    #    переписує все у Markdown і може прибрати JSON-блок.
    struct_raw = ""
    trace = inner.get("agent_trace") or []
    for t in reversed(trace):
        if "AgentStructureCreator" in (t.get("agent") or ""):
            struct_raw = t.get("output") or ""
            break
    if not struct_raw and trace:
        struct_raw = trace[-1].get("output") or ""

    # 2б) Повні тексти промптів — з БЛОКІВ Райтера (контракт «дані → рендер»):
    # Структуролог віддає легку структуру з content_from, щоб великий кириличний/
    # багатоагентний вміст не рвав JSON лімітом ходу (корінь обриву 10.07 ~21:30).
    writer_raw = ""
    for t in reversed(trace):
        if "AgentPromptWriter" in (t.get("agent") or ""):
            writer_raw = t.get("output") or ""
            break

    # 3) Детермінована матеріалізація на диск + реєстрація.
    import builder
    # 3а) ДОЗАПИТ відсутніх блоків Райтера — ПО ОДНОМУ за хід (10.07 ~23:00:
    # 5 повних промптів не влазять в один хід; правило — розмір системи не
    # залежить від жодного одиничного ходу). Один блок завжди влазить у стелю.
    sources = builder.parse_prompt_blocks(writer_raw)
    # Список агентів — з КРИХІТНОЇ, стійкої до обриву структури (+ салваж із блоків
    # Райтера й шляхів). Розкладку файлів будує сервер детерміновано; крихкий
    # великий JSON files_to_create більше НЕ на критичному шляху (корінь
    # «непарсабельний JSON» 10.07 ~23:28).
    meta = builder.parse_build_meta(struct_raw, writer_raw)
    needed = ["MAIN"] + [a for a in (meta.get("agents") or []) if a and a != "MAIN"]
    if any(i not in sources for i in needed):
        wprompt = (_load_agent_prompt(system, "AgentPromptWriter")
                   or _synth_agent_prompt(system, "AgentPromptWriter",
                                          "писати повні системні промпти агентів"))

        def _ask_block(mid):
            ask = (
                f"## TASK (the system being built)\n{task[:6000]}\n\n"
                f"## YOUR EARLIER OUTPUT (some blocks were cut off by the turn limit)\n"
                f"{(writer_raw or '')[-10000:]}\n\n"
                f"## REFILL REQUEST (deterministic, one block only)\n"
                f"Your earlier output is missing the prompt block for agent id={mid}. "
                f"Write the COMPLETE English system prompt for this agent, consistent "
                f"with the agents you already wrote (role, place in pipeline, inputs, "
                f"outputs, quality checks, response format). Output EXACTLY ONE machine "
                f"block and NOTHING else:\n"
                f"<<<AGENT_PROMPT id={mid}>>>\n...full prompt text...\n<<<END_AGENT_PROMPT>>>"
            )
            return llm.complete(wprompt, ask, temperature=0.2,
                                model=config.worker_model(),
                                max_tokens=config.BUILDER_MAX_TOKENS)

        sources = builder.refill_missing_blocks(needed, sources, _ask_block,
                                                emit=lambda s: _emit(emit, s))
    _emit(emit, "🏗️ Матеріалізую систему на диск (файли + реєстрація)…")
    b = builder.materialize_from_agents(meta, sources, task, emit)
    if not b.get("ok"):
        reason = b.get("note", "") or "невідома причина"
        # ОГЛЯДОВІСТЬ (10.07.2026, вечір): точна причина відмови матеріалізації має
        # доходити до людини Й на диск, а не ховатись за переказом мозку (кейс ~22:50
        # 10.07: мозок проковтнув причину й вигадав «обхід через build_system»).
        # 1) емітимо причину в панель прогресу ДОСЛІВНО (повз мозок);
        _emit(emit, f"❌ Матеріалізація ВІДХИЛЕНА: {reason}")
        # 2) пишемо протокол невдалого білда у runs/_build_failures.jsonl (конвенція _audit.jsonl).
        try:
            from datetime import datetime as _dt
            rec = {
                "ts": _dt.now().isoformat(),
                "task": (task or "")[:500],
                "reason": reason,
                "agents_detected": (meta.get("agents") if isinstance(meta, dict) else None),
                "have_prompt_ids": sorted((sources or {}).keys()),
                "struct_raw_tail": (struct_raw or "")[-4000:],
                "writer_raw_tail": (writer_raw or "")[-4000:],
            }
            with open(config.RUNS_DIR / "_build_failures.jsonl", "a", encoding="utf-8") as _f:
                _f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        except Exception as _e:
            import sys as _sys
            _sys.stderr.write(f"[build-fail-log] не зміг записати протокол: {_e}\n")
        inner["status"] = "runtime_error"
        inner["client_safe"] = True   # текст нижче написаний ДЛЯ ЛЮДИНИ (див. failure.result_text)
        inner["final_markdown"] = (
            "❌ Агенти спроєктували систему, але детермінована матеріалізація ВІДХИЛИЛА "
            f"результат. Точна причина: **{reason}**.\n\n"
            "Нічого не створено. ⚠ Це НЕ тимчасовий «збій рантайму» — повторний запуск тим "
            "самим шляхом дасть ту саму помилку. Передай користувачу точну причину вище "
            "ДОСЛІВНО і зупинись. НЕ пропонуй «обхід через build_system» (це ті самі двері) "
            "і НЕ повторюй побудову в цьому ж ході."
        )
        return inner

    # 4) Замок чесності: підтвердити РЕАЛЬНІ артефакти.
    from pathlib import Path as _Path
    sid = b.get("system_id", "")
    project_path = b.get("project_path", "")
    in_registry = any(s.get("id") == sid for s in registry.load_systems())
    folder_ok = bool(project_path) and _Path(project_path).exists()
    if not (in_registry and folder_ok):
        inner["status"] = "runtime_error"
        inner["client_safe"] = True   # текст нижче написаний ДЛЯ ЛЮДИНИ (див. failure.result_text)
        inner["final_markdown"] = ("❌ Перевірка НЕ підтвердила артефакти "
            f"(реєстр: {'є' if in_registry else 'нема'}, папка: {'є' if folder_ok else 'нема'}). "
            "Створення скасовано як недоведене.")
        return inner

    name = (b.get("registry_entry") or {}).get("name", sid)
    inner["system_id"] = sid
    # ⭐⭐⭐ 07.08.2026. МАШИННИЙ ФАКТ СТВОРЕНОГО — не текст, не переказ.
    # Корінь, який це лікує (живий прогін 07.08 ~15:03): Будівник СПРАВДІ збудував
    # систему на диску, а ворота приймання судили ТЕКСТ супроводу — і оголосили
    # «роботи не зроблено, файли не створювались». Мозок чесно переказав вирок,
    # людина побачила провал замість зробленої роботи.
    # Клас: продукт прогону не завжди є текстом чи файлом у теці прогону; коли
    # платформа не має МАШИННОГО факту про створене, останнє слово лишається за
    # думкою судді про текст. Факт, доведений диском, важчий за думку про текст.
    # Хто пише факт: ТОЙ, ХТО СТВОРИВ І ПЕРЕВІРИВ (тут — замок чесності вище).
    inner.setdefault("created", []).append({
        "kind": "system",
        "id": sid,
        "name": name,
        "address": str(project_path),
        "files": len(b.get("files", []) or []),
        "proof": "запис у реєстрі та папка перевірені на диску",
    })
    # Текст для ЛЮДИНИ рендерить КОД (один писар для всіх видів створеного).
    inner["final_markdown"] = created_report_markdown(inner["created"])
    # ⭐ Службові вказівки мозкові НЕ живуть у тексті результату: 07.08 рядок
    # «НЕ перебудовуй її автоматично» доїхав до людини переказом «платформа
    # заблокувала повторну побудову». Тепер у мозку окреме поле, у людини — своє.
    inner["brain_note"] = (
        "Систему СТВОРЕНО (needs_review) і показано користувачу кодом. НЕ запускай "
        "smoke test і НЕ перебудовуй її автоматично; не заходь у цикл "
        "побудова→тест→перебудова. Твоя відповідь — одне коротке речення-супровід."
    )
    _emit(emit, "✅ Систему створено й перевірено на диску.")
    return inner


def run_system(actor, system: dict, task: str, files_context: str = "", history=None, precheck=True,
               emit=None, style: str = "", depth: str = "full", should_cancel=None,
               allow_real_build: bool = True, meta_mode: bool = False,
               intent: dict = None, resume: dict = None, model_floor: str = "") -> dict:
    # model_floor: не використовувати щаблі драбини, ДЕШЕВШІ за названий. Ставить
    # ланцюг систем на другій спробі кроку (chains.may_retry).
    if model_floor:
        _FLOOR.model = model_floor
    else:
        _FLOOR.model = ""
    # depth: "full" — повний конвеєр із циклом якості (за замовчуванням);
    #        "quick" — конвеєр один раз, без раундів критика (швидко, для простих задач).
    # СПЕЦ-МАРШРУТ: «Будівник систем» має СПРАВДІ будувати, а не лише описувати.
    # allow_real_build=False лишає стару «балакучу» поведінку (для smoke-тесту, щоб
    # тестовий прогін не створював реальних систем).
    # ⭐⭐⭐ ВОРОТА 1 «ЧИ МОЖНА ЗАРАЗ ПРАЦЮВАТИ» (07.08.2026, бізнес-модель).
    # Стоять ПЕРЕД воротами «хто діє», бо право платформи ширше за право людини:
    # коли користування припинено, питання «хто саме діє» вже не має значення.
    # Відповідь дає ОДИН автор — `license.work_allowed()`, який знає про моделі
    # оплати: у моделі A строк абонплати минув, а працювати можна далі.
    # Раніше ця перевірка стояла ЛИШЕ в мозку (`agent._impl_run_system`), тобто
    # повз неї роботу запускали розклад, ланцюги, телеграм і smoke-тест —
    # той самий клас «ворота лише на першому вході».
    import license as _lic
    _ok_pay, _why_pay = _lic.work_allowed()
    if not _ok_pay:
        _emit(emit, "⛔ Користування призупинено")
        return honest_stop_result(
            system, kind="subscription_expired", reason=_why_pay,
            action="поновіть підписку — після оплати робота продовжиться без втрат",
            markdown=("## Роботу не запущено: користування призупинено\n\n%s\n\n"
                      "Дані й напрацювання лишаються на місці." % _why_pay))

    # ⭐⭐⭐ ВОРОТА 2 «ХТО ЗАПУСКАЄ» (крок 1.5 Task Desk, 06.08.2026).
    # Стоять ПЕРШОЮ дією єдиної точки запуску: усі чотири канали (консоль,
    # ланцюги, телеграм, розклад) проходять саме тут. Актор — обовʼязковий
    # аргумент без значення за замовчуванням, тому канал, який його не передасть,
    # ламається голосно, а не працює тихо «від нікого».
    import taskdesk_identity as _tdid
    _may, _why_no = _tdid.may_run_system(actor, (system or {}).get("id") or "")
    if not _may:
        _emit(emit, "⛔ Немає права запускати цю систему")
        return honest_stop_result(
            system, kind="access_denied", reason=_why_no,
            action=("увійдіть під своїм працівником або попросіть адміністратора "
                    "відкрити доступ до цієї системи в розділі «Доступи»"),
            markdown=("## Роботу не запущено: немає права\n\n%s\n\n"
                      "Платформа не виконує роботу від нікого — інакше за результат "
                      "не відповідає ніхто, а платить власник." % _why_no))

    if allow_real_build and (system or {}).get("id") == "system_builder":
        return _build_for_real(actor, system, task, files_context, history, emit, style, depth, should_cancel)

    convo = _convo(history)

    # КОНТРАКТ НАМІРУ (від мозку) + ПАСПОРТ РОЛЕЙ (від системи). Інструмент кроку
    # вмикається лише на перетині: роль вміє І контракт вимагає. Keyword-вгадувачок
    # більше немає — див. DESIGN_Контракт_наміру.md (10.07.2026).
    intent = _norm_intent(intent)
    roles = registry.get_roles(system)

    # 1) ОСМИСЛЕННЯ
    _emit(emit, "🧠 Осмислюю логіку системи…")
    plan = comprehend_system(system)
    _emit(emit, f"🧩 План готовий: {len(plan.get('pipeline', []))} етап(ів)")

    needs_calc = (not meta_mode) and intent["computation"] == "required"
    fresh_required = (not meta_mode) and intent["fresh_data"] == "required"
    wants_model = (not meta_mode) and intent["output"] == "financial_model"
    _out_label = {"chat_answer": "відповідь", "document": "документ",
                  "estimate_sheet": "таблиця-оцінка", "financial_model": "фінмодель",
                  "report": "звіт"}.get(intent["output"], intent["output"])
    if not meta_mode:
        _emit(emit, f"📋 Намір: свіжі дані {'✓' if fresh_required else '✗'}, "
                    f"розрахунок {'✓' if needs_calc else '✗'}, результат: {_out_label}")

    # ⭐⭐⭐ 05.08.2026. ВОРОТА ТЕНДЕРАЙТЕРА №1 — ДО ВИТРАТ.
    # Пакет документів для подачі мусить спиратися на оголошення замовника.
    # Немає документів у матеріалах — роботи немає: саме так 05.08 клієнт отримав
    # «шаблони з голови» від системи, яка не бачила жодного паперу замовника.
    if (system or {}).get("id") == tender_pack.SYSTEM_ID and tender_pack.enabled():
        _tp = tender_pack.customer_docs_present(files_context or "")
        if not _tp.get("ok"):
            _emit(emit, "⛔ Немає документів закупівлі — пакет не збираю")
            return honest_stop_result(
                system, kind="tender_pack_no_docs", reason=_tp.get("reason", ""),
                action=("вкажіть номер закупівлі (UA-…) або посилання на неї — "
                        "платформа візьме оголошення й додатки з Прозорро сама"),
                markdown=tender_pack.stop_text(_tp.get("reason", "")), intent=intent)

    # 2) УТОЧНЕННЯ
    _gate_degraded = ""
    _blank_questions = []
    if precheck:
        _emit(emit, "❓ Перевіряю, чи достатньо вхідних даних…")
        gate = precheck_inputs(system, plan, task, files_context, history,
                               needs_calc=needs_calc)
        # ⛔ 30.07.2026. Крок 9 закону (питати, доки не досить) не може відбутися,
        # якщо перевірка достатності НЕ ВИКОНАЛАСЬ. Раніше такий збій мовчки
        # ставав «даних вистачає» — і система бралася робити наосліп.
        if not gate.get("checked", True):
            _why = gate.get("error")
            if isinstance(_why, Exception) and failure.is_budget(_why):
                # Межа вартості — не аварія і не стоп: у неї свій шлях.
                return {"status": "runtime_error",
                        "final_markdown": failure.client_text(_why, "executor/precheck"),
                        "failure": "budget", "client_safe": True,
                        "agent_trace": [], "system_id": system.get("id")}
            _reason = ("не вдалося перевірити, чи вистачає вхідних даних: %s"
                       % (_why if isinstance(_why, str) else failure.classify(_why)))
            if _gate_must_be_strict(system, intent):
                _emit(emit, "🛑 Не можу перевірити, чи вистачає вхідних даних — "
                            "зупиняюсь чесно, а не берусь наосліп.")
                llm._log("[executor] precheck НЕ виконано (%s) — чесний стоп" % _reason)
                return honest_stop_result(
                    system, kind="precheck_impossible", reason=_reason,
                    action=("повтори запит за хвилину; якщо повторюється — перевір ключ і "
                            "доступність моделі виконавця в налаштуваннях"),
                    markdown=(
                        "## Не можу почати: не вдалося перевірити, чи вистачає даних\n\n"
                        "Перед запуском система звіряє, чи є все потрібне для якісного "
                        f"результату. Цю перевірку зараз виконати не вдалося ({_reason}).\n\n"
                        "Щоб не вводити тебе в оману, я НЕ берусь робити наосліп: раніше в "
                        "такій ситуації платформа вирішувала, що «даних вистачає», і видавала "
                        "результат, побудований на припущеннях.\n\n"
                        "**Що можна зробити:**\n\n"
                        "- повтори запит за хвилину — збій міг бути тимчасовим;\n"
                        "- якщо повторюється — перевір ключ і доступність моделі виконавця "
                        "в налаштуваннях.\n"),
                    intent=intent, plan=plan)
            # Не суворо — ЗБІЙ ПЕРЕВІРКИ НЕ МАЄ ПРАВА ЗАБИРАТИ В КЛІЄНТА РОБОТУ.
            _gate_degraded = _reason
            _emit(emit, "⚠ Перевірку достатності даних виконати не вдалось — "
                        "працюю з тим, що є, і чесно напишу про це в результаті.")
            llm._log("[executor] precheck НЕ виконано (%s) — працюю далі із застереженням" % _reason)
            audit.log_refusal("gate_degraded", system.get("id"), [], _reason)
        if (not _gate_degraded) and (not gate.get("ready")):
            # ПИТАННЯ ВИДНО ЛЮДИНІ І ЛИШАЄ СЛІД. Раніше вони доїжджали ЛИШЕ
            # рядком-інструкцією мозку: якщо мозок їх переказував по-своєму або
            # ковтав — уточнення зникало без сліду.
            for _q in gate["questions"]:
                _emit(emit, "❓ Потрібне уточнення: %s" % _q)
            llm._log("[executor] needs_input (%s): %s"
                     % (system.get("id"), " | ".join(gate["questions"])))
            # ⭐⭐⭐ 05.08.2026. ПИТАННЯ, ЯКЕ НЕ МУСИТЬ ЗУПИНЯТИ РОБОТУ.
            # Є системи, чий артефакт існує з порожніми графами (тендерний пакет —
            # це бланки). Для них зупинка з питанням коштувала клієнту подвійної
            # оплати: план і читання документів робились удруге після відповіді.
            # Тепер питання не вбиває прогін — воно стає рядком у результаті.
            if tender_pack.blanks_ok(system.get("id")):
                _blank_questions = list(gate["questions"])
                _emit(emit, "📝 Бракує даних учасника — не зупиняюсь: винесу їх "
                            "у «заповнити перед подачею»")
                llm._log("[executor] питання не блокують (%s): %d шт."
                         % (system.get("id"), len(_blank_questions)))
            else:
                return {"status": "needs_input", "questions": gate["questions"],
                        "system_id": system.get("id"), "agent_trace": [],
                        "understanding": plan.get("system_understanding", "")}

    pipeline = plan["pipeline"]
    trace = []
    # Правова задача має власну (вищу) стелю — визначає ПАСПОРТ системи.
    _legal_mode = _is_legal_system(system)
    # ⭐ 30.07.2026. РЕЖИМ ПРОЦЕДУРИ РЕЗОЛВИМО ОДИН РАЗ — ДО конвеєра, а не лише
    # на воротах виходу. Раніше режим знало тільки ядро на виході: агент його не
    # бачив, вигадував свій («відкриті торги з особливостями» замість спрощеної)
    # і будував на ньому весь перелік документів. Тепер та сама позиція їде
    # агенту як ФАКТ і вона ж (без другої резолюції) працює на воротах.
    legal_pos = None
    _legal_note = ""
    if _legal_mode and _legal_jurisdiction(task) == "UA":
        legal_pos = _resolve_legal_pos(task, history)
        _legal_note = _legal_regime_block(legal_pos)
        _brief = (legal_pos or {}).get("brief") or {}
        if _brief.get("ok"):
            _emit(emit, "⚖ Режим процедури встановлено ядром: %s — агенти працюють "
                        "саме за ним." % ((_brief.get("pos") or {}).get("label") or "—"))
    _cap = _run_cap(meta_mode, _legal_mode)
    accumulated = ""
    all_sources = []
    # ⏸ ПРОДОВЖЕННЯ ПІСЛЯ ПАУЗИ ЗА ВАРТІСТЮ (28.07.2026). Клієнт уже оплатив
    # напрацьоване — тому воно повертається на місце, а не рахується заново.
    _start_idx = 1
    if resume:
        plan = resume.get("plan") or plan
        pipeline = plan.get("pipeline") or pipeline
        trace = list(resume.get("trace") or [])
        accumulated = resume.get("accumulated") or ""
        all_sources = list(resume.get("all_sources") or [])
        _start_idx = int(resume.get("next_idx") or 1)
        if resume.get("choice") == "assemble":
            _start_idx = len(pipeline) + 1      # нових кроків не робимо взагалі
        if resume.get("new_cap"):
            _cap = float(resume["new_cap"])
        _emit(emit, "⏸ Продовжую з місця зупинки — уже зроблене не переробляю "
                    "і вдруге не рахую.")
    # Стеля їде вниз, до самого лічильника грошей: мʼяка зупинка нижче тримає
    # НОВІ кроки, а costs/llm не дають одному кроку втекти в космос (28.07.2026).
    try:
        costs.set_run_cap(_cap)
    except Exception:
        pass
    web_gaps = []   # зриви живої звірки на ролях web="always" (інваріант, не побажання)
    # Кому дістаються інструменти (перетин контракту з паспортом; паспорт існує
    # ЗАВЖДИ — get_roles сіє на льоту, тому порожні tools = СВІДОМА декларація):
    # • калькулятор — ролям із tools.calculator; якщо жодна роль його не декларує,
    #   а контракт вимагає — всім, крім критика (інакше добірка needs_capability
    #   не мала б ефекту в командах без рахувальника);
    # • веб — СТРОГО задекларованим ролям: "always" (інваріант, напр. юр-звіряч
    #   норм) або "per_intent" (лише коли контракт вимагає свіжих даних). БЕЗ
    #   fallback: роль без web не шукає ніколи (вбиває клас «веб на Будівнику»).
    #   Підказка планувальника needs_web_search — лише РОЗМІЩЕННЯ, не ворота.
    # ⭐⭐⭐ 09.08.2026. ВОРОТА НА ПЛАНI: ПОШУКОВА РОЛЬ НЕ СМIЄ ЗАГУБИТИСЬ.
    # 🩸 ЖИВИЙ ПРОВАЛ: рекрутингова видала двох кандидатiв iз вигаданими адресами
    # work.ua/resumes/40123456 i /40234567. Ворота вебу стояли на РОЛI — але мозок
    # склав план БЕЗ ролi AgentSearching, тобто охоронця поставили до дверей, у якi
    # нiхто не заходив. Модель домалювала данi з голови.
    # ⭐ ЗДАТНIСТЬ, ЯКОЇ НЕМАЄ В ПЛАНI, ДЛЯ ПРОГОНУ НЕ IСНУЄ.
    # РIШЕННЯ (без вгадування «чи треба шукати»): якщо система МАЄ пошукову роль,
    # а план її не взяв — право вийти в мережу дiстає ПЕРШИЙ дослiдницький крок
    # плану (а як таких немає — перший крок узагалi). Вартiсть та сама: web_done
    # тримає РIВНО ОДИН веб-крок на прогiн.
    _web_roles = {a for a, r in (roles or {}).items()
                  if ((r or {}).get("tools") or {}).get("web")}
    _plan_has_web = any((st.get("agent") or "") in _web_roles for st in pipeline)
    _web_orphan_idx = None
    if _web_roles and not _plan_has_web and pipeline:
        _web_orphan_idx = 0
        for _i, _st in enumerate(pipeline):
            _k = ((roles or {}).get(_st.get("agent") or "") or {}).get("kind")
            if _k == "research":
                _web_orphan_idx = _i
                break
        import sys as _wo
        _wo.stderr.write("[web] PLAN HAS NO SEARCH ROLE (system can search: %s) - "
                         "web right granted to step %d (%s)\n"
                         % (", ".join(sorted(_web_roles)), _web_orphan_idx + 1,
                            (pipeline[_web_orphan_idx] or {}).get("agent")))

    calc_agents = {s.get("agent", "") for s in pipeline
                   if _role_tools(roles, s.get("agent", "")).get("calculator")}
    web_done = False
    if needs_calc:
        _emit(emit, "🧮 Числова задача: розрахунки виконуються калькулятором, не «в умі»")
    route_diag = None   # діагностика маршрутного двигуна → у run.json (гучний фейл, не тиша)
    cond_diag = None    # слід живого веб-пошуку УМОВ (обмеження в'їзду) → у run.json
    seo_page, seo_facts, seo_diag = (("", None, None) if meta_mode
                                     else _seo_page_block(system, task, roles))
    # ЧЕСНИЙ СТОП SEO замість ФАНТАЗІЇ (дзеркало маршрутного стопу нижче): якщо це
    # SEO-задача, але сторінку НЕ прочитано впевнено (редірект на іншу / недоступна /
    # порожня JS-оболонка) — НЕ запускаємо агентів і НЕ домальовуємо аудит «з голови».
    if seo_diag is not None and not seo_diag.get("read_ok"):
        _reason = seo_diag.get("reason") or "сторінку не вдалося прочитати"
        _emit(emit, "🛑 Сторінку не прочитано впевнено — віддаю чесний стоп, а не аудит з голови.")
        honest_md = (
            "## Не можу зробити SEO-аудит: сторінку не прочитано\n\n"
            f"Я не зміг впевнено відкрити саме ту сторінку, яку ти дав. **Причина:** {_reason}.\n\n"
            "Щоб не вводити тебе в оману, я НЕ роблю аудит «з голови» — без реального вмісту "
            "сторінки будь-які висновки про заголовки, тексти, schema чи мета-теги були б "
            "вигадані.\n\n"
            "**Що можна зробити:**\n\n"
            "- перевір, чи адреса відкриває саме потрібну сторінку (не share-лінк і не "
            "перенаправлення на головну/вхід);\n"
            "- якщо сторінка під паролем або рендериться через JavaScript — дай прямий "
            "доступ чи сам HTML сторінки;\n"
            "- або повтори запит трохи згодом, якщо збій був тимчасовий.\n"
        )
        return honest_stop_result(
            system, kind="seo_page_unread", reason=_reason,
            action=("перевір адресу сторінки (без редіректів і share-лінків), дай прямий "
                    "доступ або сам HTML — і повтори запит"),
            markdown=honest_md, intent=intent, plan=plan,
            seo_read=seo_diag)     # слід дії у run.json (анти-«обман»)
    if seo_page:
        _emit(emit, "🔗 Читаю реальну сторінку структуровано (title/meta/H/schema/alt)…")
        # Той самий слот фактів: доклад реальну ШВИДКІСТЬ (Google PageSpeed), щоб поради
        # про швидкість/CWV спиралися на вимір, а не на здогад «якщо видно з коду».
        _speed, _speed_diag = (_speed_block(seo_diag)
                               if (seo_diag or {}).get("role_page_read") else ("", None))
        if _speed:
            seo_page = seo_page + "\n\n" + _speed
            _emit(emit, "⚡ Виміряв реальну швидкість сторінки (Google PageSpeed).")
        elif _speed_diag and not _speed_diag.get("ok"):
            _emit(emit, "⚡ Швидкість не виміряно (PageSpeed недоступний) — "
                        "стратег напише «не виміряно», не вигадає цифр.")
        if isinstance(seo_diag, dict):
            seo_diag["speed"] = _speed_diag
    elif not meta_mode:
        # Той самий слот інжекту реальних даних, інша система: маршрутний двигун
        # підкладає РЕАЛЬНИЙ шлях (замість «пригадування» моделлю).
        _rb, route_diag = _route_block(system, task)
        if _rb:
            seo_page = _rb
            _res = (route_diag or {}).get("result") or {}
            if _res.get("ok"):
                _h = int(_res.get("duration_h") or 0)
                _m = round(((_res.get("duration_h") or 0) - _h) * 60)
                _emit(emit, f"🗺 Двигун побудував РЕАЛЬНИЙ маршрут (Google): "
                            f"{_res.get('distance_km', '?')} км, ~{_h} год {_m} хв.")
            else:
                _emit(emit, f"⚠ Маршрутний двигун НЕ побудував маршрут: "
                            f"{(route_diag or {}).get('reason', 'причина невідома')}. "
                            "Маршрут із памʼяті НЕ вигадую — у звіті буде чесна позначка.")
        elif route_diag is not None:
            # Система маршрутів, але розбір не виділив звідки/куди — теж голосно, не мовчки.
            _emit(emit, f"⚠ Маршрутний двигун не запускався: "
                        f"{(route_diag or {}).get('reason', 'не розпізнано звідки/куди')}. "
                        "З памʼяті маршрут НЕ вигадую.")

    # ЧЕСНИЙ СТОП замість ФАНТАЗІЇ. Для системи маршрутів: якщо РЕАЛЬНОГО шляху немає
    # (двигун недоступний / розбір без звідки-куди) — НЕ віддаємо вигаданий звіт. Раніше
    # фінальний збирач домальовував маршрут «з памʼяті» під позначками [ОЦІНКА] — чесні
    # мітки, брехливий зміст. Тут ми зупиняємось коротким чесним поясненням. ВИНЯТОК:
    # не-дорожній спосіб (авіа/потяг/автобус) — це НЕ збій двигуна, там далі веб-пошук.
    if route_diag is not None:
        _rres = route_diag.get("result")
        _is_non_road = isinstance(_rres, dict) and _rres.get("mode") == "non_road"
        _route_built = isinstance(_rres, dict) and _rres.get("ok")
        # ⭐⭐⭐ 09.08.2026. НЕ КОЖНА ЗАДАЧА ЦIЄЇ СИСТЕМИ — ПРО ПОБУДОВУ МАРШРУТУ.
        # Живий випадок: «знайди кафе на вiдтинку М-03 мiж Решетилiвкою та
        # Лубнами, таблиця Назва|Адреса|Години» — маршрут тут НЕ потрiбен, потрiбен
        # веб-пошук. Розбiрник вiддав порожнi start/end (його питають «звiдки
        # ВИЇЗД i куди ЇДЕШ»), i повний стоп убив роботу, яку легко зробити.
        # Стоп лишається там, де вiн має сенс: маршрут ЗАМОВЛЕНО (є звiдки/куди),
        # але двигун його не дав. Немає звiдки/куди — це не маршрутна задача.
        _route_asked = bool((route_diag or {}).get("parsed", {}).get("start")
                            or (route_diag or {}).get("parsed", {}).get("end"))
        if (not _route_built) and (not _is_non_road) and _route_asked:
            _reason = route_diag.get("reason") or "маршрутний двигун недоступний"
            _emit(emit, "🛑 Реального маршруту немає — віддаю чесний стоп, а не вигаданий звіт.")
            honest_md = (
                "## Не можу побудувати реальний маршрут\n\n"
                f"Маршрутний двигун зараз не дав реального шляху. **Причина:** {_reason}.\n\n"
                "Щоб не вводити тебе в оману, я НЕ малюю маршрут, відстані, час і точки "
                "зупинок «з памʼяті» — вони були б вигадані. Реальні дані (траса, кілометри, "
                "час, АЗС і заклади за рейтингом) можна дати лише зі справжнього "
                "картографічного джерела.\n\n"
                "**Що можна зробити:**\n\n"
                "- повторити запит трохи згодом, якщо збій був тимчасовий;\n"
                "- або підключити надійне джерело маршрутів — тоді звіт будуватиметься "
                "з реальних даних, а не з припущень.\n"
            )
            return honest_stop_result(
                system, kind="route_not_built", reason=_reason,
                action=("повтори запит трохи згодом (якщо збій тимчасовий) або підключи "
                        "надійне джерело маршрутів — тоді звіт будується з реальних даних"),
                markdown=honest_md, intent=intent, plan=plan,
                route_engine=route_diag)

    # ЖИВІ УМОВИ: маршрут побудовано — якщо запит просить обмеження/дорожню обстановку,
    # платформа САМА робить ОДИН живий веб-пошук і підкладає реальні умови+джерела як факт
    # (той самий слот, що маршрут/зупинки). Слід дії (checked/used_search/sources) → run.json.
    if route_diag is not None:
        _cb, cond_diag = _conditions_block(system, task, route_diag)
        if _cb:
            seo_page = (seo_page + "\n" + _cb) if seo_page else _cb
            if (cond_diag or {}).get("sources"):
                _emit(emit, f"🚧 Живі умови перевірено веб-пошуком: {cond_diag['sources']} джерел.")
            else:
                _emit(emit, "🚧 Живі умови: веб актуальних даних не дав — у звіті буде "
                            "чесне «не перевірено», не «обмежень нема».")

    if meta_mode:
        _emit(emit, "🧱 Мета-режим Будівника: без веб-пошуку, калькулятора й фінальної збірки.")

    # 3) ВИКОНАННЯ ЗА ПЛАНОМ
    for idx, step in enumerate(pipeline, 1):
        if should_cancel and should_cancel():
            _emit(emit, "⏹ Зупинено на ваш запит.")
            return {"status": "cancelled", "final_markdown": "", "agent_trace": trace,
                    "system_id": system.get("id")}
        if idx < _start_idx:
            continue                      # цей етап уже оплачений і зроблений
        if _over_cap(_cap):
            # ⏸ НЕ обриваємо і НЕ витрачаємо більше. Ставимо на паузу, зберігаємо
            # напрацьоване й даємо КЛІЄНТУ вибір (вимога Андрія 28.07.2026).
            _spent = float(costs.current_run().get("usd", 0.0))
            _left = [s.get("agent", "") for s in pipeline[idx - 1:]]
            _rid = ""
            try:
                import run_state as _rs
                _rid = _rs.save({"system_id": system.get("id"), "task": task,
                                 "plan": plan, "trace": trace,
                                 "accumulated": accumulated, "all_sources": all_sources,
                                 "next_idx": idx, "style": style, "depth": depth,
                                 "files_context": files_context, "intent": intent,
                                 "cap": _cap, "spent": _spent})
            except Exception as e:
                llm._log("[executor] пауза за вартістю не збереглась: %s" % e)
            _emit(emit, f"⏸ Досягнуто межу вартості (${_cap:.2f}). Роботу поставлено "
                        f"на паузу — далі нічого не витрачаю, чекаю на ваше рішення.")
            return {"status": "paused_budget", "final_markdown": "",
                    "agent_trace": trace, "system_id": system.get("id"),
                    "run_id": _rid, "spent_usd": round(_spent, 2), "cap_usd": _cap,
                    "done_steps": idx - 1, "total_steps": len(pipeline),
                    "left_agents": _left, "resumable": bool(_rid)}
        aid = step.get("agent", "")
        role_web = _role_tools(roles, aid).get("web")
        # ВОРОТА ВЕБУ = контракт × паспорт: "always" — завжди (інваріант ролі);
        # "per_intent" — лише якщо контракт вимагає свіжих даних. Розміщення кроку —
        # за підказкою плану, з гарантією першого web-здатного кроку.
        _step_web = False
        _web_ready = config.web_search_ready()
        if (not meta_mode) and _web_ready:
            _step_web = _step_web_allowed(role_web, fresh_required, step, web_done)
            # План загубив пошукову роль — право дiстає цей крок (див. ворота вище).
            if (not _step_web) and (_web_orphan_idx is not None) \
                    and (idx - 1) == _web_orphan_idx and not web_done:
                _step_web = True
        # ⭐⭐⭐ 09.08.2026. РIШЕННЯ ПРО ВЕБ БIЛЬШЕ НЕ ТИХЕ. Три прогони поспiль
        # поверталися без жодного пошуку, i в журналi не було НI СЛОВА про те, чому.
        # Тихе рiшення = невидимий дефект: я гадав замiсть того, щоб прочитати.
        import sys as _sw
        _sw.stderr.write("[web] step=%s role=%s passport=%r intent_fresh=%s already=%s "
                         "provider=%s -> %s\n"
                         % (idx, aid, role_web, fresh_required, web_done, _web_ready,
                            "SEARCH" if _step_web else "NO SEARCH"))
        if _step_web:
            web_done = True
            _emit(emit, f"🌐 {aid}: живий веб-пошук…")
        else:
            _emit(emit, f"▶ {aid} ({idx}/{len(pipeline)})…")
        # ІНВАРІАНТ ЖИВОЇ ЗВІРКИ (web="always", напр. юр-звіряч норм): збій пошуку
        # НЕ ковтається (юрист 10.07 ~23:40 — тиша в stderr): 1 повтор → гучне ⚠ →
        # прапорець web_gaps → межа видачі примусово ставить «непідтверджено».
        live_data, step_sources, _wfail = ("", [], "")
        if _step_web:
            live_data, step_sources, _wfail = _gather_live_data(task, step, system, force=True)
            if not live_data and role_web == "always":
                _emit(emit, f"🔁 {aid}: жива звірка не вдалася ({(_wfail or '?')[:100]}) — повторюю…")
                live_data, step_sources, _wfail = _gather_live_data(task, step, system, force=True)
            if not live_data and role_web == "always":
                _emit(emit, f"⚠ {aid}: ЖИВА ЗВІРКА ДЖЕРЕЛ НЕ ВИКОНАНА "
                            f"({(_wfail or 'причина невідома')[:140]}) — результат буде "
                            "позначено непідтвердженим.")
                web_gaps.append(f"{aid}: {_wfail or 'причина невідома'}")
        elif (not meta_mode) and role_web == "always":
            # Ворота вебу навіть не відкрились (пошук не налаштований/вимкнений) —
            # для інваріантної ролі (юрист-звіряч норм) це зрив звірки. ЧЕСНИЙ СТОП:
            # без живої звірки роль НЕ має права відповідати, інакше кодова модель
            # вивалює само-балаканину замість консультації (зрив 20.07.2026). Не
            # запускаємо модель у місиво — віддаємо коротке зрозуміле пояснення +
            # 10-секундний спосіб перевірити самому.
            _emit(emit, f"⚠ {aid}: жива звірка обовʼязкова для цієї ролі, але веб-пошук "
                        "недоступний — віддаю чесний стоп, а не відповідь із голови.")
            web_gaps.append(f"{aid}: веб-пошук недоступний (не налаштований або вимкнений)")
            honest_md = (
                "## Не можу дати відповідь без живої звірки джерел\n\n"
                f"Ця система зобовʼязана перед відповіддю звірити норми з офіційним "
                f"джерелом наживо (напр. zakon.rada.gov.ua). Зараз веб-пошук недоступний "
                f"для активних моделей, тому звірку виконати неможливо.\n\n"
                "Щоб не вводити тебе в оману, я НЕ відповідаю «з памʼяті»: без реальної "
                "звірки будь-які статті, ставки й строки були б здогадом, поданим як факт.\n\n"
                "**Як увімкнути (перевірка за 10 секунд):** запусти «Diag web conditions.bat» "
                "— має бути `web_search_ready: True`. Якщо `False` — додай ключ пошуко-здатного "
                "провайдера (Gemini/OpenAI/Claude) або признач окремий пошуковий провайдер "
                "(SEARCH_PROVIDER), і повтори запит."
            )
            return honest_stop_result(
                system, kind="live_check_impossible",
                reason=(f"{aid}: жива звірка джерел обовʼязкова для цієї ролі, "
                        "але веб-пошук недоступний (не налаштований або вимкнений)"),
                action=("запусти «Diag web conditions.bat» — має бути web_search_ready: True; "
                        "якщо False — додай ключ пошуко-здатного провайдера або признач "
                        "SEARCH_PROVIDER, і повтори запит"),
                markdown=honest_md, intent=intent, plan=plan, trace=trace,
                web_invariant_gap="; ".join(web_gaps))
        if step_sources:
            all_sources.extend(step_sources)
        # ВОРОТА КАЛЬКУЛЯТОРА = контракт × паспорт.
        step_calc = needs_calc and (aid in calc_agents if calc_agents
                                    else not _looks_critic(aid))
        # ЧЕСНА ДОБIРКА ЖИВИХ ДАНИХ: пропонуємо сигнал ЛИШЕ коли живих даних цьому
        # кроку не дали, а веб у платформи Є. Критику не пропонуємо (його робота -
        # судити вже зроблене, а не ходити у свiт).
        _offer_web_now = bool((not meta_mode) and (not live_data)
                              and (not _looks_critic(aid))
                              and config.web_search_ready())
        try:
            out = _run_agent(system, step, idx, len(pipeline), plan, task, convo,
                             files_context, accumulated, live_data, style,
                             use_calc=step_calc, emit=emit, seo_page=seo_page,
                             offer_capability=(not meta_mode) and not needs_calc,
                             offer_web=_offer_web_now, legal_note=_legal_note)
        except llm.LLMNotConfigured as e:
            # ⭐ 29.07.2026. Сирий виняток більше не стає текстом для людини:
            # переклад робить ОДИН модуль, подробиці лягають у журнал.
            return {"status": "runtime_error",
                    "final_markdown": failure.client_text(e, "executor/%s" % aid),
                    "failure": failure.classify(e), "client_safe": True,
                    "agent_trace": trace, "system_id": system.get("id")}
        except llm.LLMError as e:
            if failure.is_budget(e):
                # Межа вартості — не аварія. У неї свій, уже побудований шлях.
                return {"status": "runtime_error",
                        "final_markdown": failure.client_text(e, "executor/%s" % aid),
                        "failure": "budget", "client_safe": True,
                        "agent_trace": trace, "system_id": system.get("id")}
            return {"status": "runtime_error",
                    "final_markdown": failure.client_text(e, "executor/%s" % aid),
                    "failure": failure.classify(e), "client_safe": True,
                    "agent_trace": trace, "system_id": system.get("id")}
        # ВОРОТА КРОКУ: пробільне виродження ловимо одразу — один повтор кроку,
        # далі чесний збій кроку (а не мовчазне протягування місива конвеєром).
        if _degenerate_step(out):
            _emit(emit, f"⚠ {aid}: вироджений вивід кроку (пробільний цикл) — повторюю крок…")
            try:
                out = _run_agent(system, step, idx, len(pipeline), plan, task, convo,
                                 files_context, accumulated, live_data, style,
                                 use_calc=step_calc, emit=emit, seo_page=seo_page,
                                 offer_capability=(not meta_mode) and not needs_calc,
                                 offer_web=_offer_web_now, legal_note=_legal_note)
            except llm.LLMError:
                out = ""
            if _unusable_step(out):
                # ⛔ 30.07.2026. Тут стояла ПІДМІНА: вивід кроку замінювався рядком
                # «[Збій кроку … Результат ВІДСУТНІЙ]», конвеєр ішов далі, а прогін
                # завершувався як `completed` — тобто робота з ДІРКОЮ всередині
                # їхала клієнту файлами й із зеленим вердиктом. Крок без результату
                # — це обірваний ланцюг, а не дрібна незручність: складальник
                # добудує пропуск текстом, і людина цього не побачить.
                _emit(emit, f"⛔ {aid}: крок двічі видав вироджений вивід — "
                            "зупиняюсь чесно, а не добудовую результат без нього.")
                _reason = (f"крок «{aid}» двічі видав вироджений вивід (пробільний цикл), "
                           "повтор не допоміг — результату цього кроку НЕМАЄ")
                honest_md = (
                    "## Не можу видати результат: один з етапів не дав нічого\n\n"
                    f"Етап **{aid}** двічі повернув порожній (вироджений) вивід, повтор не "
                    "допоміг. Далі по ланцюгу цей етап потрібен, тому я зупиняюсь.\n\n"
                    "Щоб не вводити тебе в оману, я НЕ збираю відповідь без нього: "
                    "складальник просто заповнив би пропуск загальними словами, і в "
                    "документі була б дірка, якої не видно.\n\n"
                    "**Що можна зробити:**\n\n"
                    "- повтори запит — вироджений вивід часто разовий;\n"
                    "- або переключи модель виконавця на надійнішу і повтори.\n"
                )
                return honest_stop_result(
                    system, kind="step_no_result", reason=_reason,
                    action=("повтори запит або переключи модель виконавця на надійнішу — "
                            "вироджений вивід зазвичай разовий"),
                    markdown=honest_md, intent=intent, plan=plan, trace=trace)
        # ЧЕСНА ДОБІРКА: агент чесно сказав, що без калькулятора результат буде «з
        # голови». Не вгадуємо — повертаємо мозку запит на ОДИН перезапуск із
        # розширеним контрактом (ліміт перезапусків — код у agent.py, не LLM).
        if (not needs_calc and not meta_mode
                and re.search(r"NEEDS_CAPABILITY\s*:?\s*calculator", out or "", re.I)):
            _emit(emit, f"🖐 {aid}: для якісного результату потрібен калькулятор — "
                        "запитую в мозку розширений контракт…")
            return {"status": "needs_capability", "capability": "calculator",
                    "final_markdown": "", "agent_trace": trace,
                    "system_id": system.get("id"),
                    "understanding": plan.get("system_understanding", "")}
        # ТЕ САМЕ ДЛЯ ЖИВОГО ВЕБУ (09.08.2026): агент чесно сказав, що без
        # актуальних зовнiшнiх даних вiдповiдь була б вигадкою. Замiсть «не маю
        # доступу» - ОДИН перезапуск iз розширеним контрактом (ліміт - код).
        if (not fresh_required and not meta_mode
                and re.search(r"NEEDS_CAPABILITY\s*:?\s*web", out or "", re.I)):
            _emit(emit, f"🖐 {aid}: без живих даних вiдповiдь була б із памʼятi — "
                        "запитую в мозку розширений контракт…")
            return {"status": "needs_capability", "capability": "web",
                    "final_markdown": "", "agent_trace": trace,
                    "system_id": system.get("id"),
                    "understanding": plan.get("system_understanding", "")}
        role = "critic" if _looks_critic(step["agent"]) else "agent"
        entry = {"agent": step["agent"], "output": out, "role": role, "purpose": step.get("purpose", "")}
        if live_data:
            entry["searched"] = True
        trace.append(entry)
        accumulated += f"\n### {step['agent']}\n{out}\n"

    # 3b) ЦИКЛ ЯКОСТІ за планом
    ql = plan["quality_loop"]
    revisions = 0
    if depth == "quick":
        _emit(emit, "⚡ Швидкий режим: без раундів критика")
    if depth != "quick" and ql.get("enabled") and ql.get("critic_agent") and ql.get("reviser_agent"):
        threshold = _threshold_value(ql.get("pass_threshold"))
        max_iter = min(int(ql.get("max_iterations") or 2), HARD_MAX_REVISIONS)
        critic_id, reviser_id = ql["critic_agent"], ql["reviser_agent"]
        critic_out = next((t["output"] for t in reversed(trace) if t["agent"] == critic_id), "")
        while revisions < max_iter and not _critic_satisfied(critic_out, threshold):
            # ⭐ 28.07.2026: раніше вихід за бюджетом був НІМИЙ — людина бачила
            # завершені кола критика і вважала, що якість визнано готовою.
            # Зупинка за ВАРТІСТЮ мусить називати себе вголос.
            if _over_cap(_cap):
                # Усі етапи вже зроблені — лишалось шліфування. Тут пауза з вибором
                # не має сенсу: чесніше зібрати оплачене й сказати про це людською
                # мовою (без назв файлів і налаштувань).
                _emit(emit, f"⚠ Досягнуто межу вартості (${_cap:.2f}) — далі не витрачаю. "
                            "Складаю відповідь із того, що вже напрацьовано. "
                            "Це зупинка за вартістю, а не «якість визнано готовою».")
                break
            revisions += 1
            _emit(emit, f"🔁 Доопрацювання за критиком (раунд {revisions})…")
            rev_prompt = platform_reach_note() + (_load_agent_prompt(system, reviser_id)
                                                  or _synth_agent_prompt(system, reviser_id))
            _calc_guard = ("## ПРАВИЛО ЧИСЕЛ\nЧисла в етапах пораховані калькулятором — "
                           "НЕ перераховуй і НЕ змінюй їх; правити можна лише текст.\n\n") if needs_calc else ""
            try:
                rev_out = llm.complete(rev_prompt,
                    _calc_guard
                    + f"## ЗАПИТ\n{task}\n\n## ПОТОЧНІ ЕТАПИ\n{accumulated}\n\n"
                    f"## ФІДБЕК КРИТИКА (усунь повністю)\n{critic_out}\n\nРаунд {revisions}. Поверни покращену версію.\n\n" + _ART,
                    model=config.worker_model())
            except llm.LLMError:
                break
            if _degenerate_step(rev_out):
                _emit(emit, "⛔ Ревізія видала вироджений вивід — зупиняю цикл якості, лишаю попередню версію.")
                break
            trace.append({"agent": f"{reviser_id} (ревізія {revisions})", "output": rev_out, "role": "revision"})
            accumulated += f"\n### {reviser_id} (ревізія {revisions})\n{rev_out}\n"
            crit_prompt = platform_reach_note() + (_load_agent_prompt(system, critic_id)
                                                   or _synth_agent_prompt(system, critic_id))
            try:
                critic_out = llm.complete(crit_prompt,
                    f"## ЗАПИТ\n{task}\n\n## МАТЕРІАЛ\n{rev_out}\n\nОціни за умовою «{ql.get('pass_threshold')}» і вкажи, чи готово.",
                    model=config.worker_model())
            except llm.LLMError:
                break
            trace.append({"agent": f"{critic_id} (оцінка {revisions})", "output": critic_out, "role": "critic"})
            accumulated += f"\n### {critic_id} (оцінка {revisions})\n{critic_out}\n"

    if should_cancel and should_cancel():
        _emit(emit, "⏹ Зупинено на ваш запит.")
        return {"status": "cancelled", "final_markdown": "", "agent_trace": trace,
                "system_id": system.get("id")}

    # 4) ФІНАЛЬНА ЗБІРКА за правилами системи
    _emit(emit, "📝 Збираю фінальний результат…")
    root_prompt = _system_root_prompt(system)
    deliverable = plan.get("final_deliverable", "")
    assembler_sys = (
        platform_reach_note()
        + (root_prompt + "\n\n" if root_prompt else "")
        + "## ТВОЯ РОЛЬ ЗАРАЗ\nТи — кореневий складальник системи. З етапів агентів збери "
          "ЄДИНИЙ чистий фінальний результат МОВОЮ ЗАПИТУ КОРИСТУВАЧА (тією, якою написано "
          "запит: російський запит → російською, український → українською; не підміняй за "
          "локаллю збірки), який дає САМЕ ТЕ, що просив користувач у запиті.\n"
          "• Формат і структуру диктує ЗАПИТ КОРИСТУВАЧА. Якщо просили конкретний артефакт "
          "(дашборд, таблицю OKR/KPI, план, юридичний висновок, договір) — видай саме його, "
          "у повному обсязі, з усіма таблицями та цифрами з етапів.\n"
          "• НЕ нав'язуй власний шаблон (зокрема «вердикт ради директорів»), якщо користувач "
          "його не просив. Думки ради/критика — лише сировина; у фінал бери суть, а не їхній формат.\n"
          f"• Очікуваний результат системи (орієнтир, не догма): {deliverable}\n"
          "• Без службових міток, оцінок критика та мета-коментарів про процес.\n\n"
        + config.FINAL_OUTPUT_STANDARDS + "\n\n" + _ART
    )
    # КЕШ (Правило A, 25.07.2026): стабільний префікс (роль+стандарти) окремо від
    # ПЕРЕМІННИХ по-задачі блоків. Anthropic кешує префікс -> hit-rate росте. Текст,
    # який бачить модель, НЕ міняється (конкатенація префікс+хвіст ідентична старій).
    _sys_suffix = (
        (("\n\n## ПРАВИЛО ЧИСЕЛ ДЛЯ ЗБІРКИ (обовʼязкове)\nЧисла в етапах пораховані "
            "калькулятором. Переноси їх у фінал ТОЧНО — не перераховуй, не заокруглюй "
            "по-своєму, не «гармонізуй». Якщо числа різних етапів суперечать — бери "
            "значення з найпізнішого розрахункового кроку і чесно познач розбіжність.")
           if needs_calc else "")
        + (("\n\n## " + config.XLSX_MODEL_NOTE) if wants_model else "")
        + (("\n\n## " + config.SCHEMA_MODEL_NOTE) if seo_facts else "")
    )
    if _sys_suffix:
        assembler_sys = [assembler_sys, _sys_suffix]
    # ІСТИНА ДВИГУНА → СКЛАДАЧУ. Для системи маршрутів реальні плечі й заклади (Google,
    # уже в seo_page-слоті) МУСЯТЬ дійти у фінал дослівно. Корінь бага 14.07: агенти-
    # дослідники вимагали URL і мітили реальні заклади «не підтверджено», а складач
    # першоджерела не бачив (збирав лише з accumulated) — тому реальні кафе/готелі й
    # рейтинги викидались, а справжні кілометри діставали фальшиву мітку «оцінка». Тепер
    # складач отримує блок движка як авторитет, який не можна хеджувати.
    _route_truth = ""
    if route_diag and isinstance(route_diag.get("result"), dict) and route_diag["result"].get("ok"):
        _route_truth = seo_page or ""
    assembler_input = (
        f"## ЗАПИТ КОРИСТУВАЧА (головне — дай саме це)\n{task}\n\n"
        + (("## ПЕРЕВІРЕНІ ДАНІ ДВИГУНА — ЄДИНЕ ДЖЕРЕЛО ПРАВДИ (вставити ДОСЛІВНО, НЕ хеджувати)\n"
            f"{_route_truth}\n\n"
            "Це РЕАЛЬНІ дані з детермінованого маршрутного двигуна (Google): відстань, час, "
            "розбивка по плечах і заклади з рейтингами та кількістю відгуків. Перенеси їх у "
            "фінал ДОСЛІВНО — усі плечі й усі заклади з їхніми рейтингами/відгуками. НЕ "
            "додавай до цих даних міток «оцінка», «не підтверджено», «посилання не "
            "підтверджено»: вони підтверджені двигуном. Відсутність клікабельного URL — НЕ "
            "привід сумніватися. НЕ шукай ці заклади в вебі наново й НЕ заміняй їх "
            "загальними фразами на кшталт «кафе вздовж траси». Якщо серед даних є блок "
            "«ЖИВІ УМОВИ» — виведи ці обмеження/дорожню обстановку з джерелами; і НІКОЛИ "
            "не пиши «обмежень нема / стандартні правила», якщо блок каже інше або каже "
            "«не перевірено».\n\n") if _route_truth else "")
        + f"## ЕТАПИ КОНВЕЄРА (сировина — зібери з неї фінал)\n{accumulated}\n\n"
        "Поверни ПОВНИЙ фінальний результат у Markdown, нічого важливого не пропускаючи "
        "(усі таблиці, чеклісти, фінансові цифри). Структура — строго під запит користувача."
    )
    # Складальник критичний: пробуємо мозок, потім запасну модель. Якщо обидва впали,
    # НЕ видаємо сирий (можливо обрізаний) вивід останнього агента за «фінал» —
    # чесно позначаємо, що збірка не вдалася й потрібен повторний запуск.
    final_markdown = ""
    assembler_ok = False
    honest_stop = None  # свідомий чесний стоп (fail-closed): {reason, action}
    if meta_mode:
        # Мета-режим (Будівник): фінальна збірка НЕ потрібна — споживач (матеріалізатор)
        # бере СИРИЙ вивід агентів із трейсу. Пропускаємо найважчий і зайвий тут крок.
        final_markdown = (trace[-1].get("output", "") if trace else "") or accumulated
        assembler_ok = True
    _chain = _assembler_models(_is_high_stakes(system, task))
    # ⭐ 28.07.2026. Саме тут згорів прогін на $2.51 при стелі $1: фінал правової
    # відповіді збирає ДОРОГИЙ мозок, і цей один крок коштував більше за всю
    # стелю. Обривати збірку не можна — клієнт заплатив і лишиться без відповіді.
    # Тому за межею фінал збирає ДЕШЕВА модель, і людині про це сказано.
    if _over_cap(_cap) and not meta_mode:
        _cheap = config.worker_model()
        if _cheap:
            _chain = [_cheap] + [m for m in _chain if m != _cheap]
            _emit(emit, "⚠ Межу вартості прогону ($%.2f) досягнуто — фінал збираю "
                        "дешевшою моделлю, щоб відповідь усе одно вийшла." % _cap)
    _work_len = len(accumulated or "")
    for _i, _mdl in enumerate(_chain):
        if assembler_ok:
            break
        _nxt = _chain[_i + 1] if _i + 1 < len(_chain) else None
        out = None
        # РЕЗЕРВ ШВИДШЕ: одна спроба на модель, тоді одразу наступна в ланцюгу. Потоковий
        # транспорт llm тепер сам відрізняє «живий-але-повільний» від «завис» (idle-таймаут)
        # і робить дешевий 1× повтор старту всередині — тож дублювати важкий повтор ТІЄЇ Ж
        # моделі тут більше не треба (раніше 2 тут × 3 у llm = до 6 дорогих перегенерацій
        # перед резервом = час і гроші).
        try:
            out = llm.complete(assembler_sys, assembler_input,
                               model=_mdl, max_tokens=config.ASSEMBLER_MAX_TOKENS,
                               timeout=config.ASSEMBLER_TIMEOUT)
        except llm.LLMError as e:
            _emit(emit, f"⚠ {_mdl} не відповів ({e})."
                        + (f" Перемикаюсь на {_nxt}…" if _nxt else ""))
            out = None
        if not (out and out.strip()):
            continue
        # ВОРОТА ЯКОСТІ СКЛАДАННЯ: відхиляємо вироджений вивід (пробільні цикли/порожнеча/
        # обрив) і пробуємо наступну, надійнішу модель — а не приймаємо брак за фінал.
        _deg = verifier.degeneracy_check(out, _work_len)
        if not _deg.get("ok"):
            _emit(emit, f"⛔ {_mdl}: вивід не пройшов ворота якості ({_deg.get('reason')})."
                        + (f" Пробую {_nxt}…" if _nxt else ""))
            continue
        final_markdown = verifier.sanitize_output(out)
        assembler_ok = True
        if _i > 0:
            _emit(emit, f"✓ Фінал зібрано резервною моделлю ({_mdl}).")
        break
    if not assembler_ok:
        _emit(emit, "⚠ Складання якісного фіналу не вдалося — потрібен повторний запуск.")
        final_markdown = (
            "> ⚠ **УВАГА: складальник не зміг зібрати ЯКІСНИЙ фінал** (усі моделі дали збій "
            "або вироджений вивід). Це НЕ готовий результат — перезапустіть задачу.\n\n"
            + (verifier.sanitize_output(accumulated) or "(етапів немає)")
        )

    # 4б) Ворота якості Excel-моделі: ЧИ потрібна повноцінна модель — каже контракт
    # наміру (financial_model). Невалідний блок, що вже зʼявився у фіналі, чистимо
    # незалежно (щоб сирий JSON не потрапив користувачу).
    if assembler_ok and (wants_model or "```xlsxmodel" in (final_markdown or "")):
        final_markdown, honest_stop = _fix_xlsxmodel(final_markdown, task, emit=emit,
                                                     wants_excel=wants_model)

    # 4в) Матеріалізація schema.org: компактну модель ```schemaorg перетворюємо на
    # валідний JSON-LD із РЕАЛЬНИХ фактів сторінки; поля без даних → чек-лист
    # «дозаповнити» (не заглушки в JSON). Лікує обрив JSON і плейсхолдери URL.
    if assembler_ok and "```schemaorg" in (final_markdown or ""):
        _emit(emit, "🧩 Збираю валідну schema.org-розмітку з реальних даних сторінки…")
        final_markdown = schema_org.materialize(final_markdown, seo_facts, emit=emit)

    # 4в-2) ⭐ 28.07.2026. САМОЗАЯВЛЕНА ЗВІРКА — ДЛЯ ВСІХ СИСТЕМ, не лише юриста.
    # Фраза «звірено з першоджерелом» має право зʼявитись лише тоді, коли звіряв
    # КОД. Модель не може ставити цю печатку сама собі — ні в юр-довідці, ні в
    # маркетинговому звіті, ні у фінмоделі. Це та сама дірка «дві правди в одному
    # документі», через яку клієнт 28.07 отримав «PASS» на незвірених нормах.
    if assembler_ok and final_markdown:
        try:
            import legal_citation_check as _seal
            _before = final_markdown
            final_markdown = _seal.strip_model_seal(final_markdown)
            if final_markdown != _before:
                _emit(emit, "🧹 Знято самозаявлену печатку «звірено з першоджерелом» — "
                            "її ставить лише машинна перевірка.")
        except Exception as e:
            llm._log(f"[executor] зняття печатки зірвалось: {e}")

    # 4г) ЮРИСТ — детермінований звіряч цитат із ВРУ (ворота проти фальшивої звірки).
    if assembler_ok and _is_legal_system(system) and _legal_jurisdiction(task) == "UA":
        # ОДИН ПИСАР: віддаємо воротам ту саму позицію, яку бачив агент.
        final_markdown = _apply_legal_citation_check(final_markdown, emit=emit, task=task,
                                                     history=history, legal_pos=legal_pos)

    # ⭐⭐⭐ 05.08.2026. ВОРОТА ТЕНДЕРАЙТЕРА №2 і №3 — НА ГОТОВОМУ АРТЕФАКТІ.
    # Кожен пункт переліку замовника мусить дожити до пакета, і кожен рядок
    # реєстру — мати підставу в оголошенні. Роботу НЕ стираємо (людина за неї
    # заплатила), але прямо кажемо, що пакет НЕ готовий до подачі: мовчазна
    # неповнота коштує дорожче за незручну правду.
    if (system or {}).get("id") == tender_pack.SYSTEM_ID:
        _chk = tender_pack.merge_checklists(
            tender_pack.checklist_from_trace(accumulated),
            tender_pack.extra_requirements_in(files_context or ""))
        # ⭐⭐⭐ 05.08.2026, ТРЕТІЙ ПРОВАЛЕНИЙ ПРОГІН. КІСТЯК ПАКЕТА БУДУЄ КОД.
        # Агенти відмовлялись складати пакет («більшість інформації відсутня» —
        # у них не було реквізитів і цін учасника), і жоден текст у промпті цього
        # не змінив: рішення ухвалює модель, а прохання в промпті — це прохання.
        # Тепер структура пакета детермінована: перелік замовника -> розділ на
        # кожен пункт + реєстр із підставами + список «заповнити перед подачею».
        # Модель не вирішує, БУТИ пакету чи ні: пакет уже є, вона його наповнює.
        # Найгірше, що можливо, — порожні графи. Це чесний папір, а не «роботи не зроблено».
        if _chk:
            try:
                _facts = {"tender_id": (tender_pack.tender_id_in(task or "")
                                        or tender_pack.tender_id_in(files_context or ""))}
                _skel = tender_skeleton.build(_chk, tender_pack.requisites(), _facts)
                if _skel:
                    final_markdown = tender_skeleton.merge_model_text(
                        _skel, final_markdown or "", _chk)
                    if _blank_questions:
                        final_markdown += ("\n\n---\n\n### ЩО ПОТРІБНО ВІД УЧАСНИКА\n"
                                           + "\n".join("- " + q for q in _blank_questions))
                    _emit(emit, "🧱 Кістяк пакета зібрано платформою — %d позицій переліку"
                                % len(_chk))
                    llm._log("[executor] кістяк пакета: позицій=%d, текст моделі=%d знаків"
                             % (len(_chk), len(final_markdown or "")))
            except Exception as _e:
                llm._log("[executor] кістяк пакета не зібрався: %s" % _e)
        _verdict = tender_pack.check_pack(final_markdown, _chk)
        llm._log("[executor] ворота пакета: пунктів=%d рядків=%d пропущено=%d без підстави=%d"
                 % (len(_chk), _verdict.get("rows", 0), len(_verdict.get("missing") or []),
                    len(_verdict.get("no_source") or [])))
        if not _verdict.get("ok"):
            # ⭐ 05.08.2026, живий прогін: моє попередження прочитав СУДДЯ ЯКОСТІ й
            # оголосив усю роботу невиконаною — людина не отримала нічого. Це вже не
            # чесність, а друга правда про «готово». Блок лишається, але прямо каже,
            # ЩО він таке: попередження учаснику перед подачею, а не вердикт про роботу.
            _lines = ["> ⚠ **ПЕРЕВІРКА ПАКЕТА ПЕРЕД ПОДАЧЕЮ.** " + (_verdict.get("reason") or "")
                      + " Це попередження учаснику, а НЕ ознака невиконаної роботи:"
                        " документи нижче складені й придатні до використання."]
            if _verdict.get("missing"):
                _lines.append("> \n> **Пункти переліку замовника, яких немає в пакеті:**")
                _lines += ["> • " + m for m in _verdict["missing"][:12]]
            if _verdict.get("no_source"):
                _lines.append("> \n> **Рядки без підстави в оголошенні** (не доведено, звідки вимога):")
                _lines += ["> • " + m for m in _verdict["no_source"][:12]]
            _lines.append("> \n> Закрийте названі пункти перед подачею — решта пакета готова.")
            final_markdown = "\n".join(_lines) + "\n\n---\n\n" + (final_markdown or "")
            _emit(emit, "⛔ Ворота пакета: %s" % (_verdict.get("reason") or "неповно"))

    # дедуплікація джерел
    seen, sources = set(), []
    for s in all_sources:
        u = (s or {}).get("url")
        if u and u not in seen:
            seen.add(u); sources.append({"title": s.get("title") or u, "url": u})

    # ⭐⭐⭐ 09.08.2026. ВОРОТА ПРОТИ ВИГАДАНИХ ПОСИЛАНЬ (живий провал у клієнта).
    # Система видала двох кандидатів із адресами work.ua/resumes/40123456 і
    # .../40234567 — послідовні круглі номери, яких вона НІКОЛИ не відкривала.
    # Позначка «не вдалося підтвердити» вже існувала, але вона лише ПОПЕРЕДЖАЛА,
    # а вигадка все одно доїжджала до людини як результат.
    # ⭐ ПОСИЛАННЯ, ЯКОГО ПЛАТФОРМА НЕ ВІДКРИВАЛА, — ЦЕ НЕ ДЖЕРЕЛО, А ВИГАДКА.
    # Правило детерміноване, без вгадування: беремо URL із тексту видачі і
    # звіряємо з РЕАЛЬНИМИ джерелами прогону (sources). Чого там немає — те не
    # має права виглядати як підтверджене посилання.
    _real = set()
    for _s in sources:
        _u = (_s or {}).get("url") or ""
        _real.add(_u.rstrip("/"))
    _in_text = [u.rstrip("/.,);:*") for u in
                re.findall(r"https?://[^\s\)\]\*,]+", final_markdown or "")]
    _fake = []
    for _u in _in_text:
        if _u.rstrip("/") in _real:
            continue
        # головна сторінка домену — це не посилання на запис, її не судимо
        if _u.rstrip("/").count("/") <= 2:
            continue
        if _u not in _fake:
            _fake.append(_u)
    if _fake:
        for _u in _fake:
            final_markdown = (final_markdown or "").replace(
                _u, "[адресу приховано: платформа її НЕ відкривала]")
        _emit(emit, "⛔ Ворота джерел: %d посилань не підтверджено — прибрано з відповіді"
                    % len(_fake))
        import sys as _sf
        _sf.stderr.write("[sources] INVENTED LINKS in output (%d): %s\n"
                         % (len(_fake), "; ".join(_fake[:5])))
        # Якщо реального джерела НЕ БУЛО ЖОДНОГО, а видача спиралась на посилання —
        # уся робота стоїть на вигадці. Це не «результат із застереженням», а СТОП.
        if not _real:
            honest_stop = honest_stop or {
                "kind": "sources_invented",
                "reason": ("у відповіді були посилання, яких платформа не відкривала "
                           "(%s), а жодного справжнього джерела в цьому прогоні не було"
                           % "; ".join(_fake[:3])),
                "action": ("повторіть запит — платформа має вийти в інтернет і спертися "
                           "на справжні сторінки; якщо повториться, скажіть про це"),
            }
            final_markdown = (
                "## Не можу віддати цей результат: посилання не підтверджені\n\n"
                "У відповіді були адреси, яких платформа **не відкривала**, а жодного "
                "справжнього джерела в цьому прогоні не було. Це означає, що дані могли "
                "бути домислені моделлю, і віддавати їх як знайдені — обман.\n\n"
                "**Що зробити:** повторіть запит. Якщо повториться — скажіть, і причину "
                "знайдемо в журналі за цим часом.\n"
            )

    # ⭐⭐⭐ 01.08.2026. ОДНА ТОЧКА, ДЕ ЗАСТЕРЕЖЕННЯ ПРО НЕВИКОНАНУ
    # ПЕРЕВІРКУ ПОТРАПЛЯЄ В РЕЗУЛЬТАТ. Пише ПЛАТФОРМА, не модель: прохання
    # до моделі «напиши це сама» — це прохання, а не ворота.
    if _gate_degraded:
        final_markdown = _gate_degraded_note(_gate_degraded) + (final_markdown or "")

    # СВІДОМИЙ СТОП НА ЗДАЧІ (жива Excel-модель не зібралась): статус мусить
    # називати себе стопом, а не завершенням — ті самі одні двері, що й вище.
    if honest_stop:
        return honest_stop_result(
            system, kind=honest_stop.get("kind") or "financial_model",
            reason=honest_stop.get("reason") or "", action=honest_stop.get("action") or "",
            markdown=final_markdown, intent=intent, plan=plan, trace=trace,
            route_engine=route_diag, conditions=cond_diag,
            web_invariant_gap="; ".join(web_gaps))

    return {
        "status": "completed",
        "final_markdown": final_markdown,
        "assembler_ok": assembler_ok,
        "honest_stop": honest_stop,
        "agent_trace": trace,
        "system_id": system.get("id"),
        "needs_calc": needs_calc,
        "intent": intent,
        "revisions": revisions,
        "understanding": plan.get("system_understanding", ""),
        "success_criteria": plan.get("success_criteria", []),
        "sources": sources,
        "web_invariant_gap": "; ".join(web_gaps),
        "route_engine": route_diag,   # для систем маршрутів: точна причина, чому шлях є/нема
        "conditions": cond_diag,      # слід живого веб-пошуку умов (обмеження в'їзду)
        "mode": system.get("orchestration_mode", "sequential"),
    }

# (кінець executor.py)
