# -*- coding: utf-8 -*-
"""win_service.py — СПРАВЖНЯ СЛУЖБА WINDOWS ДЛЯ СЕРТИФІКОВАНОЇ КОНФІГУРАЦІЇ (зміна 807, ТЗІ група Б2).

🩸 ЩО БУЛО. «Служба» платформи насправді — завдання Планувальника від імені SYSTEM (517, 697):
найширші права машини, і в переліку служб Windows її немає. Для експертизи ТЗІ потрібна
справжня служба з найменшими правами, керована диспетчером служб (зупинка, стан, відновлення).

⛒ КЛАС: «платформа працює з більшими правами, ніж потрібно, і поза диспетчером служб».
ЛІК — цей модуль, лише stdlib (ctypes):
  • диспетчер служб Windows запускає `python win_service.py`; модуль відповідає диспетчеру
    (StartServiceCtrlDispatcherW), повідомляє «працює», а сам сервер тримає дочірнім процесом
    з тими самими умовами, що й запускач завдання (`_run_service.bat`): журнал `service.log`
    (попередній — `service.prev.log`), без браузера, тихий журнал запитів, Python пакета першим;
  • сервер упав — піднімається знову за 10 с (як завдання: «піднімається знову, якщо впала»);
  • «Зупинити» в диспетчері — сервер зупиняється, служба доповідає «зупинено»;
  • обліковий запис — віртуальний `NT SERVICE\\SensFlow` (найменші права), не SYSTEM;
    права на теку платформи дає встановлювач (`service_install_real.ps1`).
⛒ ПРАВИЛО 804: справжня служба — лише для посиленого профілю / нових сертифікованих
встановлень. У Каспера й ОТУ автозапуск лишається завданням Планувальника, як є.

Запуск руками (не диспетчером) нічого не піднімає і каже, як керувати службою.
Проба: win_service_807_test.py (+ _mutants). Підвищення прав проба не робить ніколи;
справжній диспетчер служб — кухонна перевірка prove_service_807.ps1 (вікно «Так» — Андрій).
"""
import os
import subprocess
import sys
import threading
import time
from pathlib import Path

SERVICE_NAME = "SensFlow"
ENGINE = Path(__file__).resolve().parent
ROOT = ENGINE.parent
RESTART_DELAY = 10          # с: сервер упав — пауза перед новим підйомом
STOP_WAIT = 20              # с: стільки чекаємо на чисте закриття, далі — примусово

NOT_UNDER_SCM = ("Це служба Windows «%s»: її запускає диспетчер служб, а не людина.\n"
                 "Керувати нею — кнопками «Служба - стан», «Служба - зняти автозапуск»\n"
                 "або в «Служби» Windows (services.msc)." % SERVICE_NAME)


def child_command(root: Path = ROOT) -> list:
    """Те саме, що запускач завдання: Python пакета першим, utf8, server.py."""
    own = Path(root) / "python" / "python.exe"
    py = str(own) if own.is_file() else sys.executable
    return [py, "-X", "utf8", "server.py"]


def child_env(base=None, root: Path = ROOT) -> dict:
    env = dict(os.environ if base is None else base)
    if (Path(root) / "python" / "python.exe").is_file():
        env.pop("PYTHONHOME", None)
        env.pop("PYTHONPATH", None)
        env["PYTHONNOUSERSITE"] = "1"
    env["AUTO_OPEN_BROWSER"] = "0"       # вікна немає — браузер відкривати нікому
    env["SENSFLOW_QUIET"] = "1"          # успішні звернення в журнал не пишемо (516)
    env["SENSFLOW_SUPERVISED"] = "1"     # 816: наглядач — ми; сервер може попросити перезапуск
    return env


def rotate_log(root: Path = ROOT) -> Path:
    """Попередній запуск — у service.prev.log. ⛒ Підміна на Windows має право відбитись
    (файл хтось читає) — її робить ОДИН писар підміни, з терпінням (808)."""
    log = Path(root) / "service.log"
    if log.exists():
        try:
            import one_writer
            one_writer.replace_with_patience(log, Path(root) / "service.prev.log")
        except OSError:
            pass
    return log


class Supervisor:
    """Тримає сервер живим. Без диспетчера служб — щоб пробі було що перевірити без прав."""

    def __init__(self, cmd=None, cwd=None, env=None, log_path=None, restart_delay=RESTART_DELAY,
                 stop_wait=STOP_WAIT):
        self.cmd = cmd or child_command()
        self.cwd = str(cwd or ENGINE)
        self.env = env if env is not None else child_env()
        self.log_path = Path(log_path) if log_path else rotate_log()
        self.restart_delay = restart_delay
        self.stop_wait = stop_wait
        self.child = None
        self.starts = 0
        self.stopping = False
        self._down_at = None

    def _note(self, text: str):
        try:
            with open(self.log_path, "a", encoding="utf-8") as fh:
                fh.write("[служба] %s %s\n" % (time.strftime("%d.%m.%Y %H:%M:%S"), text))
        except OSError:
            pass

    def start(self):
        self._note("підіймаю платформу")
        fh = open(self.log_path, "ab")
        try:
            self.child = subprocess.Popen(self.cmd, cwd=self.cwd, env=self.env, stdout=fh,
                                          stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                                          creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        finally:
            fh.close()
        self.starts += 1
        self._down_at = None

    def tick(self):
        """Раз на кілька секунд: сервер упав — за паузу піднімаємо знову."""
        if self.stopping or self.child is None or self.child.poll() is None:
            return
        now = time.monotonic()
        if self._down_at is None:
            self._down_at = now
            self._note("платформа завершилась (код %s); підійму за %d с"
                       % (self.child.returncode, self.restart_delay))
            return
        if now - self._down_at >= self.restart_delay:
            self.start()

    def stop(self):
        self.stopping = True
        c = self.child
        if c is None or c.poll() is not None:
            self._note("зупинено")
            return
        self._note("зупиняю платформу")
        c.terminate()
        try:
            c.wait(self.stop_wait)
        except subprocess.TimeoutExpired:
            c.kill()
            c.wait(10)
        self._note("зупинено")


# ── ДИСПЕТЧЕР СЛУЖБ WINDOWS (ctypes) ─────────────────────────────────────────
SERVICE_WIN32_OWN_PROCESS = 0x10
SERVICE_STOPPED, SERVICE_START_PENDING, SERVICE_STOP_PENDING, SERVICE_RUNNING = 1, 2, 3, 4
SERVICE_ACCEPT_STOP, SERVICE_ACCEPT_SHUTDOWN = 0x1, 0x4
SERVICE_CONTROL_STOP, SERVICE_CONTROL_INTERROGATE, SERVICE_CONTROL_SHUTDOWN = 0x1, 0x4, 0x5
ERROR_FAILED_SERVICE_CONTROLLER_CONNECT = 1063
_KEEP = []                      # колбеки й таблиця живуть, доки живе процес


def _scm():
    import ctypes
    from ctypes import wintypes

    class STATUS(ctypes.Structure):
        _fields_ = [("dwServiceType", wintypes.DWORD), ("dwCurrentState", wintypes.DWORD),
                    ("dwControlsAccepted", wintypes.DWORD), ("dwWin32ExitCode", wintypes.DWORD),
                    ("dwServiceSpecificExitCode", wintypes.DWORD), ("dwCheckPoint", wintypes.DWORD),
                    ("dwWaitHint", wintypes.DWORD)]

    MAIN = ctypes.WINFUNCTYPE(None, wintypes.DWORD, ctypes.POINTER(wintypes.LPWSTR))
    HANDLER = ctypes.WINFUNCTYPE(wintypes.DWORD, wintypes.DWORD, wintypes.DWORD,
                                 ctypes.c_void_p, ctypes.c_void_p)

    class ENTRY(ctypes.Structure):
        _fields_ = [("lpServiceName", wintypes.LPWSTR), ("lpServiceProc", MAIN)]

    adv = ctypes.WinDLL("advapi32", use_last_error=True)
    adv.StartServiceCtrlDispatcherW.argtypes = [ctypes.POINTER(ENTRY)]
    adv.StartServiceCtrlDispatcherW.restype = wintypes.BOOL
    adv.RegisterServiceCtrlHandlerExW.argtypes = [wintypes.LPCWSTR, HANDLER, ctypes.c_void_p]
    adv.RegisterServiceCtrlHandlerExW.restype = ctypes.c_void_p
    adv.SetServiceStatus.argtypes = [ctypes.c_void_p, ctypes.POINTER(STATUS)]
    adv.SetServiceStatus.restype = wintypes.BOOL
    return ctypes, STATUS, MAIN, HANDLER, ENTRY, adv


def run_as_service(make_supervisor=Supervisor) -> int:
    """Повертає 0 — служба відпрацювала; 2 — це не диспетчер служб (запуск руками)."""
    ctypes, STATUS, MAIN, HANDLER, ENTRY, adv = _scm()
    stop = threading.Event()
    state = {"handle": None, "check": 0}

    def report(cur, accepted=0, hint=0, code=0):
        st = STATUS(SERVICE_WIN32_OWN_PROCESS, cur, accepted, code, 0, state["check"], hint)
        state["check"] += 1
        adv.SetServiceStatus(state["handle"], ctypes.byref(st))

    def handler(control, _etype, _edata, _ctx):
        if control in (SERVICE_CONTROL_STOP, SERVICE_CONTROL_SHUTDOWN):
            report(SERVICE_STOP_PENDING, 0, (STOP_WAIT + 10) * 1000)
            stop.set()
        return 0

    def main(_argc, _argv):
        state["handle"] = adv.RegisterServiceCtrlHandlerExW(SERVICE_NAME, h, None)
        report(SERVICE_START_PENDING, 0, 30000)
        sup = make_supervisor()
        try:
            sup.start()
        except Exception:
            report(SERVICE_STOPPED, 0, 0, 1)
            return
        report(SERVICE_RUNNING, SERVICE_ACCEPT_STOP | SERVICE_ACCEPT_SHUTDOWN)
        while not stop.wait(2):
            sup.tick()
        sup.stop()
        report(SERVICE_STOPPED)

    h = HANDLER(handler)
    m = MAIN(main)
    table = (ENTRY * 2)(ENTRY(SERVICE_NAME, m), ENTRY(None, MAIN()))
    _KEEP.extend([h, m, table])
    if not adv.StartServiceCtrlDispatcherW(table):
        if ctypes.get_last_error() == ERROR_FAILED_SERVICE_CONTROLLER_CONNECT:
            return 2
        return 1
    return 0


if __name__ == "__main__":
    rc = run_as_service() if os.name == "nt" else 2
    if rc == 2:
        print(NOT_UNDER_SCM)
    sys.exit(rc)
