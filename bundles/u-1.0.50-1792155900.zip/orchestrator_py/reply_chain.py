# -*- coding: utf-8 -*-
"""reply_chain.py — ⭐ ПОРЯДОК У РЕПЛІЦІ — ЛИШЕ З РЕЗУЛЬТАТУ (зміна 813, 16.10.2026).

🩸 Борг точки 789 (14.10.2026, рейс для Міленіуму): документ і двигун — «Київ → Житомир → Тернопіль → Львів →
Рівне → Київ», а коротка відповідь у чаті — «Готово: розрахунок рейсу Київ → Житомир → Рівне → Львів →
Тернопіль → Київ». Мозок результату не бачить (йому кажуть лише «система виконала задачу») і переказав
порядок із ЗАПИТУ людини. Людина читає в чаті один маршрут, а в документі — інший.
⛒ КЛАС: репліка називає факт, якого результат за свій не тримає. Для чисел про досьє (644) і номерів пунктів
(642) двері вже стоять; порядок — та сама хвороба: послідовність назв, яку модель відтворила з пам'яті.
⛒ ЛІК: послідовність назв через «→» (або « — ») у репліці судиться результатом. Головна послідовність
результату — перша, що складається з тих самих назв. Той самий набір, інший порядок — репліку виправлено
порядком результату; такий самий порядок — не чіпаємо; назв, яких у результаті немає, — не чіпаємо (судити
нічим, і це видно в журналі).
"""
import re

_UP = "A-ZА-ЯІЇЄҐ"
_ITEM = r"[%s][\w'’ʼ\-]*(?:\s+[%s][\w'’ʼ\-]*)?" % (_UP, _UP)
_SEP = r"\s*(?:→|->|—|–)\s*"
CHAIN = re.compile(r"(?<![\w'’ʼ\-])(%s(?:%s%s){2,})(?![\w'’ʼ\-])" % (_ITEM, _SEP, _ITEM))
_SPLIT = re.compile(_SEP)


def chains(text):
    """Усі послідовності ≥3 назв: [(початок, кінець, [назви], розділювач)]."""
    out = []
    for m in CHAIN.finditer(str(text or "")):
        items = [x.strip() for x in _SPLIT.split(m.group(1)) if x.strip()]
        sep = "→" if "→" in m.group(1) else ("->" if "->" in m.group(1) else "—")
        if len(items) >= 3:
            out.append((m.start(1), m.end(1), items, sep))
    return out


def _key(items):
    return sorted(x.lower() for x in items)


def mend(reply, result):
    """Повертає (репліка, виправлення). Виправлення — [(було, стало)]."""
    reply = str(reply or "")
    if not reply or not result:
        return reply, []
    res = chains(result)
    if not res:
        return reply, []
    fixes, out, pos = [], [], 0
    for a, b, items, sep in chains(reply):
        same = [r for r in res if _key(r[2]) == _key(items)]
        if not same or [x.lower() for x in same[0][2]] == [x.lower() for x in items]:
            continue
        new = (" %s " % sep).join(same[0][2])
        out.append(reply[pos:a])
        out.append(new)
        pos = b
        fixes.append((reply[a:b], new))
    if not fixes:
        return reply, []
    out.append(reply[pos:])
    return "".join(out), fixes
