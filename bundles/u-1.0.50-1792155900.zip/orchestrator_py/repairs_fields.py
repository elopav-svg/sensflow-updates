# -*- coding: utf-8 -*-
"""repairs_fields.py — МАПА ПОЛІВ ALLDEVICE ДЛЯ АНАЛІТИКИ РЕМОНТІВ (зміна 791, 14.10.2026).

⛒ ЄДИНЕ МІСЦЕ, ДЕ НАЗВАНО ПОЛЯ ДЖЕРЕЛА. Логіка (`repairs_events`) питає поле лише
через цю мапу. Назви взято зі специфікації Alldevice (openapi.json, знімок 14.10.2026 —
`Малбі\\02 Технічне\\Alldevice_openapi_14.10.2026.json`).

🩸 РИЗИК, НАЗВАНИЙ ПРЯМО. Специфікація — не дані Малбі. Справжні записи ми побачимо лише
з доступом: поле може бути порожнім, мати інший формат дати, дерево місць може бути
побудоване інакше (лінія не на першому рівні). Тому:
  * усе, що залежить від того, як САМЕ Малбі веде Alldevice, — тут, а не в логіці
    (`LINE_DEPTH`, `PLANNED_DOWNTIME_WORDS`, назви видів задач);
  * перше читання справжніх даних закінчується звітом якості (`quality`) — і
    налаштування мапи під нього = одна зміна після доступу.

Лише дані — жодної функції (проба 791 це судить).
"""

# Поля записів кожного джерела: наша назва → назва в Alldevice.
FIELDS = {
    "location": {
        "id": "object_id", "parent": "parent_id", "name": "object_name", "children": "data",
    },
    "device": {
        "id": "device_id", "name": "device_name", "location": "parent_id",
        "path": "objects_path", "category": "type_id", "inventory": "inventory_number",
        "serial": "serial_number", "hours": "work_hours", "status": "device_status",
    },
    "category": {"id": "type_id", "name": "type_name"},
    "task": {
        "id": "task_id", "number": "task_number_combined", "device": "device_id",
        "type": "service_type", "subject": "service_name", "fault": "fault_type",
        "fault_title": "fault_name", "plan": "original_date", "due": "service_date",
        "fact": "completed_date", "fact_end": "completed_date_end",
        "done": "is_completed", "confirmed_by": "confirmed_by_user",
        "created": "created_on", "users": "users", "user_name": "name",
        "spares": "used_spares", "spare_qty": "quantity", "spare_price": "price",
        "postponed": "is_postponed",
    },
    "downtime": {
        "id": "id", "device": "device_id", "start": "start_date", "end": "end_date",
        "seconds": "duration_seconds", "ended": "is_ended", "category": "cat_name",
        "comment": "comments",
    },
    "report": {
        "task": "task_id", "time": "total_time", "cost": "total_cost",
        "spares_cost": "spares_total_cost",
    },
}

# Що читати з Alldevice для знімка: (ключ знімка, двері, фільтри тіла запиту).
# «{from}», «{to}» — межі періоду РРРР-ММ-ДД. Двері — лише з переліку читання конектора.
REQUESTS = (
    ("locations", "/api/devices/locations", {}),
    ("categories", "/api/devices/categories", {}),
    ("devices", "/api/devices/list", {}),
    ("tasks", "/api/tasks/list", {"date_start": "{from}", "date_end": "{to}",
                                  "show_used_spares": True}),
    ("downtimes", "/api/downtimes/list", {"date_start": "{from}", "date_end": "{to}"}),
    ("reports", "/api/taskreports/list", {"date_start": "{from}", "date_end": "{to}",
                                          "date_type": "completed_date"}),
)

# Вид задачі в Alldevice → наш вид.
TASK_TYPES = {
    "extraordinary": "failure",     # позапланова — аварійний ремонт
    "planned": "planned",           # планова (разова)
    "regular": "regular",           # регулярна за графіком — ТО / ППР
}

# Рівень дерева місць, що є «лінією»: 1 — перший під коренем-цехом (0 — сам корінь).
LINE_DEPTH = 1

# Категорія простою, що означає «плановий» (не відмова). Порівнюється без регістру,
# як частина назви категорії.
PLANNED_DOWNTIME_WORDS = ("planned", "план", "ппр", "регламент")

# «Немає дати» в Alldevice.
EMPTY_DATES = ("", "0000-00-00", "0000-00-00 00:00:00")

# Випуск продукції (Excel / BI): наша назва → можливі заголовки (без регістру, початок).
PRODUCTION_HEADERS = {
    "date": ("дата", "date", "день"),
    "line": ("лінія", "линия", "line", "ділянка", "участок"),
    "shift": ("зміна", "смена", "shift"),
    "output": ("випуск", "выпуск", "обсяг", "объем", "объём", "кількість", "количество",
               "output", "вироблено", "произведено"),
}
