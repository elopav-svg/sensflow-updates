# -*- coding: utf-8 -*-
"""alldevice.py — КОНЕКТОР ALLDEVICE ЛИШЕ НА ЧИТАННЯ (зміна 790, 14.10.2026).

Малбі (Міленіум): ремонти, обладнання, простої й запчастини живуть у хмарному
Alldevice (CMMS). Їхній ІТ відкриває API з нашої IP окремому користувачеві. Ми
обіцяли клієнту письмово: платформа ЛИШЕ ДИВИТЬСЯ.

⛒ ЧОМУ ОБІЦЯНКА ТРИМАЄТЬСЯ КОДОМ, А НЕ ПРАВАМИ КОРИСТУВАЧА. API Alldevice має поряд із
читанням двері створення, зміни й видалення (задачі, обладнання, склад, списання). Чи
дасть їхній ІТ користувачеві справді «лише перегляд» — не знаємо і перевірити не можемо.
Тому межа стоїть у нас: ЗАКРИТИЙ ПЕРЕЛІК дверей читання (`READ_DOORS`), точний збіг
рядка, без жодного «нормалізування» шляху. Усе інше — відмова ДО мережі.
Перелік складено руками зі специфікації Alldevice (openapi.json, знімок 14.10.2026 —
`Малбі\\02 Технічне\\Alldevice_openapi_14.10.2026.json`), а не правилом за назвою:
правило «все, що закінчується на list або починається з get» сьогодні збігається з
правдою випадково — завтра Alldevice додасть `get_and_lock`, і воно пропустить запис.

⛒ РЕКВІЗИТИ (адреса, користувач, пароль, ключ API) — секрет компанії клієнта:
  * лежать лише в теці конекторів (`config.CONNECTORS_DIR`) — у журнал версій вона не
    йде (`git_scope`), на екран і в двері не повертаються (`settings()` — без них за
    побудовою), у тексти помилок не потрапляють (`_scrub`);
  * зберігаються лише після вдалого входу (спершу вхід, потім запис — як пошта 685);
  * адреса — лише `https://<назва>.alldevicesoft.com`: реквізити їдуть у тілі кожного
    запиту, і хибна адреса віддала б їх чужому серверу. Відкритий http — лише до цієї ж
    машини (підставний сервер проби).

⛒ СТОРІНКИ. API віддає не більше 200 записів за запит (`limit`, `start` в адресі).
`fetch_all` іде до кінця; зріз без кінця — не тиша, а відмова словами (`MAX_ROWS`).

Робота з вимикачем (`features`, `WORK_ID`): у кого її не ввімкнено, конектор не ходить
нікуди, а двері платформи відповідають 404.

Лише stdlib + `config`, `one_writer`, `netfetch`, `features`, `security_log`.
"""
import json
import urllib.error
import urllib.parse
from datetime import datetime

import config
import one_writer
import secret_box

WORK_ID = "repairs_analytics"
SETTINGS_JSON = config.CONNECTORS_DIR / "alldevice.json"
PAGE = 200                 # межа API Alldevice на один запит
MAX_ROWS = 500_000         # більше — це не дані ремонтів, а збій сторінок
TIMEOUT_S = 90
CAP_BYTES = 80_000_000
CLOUD_SUFFIX = ".alldevicesoft.com"
_LOCAL_HOSTS = ("127.0.0.1", "localhost", "::1")
PROBE_DOOR = "/api/devices/categories"   # перевірка входу: дешево, без особистих даних

# ⛒ ЗАКРИТИЙ ПЕРЕЛІК ДВЕРЕЙ ЧИТАННЯ. Новий рядок — лише після читання специфікації:
# двері мусять лише віддавати дані. Файли (pdf, вкладення) свідомо не взято — аналітиці
# вони не потрібні, а важать багато.
READ_DOORS = frozenset({
    "/api/devices/list", "/api/devices/locations", "/api/devices/categories",
    "/api/devices/manufacturers", "/api/devices/custom_fields", "/api/devices/fault_types",
    "/api/downtimes/list", "/api/downtimes/categories",
    "/api/tasks/list", "/api/tasks/workers", "/api/tasks/service_groups",
    "/api/tasks/stages", "/api/tasks/work_times", "/api/tasks/spares",
    "/api/tasks/used_spares_history",
    "/api/taskreports/list",
    "/api/products/list", "/api/products/categories", "/api/products/stocks",
    "/api/products/get_spare_part_history",
    "/api/users/list",
})

_PUBLIC = ("tenant", "username", "saved", "saved_by", "last_ok", "last_error")


class AlldeviceError(Exception):
    """Відмова словами: що не так і що зробити людині."""


class Refused(AlldeviceError):
    """Двері не з переліку читання — відмова ДО мережі."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _now() -> str:
    try:
        import clock
        return clock.now()
    except Exception:
        return datetime.now().isoformat(timespec="seconds")


def enabled() -> bool:
    try:
        import features
        return bool(features.enabled(WORK_ID))
    except Exception:
        return False


# ── АДРЕСА ───────────────────────────────────────────────────────────────────
def tenant(raw) -> str:
    """Адреса Alldevice компанії → `https://<назва>.alldevicesoft.com`. Інакше відмова."""
    t = _s(raw)
    if not t:
        raise AlldeviceError("Вкажіть адресу Alldevice компанії, наприклад "
                             "https://назва.alldevicesoft.com.")
    if "://" not in t:
        t = "https://" + t
    try:
        u = urllib.parse.urlsplit(t)
        host = (u.hostname or "").lower()
        port = u.port
    except ValueError:
        raise AlldeviceError("Адреса «%s» — не адреса сайту." % _s(raw))
    scheme = (u.scheme or "").lower()
    if u.username is not None or u.password is not None or u.query or u.fragment \
            or u.path.rstrip("/") not in ("", "/api"):
        raise AlldeviceError("Адреса Alldevice — лише назва сайту, наприклад "
                             "https://назва.alldevicesoft.com (без шляху, «@», «?», «#»).")
    if host in _LOCAL_HOSTS:
        if scheme not in ("http", "https"):
            raise AlldeviceError("Адреса «%s» — не адреса сайту." % _s(raw))
        h = "[%s]" % host if ":" in host else host
        return "%s://%s%s" % (scheme, h, (":%d" % port) if port else "")
    name = host[:-len(CLOUD_SUFFIX)] if host.endswith(CLOUD_SUFFIX) else ""
    if scheme != "https" or port is not None or not name \
            or not all(c.isalnum() or c in "-." for c in name) \
            or name.startswith(("-", ".")) or name.endswith(("-", ".")):
        raise AlldeviceError(
            "Платформа підключається лише до хмари Alldevice за захищеною адресою "
            "https://<назва>.alldevicesoft.com; «%s» — не вона." % _s(raw))
    return "https://" + host


# ── СХОВИЩЕ (ОДИН ПИСАР) ─────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(SETTINGS_JSON)
    except PermissionError:
        raise
    except Exception:
        d = {}
    # ⛒ 806: пароль і ключ у спокої — через скриньку (запечатує лише посилений профіль)
    return secret_box.opened(d, secret_box.STORES["alldevice"]) if isinstance(d, dict) else {}


def _save(d: dict) -> None:
    SETTINGS_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(SETTINGS_JSON, secret_box.kept(d, secret_box.STORES["alldevice"]))


def configured(d=None) -> bool:
    d = _load() if d is None else d
    return all(_s(d.get(k)) for k in ("tenant", "username", "password", "key"))


def settings() -> dict:
    """Стан для екрана — БЕЗ пароля й ключа за побудовою."""
    d = _load()
    out = {k: d.get(k) or "" for k in _PUBLIC}
    out["has_password"] = bool(_s(d.get("password")))
    out["has_key"] = bool(_s(d.get("key")))
    out["configured"] = configured(d)
    out["enabled"] = enabled()
    return out


def _creds(d: dict) -> dict:
    return {k: _s(d.get(k)) for k in ("tenant", "username", "password", "key")}


def _scrub(text, creds) -> str:
    """Секрет не сміє доїхати до людини навіть через текст чужого сервера."""
    t = str(text or "")
    for k in ("password", "key"):
        v = _s((creds or {}).get(k))
        if v:
            t = t.replace(v, "***")
    return t[:400]


# ── ЗВЕРНЕННЯ ────────────────────────────────────────────────────────────────
def call(path, body=None, query=None, creds=None):
    """ОДНЕ звернення до дверей читання. Повертає `response` з відповіді Alldevice.

    `creds=None` — збережені реквізити (і їхня помилка лягає на екран стану)."""
    if not isinstance(path, str) or path not in READ_DOORS:
        raise Refused("Alldevice відкрито платформі лише на перегляд: двері «%s» не "
                      "входять до переліку читання." % _s(path)[:80])
    if not enabled():
        raise AlldeviceError("Модуль «Аналітика ремонтів» на цій платформі не ввімкнено.")
    stored = creds is None
    c = _creds(_load()) if stored else _creds(creds)
    if not all(c.values()):
        raise AlldeviceError("Alldevice ще не підключено: впишіть адресу, користувача, пароль "
                             "і ключ API у «Налаштування → Alldevice».")
    try:
        return _post(path, body, query, c)
    except AlldeviceError as e:
        if stored:
            _mark(error=str(e))
        raise


def _post(path, body, query, c):
    base = tenant(c["tenant"])
    payload = {k: v for k, v in (body or {}).items() if k != "auth"}
    payload["auth"] = {"username": c["username"], "password": c["password"], "key": c["key"]}
    url = base + path
    if query:
        url += "?" + urllib.parse.urlencode({k: int(v) for k, v in query.items()})
    import netfetch
    try:
        raw = netfetch.post_json(url, payload, timeout=TIMEOUT_S, cap=CAP_BYTES)
    except urllib.error.HTTPError as e:
        msg = ""
        try:
            j = json.loads(e.read().decode("utf-8", "replace") or "{}")
            msg = _s(j.get("message") or j.get("error_code"))
        except Exception:
            pass
        raise AlldeviceError(_scrub("Alldevice відмовив (код %d)%s" % (
            e.code, (": " + msg) if msg else "."), c))
    except netfetch.EgressBlocked:
        raise AlldeviceError("Увімкнено режим максимального збереження: вихід у мережу "
                             "заборонено, Alldevice недоступний.")
    except Exception as e:
        reason = getattr(e, "reason", None) or e
        raise AlldeviceError(_scrub("Немає звʼязку з Alldevice (%s): %s" % (
            base, reason), c))
    try:
        j = json.loads(raw)
    except Exception:
        raise AlldeviceError("Alldevice відповів не даними (не JSON) — можливо, адреса "
                             "компанії не та.")
    if not isinstance(j, dict) or j.get("success") is not True:
        j = j if isinstance(j, dict) else {}
        msg = _s(j.get("message"))
        if str(j.get("code")) == "2" or msg.lower() == "unauthorized":
            raise AlldeviceError("Alldevice не прийняв вхід: перевірте користувача, пароль "
                                 "і ключ API (ключ — в Alldevice: Налаштування → API).")
        raise AlldeviceError(_scrub("Alldevice відмовив: %s" % (msg or "без пояснення"), c))
    return j.get("response")


def fetch_all(path, filters=None, creds=None) -> list:
    """Усі записи дверей читання, сторінками по `PAGE`, до кінця."""
    out, start, first_prev = [], 0, None
    while True:
        resp = call(path, filters, {"limit": PAGE, "start": start}, creds=creds)
        if isinstance(resp, dict) and isinstance(resp.get("data"), list):
            page = resp["data"]
            try:
                total = int(resp.get("total") or 0)
            except (TypeError, ValueError):
                total = 0
            more = bool(page) and start + len(page) < total
        elif isinstance(resp, list):
            page = resp
            # Список без «total»: далі лише якщо сторінка повна і НЕ повторює попередню
            # (сервер, що не знає `start`, віддасть те саме — це кінець, а не нові дані).
            head = json.dumps(page[:1], sort_keys=True, ensure_ascii=False)
            more = len(page) == PAGE and head != first_prev
            if head == first_prev:
                page = []
            first_prev = head
        elif resp is None:
            page, more = [], False
        else:
            raise AlldeviceError("Alldevice відповів на «%s» не переліком." % path)
        out.extend(page)
        start += len(page)
        if len(out) > MAX_ROWS:
            raise AlldeviceError("«%s»: понад %d записів — сторінки не сходяться, читання "
                                 "зупинено, щоб не взяти неповне за повне." % (path, MAX_ROWS))
        if not more:
            break
    if creds is None:
        _mark(ok=True)
    return out


# ── НАЛАШТУВАННЯ ─────────────────────────────────────────────────────────────
def save(tenant_raw, username, password="", key="", by="") -> dict:
    """Завести або змінити підключення. Спершу ВХІД, потім запис."""
    base = tenant(tenant_raw)
    username = _s(username)
    if not username:
        raise AlldeviceError("Вкажіть користувача Alldevice (окремого, лише на перегляд).")
    old = _load()
    same = _s(old.get("tenant")) == base and _s(old.get("username")) == username
    password, key = _s(password), _s(key)
    if not password:
        if same and _s(old.get("password")):
            password = _s(old.get("password"))
        else:
            raise AlldeviceError("Потрібен пароль користувача %s." % username)
    if not key:
        if same and _s(old.get("key")):
            key = _s(old.get("key"))
        else:
            raise AlldeviceError("Потрібен ключ API (Alldevice: Налаштування → API).")
    cand = {"tenant": base, "username": username, "password": password, "key": key}
    call(PROBE_DOOR, {}, creds=cand)
    _commit(cand, by)
    return settings()


@one_writer.guard("ALLDEVICE_JSON")
def _commit(cand: dict, by: str) -> None:
    old = _load()
    now = _now()
    new = dict(cand)
    new.update({"saved": now, "saved_by": _s(by), "last_ok": now, "last_error": ""})
    _save(new)
    _journal(old, new)


def remove(by="") -> dict:
    _remove()
    return settings()


@one_writer.guard("ALLDEVICE_JSON")
def _remove() -> bool:
    old = _load()
    if not old:
        return False
    _save({})
    _journal(old, {})
    return True


def test(by="") -> dict:
    """Перевірка звʼязку збереженими реквізитами."""
    cats = call(PROBE_DOOR, {})
    _mark(ok=True)
    return {"ok": True, "categories": len(cats) if isinstance(cats, list) else 0,
            "settings": settings()}


@one_writer.guard("ALLDEVICE_JSON")
def _mark(ok=False, error="") -> None:
    d = _load()
    if not configured(d):
        return
    if ok:
        d["last_ok"], d["last_error"] = _now(), ""
    else:
        d["last_error"] = _s(error)[:400]
    _save(d)


def _journal(old: dict, new: dict) -> None:
    """Рядок у журналі безпеки: було → стало. Пароля й ключа тут немає — лише факт зміни."""
    fields = (("tenant", "Адреса"), ("username", "Користувач"))
    chs = [(label, _s(old.get(k)), _s(new.get(k))) for k, label in fields
           if _s(old.get(k)) != _s(new.get(k))]
    if new and _s(old.get("password")) != _s(new.get("password")):
        chs.append(("Пароль", "", "змінено"))
    if new and _s(old.get("key")) != _s(new.get("key")):
        chs.append(("Ключ API", "", "змінено"))
    note = ("підключення відключено" if not new else
            ("підключення заведено" if not configured(old) else "підключення змінено"))
    try:
        import security_log
        security_log.alldevice_event(chs, note=note)
    except Exception:
        pass
