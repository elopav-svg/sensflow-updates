# -*- coding: utf-8 -*-
"""chat_view.py — ⭐ ОДИН РЕНДЕР ТЕКСТУ ДЛЯ ФАЙЛА І ДЛЯ ЧАТУ (зміна 811, 16.10.2026).

🩸 Борг точки 789 (14.10.2026): чат показував відповідь сирим markdown — таблиці з «|», заголовки «#»,
списки й лінії «---» — і в живій відповіді, і в розмові, відкритій з історії. А файл `.html` того самого
прогону був гарний.
⛒ КЛАС: два писарі однієї розмітки. Повний рендер (`artifacts.md_body`: таблиці, заголовки, списки,
лінії, цитати) жив на сервері для файлів, а екран чату мав свій урізаний (`mdLite`: лише жирний,
код, «###» і посилання). Кожен новий елемент розмітки треба було б вчити двох — і другий завжди
відставав.
⛒ ЛІК: розмітку в HTML перекладає ОДИН писар — сервер, тією самою функцією, що й файл. Відповідь чату
(жива й з історії) їде з готовим HTML; екран нічого не розбирає, а лише вставляє. Чого сервер не
відрендерив (службові написи самого екрана), екран показує звичайним текстом — без другого розбору.
"""
import copy

import artifacts


def html(md) -> str:
    """Markdown → HTML-тіло (без <html>/<body>), тим самим писарем, що й файл `.html`."""
    s = str(md or "")
    return artifacts.md_body(s) if s.strip() else ""


def for_reply(payload):
    """Відповідь ходу для екрана: додати HTML до репліки й до результату. Вхід не змінюється."""
    if not isinstance(payload, dict):
        return payload
    out = dict(payload)
    out["reply_html"] = html(out.get("reply"))
    res = out.get("result")
    if isinstance(res, dict):
        res = dict(res)
        res["final_html"] = html(res.get("final_markdown"))
        out["result"] = res
    return out


def for_thread(rec):
    """Розмова з історії для екрана: те саме, що й жива відповідь, — для кожної репліки платформи."""
    if not isinstance(rec, dict):
        return rec
    out = copy.deepcopy(rec)
    for m in out.get("messages") or []:
        if not isinstance(m, dict) or m.get("role") == "user":
            continue
        m["html"] = html(m.get("content"))
        if isinstance(m.get("result"), dict):
            m["result"]["final_html"] = html(m["result"].get("final_markdown"))
    return out
