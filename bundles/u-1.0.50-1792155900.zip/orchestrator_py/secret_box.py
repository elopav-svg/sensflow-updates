# -*- coding: utf-8 -*-
"""secret_box.py — СЕКРЕТИ В СПОКОЇ ПІД ЗАХИСТОМ WINDOWS (зміна 806, 15.10.2026, ТЗІ група Б1).

🩸 ЩО БУЛО. Ключі моделей, токени ботів, секрет підпису, паролі пошти, пароль і ключ Alldevice,
токени конекторів лежали у файлах платформи відкритим текстом. Копія теки (резервна копія,
знятий диск, архів на флешці) — і всі секрети в чужих руках. Вимога експертизи ТЗІ: секрети,
що зберігаються, захищені.

⛒ КЛАС: «секрет на диску відкритим текстом». ОДНА скринька, і кожне сховище секретів кладе
(`kept`) і бере (`opened`) їх лише через неї:
  • захист — Windows DPAPI (`CryptProtectData`, лише stdlib через ctypes), область МАШИНИ:
    служба під SYSTEM і кнопки під користувачем читають те саме. Відкрити — лише на тій самій
    машині; копія файлів на іншій машині не відкривається;
  • запечатане значення — рядок `dpapi:<base64>`; відкритий текст іде крізь `open_` як є, тож
    старі файли читаються без жодного переходу;
  • нечитане (зіпсоване або з іншої машини) — ПОРОЖНЄ і назване вголос (`UNREADABLE`, лише
    назва, без значення): текст із позначкою постачальнику як ключ не йде ніколи.
⛒ ПРАВИЛО 804. Запечатує ЛИШЕ посилений профіль (`security_profile.hardened`). У Каспера й ОТУ
файли байт у байт ті самі, адміністратору нічого не робити. ПРОЧИТАТИ запечатане вміє будь-яка
збірка від 806.
⛒ МЕЖА, СКАЗАНА СЛОВАМИ. Область машини означає: на ЦІЙ машині прочитати може процес, що має
доступ до файлу (тому право на файли — у служби й адміністраторів). Захищає від копії поза
машиною. Перенесення на іншу машину з запечатаними секретами = ключі вписати заново.
Відкат нижче 806 у посиленому профілі — те саме.

Проба: secret_box_806_test.py (+ _mutants).
"""
import base64
import os

PREFIX = "dpapi:"
_ENTROPY = b"SensFlow/secret_box/806"
_UI_FORBIDDEN = 0x01
_LOCAL_MACHINE = 0x04

# Назва ключа налаштувань — секрет, якщо закінчується так. `..._TOKENS` (межі відповіді) — ні.
SECRET_SUFFIXES = ("_KEY", "_TOKEN", "_SECRET", "_PASSWORD", "_PASS", "_PWD")

# ⛒ Сховища секретів: модуль → поля, що лягають у скриньку. Новий модуль, що зберігає
# пароль, ключ чи токен, мусить стати тут (або в EXEMPT з причиною) — так каже проба 806.
STORES = {
    "notify_mail": ("password",),
    "mail_intake": ("password",),
    "alldevice": ("password", "key"),
    "connector_oauth": ("access_token", "refresh_token", "token", "id_token"),
}
EXEMPT = {
    "crm": "база ліцензій постачальника (секрети підпису клієнтів) живе лише на нашій машині, "
           "у клієнта порожня; захист — сам комп'ютер постачальника, не профіль клієнта",
}

# Назви секретів, що на цій машині не відкрились (без значень).
UNREADABLE = []

_API = {}


def _api():
    if _API:
        return _API
    import ctypes
    from ctypes import wintypes

    class BLOB(ctypes.Structure):
        _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_char))]

    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    pb = ctypes.POINTER(BLOB)
    protect = crypt32.CryptProtectData
    protect.argtypes = [pb, wintypes.LPCWSTR, pb, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, pb]
    protect.restype = wintypes.BOOL
    unprotect = crypt32.CryptUnprotectData
    unprotect.argtypes = [pb, ctypes.c_void_p, pb, ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, pb]
    unprotect.restype = wintypes.BOOL
    free = kernel32.LocalFree
    free.argtypes = [ctypes.c_void_p]
    free.restype = ctypes.c_void_p
    _API.update(ctypes=ctypes, BLOB=BLOB, protect=protect, unprotect=unprotect, free=free)
    return _API


def _blob(data: bytes):
    a = _api()
    ct = a["ctypes"]
    buf = ct.create_string_buffer(data, len(data))
    return a["BLOB"](len(data), ct.cast(buf, ct.POINTER(ct.c_char))), buf


def _run(protecting: bool, data: bytes) -> bytes:
    a = _api()
    ct = a["ctypes"]
    inp, _keep1 = _blob(data)
    ent, _keep2 = _blob(_ENTROPY)
    out = a["BLOB"]()
    if protecting:
        ok = a["protect"](ct.byref(inp), "SensFlow", ct.byref(ent), None, None,
                          _UI_FORBIDDEN | _LOCAL_MACHINE, ct.byref(out))
    else:
        ok = a["unprotect"](ct.byref(inp), None, ct.byref(ent), None, None,
                            _UI_FORBIDDEN, ct.byref(out))
    if not ok:
        raise OSError(ct.get_last_error(), "захист Windows відмовив")
    try:
        return ct.string_at(out.pbData, out.cbData)
    finally:
        a["free"](out.pbData)


def available() -> bool:
    """Чи є на цій машині захист Windows (DPAPI)."""
    if os.name != "nt":
        return False
    try:
        _api()
        return True
    except Exception:
        return False


def want() -> bool:
    """Чи запечатувати тут: лише посилений профіль (804) і лише де є чим."""
    try:
        import security_profile
        return bool(security_profile.hardened()) and available()
    except Exception:
        return False


def is_secret_name(name: str) -> bool:
    return str(name or "").strip().upper().endswith(SECRET_SUFFIXES)


def is_sealed(value) -> bool:
    return isinstance(value, str) and value.startswith(PREFIX)


def seal(text: str) -> str:
    """Запечатати. Порожнє й уже запечатане — як є (один шар)."""
    if not isinstance(text, str) or not text or is_sealed(text):
        return text
    return PREFIX + base64.b64encode(_run(True, text.encode("utf-8"))).decode("ascii")


def open_(value, name: str = ""):
    """Відкрити. Відкритий текст — як є. Нечитане — порожньо і назване в UNREADABLE."""
    if not is_sealed(value):
        return value
    try:
        return _run(False, base64.b64decode(value[len(PREFIX):], validate=True)).decode("utf-8")
    except Exception:
        nm = str(name or "секрет")
        if nm not in UNREADABLE:
            UNREADABLE.append(nm)
        return ""


def keep(value):
    """Як класти секрет у спокій: запечатаним у посиленому профілі, інакше як є."""
    return seal(value) if want() else value


def _walk(obj, fields, fn, where=""):
    if isinstance(obj, dict):
        return {k: (fn(v, k if not where else "%s.%s" % (where, k)) if k in fields and isinstance(v, str)
                    else _walk(v, fields, fn, where)) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_walk(v, fields, fn, where) for v in obj]
    return obj


def opened(data, fields, where: str = ""):
    """Сховище прочитало файл — секретні поля (на будь-якій глибині) відкриваються."""
    return _walk(data, set(fields), lambda v, k: open_(v, k), where)


def kept(data, fields):
    """Сховище пише файл — НОВА копія зі запечатаними полями; словник того, хто пише, не змінюється."""
    if not want():
        return data
    return _walk(data, set(fields), lambda v, k: seal(v))


def _reseal_json(path, fields) -> int:
    import one_writer
    try:
        raw = one_writer.read_json(path)
    except Exception:
        return 0
    if not _has_plain(raw, set(fields)):
        return 0
    one_writer.write_json(path, kept(raw, fields))
    return 1


def _has_plain(obj, fields) -> bool:
    if isinstance(obj, dict):
        return any((k in fields and isinstance(v, str) and v and not is_sealed(v))
                   or _has_plain(v, fields) for k, v in obj.items())
    if isinstance(obj, list):
        return any(_has_plain(v, fields) for v in obj)
    return False


def seal_at_rest() -> dict:
    """Старт сервера в посиленому профілі: усе, що ще лежить відкритим, — запечатати.

    Звичайний профіль — нічого не торкається."""
    if not want():
        return {"done": False, "files": 0}
    import importlib
    import config
    n = config.seal_env_files()
    for mod, fields in STORES.items():
        m = importlib.import_module(mod)
        if mod == "connector_oauth":
            paths = sorted(config.CONNECTORS_DIR.rglob("*.token.json")) if config.CONNECTORS_DIR.exists() else []
        else:
            p = getattr(m, "SETTINGS_JSON", None) or getattr(m, "BOXES_JSON", None)
            paths = [p] if p is not None and p.exists() else []
        for p in paths:
            n += _reseal_json(p, fields)
    return {"done": True, "files": n}
