# -*- coding: utf-8 -*-
"""plain_math.py — ⭐ ФОРМУЛА LaTeX — НЕ ФОРМАТ ПРОДУКТУ: ОДИН ПЕРЕКЛАДАЧ У ЗВИЧАЙНИЙ ТЕКСТ (зміна 812, 16.10.2026).

🩸 Борг точки 789 (14.10.2026, рейс для Міленіуму): модель написала викладки формулами LaTeX —
«$$32.0\\text{ л/100 км} \\times 767.9\\text{ км} / 100 \\times 57.00\\text{ грн/л} = \\text{13\\ 998.78\\text{ грн}}$$».
Ні чат, ні `.html`, ні Word формул не малюють — людина бачила «$$», «\\times», «\\text{…}» сирими, хоча
просила «розрахунки звичайним текстом». А суддя викладки (578) мав СВІЙ розбір LaTeX, який знав лише
«\\,» як роздільник тисяч: «13\\ 998.78» він прочитав як «13» і вписав у документ клієнта «надруковано 13»
шість разів — і на хибних рядках, і на чесних.
⛒ КЛАС: другий писар формату. Текст моделі входив у продукт формулами, а кожен читач (екран, файл,
суддя) або не розумів їх зовсім, або розумів по-своєму.
⛒ ЛІК: формула стає звичайним текстом ОДИН раз і ОДНИМ писарем — тут. Його кличуть: чистильник
виводу (`verifier.sanitize_output` — результат входить у продукт, і всі судді бачать те саме, що людина),
писар розмітки (`artifacts.md_body` — показ будь-якого тексту, зокрема репліки мозку в чаті) і суддя
арифметики (`arith`, власного розбору LaTeX більше немає).
⛒ МЕЖІ: «$$…$$» — завжди формула; «$…$» — лише коли всередині є команда LaTeX (інакше це долари:
«$5 і $10»). Код у «```» і «`…`» не чіпаємо. Без залежностей — суддя арифметики лишається офлайн.
"""
import re

_FENCE = re.compile(r"(```.*?```|`[^`\n]*`)", re.S)
_BLOCK = re.compile(r"\$\$(.+?)\$\$", re.S)
_INLINE = re.compile(r"(?<![\\$])\$(?!\$)([^$\n]*\\[A-Za-z,;:! ][^$\n]*)\$(?!\$)")

_SYMBOLS = (
    ("times", "×"), ("cdot", "·"), ("div", "÷"), ("pm", "±"), ("approx", "≈"),
    ("leq", "≤"), ("le", "≤"), ("geq", "≥"), ("ge", "≥"), ("neq", "≠"), ("ne", "≠"),
    ("rightarrow", "→"), ("to", "→"), ("Rightarrow", "⇒"), ("infty", "∞"),
    ("Delta", "Δ"), ("sum", "Σ"), ("alpha", "α"), ("beta", "β"), ("cdots", "…"), ("ldots", "…"),
    ("quad", " "), ("qquad", " "), ("left", ""), ("right", ""), ("displaystyle", ""),
)
_WRAPS_PLAIN = ("text", "mathrm", "mathit", "rm", "it", "operatorname", "textrm", "mbox", "textit")
_WRAPS_BOLD = ("mathbf", "textbf", "bf", "boldsymbol")
_SUP = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")


def _group(s, i):
    """Вміст фігурних дужок, що відкриваються на позиції i: (вміст, індекс після дужки) або (None, i)."""
    if i >= len(s) or s[i] != "{":
        return None, i
    depth, j = 0, i
    while j < len(s):
        if s[j] == "{" and (j == 0 or s[j - 1] != "\\"):
            depth += 1
        elif s[j] == "}" and s[j - 1] != "\\":
            depth -= 1
            if depth == 0:
                return s[i + 1:j], j + 1
        j += 1
    return None, i


def _math(s: str) -> str:
    """Тіло формули → звичайний текст."""
    out, i = [], 0
    while i < len(s):
        ch = s[i]
        if ch == "\\":
            m = re.match(r"\\([A-Za-z]+)\s*", s[i:])
            if m:
                name = m.group(1)
                j = i + len(m.group(0))
                if name == "frac":
                    a, j2 = _group(s, j)
                    b, j3 = _group(s, j2) if a is not None else (None, j)
                    if a is not None and b is not None:
                        a, b = _math(a).strip(), _math(b).strip()
                        wrap = lambda x: ("(%s)" % x) if re.search(r"[+\-−×·÷/ ]", x) and re.search(r"[+\-−×·÷/]", x) else x
                        out.append("%s / %s" % (wrap(a), wrap(b)))
                        i = j3
                        continue
                if name in _WRAPS_PLAIN or name in _WRAPS_BOLD:
                    g, j2 = _group(s, j)
                    if g is not None:
                        inner = _math(g)
                        out.append(("**%s**" % inner.strip()) if name in _WRAPS_BOLD else inner)
                        i = j2
                        continue
                sym = dict(_SYMBOLS).get(name)
                if sym is not None:
                    out.append(" %s " % sym if sym and sym not in " " else sym)
                    i = j
                    continue
                out.append(name)              # невідома команда — її слово, без косої риски
                i = j
                continue
            nxt = s[i + 1:i + 2]
            if nxt in (",", ";", ":", "!"):     # пробіли LaTeX (і роздільник тисяч «1\,697»)
                out.append(" ")
                i += 2
                continue
            if nxt in ("%", "$", "{", "}", "_", "&", "#"):
                out.append(nxt)
                i += 2
                continue
            # Будь-яка інша коса риска йде геть, знак за нею лишається: «13\ 998.78» → «13 998.78».
            i += 1
            continue
        if ch == "~":
            out.append(" ")
        elif ch == "^":
            g, j2 = _group(s, i + 1)
            body = g if g is not None else s[i + 1:i + 2]
            plain = _math(body).strip()
            out.append(plain.translate(_SUP) if plain.isdigit() else "^" + plain)
            i = j2 if g is not None else i + 2
            continue
        elif ch == "_":
            g, j2 = _group(s, i + 1)
            if g is not None:
                out.append("_" + _math(g).strip())
                i = j2
                continue
            out.append(ch)
        elif ch in "{}":
            pass
        else:
            out.append(ch)
        i += 1
    t = "".join(out)
    t = re.sub(r"[ \t]{2,}", " ", t)
    t = re.sub(r"\*\*\s+\*\*", " ", t)
    return t


def _plain_part(t: str) -> str:
    t = _BLOCK.sub(lambda m: _math(m.group(1)).strip(), t)
    t = _INLINE.sub(lambda m: _math(m.group(1)).strip(), t)
    return t


def to_plain(text) -> str:
    """Текст із формулами LaTeX → той самий текст звичайним письмом. Без формул — байт у байт той самий."""
    s = str(text or "")
    if "$" not in s and "\\" not in s:
        return s
    parts = _FENCE.split(s)
    for k in range(0, len(parts), 2):                  # непарні — код, його не чіпаємо
        if "$" in parts[k]:
            parts[k] = _plain_part(parts[k])
    return "".join(parts)


def tex_line(line) -> str:
    """Для судді арифметики: рядок, у якому LaTeX без обгорток «$$» (уривок викладки), — теж формула."""
    s = str(line or "")
    if "$" in s:
        return to_plain(s)
    return _math(s) if "\\" in s else s
