# -*- coding: utf-8 -*-
"""repairs_events.py — ДАНІ ALLDEVICE → ОДНА ТАБЛИЦЯ ПОДІЙ (зміна 791, 14.10.2026).

Пілот Малбі «аналітика ремонтів». Рахувати (792) можна лише те, що має однакову форму.
Сирі записи Alldevice — це обладнання з деревом місць, задачі трьох видів, простої,
звіти з витратами; поруч — випуск продукції з Excel. Тут вони стають:
  * `equipment` — обладнання: лінія, місце (повний шлях), агрегат, категорія;
  * `events` — ОДНА таблиця подій (задача або простій) з однаковими полями;
  * `quality` — звіт якості: що в даних неповне чи суперечливе, ЧИСЛАМИ.

⛒ НАЗВИ ПОЛІВ ДЖЕРЕЛА — ЛИШЕ В МАПІ (`repairs_fields`). Тут їх немає жодної: логіка
питає поле через `_f(record, джерело, наша_назва)`. Справжні дані Малбі ми побачимо лише з
доступом; якщо назви чи формат розійдуться зі специфікацією, правиться мапа, а не логіка.

⛒ НЕПОВНЕ НЕ СТАЄ НУЛЕМ. Немає дати — `None`, а не «0000-00-00» і не сьогодні. Незакінчений
простій — без тривалості. Рядок випуску без числа — пропущений і порахований у якості.
Повтор запису (сторінки перекрились) — один раз, і число повторів у якості.

Лише stdlib + `repairs_fields` (+ `alldevice` для `pull`). Без моделі, без мережі в
`normalize`/`production`.
"""
import datetime as _dt

import repairs_fields as RF

T_FAILURE = "failure"       # аварійний ремонт (позапланова задача)
T_PLANNED = "planned"       # плановий ремонт (разова планова задача)
T_REGULAR = "regular"       # регламентне ТО за графіком (ППР)
T_OTHER = "other"           # вид, якого немає в мапі
T_DOWNTIME = "downtime"     # простій обладнання
NO_LINE = "без лінії"

TYPE_NAMES = {T_FAILURE: "аварійний ремонт", T_PLANNED: "плановий ремонт",
              T_REGULAR: "регламентне ТО", T_OTHER: "інше", T_DOWNTIME: "простій"}


def _f(rec, src, name, default=None):
    """Поле запису через мапу. Немає поля — `default`."""
    if not isinstance(rec, dict):
        return default
    key = RF.FIELDS.get(src, {}).get(name)
    if key is None:
        return default
    v = rec.get(key, default)
    return default if v is None else v


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _num(v):
    """Число з тексту: «1 250,5», «1250.5», «−3»; не число — None."""
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v)
    t = _s(v).replace(" ", "").replace(" ", "").replace(" ", "")
    t = t.replace(",", ".").replace("−", "-")
    try:
        return float(t)
    except ValueError:
        return None


def _dtime(v):
    """Дата й час або None. «0000-00-00» — дати немає."""
    if isinstance(v, _dt.datetime):
        return v
    if isinstance(v, _dt.date):
        return _dt.datetime(v.year, v.month, v.day)
    t = _s(v)
    if t in RF.EMPTY_DATES:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d",
                "%d.%m.%Y %H:%M:%S", "%d.%m.%Y %H:%M", "%d.%m.%Y", "%d.%m.%y"):
        try:
            return _dt.datetime.strptime(t, fmt)
        except ValueError:
            continue
    return None


def _date(v):
    d = _dtime(v)
    return d.date() if d else None


def _hours(v):
    """«03:30» → 3.5; число — як є (години)."""
    t = _s(v)
    if ":" in t:
        p = t.split(":")
        try:
            return round(int(p[0]) + int(p[1]) / 60.0, 2)
        except (ValueError, IndexError):
            return None
    n = _num(t)
    return n


# ── ОБЛАДНАННЯ ───────────────────────────────────────────────────────────────
def _locations(tree) -> dict:
    """id місця → перелік назв від кореня до нього."""
    out = {}

    def walk(nodes, chain):
        for n in nodes or []:
            if not isinstance(n, dict):
                continue
            lid = _int(_f(n, "location", "id"))
            names = chain + [_s(_f(n, "location", "name"))]
            if lid is not None:
                out[lid] = names
            walk(_f(n, "location", "children", []), names)
    walk(tree if isinstance(tree, list) else [], [])
    return out


def _equipment(raw, quality) -> dict:
    locs = _locations(raw.get("locations"))
    cats = {_int(_f(c, "category", "id")): _s(_f(c, "category", "name"))
            for c in raw.get("categories") or [] if isinstance(c, dict)}
    eq = {}
    for d in raw.get("devices") or []:
        did = _int(_f(d, "device", "id"))
        if did is None:
            quality["device_without_id"] = quality.get("device_without_id", 0) + 1
            continue
        names = locs.get(_int(_f(d, "device", "location")))
        if names is None:
            # Запасний шлях — повний шлях місць «/0/1/11/111»: найглибше відоме місце.
            for part in reversed(_s(_f(d, "device", "path")).strip("/").split("/")):
                if _int(part) in locs:
                    names = locs[_int(part)]
                    break
        if names:
            line = names[RF.LINE_DEPTH] if len(names) > RF.LINE_DEPTH else names[-1]
            place = " / ".join(names)
        else:
            line, place = NO_LINE, ""
            quality["device_without_place"] = quality.get("device_without_place", 0) + 1
        eq[did] = {"id": did, "name": _s(_f(d, "device", "name")) or ("#%d" % did),
                   "line": line, "place": place,
                   "category": cats.get(_int(_f(d, "device", "category")), ""),
                   "inventory": _s(_f(d, "device", "inventory")),
                   "serial": _s(_f(d, "device", "serial")),
                   "hours": _num(_f(d, "device", "hours")),
                   "status": _s(_f(d, "device", "status"))}
    return eq


def _where(eq, did, quality):
    e = eq.get(did)
    if e:
        return e["name"], e["line"], e["place"]
    quality["unknown_device"] = quality.get("unknown_device", 0) + 1
    return ("#%s" % did if did is not None else "?"), NO_LINE, ""


# ── ПОДІЇ ────────────────────────────────────────────────────────────────────
def _reports(raw) -> dict:
    out = {}
    for r in raw.get("reports") or []:
        tid = _int(_f(r, "report", "task"))
        if tid is None:
            continue
        cur = out.setdefault(tid, {"work_h": None, "cost": None, "spares_cost": None})
        for k, src, conv in (("work_h", "time", _hours), ("cost", "cost", _num),
                             ("spares_cost", "spares_cost", _num)):
            v = conv(_f(r, "report", src))
            if v is not None:
                cur[k] = round((cur[k] or 0) + v, 2)   # кілька звітів однієї задачі — сума
    return out


def _task(t, eq, reps, quality) -> dict:
    tid = _int(_f(t, "task", "id"))
    did = _int(_f(t, "task", "device"))
    name, line, place = _where(eq, did, quality)
    kind = RF.TASK_TYPES.get(_s(_f(t, "task", "type")).lower())
    if kind is None:
        kind = T_OTHER
        quality["unknown_task_type"] = quality.get("unknown_task_type", 0) + 1
    fault = _f(t, "task", "fault")
    if isinstance(fault, dict):
        fault = _s(fault.get(RF.FIELDS["task"]["fault_title"]))
    users = [_s(_f(u, "task", "user_name")) for u in (_f(t, "task", "users", []) or [])
             if isinstance(u, dict) and _s(_f(u, "task", "user_name"))]
    done = bool(_f(t, "task", "done", False))
    due = _date(_f(t, "task", "due"))
    plan = _date(_f(t, "task", "plan")) or due
    fact = _date(_f(t, "task", "fact")) if done else None
    rep = reps.get(tid) or {}
    spares = None
    for sp in _f(t, "task", "spares", []) or []:
        q, p = _num(_f(sp, "task", "spare_qty")), _num(_f(sp, "task", "spare_price"))
        if q is not None and p is not None:
            spares = round((spares or 0) + q * p, 2)
    if done and fact is None:
        quality["done_without_date"] = quality.get("done_without_date", 0) + 1
    return {"kind": "task", "id": tid, "number": _s(_f(t, "task", "number")),
            "device_id": did, "device": name, "line": line, "place": place,
            "type": kind, "subject": _s(_f(t, "task", "subject")), "fault": _s(fault),
            "plan": plan, "due": due, "fact": fact, "done": done,
            "late_days": (fact - due).days if (fact and due) else None,
            "fact_start": None, "fact_end": None, "duration_h": None,
            "work_h": rep.get("work_h"), "cost": rep.get("cost"),
            "spares_cost": rep.get("spares_cost") if rep.get("spares_cost") is not None else spares,
            "users": users, "confirmed_by": _s(_f(t, "task", "confirmed_by")),
            "created": _dtime(_f(t, "task", "created")),
            "postponed": bool(_f(t, "task", "postponed", False)),
            "planned": kind in (T_PLANNED, T_REGULAR), "category": ""}


def _downtime(d, eq, quality) -> dict:
    did = _int(_f(d, "downtime", "device"))
    name, line, place = _where(eq, did, quality)
    start, end = _dtime(_f(d, "downtime", "start")), _dtime(_f(d, "downtime", "end"))
    ended = _f(d, "downtime", "ended", None)
    secs = _num(_f(d, "downtime", "seconds"))
    dur = None
    if ended is False or end is None:
        quality["downtime_open"] = quality.get("downtime_open", 0) + 1
        end = None
    elif secs is not None and secs >= 0:
        dur = round(secs / 3600.0, 2)
    elif start and end and end >= start:
        dur = round((end - start).total_seconds() / 3600.0, 2)
    else:
        quality["downtime_bad_time"] = quality.get("downtime_bad_time", 0) + 1
    cat = _s(_f(d, "downtime", "category"))
    planned = any(w in cat.lower() for w in RF.PLANNED_DOWNTIME_WORDS)
    return {"kind": "downtime", "id": _int(_f(d, "downtime", "id")), "number": "",
            "device_id": did, "device": name, "line": line, "place": place,
            "type": T_DOWNTIME, "subject": _s(_f(d, "downtime", "comment")), "fault": "",
            "plan": None, "due": None, "fact": start.date() if start else None,
            "done": end is not None, "late_days": None,
            "fact_start": start, "fact_end": end, "duration_h": dur,
            "work_h": None, "cost": None, "spares_cost": None, "users": [],
            "confirmed_by": "", "created": None, "postponed": False,
            "planned": planned, "category": cat}


def event_date(e):
    """Дата події для періоду й порядку: факт, інакше строк, інакше план."""
    return e.get("fact") or e.get("due") or e.get("plan")


def normalize(raw: dict) -> dict:
    """Сирий знімок Alldevice → {"equipment", "events", "quality", "period"}."""
    raw = raw if isinstance(raw, dict) else {}
    quality = {}
    eq = _equipment(raw, quality)
    reps = _reports(raw)
    events, seen = [], set()
    for src, fn in (("task", lambda r: _task(r, eq, reps, quality)),
                    ("downtime", lambda r: _downtime(r, eq, quality))):
        for r in raw.get(src + "s") or []:
            rid = _int(_f(r, src, "id"))
            if (src, rid) in seen:
                quality["duplicates"] = quality.get("duplicates", 0) + 1
                continue
            seen.add((src, rid))
            events.append(fn(r))
    events.sort(key=lambda e: (event_date(e) or _dt.date.max, e["kind"], e["id"] or 0))
    dates = [event_date(e) for e in events if event_date(e)]
    if len(dates) < len(events):
        quality["event_without_date"] = len(events) - len(dates)
    return {"equipment": eq, "events": events, "quality": quality,
            "period": (min(dates), max(dates)) if dates else None}


# ── ВИПУСК ПРОДУКЦІЇ (Excel / BI) ────────────────────────────────────────────
def _excel_date(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool) and 20000 < v < 80000:
        return (_dt.datetime(1899, 12, 30) + _dt.timedelta(days=float(v))).date()
    return _date(v)


def production(table) -> dict:
    """Таблиця випуску (перший рядок — заголовки) → {"rows", "unit", "quality"}."""
    rows = [list(r) for r in (table or []) if isinstance(r, (list, tuple))]
    if not rows:
        raise ValueError("Таблиця випуску порожня.")
    head = [_s(h).lower() for h in rows[0]]
    col = {}
    for key, words in RF.PRODUCTION_HEADERS.items():
        for i, h in enumerate(head):
            if i not in col.values() and any(h.startswith(w) for w in words):
                col[key] = i
                break
    if "date" not in col or "output" not in col:
        raise ValueError("У таблиці випуску не знайдено стовпців дати й випуску (шукаю "
                         "заголовки «Дата» і «Випуск/Обсяг/Кількість»).")
    oh = _s(rows[0][col["output"]])
    unit = ""
    if "," in oh:
        unit = oh.split(",", 1)[1].strip()
    elif "(" in oh and ")" in oh:
        unit = oh[oh.index("(") + 1:oh.rindex(")")].strip()
    out, skipped = [], 0
    for r in rows[1:]:
        cell = (lambda k: r[col[k]] if k in col and col[k] < len(r) else None)
        d, v = _excel_date(cell("date")), _num(cell("output"))
        if d is None or v is None:
            if any(_s(x) for x in r):
                skipped += 1
            continue
        out.append({"date": d, "line": _s(cell("line")), "shift": _s(cell("shift")),
                    "output": v})
    return {"rows": out, "unit": unit, "quality": {"skipped": skipped}}


# ── ЗНІМОК З ALLDEVICE ───────────────────────────────────────────────────────
def pull(date_from, date_to, fetch=None) -> dict:
    """Сирий знімок за період через конектор лише на читання (`alldevice.fetch_all`)."""
    if fetch is None:
        import alldevice
        fetch = alldevice.fetch_all
    ds, de = _s(date_from), _s(date_to)
    raw = {}
    for key, door, filters in RF.REQUESTS:
        body = {k: (ds if v == "{from}" else de if v == "{to}" else v)
                for k, v in (filters or {}).items()}
        raw[key] = fetch(door, body)
    return raw
