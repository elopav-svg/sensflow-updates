# -*- coding: utf-8 -*-
"""ed25519.py — ПІДПИС Ed25519 (RFC 8032) НА ЧИСТОМУ PYTHON (зміна 798, 15.10.2026).

🩸 НАВІЩО. До 798 маніфест оновлень і ключ ліцензії підписувались HMAC-SHA256: секрет
лежав і в постачальника, і на машині замовника. Хто має машину замовника, той має й
секрет — і може підписати будь-яке «оновлення» чи ліцензію (паспорт 784, розділ 15).
⛒ АСИМЕТРИЧНИЙ ПІДПИС: закритий ключ лише в постачальника, у замовника — відкритий.
Перевірити підпис може будь-хто, підробити — ніхто.

⛒ ЧОМУ СВІЙ КОД, А НЕ БІБЛІОТЕКА. Пакет замовника везе власний Python і перелічені
колеса (`client_runtime`); нова бінарна залежність — це новий двійковий файл у
збірці, нові контрольні суми і нова точка відмови. Ed25519 — ~100 рядків чистої
арифметики (RFC 8032, розділ 5.1); перевірка підпису маніфесту — десятки мілісекунд.
Правильність доводить проба на векторах RFC 8032 і звірці з незалежною реалізацією.

⚠ Цей модуль — для ПЕРЕВІРКИ цілісності наших маніфестів і ліцензій. Сталий час
виконання (захист від атак за часом) тут не потрібен: підписує лише постачальник на
своїй машині, а замовник лише перевіряє відкритий підпис.
"""
import hashlib

_P = 2 ** 255 - 19
_L = 2 ** 252 + 27742317777372353535851937790883648493
_D = (-121665 * pow(121666, _P - 2, _P)) % _P
_I = pow(2, (_P - 1) // 4, _P)


def _h(m: bytes) -> int:
    return int.from_bytes(hashlib.sha512(m).digest(), "little")


def _recover_x(y: int, sign: int):
    if y >= _P:
        return None
    x2 = (y * y - 1) * pow(_D * y * y + 1, _P - 2, _P)
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (_P + 3) // 8, _P)
    if (x * x - x2) % _P != 0:
        x = x * _I % _P
    if (x * x - x2) % _P != 0:
        return None
    if (x & 1) != sign:
        x = _P - x
    return x


_GY = 4 * pow(5, _P - 2, _P) % _P
_GX = _recover_x(_GY, 0)
_G = (_GX, _GY, 1, _GX * _GY % _P)
_ZERO = (0, 1, 1, 0)


def _add(a, b):
    x1, y1, z1, t1 = a
    x2, y2, z2, t2 = b
    A = (y1 - x1) * (y2 - x2) % _P
    B = (y1 + x1) * (y2 + x2) % _P
    C = 2 * t1 * t2 * _D % _P
    Dd = 2 * z1 * z2 % _P
    E, F, G, H = B - A, Dd - C, Dd + C, B + A
    return (E * F % _P, G * H % _P, F * G % _P, E * H % _P)


def _mul(s: int, p):
    q = _ZERO
    while s > 0:
        if s & 1:
            q = _add(q, p)
        p = _add(p, p)
        s >>= 1
    return q


def _eq(a, b) -> bool:
    x1, y1, z1, _ = a
    x2, y2, z2, _ = b
    return (x1 * z2 - x2 * z1) % _P == 0 and (y1 * z2 - y2 * z1) % _P == 0


def _compress(p) -> bytes:
    x, y, z, _ = p
    zi = pow(z, _P - 2, _P)
    x, y = x * zi % _P, y * zi % _P
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s: bytes):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    if x is None:
        return None
    return (x, y, 1, x * y % _P)


def _expand(secret: bytes):
    if len(secret) != 32:
        raise ValueError("закритий ключ Ed25519 — рівно 32 байти")
    h = hashlib.sha512(secret).digest()
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def public_key(secret: bytes) -> bytes:
    """Відкритий ключ (32 байти) із закритого (32 байти)."""
    a, _ = _expand(secret)
    return _compress(_mul(a, _G))


def sign(secret: bytes, msg: bytes) -> bytes:
    """Підпис (64 байти). Детермінований: той самий ключ і текст — той самий підпис."""
    a, prefix = _expand(secret)
    A = _compress(_mul(a, _G))
    r = _h(prefix + msg) % _L
    R = _compress(_mul(r, _G))
    k = _h(R + A + msg) % _L
    s = (r + k * a) % _L
    return R + int.to_bytes(s, 32, "little")


def verify(public: bytes, msg: bytes, signature: bytes) -> bool:
    """Чи підписав `msg` власник закритого ключа до `public`. Ніколи не кидає."""
    try:
        if len(public) != 32 or len(signature) != 64:
            return False
        A = _decompress(public)
        if A is None:
            return False
        R = _decompress(signature[:32])
        if R is None:
            return False
        s = int.from_bytes(signature[32:], "little")
        if s >= _L:
            return False
        k = _h(signature[:32] + public + msg) % _L
        return _eq(_mul(s, _G), _add(R, _mul(k, A)))
    except Exception:
        return False
