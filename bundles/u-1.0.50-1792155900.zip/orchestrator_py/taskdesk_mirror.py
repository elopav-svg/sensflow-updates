# -*- coding: utf-8 -*-
"""
taskdesk_mirror.py — ОДИН ЧИТАЧ ЖУРНАЛУ: ДЗЕРКАЛО КЕРІВНИКА І РОЗДІЛ ЗВІТУ.

Записка: DESIGN_Звіт_розробнику_і_Дзеркало_керівника.md (29.08.2026).
Слово Андрія 30.08.2026: читач замість лічильників · перелік показників як є ·
дзеркало — ОКРЕМА ПЛАТНА ПОЗИЦІЯ.

КЛАС ПРОБЛЕМИ. Продукт щодня пише факти про власну роботу — і не має нікого,
хто перетворює їх на картину. Той самий клас уже був у журналу подій до появи
зведення: журнал, якого ніхто не читає, — нуль.

ТОЧКА РІШЕННЯ. Одна — цей файл. Він і тільки він рахує підсумки. Нових
лічильників поруч із журналом не заводимо: другий рахунок розійшовся б із
першим на першому ж збої.

УСІ КАНАЛИ. Екран дзеркала (вдома, з іменами), розділ у звіті розробнику
(назовні, без імен) і будь-який майбутній вивіз питають ЦЕЙ модуль.

ЧИ ПРОТЕЧЕ МАЙБУТНІЙ КАНАЛ. Тут головна небезпека: обидва зрізи їдять один
журнал, але один лишається вдома з іменами, а другий їде назовні. Якби
знеособлення жило в каналі, перший же новий канал повіз би імена. Тому
ЗНЕОСОБЛЕННЯ ЖИВЕ ТУТ: `anon()` — єдиний зріз, який узагалі можна кудись
віддати, і в його виводі не існує ні ідентифікатора людини, ні назви задачі,
ні вільного тексту. `named()` віддає імена і питає право по ДЕРЕВУ компанії,
а не по галочці [[project_unit_liquidation]].

⭐ ВЛАСНИЙ РОТ ПРОТИ ПРИБИРАННЯ. `taskdesk_events.prune()` викидає події, які
забрали ВСІ роти. Дзеркало, що читає місяці, одного дня прокинулось би з
порожнім журналом і показало керівникові нуль замість роботи. Тому воно
реєструється СВОЇМ ротом і веде власний підсумковий файл: у ньому лежать
ЧИСЛА, а не події, — він не росте разом із журналом.

⚠ ЧОГО ТУТ НЕМАЄ І ЧОМУ. «Чим користуються: дошка, список, пошук, фільтр,
вивіз» і «скільки разів людина натрапила на порожній екран» — цього в журналі
НЕМАЄ: там лежать лише події ЗАДАЧ. Це не забуте поле, а нові двері (запис
натискань людини), і вони не відчиняються без прямого слова Андрія.

⚠ МЕЖА, ЯКУ КАЖЕМО КЕРІВНИКОВІ ВГОЛОС: дзеркало міряє роботу В СИСТЕМІ. Хто
працює повз систему — тут невидимий, і нуль у нього означає «не бачу», а не
«не працює».
"""

import json
import sys

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import taskdesk_events as events
import taskdesk_people as people
import taskdesk_tasks as tasks
import taskdesk_templates as tpls   # ⭐ 707: слово «Інше» — одне на продукт
import one_writer

DESK_DIR = config.STATE_DIR / "taskdesk"

# ⛒ ДРУГИЙ ЗАМОК: чек, завантажений не через файл, не сміє працювати по
# бойовому стану — тут живі люди й задачі.
config.refuse_live_state_for_checks(__name__)

TOTALS = DESK_DIR / "mirror_totals.json"
SINK = "mirror"           # імʼя нашого рота в журналі подій
REASONS_KEEP = 200        # причини відмов — лише останні; це слова, не числа
DEFAULT_DAYS = 30
NOBODY = "-"              # подію народив сторож, а не людина

# Види, які в підсумках рахуються окремим іменем, хоч і не є видами події.
COUNT_REWORK = "rework"   # результат зʼявився ВДРУГЕ — робота вернулась
COUNT_CLOSED = "closed"   # задача доїхала до закритої стадії
# ⭐⭐ 706 (проєкт розробки ОТУ, 3.4 і 3.6). Провал перевірки лягає на ВИКОНАВЦЯ (на ньому
# висіла робота), а не на того, хто не прийняв; ясність постановки — на ПОСТАНОВНИКА.
# Тому ці числа кладуться в кошик не діяча події, а тієї людини, про кого вона.
COUNT_FAILED = "failed"                   # робота людини не пройшла перевірку
COUNT_SET_FIRST = "set_clear_first"       # її задачу зрозуміли з першого разу
COUNT_SET_CLARIFY = "set_clarified"       # по її задачі просили уточнення
COUNT_SET_UNCLEAR = "set_unclear"         # її задача стояла незрозумілою добу
# ⭐ 708 (3.5, 4.4 Б): етап, почато раніше попереднього, — на виконавця етапу.
COUNT_EARLY = "early"
# Числа «про людину», а не її дії: у «скільки дій за період» вони не входять.
SYNTH = (COUNT_REWORK, COUNT_CLOSED, COUNT_FAILED, COUNT_SET_FIRST,
         COUNT_SET_CLARIFY, COUNT_SET_UNCLEAR, COUNT_EARLY)


class MirrorError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


# ---------------------------------------------------------------------------
# ПІДСУМКОВИЙ ФАЙЛ: день × людина × вид. Чисел небагато, подій — скільки завгодно.
# ---------------------------------------------------------------------------
def _empty() -> dict:
    # ⭐ 706: `fails` — причини провалів (слова, лише останні); `pfail` — день ×
    # проєкт × виконавець: числа без обрізання, щоб проєкт міряти чесно.
    # ⭐ 707: `tpl` — день × людина × причина з шаблону; `tplp` — те саме по проєктах;
    # `tpl_other` — слова «Інше» (лише останні).
    # ⭐ 708: `early` — етапи, почато раніше попереднього (з причиною; лише останні).
    return {"version": 1, "days": {}, "tasks": {}, "reasons": [], "fails": [], "pfail": {},
            "tpl": {}, "tplp": {}, "tpl_other": [], "early": []}


def _load() -> dict:
    try:
        d = one_writer.read_json(TOTALS)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        return _empty()
    if not isinstance(d, dict) or not isinstance(d.get("days"), dict):
        return _empty()
    if not isinstance(d.get("tasks"), dict):
        d["tasks"] = {}
    if not isinstance(d.get("reasons"), list):
        d["reasons"] = []
    if not isinstance(d.get("fails"), list):
        d["fails"] = []
    if not isinstance(d.get("pfail"), dict):
        d["pfail"] = {}
    for k in ("tpl", "tplp"):
        if not isinstance(d.get(k), dict):
            d[k] = {}
    if not isinstance(d.get("tpl_other"), list):
        d["tpl_other"] = []
    if not isinstance(d.get("early"), list):
        d["early"] = []
    d.setdefault("version", 1)
    return d


def _save(state: dict) -> None:
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(TOTALS, state)


def fold(rows, state=None) -> dict:
    """ЧИСТЕ згортання подій у підсумки: ні диска, ні годинника.

    ⭐ Саме тому чек може прогнати його на СПРАВЖНІХ подіях із журналу, а не на
    вигаданому наборі полів [[feedback_stand_must_mirror_real_path]]."""
    st = state if state is not None else _empty()
    st.setdefault("fails", [])
    st.setdefault("pfail", {})
    st.setdefault("tpl", {})
    st.setdefault("tplp", {})
    st.setdefault("tpl_other", [])
    st.setdefault("early", [])

    def about(day, who, key):
        """+1 у кошик людини, ПРО КОГО подія (706), а не того, хто її зробив."""
        box = st["days"].setdefault(day, {}).setdefault(who or NOBODY, {})
        box[key] = int(box.get(key) or 0) + 1

    for e in rows or []:
        kind = str(e.get("kind") or "")
        if kind not in events.KINDS_ALL:
            continue
        day = str(e.get("at") or "")[:10]
        if len(day) != 10:
            continue
        who = str(e.get("actor_id") or "").strip() or NOBODY
        tid = str(e.get("task_id") or "").strip()
        det = e.get("details") or {}
        # ⛒ 708: рух головної задачі ЗА ЕТАПАМИ — наслідок, а не чиясь робота: ні «закрито»,
        # ні «прийнято з першого разу» він людині не додає (робота — це її етапи).
        if kind == events.KIND_STAGE and det.get("by_steps"):
            continue
        led = st["tasks"].setdefault(tid, {"r": 0, "v": 0}) if tid else None
        bucket = st["days"].setdefault(day, {}).setdefault(who, {})
        bucket[kind] = int(bucket.get(kind) or 0) + 1
        if kind == events.KIND_STAGE:
            # «Закрито» — це СТАДІЯ, а не окремий вид події. Судимо тут, за
            # переліком закритих стадій самого Task Desk: якби це рахував звіт,
            # він мусив би завести власне уявлення про те, що таке «закрито».
            if str(det.get("stage") or "") in tasks.STAGES_CLOSED:
                bucket[COUNT_CLOSED] = int(bucket.get(COUNT_CLOSED) or 0) + 1
        accepted = (kind == events.KIND_VERIFIED
                    or (kind == events.KIND_STAGE
                        and str(det.get("stage") or "") == tasks.STAGE_DONE))
        if kind == events.KIND_RESULT and led is not None:
            led["r"] = int(led.get("r") or 0) + 1
            if led["r"] > 1:
                # Результат удруге по тій самій задачі: з першого разу не пройшло.
                bucket[COUNT_REWORK] = int(bucket.get(COUNT_REWORK) or 0) + 1
        elif accepted and led is not None:
            if kind == events.KIND_VERIFIED:
                led["v"] = int(led.get("v") or 0) + 1
            if not led.get("vday"):
                # ⭐ 706: судимо ПЕРШЕ ПРИЙМАННЯ — перевірку або завершення, що
                # раніше. Доти лише перевірку, і задача без перевіряючого (її
                # приймає постановник) «з першого разу» не мірялась узагалі.
                # З першого разу — жодного провалу і не більше одного результату.
                led["vday"] = day
                led["fp"] = bool(int(led.get("f") or 0) == 0
                                 and int(led.get("r") or 0) <= 1)
                led["who"] = str(det.get("assignee_id") or "")
                led["prj"] = str(det.get("project_id") or "")
        elif kind == events.KIND_FAILED:
            if led is not None:
                led["f"] = int(led.get("f") or 0) + 1
            ass = str(det.get("assignee_id") or "").strip() or NOBODY
            about(day, ass, COUNT_FAILED)
            pid = str(det.get("project_id") or "").strip()
            if pid:
                box = st["pfail"].setdefault(day, {}).setdefault(pid, {})
                box[ass] = int(box.get(ass) or 0) + 1
            st["fails"].append({"day": day, "who": ass, "task_id": tid, "project_id": pid,
                                "reason": str(det.get("reason") or "")[:300]})
            del st["fails"][:-REASONS_KEEP]
        elif kind == events.KIND_UNDERSTOOD:
            if det.get("first"):
                about(day, str(det.get("author_id") or ""), COUNT_SET_FIRST)
        elif kind == events.KIND_CLARIFY:
            about(day, str(det.get("author_id") or ""), COUNT_SET_CLARIFY)
        elif kind == events.KIND_UNCLEAR:
            about(day, str(det.get("author_id") or ""), COUNT_SET_UNCLEAR)
        elif kind == events.KIND_EARLY:
            ass = str(det.get("assignee_id") or "").strip() or NOBODY
            about(day, ass, COUNT_EARLY)
            st["early"].append({"day": day, "who": ass, "task_id": tid,
                                "project_id": str(det.get("project_id") or "").strip(),
                                "parent_id": str(det.get("parent_id") or ""),
                                "n": det.get("n"), "reason": str(det.get("text") or "")[:300]})
            del st["early"][:-REASONS_KEEP]
        elif kind == events.KIND_REFUSED:
            st["reasons"].append(
                {"day": day, "who": who, "task_id": tid,
                 "reason": str((e.get("details") or {}).get("reason") or "")[:300]})
            del st["reasons"][:-REASONS_KEEP]
        # ⭐⭐ 707 (3.7): ПРИЧИНИ З ШАБЛОНІВ — коментар за шаблоном і пояснення провалу.
        # Рахуємо ВИБІР (а не слова): шаблон, поле, варіант — на людину, що писала, і
        # на проєкт. «Інше» — теж число, а його слова — окремим переліком (лише вдома).
        tpl = det.get("tpl") if kind in (events.KIND_COMMENT, events.KIND_EXPLAINED,
                                         events.KIND_EARLY) else None
        if isinstance(tpl, dict) and tpl.get("name"):
            pid = str(det.get("project_id") or "").strip()
            for a in tpl.get("answers") or []:
                if not isinstance(a, dict):
                    continue
                key = _reason_key(tpl.get("name"), a.get("label"), a.get("value"))
                box = st["tpl"].setdefault(day, {}).setdefault(who, {})
                box[key] = int(box.get(key) or 0) + 1
                if pid:
                    pbox = st["tplp"].setdefault(day, {}).setdefault(pid, {}).setdefault(who, {})
                    pbox[key] = int(pbox.get(key) or 0) + 1
                if a.get("other"):
                    st["tpl_other"].append({
                        "day": day, "who": who, "task_id": tid, "project_id": pid,
                        "template": str(tpl.get("name") or ""), "label": str(a.get("label") or ""),
                        "text": str(a.get("text") or "")[:300]})
                    del st["tpl_other"][:-REASONS_KEEP]
    return st


def _reason_key(name, label, value) -> str:
    """Ключ причини в підсумковому файлі — список, а не склеєний рядок: назва шаблону чи
    варіант можуть містити будь-який знак-розділювач."""
    return json.dumps([str(name or ""), str(label or ""), str(value or "")], ensure_ascii=False)


# ---------------------------------------------------------------------------
# ЗАБІР ПОДІЙ. Дзеркало — СВІЙ рот: доки воно не забрало подію, прибирання її
# не чіпає (див. `taskdesk_events.prune`).
# ---------------------------------------------------------------------------
def ingest(limit: int = 5000) -> dict:
    """Забрати з журналу все нове й скласти в підсумки.

    ⭐ Рот реєструється З ПОЧАТКУ (`from_now=False`), а не з «зараз»: боту
    історія не потрібна, а дзеркалу вона і є матеріалом."""
    events.register(SINK, from_now=False)
    st = _load()
    taken = 0
    # ⭐ ДОЇДАЄМО ДО КІНЦЯ, а не одну пачку. Інакше екран після довгої перерви
    # показав би ЧАСТИНУ роботи й нічого про це не сказав.
    while True:
        was = events.cursor(SINK)
        rows = events.pending(SINK, limit=max(1, int(limit)))
        if not rows:
            break
        fold(rows, st)
        _save(st)
        # Курсор рухається ЛИШЕ після того, як підсумки лягли на диск: інакше
        # падіння між двома рядками зʼїло б події назавжди.
        events.ack(SINK, max(int(r.get("id") or 0) for r in rows))
        taken += len(rows)
        # ⛒ ВИХІД ПО ПОСТУПУ, А НЕ ПО ЗАЛИШКУ. Якщо курсор не зрушив, наступна
        # пачка буде та сама — і читач крутився б вічно, а екран керівника
        # просто не відкрився б. Зупиняємось і КАЖЕМО про це.
        if events.cursor(SINK) <= was:
            sys.stderr.write("[дзеркало] курсор не зрушив на події %d — "
                             "припиняю забір, підсумки неповні\n" % was)
            break
    return {"taken": taken, "cursor": events.cursor(SINK),
            "days": len(st["days"]), "tasks": len(st["tasks"])}


# ⭐⭐⭐ 677 (01.10.2026). ДОВІЛЬНИЙ ПЕРІОД «ВІД–ДО». Доробка Андрія 01.10.2026:
# 7/30/90 днів замало — керівник хоче «з 01.09.2026 по 30.09.2026».
# ⛒ ВІКНО ДНІВ МАЄ ОДНОГО ПИСАРЯ (`window`): і «останні N днів», і «від–до»
# стають тим самим переліком днів, а читачі (`named`, `anon`) рахують по ньому
# однаково. Друге вікно поруч розійшлось би з першим на межі періоду.
MAX_RANGE_DAYS = 366


def _human_day(v, what: str):
    """Дата людською (ДД.ММ.РРРР) або машинною (РРРР-ММ-ДД) формою → `date`."""
    import datetime as _dt
    import re as _re
    s = str(v or "").strip()
    m = _re.match(r"^(\d{2})\.(\d{2})\.(\d{4})$", s)
    if m:
        s = "%s-%s-%s" % (m.group(3), m.group(2), m.group(1))
    try:
        if len(s) != 10:
            raise ValueError(s)
        return _dt.date.fromisoformat(s)
    except Exception:
        raise MirrorError("%s «%s» не читається. Вкажіть дату у вигляді ДД.ММ.РРРР."
                          % (what, str(v or "").strip()))


def window(days: int = 0, date_from: str = "", date_to: str = "") -> list:
    """Перелік днів вікна, від останнього дня назад: «останні N днів» або
    «від–до» включно з обома кінцями. Хибний період — відмова словами."""
    import datetime as _dt
    today = _dt.date.fromisoformat(clock.now()[:10])
    f, t = str(date_from or "").strip(), str(date_to or "").strip()
    if not f and not t:
        n = max(1, int(days or DEFAULT_DAYS))
        return [(today - _dt.timedelta(days=i)).isoformat() for i in range(n)]
    if not f:
        raise MirrorError("Скажіть, з якого дня показувати: дата «по» без дати «з» "
                          "не має початку.")
    d1 = _human_day(f, "Дата «з»")
    d2 = _human_day(t, "Дата «по»") if t else today
    if d1 > d2:
        raise MirrorError("Дата «з» (%s) пізніша за дату «по» (%s) — поміняйте їх місцями."
                          % (d1.strftime("%d.%m.%Y"), d2.strftime("%d.%m.%Y")))
    if d2 > today:
        raise MirrorError("День %s ще не настав: дзеркало показує лише те, що вже "
                          "відбулося." % d2.strftime("%d.%m.%Y"))
    n = (d2 - d1).days + 1
    if n > MAX_RANGE_DAYS:
        raise MirrorError("Період задовгий: %d днів, а можна щонайбільше %d (рік)."
                          % (n, MAX_RANGE_DAYS))
    return [(d2 - _dt.timedelta(days=i)).isoformat() for i in range(n)]


def _window(days: int) -> list:
    """Перелік днів вікна, від сьогодні назад (тонкий виклик `window`)."""
    try:
        return window(days)
    except Exception:
        return []


def _counts(state: dict, window) -> dict:
    """{людина: {вид: скільки}} за вікно."""
    out = {}
    for day in window:
        for who, kinds in (state["days"].get(day) or {}).items():
            box = out.setdefault(who, {})
            for k, n in (kinds or {}).items():
                box[k] = int(box.get(k) or 0) + int(n or 0)
    return out


def _first_pass(state: dict, window, who=None, prj=None, legacy: bool = False) -> dict:
    """Скільки роботи пройшло з першого разу. Судимо ПЕРШЕ приймання задачі й
    ставимо його в той день, коли воно сталось. `who` / `prj` (706) — лише задачі
    цих виконавців / цього проєкту (на мить приймання).

    ⚠ `legacy`: задачі, прийняті до 706, не знають виконавця. У загальне число глядача
    вони входять, як і входили (інакше після оновлення число мовчки впало б); у число
    окремої людини — ні: приписати їх комусь означало б вигадати."""
    ws = set(window)
    total = ok = 0
    for led in (state.get("tasks") or {}).values():
        if str((led or {}).get("vday") or "") in ws:
            if who is not None:
                if "who" not in led:
                    if not legacy:
                        continue
                elif str(led.get("who") or "") not in who:
                    continue
            if prj is not None and str(led.get("prj") or "") != prj:
                continue
            total += 1
            ok += 1 if led.get("fp") else 0
    return {"verified": total, "first_time": ok,
            "percent": (int(round(ok * 100.0 / total)) if total else None)}


def _live(rows=None) -> dict:
    """Черга і кинуте — це СТАН, а не історія, тому питаємо живі задачі.

    ⛒ Мірку «задача стоїть» рахує сам Task Desk (`stuck`, зміна 240). Другого
    судді цього правила ми не заводимо: два писарі одного правила — нуль
    писарів."""
    rows = tasks.load_all(include_closed=False) if rows is None else rows
    by_person, by_stage = {}, {}
    for t in rows:
        who = str(t.get("assignee_id") or "").strip() or NOBODY
        p = by_person.setdefault(who, {"open": 0, "stuck": 0, "overdue": 0,
                                       "awaiting_verify": 0})
        st = str(t.get("stage") or "")
        s = by_stage.setdefault(st, {"open": 0, "stuck": 0})
        p["open"] += 1
        s["open"] += 1
        if t.get("stuck"):
            p["stuck"] += 1
            s["stuck"] += 1
        if t.get("overdue"):
            p["overdue"] += 1
        if t.get("awaiting_verify"):
            p["awaiting_verify"] += 1
    # ⛒ Порядок черги — ТОЙ САМИЙ, що в Task Desk, а не випадковий порядок
    # словника: людина читає стадії зліва направо так, як звикла їх бачити.
    ordered = {}
    for st_id in tasks.STAGES_ALL:
        if st_id in by_stage:
            ordered[st_id] = by_stage[st_id]
    for st_id, box in by_stage.items():
        ordered.setdefault(st_id, box)
    return {"by_person": by_person, "by_stage": ordered, "open": len(rows),
            "tempo_days": int((tasks.tempo(rows) or {}).get("days") or 0)}


# ---------------------------------------------------------------------------
# ХТО ЩО БАЧИТЬ. Право рахується з ДЕРЕВА компанії, а не з галочки: галочку
# забувають зняти, а дерево не застаріває [[project_unit_liquidation]].
# ---------------------------------------------------------------------------
def scope_of(viewer_id: str, is_admin: bool = False) -> list:
    """Кого цей глядач має право бачити у дзеркалі: себе і всіх, для кого він
    керівник на будь-якому рівні. Адміністратор бачить компанію."""
    viewer_id = str(viewer_id or "").strip()
    if is_admin:
        return [e["id"] for e in people.employees(True)]
    if not viewer_id:
        raise MirrorError("Дзеркало не показують без імені глядача.")
    if not people.employee(viewer_id):
        raise MirrorError("Такого працівника немає: %s" % viewer_id)
    return [viewer_id] + list(people.subordinates_of(viewer_id))


def _person_row(emp_id: str, cnt: dict, live: dict) -> dict:
    """Один рядок дзеркала — БЕЗ імені. Імʼя доклеює `named()`; так той самий
    рядок годиться і для знеособленого зрізу."""
    c = dict(cnt or {})
    l = dict(live or {})
    return {
        "open": int(l.get("open") or 0),
        "stuck": int(l.get("stuck") or 0),
        "overdue": int(l.get("overdue") or 0),
        "awaiting_verify": int(l.get("awaiting_verify") or 0),
        "created": int(c.get(events.KIND_CREATED) or 0),
        "results": int(c.get(events.KIND_RESULT) or 0),
        "rework": int(c.get(COUNT_REWORK) or 0),
        "verified": int(c.get(events.KIND_VERIFIED) or 0),
        "refused": int(c.get(events.KIND_REFUSED) or 0),
        "comments": int(c.get(events.KIND_COMMENT) or 0),
        "closed": int(c.get(COUNT_CLOSED) or 0),
        "stage_moves": int(c.get(events.KIND_STAGE) or 0),
        # ⭐ 706: провали перевірки — на виконавця; ясність постановки — на постановника.
        "failed": int(c.get(COUNT_FAILED) or 0),
        "set_clear_first": int(c.get(COUNT_SET_FIRST) or 0),
        "set_clarified": int(c.get(COUNT_SET_CLARIFY) or 0),
        "set_unclear": int(c.get(COUNT_SET_UNCLEAR) or 0),
        # ⭐ 708: етапи, почато раніше попереднього, — на виконавця.
        "early": int(c.get(COUNT_EARLY) or 0),
        "events": sum(int(v or 0) for k, v in c.items() if k not in SYNTH),
    }


def _projects(st: dict, win, seen) -> list:
    """⭐ 706 (3.4): проєкти — скільки разів робота в них не пройшла перевірку і
    скільки прийнятого пройшло з першого разу. Лише робота своїх людей: проєкт
    може бути спільний, а глядач бачить своїх, не чужих."""
    ws, seen = set(win), set(seen)
    failed = {}
    for day in ws:
        for pid, box in ((st.get("pfail") or {}).get(day) or {}).items():
            n = sum(int(v or 0) for w, v in (box or {}).items() if w in seen)
            if n:
                failed[pid] = failed.get(pid, 0) + n
    judged = {str(led.get("prj") or "") for led in (st.get("tasks") or {}).values()
              if str(led.get("vday") or "") in ws and str(led.get("who") or "") in seen}
    out = []
    for pid in sorted((set(failed) | judged) - {""}):
        out.append({"id": pid, "name": tasks.project_name(pid), "failed": failed.get(pid, 0),
                    "first_pass": _first_pass(st, win, who=seen, prj=pid)})
    out.sort(key=lambda r: (-r["failed"], r["name"]))
    return out


def _reasons(st: dict, win, seen, names: dict) -> list:
    """⭐ 707 (3.7): статистика причин — що найчастіше, у кого і в якому проєкті.
    Лише свої люди; найчастіша причина — зверху."""
    ws, seen = set(win), set(seen)
    total, ppl, prj = {}, {}, {}
    for day in ws:
        for who, box in ((st.get("tpl") or {}).get(day) or {}).items():
            if who not in seen:
                continue
            for key, n in (box or {}).items():
                total[key] = total.get(key, 0) + int(n or 0)
                ppl.setdefault(key, {})[who] = ppl.setdefault(key, {}).get(who, 0) + int(n or 0)
        for pid, by_who in ((st.get("tplp") or {}).get(day) or {}).items():
            for who, box in (by_who or {}).items():
                if who not in seen:
                    continue
                for key, n in (box or {}).items():
                    prj.setdefault(key, {})[pid] = prj.setdefault(key, {}).get(pid, 0) + int(n or 0)
    out = []
    for key, n in total.items():
        try:
            name, label, value = json.loads(key)
        except Exception:
            continue
        top_p = sorted(ppl.get(key, {}).items(), key=lambda x: (-x[1], names.get(x[0], x[0])))
        top_j = sorted(prj.get(key, {}).items(), key=lambda x: -x[1])
        out.append({"template": name, "label": label, "value": value,
                    "other": value == tpls.OTHER, "count": n,
                    "people": [{"id": w, "name": names.get(w, w), "count": c} for w, c in top_p[:5]],
                    "projects": [{"id": p, "name": tasks.project_name(p), "count": c}
                                 for p, c in top_j[:5]]})
    out.sort(key=lambda r: (-r["count"], r["template"], r["value"]))
    return out


def since_day(state: dict = None) -> str:
    """З якого дня взагалі є матеріал. Керівник має бачити цю межу очима:
    журнал починається з дня, коли його ввімкнули."""
    st = state if state is not None else _load()
    days = sorted((st.get("days") or {}).keys())
    return days[0] if days else ""


def named(viewer_id: str, is_admin: bool = False, days: int = DEFAULT_DAYS,
          take: bool = True, date_from: str = "", date_to: str = "") -> dict:
    """ІМЕННИЙ зріз — лише для екрана вдома. Назовні його не віддають ніколи.

    ⚠ Межа, яку екран мусить сказати вголос: тут видно роботу В СИСТЕМІ."""
    win = window(days, date_from, date_to)      # ⛒ 677: хибний період — відмова до роботи
    if take:
        ingest()
    st = _load()
    cnt = _counts(st, win)
    live = _live()
    mine = scope_of(viewer_id, is_admin)
    rows = []
    for eid in mine:
        emp = people.employee(eid) or {}
        row = _person_row(eid, cnt.get(eid), (live["by_person"] or {}).get(eid))
        row["id"] = eid
        row["name"] = emp.get("full_name") or eid
        row["silent"] = bool(row["events"] == 0)
        row["first_pass"] = _first_pass(st, win, who={eid})
        rows.append(row)
    rows.sort(key=lambda r: (-r["open"], -r["events"], r["name"]))
    seen = set(mine)
    reasons = [r for r in (st.get("reasons") or [])
               if r.get("day") in set(win) and r.get("who") in seen]
    # ⭐ 706: чому не пройшли перевірку — з людиною й проєктом, лише свої люди.
    names = {e["id"]: e.get("full_name") or e["id"] for e in people.employees(True)}
    fails = [dict(f, name=names.get(f.get("who"), f.get("who")),
                  project_name=(tasks.project_name(f["project_id"]) if f.get("project_id") else ""))
             for f in (st.get("fails") or [])
             if f.get("day") in set(win) and f.get("who") in seen]
    return {
        "days": len(win), "since": since_day(st),
        # ⭐ 677: межі показаного періоду — машинним виглядом; людською мовою їх
        # пише екран (єдиний перекладач дат), як і `since`.
        "from": win[-1] if win else "", "to": win[0] if win else "",
        "mode": "range" if str(date_from or "").strip() else "days",
        "people": rows,
        "by_stage": live["by_stage"],
        # ⭐ Назви стадій приходять із ЄДИНОГО словника Task Desk: другий
        # словник назв на екрані розійшовся б із першим уже наступного місяця.
        "stage_names": dict(tasks.STAGE_NAMES),
        "tempo_days": live["tempo_days"],
        "open_total": live["open"],
        # ⭐ 706: загальне число — лише по своїх людях (доти глядач бачив число всієї
        # компанії, хоч його люди — частина її).
        "first_pass": _first_pass(st, win, who=None if is_admin else seen, legacy=True),
        "refusals": list(reversed(reasons)),
        "failures": list(reversed(fails)),
        "projects": _projects(st, win, seen),
        # ⭐ 707: причини з шаблонів і «Інше» своїми словами.
        "reasons": _reasons(st, win, seen, names),
        "reasons_other": list(reversed([
            dict(o, name=names.get(o.get("who"), o.get("who")),
                 project_name=(tasks.project_name(o["project_id"]) if o.get("project_id") else ""))
            for o in (st.get("tpl_other") or [])
            if o.get("day") in set(win) and o.get("who") in seen])),
        # ⭐ 708: етапи, почато раніше попереднього, — хто, етап якої задачі, причина, проєкт.
        "early": list(reversed([
            dict(x, name=names.get(x.get("who"), x.get("who")),
                 project_name=(tasks.project_name(x["project_id"]) if x.get("project_id") else ""))
            for x in (st.get("early") or [])
            if x.get("day") in set(win) and x.get("who") in seen])),
        # ⛒ Дати в текст НЕ склеюємо: день лежить окремо (`since`) машинним
        # виглядом, а по-людськи його пише екран — там, де вже живе єдиний
        # перекладач дат. Інакше у продукті зʼявився б другий формат дати.
        "limits": [
            "Дзеркало міряє роботу в системі: хто працює повз неї — тут невидимий.",
            "Журнал починається з дня, коли його ввімкнули.",
        ],
    }


def anon(days: int = DEFAULT_DAYS, take: bool = True, date_from: str = "",
         date_to: str = "") -> dict:
    """ЗНЕОСОБЛЕНИЙ зріз — ЄДИНИЙ, який узагалі можна віддати назовні.

    ⭐ Тут немає ні ідентифікатора людини, ні назви задачі, ні вільного тексту.
    Люди — «людина 1, людина 2»: для правок продукту досить знати, що працює
    двоє, а не хто вони. Причини відмов лишаються ВДОМА: це слова людей."""
    win = window(days, date_from, date_to)      # ⛒ 677: хибний період — відмова до роботи
    if take:
        ingest()
    st = _load()
    cnt = _counts(st, win)
    live = _live()
    who = sorted(set(list(cnt.keys()) + list((live["by_person"] or {}).keys())))
    rows = []
    for n, eid in enumerate(who, 1):
        row = _person_row(eid, cnt.get(eid), (live["by_person"] or {}).get(eid))
        row["label"] = "людина %d" % n
        rows.append(row)
    by_stage = {}
    for stage, box in (live["by_stage"] or {}).items():
        by_stage[str(stage)] = {"open": int(box.get("open") or 0),
                                "stuck": int(box.get("stuck") or 0)}
    total = {}
    for box in cnt.values():
        for k, v in (box or {}).items():
            total[k] = int(total.get(k) or 0) + int(v or 0)
    return {
        "days": len(win), "people": len(rows), "rows": rows,
        "from": win[-1] if win else "", "to": win[0] if win else "",
        "by_stage": by_stage, "open_total": live["open"],
        "tempo_days": live["tempo_days"],
        "events": total,
        "refusals": int(total.get(events.KIND_REFUSED) or 0),
        "first_pass": _first_pass(st, win),
        # ⭐ 707: назовні — лише скільки причин записано за шаблонами; ні варіантів, ні слів.
        "reasons_total": sum(int(n or 0) for day in win
                             for box in ((st.get("tpl") or {}).get(day) or {}).values()
                             for n in (box or {}).values()),
    }


def snapshot() -> dict:
    """Стан читача одним поглядом — для консолі й для чеків."""
    st = _load()
    return {"file": str(TOTALS), "exists": TOTALS.exists(),
            "days": len(st.get("days") or {}), "tasks": len(st.get("tasks") or {}),
            "reasons": len(st.get("reasons") or []),
            "cursor": events.cursor(SINK), "since": since_day(st)}
