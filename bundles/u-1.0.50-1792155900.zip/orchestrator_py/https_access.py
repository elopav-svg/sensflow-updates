# -*- coding: utf-8 -*-
"""
https_access.py — зміна 537, 08.09.2026.

ОДНА ТОЧКА, ЯКА ВІДПОВІДАЄ НА ПИТАННЯ «ЧИ ЗАШИФРОВАНО».

ЧОМУ ОКРЕМИЙ МОДУЛЬ. Те саме, що й з адресою (`network_access.py`): на це
питання відповідають ТРОЄ — сервер (чим накрити сокет), екран «Доступи»
(що показати людині) і замок мережі (чи можна взагалі відкриватись). Три
власні відповіді на одне питання рано чи пізно розійдуться, і розійдуться
ТИХО. Тому відповідь одна й лежить тут.

ЩО МИ ЗАХИЩАЄМО. Рішення Андрія 08.09.2026: конфіденційність у ПЕРИМЕТРІ
ОФІСУ. Люди заходять зі своїх комп'ютерів через офісний роутер; усе, що
йде всередині офісу — паролі, угоди, документи — має бути закрите.
Назовні платформа не виходить взагалі.

ТРИ ПРАВИЛА, НА ЯКИХ ЦЕ ТРИМАЄТЬСЯ.

  1. ШИФРУВАННЯ — НЕ ОКРЕМИЙ ВИМИКАЧ. Його не можна вимкнути окремо від
     мережі. Мережа відкрита → шифрування є. Немає придатного сертифіката
     → мережа НЕ відкривається. Це ТРЕТІЙ ПОВЕРХ того самого замка, на
     якому вже стоять «вхід із паролем» і «пароль, а не легкий режим».

  2-a. ⛒ 568. КЛЮЧ ОФІСУ ЖИВЕ У СХОВИЩІ WINDOWS, А PFX — ЛИШЕ ПЕРЕНОСНА
     КОПІЯ. Донині перевипуск відкривав `office_ca.pfx` паролем із `made.json`
     — тобто таємниця жила ОКРЕМО від файла, який вона відкриває, і та сама
     Windows, що ключ зробила, свій же pfx імпортувати відмовлялась
     («The specified network password is not correct», журнал 12.09.2026).
     Тепер ключ офісу беремо зі сховища за імʼям `CN=SensFlow Office Key`,
     pfx лишається для сумісності й пишеться сучасним форматом, а якщо ключа
     немає НІДЕ — робимо новий і кажемо ціну вголос.

  2. КЛЮЧ НАРОДЖУЄ САМА WINDOWS, а не наш код. Ми не пишемо власної
     криптографії: ключ і сертифікат створює вбудований засіб системи
     (`New-SelfSignedCertificate`), а цей модуль лише перекладає готові
     числа у формат, який читає Python. Ключ народжується на машині
     клієнта і НІКУДИ З НЕЇ НЕ ЇДЕ.

  3. ПРАЦІВНИКАМ СТАВИТЬСЯ КЛЮЧ ОФІСУ, А НЕ СЕРТИФІКАТ СЕРВЕРА. Машина
     створює собі ВЛАСНИЙ ключ офісу (на 10 років) і ним підписує
     сертифікат сервера (на `SRV_DAYS` днів — з 744 не довше, ніж приймає iPhone,
     і перевипускається сам на старті). У браузери працівників один раз ставиться
     ключ офісу. Далі сервер може змінити адресу чи перевипустити свій
     сертифікат — і обходити десять комп'ютерів удруге не треба.
     Сертифікат сервера, виписаний на адресу, обходу вимагав би щоразу.

ЩО ЛЕЖИТЬ НА ДИСКУ (тека `certs`, оголошена ЖИВИМ СТАНОМ машини — вона не
їде в клієнтський пакет і не затирається оновленням):

    office_ca.crt.pem  — ключ офісу, ВІДКРИТА частина. Цей файл і тільки
                         цей роздається на комп'ютери працівників.
    office_ca.key.pem  — ключ офісу, ТАЄМНА частина. Не покидає машину.
    office_ca.pfx      — той самий ключ офісу у форматі Windows: потрібен,
                         щоб перевипустити сертифікат сервера, не турбуючи
                         працівників.
    server.crt.pem     — сертифікат сервера на поточну адресу.
    server.key.pem     — таємний ключ сервера.
    made.json          — хто і коли зробив. Це НОТАТКА ДЛЯ ЕКРАНА.

🩸 СУДДЯ — САМ ФАЙЛ, А НЕ НАША НОТАТКА. Строк дії і адресу ми читаємо з
самого сертифіката (мінімальний розбір DER нижче), а не з `made.json`.
Нотатка може розійтись із дійсністю; сертифікат — ні. Це той самий урок,
що й «чек мусить питати те місце, яке за намір відповідає».

Жодних зовнішніх залежностей.
"""

import base64
import datetime
import json
import re
import os
import socket
import ssl
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import config  # noqa: E402
import one_writer  # noqa: E402

# ── Імена файлів. Одне місце, щоб екран, чек і збирач не вигадували своїх ──
CA_CRT = "office_ca.crt.pem"
CA_KEY = "office_ca.key.pem"
CA_PFX = "office_ca.pfx"
SRV_CRT = "server.crt.pem"
SRV_KEY = "server.key.pem"
MADE = "made.json"

CA_YEARS = 10          # ключ офісу: ставиться працівникам ОДИН раз
# ⛒⛒ 744. СЕРТИФІКАТ СЕРВЕРА — НЕ ДОВШЕ, НІЖ ПРИЙМАЄ ТЕЛЕФОН. Apple (iOS 13+, macOS 10.15+) не
# приймає сертифікат сервера на строк понад 825 днів — навіть від ключа, якому телефон довіряє.
# 🩸 До 744 було 5 років: 1.0.44 пообіцяла SensFlow на iPhone, а Safari сторінки не відкривав.
# Короткий строк нічого не коштує: перевипуск — тим самим ключем офісу, сам, на старті (`renew_if_due`).
SRV_DAYS = 800         # сертифікат сервера: перевипускається без обходу машин
PHONE_MAX_DAYS = 825   # межа Apple для сертифіката сервера
WARN_DAYS = 30         # за скільки днів до кінця перевипускати
CA_SUBJECT = "CN=SensFlow Office Key"   # імʼя ключа офісу у сховищі Windows — одне місце

# Чому шифрування непридатне — мовою, яку розуміє екран і вікно запуску.
PROBLEM_MISSING = "missing"       # сертифіката ще немає
PROBLEM_BROKEN = "broken"         # файли є, але не читаються
PROBLEM_EXPIRED = "expired"       # строк вийшов
PROBLEM_IP = "ip_changed"         # адреса машини змінилась, сертифікат чужий


def certs_dir():
    """Тека ключів. 🩸 Адресу рахує ЛИШЕ `config` — правило продукту."""
    return config.CERTS_DIR


def paths() -> dict:
    d = certs_dir()
    return {
        "dir": d,
        "ca_crt": d / CA_CRT,
        "ca_key": d / CA_KEY,
        "ca_pfx": d / CA_PFX,
        "srv_crt": d / SRV_CRT,
        "srv_key": d / SRV_KEY,
        "made": d / MADE,
    }


# ═══════════════════════════════════════════════════════════════════════════
# МІНІМАЛЬНИЙ РОЗБІР СЕРТИФІКАТА
#
# Нам треба знати рівно три речі: доки він дійсний, на які адреси виписаний
# і чи він — ключ офісу. Це НЕ криптографія: ми нічого не перевіряємо й
# нічого не підписуємо, а лише читаємо поля з файла. Підпис і шифрування
# робить `ssl` (тобто OpenSSL), як і робив.
# ═══════════════════════════════════════════════════════════════════════════

_OID_SAN = b"\x55\x1d\x11"   # subjectAltName — адреси, на які виписано
_OID_BC = b"\x55\x1d\x13"    # basicConstraints — чи це ключ, яким підписують


def _tlv(buf, i):
    """Один вузол DER: (тег, початок вмісту, кінець вмісту, початок наступного)."""
    tag = buf[i]
    i += 1
    n = buf[i]
    i += 1
    if n & 0x80:
        k = n & 0x7F
        n = int.from_bytes(buf[i:i + k], "big")
        i += k
    return tag, i, i + n, i + n


def _children(buf, start, end):
    out = []
    i = start
    while i < end:
        tag, s, e, nxt = _tlv(buf, i)
        out.append((tag, s, e))
        i = nxt
    return out


def _parse_time(raw: bytes, tag: int):
    t = raw.decode("ascii", "ignore").strip()
    if t.endswith("Z"):
        t = t[:-1]
    if tag == 0x17:                      # UTCTime: YYMMDDHHMMSS
        yy = int(t[0:2])
        year = 2000 + yy if yy < 50 else 1900 + yy
        rest = t[2:]
    else:                                # GeneralizedTime: YYYYMMDDHHMMSS
        year = int(t[0:4])
        rest = t[4:]
    mo = int(rest[0:2])
    dd = int(rest[2:4])
    hh = int(rest[4:6]) if len(rest) >= 6 else 0
    mi = int(rest[6:8]) if len(rest) >= 8 else 0
    ss = int(rest[8:10]) if len(rest) >= 10 else 0
    return datetime.datetime(year, mo, dd, hh, mi, ss)


def pem_to_der(text: str) -> bytes:
    body = []
    keep = False
    for line in str(text or "").splitlines():
        if line.startswith("-----BEGIN"):
            keep = True
            continue
        if line.startswith("-----END"):
            break
        if keep:
            body.append(line.strip())
    return base64.b64decode("".join(body))


def cert_facts(der: bytes) -> dict:
    """Строк дії, адреси й «чи це ключ офісу» — прочитані з самого файла."""
    out = {"not_before": None, "not_after": None, "ips": [], "dns": [], "is_ca": False}
    _t, s, e, _n = _tlv(der, 0)                       # Certificate
    kids = _children(der, s, e)
    tbs = kids[0]                                     # tbsCertificate
    for (t, cs, ce) in _children(der, tbs[1], tbs[2]):
        if t == 0x30 and out["not_after"] is None:
            two = _children(der, cs, ce)
            if len(two) == 2 and all(x[0] in (0x17, 0x18) for x in two):
                out["not_before"] = _parse_time(der[two[0][1]:two[0][2]], two[0][0])
                out["not_after"] = _parse_time(der[two[1][1]:two[1][2]], two[1][0])
        elif t == 0xA3:                               # extensions [3]
            seq = _children(der, cs, ce)
            if not seq:
                continue
            for (_et, es, ee) in _children(der, seq[0][1], seq[0][2]):
                parts = _children(der, es, ee)
                if not parts:
                    continue
                oid = der[parts[0][1]:parts[0][2]]
                val = None
                for (pt, ps, pe) in parts[1:]:
                    if pt == 0x04:
                        val = (ps, pe)
                if val is None:
                    continue
                if oid == _OID_SAN:
                    inner = _children(der, val[0], val[1])
                    if inner:
                        for (gt, gs, ge) in _children(der, inner[0][1], inner[0][2]):
                            if gt == 0x82:
                                out["dns"].append(der[gs:ge].decode("ascii", "ignore"))
                            elif gt == 0x87 and (ge - gs) == 4:
                                out["ips"].append(".".join(str(b) for b in der[gs:ge]))
                elif oid == _OID_BC:
                    inner = _children(der, val[0], val[1])
                    if inner:
                        for (bt, bs, be) in _children(der, inner[0][1], inner[0][2]):
                            if bt == 0x01 and be > bs and der[bs] != 0:
                                out["is_ca"] = True
    return out


def facts_of(path) -> dict:
    """Факти сертифіката з файла. Порожньо — отже прочитати не вдалось."""
    try:
        text = open(str(path), "r", encoding="utf-8", errors="ignore").read()
        return cert_facts(pem_to_der(text))
    except Exception:
        return {}


# ═══════════════════════════════════════════════════════════════════════════
# СТАН — ОДНА ВІДПОВІДЬ ДЛЯ СЕРВЕРА, ЕКРАНА, ВІКНА ЗАПУСКУ І ЧЕКА
# ═══════════════════════════════════════════════════════════════════════════

def _lan_ip() -> str:
    """Адреса машини в офісній мережі. Питаємо сусіда, щоб відповідь була одна."""
    try:
        import network_access as _net
        return _net.lan_ip()
    except Exception:
        return ""


def state() -> dict:
    """Повний стан шифрування. Судить ФАЙЛИ, а не нотатку."""
    p = paths()
    ip_now = _lan_ip()
    out = {
        "have": False,
        "usable": False,
        "problem": PROBLEM_MISSING,
        "detail": "",
        "ip_now": ip_now,
        "ips": [],
        "dns": [],
        "names_missing": [],
        "not_after": "",
        "days_left": 0,
        "expiring": False,
        "ca_not_after": "",
        "ca_days_left": 0,
        "maker": "",
        "made_at": "",
        "ca_source": "",
        "ca_renewed": False,
        "span_days": 0,
        "phone_fit": False,
        "behind_proxy": False,
        "renew_due": False,
    }
    have_files = all(os.path.exists(str(p[k])) for k in ("ca_crt", "srv_crt", "srv_key"))
    if not have_files:
        return out
    out["have"] = True
    srv = facts_of(p["srv_crt"])
    ca = facts_of(p["ca_crt"])
    if not srv or not srv.get("not_after") or not ca or not ca.get("not_after"):
        out["problem"] = PROBLEM_BROKEN
        return out
    now = datetime.datetime.utcnow()
    out["ips"] = list(srv.get("ips") or [])
    out["dns"] = list(srv.get("dns") or [])       # ⛒ 722: імена — з самого файла
    out["not_after"] = srv["not_after"].strftime("%d.%m.%Y")
    out["days_left"] = (srv["not_after"] - now).days
    out["ca_not_after"] = ca["not_after"].strftime("%d.%m.%Y")
    out["ca_days_left"] = (ca["not_after"] - now).days
    # ⛒ 744: строк — із самого файла (NotBefore..NotAfter), як і рахує телефон.
    if srv.get("not_before"):
        out["span_days"] = (srv["not_after"] - srv["not_before"]).days
    out["phone_fit"] = 0 < out["span_days"] <= PHONE_MAX_DAYS
    # ⛒⛒ 769. ЕТАЛОН + ОСОБЛИВІСТЬ МАШИНИ: за довіреним проксі (695, `TRUSTED_PROXY`) телефони й
    # компʼютери бачать сертифікат ПРОКСІ, а наш — лише сам проксі. 🩸 ОТУ (NPM): перевипуск
    # заради iPhone їм нічого не давав, а ризик і клопіт лягали на їхнє ІТ.
    out["behind_proxy"] = bool(_trusted_proxies())
    try:
        made = json.load(open(str(p["made"]), "r", encoding="utf-8"))
        out["maker"] = str(made.get("maker") or "")
        out["made_at"] = str(made.get("made_at") or "")
        out["ca_source"] = str(made.get("ca_source") or "")
        out["ca_renewed"] = bool(made.get("ca_renewed"))
    except Exception:
        pass
    if srv["not_after"] <= now or ca["not_after"] <= now:
        out["problem"] = PROBLEM_EXPIRED
        # Прострочений лише сертифікат сервера — його перевипуск лікує; ключ офісу — ні.
        out["renew_due"] = ca["not_after"] > now
        return out
    # 🩸 АДРЕСА МАШИНИ ЗМІНИЛАСЬ — СЕРТИФІКАТ ЧУЖИЙ. Браузер покаже червоне
    # не тому, що ми його не знаємо, а тому, що він виписаний не на цю адресу.
    # Мовчати про це не можна: людина побачить попередження і не зрозуміє чому.
    if ip_now and ip_now not in out["ips"]:
        out["problem"] = PROBLEM_IP
        return out
    # ⭐⭐⭐ 537ж, 08.09.2026. ОСТАННЄ СЛОВО — ЗА СПРОБОЮ, А НЕ ЗА ПАСПОРТОМ.
    # 🩸 ЗНАЙДЕНО ЖИВОЮ МАШИНОЮ: Windows підписала сертифікат старим способом
    # (SHA-1). Дати правильні, адреси правильні, паспорт бездоганний — а `ssl`
    # такий сертифікат не приймає. Ми казали «увімкнено», замок пускав мережу,
    # і платформа стала б на 0.0.0.0 БЕЗ ШИФРУВАННЯ.
    # Тому придатність доводиться ЄДИНИМ способом: спробувати підняти
    # шифрування насправді. Не піднялось — непридатне, і причина названа.
    ctx, err = _build_context()
    if ctx is None:
        out["problem"] = PROBLEM_BROKEN
        out["detail"] = err
        return out
    out["problem"] = ""
    out["usable"] = True
    out["expiring"] = out["days_left"] <= WARN_DAYS
    out["renew_due"] = bool(out["expiring"] or phone_matters(out))
    # ⛒⛒ 722: імʼя машини, якого сертифікат не знає, — ПОПЕРЕДЖЕННЯ, а не «непридатний».
    # Непридатний закрив би мережу (замок питає `usable`), а за адресою цифрами все працює;
    # браузер попереджає лише тих, хто відкриває за цим іменем. Лік — «Оновити сертифікат».
    known = {x.lower() for x in out["dns"]}
    out["names_missing"] = [n for n in machine_names() if n.lower() not in known]
    return out


def usable() -> bool:
    """Коротка відповідь для замка мережі."""
    return bool(state().get("usable"))


def _build_context():
    """Спробувати підняти шифрування. Повертає (контекст, причина відмови).

    🩸 ЦЕ ЄДИНЕ МІСЦЕ, ЯКЕ ВІДПОВІДАЄ НА ПИТАННЯ «ЧИ МОЖЕМО МИ ШИФРУВАТИ».
    І `state()`, і `context()` питають саме його: два різні способи відповісти
    на одне питання розійшлись би — і розійшлись би тихо.
    """
    p = paths()
    try:
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        ctx.minimum_version = ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(certfile=str(p["srv_crt"]), keyfile=str(p["srv_key"]))
        return ctx, ""
    except Exception as ex:
        return None, str(ex)[:300]


def context():
    """Готовий контекст TLS або None. Єдине джерело для server.py."""
    if not usable():
        return None
    return _build_context()[0]


def tls_error() -> str:
    """Чому шифрування не піднімається — словами системи. Для екрана й журналу."""
    return _build_context()[1]


def ca_public_pem() -> str:
    """Той САМИЙ файл, що ставиться працівникам. Лише відкрита частина.
    🩸 Таємний ключ офісу тут не з'являється НІКОЛИ — цієї функції немає."""
    try:
        return open(str(paths()["ca_crt"]), "r", encoding="utf-8").read()
    except Exception:
        return ""


def _trusted_proxies() -> list:
    """⛒ 769: довірені проксі машини — той самий розбір, що в судді запитів (`client_addr`)."""
    import client_addr
    return client_addr.trusted_list()


def phone_matters(st) -> bool:
    """⛒ 769: чи важить, що сертифікат задовгий для телефона. Лише тоді, коли телефон бачить САМЕ
    його — платформа не за проксі. Одне місце для перевипуску, вікна запуску й екрана."""
    return not st.get("phone_fit") and not st.get("behind_proxy")


def phone_note(span_days) -> str:
    """⛒ 744: що сказати, коли сертифікат сервера задовгий для iPhone. Один текст — для вікна запуску."""
    return ("УВАГА: сертифікат виданий на %s днів, а iPhone приймає не більше %d — на iPhone "
            "платформа не відкриється. Натисніть «Оновити сертифікат» на екрані Доступи — "
            "компʼютери працівників чіпати не треба." % (span_days or "?", PHONE_MAX_DAYS))


def names_note(missing) -> str:
    """⛒ 722: що сказати, коли сертифікат не знає імені машини. Один текст — для вікна запуску."""
    return ("УВАГА: сертифікат не знає імені %s — браузер, відкритий за цим іменем, "
            "попереджатиме. Натисніть «Оновити сертифікат» на екрані Доступи — "
            "компʼютери працівників чіпати не треба." % ", ".join(missing))


def console_lines() -> list:
    """Що сказати у вікні запуску. Людина не має гадати."""
    st = state()
    lines = []
    if _AUTO.get("said"):
        import textwrap as _tw
        _first = True
        for _chunk in _tw.wrap(_AUTO["said"], 56):
            lines.append((" Сертифікат      : " if _first else "        ") + _chunk)
            _first = False
    if st.get("ca_renewed"):
        # 🩸 568. Людина має дізнатись це з вікна запуску, а не від працівника,
        # у якого браузер раптом показав попередження. Текст — не свій: той
        # самий, що й у відповіді екрана (`renewal_note`).
        import textwrap as _tw
        _first = True
        for _chunk in _tw.wrap(renewal_note(True), 56):
            lines.append((" Ключ офісу      : " if _first else "        ") + _chunk)
            _first = False
    if st["usable"]:
        lines.append(" Шифрування      : УВІМКНЕНО (сертифікат діє до %s)" % st["not_after"])
        if st.get("names_missing"):
            # ⛒ 722: той самий текст, що й на екрані «Доступи» (`names_note`).
            import textwrap as _tw
            for _chunk in _tw.wrap(names_note(st["names_missing"]), 56):
                lines.append("        " + _chunk)
        if phone_matters(st):
            import textwrap as _tw
            for _chunk in _tw.wrap(phone_note(st.get("span_days")), 56):
                lines.append("        " + _chunk)
        elif st["expiring"]:
            lines.append("        УВАГА: лишилось %d днів. Створіть новий сертифікат"
                         % st["days_left"])
            lines.append("        на екрані Доступи — комп'ютери працівників чіпати не треба.")
    elif st["problem"] == PROBLEM_MISSING:
        lines.append(" Шифрування      : сертифіката ще немає")
    elif st["problem"] == PROBLEM_EXPIRED:
        lines.append(" Шифрування      : сертифікат ПРОСТРОЧЕНИЙ")
    elif st["problem"] == PROBLEM_IP:
        lines.append(" Шифрування      : сертифікат виписаний на іншу адресу")
        lines.append("        (тепер %s, а в сертифікаті %s)"
                     % (st["ip_now"] or "?", ", ".join(st["ips"]) or "?"))
    else:
        lines.append(" Шифрування      : файли сертифіката не читаються")
    return lines


# ═══════════════════════════════════════════════════════════════════════════
# СТВОРЕННЯ КЛЮЧІВ
#
# 🩸 ГОЛОВНЕ ПРАВИЛО ЦЬОГО РОЗДІЛУ: МИ НЕ ПИШЕМО КРИПТОГРАФІЇ.
# Ключ і підпис робить сама операційна система своїм вбудованим засобом.
# Наш код виконує рівно дві дії, у яких немає жодної таємниці:
#   1) каже системі, ЯКИЙ сертифікат потрібен (на які адреси, доки, ким
#      підписаний);
#   2) перекладає готові числа з формату Windows у формат PEM, який читає
#      Python. Це перекладання — розкладка чисел по коробочках DER, а не
#      обчислення. Жодного байта ключа ми не вигадуємо.
#
# Для експертизи це принципова різниця: «використали засоби операційної
# системи» проти «написали своє шифрування».
# ═══════════════════════════════════════════════════════════════════════════

def _der_len(n: int) -> bytes:
    if n < 0x80:
        return bytes([n])
    b = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(b)]) + b


def _der_int(raw: bytes) -> bytes:
    v = raw.lstrip(b"\x00") or b"\x00"
    if v[0] & 0x80:                       # DER: старший біт означав би мінус
        v = b"\x00" + v
    return b"\x02" + _der_len(len(v)) + v


def _der_seq(parts: bytes) -> bytes:
    return b"\x30" + _der_len(len(parts)) + parts


def _pem_block(title: str, der: bytes) -> str:
    b64 = base64.b64encode(der).decode("ascii")
    rows = [b64[i:i + 64] for i in range(0, len(b64), 64)]
    return ("-----BEGIN %s-----\n" % title) + "\n".join(rows) + ("\n-----END %s-----\n" % title)


def rsa_key_pem(d: dict) -> str:
    """PEM таємного ключа з готових чисел, які видала система.

    Порядок чисел визначений стандартом (PKCS#1) і не є нашим винаходом:
    версія, модуль, відкритий показник, таємний показник, два прості
    множники і три допоміжні числа для швидкості.
    """
    g = lambda k: base64.b64decode(d[k])          # noqa: E731
    body = _der_seq(
        _der_int(b"\x00")
        + _der_int(g("n")) + _der_int(g("e")) + _der_int(g("d"))
        + _der_int(g("p")) + _der_int(g("q"))
        + _der_int(g("dp")) + _der_int(g("dq")) + _der_int(g("iq"))
    )
    return _pem_block("RSA PRIVATE KEY", body)


def cert_pem(b64: str) -> str:
    return _pem_block("CERTIFICATE", base64.b64decode(b64))


def _pem_der(text: str, title: str) -> bytes:
    m = re.search(r"-----BEGIN %s-----(.*?)-----END %s-----" % (title, title), text or "", re.S)
    if not m:
        raise ValueError("немає блока %s" % title)
    return base64.b64decode("".join(m.group(1).split()))


def cert_der_b64(text: str) -> str:
    """⛒ 770: сертифікат офісу з PEM — даними для підпису (саме той, що стоїть у працівників)."""
    return base64.b64encode(_pem_der(text, "CERTIFICATE")).decode("ascii")


def _der_items(der: bytes, pos: int = 0, end: int = None) -> list:
    """Найпростіший читач DER: [(тег, вміст)] на одному рівні."""
    end = len(der) if end is None else end
    out = []
    while pos < end:
        tag = der[pos]
        ln = der[pos + 1]
        pos += 2
        if ln & 0x80:
            k = ln & 0x7F
            ln = int.from_bytes(der[pos:pos + k], "big")
            pos += k
        out.append((tag, der[pos:pos + ln]))
        pos += ln
    return out


def rsa_parts_of_pem(text: str) -> dict:
    """⛒ 770: числа таємного ключа (PKCS#1 «RSA PRIVATE KEY» або PKCS#8 «PRIVATE KEY») — у тому вигляді,
    якого чекає Windows (RSAParameters): модуль і таємний показник — на повну довжину модуля, решта —
    на половину. Дзеркало `rsa_key_pem`."""
    if "BEGIN RSA PRIVATE KEY" in (text or ""):
        der = _pem_der(text, "RSA PRIVATE KEY")
    else:
        outer = _der_items(_der_items(_pem_der(text, "PRIVATE KEY"))[0][1])
        der = outer[2][1]                     # OCTET STRING із PKCS#1
    ints = [int.from_bytes(v, "big") for t, v in _der_items(_der_items(der)[0][1]) if t == 0x02]
    _ver, n, e, d, p_, q, dp, dq, iq = ints[:9]
    nl = (n.bit_length() + 7) // 8
    hl = (nl + 1) // 2
    b = lambda x, ln: base64.b64encode(x.to_bytes(ln, "big")).decode("ascii")   # noqa: E731
    el = max(1, (e.bit_length() + 7) // 8)
    return {"n": b(n, nl), "e": b(e, el), "d": b(d, nl), "p": b(p_, hl), "q": b(q, hl),
            "dp": b(dp, hl), "dq": b(dq, hl), "iq": b(iq, hl)}


def _write(path, text: str):
    """Запис із заміною: спершу поруч, потім на місце. Половини файла не буває."""
    path = str(path)
    tmp = path + ".new"
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)
    one_writer.replace_with_patience(tmp, path)


def _dns_fqdn() -> str:
    """Повне доменне імʼя машини, як його каже сама система. Порожньо — не сказала.
    Windows: `GetComputerNameExW(ComputerNameDnsFullyQualified)` — без звернення до DNS-сервера
    (зворотний пошук `socket.getfqdn` повертає що завгодно). Деінде — `getfqdn`, якщо в ньому є домен."""
    try:
        if os.name == "nt":
            import ctypes
            n = ctypes.c_ulong(0)
            ctypes.windll.kernel32.GetComputerNameExW(3, None, ctypes.byref(n))
            buf = ctypes.create_unicode_buffer(max(int(n.value), 1) + 1)
            if ctypes.windll.kernel32.GetComputerNameExW(3, buf, ctypes.byref(n)):
                return buf.value or ""
            return ""
        f = socket.getfqdn()
        return f if "." in f else ""
    except Exception:
        return ""


def _name_ok(n: str) -> bool:
    """Імʼя машини: латиниця, цифри, «-», «.», «_» (Windows дозволяє підкреслення в імені
    компʼютера). 🩸 Воно стає ТЕКСТОМ команди PowerShell (`_PS_SCRIPT`) — чужий знак (лапка,
    крапка з комою, пробіл) не йде в сертифікат зовсім."""
    return bool(n) and len(n) <= 253 and all(
        c.isascii() and (c.isalnum() or c in "-._") for c in n)


def machine_names() -> list:
    """⛒⛒ 722. ОДИН ПИСАР ІМЕН МАШИНИ: localhost, коротке імʼя і ПОВНЕ доменне.
    🩸 Розгортання ОТУ 05.10.2026 (Р-0004): машина в домені, працівники відкривають
    `сервер.домен.local`, а повного імені в сертифікаті не було — браузер попереджав, хоч ключ
    офісу стояв. Без повторів (у робочій групі повне = коротке); чуже імʼя не йде."""
    out = []
    try:
        cands = ["localhost", socket.gethostname(), _dns_fqdn()]
    except Exception:
        cands = ["localhost", _dns_fqdn()]
    for n in cands:
        n = (n or "").strip()
        if _name_ok(n) and n.lower() not in {x.lower() for x in out}:
            out.append(n)
    return out


def _san_parts() -> tuple:
    """Адреси, на які виписуємо сертифікат: своя адреса в мережі, ця машина
    сама для себе, і імена комп'ютера (`machine_names`, з 722 — і повне доменне).
    🩸 Браузер, якому дали адресу цифрами, вимагає, щоб саме ЦИФРИ стояли в
    сертифікаті — імені йому мало."""
    ips = ["127.0.0.1"]
    ip = _lan_ip()
    if ip and ip not in ips:
        ips.append(ip)
    return ips, machine_names()


# ⛒⛒⛒ 770 (11.10.2026). КЛЮЧ ОФІСУ — ЦЕ ФАЙЛ, ЯКИЙ СТОЇТЬ У ПРАЦІВНИКІВ, А НЕ НАЗВА В СХОВИЩІ WINDOWS.
# 🩸 Доти ключ офісу шукали в сховищі Windows за НАЗВОЮ, а підписувала команда, якій ключ мусить лежати в
# сховищі ТОГО, хто її запускає. Служба працює від імені SYSTEM — у її сховищі ключа немає, і перевипуск на
# старті падав («Windows не створила сертифікат»: Каспер після 1.0.45 так і лишився без iPhone). У сховищі
# людини лежали три чужі ключі з тією самою назвою — перевипуск підписав сертифікат одним із них, і жоден
# пристрій йому не довіряв (машина Андрія, 11.10.2026).
# Лік: ключ офісу — пара файлів `office_ca.crt.pem` (його ставлять працівникам) + `office_ca.key.pem`;
# підпис — у пам'яті (.NET `CertificateRequest`, є у Windows PowerShell 5.1 / .NET 4.7.2+); сховище не
# використовується ніде; ключ, що не збігається із сертифікатом офісу, — відмова (`KEY_MISMATCH`).
_PS_SCRIPT = r"""
$ErrorActionPreference = 'Stop'
$inp    = Get-Content -Raw -Encoding UTF8 -LiteralPath '{INP}' | ConvertFrom-Json
$out    = '{OUT}'
$caPfx  = '{CAPFX}'
$pwdText= '{PFXPWD}'
$mayNew = '{MAYNEWCA}'
$subject= '{SUBJECT}'
$NS     = 'System.Security.Cryptography.X509Certificates'
$sha    = [System.Security.Cryptography.HashAlgorithmName]::SHA256
$pkcs1  = [System.Security.Cryptography.RSASignaturePadding]::Pkcs1

function B64($s) {{ return [Convert]::FromBase64String([string]$s) }}
function KeyOf($k) {{
  $p = New-Object System.Security.Cryptography.RSAParameters
  $p.Modulus = B64 $k.n; $p.Exponent = B64 $k.e; $p.D = B64 $k.d
  $p.P = B64 $k.p; $p.Q = B64 $k.q; $p.DP = B64 $k.dp; $p.DQ = B64 $k.dq; $p.InverseQ = B64 $k.iq
  $r = New-Object System.Security.Cryptography.RSACng
  $r.ImportParameters($p)
  return $r
}}
function Dump($raw, $rsa) {{
  $p = $rsa.ExportParameters($true)
  return @{{
    cert = [Convert]::ToBase64String($raw)
    n  = [Convert]::ToBase64String($p.Modulus)
    e  = [Convert]::ToBase64String($p.Exponent)
    d  = [Convert]::ToBase64String($p.D)
    p  = [Convert]::ToBase64String($p.P)
    q  = [Convert]::ToBase64String($p.Q)
    dp = [Convert]::ToBase64String($p.DP)
    dq = [Convert]::ToBase64String($p.DQ)
    iq = [Convert]::ToBase64String($p.InverseQ)
  }}
}}
function Ski($cert) {{
  foreach ($x in $cert.Extensions) {{
    if ($x.Oid.Value -eq '2.5.29.14') {{
      return (New-Object ($NS + '.X509SubjectKeyIdentifierExtension') @($x, $x.Critical)).SubjectKeyIdentifier
    }}
  }}
  return (New-Object ($NS + '.X509SubjectKeyIdentifierExtension') @($cert.PublicKey, $false)).SubjectKeyIdentifier
}}

$ca = $null
$caRsa = $null
$source = ''
$officeCrt = $null
if ($inp.ca_cert) {{ $officeCrt = New-Object ($NS + '.X509Certificate2') @(,[byte[]](B64 $inp.ca_cert)) }}

# 1. КЛЮЧ ОФІСУ — ПАРА ФАЙЛІВ. Ключ мусить відповідати сертифікату, який стоїть у працівників.
if ($officeCrt -ne $null -and $inp.ca_key) {{
  $caRsa = KeyOf $inp.ca_key
  $pub = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPublicKey($officeCrt)
  if ([Convert]::ToBase64String($pub.ExportParameters($false).Modulus) -ne [string]$inp.ca_key.n) {{
    throw 'KEY_MISMATCH'
  }}
  $ca = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::CopyWithPrivateKey($officeCrt, $caRsa)
  $source = 'pem'
}}

# 2. СУМІСНІСТЬ: ключ лежить лише переносною копією (pfx) — у пам'ять, не в сховище; той самий сертифікат.
if ($ca -eq $null -and (Test-Path -LiteralPath $caPfx)) {{
  $flags = [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]'Exportable,EphemeralKeySet'
  $fromPfx = $null
  try {{ $fromPfx = New-Object ($NS + '.X509Certificate2') @($caPfx, $pwdText, $flags) }} catch {{ $fromPfx = $null }}
  if ($fromPfx -ne $null) {{
    if ($officeCrt -ne $null -and $fromPfx.Thumbprint -ne $officeCrt.Thumbprint) {{ throw 'KEY_MISMATCH' }}
    $caRsa = [System.Security.Cryptography.X509Certificates.RSACertificateExtensions]::GetRSAPrivateKey($fromPfx)
    $ca = $fromPfx
    $source = 'pfx'
  }}
}}

# 3. НЕМАЄ НІЧИМ — новий ключ офісу лише з правом на нього.
#    ⛒ 744: перевипуск на старті нового ключа НЕ робить — це обхід усіх машин, і
#    вирішує його людина кнопкою, а не служба мовчки.
if ($ca -eq $null -and $mayNew -ne '1') {{
  throw 'NO_OFFICE_KEY'
}}
if ($ca -eq $null) {{
  $caRsa = New-Object System.Security.Cryptography.RSACng @(2048)
  $req = New-Object ($NS + '.CertificateRequest') @($subject, $caRsa, $sha, $pkcs1)
  $req.CertificateExtensions.Add((New-Object ($NS + '.X509BasicConstraintsExtension') @($true, $true, 0, $true)))
  $req.CertificateExtensions.Add((New-Object ($NS + '.X509KeyUsageExtension') @(
      [System.Security.Cryptography.X509Certificates.X509KeyUsageFlags]'KeyCertSign,CrlSign,DigitalSignature', $true)))
  $req.CertificateExtensions.Add((New-Object ($NS + '.X509SubjectKeyIdentifierExtension') @($req.PublicKey, $false)))
  $ca = $req.CreateSelfSigned([DateTimeOffset]::Now.AddMinutes(-10), [DateTimeOffset]::Now.AddYears({CAYEARS}))
  $source = 'new'
  # Переносна копія — як і раніше, поруч (тепер лише запасна: правда — пара PEM-файлів).
  try {{ [IO.File]::WriteAllBytes($caPfx, $ca.Export('Pfx', $pwdText)) }} catch {{ }}
}}

# 4. СЕРТИФІКАТ СЕРВЕРА — ПІДПИС У ПАМ'ЯТІ, СХОВИЩЕ НЕ ПОТРІБНЕ.
$srvRsa = New-Object System.Security.Cryptography.RSACng @(2048)
$req = New-Object ($NS + '.CertificateRequest') @('CN=SensFlow', $srvRsa, $sha, $pkcs1)
$req.CertificateExtensions.Add((New-Object ($NS + '.X509BasicConstraintsExtension') @($false, $false, 0, $true)))
$req.CertificateExtensions.Add((New-Object ($NS + '.X509KeyUsageExtension') @(
    [System.Security.Cryptography.X509Certificates.X509KeyUsageFlags]'DigitalSignature,KeyEncipherment', $true)))
$eku = New-Object System.Security.Cryptography.OidCollection
$null = $eku.Add((New-Object System.Security.Cryptography.Oid '1.3.6.1.5.5.7.3.1'))
$req.CertificateExtensions.Add((New-Object ($NS + '.X509EnhancedKeyUsageExtension') @($eku, $false)))
$sanB = New-Object ($NS + '.SubjectAlternativeNameBuilder')
foreach ($ip in @($inp.ips)) {{ if ($ip) {{ $sanB.AddIpAddress([System.Net.IPAddress]::Parse([string]$ip)) }} }}
foreach ($dn in @($inp.names)) {{ if ($dn) {{ $sanB.AddDnsName([string]$dn) }} }}
$req.CertificateExtensions.Add($sanB.Build())
$req.CertificateExtensions.Add((New-Object ($NS + '.X509SubjectKeyIdentifierExtension') @($req.PublicKey, $false)))
# Ідентифікатор ключа офісу (AKI) — щоб пристрій знайшов саме цей ключ, навіть коли поруч є інші з тією самою назвою.
$kid = [byte[]]@(for ($i = 0; $i -lt (Ski $ca).Length; $i += 2) {{ [Convert]::ToByte((Ski $ca).Substring($i, 2), 16) }})
$aki = [byte[]](@(0x30, ($kid.Length + 2), 0x80, $kid.Length) + $kid)
$req.CertificateExtensions.Add((New-Object ($NS + '.X509Extension') @('2.5.29.35', $aki, $false)))
$nb = [DateTimeOffset]::Now.AddMinutes(-10)
$na = [DateTimeOffset]::Now.AddDays({SRVDAYS})
if ($na -gt [DateTimeOffset]$ca.NotAfter) {{ $na = [DateTimeOffset]$ca.NotAfter }}
$serial = New-Object byte[] 16
(New-Object System.Security.Cryptography.RNGCryptoServiceProvider).GetBytes($serial)
$serial[0] = $serial[0] -band 0x7F
$srv = $req.Create($ca, $nb, $na, $serial)

$res = @{{ server = (Dump $srv.RawData $srvRsa); source = $source; reused = ($source -ne 'new') }}
# Ключ, відкритий із pfx, Windows вивантажувати відкритим текстом не дає — тоді лишаємо лише сертифікат офісу,
# а джерелом і далі буде запасна копія (підпис від цього не залежить).
if ($source -ne 'pem') {{
  try {{ $res['ca'] = (Dump $ca.RawData $caRsa) }} catch {{ $res['ca_crt_only'] = [Convert]::ToBase64String($ca.RawData) }}
}}
[IO.File]::WriteAllText($out, ($res | ConvertTo-Json -Depth 6), [Text.Encoding]::UTF8)
"""


def _make_windows(ips, names, may_new_ca=True) -> dict:
    """Сертифікат підписує Windows (.NET) у пам'яті ключем офісу з файла; ми лише даємо дані й
    перекладаємо (770)."""
    import secrets
    p = paths()
    made_pwd = ""
    try:
        made_pwd = json.load(open(str(p["made"]), "r", encoding="utf-8")).get("pfx_pwd") or ""
    except Exception:
        made_pwd = ""
    if not made_pwd:
        made_pwd = secrets.token_hex(16)
    had_key = os.path.exists(str(p["ca_crt"])) or os.path.exists(str(p["ca_pfx"]))
    # ⛒ 770: ключ офісу — пара файлів; скрипт отримує їх даними, сховища Windows не питає.
    inp = {"ips": list(ips), "names": list(names)}
    try:
        inp["ca_cert"] = cert_der_b64(open(str(p["ca_crt"]), "r", encoding="utf-8").read())
    except Exception:
        pass
    try:
        inp["ca_key"] = rsa_parts_of_pem(open(str(p["ca_key"]), "r", encoding="utf-8").read())
    except Exception:
        pass
    work = tempfile.mkdtemp(prefix="sensflow_cert_")
    ps_file = os.path.join(work, "make_cert.ps1")
    inp_file = os.path.join(work, "in.json")
    out_file = os.path.join(work, "out.json")
    script = _PS_SCRIPT.format(
        INP=inp_file.replace("'", "''"),
        OUT=out_file.replace("'", "''"),
        CAPFX=str(p["ca_pfx"]).replace("'", "''"),
        PFXPWD=made_pwd,
        MAYNEWCA="1" if may_new_ca else "0",
        SUBJECT=CA_SUBJECT.replace("'", "''"),
        CAYEARS=CA_YEARS,
        SRVDAYS=int(SRV_DAYS),
    )
    try:
        with open(inp_file, "w", encoding="utf-8") as f:
            json.dump(inp, f)
        # 🩸 .ps1 читається й пишеться в utf-8-sig — правило продукту.
        with open(ps_file, "w", encoding="utf-8-sig", newline="\r\n") as f:
            f.write(script)
        r = subprocess.run(
            ["powershell", "-NoProfile", "-NonInteractive",
             "-ExecutionPolicy", "Bypass", "-File", ps_file],
            capture_output=True, text=True, timeout=300)
        if r.returncode != 0 or not os.path.exists(out_file):
            msg = (r.stderr or r.stdout or "").strip()
            if "NO_OFFICE_KEY" in msg:
                msg = NO_KEY_SAID
            elif "KEY_MISMATCH" in msg:
                msg = KEY_MISMATCH_SAID
            return {"ok": False, "error": msg[:900] or "Windows не створила сертифікат",
                    "maker": "windows"}
        data = json.load(open(out_file, "r", encoding="utf-8-sig"))
        data["had_key"] = had_key
        return _lay_down(data, "windows", made_pwd)
    except Exception as ex:
        return {"ok": False, "error": str(ex)[:900], "maker": "windows"}
    finally:
        for f in (ps_file, inp_file, out_file):
            try:
                os.remove(f)
            except Exception:
                pass
        try:
            os.rmdir(work)
        except Exception:
            pass


def _make_openssl(ips, names, may_new_ca=True) -> dict:
    """СТЕНД. Той самий склад файлів, зроблений openssl — щоб механізм
    шифрування, замок і екран можна було довести тут, у робочій оболонці.
    🩸 У клієнта на Windows працює НЕ цей шлях, а той, що вище."""
    p = paths()
    work = tempfile.mkdtemp(prefix="sensflow_cert_")
    ext = os.path.join(work, "ext.cnf")
    san = ",".join(["IP:%s" % x for x in ips] + ["DNS:%s" % x for x in names])
    try:
        open(ext, "w", encoding="utf-8").write(
            "subjectAltName=%s\nextendedKeyUsage=serverAuth\nbasicConstraints=CA:FALSE\n" % san)
        ca_crt = str(p["ca_crt"])
        ca_key = str(p["ca_key"])
        reused = os.path.exists(ca_crt) and os.path.exists(ca_key)
        run = lambda a: subprocess.run(a, capture_output=True, text=True)  # noqa: E731
        if not reused and not may_new_ca:
            return {"ok": False, "error": NO_KEY_SAID, "maker": "openssl"}
        if not reused:
            r = run(["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes",
                     "-keyout", ca_key, "-out", ca_crt,
                     "-days", str(CA_YEARS * 365), "-subj", "/" + CA_SUBJECT,
                     "-addext", "basicConstraints=critical,CA:TRUE,pathlen:0",
                     "-addext", "keyUsage=critical,keyCertSign,cRLSign"])
            if r.returncode != 0:
                return {"ok": False, "error": (r.stderr or "")[:900], "maker": "openssl"}
        csr = os.path.join(work, "s.csr")
        r = run(["openssl", "req", "-newkey", "rsa:2048", "-nodes",
                 "-keyout", str(p["srv_key"]), "-out", csr, "-subj", "/CN=SensFlow"])
        if r.returncode != 0:
            return {"ok": False, "error": (r.stderr or "")[:900], "maker": "openssl"}
        r = run(["openssl", "x509", "-req", "-in", csr, "-CA", ca_crt, "-CAkey", ca_key,
                 "-CAcreateserial", "-out", str(p["srv_crt"]),
                 "-days", str(int(SRV_DAYS)), "-extfile", ext])
        if r.returncode != 0:
            return {"ok": False, "error": (r.stderr or "")[:900], "maker": "openssl"}
        # ⛒⛒⛒ 568. НОТАТКУ ПИШЕ ОДИН ПИСАР — `_lay_down`, і на стенді теж.
        # Доти стенд писав `made.json` сам: два писарі однієї нотатки означали,
        # що правда про джерело ключа жила лише на одному з двох шляхів, і чек
        # на стенді зеленів там, де на Windows уже брехало.
        return _lay_down({"source": "pem" if reused else "new",
                          "had_key": reused}, "openssl (стенд)", "")
    except Exception as ex:
        return {"ok": False, "error": str(ex)[:900], "maker": "openssl"}
    finally:
        for f in (ext, os.path.join(work, "s.csr")):
            try:
                os.remove(f)
            except Exception:
                pass
        try:
            os.rmdir(work)
        except Exception:
            pass


def renewal_note(renewed: bool) -> str:
    """⛒ 568. ЦІНУ НОВОГО КЛЮЧА ОФІСУ КАЖЕ ОДНЕ РЕЧЕННЯ — і екранові, і вікну
    запуску. Порожньо означає «ключ той самий, обходити машини не треба»."""
    if not renewed:
        return ""
    return ("Ключ офісу створено ЗАНОВО: старий не відкривався. Якщо ви вже "
            "ставили ключ компʼютерам працівників — поставте новий файл ще раз.")


def _lay_down(data: dict, maker: str, pfx_pwd: str) -> dict:
    """Розкласти по файлах те, що видала система.

    ⛒ 568. Джерело ключа офісу називається СЛОВОМ (`store`/`pfx`/`new`), а не
    вгадується по тому, чи є файл: саме це слово потім каже людині, чи ключ
    створено заново — і чи треба обійти компʼютери працівників."""
    p = paths()
    source = str(data.get("source") or ("pem" if data.get("reused") else "new"))
    reused = source != "new"
    renewed = bool(source == "new" and data.get("had_key"))
    if data.get("ca"):
        ca = data["ca"]
        _write(p["ca_crt"], cert_pem(ca["cert"]))
        _write(p["ca_key"], rsa_key_pem(ca))
    elif data.get("ca_crt_only") and not os.path.exists(str(p["ca_crt"])):
        _write(p["ca_crt"], cert_pem(data["ca_crt_only"]))          # ⛒ 770: ключ лишився в pfx
    srv = data.get("server") or {}
    if srv:
        _write(p["srv_crt"], cert_pem(srv["cert"]))
        _write(p["srv_key"], rsa_key_pem(srv))
    _write(p["made"], json.dumps({
        "maker": maker,
        "made_at": datetime.datetime.now().strftime("%d.%m.%Y %H:%M"),
        "ca_reused": reused,
        "ca_source": source,
        "ca_renewed": renewed,
        # 🩸 ЧЕСНО: цей пароль нічого не додає до безпеки — він лежить поруч
        # із самим файлом. Windows просто не вміє зберігати ключ без пароля.
        # Захищає ці файли тека, а не пароль.
        "pfx_pwd": pfx_pwd,
    }, ensure_ascii=False, indent=2))
    out = {"ok": True, "error": "", "maker": maker, "ca_reused": reused,
           "ca_source": source, "ca_renewed": renewed, "said": ""}
    if renewed:
        out["said"] = renewal_note(renewed)
    return out


def make(may_new_ca: bool = True, ips=None, names=None) -> dict:
    """Створити (або перевипустити) сертифікат сервера.

    Ключ офісу створюється ОДИН раз і далі перевикористовується: працівники
    вже поставили його собі, і другого обходу машин бути не повинно.
    ⛒ 744: `may_new_ca=False` — перевипуск без права робити новий ключ офісу
    (так кличе старт сервера); `ips`/`names` — склад, якщо його вирішив кличучий.
    """
    try:
        os.makedirs(str(certs_dir()), exist_ok=True)
    except Exception as ex:
        return {"ok": False, "error": "не вдалось створити теку ключів: %s" % ex, "maker": ""}
    if ips is None or names is None:
        _ips, _names = _san_parts()
        ips = _ips if ips is None else ips
        names = _names if names is None else names
    out = (_make_windows(ips, names, may_new_ca) if os.name == "nt"
           else _make_openssl(ips, names, may_new_ca))
    # ⭐⭐⭐ 537ж: СТВОРИЛИ — ДОВЕДИ. Файли можуть лягти на диск і бути
    # непридатними (саме так і сталось 08.09.2026 із підписом SHA-1). Кажемо
    # «зроблено» лише тоді, коли шифрування СПРАВДІ піднімається.
    if out.get("ok"):
        ctx, err = _build_context()
        if ctx is None:
            out["ok"] = False
            out["error"] = ("сертифікат створено, але шифрування ним не "
                            "піднімається: %s" % err)
    return out


# ═══════════════════════════════════════════════════════════════════════════
# ⭐⭐ 744. ПЕРЕВИПУСК НА СТАРТІ — САМ, ТИМ САМИМ КЛЮЧЕМ ОФІСУ
#
# Сертифікат сервера — похідний: його перевипуск нікого не турбує, бо компʼютери й телефони
# довіряють КЛЮЧУ ОФІСУ, а не сертифікатові. Тому платформа не чекає, доки хтось натисне кнопку:
# задовгий для телефона, закінчується чи закінчився — перевипускає на старті сервера.
# ⛒ Три межі:
#   1. Ключ офісу — лише той самий. Немає його ніде — нового НЕ робимо (це обхід усіх машин,
#      рішення людини), старого сертифіката не чіпаємо, причину кажемо у вікні запуску.
#   2. Склад адрес і імен — ОБʼЄДНАННЯ старого сертифіката й нинішнього. Служба, що стартувала
#      раніше мережі, не знає адреси офісу; без обʼєднання перевипуск викинув би її, і всі
#      компʼютери офісу побачили б попередження.
#   3. Сказане — одне речення (`_AUTO["said"]`), його показує вікно запуску.
# ═══════════════════════════════════════════════════════════════════════════

KEY_MISMATCH_SAID = ("ключ офісу (office_ca.key.pem) не збігається з сертифікатом офісу, який стоїть у "
                     "працівників, — підпис чужим ключем не робимо; поверніть ключ із бекапу")
NO_KEY_SAID = ("ключ офісу не відкривається — новий на старті не робиться (його довелось би "
               "ставити на всі компʼютери й телефони наново); натисніть «Оновити сертифікат» "
               "на екрані Доступи")

_AUTO = {"said": ""}


def _union(old, new) -> list:
    out = []
    for x in list(old or []) + list(new or []):
        x = str(x or "").strip()
        if x and x.lower() not in {y.lower() for y in out}:
            out.append(x)
    return out


def renew_if_due() -> dict:
    """Перевипустити сертифікат сервера, якщо він задовгий для телефона (і телефон бачить саме
    його — не за проксі, 769), закінчується чи закінчився. Повертає {"renewed": bool, "why": str}.
    Кличе старт сервера."""
    import ipaddress
    st = state()
    if not st.get("renew_due"):
        return {"renewed": False, "why": ""}
    ips_now, names_now = _san_parts()
    ips = []
    for x in _union(st.get("ips"), ips_now):
        try:
            ips.append(str(ipaddress.IPv4Address(x)))
        except ValueError:
            continue
    names = [n for n in _union(st.get("dns"), names_now) if _name_ok(n)]
    made = make(may_new_ca=False, ips=ips, names=names)
    if made.get("ok"):
        _AUTO["said"] = ("оновлено на старті (тим самим ключем офісу — компʼютери й телефони "
                         "чіпати не треба).")
        return {"renewed": True, "why": ""}
    why = str(made.get("error") or "невідома причина")
    _AUTO["said"] = "оновити на старті не вдалось: %s." % why
    return {"renewed": False, "why": why}
