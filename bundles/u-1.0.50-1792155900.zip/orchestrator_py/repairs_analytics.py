# -*- coding: utf-8 -*-
"""repairs_analytics.py — АНАЛІТИКА РЕМОНТІВ РАХУЄТЬСЯ КОДОМ (зміна 792, 14.10.2026).

Пілот Малбі. На вході — таблиця подій (`repairs_events.normalize`) і, якщо є, випуск
продукції (`repairs_events.production`). На виході — ЧИСЛА пʼяти відповідей, які просили
на зустрічі 14.10.2026:
  1. поломки, що повторюються (по обладнанню, по парі «обладнання + вид відмови», по лінії);
  2. план/факт робіт за графіком і частка аварійних робіт;
  3. чернетка ППР — для обладнання, що ламається регулярно;
  4. звʼязок технічних простоїв із випуском (втрата випуску в дні простою);
  5. дірки у відповідальності; навантаження людей.

⛒ ЧОМУ КОД, А НЕ МОДЕЛЬ. Кожне число тут стає рішенням інженера: інтервал ТО, кому
доручити, скільки втрачено продукції. Модель на тисячах рядків помиляється в додаванні й
вигадує інтервали; тут кожне число відтворюване й перевіряється пробою на ручному наборі.
Модель (якщо буде) лише ПОЯСНЮЄ готові числа — і не сміє їх міняти.

⛒ ПРАВИЛА, ЯКІ ТРЕБА ЗНАТИ ЧИТАЧУ (вони ж — у звіті):
  * відмова = аварійна (позапланова) задача; простій лічиться окремо годинами — одна
    поломка часто має і задачу, і простій, і рахувати їх двічі як відмови не можна;
  * «хронічна» — від `CHRONIC_FROM` відмов за період;
  * чернетка ППР: інтервал ТО = `PPR_SHARE` × медіанний інтервал між відмовами, не менше
    `PPR_MIN_DAYS`; це відправна точка для інженера, а не наказ;
  * база випуску лінії — медіана днів БЕЗ ЖОДНОГО простою (плановий теж знижує випуск,
    і такий день — не норма); втрата — нестача до бази в дні з позаплановим простоєм
    (плановий простій втратою не є).

Лише stdlib + `repairs_events` (константи видів). Без моделі, без мережі.
"""
import datetime as _dt
import statistics as _st

import repairs_events as RE

CHRONIC_FROM = 3
PPR_SHARE = 0.7
PPR_MIN_DAYS = 7

ADV_SHORTEN = "скоротити інтервал ТО"
ADV_CREATE = "завести регламентне ТО"
ADV_KEEP = "інтервал ТО відповідає — перевірити якість ТО"


def _r1(x):
    return None if x is None else round(float(x), 1)


def _median(xs):
    return _st.median(xs) if xs else None


def _norm_line(s) -> str:
    return " ".join(str(s or "").split()).casefold()


def _intervals(dates):
    ds = sorted(d for d in dates if d)
    return [(b - a).days for a, b in zip(ds, ds[1:])]


def _date_of(e):
    return RE.event_date(e)


# ── 1. ПОЛОМКИ, ЩО ПОВТОРЮЮТЬСЯ ──────────────────────────────────────────────
def _failures(events, eq):
    fails = [e for e in events if e["kind"] == "task" and e["type"] == RE.T_FAILURE]
    downs = [e for e in events if e["kind"] == "downtime"]
    by_dev = {}
    for e in fails:
        r = by_dev.setdefault(e["device_id"], {"device_id": e["device_id"], "device": e["device"],
                                               "line": e["line"], "dates": [], "faults": {}})
        r["dates"].append(_date_of(e))
        f = e["fault"] or "не вказано"
        r["faults"][f] = r["faults"].get(f, 0) + 1
    dh, ph, dn = {}, {}, {}
    for e in downs:
        if e["duration_h"] is None:
            continue
        if e["planned"]:
            ph[e["device_id"]] = ph.get(e["device_id"], 0.0) + e["duration_h"]
        else:
            dh[e["device_id"]] = dh.get(e["device_id"], 0.0) + e["duration_h"]
            dn[e["device_id"]] = dn.get(e["device_id"], 0) + 1
    for did in set(dh) | set(ph):
        if did not in by_dev:
            info = eq.get(did) or {}
            by_dev[did] = {"device_id": did, "device": info.get("name") or "#%s" % did,
                           "line": info.get("line") or RE.NO_LINE, "dates": [], "faults": {}}
    rows = []
    for did, r in by_dev.items():
        iv = _intervals(r["dates"])
        ds = sorted(d for d in r["dates"] if d)
        down = round(dh.get(did, 0.0), 2)
        rows.append({"device_id": did, "device": r["device"], "line": r["line"],
                     "count": len(r["dates"]), "first": ds[0] if ds else None,
                     "last": ds[-1] if ds else None, "intervals": iv,
                     "mean_days": _r1(sum(iv) / len(iv)) if iv else None,
                     "median_days": _median(iv),
                     "chronic": len(r["dates"]) >= CHRONIC_FROM,
                     "faults": dict(sorted(r["faults"].items(), key=lambda kv: (-kv[1], kv[0]))),
                     "downtime_h": down, "downtimes": dn.get(did, 0),
                     "mttr_h": _r1(down / dn[did]) if dn.get(did) else None,
                     "planned_h": round(ph.get(did, 0.0), 2)})
    rows.sort(key=lambda x: (-x["count"], -x["downtime_h"], str(x["device"])))
    pairs = {}
    for e in fails:
        k = (e["device_id"], e["fault"] or "не вказано")
        pairs.setdefault(k, {"device_id": k[0], "device": e["device"], "line": e["line"],
                             "fault": k[1], "dates": []})["dates"].append(_date_of(e))
    prow = []
    for p in pairs.values():
        iv = _intervals(p["dates"])
        prow.append({"device_id": p["device_id"], "device": p["device"], "line": p["line"],
                     "fault": p["fault"], "count": len(p["dates"]), "intervals": iv,
                     "median_days": _median(iv)})
    prow.sort(key=lambda x: (-x["count"], str(x["device"]), x["fault"]))
    lines = {}
    for r in rows:
        L = lines.setdefault(r["line"], {"line": r["line"], "count": 0, "downtime_h": 0.0,
                                         "devices": 0})
        L["count"] += r["count"]
        L["downtime_h"] = round(L["downtime_h"] + r["downtime_h"], 2)
        L["devices"] += 1 if r["count"] else 0
    lrow = sorted(lines.values(), key=lambda x: (-x["count"], -x["downtime_h"], x["line"]))
    return {"total": len(fails), "by_device": rows, "by_pair": prow, "by_line": lrow}


# ── 2. ПЛАН / ФАКТ ───────────────────────────────────────────────────────────
def _plan_fact(events, as_of):
    tasks = [e for e in events if e["kind"] == "task"]
    sched = [e for e in tasks if e["type"] in (RE.T_PLANNED, RE.T_REGULAR)
             and e["due"] and e["due"] <= as_of]
    on_time = [e for e in sched if e["done"] and e["fact"] and e["fact"] <= e["due"]]
    late = [e for e in sched if e["done"] and e["fact"] and e["fact"] > e["due"]]
    overdue = [e for e in sched if not e["done"] and e["due"] < as_of]
    od_rows = [{"id": e["id"], "number": e["number"], "device_id": e["device_id"],
                "device": e["device"], "line": e["line"], "subject": e["subject"],
                "due": e["due"], "overdue_days": (as_of - e["due"]).days, "users": e["users"]}
               for e in overdue]
    od_rows.sort(key=lambda x: -x["overdue_days"])
    by_line = {}
    for e in sched:
        L = by_line.setdefault(e["line"], {"line": e["line"], "scheduled": 0, "on_time": 0,
                                           "late": 0, "overdue_open": 0})
        L["scheduled"] += 1
        L["on_time"] += e in on_time
        L["late"] += e in late
        L["overdue_open"] += e in overdue
    for L in by_line.values():
        L["on_time_share"] = _r1(100.0 * L["on_time"] / L["scheduled"])
    by_month = {}
    for e in sched:
        m = e["due"].strftime("%Y-%m")
        M = by_month.setdefault(m, {"month": m, "scheduled": 0, "on_time": 0})
        M["scheduled"] += 1
        M["on_time"] += e in on_time
    fails = [e for e in tasks if e["type"] == RE.T_FAILURE]
    return {"scheduled": len(sched), "on_time": len(on_time), "late": len(late),
            "late_days_avg": _r1(sum(e["late_days"] for e in late) / len(late)) if late else None,
            "overdue_open": len(overdue), "overdue": od_rows,
            "on_time_share": _r1(100.0 * len(on_time) / len(sched)) if sched else None,
            "reactive_share": _r1(100.0 * len(fails) / len(tasks)) if tasks else None,
            "by_line": sorted(by_line.values(), key=lambda x: x["line"]),
            "by_month": [by_month[k] for k in sorted(by_month)]}


# ── 3. ЧЕРНЕТКА ППР ──────────────────────────────────────────────────────────
def _ppr(events, failures):
    reg = {}
    for e in events:
        if e["kind"] == "task" and e["type"] == RE.T_REGULAR and (e["due"] or e["plan"]):
            reg.setdefault(e["device_id"], []).append(e["due"] or e["plan"])
    out = []
    for r in failures["by_device"]:
        if not r["chronic"] or r["median_days"] is None:
            continue
        prop = max(PPR_MIN_DAYS, int(round(PPR_SHARE * r["median_days"])))
        cur = _median(_intervals(reg.get(r["device_id"], [])))
        if cur is None:
            adv = ADV_CREATE
        elif cur > prop:
            adv = ADV_SHORTEN
        else:
            adv = ADV_KEEP
        out.append({"device_id": r["device_id"], "device": r["device"], "line": r["line"],
                    "failures": r["count"], "median_days": r["median_days"],
                    "main_fault": next(iter(r["faults"]), ""), "proposed_days": prop,
                    "next_date": r["last"] + _dt.timedelta(days=prop) if r["last"] else None,
                    "current_days": cur, "advice": adv})
    return out


# ── 4. ПРОСТОЇ ↔ ВИПУСК ──────────────────────────────────────────────────────
def _pearson(xs, ys):
    n = len(xs)
    if n < 3:
        return None
    mx, my = sum(xs) / n, sum(ys) / n
    sx = sum((x - mx) ** 2 for x in xs) ** 0.5
    sy = sum((y - my) ** 2 for y in ys) ** 0.5
    if not sx or not sy:
        return None
    return round(sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / (sx * sy), 2)


def _output(events, eq, production):
    if not production or not production.get("rows"):
        return None
    known = {_norm_line(e.get("line")): e.get("line") for e in eq.values()}
    known.update({_norm_line(e["line"]): e["line"] for e in events})
    down, anyd = {}, set()
    for e in events:
        if e["kind"] == "downtime" and e["duration_h"] and e["fact"]:
            anyd.add((_norm_line(e["line"]), e["fact"]))
        if e["kind"] == "downtime" and not e["planned"] and e["duration_h"] and e["fact"]:
            k = (_norm_line(e["line"]), e["fact"])
            down[k] = down.get(k, 0.0) + e["duration_h"]
    days = {}
    for r in production["rows"]:
        k = (_norm_line(r["line"]), r["date"])
        days[k] = days.get(k, 0.0) + r["output"]
    unmatched = sorted({r["line"] for r in production["rows"]
                        if _norm_line(r["line"]) not in known})
    out = []
    for ln in sorted({k[0] for k in days if k[0] in known}):
        ds = sorted((d, v) for (l, d), v in days.items() if l == ln)
        quiet = [v for d, v in ds if (ln, d) not in anyd]
        base = _median(quiet)
        hit = [(d, v, down[(ln, d)]) for d, v in ds if down.get((ln, d))]
        loss = round(sum(max(0.0, base - v) for _d, v, _h in hit), 2) if base is not None else None
        out.append({"line": known[ln], "days": len(ds), "baseline": base,
                    "downtime_days": len(hit),
                    "downtime_h": round(sum(h for _d, _v, h in hit), 2), "loss": loss,
                    "corr": _pearson([down.get((ln, d), 0.0) for d, _v in ds], [v for _d, v in ds])})
    return {"unit": production.get("unit") or "", "by_line": out,
            "loss_total": round(sum(r["loss"] or 0 for r in out), 2),
            "unmatched_lines": unmatched}


# ── 5. ДІРКИ У ВІДПОВІДАЛЬНОСТІ І ЛЮДИ ───────────────────────────────────────
def _row(e, as_of=None):
    r = {"id": e["id"], "number": e["number"], "device_id": e["device_id"], "device": e["device"],
         "line": e["line"], "type": e["type"], "subject": e["subject"], "due": e["due"],
         "fact": e["fact"], "users": e["users"]}
    if as_of and e["due"] and not e["done"] and e["due"] < as_of:
        r["overdue_days"] = (as_of - e["due"]).days
    return r


def _holes(events, failures, as_of):
    tasks = [e for e in events if e["kind"] == "task"]
    overdue = (lambda e: not e["done"] and e["due"] and e["due"] < as_of)
    has_sched = {e["device_id"] for e in tasks if e["type"] in (RE.T_PLANNED, RE.T_REGULAR)}
    return {
        "no_users": [_row(e, as_of) for e in tasks if not e["users"]],
        "no_users_overdue": [_row(e, as_of) for e in tasks if not e["users"] and overdue(e)],
        "no_confirm": [_row(e) for e in tasks if e["done"] and not e["confirmed_by"]],
        "no_fault": [_row(e) for e in tasks if e["type"] == RE.T_FAILURE and not e["fault"]],
        "no_ppr": [{"device_id": r["device_id"], "device": r["device"], "line": r["line"],
                    "failures": r["count"]}
                   for r in failures["by_device"] if r["count"] and r["device_id"] not in has_sched],
    }


def _people(events, as_of):
    pe = {}
    for e in events:
        if e["kind"] != "task":
            continue
        for u in e["users"]:
            p = pe.setdefault(u, {"name": u, "tasks": 0, "failures": 0, "overdue": 0, "late": 0})
            p["tasks"] += 1
            p["failures"] += e["type"] == RE.T_FAILURE
            p["overdue"] += bool(not e["done"] and e["due"] and e["due"] < as_of)
            p["late"] += bool(e["late_days"] and e["late_days"] > 0)
    return sorted(pe.values(), key=lambda x: (-x["tasks"], x["name"]))


def analyze(norm: dict, production=None, as_of=None) -> dict:
    """Числа аналітики ремонтів. `as_of` — дата звіту (типово сьогодні)."""
    as_of = as_of or _dt.date.today()
    events = list((norm or {}).get("events") or [])
    eq = dict((norm or {}).get("equipment") or {})
    fl = _failures(events, eq)
    return {"as_of": as_of, "period": (norm or {}).get("period"),
            "events": len(events), "devices": len(eq),
            "failures": fl, "plan_fact": _plan_fact(events, as_of), "ppr": _ppr(events, fl),
            "output": _output(events, eq, production), "holes": _holes(events, fl, as_of),
            "people": _people(events, as_of), "quality": dict((norm or {}).get("quality") or {}),
            "rules": {"chronic_from": CHRONIC_FROM, "ppr_share": PPR_SHARE,
                      "ppr_min_days": PPR_MIN_DAYS}}
