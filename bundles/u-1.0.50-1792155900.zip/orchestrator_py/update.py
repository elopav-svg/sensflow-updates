"""
update.py — механіка оновлень клієнтської інсталяції SensFlow (Фаза 1).

Дизайн (DESIGN_Оновлення_та_Сервіс-центр.md):
  • Перевірка: тягне PER-CLIENT маніфест (за хешем імені клієнта), перевіряє HMAC-підпис
    секретом ліцензії (LICENSE_SIGNING_SECRET) — без нової PKI. Гейт — активна ліцензія.
  • Застосування по кліку: для кожного нового оновлення →
      завантажити бандл (zip) → звірити SHA-256 → БЕКАП → розпакувати поверх коду
      → пост-перевірка (py_compile) → при збої ВІДКАТ із бекапу → журнал.
  • НІКОЛИ не чіпає: .env.local, runs/, threads/, _backups/ (ключі й дані клієнта).

Тільки stdlib (urllib). Підтримує https:// і file:// (для офлайн-тесту).
"""

import json
import os
import hmac
import hashlib
import shutil
import zipfile
import tempfile
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime

import config
import one_writer


# ⛒ 623: ДОВІРУ ДО СЕРТИФІКАТА ЗНАЄ ОДИН ПИСАР (netfetch.ssl_context).
# Модуль, що відкриває сокет сам, у клієнта зі старим сховищем коренів ляже
# мовчки — саме це сталось 21.09.2026 з Telegram. Тому кожен вихід питає його.
def _sf_ssl():
    try:
        import netfetch
        return netfetch.ssl_context()
    except Exception:
        return None


# Файли/теки, які застосування ніколи не перезаписує (відносно кореня платформи).
_PROTECTED = (
    "orchestrator_py/.env.local",
    "orchestrator_py/.env",
    "orchestrator_py/runs/",
    "orchestrator_py/threads/",
    "_backups/",
)

# ⭐⭐⭐ 04.08.2026. ДРУГИЙ ЗАМОК — НА БОЦІ КЛІЄНТА.
# Перелік вище — це імена, які ми згадали. Але оновлення розпаковується ПОВЕРХ,
# і будь-який файл стану, що випадково потрапив у бандл, затирає ЖИВУ памʼять
# машини клієнта. Так сторож тендерів після оновлення забував, що вже надсилав.
# Ми прибрали стан із бандла (publish_update), але це наш бік і наша уважність.
# Тут стоїть замок, який тримає навіть тоді, коли ми помилились: клас «стан»
# знає state_files — один писар на всі три шляхи.
try:
    import state_files as _state_files
except Exception:                                    # старий пакет без модуля
    _state_files = None

_JOURNAL = config.RUNS_DIR / "_updates.json"


# ── Версії ───────────────────────────────────────────────────────────────────
def current_version() -> str:
    j = _journal_load()
    return j.get("version") or config.APP_VERSION


def _parse(v):
    out = []
    for part in str(v or "0").strip().split("."):
        num = "".join(ch for ch in part if ch.isdigit())
        out.append(int(num) if num else 0)
    return tuple(out) or (0,)


def _newer(latest, current) -> bool:
    return _parse(latest) > _parse(current)


# ── Журнал застосованих оновлень ─────────────────────────────────────────────
def _journal_load() -> dict:
    try:
        d = one_writer.read_json(_JOURNAL)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    d.setdefault("version", config.APP_VERSION)
    d.setdefault("applied", [])
    return d


def _journal_save(d: dict):
    try:
        _JOURNAL.parent.mkdir(parents=True, exist_ok=True)
        one_writer.write_json(_JOURNAL, d)
    except Exception:
        pass


# ── Підпис маніфесту (HMAC секретом ліцензії) ────────────────────────────────
def _secret() -> bytes:
    return (config.ENV.get("LICENSE_SIGNING_SECRET")
            or "SensFlow-license-signing-2026-change-me").encode("utf-8")


def _canon(manifest_body: dict) -> bytes:
    """Канонічний JSON тіла маніфесту (без поля sig) для підпису."""
    body = {k: v for k, v in manifest_body.items() if k != "sig"}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def manifest_sig(manifest_body: dict, secret=None) -> str:
    """HMAC-SHA256 (hex) тіла маніфесту. Спільне для перевірки (клієнт) і публікації (підтримка).
    secret: per-client секрет (None = секрет цієї збірки). Клієнт перевіряє своїм секретом
    зі своєї .env.local; публікатор підписує секретом клієнта з CRM."""
    key = _secret() if secret is None else (secret.encode("utf-8") if isinstance(secret, str) else secret)
    return hmac.new(key, _canon(manifest_body), hashlib.sha256).hexdigest()


# ── ⭐⭐⭐ 798. ПЕЧАТКА ПОСТАЧАЛЬНИКА: ПІДПИС Ed25519 ────────────────────────────
# 🩸 До 798 клієнт вірив маніфесту з HMAC — а секрет HMAC лежить у його ж
# `.env.local` (або вбудоване типове значення вище). Хто має машину замовника, міг
# підписати будь-яке «оновлення» (паспорт 784, розділ 15).
# ⛒ Клієнт вірить ЛИШЕ підпису Ed25519 (`ed25519.py`, RFC 8032) відкритим ключем
# постачальника, вшитим нижче. Закритий ключ — лише на машині постачальника
# (`SUPPLIER_ED25519_KEY` у його `.env.local`); ні в пакет, ні в оновлення він не їде.
# ⛒ Публікація запечатує ОДНИМ писарем (`seal_manifest`): Ed25519 + HMAC старої
# схеми поверх нього — клієнти на коді до 798 так само приймуть перехідне оновлення.
SUPPLIER_PUBLIC_HEX = "dddeda622a183b96472027c3b30c65197cd5061dab77f4e2ff590f81f545fda8"
SUPPLIER_KEY_ENV = "SUPPLIER_ED25519_KEY"
ED_FIELD = "sig_ed25519"


class SealError(Exception):
    """Публікацію зупинено: печатку поставити не можна (слова — людині)."""


def _canon_ed(manifest_body: dict) -> bytes:
    """Канонічне тіло для Ed25519: без обох підписів."""
    body = {k: v for k, v in manifest_body.items() if k not in ("sig", ED_FIELD)}
    return json.dumps(body, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def seal_manifest(man: dict, secret=None) -> dict:
    """Запечатати маніфест перед публікацією: Ed25519 ключем постачальника, потім HMAC
    старої схеми (`secret` — секрет клієнта з CRM) для клієнтів на коді до 798."""
    import ed25519
    raw = str(config.ENV.get(SUPPLIER_KEY_ENV) or "").strip()
    if not raw:
        raise SealError("немає ключа підпису постачальника (%s у .env.local) — публікацію "
                        "зупинено" % SUPPLIER_KEY_ENV)
    try:
        sk = bytes.fromhex(raw)
    except ValueError:
        sk = b""
    if len(sk) != 32:
        raise SealError("ключ підпису постачальника пошкоджено (%s) — публікацію зупинено"
                        % SUPPLIER_KEY_ENV)
    if ed25519.public_key(sk).hex() != SUPPLIER_PUBLIC_HEX:
        raise SealError("ключ підпису постачальника не збігається з відкритим ключем у коді "
                        "(update.SUPPLIER_PUBLIC_HEX) — клієнти відкинули б оновлення; "
                        "публікацію зупинено")
    man.pop("sig", None)
    man.pop(ED_FIELD, None)
    tok = str(config.ENV.get(CHANNEL_TOKEN_ENV) or "").strip()
    if tok:                                          # ⭐ 805: ключ каналу — під печаткою
        man[CHANNEL_FIELD] = channel_key_seal(tok, secret)
    man[ED_FIELD] = ed25519.sign(sk, _canon_ed(man)).hex()
    man["sig"] = manifest_sig(man, secret=secret)
    return man


def _verify_sig(manifest: dict) -> bool:
    """⭐ 798: віримо лише печатці постачальника (Ed25519). HMAC — не доказ."""
    import ed25519
    try:
        raw = bytes.fromhex(str(manifest.get(ED_FIELD) or ""))
        pub = bytes.fromhex(SUPPLIER_PUBLIC_HEX)
    except ValueError:
        return False
    return ed25519.verify(pub, _canon_ed(manifest), raw)


# ── ⭐⭐⭐ 805. ЗАКРИТИЙ КАНАЛ ОНОВЛЕНЬ: КЛЮЧ ДОСТУПУ ПРИХОДИТЬ САМ ───────────────
# 🩸 Сховище оновлень на GitHub було публічним: код кожного оновлення міг скачати
# будь-хто. Закрити його можна лише тоді, коли платформа клієнта ходить туди з ключем
# «лише читання». Слово Андрія 15.10.2026: адміністратор клієнта нічого не робить —
# отже ключ їде каналом оновлень, зашифрований секретом САМЕ цього клієнта
# (`LICENSE_SIGNING_SECRET` у нього = картка CRM у постачальника), під печаткою Ed25519.
# ⛒ Ключ іде лише на адреси каналу (`TOKEN_HOSTS`) і не передається на перенаправленні.
# ⛒ Відкликаний ключ на ще публічному сховищі не зупиняє оновлень: повтор без ключа.
CHANNEL_FIELD = "channel_key"
CHANNEL_TOKEN_ENV = "UPDATE_CHANNEL_TOKEN"
TOKEN_HOSTS = (("https", "raw.githubusercontent.com"),)
_CHANNEL = config.RUNS_DIR / "_update_channel.json"


def _secret_bytes(secret=None) -> bytes:
    if secret is None:
        return _secret()
    return secret.encode("utf-8") if isinstance(secret, str) else secret


def _ck_keys(secret) -> tuple:
    s = _secret_bytes(secret)
    return (hmac.new(s, b"sensflow-channel-805-enc", hashlib.sha256).digest(),
            hmac.new(s, b"sensflow-channel-805-mac", hashlib.sha256).digest())


def _ck_stream(key: bytes, nonce: bytes, n: int) -> bytes:
    out, i = b"", 0
    while len(out) < n:
        out += hmac.new(key, nonce + i.to_bytes(4, "big"), hashlib.sha256).digest()
        i += 1
    return out[:n]


def channel_key_seal(token: str, secret=None) -> dict:
    """Зашифрувати ключ каналу секретом клієнта (шифр + перевірка цілості, лише stdlib)."""
    enc, mac = _ck_keys(secret)
    nonce = os.urandom(16)
    raw = token.encode("utf-8")
    c = bytes(a ^ b for a, b in zip(raw, _ck_stream(enc, nonce, len(raw))))
    t = hmac.new(mac, nonce + c, hashlib.sha256).hexdigest()
    return {"v": 1, "n": nonce.hex(), "c": c.hex(), "t": t}


def channel_key_open(box, secret=None) -> str:
    """Ключ каналу або "" — чужий секрет, підправлений чи зламаний запис."""
    try:
        enc, mac = _ck_keys(secret)
        nonce, c = bytes.fromhex(box["n"]), bytes.fromhex(box["c"])
        want = hmac.new(mac, nonce + c, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(want, str(box["t"])):
            return ""
        return bytes(a ^ b for a, b in zip(c, _ck_stream(enc, nonce, len(c)))).decode("utf-8")
    except Exception:
        return ""


def channel_token() -> str:
    """Ключ каналу: рядок UPDATE_CHANNEL_TOKEN (постачальник / ручний запас) або отриманий."""
    tok = str(config.ENV.get(CHANNEL_TOKEN_ENV) or "").strip()
    if tok:
        return tok
    try:
        return str(json.loads(_CHANNEL.read_text(encoding="utf-8")).get("token") or "")
    except Exception:
        return ""


def _remember_channel(manifest: dict):
    """Лише після печатки: запамʼятати ключ каналу, якщо він для цієї інсталяції."""
    box = manifest.get(CHANNEL_FIELD)
    if not isinstance(box, dict):
        return
    tok = channel_key_open(box)
    if not tok or tok == channel_token():
        return
    try:
        _CHANNEL.parent.mkdir(parents=True, exist_ok=True)
        one_writer.write_json(_CHANNEL, {"token": tok, "at": datetime.now().isoformat(timespec="seconds")})
    except Exception:
        pass


def _token_for(url: str) -> str:
    from urllib.parse import urlsplit
    u = urlsplit(url)
    if (u.scheme.lower(), (u.hostname or "").lower()) not in TOKEN_HOSTS:
        return ""
    return channel_token()


# ── ⭐⭐⭐ 20.09.2026 (зміна 621). АДРЕСА КАНАЛУ — ОДИН ПИСАР НА ОБИДВА БОКИ ──
# КЛАС: канал оновлень адресовано ІМЕНЕМ, а живу інсталяцію визначає ЛІЦЕНЗІЯ.
# Живий випадок: у CRM дві картки Каспера — пілот «Подервінскас Андрій
# Владимирович» (псевдонім Casper, строк минув 10.09.2026) і платна
# ТОВ «КАСПЕР УКРАЇНА» (до 13.09.2027). Усі 25 публікацій пішли в канал
# ПІЛОТА, бо в батнику стояло імʼя `Casper`. Платна збірка питала свою адресу,
# файла там не було, і платформа відповідала клієнтові «У вас найновіша
# версія». Місяць роботи не доїхав, і жоден рядок не був червоний.
# ⛒ Тому адресу рахує ОДИН писар — цей, — і публікація питає саме його.
def channel_hash(customer: str) -> str:
    """Адреса каналу оновлень для імені з ліцензії. Єдиний писар на обидва боки."""
    return hashlib.sha256((customer or "anon").encode("utf-8")).hexdigest()[:16]


def manifest_name(customer: str) -> str:
    return "%s.json" % channel_hash(customer)


def _dmy(iso: str) -> str:
    """Дата людині — DD.MM.YYYY."""
    try:
        y, m, d = str(iso).split("-")
        return "%s.%s.%s" % (d, m, y)
    except Exception:
        return str(iso or "")


def pick_channel(name: str, cards: dict, today=None, purpose: str = "publish") -> dict:
    """⛒ ВОРОТА ПУБЛІКАЦІЇ: у який канал і чи взагалі можна класти оновлення.

    ⛒ ВОРОТА СУДЯТЬ ДІЮ, А НЕ САМЕ ІМʼЯ (20.09.2026, та сама зміна).
    `purpose="publish"` — НОВЕ оновлення: у мертвий канал не їде, бо там його
    ніхто не прочитає. `purpose="repair"` — виправити опис або ВІДКЛИКАТИ вже
    покладене: це дозволено й на мертвій ліцензії, інакше поганий бандл не було
    б чим забрати назад. Ворота, які глушать ремонт, самі стають вадою.

    Приймає будь-яке з трьох імен картки (ключ, `customer`, `name_en`) і
    ПОВЕРТАЄ адресу, яку справді питає інсталяція з виданим ключем.

    FAIL-CLOSED на трьох речах, кожна з яких колись коштувала тихого успіху:
      • імені немає в CRM — маніфест ліг би у файл, якого ніхто не читає;
      • імʼя збігається з кількома картками — мовчазний вибір першої;
      • ліцензія картки мертва — канал, якого не читає жодна жива інсталяція.
    """
    from datetime import date as _date
    today = today or _date.today()
    want = (name or "").strip().lower()
    out = {"ok": False, "customer": "", "hash": "", "edition": "", "expiry": "", "why": ""}
    if not want:
        out["why"] = "імені клієнта не названо"
        return out

    hits = []
    for key, c in (cards or {}).items():
        names = {str(key).strip().lower(),
                 str((c or {}).get("customer") or "").strip().lower(),
                 str((c or {}).get("name_en") or "").strip().lower()}
        names.discard("")
        if want in names:
            hits.append((key, c or {}))

    if not hits:
        out["why"] = ("у CRM немає клієнта «%s» — маніфест ліг би у файл, "
                      "якого ніхто не читає" % name)
        return out
    if len(hits) > 1:
        out["why"] = ("імʼя «%s» збігається з %d картками (%s) — назви точніше, "
                      "мовчазний вибір першої вже коштував місяця оновлень"
                      % (name, len(hits),
                         "; ".join(str(k) for k, _ in hits)))
        return out

    key, card = hits[0]
    cust = str(card.get("customer") or key)
    out["customer"] = cust
    out["hash"] = channel_hash(cust)
    out["edition"] = str(card.get("edition") or "")
    expiry = str(card.get("expiry") or "")
    out["expiry"] = expiry
    try:
        from datetime import date as _d
        exp = _d.fromisoformat(expiry)
    except Exception:
        if str(purpose or "publish") != "publish":
            out["ok"] = True          # ремонт уже покладеного строку не питає
            return out
        out["why"] = ("у картці «%s» немає придатного строку ліцензії (%r) — "
                      "невідомо, чи читає хтось цей канал" % (cust, expiry))
        return out
    if exp < today and str(purpose or "publish") == "publish":
        out["why"] = ("ліцензія картки «%s» скінчилась %s — оновлення лягло б у "
                      "канал, якого не читає жодна жива інсталяція"
                      % (cust, _dmy(expiry)))
        return out

    out["ok"] = True
    out["why"] = ""
    return out


# ── ⭐⭐⭐ 20.09.2026 (зміна 621). ЩО НОВЕ ДЛЯ ЦІЄЇ ІНСТАЛЯЦІЇ — ОДИН ПИСАР ───
# Відбір судив лише id із журналу. У свіжої збірки журнал ПОРОЖНІЙ, тож уся
# історія бандлів (1.0.1 … 1.0.25) вважалась новою і лягала ПОВЕРХ свіжого
# коду — відкат під виглядом оновлення. Версія судиться разом з id, і одним
# писарем на обидві двері: перевірку і застосування.
def new_for_install(updates, current: str, applied) -> list:
    """Нове = ще не застосоване І СТРОГО НОВІШЕ за встановлену версію."""
    applied = set(applied or ())
    out = []
    for u in (updates or []):
        if not isinstance(u, dict) or not u.get("id"):
            continue
        if u["id"] in applied:
            continue
        if not _newer(u.get("version"), current):
            continue
        out.append(u)
    out.sort(key=lambda u: _parse(u.get("version")))
    return out


# ── Адреса маніфесту (per-client за хешем імені) ─────────────────────────────
def _customer() -> str:
    try:
        import license as licensing
        return licensing.status().get("customer", "") or ""
    except Exception:
        return ""


def manifest_url() -> str:
    """Прямий UPDATE_URL (override) АБО per-client: <UPDATE_BASE_URL>/<hash(customer)>.json.
    ⭐ 801: тека оновлень (`UPDATE_DIR`) — канал тим самим писарем, але з диска."""
    _dir = str(getattr(config, "UPDATE_DIR", "") or "").strip()
    if _dir:
        return (Path(_dir) / "manifests" / manifest_name(_customer())).as_uri()
    if config.UPDATE_URL:
        return config.UPDATE_URL
    if config.UPDATE_BASE_URL:
        return f"{config.UPDATE_BASE_URL}/{manifest_name(_customer())}"
    return ""


# ── Низькорівневе завантаження (https / file) ────────────────────────────────
def _open_bytes(url: str, timeout: int, headers: dict, token: str) -> bytes:
    req = urllib.request.Request(url, headers=headers or {})
    if token:                                        # ⛒ 805: на перенаправленні — не передається
        req.add_unredirected_header("Authorization", "token " + token)
    with urllib.request.urlopen(req, timeout=timeout, context=_sf_ssl()) as r:
        return r.read()


def _fetch_bytes(url: str, timeout: int = 30, headers: dict = None) -> bytes:
    tok = _token_for(url)
    if tok:
        try:
            return _open_bytes(url, timeout, headers, tok)
        except urllib.error.HTTPError as e:
            if e.code not in (401, 403, 404):
                raise
            # ⛒ 805: ключ відкликано, а сховище ще публічне — пробуємо без ключа
    return _open_bytes(url, timeout, headers, "")


def _fetch_json(url: str, timeout: int = 12) -> dict:
    headers = {"Accept": "application/json", "User-Agent": f"SensFlow/{current_version()}"}
    if config.LICENSE_KEY:
        headers["x-license-key"] = config.LICENSE_KEY
    return json.loads(_fetch_bytes(url, timeout=timeout, headers=headers).decode("utf-8"))


# ── Перевірка наявності оновлень ─────────────────────────────────────────────
def check_for_update(timeout: int = 12) -> dict:
    """Стан без жодних змін у системі:
    {current, latest, available, gated, message, updates:[...], notes}."""
    cur = current_version()
    # ⛒ 621: стан каналу оголошується ЗАВЖДИ. «unknown» — це не «все свіже».
    base = {"current": cur, "latest": cur, "available": False, "gated": False,
            "unknown": False, "channel": "ok",
            "message": "", "updates": [], "notes": ""}

    # Гейт підписки
    import license as licensing
    lic = licensing.status()
    if not lic.get("valid"):
        base["gated"] = True
        base["channel"] = "gated"
        base["message"] = ("Оновлення доступні за активною підпискою. "
                           "Активуйте ліцензію (Про систему → Ліцензія) або зверніться до підтримки.")
        if config.LICENSE_KEY:
            base["message"] = (f"Оновлення недоступні: ліцензія — {lic.get('reason','недійсна')}. "
                               "Зверніться до підтримки SensFlow.")
        return base

    url = manifest_url()
    # ⭐ 801: закритий контур (800) без теки оновлень — чесні слова, що робити, а не
    # «сервер недоступний»: з інтернету тут оновлення не прийде ніколи.
    try:
        import closed_perimeter as _cp801
        if _cp801.on() and url and not url.lower().startswith("file:"):
            base["unknown"] = True
            base["channel"] = "closed"
            base["message"] = ("Закритий контур: оновлення з інтернету вимкнено. Отримайте пакет "
                               "оновлень у постачальника, покладіть теку на цей компʼютер і вкажіть її "
                               "рядком UPDATE_DIR у файлі налаштувань (мануал 3.4).")
            return base
    except Exception:
        pass
    if not url:
        base["unknown"] = True
        base["channel"] = "off"
        base["message"] = ("Сервер оновлень не налаштований — ми не знаємо, чи є для вас "
                           "нові версії. Зверніться до підтримки SensFlow.")
        return base

    try:
        manifest = _fetch_json(url, timeout=timeout)
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            base["gated"] = True
            base["channel"] = "gated"
            base["message"] = "Підписку не підтверджено. Зверніться до підтримки SensFlow."
        elif e.code == 404:
            # ⛒⛒⛒ 621. ТУТ БУЛА НАЙДОРОЖЧА БРЕХНЯ: 404 означав «у вас найновіша
            # версія». Насправді 404 означає, що каналу для цієї ліцензії просто
            # НЕМАЄ, і ми не знаємо нічого. Каспер так місяць читав зелений напис.
            base["unknown"] = True
            base["channel"] = "missing"
            base["message"] = ("Канал оновлень для вашої ліцензії ще не відкрито — "
                               "ми не знаємо, чи є для вас нові версії. "
                               "Зверніться до підтримки SensFlow.")
        else:
            base["unknown"] = True
            base["channel"] = "unreachable"
            base["message"] = f"Не вдалося перевірити оновлення (HTTP {e.code}). Стан невідомий."
        return base
    except Exception:
        base["unknown"] = True
        base["channel"] = "unreachable"
        base["message"] = "Сервер оновлень недоступний — стан невідомий. Спробуйте пізніше."
        return base

    if not _verify_sig(manifest):
        base["unknown"] = True
        base["channel"] = "untrusted"
        base["message"] = "Підпис маніфесту оновлень недійсний — застосування заблоковано (безпека)."
        return base
    _remember_channel(manifest)                      # ⭐ 805: лише після печатки

    journal = _journal_load()
    # ⛒ 621: один писар «що нове для ЦІЄЇ інсталяції» — і на перевірці, і на
    # застосуванні. Судиться версія, а не лише журнал: свіжа збірка з порожнім
    # журналом більше не отримує історію бандлів собі на голову.
    new = new_for_install(manifest.get("updates"), cur, journal.get("applied", []))

    base["latest"] = str(manifest.get("version") or cur)
    base["notes"] = str(manifest.get("notes") or "")
    base["updates"] = new
    base["available"] = bool(new)
    base["message"] = (f"Доступно оновлень: {len(new)}." if new else "У вас найновіша версія.")
    return base


# ── Безпечне застосування ────────────────────────────────────────────────────
def _is_protected(rel: str) -> bool:
    rel = rel.replace("\\", "/")
    if rel.startswith("/") or ".." in rel.split("/"):
        return True  # захист від виходу за межі
    if any(rel == p.rstrip("/") or rel.startswith(p) for p in _PROTECTED):
        return True
    # Живий стан клієнта не затирається НІКОЛИ, навіть якщо ми поклали свій у бандл.
    if _state_files is not None:
        try:
            return bool(_state_files.is_state(rel))
        except Exception:
            return False
    return False


def _post_check(engine_dir: Path) -> list:
    """py_compile усіх .py движка. Повертає список битих (порожній = ок)."""
    import py_compile
    bad = []
    for f in engine_dir.rglob("*.py"):
        if "__pycache__" in f.parts:
            continue
        try:
            py_compile.compile(str(f), doraise=True)
        except Exception:
            bad.append(str(f.relative_to(engine_dir)))
    return bad


def _bundle_source(u: dict) -> str:
    """⭐ 801: звідки брати пакет. Задано теку оновлень — з `<тека>/bundles/<імʼя>` (імʼя — з
    адреси в переліку); інакше — за адресою з переліку. Довіра однакова: печатка переліку і
    SHA-256 пакета."""
    url = str(u.get("bundle_url") or "")
    _dir = str(getattr(config, "UPDATE_DIR", "") or "").strip()
    if not _dir:
        return url
    from urllib.parse import urlsplit, unquote
    name = Path(unquote(urlsplit(url).path)).name
    p = Path(_dir) / "bundles" / name
    if not name or not p.is_file():
        raise FileNotFoundError("Пакета «%s» немає в теці оновлень (%s) — покладіть його туди "
                                "разом із переліком і повторіть." % (name or "?", Path(_dir) / "bundles"))
    return p.as_uri()


def _apply_one(u: dict, root: Path) -> dict:
    """Застосовує одне оновлення з бекапом і відкатом. root — корінь платформи."""
    uid = u.get("id")
    res = {"id": uid, "version": u.get("version"), "ok": False, "message": ""}
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_dir = root / "_backups" / f"{ts}_{uid}"
    overwritten, added = [], []
    tmpzip = None
    try:
        # ⭐ 801: пакет без контрольної суми в переліку — не застосовується (до 801 — застосовувався
        # без перевірки цілісності).
        want = str(u.get("sha256") or "").lower()
        if len(want) != 64:
            res["message"] = ("У переліку оновлень немає контрольної суми пакета — застосування "
                              "скасовано (безпека).")
            return res
        # 1) завантажити бандл (з теки оновлень — за імʼям, 801)
        try:
            src = _bundle_source(u)
        except FileNotFoundError as e:
            res["message"] = str(e)
            return res
        raw = _fetch_bytes(src, timeout=120)
        # 2) SHA-256
        got = hashlib.sha256(raw).hexdigest()
        if got != want:
            res["message"] = "SHA-256 бандла не збігається — застосування скасовано."
            return res
        tmpzip = Path(tempfile.gettempdir()) / f"sf_update_{uid}.zip"
        tmpzip.write_bytes(raw)

        with zipfile.ZipFile(tmpzip) as z:
            members = [m for m in z.namelist() if not m.endswith("/")]
            # 3) бекап того, що перезапишемо; реєстрація нових файлів
            backup_dir.mkdir(parents=True, exist_ok=True)
            for m in members:
                if _is_protected(m):
                    continue
                target = root / m
                if target.exists():
                    dst = backup_dir / m
                    dst.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(target, dst)
                    overwritten.append(m)
                else:
                    added.append(m)
            (backup_dir / "_changeset.json").write_text(
                json.dumps({"overwritten": overwritten, "added": added}, ensure_ascii=False),
                encoding="utf-8")
            # 4) розпакувати поверх (крім захищеного)
            for m in members:
                if _is_protected(m):
                    continue
                target = root / m
                target.parent.mkdir(parents=True, exist_ok=True)
                with z.open(m) as src, open(target, "wb") as out:
                    shutil.copyfileobj(src, out)

        # 5) пост-перевірка
        bad = _post_check(root / "orchestrator_py")
        if bad:
            _rollback(root, backup_dir, overwritten, added)
            res["message"] = f"Пост-перевірка не пройшла ({len(bad)} битих файлів) — відкат виконано, лишились на старій версії."
            return res

        res["ok"] = True
        res["message"] = f"Оновлення {u.get('version')} застосовано."
        return res
    except Exception as e:
        # будь-який збій → відкат
        try:
            _rollback(root, backup_dir, overwritten, added)
        except Exception:
            pass
        res["message"] = f"Збій застосування ({e}) — відкат виконано."
        return res
    finally:
        try:
            if tmpzip and tmpzip.exists():
                tmpzip.unlink()
        except Exception:
            pass


def _rollback(root: Path, backup_dir: Path, overwritten: list, added: list):
    """Відновлює перезаписані файли з бекапу й видаляє щойно додані."""
    for m in overwritten:
        src = backup_dir / m
        if src.exists():
            dst = root / m
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
    for m in added:
        try:
            (root / m).unlink()
        except Exception:
            pass


def apply_updates(ids=None, root: Path = None) -> dict:
    """Застосовує нові оновлення (всі або зі списку ids). root за замовчуванням — корінь платформи.
    Повертає {ok, applied:[...], failed:[...], message, restart_suggested}."""
    root = Path(root) if root else config.PLATFORM_ROOT
    state = check_for_update()
    if state.get("gated"):
        return {"ok": False, "applied": [], "failed": [], "message": state.get("message", "Немає доступу")}
    # ⛒ 621: невідоме не вдає «нема чого робити». Якщо канал не відповів, ми не
    # знаємо, чи є оновлення, — і кажемо саме це, тим самим текстом, що й екран.
    if state.get("unknown"):
        return {"ok": False, "applied": [], "failed": [], "unknown": True,
                "channel": state.get("channel", ""),
                "message": state.get("message", "Стан оновлень невідомий.")}
    todo = [u for u in state.get("updates", []) if (ids is None or u.get("id") in set(ids))]
    if not todo:
        return {"ok": True, "applied": [], "failed": [], "message": "Немає чого застосовувати."}

    applied, failed = [], []
    journal = _journal_load()
    for u in todo:
        r = _apply_one(u, root)
        if r["ok"]:
            applied.append(r)
            if u.get("id") not in journal["applied"]:
                journal["applied"].append(u.get("id"))
            journal["version"] = str(u.get("version") or journal.get("version"))
            _journal_save(journal)
        else:
            failed.append(r)
            break  # зупиняємось на першому збої (вже відкочено)

    ok = bool(applied) and not failed
    msg = (f"Застосовано {len(applied)} оновлень." if applied else "")
    if failed:
        msg = (msg + " " + failed[-1]["message"]).strip()
    return {"ok": ok, "applied": applied, "failed": failed,
            "message": msg or "Готово.", "restart_suggested": bool(applied)}


# Фаза 1 — ядро механіки оновлень (per-client маніфест, підпис, apply+rollback+журнал).

