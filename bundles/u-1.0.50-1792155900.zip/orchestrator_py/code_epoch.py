# -*- coding: utf-8 -*-
"""code_epoch.py — ⭐ ПРОЦЕС ЗНАЄ, ЧИ ЙОГО КОД — ТОЙ, ЩО НА ДИСКУ (зміна 815, 16.10.2026).

🩸 16.10.2026, Андрій із телефона: «Інструкції не працюють» — «Довідник не зібрався: мітку SEC_ROTATE_MB не вдалося
порахувати: module 'protocol' has no attribute 'SEC_ROTATE_BYTES'». Платформу запущено 15.10.2026 о 08:56; модуль
журналу безпеки (`protocol`) завантажився тоді ж — старим. Довідник (`manual_build`) завантажився пізніше, вже з диска
після зміни 796, і попросив у старого модуля межу, якої той ще не мав. Процес тримав у пам'яті код із ДВОХ моментів —
і ніхто про це не знав. Те саме чекає клієнта між «Оновити» і перезапуском.
⛒ КЛАС: процес не знає, що його код застарів відносно диска, тож поломка змішаного коду виглядає як «поломка джерела».
⛒ ЛІК: на старті сервер знімає відбиток (файл → час зміни) кожного модуля рушія, що вже в пам'яті; модулі, які
підвантажились пізніше, записуються при першій зустрічі. `drift()` — модулі, чий файл на диску змінився після того,
як процес їх прочитав. Тоді є що сказати людині: «перезапустіть платформу».
Без залежностей і без мережі.
"""
import os
import sys
import time
from pathlib import Path

_HERE = Path(__file__).resolve().parent
_SNAP = {}                 # імʼя модуля -> (шлях, mtime_ns на момент, коли процес його побачив)
_ROOT = [_HERE]
_STARTED = [""]


def _scan():
    root = _ROOT[0]
    for name, mod in list(sys.modules.items()):
        if name in _SNAP:
            continue
        f = getattr(mod, "__file__", None)
        if not f or not str(f).endswith(".py"):
            continue
        try:
            p = Path(f).resolve()
            if p.parent != root:
                continue
            _SNAP[name] = (str(p), p.stat().st_mtime_ns)
        except OSError:
            continue


def mark(root=None) -> int:
    """Зняти відбиток коду, що вже в пам'яті. Кличе сервер на старті. Повертає, скільки модулів записано."""
    _ROOT[0] = Path(root).resolve() if root else _HERE
    _SNAP.clear()
    _STARTED[0] = time.strftime("%d.%m.%Y %H:%M")
    _scan()
    return len(_SNAP)


def drift() -> list:
    """Модулі рушія, чий файл на диску змінився після того, як процес їх прочитав."""
    _scan()
    out = []
    for name, (path, mt) in sorted(_SNAP.items()):
        try:
            if os.stat(path).st_mtime_ns != mt:
                out.append(name)
        except OSError:
            out.append(name)
    return out


def started() -> str:
    return _STARTED[0]


def restart_note() -> str:
    """Людське речення, коли код у пам'яті застарів; порожньо — коли все збігається."""
    d = drift()
    if not d:
        return ""
    return ("Платформу оновлено на диску, а в пам'яті ще працює копія%s — перезапустіть платформу, і все "
            "запрацює як слід (змінились: %s)."
            % ((" від " + _STARTED[0]) if _STARTED[0] else "",
               ", ".join(d[:6]) + (" та інші" if len(d) > 6 else "")))
