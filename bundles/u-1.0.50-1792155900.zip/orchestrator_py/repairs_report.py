# -*- coding: utf-8 -*-
"""repairs_report.py — «АНАЛІТИКА РЕМОНТІВ»: РОБОТА ПЛАТФОРМИ І ЗВІТ (зміна 793, 14.10.2026).

Пілот Малбі. Оркестратор на запит про ремонти кличе РОБОТУ ПЛАТФОРМИ без моделі
(`data_jobs`, вихід «звіт»):
    знімок з Alldevice (лише перегляд, `repairs_events.pull`)
      → таблиця подій (`repairs_events.normalize`)
      → числа кодом (`repairs_analytics.analyze`)
      → звіт markdown (`render`) з таблицями й блоками графіків
      → файли — ТИМ САМИМ складачем, що й результат системи (`agent._publish_job_report`
        → `artifacts.write_result_artifacts`): .md, .html-дашборд (SVG, 788), .docx, .xlsx.

⛒ ЧОМУ РОБОТА, А НЕ СИСТЕМА З АГЕНТАМИ. Система реєстру — це агенти-моделі; тут жодне
число не сміє рахувати модель (792). Шлях «робота → звіт» уже існує для тендерів і проходить
ті самі ворота файла, журнал прогонів і аудит. Другого складача не заводимо.

⛒ ВИМИКАЧ. Робота належить роботі «Аналітика ремонтів» (`alldevice.WORK_ID`): там, де її не
ввімкнено, оркестратор її не бачить зовсім (`data_jobs`, поле `work`).

Знімок даних (сирі записи Alldevice) кладеться в теку стану `state/repairs/` — щоб звіт
можна було відтворити й звірити; реквізитів у ньому немає (вони не є частиною відповіді).
"""
import datetime as _dt
import json

import config

SNAP_DIR = config.STATE_DIR / "state" / "repairs"
SNAP_KEEP = 10
DEFAULT_DAYS = 730          # «два роки даних», як казали на зустрічі 14.10.2026


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _d(x) -> str:
    """Дата ДД.ММ.РРРР; немає — «—»."""
    if isinstance(x, (_dt.date, _dt.datetime)):
        return x.strftime("%d.%m.%Y")
    return "—"


def _n(x) -> str:
    """Число для таблиці: ціле — без «.0», інакше одна цифра після крапки; немає — «—»."""
    if x is None:
        return "—"
    try:
        f = float(x)
    except (TypeError, ValueError):
        return _s(x) or "—"
    if f == int(f):
        return str(int(f))
    return "%.1f" % f


def _big(x) -> str:
    """Число в тексті людині: розряди пробілом — «107 703.8»; немає — «—»."""
    t = _n(x)
    if t == "—":
        return t
    whole, _, frac = t.partition(".")
    sign = "-" if whole.startswith("-") else ""
    whole = whole.lstrip("-")
    grp = []
    while len(whole) > 3:
        grp.insert(0, whole[-3:])
        whole = whole[:-3]
    grp.insert(0, whole)
    return sign + "\u00a0".join(grp) + (("." + frac) if frac else "")


def _num(v):
    """Значення для графіка: ціле — цілим (у таблиці даних графіка не «25.0»)."""
    f = round(float(v or 0), 1)
    return int(f) if f == int(f) else f


def _cell(v) -> str:
    return _s(v).replace("|", "/").replace("\n", " ") or "—"


def _table(head, rows) -> str:
    out = ["| " + " | ".join(head) + " |", "| " + " | ".join(["---"] * len(head)) + " |"]
    for r in rows:
        out.append("| " + " | ".join(_cell(c) for c in r) + " |")
    return "\n".join(out)


def _chart(kind, title, labels, name, data) -> str:
    spec = {"type": kind, "title": title, "labels": [str(x) for x in labels],
            "series": [{"name": name, "data": [_num(v) for v in data]}]}
    return "```chart\n%s\n```" % json.dumps(spec, ensure_ascii=False)


QUALITY_WORDS = {
    "duplicates": "повторені записи (сторінки перекрились) — враховано один раз",
    "unknown_device": "події на обладнанні, якого немає в переліку обладнання",
    "device_without_place": "обладнання без місця в дереві (лінія невідома)",
    "device_without_id": "обладнання без номера (пропущено)",
    "downtime_open": "незакінчені простої (без тривалості)",
    "downtime_bad_time": "простої з хибним часом (кінець раніше початку)",
    "unknown_task_type": "задачі невідомого виду",
    "done_without_date": "виконані задачі без дати виконання",
    "event_without_date": "події без жодної дати",
}


def render(R: dict, source: str = "Alldevice", production_name: str = "") -> str:
    """Числа аналітики → звіт markdown українською. Чисел тут не рахуємо — лише показуємо."""
    F, PF, PPR, O, H = (R.get("failures") or {}), (R.get("plan_fact") or {}), \
        (R.get("ppr") or []), R.get("output"), (R.get("holes") or {})
    per = R.get("period")
    L = []
    L.append("# Аналітика ремонтів і простоїв")
    L.append("")
    L.append("Період даних: %s — %s. Дата звіту: %s. Джерело: %s; подій %d, обладнання %d. "
             "Випуск продукції: %s." % (
                 _d(per[0]) if per else "—", _d(per[1]) if per else "—", _d(R.get("as_of")),
                 source, int(R.get("events") or 0), int(R.get("devices") or 0),
                 ("файл «%s»" % production_name) if (O and production_name) else
                 ("надано" if O else "не надано")))
    L.append("")
    # ── Головне ──
    top = (F.get("by_device") or [{}])[0] if F.get("by_device") else {}
    chronic = [r for r in F.get("by_device") or [] if r.get("chronic")]
    L.append("## Головне")
    L.append("")
    L.append("- Аварійних ремонтів: %d; обладнання, що ламається регулярно (від %d відмов): %d%s." % (
        int(F.get("total") or 0), int((R.get("rules") or {}).get("chronic_from") or 0), len(chronic),
        ("; найчастіше — %s (%s): відмов %d, медіана між відмовами %s дн" % (
            top.get("device"), top.get("line"), int(top.get("count") or 0), _n(top.get("median_days"))))
        if top.get("count") else ""))
    L.append("- Роботи за графіком: вчасно %s%% (%d з %d), із запізненням %d, прострочено й не "
             "виконано %d." % (_n(PF.get("on_time_share")), int(PF.get("on_time") or 0),
                               int(PF.get("scheduled") or 0), int(PF.get("late") or 0),
                               int(PF.get("overdue_open") or 0)))
    L.append("- Частка аварійних робіт серед усіх: %s%%." % _n(PF.get("reactive_share")))
    if O:
        L.append("- Втрата випуску в дні позапланових простоїв: %s %s." % (
            _big(O.get("loss_total")), O.get("unit") or ""))
    else:
        L.append("- Звʼязок простоїв із випуском: дані випуску не надано.")
    L.append("- Відповідальність: задач без виконавця %d (із них прострочених %d), аварій без "
             "виду відмови %d, обладнання з відмовами без жодного ТО %d." % (
                 len(H.get("no_users") or []), len(H.get("no_users_overdue") or []),
                 len(H.get("no_fault") or []), len(H.get("no_ppr") or [])))
    L.append("")
    # ── 1 ──
    L.append("## 1. Поломки, що повторюються")
    L.append("")
    bd = [r for r in F.get("by_device") or [] if r.get("count")]
    if bd:
        t10 = bd[:10]
        L.append(_chart("bar", "Відмови за обладнанням (топ-%d)" % len(t10),
                        [r["device"] for r in t10], "Відмов", [r["count"] for r in t10]))
        L.append("")
        L.append(_table(["Обладнання", "Лінія", "Відмов", "Середній інтервал, дн", "Медіана, дн",
                         "Позаплановий простій, год", "Відновлення в середньому, год",
                         "Головний вид відмови", "Перша", "Остання"],
                        [[r["device"], r["line"], r["count"], _n(r["mean_days"]), _n(r["median_days"]),
                          _n(r["downtime_h"]), _n(r["mttr_h"]), next(iter(r["faults"]), "—"),
                          _d(r["first"]), _d(r["last"])] for r in bd]))
    else:
        L.append("Аварійних ремонтів за період немає.")
    L.append("")
    pairs = [r for r in F.get("by_pair") or [] if r.get("count", 0) >= 2][:30]
    if pairs:
        L.append("**Повторення того самого виду відмови на тому самому обладнанні**")
        L.append("")
        L.append(_table(["Обладнання", "Лінія", "Вид відмови", "Відмов", "Медіана інтервалу, дн"],
                        [[r["device"], r["line"], r["fault"], r["count"], _n(r["median_days"])]
                         for r in pairs]))
        L.append("")
    bl = F.get("by_line") or []
    if bl:
        L.append(_chart("bar", "Позапланові простої за лініями, год", [r["line"] for r in bl],
                        "Годин", [r["downtime_h"] for r in bl]))
        L.append("")
        L.append(_table(["Лінія", "Відмов", "Позаплановий простій, год", "Одиниць обладнання з відмовами"],
                        [[r["line"], r["count"], _n(r["downtime_h"]), r["devices"]] for r in bl]))
        L.append("")
    # ── 2 ──
    L.append("## 2. План і факт")
    L.append("")
    L.append(_table(["Показник", "Значення"], [
        ["Робіт за графіком зі строком до дати звіту", PF.get("scheduled")],
        ["Виконано вчасно", "%s з %s (%s%%)" % (PF.get("on_time"), PF.get("scheduled"),
                                                _n(PF.get("on_time_share")))],
        ["Виконано із запізненням", PF.get("late")],
        ["Середнє запізнення, дн", _n(PF.get("late_days_avg"))],
        ["Прострочено й не виконано", PF.get("overdue_open")],
        ["Частка аварійних робіт серед усіх, %", _n(PF.get("reactive_share"))]]))
    L.append("")
    bm = PF.get("by_month") or []
    if len(bm) >= 2:
        L.append(_chart("line", "Вчасно виконані роботи за графіком, % за місяцями",
                        [m["month"][5:] + "." + m["month"][:4] for m in bm], "Вчасно, %",
                        [100.0 * m["on_time"] / m["scheduled"] if m["scheduled"] else 0 for m in bm]))
        L.append("")
    if PF.get("by_line"):
        L.append(_table(["Лінія", "За графіком", "Вчасно", "Із запізненням", "Прострочено", "Вчасно, %"],
                        [[r["line"], r["scheduled"], r["on_time"], r["late"], r["overdue_open"],
                          _n(r["on_time_share"])] for r in PF["by_line"]]))
        L.append("")
    od = PF.get("overdue") or []
    if od:
        L.append("**Прострочені й не виконані роботи** (найстаріші зверху, до 50)")
        L.append("")
        L.append(_table(["Номер", "Обладнання", "Лінія", "Робота", "Строк", "Днів прострочки", "Виконавці"],
                        [[r["number"] or r["id"], r["device"], r["line"], r["subject"], _d(r["due"]),
                          r["overdue_days"], ", ".join(r["users"]) or "не призначено"] for r in od[:50]]))
        L.append("")
    # ── 3 ──
    L.append("## 3. Чернетка ППР")
    L.append("")
    rules = R.get("rules") or {}
    L.append("Для обладнання, що ламається регулярно: інтервал ТО = %s × медіанний інтервал між "
             "відмовами (не менше %s днів), наступне ТО — від останньої відмови. Це відправна точка "
             "для інженера, а не наказ." % (_n(rules.get("ppr_share")), _n(rules.get("ppr_min_days"))))
    L.append("")
    if PPR:
        L.append(_table(["Обладнання", "Лінія", "Відмов", "Головний вид відмови", "Медіана між відмовами, дн",
                         "ТО кожні, дн", "Наступне ТО", "Чинний інтервал ТО, дн", "Що зробити"],
                        [[r["device"], r["line"], r["failures"], r["main_fault"] or "—",
                          _n(r["median_days"]), r["proposed_days"], _d(r["next_date"]),
                          _n(r["current_days"]) if r["current_days"] is not None else "немає ТО",
                          r["advice"]] for r in PPR]))
    else:
        L.append("Обладнання з регулярними відмовами за період немає.")
    L.append("")
    # ── 4 ──
    L.append("## 4. Простої і випуск")
    L.append("")
    if not O:
        L.append("Дані випуску продукції не надано. Покладіть таблицю випуску (дата, лінія, обсяг) "
                 "у «Файли» і назвіть її в запиті — розділ порахується.")
    else:
        u = O.get("unit") or ""
        L.append("База лінії — медіана випуску в дні без жодного простою; втрата — нестача до "
                 "бази в дні з позаплановим простоєм (плановий простій втратою не є). Звʼязок (r) — "
                 "від −1 до 1: чим ближче до −1, тим тісніше простій зменшує випуск.")
        L.append("")
        rows = O.get("by_line") or []
        L.append(_table(["Лінія", "Днів даних", "База, %s" % u, "Днів із простоєм", "Простій, год",
                         "Втрата, %s" % u, "Звʼязок (r)"],
                        [[r["line"], r["days"], _n(r["baseline"]), r["downtime_days"],
                          _n(r["downtime_h"]), _n(r["loss"]), _n(r["corr"])] for r in rows]))
        L.append("")
        L.append("Втрата випуску всього: %s %s." % (_big(O.get("loss_total")), u))
        if rows:
            L.append("")
            L.append(_chart("bar", "Втрата випуску в дні позапланових простоїв, %s" % u,
                            [r["line"] for r in rows], "Втрата", [r["loss"] or 0 for r in rows]))
        if O.get("unmatched_lines"):
            L.append("")
            L.append("Лінії з таблиці випуску, яких немає в Alldevice (назви не збіглися — у "
                     "розрахунок не увійшли): %s." % ", ".join(O["unmatched_lines"]))
    L.append("")
    # ── 5 ──
    L.append("## 5. Відповідальність")
    L.append("")
    L.append(_table(["Що не так", "Кількість"], [
        ["Задачі без виконавця", len(H.get("no_users") or [])],
        ["Прострочені задачі без виконавця", len(H.get("no_users_overdue") or [])],
        ["Виконані задачі без підтвердження", len(H.get("no_confirm") or [])],
        ["Аварії без виду відмови", len(H.get("no_fault") or [])],
        ["Обладнання з відмовами без жодного ТО", len(H.get("no_ppr") or [])]]))
    L.append("")
    if H.get("no_users"):
        L.append("**Задачі без виконавця** (до 50)")
        L.append("")
        L.append(_table(["Номер", "Обладнання", "Лінія", "Вид", "Робота", "Строк", "Днів прострочки"],
                        [[r["number"] or r["id"], r["device"], r["line"], _type(r["type"]), r["subject"],
                          _d(r["due"]), r.get("overdue_days", "—")] for r in H["no_users"][:50]]))
        L.append("")
    if H.get("no_ppr"):
        L.append("**Обладнання з відмовами без жодного ТО в графіку**")
        L.append("")
        L.append(_table(["Обладнання", "Лінія", "Відмов"],
                        [[r["device"], r["line"], r["failures"]] for r in H["no_ppr"]]))
        L.append("")
    # ── 6 ──
    L.append("## 6. Люди")
    L.append("")
    pe = R.get("people") or []
    if pe:
        L.append(_table(["Виконавець", "Задач", "Аварійних", "Прострочених", "Виконано із запізненням"],
                        [[r["name"], r["tasks"], r["failures"], r["overdue"], r["late"]] for r in pe]))
    else:
        L.append("У задачах не вказано жодного виконавця.")
    L.append("")
    # ── Якість ──
    L.append("## Якість даних")
    L.append("")
    q = R.get("quality") or {}
    if q:
        L.append(_table(["Що знайдено в даних", "Кількість"],
                        [[QUALITY_WORDS.get(k, k), v] for k, v in sorted(q.items())]))
    else:
        L.append("Неповних чи суперечливих записів не знайдено.")
    L.append("")
    L.append("## Як рахувалось")
    L.append("")
    L.append("- Усі числа пораховано кодом платформи з даних Alldevice, без моделі ШІ; повторний "
             "прогін на тих самих даних дає ті самі числа.")
    L.append("- Відмова — аварійна (позапланова) задача. Простій лічиться окремо, годинами: одна "
             "поломка часто має і задачу, і простій, і двічі як відмову її не рахуємо.")
    L.append("- Плановий простій (за категорією простою) — не відмова і не втрата випуску.")
    L.append("- Роботи за графіком — планові й регламентні задачі зі строком до дати звіту; «вчасно» — "
             "виконано не пізніше строку.")
    L.append("- Платформа лише читає Alldevice: нічого в ньому не створює, не змінює і не видаляє.")
    return "\n".join(L).rstrip() + "\n"


def _type(t) -> str:
    try:
        import repairs_events as RE
        return RE.TYPE_NAMES.get(t, t)
    except Exception:
        return _s(t)


# ── РОБОТА ПЛАТФОРМИ ─────────────────────────────────────────────────────────
def ready():
    """Чи готові власні дані: робота ввімкнена і Alldevice підключено."""
    try:
        import alldevice
    except Exception as e:
        return (False, "конектор Alldevice не читається (%s)" % type(e).__name__)
    if not alldevice.enabled():
        return (False, "модуль «Аналітика ремонтів» не ввімкнено")
    if not alldevice.configured():
        return (False, "Alldevice не підключено — адміністратор вписує адресу, користувача, "
                       "пароль і ключ API в «Налаштування → Alldevice»")
    return (True, "Alldevice підключено (лише перегляд)")


def _parse_day(v, what):
    t = _s(v)
    for fmt in ("%d.%m.%Y", "%Y-%m-%d"):
        try:
            return _dt.datetime.strptime(t, fmt).date()
        except ValueError:
            continue
    raise ValueError("%s «%s» — не дата; потрібно ДД.ММ.РРРР." % (what, t))


def _production_from_store(name):
    """Таблиця випуску з «Файлів» платформи за назвою (найновіший файл із такою назвою)."""
    import file_store
    want = " ".join(_s(name).split()).casefold()
    hits = [f for f in file_store.all_files()
            if " ".join(_s(f.get("name")).split()).casefold() == want and f.get("present")]
    if not hits:
        raise ValueError("Файла випуску «%s» немає у «Файлах» платформи — покладіть його туди "
                         "або назвіть точно." % _s(name))
    hits.sort(key=lambda f: _s(f.get("at")), reverse=True)
    path = file_store.path_of(hits[0]["id"])
    low = str(path).lower()
    if low.endswith(".csv"):
        import csv
        raw = path.read_bytes()
        txt = raw.decode("utf-8-sig", errors="replace")
        dialect = csv.Sniffer().sniff(txt[:4096], delimiters=";,\t") if txt.strip() else csv.excel
        table = [r for r in csv.reader(txt.splitlines(), dialect)]
    elif low.endswith(".xlsx"):
        import openpyxl
        wb = openpyxl.load_workbook(str(path), data_only=True, read_only=True)
        table = [list(r) for r in wb.worksheets[0].iter_rows(values_only=True)]
        table = [r for r in table if any(c not in (None, "") for c in r)]
    else:
        raise ValueError("Файл випуску «%s»: потрібна таблиця .xlsx або .csv." % _s(name))
    import repairs_events as RE
    return RE.production(table), hits[0].get("name")


def _snapshot(raw: dict, ds, de) -> None:
    SNAP_DIR.mkdir(parents=True, exist_ok=True)
    stamp = _dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    p = SNAP_DIR / ("alldevice_%s_%s_%s.json" % (ds.isoformat(), de.isoformat(), stamp))
    p.write_text(json.dumps(raw, ensure_ascii=False), encoding="utf-8")
    old = sorted(SNAP_DIR.glob("alldevice_*.json"))
    for f in old[:-SNAP_KEEP]:
        try:
            f.unlink()
        except Exception:
            pass


def repairs_job(date_from="", date_to="", production_file="", **_ignored) -> dict:
    """Робота платформи «Аналітика ремонтів» → {"status", "summary": звіт markdown}."""
    ok, why = ready()
    if not ok:
        return {"status": "failed", "summary": "Аналітику ремонтів не запущено: %s." % why}
    try:
        de = _parse_day(date_to, "Кінець періоду") if _s(date_to) else _dt.date.today()
        ds = (_parse_day(date_from, "Початок періоду") if _s(date_from)
              else de - _dt.timedelta(days=DEFAULT_DAYS))
    except ValueError as e:
        return {"status": "failed", "summary": str(e)}
    if ds > de:
        return {"status": "failed", "summary": "Початок періоду (%s) пізніше кінця (%s)." % (
            _d(ds), _d(de))}
    prod, pname = None, ""
    if _s(production_file):
        try:
            prod, pname = _production_from_store(production_file)
        except ValueError as e:
            return {"status": "failed", "summary": str(e)}
    import alldevice
    import repairs_analytics as RA
    import repairs_events as RE
    try:
        raw = RE.pull(ds.isoformat(), de.isoformat())
    except alldevice.AlldeviceError as e:
        return {"status": "failed", "summary": "Дані з Alldevice не прочитано: %s" % e}
    _snapshot(raw, ds, de)
    norm = RE.normalize(raw)
    R = RA.analyze(norm, production=prod, as_of=de)
    return {"status": "completed",
            "summary": render(R, source="Alldevice (лише перегляд)", production_name=pname)}
