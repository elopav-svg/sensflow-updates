# -*- coding: utf-8 -*-
"""party_merge.py — ⭐⭐⭐ ЗЛИТТЯ КАРТКИ-ДУБЛЯ В ОСНОВНУ (зміна 779, 12.10.2026).

🩸 ЩО БУЛО. 12.10.2026 у CRM Андрія зʼявились три пари дублів: Одинцов p0047 → p0031 (у дублі — ERP і договір),
Каспер p0038 → p0020 (у дублі — історія оновлень сервіс-центру й картка ліцензії), ОТУ p0045 → p0039. Злити було
нічим: видалення (777) чесно відмовляє на угодах і документах, а переносити руками — двадцять дверей.

⛒ КЛАС: посилання на контрагента живе в СЕМИ сховищах (карта 779): картка довідника; реєстр звʼязків (угоди,
люди, відповідальний, задачі); документи клієнта; черга «Рознести»; картки ліцензій сервіс-центру; закріплення
стрічки; власні поля. Журнали (протокол, події задач) лише дописуються — їх не переписуємо: дубль лишається в архіві
з позначкою «злито в», і стрічки читають його минуле через неї (`parties.lineage` / `parties.resolve`).

⛒ ПЕРЕЛІК І ЗЛИТТЯ — ОДИН КОД. Кожне сховище має свого писаря з `dry=True`: перелік «що переїде» — це те саме
злиття, яке нічого не записало. Двох описів однієї дії, що розійдуться завтра, немає.

⛒ ПОРЯДОК: спершу відмови (сухий хід картки), далі сховища, і лише останнім — картка (`parties.absorb`), яка
ставить «злито в». Світло зникло посередині — повторний запуск доводить злиття до кінця: переведене вже не
знайдеться, а картка ще не позначена.

⛒ Злиття не має кнопки «скасувати»: розлити назад означало б угадувати, що чиє. Усе, що зроблено, лежить у журналі
рядок за рядком — і перелік перед злиттям каже це вголос.
"""
import crm
import card_values
import deal_documents
import deal_mail
import entity
import links
import one_writer
import parties
import pins


def _s(v) -> str:
    return "" if v is None else str(v).strip()


def _walk(dup: str, main: str, dry: bool, kitchen: bool = True, by: str = "") -> dict:
    """Один хід по всіх сховищах. `dry=True` — лише перелік."""
    dup, main = _s(dup), _s(main)
    parties.absorb(dup, main, dry=True)              # відмови словами — до будь-якого запису
    ra, rb = entity.ref(entity.KIND_PARTY, dup), entity.ref(entity.KIND_PARTY, main)
    moves, drops, stays = [], [], []

    lk = links.repoint(ra, rb, by=by, dry=dry)
    moves += lk["moved"]
    drops += lk["dropped"]
    moves += deal_documents.repoint_party(dup, main, dry=dry)
    moves += deal_mail.repoint_party(dup, main, dry=dry)
    cards = crm.repoint_party(dup, main, dry=dry)
    if kitchen:
        moves += ["картка ліцензії сервіс-центру «%s»" % c for c in cards]
    pn = pins.rekey(ra, rb, dry=dry)
    if pn["moved"]:
        moves.append("закріплених подій: %d" % pn["moved"])
    if pn["dropped"]:
        drops.append("закріплених подій понад межу %d: %d (найстаріші)" % (pins.LIMIT, pn["dropped"]))
    cv = card_values.rekey(ra, rb, dry=dry)
    moves += cv["moved"]
    stays += cv["conflicts"]
    moves += parties.absorb(dup, main, extra=cv["conflicts"], summary=moves[:] + drops[:],
                            by=by, dry=dry)
    return {"moves": moves, "drops": drops, "conflicts": stays}


def plan(dup: str, main: str, kitchen: bool = True) -> dict:
    """Що переїде, що відпаде — словами. Нічого не пише. Відмова — `parties.PartyError`."""
    with one_writer.hold():
        w = _walk(dup, main, dry=True, kitchen=kitchen)
    a, b = parties.get(dup), parties.get(main)
    return {
        "from": {"id": _s(dup), "name": _s(a.get("name"))},
        "to": {"id": _s(main), "name": _s(b.get("name"))},
        "moves": w["moves"],
        "drops": w["drops"],
        "after": ("Картка %s лишиться в архіві з позначкою «злито в %s»: її номер у журналі веде до основної. "
                  "Скасувати злиття кнопкою не можна — кожен крок лежить у журналі." % (_s(dup), _s(main))),
    }


def merge(dup: str, main: str, by: str = "", kitchen: bool = True) -> dict:
    """Злити. Під одним замком писаря: ніхто не допише в дубль посеред злиття."""
    with one_writer.hold():
        w = _walk(dup, main, dry=False, kitchen=kitchen, by=by)
    return {"merged": _s(dup), "into": _s(main), "moves": w["moves"], "drops": w["drops"]}
