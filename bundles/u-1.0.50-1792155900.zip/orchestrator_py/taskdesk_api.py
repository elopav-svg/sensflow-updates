# -*- coding: utf-8 -*-
"""
taskdesk_api.py — ТОНКИЙ ШАР МІЖ КОНСОЛЛЮ І ЯДРОМ TASK DESK (крок 1.4).

`server.py` лишається транспортом: він приймає запит, питає ворота «хто це» і
віддає сюди. Уся логіка дій живе тут, в ОДНІЙ таблиці дій. Так новий екран не
може винайти собі власний шлях повз перевірки — таблиця одна.

ТРИ ПЕРЕВІРКИ, ЯКІ ПРОХОДИТЬ КОЖНА ДІЯ:
  1. **вимикач роботи** — поки Task Desk не ввімкнений, тут не працює нічого;
  2. **адміністратор** — оргструктуру й доступи веде лише він;
  3. **дія з таблиці** — невідома назва дії не виконується, а називається.
Відмова завжди має причину словами: тиха відмова = вимкнені ворота.
"""

import features
import clock                       # ОДИН ПИСАР ЧАСУ на весь продукт
import entity                      # спільне ІМʼЯ людини й речі
import protocol                    # спільний ЖУРНАЛ усіх дій
import taskdesk_identity as identity
import taskdesk_projects as tprj      # ⭐ 705: суддя проєктів Task Desk
import second_factor               # ⭐ 666: двофакторний вхід
import access_letter               # ⭐ 696: лист доступу працівнику
import password_link               # ⭐ 696: разове посилання «встановити свій пароль»
import taskdesk_intake as intake   # розбір одного рядка: хто · коли · що
import taskdesk_links as tlinks    # словник і формулювання звʼязків (зміна 172)
import taskdesk_mirror as mirror   # ОДИН читач журналу подій (зміна 379)
import taskdesk_ai as ai
import taskdesk_comment as comment_door   # ОДИН писар коментаря (650)
import taskdesk_export as export
import taskdesk_fields as fields
import taskdesk_people as people
import taskdesk_worktypes as worktypes
import taskdesk_templates as tpls       # ⭐ 707: шаблони пояснень і запитів
import taskdesk_prefs as prefs
import taskdesk_roles as roles
import taskdesk_org_chart as org_chart
import taskdesk_tasks as tasks
import taskdesk_telegram as mouth

WORK_ID = "taskdesk"


class ApiError(Exception):
    def __init__(self, message, status=400, code="taskdesk_error"):
        Exception.__init__(self, message)
        self.status = status
        self.code = code


def enabled() -> bool:
    """ЄДИНА відповідь «чи Task Desk увімкнений». Поки робота не завершена, вона
    їде клієнту вимкненою — це вимога воріт складу релізу."""
    return features.enabled(WORK_ID)


def _require_enabled():
    if not enabled():
        raise ApiError("Task Desk у цій збірці вимкнений.", 403, "taskdesk_off")


def _require_admin(actor):
    """Оргструктуру й доступи веде адміністратор.

    Поки вхід не вимагається (одноосібний клієнт, як Каспер сьогодні), господар
    машини і є адміністратор — так само, як у решті консолі. Щойно людей стає
    двоє, вхід обовʼязковий, і тут уже потрібен саме адміністратор."""
    if not identity.login_required():
        return
    if not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    if not actor.get("is_admin"):
        raise ApiError("Ці налаштування веде адміністратор.", 403, "admin_only")


# ---------------------------------------------------------------------------
# ЧИТАННЯ
# ---------------------------------------------------------------------------
def people_state(actor) -> dict:
    """⭐ РІШЕННЯ АНДРІЯ 08.08.2026: розділ «Люди» — це ДОВІДНИК компанії, а не
    панель адміністратора. Колега має знайти телефон колеги, не питаючи нікого.

    Тому дивляться ВСІ, а от ВЕДЕ структуру адміністратор. Різниця не в тому,
    що показати, а в тому, що можна: інструменти й службовий журнал змін їдуть
    лише адміністратору. Екран їх не ховає «про всяк випадок» — він їх просто
    не отримує, і намалювати кнопку, якої немає, не може."""
    _require_enabled()
    # ⭐ «Відкрито всім працівникам» не означає «відкрито нікому»: коли вхід
    # обовʼязковий, довідник компанії бачить лише впізнана людина.
    if identity.login_required() and not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    adm = _is_admin(actor)
    st = people.load()
    # ⛒ Підрозділи їдуть УСІ — так само, як і працівники разом зі звільненими.
    # Ховає ліквідованих сам екран, за тією ж галочкою; а списки ВИБОРУ беруть
    # `people.units()`, який ліквідованих не віддає.
    out = {"units": st["units"], "positions": st["positions"],
           "employees": st["employees"],
           # ⭐ Горизонти бачать УСІ (це видимий орієнтир структури), а веде їх
           # адміністратор — як і всю оргструктуру на цьому екрані.
           "horizons": st["horizons"], "horizon_numbers": list(people.HORIZON_NUMBERS),
           "unreadable_reason": st.get("unreadable_reason", ""),
           # ⭐ Один писар «хто я тут» — екран не здогадується за виглядом даних.
           "rights": {"is_admin": adm, "me": _me(actor),
                      "may_manage": adm,
                      # ⭐ Ліквідація — рішення власника, а не адміністратора.
                      # Один писар цієї відповіді: екран не здогадується сам.
                      "may_liquidate": _may_liquidate(actor),
                      # ⛒ Кнопка в нікуди гірша за її відсутність: екран питає,
                      # а не вгадує, чи відкриється історія цій людині.
                      "may_see_history": _may_see_history(actor),
                      # ⛒ Те саме питання про дзеркало — і та сама відповідь,
                      # що й у воротах дії: другої тут не заводимо.
                      "may_see_mirror": _may_see_mirror(actor)}}
    if adm:
        out["audit"] = st["audit"][-30:]
    return out


def _may_liquidate(actor) -> bool:
    """Чи МОЖНА цій людині ліквідувати підрозділ — та сама умова, що й у
    воротах дії. Друга відповідь у другому місці розійшлася б із першою."""
    try:
        _require_top_manager(actor)
        return True
    except ApiError:
        return False


# ── ІСТОРІЯ ЗМІН КОМПАНІЇ (зміна 364, 30.08.2026) ───────────────────────────
# ⭐ ТРИ ЧЕСНІ ВІДПОВІДІ НА «ХТО ЦЕ ЗРОБИВ», І ЖОДНОЇ ЗАЙВОЇ (зміна 375).
# Четвертого («господар платформи») тут був: живий прогін показав, що продукт
# його не народжує — ворота консолі завжди називають того, хто діє, а в
# одноосібному режимі це ВЛАСНИК, і в рядку стоїть саме його імʼя.
WHO_UNKNOWN = "unknown"          # старий запис: автора тоді не вели
WHO_SYSTEM = "system"            # зроблено НЕ через екран: обслуговування, автоматика
WHO_PERSON = "person"            # названа людина (у одноосібному режимі — Власник)

WHO_WORDS = {
    WHO_UNKNOWN: "невідомо — запис зроблено до того, як платформа почала "
                 "запамʼятовувати автора",
    WHO_SYSTEM: "сама платформа, не через екран",
}

HISTORY_PAGE = 100               # скільки рядків віддаємо за раз
HISTORY_PAGE_MAX = 500


def _may_see_history(actor) -> bool:
    """Чи МОЖНА цій людині дивитись історію компанії. Одна відповідь на це
    питання — саме тут; екран її лише питає."""
    if _is_admin(actor):
        return True
    return _may_liquidate(actor)


def _require_history_reader(actor):
    if _may_see_history(actor):
        return
    if identity.login_required() and not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    raise ApiError("Історію змін компанії дивляться старший керівник і "
                   "адміністратор.", 403, "not_allowed")


def _who_of(row: dict) -> tuple:
    """(вид автора, підпис) для рядка протоколу. ОДИН писар цієї відповіді."""
    who = str(row.get("actor") or "").strip()
    if who:
        # ⛒ Імʼя дістаємо в `entity` — єдиного писаря людських назв. Другий
        # словник імен розійшовся б із першим уже наступного місяця.
        try:
            return WHO_PERSON, (entity.title(who) or who)
        except Exception:
            return WHO_PERSON, who
    # Імені немає — і вигадувати його не можна. Через екран зміна без автора
    # не проходить: ворота консолі завжди кажуть, хто діє. Отже, це зміна
    # ПОЗА екраном, і саме так ми її й називаємо.
    return WHO_SYSTEM, WHO_WORDS[WHO_SYSTEM]


def _history_rows() -> list:
    """УСЯ історія компанії, свіжіше — зверху. Два джерела, дві ЕПОХИ, а не два
    писарі: старий список заморожений і більше не росте (зміна 361)."""
    out = []
    seq = 0
    for r in protocol.read():
        if str(r.get("action") or "") not in protocol.ORG_ACTIONS:
            continue
        seq += 1
        kind, words = _who_of(r)
        subj = str(r.get("subject") or "")
        try:
            about_what = entity.human(subj) if subj else ""
        except Exception:
            about_what = subj
        out.append({
            "seq": seq,
            "at": str(r.get("at") or ""),
            "what": str(r.get("note") or "")
                    or protocol.ACTIONS.get(str(r.get("action")), ""),
            "action": str(r.get("action") or ""),
            "action_name": protocol.ACTIONS.get(str(r.get("action")), ""),
            "about": about_what,
            "who_kind": kind, "who": words,
        })
    for a in people.legacy_audit():
        out.append({
            # ⛒ Старий, заморожений слід порядку запису не має і вже не матиме.
            # Він увесь із давнішої епохи, тому нуль тут нічого не переставляє.
            "seq": 0,
            "at": str(a.get("at") or ""), "what": str(a.get("what") or ""),
            "action": "", "action_name": "", "about": "",
            "who_kind": WHO_UNKNOWN, "who": WHO_WORDS[WHO_UNKNOWN],
        })
    # ⭐ ДРУГИЙ КЛЮЧ — ПОРЯДОК ЗАПИСУ. Час у продукті з точністю до секунди, а
    # людина за секунду встигає зробити кілька змін поспіль. Без другого ключа
    # такі рядки лягали б у зворотному порядку до всього іншого списку.
    out.sort(key=lambda r: (r["at"], r["seq"]), reverse=True)
    for r in out:
        r.pop("seq", None)
    return out


def history_state(actor, query: str = "", since: str = "", until: str = "",
                  limit: int = HISTORY_PAGE, offset: int = 0) -> dict:
    """ЩО БАЧИТЬ ЛЮДИНА НА ЕКРАНІ ІСТОРІЇ ЗМІН КОМПАНІЇ.

    ⚠ ЧЕСНА МЕЖА: журнал читається цілком на кожен запит. За три тижні роботи
    платформи він важить 150 КБ — тобто років на десять запасу; коли впреться,
    лікуватимемо читанням із кінця, а не стелею на записи."""
    _require_enabled()
    _require_history_reader(actor)
    rows = _history_rows()
    total_all = len(rows)
    q = str(query or "").strip().lower()
    d1, d2 = str(since or "").strip()[:10], str(until or "").strip()[:10]
    if d1:
        rows = [r for r in rows if r["at"][:10] >= d1]
    if d2:
        rows = [r for r in rows if r["at"][:10] <= d2]
    if q:
        rows = [r for r in rows
                if q in r["what"].lower() or q in r["who"].lower()
                or q in r["about"].lower()]
    try:
        lim = max(1, min(int(limit or HISTORY_PAGE), HISTORY_PAGE_MAX))
    except Exception:
        lim = HISTORY_PAGE
    try:
        off = max(0, int(offset or 0))
    except Exception:
        off = 0
    return {"rows": rows[off:off + lim], "found": len(rows), "total": total_all,
            "offset": off, "limit": lim,
            "query": str(query or ""), "since": d1, "until": d2,
            "rights": {"may_see": True, "is_admin": _is_admin(actor)}}


# ── ДЗЕРКАЛО КЕРІВНИКА (зміна 388, 30.08.2026) ──────────────────────────────
# ⚖ Слово Андрія 30.08: дзеркало — ОКРЕМА ПЛАТНА позиція, показники — як у
# розділі 5 записки. Числа рахує ОДИН читач `taskdesk_mirror`; тут — лише
# питання «кому це видно».
MIRROR_DAYS = (7, 30, 90)


def _may_see_mirror(actor) -> bool:
    """Чи МОЖНА цій людині дивитись дзеркало. Одна відповідь — саме тут.

    ⛒ Рахуємо з ДЕРЕВА: дзеркало показує роботу підлеглих, отже дивиться той,
    у кого підлеглі є. Адміністратор бачить компанію."""
    if _is_admin(actor):
        return True
    me = _me(actor)
    if not me:
        return False
    try:
        return bool(people.subordinates_of(me))
    except Exception:
        return False


def _require_mirror_reader(actor):
    if _may_see_mirror(actor):
        return
    if identity.login_required() and not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    raise ApiError("Дзеркало показує роботу підлеглих — його дивляться "
                   "керівники й адміністратор. У вас підлеглих немає.",
                   403, "not_allowed")


def mirror_state(actor, days=0, date_from="", date_to="") -> dict:
    """ЩО БАЧИТЬ КЕРІВНИК У ДЗЕРКАЛІ.

    ⚠ Тут навмисно НЕМАЄ знеособлення: воно живе в читачі, і назовні їде інший
    зріз. Цей екран лишається ВДОМА, дані з нього нікуди не йдуть."""
    _require_enabled()
    _require_mirror_reader(actor)
    try:
        d = int(days or 0)
    except Exception:
        d = 0
    if d not in MIRROR_DAYS:
        d = MIRROR_DAYS[1]
    # ⭐ 677: довільний період «від–до» — той самий читач; хибний період —
    # відмова 400 словами людині, а не збій дверей.
    try:
        out = mirror.named(_me(actor), _is_admin(actor), d,
                           date_from=str(date_from or ""), date_to=str(date_to or ""))
    except mirror.MirrorError as e:
        raise ApiError(str(e), 400, "bad_period")
    out["days_options"] = list(MIRROR_DAYS)
    out["rights"] = {"may_see": True, "is_admin": _is_admin(actor)}
    return out


def _fold_list(raw) -> list:
    """Перелік гілок з адреси: «e1,e2,e3». Чужого сюди не проходить — усе, чого
    немає серед працівників, малювальник далі й сам відкине, але межу довжини
    ставимо тут: адреса не сміє бути важелем навантаження на сервер."""
    if not raw:
        return []
    parts = [p.strip() for p in str(raw).replace(" ", ",").split(",")]
    return [p for p in parts if p][:_FOLD_MAX]


_FOLD_MAX = 400   # стільки гілок людина фізично не натисне; далі — не наш клієнт


def structure_state(actor, fold=None, open_=None) -> dict:
    """ЩО БАЧИТЬ ЛЮДИНА НА ЕКРАНІ СТРУКТУРИ КОМПАНІЇ.

    ⚖ Рішення Андрія 30.08.2026: дивляться УСІ працівники — кожен має бачити,
    до кого йти з питанням і хто з ним нарівні. Веде структуру адміністратор,
    і саме тому екран каже, КУДИ йти по зміни, а не малює кнопок, яких у
    людини немає.

    ⛒ Розкладку рахує малювальник на сервері; екран лише малює."""
    _require_enabled()
    if identity.login_required() and not actor:
        raise ApiError("Увійдіть під своїм працівником.", 401, "login_required")
    st = people.load()
    return {"chart": org_chart.layout(fold=_fold_list(fold),
                                      open_=_fold_list(open_)),
            # Легенда горизонтів: номер і колір, більше в горизонта нічого
            # немає — назв у них немає свідомо.
            "horizons": st["horizons"],
            "unreadable_reason": st.get("unreadable_reason", ""),
            "rights": {"is_admin": _is_admin(actor), "may_manage": _is_admin(actor)}}


def employee_card(actor, emp_id: str) -> dict:
    """Картку ЧИТАЄ кожен працівник — це довідник компанії (рішення Андрія
    08.08.2026). А от ПРАВИТИ можна лише те, що дозволяє `people.card_rights()`:
    свої контакти — сама людина, місце в компанії — адміністратор."""
    _require_enabled()
    adm = _is_admin(actor)
    me = _me(actor)
    emp_id = str(emp_id or "").strip()
    card = people.card(emp_id)
    if not card:
        raise ApiError("Такого працівника немає.", 404, "not_found")
    # ⭐ Права їдуть РАЗОМ із карткою: екран малює лише те, що людині належить.
    # Кнопка, яка відмовить, бреше не менше за її відсутність.
    card["rights"] = people.card_rights(me, emp_id, adm)
    # ⭐ СТАН КАНАЛУ ЇДЕ РАЗОМ ІЗ КАРТКОЮ, як і права: екран не здогадується,
    # підключений телеграм чи ні, і не малює кнопку, за якою нічого немає.
    card["telegram"] = _telegram_state(emp_id)
    # ⭐ 667: так само — стан другого фактора (лише своя картка або адміністратор).
    card["second_factor"] = _second_factor_card(actor, emp_id, adm)
    # ⭐ Список людей для вибору делегата їде лише тому, хто справді може
    # заводити відсутність. Порожній вибір під забороненою дією — та сама
    # кнопка, що відмовить.
    if card["rights"].get("absence"):
        card["people"] = [{"id": e["id"], "name": e.get("full_name") or e["id"]}
                          for e in people.employees() if e["id"] != emp_id]
    if adm:
        card["units"] = [{"id": u["id"], "name": u.get("name") or u["id"]}
                         for u in people.units()]
        card["positions"] = [{"id": p["id"], "name": p.get("name") or p["id"]}
                             for p in people.positions()]
        # Вибрати можна лише ЗАВЕДЕНИЙ горизонт: список порожній, поки жодному
        # номеру не дали кольору — і кнопки, за якою нічого немає, не буде.
        card["horizons"] = [dict(h) for h in people.load()["horizons"]]
    return card


def _second_factor_card(actor, emp_id: str, adm: bool):
    """⭐⭐⭐ 667. ДВОФАКТОРНИЙ ВХІД НА КАРТЦІ.

    Своя картка (жива сесія цього ж запису) — людина веде свій другий фактор
    сама; адміністратор на чужій — бачить стан і може скинути. Колега на чужій
    картці не бачить нічого: чи захищений чужий вхід — не довідкова інформація.
    ⛒ Лише «так/ні», дата і скільки резервних лишилось: ні ключа, ні хешів."""
    acc = identity.account_of_employee(str(emp_id or "").strip())
    mine = bool(actor and actor.get("id") and acc and actor.get("id") == acc["id"])
    if not (mine or adm):
        return None
    if acc is None:
        return {"has_account": False, "mine": False, "admin": bool(adm)}
    try:
        st = second_factor.status(acc)
    except second_factor.SecondFactorError as e:
        st = {"enrolled": False, "error": str(e)}
    return dict(st, has_account=True, mine=mine, admin=bool(adm),
                account_id=acc["id"], login=acc["login"])


def _acc_of(emp_id: str) -> dict:
    """Обліковий запис працівника. Немає запису — немає й каналу: бот упізнає
    людину лише через вхід у платформу."""
    acc = identity.account_of_employee(str(emp_id or "").strip())
    if acc is None:
        raise ApiError("У цього працівника немає облікового запису, тож "
                       "підключати телеграм нема до чого. Це заводить адміністратор "
                       "у розділі «Доступи».", 400, "no_account")
    return acc


def _telegram_state(emp_id: str) -> dict:
    """Чи є в людини канал і чи взагалі є куди підключатись.

    ⭐ `available` — це чесність екрана: якщо в клієнта не заведений бот задач
    (закритий контур або просто ще не завели), кнопки не буде взагалі, а не
    буде кнопки, яка відмовить."""
    import taskdesk_telegram as mouth
    out = {"available": mouth.enabled(), "bot": mouth.bot_username(),
           "linked": False, "code": "", "expires_at": "", "has_account": False}
    acc = identity.account_of_employee(str(emp_id or "").strip())
    if acc is None:
        return out
    out["has_account"] = True
    out.update(identity.telegram_state(acc["id"]))
    return out


def roles_state(actor) -> dict:
    """ЩО БАЧИТЬ АДМІНІСТРАТОР НА ЕКРАНІ ПРАВ.

    ⛒ «Яка роль у людини НАСПРАВДІ» рахує сервер (`role_of`), а не сторінка:
    правило «особисте → підрозділ деревом угору → за замовчуванням» мусить мати
    одного писаря, інакше екран через місяць показуватиме своє."""
    _require_enabled()
    _require_admin(actor)
    m = roles.matrix()
    m["units"] = [{"id": u["id"], "name": u.get("name", ""),
                   "parent_id": u.get("parent_id", "")} for u in people.units()]
    m["employees"] = [{"id": e["id"], "name": e.get("full_name", ""),
                       "unit_id": e.get("unit_id", "")} for e in people.employees()]
    m["effective"] = {e["id"]: (roles.role_of(e["id"]) or {}).get("id", "")
                      for e in people.employees()}
    return m


def worktypes_state(actor) -> dict:
    """ЩО БАЧИТЬ АДМІНІСТРАТОР НА ЕКРАНІ ТИПІВ РОБОТИ.

    ⛒ Побитий файл довідника не ховається: причина їде на екран словами, бо
    інакше людина побачить порожній список і вирішить, що її роботу стерли."""
    _require_enabled()
    _require_admin(actor)
    st = worktypes.load()
    return {"types": st["types"],
            "unreadable_reason": st.get("unreadable_reason", ""),
            "advised_points": worktypes.ADVISED_POINTS}


def accounts_state(actor) -> dict:
    _require_enabled()
    _require_admin(actor)
    import registry
    try:
        systems = [{"id": s.get("id"), "name": s.get("name") or s.get("id")}
                   for s in (registry.load_systems() or [])]
    except Exception:
        systems = []
    return {"accounts": identity.accounts(),
            "employees": people.employees(),
            "systems": systems,
            "login_required": identity.login_required(),
            "light_mode": identity.light_mode(),
            "second_factor": _second_factor_overview(),
            "letter": _letter_overview(),
            "no_access": _no_access()}


def _letter_overview() -> dict:
    """⭐ 696: картка «Лист доступу» і стан листа кожного запису. Без токенів."""
    try:
        return access_letter.overview()
    except Exception as e:                            # noqa: BLE001
        return {"error": "стан листів доступу не читається: %s" % type(e).__name__}


def password_link_door(data: dict) -> dict:
    """⭐⭐⭐ 696: ДВЕРІ РАЗОВОГО ПОСИЛАННЯ — БЕЗ СЕСІЇ. Пускає лише дійсний токен;
    сесії не відкривають: увійде людина сама, своїм новим паролем."""
    _require_enabled()
    do = str((data or {}).get("do") or "").strip()
    token = str((data or {}).get("token") or "")
    try:
        if do == "check":
            return password_link.check(token)
        if do == "set":
            return password_link.use(token, str((data or {}).get("password") or ""))
    except password_link.LinkError as e:
        raise ApiError(str(e), 400, "link_refused")
    raise ApiError("Невідома дія «%s». Відомі: check, set" % do, 400, "unknown_action")


def _second_factor_overview() -> dict:
    """⭐ 666: для консолі доступів — вимога і хто підключив. Жодної таємниці:
    лише «так/ні», дата і скільки резервних кодів лишилось."""
    try:
        per = {a["id"]: second_factor.status(a) for a in identity.accounts()}
        return {"policy": second_factor.policy(), "accounts": per,
                "roles": [{"id": r["id"], "name": r.get("name") or r["id"]}
                          for r in roles.roles()],
                "error": ""}
    except second_factor.SecondFactorError as e:
        return {"policy": {}, "accounts": {}, "roles": [], "error": str(e)}


# ---------------------------------------------------------------------------
# ⭐⭐⭐ 666: СВІЙ ДРУГИЙ ФАКТОР — ВЕДЕ САМА ЛЮДИНА, НЕ АДМІНІСТРАТОР.
# ⛒ Лише з живою сесією: у одноосібному режимі входу за паролем немає, і
# «другий» фактор без першого — порожній звук. Господаря машини тут не
# підставляємо (`resolve_actor`) свідомо.
# ---------------------------------------------------------------------------
def _session_actor(actor):
    _require_enabled()
    if not actor or not actor.get("id"):
        raise ApiError("Двофакторний вхід підключається під своїм обліковим записом "
                       "— увійдіть за паролем.", 401, "login_required")
    return actor


def second_factor_state(actor) -> dict:
    acc = _session_actor(actor)
    try:
        return second_factor.status(acc)
    except second_factor.SecondFactorError as e:
        raise ApiError(str(e), 503, "second_factor_unreadable")


def run_second_factor(actor, data: dict) -> dict:
    acc = _session_actor(actor)
    do = str((data or {}).get("do") or "").strip()
    code = str((data or {}).get("code") or "")
    doors = {"begin": lambda: second_factor.begin_enroll(acc),
             "confirm": lambda: second_factor.confirm_enroll(acc, code),
             "regen": lambda: second_factor.regen_backup(acc, code),
             "disable": lambda: second_factor.disable(acc, code)}
    if do not in doors:
        raise ApiError("Невідома дія «%s». Відомі: %s" % (do, ", ".join(sorted(doors))),
                       400, "unknown_action")
    with protocol.step(actor=entity.person_of_actor(acc), source="ui"):
        try:
            out = doors[do]()
        except second_factor.SecondFactorError as e:
            raise ApiError(str(e), 400, "refused")
    out = dict(out or {})
    out["status"] = second_factor.status(acc)
    return out


def photo_set(actor, emp_id: str, data_url: str) -> dict:
    """Фото приходить із браузера рядком «data:image/png;base64,...».
    Розбираємо його ТУТ, а ядро отримує вже байти — воно не мусить знати про веб."""
    _require_enabled()
    rights = people.card_rights(_me(actor), emp_id, _is_admin(actor))
    if not rights["photo"]:
        raise ApiError("Фото ставить сама людина або адміністратор.", 403, "not_allowed")
    raw_b64 = str(data_url or "")
    if "," in raw_b64:
        raw_b64 = raw_b64.split(",", 1)[1]
    import base64
    try:
        raw = base64.b64decode(raw_b64, validate=True)
    except Exception:
        raise ApiError("Файл не прочитався — спробуйте інший.", 400, "bad_photo")
    try:
        return {"ok": True, "result": people.set_photo(emp_id, raw)}
    except people.PeopleError as e:
        raise ApiError(str(e), 400, "refused")


def photo_get(actor, emp_id: str) -> tuple:
    _require_enabled()
    _require_admin(actor)
    raw, mime = people.photo_bytes(emp_id)
    if not raw:
        raise ApiError("Фото немає.", 404, "no_photo")
    return raw, mime


# ---------------------------------------------------------------------------
# ЗАДАЧІ. Тут інші ворота, ніж в оргструктурі: задачі веде НЕ адміністратор,
# а сам працівник. Тому питаємо не «чи ти адмін», а «хто ти» — і далі все
# вирішує ОДНА функція видимості з `taskdesk_tasks`.
# ---------------------------------------------------------------------------
def _is_admin(actor) -> bool:
    """⭐ ОДНА відповідь «чи ця людина адміністратор» — та сама умова, що й у
    `_require_admin`: поки вхід не вимагається, господар машини і є адміністратор.
    Друга відповідь у другому місці розійшлася б із першою."""
    return identity.is_admin(actor)


def _me(actor) -> str:
    """Хто дивиться. ОДНА відповідь; порожньо — коли людина не впізнана."""
    return str((actor or {}).get("employee_id") or "").strip()


def _require_actor(actor):
    """ХТО ДІЄ — і якщо ніхто, то СКАЗАТИ, ЩО РОБИТИ, а не просто «ні».

    ⭐⭐⭐ 24.08.2026. Тут був глухий кут для щойно відкритого клієнта: у
    порожній платформі актор — ВЛАСНИК без картки працівника, і екран задач
    казав йому «Увійдіть під своїм працівником». Увійти нема під ким: людей ще
    не заводили. «Порожньо» і «не впізнано» — РІЗНІ стани, і плутати їх
    означає посилати людину не туди.
    """
    if not actor:
        raise ApiError("Не видно, хто ви. Увійдіть під своїм працівником.",
                       401, "login_required")
    emp = str(actor.get("employee_id") or "").strip()
    if not emp:
        st = people.setup_state("")
        raise ApiError(st["hint"], 409, st["code"])
    return emp


SCOPE_NAMES = {"all": "усі видимі", "mine": "мої", "i_set": "я поставив",
               "overdue": "протерміновані"}


NO_PROJECT = "__none__"          # ⭐ 705: плитка «Без проєкту» (4.3 Б)


def _by_project(lst, project: str):
    """⭐ 705: дошка проєкту. Лише ЗВУЖУЄ — і стоїть усередині тих самих воріт
    `narrow`, що й фільтр: додати задачу, якої людина не бачить, не може."""
    project = str(project or "").strip()
    if not project:
        return lst
    if project == NO_PROJECT:
        return [t for t in lst if not str(t.get("project_id") or "").strip()]
    return [t for t in lst if str(t.get("project_id") or "").strip() == project]


def _desk(actor, scope, show_closed, flt=None, use_saved=True, query="",
          show_archive=False, project=""):
    """ОДИН збирач того, що людина бачить на екрані задач. І список, і дошка, і
    вивантаження виходять ЗВІДСИ — тому файл не може розійтися з екраном."""
    me = _require_actor(actor)
    my = prefs.load(me)
    flt = my["filter"] if (flt is None and use_saved) else (flt or {})
    ctx = fields.context()
    try:
        # ⭐⭐⭐ ОДНІ ВОРОТА НА ОБИДВА ЗВУЖЕННЯ: спершу фільтр, потім пошук — і
        # обидва всередині ОДНОГО `narrow`. Тому перевірка `board()` «фільтр не
        # має права додавати задач» накриває й пошук: другого шляху до списку
        # немає фізично, а не за домовленістю.
        # ⭐ 709: дошка ПРОЄКТУ — у колонках його власника; загальна — стадіями, як досі.
        layout = (tprj.board_columns(project)
                  if str(project or "").strip() not in ("", NO_PROJECT) else None)
        # ⭐ 733: варіанти фільтра рахуються з УСЬОГО видимого людині, а не з уже звуженого:
        # після «Мої протерміновані» інших виконавців у фільтрі не лишалось — і скласти
        # «протерміновані кількох виконавців» було неможливо (знайдено живим поглядом).
        pool = []

        def _seen(lst):
            pool[:] = lst
            return lst
        data = tasks.board(me, scope=scope, show_closed=show_closed,
                           show_archive=show_archive, layout=layout,
                           narrow=lambda lst: _by_project(
                               fields.search_narrow(
                                   fields.apply_filter(_seen(lst), flt, ctx), query, ctx),
                               project))
        data["_pool"] = pool
    except fields.FieldError as e:
        raise ApiError(str(e), 400, "bad_filter")
    except tasks.TaskError as e:
        raise ApiError(str(e), 400, "refused")
    flat = [t for c in data["columns"] for t in c["tasks"]]
    # ⭐ НАЗВУ ПРОЄКТУ РАХУЄ ОДИН ПИСАР — той самий, що пише її в картку, у
    # фільтр і у файл. Сторінка не збирає назву сама зі свого переліку: там
    # немає ні видалених проєктів, ні чужих, і дошка мовчала б там, де має
    # сказати «проєкт видалено».
    for _t in flat:
        _t["project_name"] = tasks.project_name(_t.get("project_id") or "")
    # ⭐⭐⭐ ПОРЯДОК РАХУЄТЬСЯ ОДИН РАЗ І НА ВСЕ: список, дошка і xlsx не мають
    # права розійтися. Тому сортувальник кличеться РІВНО ТУТ, а колонки дошки
    # лише переставляються за вже порахованим порядком.
    srt = my.get("sort") or {}
    if srt.get("field"):
        try:
            flat = fields.sort_rows(flat, srt["field"], srt.get("desc"), ctx)
        except fields.FieldError as e:
            raise ApiError(str(e), 400, "bad_sort")
        order = {t["id"]: i for i, t in enumerate(flat)}
        for c in data["columns"]:
            c["tasks"].sort(key=lambda t: order[t["id"]])
    return me, my, ctx, flt, data, flat


def _project_tiles(me: str, work: list) -> list:
    """⭐ 705: плитки проєктів. Лічба — ЛИШЕ з задач, які людина бачить: у
    роботі (не закриті) і протерміновані. «Без проєкту» — якщо такі задачі є.
    ⭐ 706 (3.2): і скільки відкритих задач не пройшли перевірку — та сама позначка
    «не пройшла перевірку: N», що на картці."""
    open_ = tasks.visible_tasks(me, include_closed=False)
    by = {}
    for t in open_:
        k = str(t.get("project_id") or "").strip() or NO_PROJECT
        c = by.setdefault(k, [0, 0, 0])
        c[0] += 1
        c[1] += 1 if t.get("overdue") else 0
        c[2] += 1 if t.get("failed_count") else 0
    out = []
    for r in work:
        c = by.get(r["id"], [0, 0, 0])
        out.append({"id": r["id"], "name": r["name"], "owner_name": r["owner_name"],
                    "status": r["status"], "status_name": r["status_name"],
                    "open_count": c[0], "overdue_count": c[1], "failed_count": c[2]})
    if NO_PROJECT in by:
        c = by[NO_PROJECT]
        out.append({"id": NO_PROJECT, "name": "Без проєкту", "owner_name": "",
                    "status": "", "status_name": "", "open_count": c[0],
                    "overdue_count": c[1], "failed_count": c[2]})
    return out


def _project_board(actor, me: str, project: str) -> dict:
    """⭐ 705: усе про проєкти, що потрібно екрану задач: плитки, вибраний
    проєкт (картка над дошкою), архів і «Попросити доступ». Чужий проєкт на
    дошці — відмова словами, а не порожня дошка."""
    v = tasks._viewer(me, _is_admin(actor))
    lst = tprj.listing(v)
    out = {"project": project, "project_tiles": _project_tiles(me, lst["projects"]),
           "project_archived": [{"id": r["id"], "name": r["name"]}
                                for r in lst["archived"]],
           "project_requestable": lst["requestable"], "project_current": None}
    if project and project != NO_PROJECT:
        rows = {r["id"]: r for r in lst["projects"] + lst["archived"]}
        if project not in rows:
            raise ApiError("Цей проєкт вам не видно. Попросіть доступ у власника.",
                           403, "not_visible")
        cur = dict(rows[project])
        if cur.get("may_manage"):
            cur["statuses"] = [{"id": k, "name": n} for k, n in tprj.STATUS_NAMES.items()]
            # ⭐ 709: до якої стадії може належати нова колонка — лише основні.
            cur["column_stages"] = [{"id": s, "name": tasks.STAGE_NAMES[s]}
                                    for s in tprj.column_stages()]
        out["project_current"] = cur
    return out


def _priorities() -> list:
    """⭐ 734: варіанти пріоритету їдуть зі словника задачі — сторінка своїх слів не має."""
    return [{"id": p, "name": tasks.PRIORITY_NAMES[p]} for p in tasks.PRIORITIES]


def board_state(actor, scope: str = "all", show_closed: bool = False,
                flt=None, query: str = "", fresh: bool = False,
                show_archive: bool = False, project: str = "") -> dict:
    _require_enabled()
    project = str(project or "").strip()
    # ⭐ Набір за замовчуванням ставиться ЛИШЕ на вході на екран (`fresh`),
    # а не на кожен запит: інакше він скидав би фільтр людині під руками
    # щоразу, коли вона щось шукає.
    if fresh:
        try:
            prefs.apply_default(_require_actor(actor))
        except prefs.PrefsError:
            pass
    # ⭐ 705: «Управління» заводиться саме при вході в Task Desk (4.3), і до
    # відбору дошки — щоб його плитка була вже на першому вході.
    tprj.ensure_management(top_manager_id())
    pboard = _project_board(actor, _require_actor(actor), project)
    me, my, ctx, flt, data, flat = _desk(actor, scope, show_closed, flt,
                                        query=query, show_archive=show_archive,
                                        project=project)
    data.update(pboard)
    # Екран каже людині, що архів існує і скільки в ньому лежить.
    data["archive_total"] = tasks.archive_count()
    data["archive_on"] = bool(show_archive)
    cols = my["columns"]
    data["me"] = {"id": me, "name": people.employee(me).get("full_name", "")}
    data["people"] = [{"id": e["id"], "name": e.get("full_name", "")}
                      for e in people.employees()]
    # ⭐ Панель створення теж має вибрати тип роботи — з того самого списку.
    data["worktypes"] = [{"id": w["id"], "name": w["name"]}
                         for w in worktypes.types()]
    data["priorities"] = _priorities()                            # ⭐ 734
    # ⭐ І проєкти — тим самим шляхом. Перелік рівно той, який людині НАЛЕЖИТЬ:
    # право рахує Task Desk по дереву компанії, а не сторінка своїм «якщо».
    data["projects"] = tasks.projects_for(me, _is_admin(actor))
    # ⭐ 705: кнопка «Створити проєкт» і її форма — від того самого судді.
    data["may_create_project"] = may_create_project(actor)
    data["project_owners"] = _project_owners(actor, me)
    # ⭐ Рядки списку рахує РЕЄСТР, а не сторінка: інакше екран став би другим
    # форматувальником і розійшовся б із файлом xlsx.
    data["fields"] = fields.catalogue()
    data["columns_all"] = [f["id"] for f in fields.FIELDS]
    data["columns_used"] = cols
    data["heads"] = [fields.field(c)["label"] for c in cols]
    data["rows"] = [{"id": t["id"], "overdue": bool(t["overdue"]),
                     "cells": fields.row(t, cols, ctx)} for t in flat]
    # ⭐ Кожна картка несе СВОЇ права — з тієї самої таблиці, що й картка задачі.
    # Без цього перетягування мишею вирішувало б саме, куди можна кинути, і
    # стало б другим писарем прав.
    adm = _is_admin(actor)
    for t in flat:
        t["may"] = tasks.rights(t, me, adm)
    data["filter"] = flt
    data["filter_options"] = fields.options(data.pop("_pool", None) or flat, ctx)
    data["views"] = [{"id": v["id"], "name": v["name"]} for v in my["views"]]
    data["view_id"] = my["view_id"]
    # ⭐ ПОШУК — ТРЕТЄ ПИТАННЯ ЕКРАНА, і він НЕ ЗБЕРІГАЄТЬСЯ в налаштуваннях:
    # «де та задача про оплату» — питання на півхвилини, а не вигляд списку.
    # Але екран мусить КАЗАТИ, що він звужений — тому запит йде назад.
    data["query"] = str(query or "")
    data["search_hint"] = fields.SEARCH_HINT
    # ⭐ Готові набори рахує ОДИН писар наборів, а не сторінка: інакше
    # екран знав би імена полів від себе й розійшовся б із реєстром.
    data["presets"] = prefs.presets(me)
    data["sort"] = my.get("sort") or {"field": "", "desc": False}
    data["default_view_id"] = my.get("default_view_id") or ""
    # ⭐ ВЛАДА НЕ СМІЄ БУТИ ТИХОЮ, а правда про вигляд — теж влада: екран каже,
    # чиї зараз колонки — свої чи компанійські, і хто задав компанійські.
    data["is_admin"] = adm
    data["view_own"] = bool(my.get("columns_own") or my.get("sort_own"))
    data["company"] = prefs.company()
    return data


def task_state(actor, tid: str) -> dict:
    _require_enabled()
    me = _require_actor(actor)
    seen = tasks.visible_ids(me)
    if tid not in seen:
        raise ApiError("Цієї задачі вам не видно.", 403, "not_visible")
    # ⭐ `incoming=True` — картка ЄДИНЕ місце, де потрібні ще й ті, хто вказує НА
    # цю задачу. Зворотний бік ніде не зберігається, тому його рахують саме тут.
    # ⛒ 708: назви етапів і головної, яких людині не видно, з картки не їдуть.
    t = tasks.mask_steps(tasks.task(tid, incoming=True), seen)
    names = {e["id"]: e.get("full_name", "") for e in people.employees(True)}
    t["my_role"] = tasks.role_of(t, me)
    # ⭐ Кнопки малюються з ЦЬОГО, а не з власних «якщо» на сторінці: інакше
    # екран став би другим писарем прав і розійшовся б із кодом дії.
    t["may"] = tasks.rights(t, me, _is_admin(actor))
    t["reach"] = mouth.reach(t, me)
    t["names"] = names
    t["me"] = {"id": me, "name": names.get(me, "")}
    t["people"] = [{"id": e["id"], "name": e.get("full_name", "")}
                   for e in people.employees()]
    # ⭐ Вибір типу роботи їде РАЗОМ із карткою, як і люди: другий шлях по ті
    # самі дані означав би, що екран колись покаже не той список.
    t["worktypes"] = [{"id": w["id"], "name": w["name"]}
                      for w in worktypes.types()]
    t["priorities"] = _priorities()                               # ⭐ 734
    # ⭐ ПРОЄКТИ ЇДУТЬ РАЗОМ ІЗ КАРТКОЮ, як люди й типи роботи. Другий шлях по ті
    # самі дані означав би, що екран колись покаже не той перелік. І перелік тут
    # рівно той, який людині НАЛЕЖИТЬ: право рахує Task Desk по дереву компанії,
    # а не екран за своїм «якщо».
    t["projects"] = tasks.projects_for(me, _is_admin(actor))
    t["project_name"] = tasks.project_name(t.get("project_id") or "")
    # ⭐ 707: шаблони їдуть разом із карткою — для «Додати за шаблоном» і окремо
    # для пояснення провалу перевірки. Лише чинні.
    t["templates"] = tpls.templates(purpose=tpls.PURPOSE_ANY)
    t["templates_fail"] = tpls.templates(purpose=tpls.PURPOSE_FAIL)
    # ⭐ 708: і для «Почати раніше з поясненням» — шаблони раннього початку етапу.
    t["templates_early"] = tpls.templates(purpose=tpls.PURPOSE_EARLY)
    t["tpl_other"] = {"word": tpls.OTHER, "suffix": tpls.OTHER_SUFFIX}
    _add_links(t, me)
    return t


# ---------------------------------------------------------------------------
# ЗВʼЯЗКИ ЗАДАЧІ ДЛЯ ЕКРАНА (зміна 172)
# ---------------------------------------------------------------------------
LINK_TARGETS_MAX = 300      # ⚠ мовчазних обрізань не буває: скільки не влізло — скажемо


def _add_links(t: dict, me: str) -> None:
    """Що показати в блоці «Звʼязки» і з чого людині вибирати.

    ⭐ ФОРМУЛЮВАННЯ БЕРЕМО В `taskdesk_links`, а не складаємо на сторінці:
    інакше екран став би другим писарем слів і розійшовся б із телеграмом."""
    mine = tasks.visible_tasks(me)
    # ⛒ 708: назви задач, яких глядачу не видно, — лише номером (суддя — `visible_ids`).
    seen = {x["id"] for x in mine}
    t["links_view"] = tlinks.decorate(t.get("links") or [], seen_tasks=seen)
    t["links_in_view"] = tlinks.decorate(t.get("links_in") or [], back=True, seen_tasks=seen)
    t["link_rels"] = [{"id": r, "name": tlinks.REL_NAMES[r],
                       "tasks_only": r in tlinks.TASK_ONLY} for r in tlinks.RELS]

    rows = [{"ref": "task:%s" % x["id"], "id": x["id"], "title": x["title"]}
            for x in mine if x["id"] != t["id"]]
    note = ""
    if len(rows) > LINK_TARGETS_MAX:
        note = ("показано перші %d задач із %d — решту знайдіть за номером"
                % (LINK_TARGETS_MAX, len(rows)))
        rows = rows[:LINK_TARGETS_MAX]
    parties = []
    try:
        import parties as _pt
        for x in _pt.all_parties():
            parties.append({"ref": "party:%s" % x["id"], "id": x["id"],
                            "title": x.get("name") or x["id"]})
    except Exception as ex:
        note = (note + " · " if note else "") + "довідник контрагентів не прочитався: %s" % ex
    t["link_targets"] = {"tasks": rows, "parties": parties, "note": note}


def _result(me, d, adm: bool = False) -> dict:
    """Позначити наявний коментар результатом — і звірити його з критерієм."""
    tid = d.get("id") or ""
    cid = d.get("comment_id") or ""
    body = ""
    try:
        for c in (tasks.task(tid).get("feed") or []):
            if c["id"] == cid:
                body = c.get("text") or ""
                break
    except tasks.TaskError:
        body = ""
    m, note = comment_door.match_for(tid, body)
    t = tasks.mark_result(tid, me, cid, adm, match=m)
    if note:
        t = dict(t)
        t["ai_note"] = note
    return t


def _comment(me, d, adm: bool = False) -> dict:
    """Коментар зберігається ЗАВЖДИ. Мозок читає його ПІСЛЯ і лише пропонує.

    ⭐ 650: ПИШЕ ОДИН ПИСАР — `taskdesk_comment.write()`, той самий, що й у бота
    задач. Доти ця логіка жила тут, і бот писав повз мозок."""
    return comment_door.write(d.get("id") or "", me, d.get("text") or "",
                              bool(d.get("as_result")), adm)


def _quick_add(me, d, adm=False) -> dict:
    """⭐⭐⭐ ОДИН РЯДОК → ЗАДАЧА (зміна 223, 26.08.2026).

    КОРІНЬ, ЗАРАДИ ЯКОГО ЦЕ ІСНУЄ. Задачники вмирають не від поганих воріт, а
    від того, що поставити задачу довше, ніж написати в чат. Тут — один рядок.

    ⛒ ПОРЯДОК НАВМИСНИЙ: спершу РОЗБІР (безкоштовно, кодом), потім СТВОРЕННЯ
    (усі наявні ворота прав і SoD, бо йдемо через ту саму `tasks.create`), і
    лише ПОТІМ мозок. Задача вже на диску, коли він тільки починає думати.

    🩸 ГРОШІ. Мозок кличемо ЛИШЕ для задачі ІНШІЙ людині — рішення Андрія
    26.08.2026. Нагадування собі критерію приймання не потребує.
    """
    line = (d.get("line") or d.get("text") or "").strip()
    if not line:
        raise tasks.TaskError("Порожній рядок — задачі з нього не вийде.")
    parsed = intake.parse(line, people.employees(), clock.now()[:10],
                          tasks.find_due_in)
    if not parsed["title"]:
        raise tasks.TaskError(
            "; ".join(parsed["unclear"]) or "У рядку немає самої задачі.")
    t = tasks.create(me, parsed["title"], parsed["assignee_id"],
                     parsed["due_at"], source="quick")
    out = dict(t)
    out["said"] = parsed["said"]
    out["unclear"] = list(parsed["unclear"])

    # ⛒ ВОРОТА ВХОДУ. Безкоштовна половина вже порахована в самій задачі
    # (`unready_why`). Платна половина — лише пропозиція формулювання, і лише
    # там, де є за що платити.
    if not (out.get("for_other") and not out.get("acceptance")):
        return out
    try:
        found, note = ai.propose_acceptance_soon(t.get("title", ""),
                                                 t.get("description", ""))
    except Exception as e:
        out["ai_note"] = str(e)
        return out
    if note:
        out["ai_note"] = note
        return out
    if not found:
        return out
    try:
        out = dict(tasks.add_proposal(t["id"], tasks.PROPOSAL_ACCEPT, "",
                                      found.get("why", ""), "", "",
                                      found["acceptance"]))
        out["said"] = parsed["said"]
        out["unclear"] = list(parsed["unclear"])
        out["ai_note"] = "ok"
    except tasks.TaskError as e:
        out["ai_note"] = str(e)
    return out


# ⭐ Третій аргумент `adm` — прапорець адміністратора. Він іде ЗВЕРХУ, з шару
# облікових записів, бо в самій задачі адміністратора може не бути взагалі.
TASK_ACTIONS = {
    "create": lambda me, d, adm: tasks.create(
        me, d.get("title") or "", d.get("assignee_id") or "", d.get("due_at") or "",
        d.get("description") or "", d.get("coassignee_ids") or [],
        d.get("watcher_ids") or [], d.get("checklist") or [],
        verifier_id=d.get("verifier_id") or "",
        worktype_id=d.get("worktype_id") or "",
        project_id=d.get("project_id") or "", is_admin=adm,
        priority=d.get("priority") or ""),                     # ⭐ 734
    "comment": lambda me, d, adm: _comment(me, d, adm),
    "result": lambda me, d, adm: _result(me, d, adm),
    # ⭐ «Перевірив, годиться» — окрема дія, а не стадія. Незгода — «Не прийняти»
    # з причиною (706); доти вона їхала стадією «На доопрацювання» без сліду.
    "verify": lambda me, d, adm: tasks.verify(d.get("id") or "", me, adm),
    # ⭐ 706 (проєкт розробки ОТУ, 3.4 і 3.6).
    "reject": lambda me, d, adm: tasks.reject(d.get("id") or "", me,
                                              d.get("reason") or "", adm),
    "explain": lambda me, d, adm: tasks.explain(d.get("id") or "", me,
                                                d.get("text") or "", adm,
                                                template_id=d.get("template_id") or "",
                                                answers=d.get("answers") or {}),
    # ⭐ 707 (3.7): «Додати за шаблоном».
    "comment_tpl": lambda me, d, adm: tasks.comment_by_template(
        d.get("id") or "", me, d.get("template_id") or "", d.get("answers") or {}, adm),
    # ⭐ 708 (3.5, 4.4 Б): етапи великої задачі.
    "step_add": lambda me, d, adm: tasks.add_step(
        d.get("id") or "", me, d.get("title") or "", d.get("assignee_id") or "",
        d.get("due_at") or "", d.get("verifier_id") or "", d.get("description") or "", adm),
    "step_move": lambda me, d, adm: tasks.move_step(d.get("id") or "", me,
                                                    d.get("step_id") or "",
                                                    bool(d.get("up")), adm),
    "early": lambda me, d, adm: tasks.start_early(d.get("id") or "", me,
                                                  d.get("template_id") or "",
                                                  d.get("answers") or {},
                                                  d.get("text") or "", adm),
    "ack": lambda me, d, adm: tasks.acknowledge(d.get("id") or "", me, adm),
    "clarify": lambda me, d, adm: tasks.clarify(d.get("id") or "", me,
                                                d.get("text") or "", adm),
    "stage": lambda me, d, adm: tasks.set_stage(d.get("id") or "", me,
                                                d.get("stage") or "", adm),
    # ⭐ 709: перенести в колонку дошки проєкту (інша стадія — ті самі двері `set_stage`).
    "column": lambda me, d, adm: tasks.set_column(d.get("id") or "", me,
                                                  d.get("column") or "", adm),
    "delegate": lambda me, d, adm: tasks.delegate(d.get("id") or "", me,
                                                  d.get("assignee_id") or "", adm),
    "refuse": lambda me, d, adm: tasks.refuse(d.get("id") or "", me,
                                              d.get("reason") or "", adm),
    "check": lambda me, d, adm: tasks.check_item(d.get("id") or "", me,
                                                 d.get("item_id") or "",
                                                 bool(d.get("done")), adm),
    # ⭐ СТАНДАРТ ГОТОВНОСТІ (зміна 225) — окрема дія, а не «ще один пункт
    # плану»: чек-лист каже ЯК робити, стандарт — ЗА ЧИМ приймемо.
    "dod": lambda me, d, adm: tasks.check_dod(d.get("id") or "", me,
                                              d.get("point_id") or "",
                                              bool(d.get("done")), adm),
    "proposal": lambda me, d, adm: tasks.resolve_proposal(
        d.get("id") or "", me, d.get("proposal_id") or "",
        bool(d.get("accept")), adm),
    # ⭐ ЗВʼЯЗОК — ТАКА САМА ДІЯ, ЯК РЕШТА: іде тим самим єдиним входом, під тими
    # самими правами (`ACT_EDIT`), і лишає слід у стрічці, нерві й протоколі.
    "link": lambda me, d, adm: tasks.link(d.get("id") or "", me, d.get("ref") or "",
                                          d.get("rel") or "", adm),
    "unlink": lambda me, d, adm: tasks.unlink(d.get("id") or "", me, d.get("ref") or "",
                                              d.get("rel") or "", adm),
    "update": lambda me, d, adm: tasks.update(d.get("id") or "", me, adm,
                                              **{k: v for k, v in d.items()
                                                 if k in ("title", "description", "due_at",
                                                          "coassignee_ids", "watcher_ids",
                                                          "verifier_id", "acceptance",
                                                          "worktype_id", "project_id",
                                                          "priority")}),
    # ⭐ ОДИН РЯДОК — ТА САМА ДІЯ, ЩО Й РЕШТА: єдиний вхід, ті самі права,
    # той самий слід. Другого шляху завести задачу в продукті немає.
    "quick_add": lambda me, d, adm: _quick_add(me, d, adm),
}


def run_task_action(actor, data: dict) -> dict:
    """ЄДИНИЙ вхід усіх дій над задачами — щоб новий екран не винайшов свій шлях
    повз перевірки. Невідома дія не виконується, а називається."""
    _require_enabled()
    me = _require_actor(actor)
    name = str((data or {}).get("action") or "").strip()
    fn = TASK_ACTIONS.get(name)
    if fn is None:
        raise ApiError("Невідома дія «%s». Відомі: %s"
                       % (name, ", ".join(sorted(TASK_ACTIONS))), 400, "unknown_action")
    try:
        res = fn(me, data or {}, _is_admin(actor))
    except tasks.TaskError as e:
        raise ApiError(str(e), 400, "refused")
    except people.PeopleError as e:
        raise ApiError(str(e), 400, "refused")
    if isinstance(res, dict) and res.get("id") and (res.get("step_of") or res.get("steps")):
        # ⛒ 708: відповідь на дію — та сама картка, отже й ті самі межі видимого.
        res = tasks.mask_steps(dict(res), tasks.visible_ids(me))
    out = {"ok": True, "result": res}
    # ⭐⭐⭐ ПРАВДА ПРО ТИШУ ЇДЕ З КОЖНОЮ ДІЄЮ, а не лише зі створенням: людина
    # має знати, хто про її крок дізнається, коли б вона його не зробила.
    # Порахувати це має ОДИН писар (`mouth.reach`), інакше екран створення й
    # картка задачі казали б різне.
    if isinstance(res, dict) and res.get("id") and res.get("stage"):
        try:
            out["reach"] = mouth.reach(res, me)
        except Exception as e:
            # Тиша про тишу — рівно те, що ми тут і лікуємо.
            out["reach"] = {"note": "Не вдалося порахувати, кому це піде: %s" % e}
    return out


# ---------------------------------------------------------------------------
# ДІЇ — ОДНА ТАБЛИЦЯ НА ВСЮ КОНСОЛЬ
# ---------------------------------------------------------------------------
def _d(data, *names):
    return [(data.get(n) or "") for n in names]


PEOPLE_ACTIONS = {
    "unit_add": lambda d: people.add_unit(*_d(d, "name", "parent_id", "head_employee_id")),
    "unit_parent": lambda d: people.set_unit_parent(*_d(d, "unit_id", "parent_id")),
    "unit_head": lambda d: people.set_unit_head(*_d(d, "unit_id", "head_employee_id")),
    # ⭐ ЛІКВІДАЦІЯ (зміна 350). Дочірні підрозділи не гинуть: `children_to`
    # каже, кому вони переходять; порожньо — батьківському.
    "unit_liquidate": lambda d: people.liquidate_unit(d.get("unit_id") or "",
                                                      d.get("children_to") or ""),
    "unit_restore": lambda d: people.restore_unit(d.get("unit_id") or ""),
    # ⭐ ГОРИЗОНТИ (зміна 302): вісім готових місць. «Завести» горизонт означає
    # дати номеру КОЛІР; порожній колір звільняє місце, і писар відмовиться,
    # якщо на ньому ще хтось стоїть.
    "horizon_color": lambda d: people.set_horizon_color(*_d(d, "number", "color")),
    "unit_horizon": lambda d: people.set_unit_horizon(*_d(d, "unit_id", "number")),
    "position_add": lambda d: people.add_position(d.get("name") or ""),
    # ⭐⭐⭐ 626е (22.09.2026): ВИПРАВЛЕННЯ ІМЕНІ — КНОПКОЮ, А НЕ ПРАВКОЮ ФАЙЛА.
    # Нові дії йдуть ТИМИ САМИМИ воротами (таблиця «people» — адмінська), а не
    # другим замком поруч.
    "unit_rename": lambda d: people.rename_unit(d.get("id") or d.get("unit_id") or "",
                                                d.get("name") or ""),
    "position_rename": lambda d: people.rename_position(
        d.get("id") or d.get("position_id") or "", d.get("name") or ""),
    "position_archive": lambda d: people.archive_position(
        d.get("id") or d.get("position_id") or ""),
    "position_restore": lambda d: people.restore_position(
        d.get("id") or d.get("position_id") or ""),
    "employee_add": lambda d: _employee_add(d),
    "employee_update": lambda d: people.update_employee(
        d.get("id") or "", **{k: v for k, v in d.items()
                              if k in ("full_name", "unit_id", "position_id", "email",
                                       "telegram_id", "birthday", "phone_mobile",
                                       "phone_work", "horizon_id")}),
    "employee_dismiss": lambda d: people.dismiss_employee(d.get("id") or "",
                                                          d.get("reason") or ""),
    # ⭐ ЗАМІЩЕННЯ НА ЧАС ВІДСУТНОСТІ (зміна 224). Іде тим самим єдиним входом,
    # що й решта дій над карткою, — другого шляху завести відсутність немає.
    "absence_set": lambda d: people.set_absence(
        d.get("id") or "", d.get("from") or "", d.get("to") or "",
        d.get("delegate_id") or "", d.get("reason") or ""),
    "absence_clear": lambda d: people.clear_absence(d.get("id") or "",
                                                    d.get("absence_id") or ""),
    "employee_restore": lambda d: people.restore_employee(d.get("id") or ""),
    # ⭐ КАНАЛ ПІДКЛЮЧАЄ САМА ЛЮДИНА. Номер чату не знає ні вона, ні
    # адміністратор — його знає лише телеграм. Тому екран видає РАЗОВИЙ КОД,
    # а звʼязує код із чатом бот.
    "telegram_code": lambda d: identity.link_code(_acc_of(d.get("id") or "")["id"]),
    "telegram_unlink": lambda d: identity.unlink_telegram(_acc_of(d.get("id") or "")["id"]),
}

# ⭐ ТИПИ РОБОТИ — ПРАВИЛО КОМПАНІЇ, А НЕ ОСОБИСТА НАСТРОЙКА, тому веде їх
# адміністратор (за замовчуванням таблиці). 🩸 Заготовок від нас немає: клієнт
# складає стандарт сам (рішення Андрія 26.08.2026).
WORKTYPE_ACTIONS = {
    "type_add": lambda d: worktypes.add_type(d.get("name") or "",
                                             d.get("points") or []),
    "type_update": lambda d: worktypes.update_type(
        d.get("id") or "",
        name=d.get("name") if "name" in d else None,
        points=d.get("points") if "points" in d else None),
    "type_active": lambda d: worktypes.set_active(d.get("id") or "",
                                                  bool(d.get("active"))),
}


def _employee_add(d: dict) -> dict:
    """⭐⭐⭐ 702: ПРАЦІВНИК ОДНИМ КРОКОМ (зауваження Андрія з ОТУ 06.10.2026). Галочка
    «Дати доступ до платформи» — картка, обліковий запис і лист доступу однією дією.
    Логін: названий руками або від писаря `identity.suggest_login` (частина пошти до @).
    ⛒ Зайнятий логін, названий руками, — відмова ДО картки: друга спроба не дасть дубля
    працівника. Запис не склався з іншої причини — картка лишається, відповідь каже чому
    (людина з'явиться в «Працівники без доступу» на «Доступах»)."""
    want = bool(d.get("access"))
    login = ""
    if want:
        login = str(d.get("login") or "").strip().lower() or \
            identity.suggest_login(d.get("email") or "")
        if login and identity.account_by_login(login):
            raise identity.IdentityError(
                "логін «%s» уже зайнятий — змініть його або залиште поле порожнім: платформа "
                "придумає вільний з пошти. Працівника не додано." % login)
    emp = people.add_employee(
        d.get("full_name") or "", d.get("unit_id") or "", d.get("position_id") or "",
        d.get("email") or "", d.get("telegram_id") or "", d.get("birthday") or "",
        d.get("phone_mobile") or "", d.get("phone_work") or "")
    if not want:
        return emp
    out = dict(emp)
    if not login:
        out["access"] = {"created": False,
                         "reason": "немає ні пошти, ні логіна — доступ не створено; дайте його "
                                   "на екрані «Доступи», коли буде логін"}
        return out
    try:
        acc = identity.create_account(login, "", emp["id"], False)
    except identity.IdentityError as e:
        out["access"] = {"created": False, "reason": str(e)}
        return out
    out["access"] = {"created": True, "login": acc["login"], "account_id": acc["id"],
                     "letter": access_letter.after_create(acc)}
    return out


def _no_access() -> list:
    """⭐ 702: хто працює, а облікового запису не має — з придуманим логіном. Логіни в
    переліку не повторюються (у двох «ivan@…» — ivan і ivan2)."""
    have = {a["employee_id"] for a in identity.accounts()}
    out, taken = [], set()
    for e in people.employees():                     # лише ті, хто працює
        if e["id"] in have:
            continue
        login = identity.suggest_login(e.get("email") or "", taken)
        if login:
            taken.add(login)
        out.append({"employee_id": e["id"], "full_name": e.get("full_name") or "",
                    "email": e.get("email") or "", "login": login})
    return out


def _account_add(d: dict) -> dict:
    """⭐⭐⭐ 696: ЗАВЕСТИ ЗАПИС — І ЛИСТ ДОСТУПУ ЙДЕ САМ (слово Андрія 05.10.2026).
    Пароль необовʼязковий: людина ставить свій за разовим посиланням із листа.
    Лист не пішов — запис однаково заведено, а відповідь каже, чому лист не пішов."""
    acc = identity.create_account(
        d.get("login") or "", d.get("password") or "", d.get("employee_id") or "",
        bool(d.get("is_admin")))
    out = dict(acc)
    out["letter"] = access_letter.after_create(acc)
    return out


def _letter_send(d: dict) -> dict:
    return {"letter": access_letter.send_for(d.get("id") or "")}


def _letter_settings(d: dict) -> dict:
    return access_letter.save_settings(d.get("public_url") or "", d.get("trusted_proxy") or "")


ACCESS_ACTIONS = {
    "account_add": _account_add,
    # ⭐ 696: лист доступу ще раз (після зміни пошти, строку посилання, пароля) і
    # картка «Лист доступу»: адреса для працівників і довірений проксі.
    "letter_send": _letter_send,
    "letter_settings": _letter_settings,
    "password": lambda d: identity.set_password(d.get("id") or "", d.get("password") or ""),
    "active": lambda d: identity.set_active(d.get("id") or "", bool(d.get("active"))),
    "layers": lambda d: identity.set_layers(d.get("id") or "", d.get("layers") or []),
    "orchestrator": lambda d: identity.set_orchestrator_access(
        d.get("id") or "", d.get("mode") or "", d.get("systems") or []),
    # ⭐⭐⭐ 588 (16.09.2026): РІВЕНЬ І ПРИБИРАННЯ ЗАПИСУ — КНОПКАМИ, А НЕ
    # ПРАВКОЮ ФАЙЛА. Доти в цій таблиці були пароль, вмикання, шари й
    # оркестратор, а рівень адміністратора задавався ЛИШЕ при народженні
    # запису. Разом із правилом «один працівник — один запис» це робило
    # помилку в рівні невиправною: 15.09.2026 у Каспера довелось правити
    # `accounts.json` руками. Нові дії йдуть ТИМИ САМИМИ воротами (таблиця
    # `access` — адмінська), а не другим замком поруч.
    "is_admin": lambda d: identity.set_admin(d.get("id") or "",
                                             bool(d.get("is_admin"))),
    "account_remove": lambda d: identity.remove_account(d.get("id") or ""),
    # ⭐ 666: скинути другий фактор (телефон загублено) і вимога для всіх/ролей.
    "second_factor_reset": lambda d: identity.reset_second_factor(d.get("id") or ""),
    "second_factor_policy": lambda d: second_factor.set_policy(d.get("mode") or "",
                                                               d.get("roles") or []),
}


# ⭐ РЕЄСТР ТАБЛИЦЬ ДІЙ — одне місце, де перелічені ВСІ таблиці Task Desk.
# Нова таблиця, не вписана сюди, не має входу з сервера; чек 1.4 звіряє реєстр
# із тим, що насправді оголошено у файлі, — тому «таблиця повз реєстр» не живе.
# ---------------------------------------------------------------------------
# НАЛАШТУВАННЯ ЕКРАНА Й ВИВАНТАЖЕННЯ. Ворота тут ті самі, що в задачах: це веде
# САМА ЛЮДИНА, не адміністратор. Тому окремий вхід `run_prefs_action`, а не
# спільний із оргструктурою.
# ---------------------------------------------------------------------------
# ⭐⭐⭐ 669. ВИВАНТАЖЕННЯ — ОКРЕМЕ ПРАВО, ОДНА ВІДПОВІДЬ НА ВСІ ДВЕРІ.
# 🩸 Досі «Вивантажити в Excel» міг будь-хто з карткою працівника, файл лягав у
# теку на СЕРВЕРІ, а клієнтська база приходила в браузер цілим шматком. Тепер:
# чи можна — питають тут (двері задач, двері бази CRM і «хто я» для кнопок),
# відмова — словами і рядком у журналі безпеки.
EXPORT_REFUSED = ("Вивантаження даних — окреме право «Вивантаження». Його дає "
                  "адміністратор на екрані прав.")


def may_export(actor) -> bool:
    """Чи може ця людина вивантажувати дані. «Не знаю» означає «ні»."""
    try:
        if not identity.login_required():
            return True                 # одноосібна машина: господар і є адміністратор
        if not actor:
            return False
        if actor.get("is_admin"):
            return True
        emp = str(actor.get("employee_id") or "").strip()
        return bool(emp) and bool(roles.allows(emp, roles.P_EXPORT))
    except Exception:
        return False


# ---------------------------------------------------------------------------
# ⭐⭐ 707 (06.10.2026). ШАБЛОНИ ПОЯСНЕНЬ І ЗАПИТІВ — довідник веде той, кому дано право
# «Вести шаблони» (з коробки — керівник і повний доступ), і адміністратор.
# ---------------------------------------------------------------------------
TEMPLATES_REFUSED = ("Довідник шаблонів веде той, кому дано право «Вести шаблони». "
                     "Його дає адміністратор на екрані «Права доступу».")


def may_manage_templates(actor) -> bool:
    """Чи може ця людина вести довідник шаблонів. «Не знаю» означає «ні»."""
    try:
        if not identity.login_required():
            return True                 # одноосібна машина: господар і є адміністратор
        if not actor:
            return False
        if actor.get("is_admin"):
            return True
        emp = str(actor.get("employee_id") or "").strip()
        return bool(emp) and bool(roles.allows(emp, roles.P_TEMPLATES))
    except Exception:
        return False


def _require_templates(actor):
    if not may_manage_templates(actor):
        raise ApiError(TEMPLATES_REFUSED, 403, "templates_right")


def whoami_flags(actor) -> dict:
    """⭐ 707: кнопки, які малює екран за правом, питають ТИХ САМИХ суддів, що й двері.
    Одне місце на всі прапорці «хто я» (вивантаження 669, проєкти 705, шаблони 707)."""
    out = {}
    for key, judge in (("can_export", may_export), ("can_create_projects", None),
                       ("can_manage_templates", may_manage_templates)):
        try:
            fn = judge or may_create_project
            out[key] = bool(fn(actor))
        except Exception:
            out[key] = False            # «не знаю» ховає кнопку
    return out


def _tpl_view(t: dict) -> dict:
    return dict(t, purpose_name=tpls.PURPOSE_NAMES.get(t["purpose"], t["purpose"]))


def templates_state(actor) -> dict:
    """Екран довідника шаблонів: усі шаблони, з прибраними з вибору."""
    _require_enabled()
    _require_templates(actor)
    st = tpls.load()
    return {"templates": [_tpl_view(t) for t in st["templates"]],
            "unreadable_reason": st.get("unreadable_reason", ""),
            "purposes": [{"id": k, "name": v} for k, v in tpls.PURPOSE_NAMES.items()],
            "kinds": [{"id": k, "name": v} for k, v in tpls.KIND_NAMES.items()],
            "other": tpls.OTHER, "other_suffix": tpls.OTHER_SUFFIX,
            "max_fields": tpls.MAX_FIELDS}


TEMPLATE_ACTIONS = {
    "tpl_add": lambda d: tpls.add(d.get("name") or "", d.get("purpose") or tpls.PURPOSE_ANY,
                                  d.get("fields") or []),
    "tpl_update": lambda d: tpls.update(
        d.get("id") or "",
        name=d.get("name") if "name" in d else None,
        purpose=d.get("purpose") if "purpose" in d else None,
        fields=d.get("fields") if "fields" in d else None),
    "tpl_active": lambda d: tpls.set_active(d.get("id") or "", bool(d.get("active"))),
}


# ---------------------------------------------------------------------------
# ⭐⭐⭐ 705 (06.10.2026). ПРОЄКТИ В САМОМУ TASK DESK — ОДНІ ДВЕРІ.
# Проєкт розробки ОТУ, частина 2 (пп. 3.1, 3.2; 4.1 Б, 4.2 В, 4.3 Б). Хто що
# бачить і хто чим керує — судить `taskdesk_projects`; тут — право облікового
# запису «Створювати проєкти» і переклад відмов у мову екрана.
# ---------------------------------------------------------------------------
PROJECT_CREATE_REFUSED = ("Створювати проєкти — окреме право «Створювати проєкти». "
                          "Його дає адміністратор на екрані «Права доступу».")


def may_create_project(actor) -> bool:
    """Чи може ця людина заводити проєкти. «Не знаю» означає «ні»."""
    try:
        if not identity.login_required():
            return True                 # одноосібна машина: господар і є адміністратор
        if not actor:
            return False
        if actor.get("is_admin"):
            return True
        emp = str(actor.get("employee_id") or "").strip()
        return bool(emp) and bool(roles.allows(emp, roles.P_PROJECTS))
    except Exception:
        return False


def _project_owners(actor, me: str) -> list:
    """Кого форма пропонує власником: себе і підлеглих; адміністраторові — усіх."""
    if _is_admin(actor):
        ids = [e["id"] for e in people.employees()]
    else:
        ids = [me] + [x for x in people.subordinates_of(me) if x != me]
    names = {e["id"]: e.get("full_name", "") for e in people.employees()}
    return [{"id": x, "name": names.get(x, "")} for x in ids if x in names]


def _project_viewer(actor) -> "tprj.Viewer":
    me = _require_actor(actor)
    return tasks._viewer(me, _is_admin(actor))


def projects_state(actor) -> dict:
    """Екран проєктів: робочий перелік, архів, «попросити доступ», право створювати."""
    _require_enabled()
    v = _project_viewer(actor)
    tprj.ensure_management(top_manager_id())
    out = tprj.listing(v)
    out["may_create"] = may_create_project(actor)
    out["owners"] = _project_owners(actor, v.id)
    out["statuses"] = [{"id": k, "name": n} for k, n in tprj.STATUS_NAMES.items()]
    return out


def _project_create(actor, v, d):
    if not may_create_project(actor):
        raise ApiError(PROJECT_CREATE_REFUSED, 403, "project_right")
    return tprj.create(v, d.get("name") or "", d.get("owner_id") or "",
                       d.get("description") or "")


PROJECT_ACTIONS = {
    "create": _project_create,
    "edit": lambda actor, v, d: tprj.edit(
        v, d.get("id") or "",
        **{k: d[k] for k in ("name", "description", "owner_id") if k in d}),
    "status": lambda actor, v, d: tprj.set_status(v, d.get("id") or "", d.get("status") or ""),
    "member_add": lambda actor, v, d: tprj.member_add(v, d.get("id") or "",
                                                      d.get("employee_id") or ""),
    "member_remove": lambda actor, v, d: tprj.member_remove(v, d.get("id") or "",
                                                            d.get("employee_id") or ""),
    "request": lambda actor, v, d: tprj.request(v, d.get("id") or "", d.get("note") or ""),
    "decide": lambda actor, v, d: tprj.decide(v, d.get("id") or "", d.get("employee_id") or "",
                                              bool(d.get("accept"))),
    # ⭐ 709 (3.3): колонки дошки — власник проєкту. Скільки задач у колонці, рахує
    # Task Desk (усі задачі, не лише видимі тому, хто прибирає).
    "column_add": lambda actor, v, d: tprj.column_add(v, d.get("id") or "", d.get("name") or "",
                                                      d.get("stage") or ""),
    "column_rename": lambda actor, v, d: tprj.column_rename(v, d.get("id") or "",
                                                            d.get("column") or "",
                                                            d.get("name") or ""),
    "column_move": lambda actor, v, d: tprj.column_move(v, d.get("id") or "",
                                                        d.get("column") or "",
                                                        bool(d.get("left"))),
    "column_remove": lambda actor, v, d: tprj.column_remove(
        v, d.get("id") or "", d.get("column") or "",
        lambda cid: tasks.column_load(d.get("id") or "", cid)),
}


def run_project_action(actor, data: dict) -> dict:
    """ЄДИНИЙ вхід дій над проєктами. Невідома дія не виконується, а називається."""
    _require_enabled()
    v = _project_viewer(actor)
    name = str((data or {}).get("action") or "").strip()
    fn = PROJECT_ACTIONS.get(name)
    if fn is None:
        raise ApiError("Невідома дія «%s». Відомі: %s"
                       % (name, ", ".join(sorted(PROJECT_ACTIONS))), 400, "unknown_action")
    try:
        res = fn(actor, v, data or {})
    except tprj.ProjectError as e:
        raise ApiError(str(e), 400, "refused")
    return {"ok": True, "result": res}


def require_export(actor, what: str):
    """Пустити до вивантаження або відмовити — і відмову записати в журнал."""
    if may_export(actor):
        return
    import security_log
    security_log.data_export(what, 0, refused="немає права «Вивантаження»")
    raise ApiError(EXPORT_REFUSED, 403, "export_right")


def export_tasks(actor, d) -> dict:
    """ОДНІ ДВЕРІ вивантаження задач: право → файл у теці, яку віддасть сервер і
    одразу прибере (`res["folder"]`) → рядок у журналі безпеки."""
    _require_enabled()
    _require_actor(actor)
    what = "задачі Task Desk"
    require_export(actor, what)
    import tempfile
    folder = tempfile.mkdtemp(prefix="sf_tdx_")
    try:
        res = _export(actor, d or {}, folder)
    except Exception:
        import shutil
        shutil.rmtree(folder, ignore_errors=True)
        raise
    res["folder"] = folder
    import security_log
    security_log.data_export(what, res.get("rows", 0), note="показано: %s; пошук: %s" % (
        SCOPE_NAMES.get(str((d or {}).get("scope") or "all"), "усі видимі"),
        str((d or {}).get("q") or "").strip() or "не задавали"))
    return res


def _export(actor, d, folder) -> dict:
    scope = str(d.get("scope") or "all")
    show_closed = bool(d.get("closed"))
    show_archive = bool(d.get("archive"))
    # ⭐ ЩО НА ЕКРАНІ, ТЕ Й У ФАЙЛІ: пошук йде в вивантаження тим самим
    # шляхом, що й у список. Інакше людина шукала б одне, а вивантажувала інше.
    query = str(d.get("q") or "")
    me, my, ctx, flt, data, flat = _desk(actor, scope, show_closed,
                                        d.get("filter"),
                                        use_saved=d.get("filter") is None,
                                        query=query, show_archive=show_archive)
    data.pop("_pool", None)
    who = people.employee(me).get("full_name", "")
    try:
        res = export.build(flat, my["columns"], ctx, who_name=who, flt=flt,
                           scope_name=SCOPE_NAMES.get(scope, scope), query=query,
                           folder=folder)
    except export.ExportError as e:
        raise ApiError(str(e), 400, "no_excel")
    return res


PREFS_ACTIONS = {
    "columns": lambda me, d: prefs.set_columns(me, d.get("columns") or []),
    "filter": lambda me, d: prefs.set_filter(me, d.get("filter") or {},
                                             d.get("view_id") or ""),
    "view_save": lambda me, d: prefs.save_view(me, d.get("name") or "",
                                               d.get("filter") or {},
                                               d.get("columns"),
                                               d.get("view_id") or ""),
    "view_delete": lambda me, d: prefs.delete_view(me, d.get("view_id") or ""),
    "view_use": lambda me, d: prefs.use_view(me, d.get("view_id") or ""),
    "view_default": lambda me, d: prefs.set_default_view(me, d.get("view_id") or ""),
    "sort": lambda me, d: prefs.set_sort(me, d.get("field") or "", d.get("desc")),
    "view_reset": lambda me, d: prefs.reset_view(me),
    "company_set": lambda me, d: prefs.set_company(me, d.get("columns"),
                                                   d.get("sort")),
}


# ⭐ ОДИН ПЕРЕЛІК ДІЙ, ЯКІ ВЕДЕ АДМІНІСТРАТОР. Решта в цій таблиці — це те, що
# людина робить СОБІ. Змішати їх означало б віддати вигляд компанії будь-кому.
PREFS_ADMIN_ONLY = ("company_set",)


def run_prefs_action(actor, data: dict) -> dict:
    """ЄДИНИЙ вхід налаштувань екрана (вивантаження — `export_tasks`, 669)."""
    _require_enabled()
    me = _require_actor(actor)
    name = str((data or {}).get("action") or "").strip()
    if name in PREFS_ADMIN_ONLY:
        _require_admin(actor)
    # ⛒ 669: вивантаження тут більше не живе — це не налаштування, а окреме
    # право і файл у браузер: двері `/api/taskdesk/export` (`export_tasks`).
    fn = PREFS_ACTIONS.get(name)
    if fn is None:
        raise ApiError("Невідома дія «%s». Відомі: %s. Вивантаження в Excel — "
                       "окремі двері з правом «Вивантаження»."
                       % (name, ", ".join(sorted(PREFS_ACTIONS))),
                       400, "unknown_action")
    try:
        return {"ok": True, "result": fn(me, data or {})}
    except prefs.PrefsError as e:
        raise ApiError(str(e), 400, "refused")
    except fields.FieldError as e:
        raise ApiError(str(e), 400, "refused")


# ⭐⭐⭐ ЕТАП 2 (24.08.2026). ПРАВА КРУТЯТЬСЯ РУКАМИ, А НЕ З КОДУ.
# Матриця «роль × дозвіл» зʼявилась зміною 205, але міняти її можна було лише
# правкою файла. Екран ходить через ТІ САМІ двері (`run_action`), тому ворота
# адміністратора не треба писати вдруге — вони вже стоять на вході.
ROLES_ACTIONS = {
    "role_add": lambda d: roles.add_role(d.get("name") or "",
                                         d.get("copy_from") or ""),
    "perm": lambda d: roles.set_perm(d.get("role_id") or "", d.get("perm") or "",
                                     bool(d.get("on"))),
    "assign": lambda d: roles.assign_to(d.get("kind") or "",
                                        d.get("target_id") or "",
                                        d.get("role_id") or ""),
}


ACTION_TABLES = {
    "roles": ROLES_ACTIONS,       # права — веде адміністратор
    "people": PEOPLE_ACTIONS,     # оргструктура — веде адміністратор
    "access": ACCESS_ACTIONS,     # доступи — веде адміністратор
    "worktypes": WORKTYPE_ACTIONS,  # типи робіт і стандарт — веде адміністратор
    "tasks": TASK_ACTIONS,        # задачі — веде сам працівник (інші ворота)
    "prefs": PREFS_ACTIONS,       # вигляд списку й вивантаження — теж сам працівник
    # ⭐ 705: проєкти — свої двері (`run_project_action`), права судить Task Desk.
    "projects": PROJECT_ACTIONS,
    # ⭐ 707: довідник шаблонів — своє право «Вести шаблони».
    "templates": TEMPLATE_ACTIONS,
}


# ⭐⭐⭐ ХТО МОЖЕ ЯКУ ДІЮ. Доти тут стояло глухе «все веде адміністратор», і
# рішення «людина править свої дані» просто не мало куди лягти. Тепер правило
# живе ОДНІЄЮ таблицею, як `ACTION_ROLES` у задачах: що не названо — адміністратор.
WHO_ADMIN = "admin"
# ⭐ Ліквідація підрозділу — не адміністрування, а рішення власника.
WHO_TOP = "top_manager"
WHO_SELF_OR_ADMIN = "self_or_admin"

WHO_MY_CARD = "my_card"
# ⭐ Відсутність — не поле картки. Її заводить сама людина, ЇЇ КЕРІВНИК або
# адміністратор: людина може зникнути раптово і вже нічого не ввести.
WHO_ABSENCE = "absence"
# ⭐ 707: довідник шаблонів — право «Вести шаблони», а не лише адміністратор.
WHO_TEMPLATES = "templates"

ACTION_WHO = {
    "people": {"employee_update": WHO_SELF_OR_ADMIN,
               "unit_liquidate": WHO_TOP,
               "unit_restore": WHO_TOP,
               "absence_set": WHO_ABSENCE,
               "absence_clear": WHO_ABSENCE,
               # Своя картка цілком: тут не поле правлять, а вмикають канал.
               "telegram_code": WHO_MY_CARD,
               "telegram_unlink": WHO_MY_CARD},
    "templates": {a: WHO_TEMPLATES for a in ("tpl_add", "tpl_update", "tpl_active")},
}


def top_manager_id() -> str:
    """ХТО СТАРШИЙ КЕРІВНИК КОМПАНІЇ — обчислено з дерева, а не записано.

    Це той, під ким стоїть УСЯ компанія: сам без керівника, і кожен інший
    працівник через ланцюг керівників доходить саме до нього. Якщо таких
    немає або їх кілька — порожньо, і той, хто питає, мусить сказати про це
    словами, а не вгадати."""
    emps = [e for e in people.employees() if not e.get("broken")]
    if not emps:
        return ""
    tops = [e for e in emps if not _s_id(e.get("manager_id"))]
    # ⛒ Тут перевіряється лише те, що вершина ВЗАГАЛІ Є. Скільки їх — питає не
    # це правило, а досяжність нижче: якщо вершин дві, хтось із людей не дійде
    # до обраної, і відповіді не буде. Два сторожі на одне правило — це нуль.
    if not tops:
        return ""
    top = tops[0]["id"]
    by_id = {e["id"]: e for e in emps}
    for e in emps:
        cur, seen = e["id"], set()
        while cur and cur not in seen:
            if cur == top:
                break
            seen.add(cur)
            cur = _s_id(by_id.get(cur, {}).get("manager_id"))
        else:
            return ""
        if cur != top:
            return ""
    return top


def _s_id(v) -> str:
    return str(v or "").strip()


def _require_top_manager(actor):
    """Ліквідувати підрозділ може лише старший керівник компанії."""
    # Поки вхід не вимагається, розрізняти нікого: господар машини і є власник.
    if not identity.login_required():
        _require_admin(actor)
        return
    me = _me(actor)
    if not me:
        raise ApiError("Увійдіть під своїм працівником: ліквідувати підрозділ "
                       "може лише старший керівник компанії.", 401, "login_required")
    top = top_manager_id()
    if not top:
        raise ApiError(
            "Платформа не може визначити старшого керівника компанії: у "
            "структурі більше ніж одна вершина або вона порожня. Спершу "
            "зведіть структуру до одного керівника нагорі — тоді ліквідація "
            "підрозділу стане доступною йому.", 400, "no_top_manager")
    if me != top:
        raise ApiError("Рішення про ліквідацію підрозділу приймає лише старший "
                       "керівник компанії.", 403, "not_top_manager")


def _guard_my_card(actor, data: dict):
    """Дія над СВОЄЮ карткою (не над полем). Адміністратор може й над чужою:
    він видає код людині, яка ще не має доступу до екрана, і знімає канал
    звільненому."""
    emp_id = str((data or {}).get("id") or "").strip()
    if not emp_id:
        raise ApiError("Не сказано, чия це картка.", 400, "no_id")
    if _is_admin(actor):
        return
    if not people.card_rights(_me(actor), emp_id, False).get("is_self"):
        raise ApiError("Телеграм людина підключає у своїй картці — чужу картку "
                       "змінює адміністратор.", 403, "not_allowed")


def _guard_absence(actor, data: dict):
    """Відсутність заводить сама людина, її керівник або адміністратор.
    Відповідь на це питання рахує ОДИН писар — `people.card_rights`, той самий,
    з якого екран малює блок. Інакше зʼявилась би кнопка, яка відмовить."""
    emp_id = str((data or {}).get("id") or "").strip()
    if not emp_id:
        raise ApiError("Не сказано, чию відсутність заводити.", 400, "no_id")
    if not people.card_rights(_me(actor), emp_id,
                              _is_admin(actor)).get("absence"):
        raise ApiError("Відсутність заводить сама людина, її керівник або "
                       "адміністратор.", 403, "not_allowed")


def _guard_card_fields(actor, data: dict):
    """Людина править СВОЄ, адміністратор — усе. Поле не за правом — відмова, яка
    називає, хто б це зміг."""
    emp_id = str((data or {}).get("id") or "").strip()
    if not emp_id:
        raise ApiError("Не сказано, чию картку правити.", 400, "no_id")
    rights = people.card_rights(_me(actor), emp_id, _is_admin(actor))
    asked = [k for k in (data or {}) if k not in ("action", "id")]
    if not asked:
        raise ApiError("Не сказано, що саме змінити.", 400, "no_fields")
    # ⭐ Відмова називає ПРИЧИНУ і того, хто б це зміг. Дві причини — різні:
    # «це не твоя картка» і «це поле не твоє» плутати не можна, бо людина
    # шукатиме зовсім не там. (`.capitalize()` тут теж не місце: «ПІБ» він
    # перетворював на «Піб» — знайдено живим прогоном 08.08.2026.)
    for f in asked:
        if f not in rights["fields"]:
            what = people.FIELD_NAMES.get(f, f)
            if not rights["is_self"]:
                raise ApiError(
                    "Це картка іншої людини: свої дані вона міняє сама, "
                    "а решту — адміністратор.", 403, "not_allowed")
            raise ApiError("У своїй картці %s змінює %s."
                           % (what, people.who_may_edit(f)), 403, "not_allowed")


def run_action(actor, table: str, data: dict) -> dict:
    """ЄДИНИЙ вхід для всіх дій обох екранів."""
    _require_enabled()
    actions = ACTION_TABLES.get(table)
    if actions is None:
        raise ApiError("Невідомий розділ «%s»." % table, 404, "unknown_table")
    name = str((data or {}).get("action") or "").strip()
    fn = actions.get(name)
    if fn is None:
        raise ApiError("Невідома дія «%s». Відомі: %s"
                       % (name, ", ".join(sorted(actions))), 400, "unknown_action")
    who = ACTION_WHO.get(table, {}).get(name, WHO_ADMIN)
    if who == WHO_ADMIN:
        _require_admin(actor)
    elif who == WHO_TOP:
        _require_top_manager(actor)
    elif who == WHO_MY_CARD:
        _guard_my_card(actor, data or {})
    elif who == WHO_ABSENCE:
        _guard_absence(actor, data or {})
    elif who == WHO_TEMPLATES:
        _require_templates(actor)
    else:
        _guard_card_fields(actor, data or {})
    # ⭐⭐⭐ ХТО ДІЄ — КАЖУТЬ ДВЕРІ, А НЕ КОЖНА ДІЯ ОКРЕМО (зміна 363, 30.08.2026).
    # Джерело кладемо теж: за ним журнал відрізняє «людина за екраном, вхід не
    # вимагається» від «зробила сама платформа». Без нього обидва випадки
    # виглядали б однаково безіменними, і екран мусив би вгадувати.
    # ⛒ Саме `step`, а не `bind`: сервер багатопотоковий і тримає зʼєднання, тож
    # прив'язка мусить померти разом із запитом.
    with protocol.step(actor=entity.person_of_actor(actor), source="ui"):
        try:
            result = fn(data or {})
        except (people.PeopleError, identity.IdentityError, roles.RoleError,
                worktypes.WorkTypeError, second_factor.SecondFactorError,
                tpls.TemplateError,
                access_letter.LetterError) as e:            # ⭐ 696: відмова словами
            # Відмова судді повноважень доходить до людини ТИМИ САМИМИ словами.
            raise ApiError(str(e), 400, "refused")
    return {"ok": True, "result": result}
