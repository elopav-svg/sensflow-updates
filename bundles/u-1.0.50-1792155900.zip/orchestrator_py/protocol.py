# -*- coding: utf-8 -*-
"""protocol.py — ЗАГАЛЬНИЙ ПРОТОКОЛ УСІХ ДІЙ ПЛАТФОРМИ (зміна 169, 13.08.2026).

⭐⭐⭐ КОРІНЬ. Слово Андрія 12.08.2026: «...і ведеться загальний протокол усіх дій
для аналізу і прийняття стратегічних рішень.»

Досі кожен домен вів СВІЙ журнал у СВОЄМУ форматі й СВОЇМИ іменами:
`runs/_audit.jsonl` (прогони), `taskdesk/events.jsonl` (задачі), історія всередині
картки CRM, слід виходів конекторів. Вони не бʼються не тому, що хтось лінувався, а
тому, що не було спільного способу НАЗВАТИ ту саму річ. Спільне імʼя тепер дає
`entity.py`; цей файл дає спільний ЖУРНАЛ.

ОДИН РЯДОК = ОДНА ДІЯ:
    at        коли (за єдиним писарем часу `clock`)
    actor     хто зробив          person:acc_1 · system:tender_writer
    action    що саме             ЗАКРИТИЙ словник дієслів (див. ACTIONS)
    subject   головна річ         task:128
    about     кого ще стосується  [party:p0004, run:run-2026-08-12T10-40-39]
    outcome   чим скінчилось      ok · refused · failed · stopped
    reason    причина СЛОВАМИ     «немає доступу до пошти»
    cost_usd  скільки коштувало   0.049
    source    звідки прийшла робота  human.console · telegram · mail · schedule

⭐ КЛЮЧОВЕ АРХІТЕКТУРНЕ РІШЕННЯ: **ЗВʼЯЗОК МІЖ СУТНОСТЯМИ ЖИВЕ ТУТ, А НЕ
КОПІЮЄТЬСЯ В КОЖЕН ФАЙЛ.** Не «допишемо клієнта в задачу, задачу в прогін, прогін у
картку» — це три копії однієї правди, які розійдуться за тиждень. Один рядок каже:
ця дія стосується цієї задачі, цього контрагента і цього прогону. «Покажи все про
Каспера» — прохід журналом, а не збирання по трьох файлах.

⚠ ПРОТОКОЛ НЕ МАЄ ПРАВА ЗАВАЛИТИ РОБОТУ. `write()` НІКОЛИ не кидає — як і `audit`.
Але тиха згода теж заборонена: відхилений рядок голосно лягає у ВЛАСНИЙ файл невдач
(`protocol_failures.jsonl`) і повертає False. Мовчазна втрата рядка зробила б журнал
брехуном, а брехливий журнал гірший за відсутній.

⚠ СЕКРЕТИ В ЖУРНАЛ НЕ ПОТРАПЛЯЮТЬ. Прибирання секретів стало ОДНИМ ПИСАРЕМ саме тут
(до 13.08 воно жило всередині `audit._scrub`), і `audit` тепер кличе його — щоб не
було двох різних «чистильників», які розійдуться.

⚠ ЧОМУ ЗВИЧАЙНИЙ ФАЙЛ, А НЕ БАЗА. Обсяг — сотні-тисячі рядків на місяць. SQLite дав
би новий тип сховища, блокування, міграції й окремий бекап — ціна є, виграшу немає.

Файл: `state/protocol.jsonl` (тека `state` уже в переліку живого стану
`state_files.STATE_DIRS`, тобто клієнту не їде і його власний не затирає).
Шлях лежить у змінній модуля — чек підміняє її й не сміє писати в бойову теку
(той самий прийом, що з `audit._PATH` і `parties.PARTIES_JSON`).
"""

import contextlib
import hashlib
import json
import threading

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import entity

# ⚠ Тека саме `config.STATE_DIR / "state"` — так само, як добовий рахунок грошей
# (`costs._day_path`). Це та сама тека живого стану, яку `state_files.STATE_DIRS`
# уже тримає осторонь від клієнтської збірки й від бандла оновлень.
_DIR = config.STATE_DIR / "state"
_PATH = _DIR / "protocol.jsonl"
_FAIL_PATH = _DIR / "protocol_failures.jsonl"
# ⭐⭐⭐ 663. РОДИНА БЕЗПЕКИ ЛЯГАЄ У СВІЙ ФАЙЛ — тим самим писарем.
# 🩸 Рахунок для ОТУ (~600 людей): входи й виходи — сотні рядків на день,
# ~0,5 МБ; за рік ~190 МБ. Екрани історії читають загальний протокол цілком —
# у спільному файлі кожне відкриття історії угоди тягнуло б і всі входи
# компанії. Писар, словник, чистильник і файл невдач ті самі; різниться лише
# МІСЦЕ, і його вирішує дієслово (`path_of`), а не той, хто пише.
_SEC_PATH = _DIR / "security.jsonl"


# ── ЗАКРИТИЙ СЛОВНИК ДІЄСЛІВ ─────────────────────────────────────────────────
# Урок зміни 162: вміння, якого немає в словнику, не можна ні оголосити, ні
# заборонити — і тоді замість нього мовчки підставляється сусіднє. Нове дієслово
# заводиться ТУТ, свідомо, а не зʼявляється саме з чергового виклику.
A_RUN_FINISHED = "run.finished"
A_RUN_EVENT = "run.event"
A_RUN_REFUSED = "run.refused"
A_TASK_CREATED = "task.created"
A_TASK_CHANGED = "task.changed"
# ⭐ ЗВʼЯЗОК І ПРОТЕРМІНУВАННЯ — ОКРЕМІ ДІЄСЛОВА (зміна 172). Обидва
# відповідають на різні питання звіту: «що з чим повʼязано» і «де робота
# стоїть». Заганяти їх у `task.changed` означало б втратити рівно ту
# аналітику, заради якої протокол і будувався.
A_TASK_LINKED = "task.linked"
A_TASK_UNLINKED = "task.unlinked"
A_TASK_OVERDUE = "task.overdue"
# ⭐ ЗАКРИТТЯ — ОКРЕМЕ ДІЄСЛОВО (зміна 173, 14.08.2026). Слово Андрія: рейтинг
# підрозділу тримається на «відсотку своєчасного виконання». Стадія «Виконана»
# і досі приїжджала як `task.changed` із приміткою ТЕКСТОМ — рахувати відсоток
# по підрядку в примітці означало б порушити власний закон «чек по рядку в
# тексті фальшивий». Тому «вчасно / із запізненням» стає ФАКТОМ рядка.
A_TASK_DONE = "task.done"
A_PARTY_CREATED = "party.created"
A_PARTY_CHANGED = "party.changed"
A_PARTY_DELETED = "party.deleted"
A_PARTY_INBOUND = "party.inbound"
A_PARTY_HISTORY = "party.history"
A_PARTY_UPDATE = "party.update_sent"
# ⭐⭐⭐ 779 (12.10.2026): ЗЛИТТЯ — СВОЄ ДІЄСЛОВО. Дубль не «змінено» і не «прибрано»: усе його переїхало в основну
# картку, а сам він лишився в архіві з позначкою «злито в». Рядок пишеться про ОСНОВНУ з дублем в `about` — тому
# він стоїть у стрічках обох карток.
A_PARTY_MERGED = "party.merged"
A_CONNECTOR_CALL = "connector.call"
A_MONEY_SPENT = "money.spent"
# ⭐⭐⭐ ЗВʼЯЗОК — СВОЄ ДІЄСЛОВО (крок B2, 14.08.2026). Досі звʼязок умів заводити
# лише Task Desk, і дієслово так і звалось — `task.linked`. Тепер факт звʼязку
# живе у власному реєстрі (`links.py`) і буває між БУДЬ-ЯКИМИ сутностями: угода
# ↔ контакт, заявка ↔ договір. Писати про них «задачу звʼязано» означало б
# збрехати у звіті про те, що саме сталось.
# ⛒ СТАРІ ДІЄСЛОВА ЛИШАЮТЬСЯ У СЛОВНИКУ НАЗАВЖДИ. Журнал append-only не
# переписують: рядки від 13-14.08 мусять читатись і за рік.
A_LINK_CREATED = "link.created"
A_LINK_REMOVED = "link.removed"
# ⭐ 779: звʼязок ПЕРЕВЕДЕНО з дубля на основну картку (злиття). Це не «прибрано» і не «заведено»: той самий
# звʼязок, з тим самим підписом і автором, тепер веде до основної.
A_LINK_MOVED = "link.moved"
# ⭐⭐⭐ УГОДА — СВОЇ ДІЄСЛОВА (крок C1, 15.08.2026). Досі рух угоди взагалі
# не потрапляв у журнал: угода не була сутністю, і стадія мінялась усередині
# картки клієнта мовчки. СТАДІЯ — ОКРЕМЕ ДІЄСЛОВО від звичайної зміни:
# саме на ній тримається весь аналіз воронки, а шукати зміну стадії підрядком
# у примітці означало б порушити власний закон «чек по рядку в тексті фальшивий».
A_CARD_FILLED = "card.filled"
A_CARD_CLEARED = "card.cleared"
A_FIELD_CREATED = "field.created"
A_FIELD_CHANGED = "field.changed"
A_FIELD_OFF = "field.off"
A_GOOD_CREATED = "good.created"
A_GOOD_CHANGED = "good.changed"
A_GOOD_ARCHIVED = "good.archived"
A_DEAL_CREATED = "deal.created"
A_DEAL_CHANGED = "deal.changed"
A_DEAL_STAGE = "deal.stage"
A_DEAL_DELETED = "deal.deleted"
# ⭐⭐⭐ 535: ПОЗИЦІЇ УГОДИ. Слід про них іде в ЦЕЙ журнал, а не в
# другий поруч: історія угоди має лишатись однією стрічкою.
# ⭐ 585 (16.09.2026): документи угоди — договір, рахунок, акт.
A_DEAL_DOC_ADDED = "deal.doc_added"
A_DEAL_DOC_REMOVED = "deal.doc_removed"
# ⭐⭐⭐ 625 (21.09.2026): ЗАМІНА ПАПЕРУ. Документ лишається тим самим
# (id, тип, номер), міняється його файл — нова редакція того самого
# договору. Окреме дієслово, бо «причеплено» і «відчеплено» тут брехали б:
# у картці нічого не додалось і нічого не зникло.
A_DEAL_DOC_RESTATED = "deal.doc_restated"
# ⭐⭐⭐ 662 (30.09.2026): ВИПРАВЛЕНО ЗАПИС НОМЕРА. Папір і файл ті самі; хибним
# був лише запис номера (номер контрагента лежав у нашій формі). Не «нова
# редакція» — паперу ніхто не міняв.
A_DEAL_DOC_RENUMBERED = "deal.doc_renumbered"
# ⭐⭐⭐ 648 (26.09.2026): ДОКУМЕНТИ КЛІЄНТА (статут, витяг, довіреність) живуть у
# його картці й беруться в угоду без копії файла.
A_PARTY_DOC_ADDED = "party.doc_added"
A_PARTY_DOC_REMOVED = "party.doc_removed"
A_DEAL_DOC_TAKEN = "deal.doc_taken"
A_DEAL_ITEM_ADDED = "deal.item_added"
A_DEAL_ITEM_CHANGED = "deal.item_changed"
A_DEAL_ITEM_REMOVED = "deal.item_removed"
# ⭐⭐⭐ ЛИСТУВАННЯ З АДРЕСОЮ УГОДИ (крок C2, 15.08.2026). «Сформовано» і
# «надіслано» — РІЗНІ факти: пошту шле поштова програма людини, тому чужого
# факту на себе не беремо. А «чекає на рознесення» — теж окремий факт: це
# обіцянка людині, що лист не загубився, поки адреси в ньому немає.
A_DEAL_MAIL_OUT = "deal.mail_out"
A_DEAL_MAIL_IN = "deal.mail_in"
A_DEAL_MAIL_PARKED = "deal.mail_parked"
# ⭐ 613. МІСТОК «КАРТКА → КП»: одне дієслово на всі його кінці —
# вдало, спинено суддею, відмовлено правами. Решту каже `outcome` і слова.
A_DEAL_KP = "deal.kp"

# ⭐ 616: МАГАЗИН. Два дієслова, бо це дві РІЗНІ події: документ сформовано —
# факт платформи; передано поштовій програмі — момент, коли справа вийшла з
# наших рук. Одним дієсловом їх не злити: тоді журнал не відповість, чи лист
# узагалі полетів.
A_SHOP_ORDER = "shop.order"
A_SHOP_HANDED = "shop.handed"

# ⭐⭐⭐ ОРГСТРУКТУРА (зміна 360, 30.08.2026) — ОСТАННІЙ ДОМЕН, ЯКИЙ ПИСАВ
# ПОВЗ ПРОТОКОЛ. Він вів власний слід усередині файла стану: зі стелею в
# 200 записів, без імені того, хто діяв, і без жодного читача. Три біди —
# один корінь: домен не мав спільного журналу. Тепер має, і всі три
# зникають разом: протокол нічого не викидає, «хто» — його поле, а історію
# компанії читає екран `/history`.
A_ORG_UNIT_CREATED = "org.unit_created"
A_ORG_UNIT_MOVED = "org.unit_moved"
A_ORG_UNIT_HEAD = "org.unit_head"
A_ORG_UNIT_LIQUIDATED = "org.unit_liquidated"
A_ORG_UNIT_RESTORED = "org.unit_restored"
A_ORG_UNIT_HORIZON = "org.unit_horizon"
A_ORG_HORIZON = "org.horizon_changed"
A_ORG_POSITION_CREATED = "org.position_created"
# ⭐⭐⭐ 626е (22.09.2026): ВИПРАВЛЕННЯ ІМЕНІ. У сутності було народження і
# смерть, а виправлення не було: помилка в назві («Комірційний директор» у
# ТОВ «КАСПЕР УКРАЇНА») лишалась назавжди.
A_ORG_UNIT_RENAMED = "org.unit_renamed"
A_ORG_POSITION_RENAMED = "org.position_renamed"
A_ORG_POSITION_ARCHIVED = "org.position_archived"
A_ORG_POSITION_RESTORED = "org.position_restored"
A_ORG_EMP_HIRED = "org.employee_hired"
A_ORG_EMP_CHANGED = "org.employee_changed"
A_ORG_EMP_DISMISSED = "org.employee_dismissed"
A_ORG_EMP_RESTORED = "org.employee_restored"
A_ORG_ABSENCE_SET = "org.absence_set"
A_ORG_ABSENCE_CLEAR = "org.absence_clear"
# ⛒ ОКРЕМЕ ДІЄСЛОВО ДЛЯ ПЕРЕНЕСЕНИХ ЗАПИСІВ. Старий слід не знає, ХТО діяв,
# і не знає, ЩО саме за дія це була. Приписати їм сьогоднішнє дієслово
# означало б збрехати в журналі; лишити поза журналом — загубити роки історії.
A_ORG_LEGACY = "org.legacy"
# ⭐ 659: бюджет і вимикачі ШІ — рішення адміністратора клієнта про ГРОШІ.
# Хто і коли змінив межу, мусить бути видно так само, як хто змінив структуру.
A_AI_BUDGET = "ai.budget_changed"

# ⭐⭐⭐ 663 (30.09.2026). ЖУРНАЛ БЕЗПЕКИ — РОДИНА ДІЄСЛІВ ЦЬОГО Ж ПРОТОКОЛУ.
# 🩸 Доти вхід, невдала спроба і вихід не лишали сліду взагалі, а зміни
# облікових записів і ролей лягали куцим списком усередині їхніх файлів — без
# «хто», без «звідки», без «було → стало». ОТУ (лист ІТ/СБ) питає саме це.
# ⛒ НЕ ДРУГИЙ ЖУРНАЛ ПОРУЧ: той самий писар, той самий чистильник секретів,
# той самий файл невдач. Пишуть їх двері входу (`taskdesk_identity.login`,
# `logout`) і ЄДИНІ ПИСАРІ облікових записів і ролей — через `security_log`.
A_AUTH_LOGIN = "auth.login"
A_AUTH_FAILED = "auth.login_failed"
A_AUTH_LOGOUT = "auth.logout"
A_ACC_CREATED = "account.created"
A_ACC_CHANGED = "account.changed"
# ⛒ Пароль — своє дієслово і БЕЗ значень: «було → стало» тут не існує.
A_ACC_PASSWORD = "account.password"
A_ACC_REMOVED = "account.removed"
A_ROLE_CREATED = "role.created"
A_ROLE_CHANGED = "role.changed"
A_ROLE_ASSIGNED = "role.assigned"
# ⭐ 665: пауза після невдалих спроб — ОДИН рядок на паузу, а не на кожне
# стукання під нею (інакше перебір заливав би журнал).
A_AUTH_LOCKED = "auth.locked"
# ⭐ 666: двофакторний вхід. ⛒ Жоден рядок не несе ні таємниці, ні коду:
# «підключено / скинуто / коди видано / вимогу змінено» — і хто.
A_TFA_ON = "second_factor.on"
A_TFA_OFF = "second_factor.off"
A_TFA_CODES = "second_factor.codes"
A_TFA_POLICY = "second_factor.policy"
# ⭐ 669: вивантаження даних (задачі, клієнтська база) і відмова в ньому —
# хто, що, скільки рядків. Самих даних рядок не несе.
A_DATA_EXPORT = "data.export"
# ⭐ 685: скринька, з якої платформа шле сповіщення працівникам, — заведено,
# змінено чи відключено. Пароля рядок не несе — лише факт його зміни.
A_NOTIFY_MAIL = "notify_mail.set"
# ⭐ 696: лист доступу працівнику (адреса, логін, разове посилання) — пішов чи ні
# і чому. Токена посилання рядок не несе ніколи.
A_ACC_LETTER = "account.access_letter"
# ⭐ 696: адреса для працівників і довірений проксі — було → стало. Кому
# платформа вірить заголовок «справжня адреса людини» — питання безпеки.
A_ACCESS_SETTINGS = "access.settings"
# ⭐ 790: підключення до Alldevice клієнта (адреса, користувач, пароль, ключ API) —
# заведено, змінено чи відключено. Пароля й ключа рядок не несе — лише факт зміни.
A_ALLDEVICE = "alldevice.set"
# ⭐ 797: запит на зміну прийшов із чужої сторінки (захист від підробки запиту) —
# звідки і куди. Куки й тіла запиту рядок не несе.
A_FOREIGN_ORIGIN = "request.foreign_origin"
# ⭐ 816: перезапуск платформи з налаштувань (адміністратор) — і відмова, коли наглядача немає.
A_PLATFORM_RESTART = "platform.restart"

# Дієслова безпеки одним переліком: за ним екран журналу безпеки (664)
# відбирає рядки, і за ним же проба бачить, що жодне не лишилось без назви.
SECURITY_ACTIONS = (A_AUTH_LOGIN, A_AUTH_FAILED, A_AUTH_LOGOUT, A_AUTH_LOCKED,
                    A_ACC_CREATED, A_ACC_CHANGED, A_ACC_PASSWORD, A_ACC_REMOVED,
                    A_ROLE_CREATED, A_ROLE_CHANGED, A_ROLE_ASSIGNED,
                    A_TFA_ON, A_TFA_OFF, A_TFA_CODES, A_TFA_POLICY,
                    A_DATA_EXPORT, A_NOTIFY_MAIL, A_ACC_LETTER, A_ACCESS_SETTINGS,
                    A_ALLDEVICE, A_FOREIGN_ORIGIN, A_PLATFORM_RESTART)

# Дієслова оргструктури одним переліком: за ним екран історії відбирає рядки,
# і за ним же чек бачить, що жодне з них не лишилось без назви.
ORG_ACTIONS = (A_ORG_UNIT_CREATED, A_ORG_UNIT_MOVED, A_ORG_UNIT_HEAD,
               A_ORG_UNIT_LIQUIDATED, A_ORG_UNIT_RESTORED, A_ORG_UNIT_HORIZON,
               A_ORG_HORIZON, A_ORG_POSITION_CREATED, A_ORG_UNIT_RENAMED,
               A_ORG_POSITION_RENAMED, A_ORG_POSITION_ARCHIVED,
               A_ORG_POSITION_RESTORED, A_ORG_EMP_HIRED,
               A_ORG_EMP_CHANGED, A_ORG_EMP_DISMISSED, A_ORG_EMP_RESTORED,
               A_ORG_ABSENCE_SET, A_ORG_ABSENCE_CLEAR, A_ORG_LEGACY)

ACTIONS = {
    A_RUN_FINISHED: "прогін завершився",
    A_RUN_EVENT: "подія прогону",
    A_RUN_REFUSED: "робота не відбулась",
    A_TASK_CREATED: "задачу створено",
    A_TASK_CHANGED: "задачу змінено",
    A_TASK_LINKED: "задачу звʼязано",
    A_TASK_UNLINKED: "звʼязок задачі прибрано",
    A_TASK_OVERDUE: "строк задачі минув",
    A_TASK_DONE: "задачу виконано",
    A_PARTY_CREATED: "контрагента заведено",
    A_PARTY_CHANGED: "картку контрагента змінено",
    A_PARTY_DELETED: "контрагента прибрано з довідника",
    A_PARTY_INBOUND: "вхідне від контрагента",
    A_PARTY_HISTORY: "запис в історію контрагента",
    A_PARTY_UPDATE: "контрагенту направлено оновлення",
    A_PARTY_MERGED: "картку контрагента злито з основною",
    A_CONNECTOR_CALL: "звернення до чужого сервісу",
    A_MONEY_SPENT: "витрачено грошей",
    A_LINK_CREATED: "сутності звʼязано",
    A_LINK_REMOVED: "звʼязок прибрано",
    A_LINK_MOVED: "звʼязок переведено на основну картку",
    A_CARD_FILLED: "поле картки заповнено",
    A_CARD_CLEARED: "значення поля картки прибрано",
    A_FIELD_CREATED: "поле картки оголошено",
    A_FIELD_CHANGED: "поле картки змінено",
    A_FIELD_OFF: "поле картки виведено з роботи або повернено",
    A_GOOD_CREATED: "товар заведено",
    A_GOOD_CHANGED: "картку товару змінено",
    A_GOOD_ARCHIVED: "товар прибрано з обігу або повернено",
    A_DEAL_CREATED: "угоду заведено",
    A_DEAL_CHANGED: "угоду змінено",
    A_DEAL_STAGE: "стадію угоди змінено",
    A_DEAL_DELETED: "угоду прибрано",
    A_DEAL_DOC_ADDED: "документ причеплено до угоди",
    A_DEAL_DOC_REMOVED: "документ відчеплено від угоди",
    A_DEAL_DOC_RESTATED: "папір документа замінено новою редакцією",
    A_DEAL_DOC_RENUMBERED: "запис номера документа виправлено",
    A_PARTY_DOC_ADDED: "документ клієнта покладено в його картку",
    A_PARTY_DOC_REMOVED: "документ клієнта прибрано з картки",
    A_DEAL_DOC_TAKEN: "документ клієнта взято в угоду",
    A_DEAL_ITEM_ADDED: "позицію додано в угоду",
    A_DEAL_ITEM_CHANGED: "позицію угоди змінено",
    A_DEAL_ITEM_REMOVED: "позицію прибрано з угоди",
    A_DEAL_MAIL_OUT: "лист із угоди сформовано",
    A_DEAL_MAIL_IN: "вхідне лягло в угоду",
    A_DEAL_MAIL_PARKED: "вхідне чекає на рознесення",
    A_DEAL_KP: "комерційну пропозицію з картки",
    A_SHOP_ORDER: "замовлення розробнику сформовано",
    A_SHOP_HANDED: "замовлення передано поштовій програмі",
    A_ORG_UNIT_CREATED: "підрозділ заведено",
    A_ORG_UNIT_MOVED: "підрозділ переміщено",
    A_ORG_UNIT_HEAD: "керівника підрозділу змінено",
    A_ORG_UNIT_LIQUIDATED: "підрозділ ліквідовано",
    A_ORG_UNIT_RESTORED: "підрозділ відновлено",
    A_ORG_UNIT_HORIZON: "підрозділ поставлено на горизонт",
    A_ORG_HORIZON: "горизонт змінено",
    A_ORG_POSITION_CREATED: "посаду заведено",
    A_ORG_UNIT_RENAMED: "підрозділ перейменовано",
    A_ORG_POSITION_RENAMED: "посаду перейменовано",
    A_ORG_POSITION_ARCHIVED: "посаду прибрано з переліку",
    A_ORG_POSITION_RESTORED: "посаду повернуто з архіву",
    A_ORG_EMP_HIRED: "працівника заведено",
    A_ORG_EMP_CHANGED: "картку працівника змінено",
    A_ORG_EMP_DISMISSED: "працівника звільнено",
    A_ORG_EMP_RESTORED: "працівника поновлено",
    A_ORG_ABSENCE_SET: "відсутність заведено",
    A_ORG_ABSENCE_CLEAR: "період відсутності прибрано",
    A_ORG_LEGACY: "зміна структури (записана до ведення авторства)",
    A_AI_BUDGET: "бюджет і вимикачі ШІ змінено",
    A_AUTH_LOGIN: "вхід у платформу",
    A_AUTH_FAILED: "невдала спроба входу",
    A_AUTH_LOGOUT: "вихід із платформи",
    A_ACC_CREATED: "обліковий запис заведено",
    A_ACC_CHANGED: "доступи облікового запису змінено",
    A_ACC_PASSWORD: "пароль облікового запису змінено",
    A_ACC_REMOVED: "обліковий запис прибрано",
    A_ROLE_CREATED: "роль доступу заведено",
    A_ROLE_CHANGED: "права ролі змінено",
    A_ROLE_ASSIGNED: "роль призначено або знято",
    A_AUTH_LOCKED: "вхід призупинено після невдалих спроб",
    A_TFA_ON: "двофакторний вхід підключено",
    A_TFA_OFF: "двофакторний вхід вимкнено або скинуто",
    A_TFA_CODES: "резервні коди видано заново",
    A_TFA_POLICY: "вимогу двофакторного входу змінено",
    A_DATA_EXPORT: "дані вивантажено",
    A_NOTIFY_MAIL: "пошту для сповіщень змінено",
    A_ACC_LETTER: "лист доступу працівнику",
    A_ACCESS_SETTINGS: "адресу для працівників або довірений проксі змінено",
    A_ALLDEVICE: "підключення до Alldevice змінено",
    A_FOREIGN_ORIGIN: "запит із чужої сторінки відхилено",
    A_PLATFORM_RESTART: "платформу перезапущено з налаштувань",
}

# ── Чим скінчилось ───────────────────────────────────────────────────────────
OUT_OK = "ok"
OUT_REFUSED = "refused"          # платформа свідомо не стала робити (ворота, брак даних)
OUT_FAILED = "failed"            # спробувала і зламалась
OUT_STOPPED = "stopped"          # обірвано межею (гроші, час, людина натиснула «Стоп»)
# ⭐ «ІЗ ЗАПІЗНЕННЯМ» — ОКРЕМИЙ ПІДСУМОК (зміна 173, 14.08.2026). Робота
# ВІДБУЛАСЬ, тому це не `stopped` і не `failed`; але зарахувати її в `ok`
# означало б завищити виконавську дисципліну — а «відсоток своєчасного
# виконання» Андрій назвав головною мірою підрозділу.
# ⛒ І ЖИВЕ ВОНО САМЕ ТУТ, У ЗАКРИТОМУ СЛОВНИКУ, А НЕ СЛОВАМИ В ПРИМІТЦІ:
# відсоток, порахований пошуком підрядка в тексті, поїде від першого ж
# переписаного формулювання. Це наш власний закон «чек по рядку — фальшивий».
OUT_LATE = "late"
OUTCOMES = (OUT_OK, OUT_REFUSED, OUT_FAILED, OUT_STOPPED, OUT_LATE)
OUTCOME_NAMES = {OUT_OK: "виконано", OUT_REFUSED: "відмова",
                 OUT_FAILED: "поломка", OUT_STOPPED: "обірвано",
                 OUT_LATE: "виконано із запізненням"}

# ── Звідки прийшла робота ────────────────────────────────────────────────────
# Словник закритий заради звіту («звідки береться робота» — питання №1 Андрія).
# Але СИРИЙ канал не губиться: незнайомий лягає як `other` + `source_raw`.
# Це не тиха підстановка: обидва значення видно в тому самому рядку.
S_CONSOLE = "human.console"
S_TELEGRAM = "telegram"
S_MAIL = "mail"
S_SCHEDULE = "schedule"
S_SYSTEM = "system"
S_OTHER = "other"
SOURCES = (S_CONSOLE, S_TELEGRAM, S_MAIL, S_SCHEDULE, S_SYSTEM, S_OTHER)
SOURCE_NAMES = {S_CONSOLE: "людина в консолі", S_TELEGRAM: "телеграм",
                S_MAIL: "пошта", S_SCHEDULE: "розклад",
                S_SYSTEM: "сама платформа", S_OTHER: "інше"}

_SOURCE_MAP = {
    "chat": S_CONSOLE, "console": S_CONSOLE, "human": S_CONSOLE,
    "human.console": S_CONSOLE, "ui": S_CONSOLE, "web": S_CONSOLE,
    "telegram": S_TELEGRAM, "tg": S_TELEGRAM,
    "mail": S_MAIL, "email": S_MAIL, "gmail": S_MAIL,
    "schedule": S_SCHEDULE, "scheduler": S_SCHEDULE, "automation": S_SCHEDULE,
    "system": S_SYSTEM, "platform": S_SYSTEM,
}

MAX_REASON = 300                  # причина словами, а не текст результату
# ⭐ 663: «було → стало» — поле рядка, а не текст у примітці: екран і звіт
# читають його як дані, а не шукають підрядок.
MAX_CHANGE_FIELD = 80
MAX_CHANGE_VALUE = 160
MAX_CHANGES = 40


class ProtocolError(Exception):
    """Відмова з причиною словами. Ловиться всередині `write` — назовні не летить."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ── ОДИН ПИСАР ПРИБИРАННЯ СЕКРЕТІВ ───────────────────────────────────────────
# ⭐ 13.08.2026. Правило жило всередині `audit._scrub`. Поки писар один — усе
# гаразд; але поява ДРУГОГО журналу (цього) означала б і другий чистильник, а два
# чистильники розходяться — і одного дня ключ виїде тим, що новіший. Тому правда
# переїхала сюди, а `audit._scrub` став тонким викликом.
SECRET_HINTS = ("sk-", "api_key", "apikey", "token=", "bearer ", "aiza", "ghp_",
                "secret_", "client_secret", "refresh_token", "password=")

SECRET_MASK = "[приховано: можливий секрет у тексті]"


def scrub(text, limit: int = 160) -> str:
    """Обрізати до безпечної довжини і прибрати рядок, схожий на ключ.

    Обрізаємо ДО перевірки — рівно як робив `audit._scrub`, щоб поведінка журналу
    прогонів не змінилась ні на знак."""
    t = _s(text)[:limit] if limit else _s(text)
    low = t.lower()
    if any(h in low for h in SECRET_HINTS):
        return SECRET_MASK
    return t


# ── КОНТЕКСТ ПОТОЧНОЇ РОБОТИ ─────────────────────────────────────────────────
# ⭐ НАВІЩО. Гроші рахує `costs`, який не знає ні клієнта, ні задачі; задачу знає
# Task Desk, який не знає ціни. Якби кожен домен ДОПИСУВАВ чуже поле собі у файл —
# це були б ті самі три копії однієї правди, від яких ми тікали. Тому домени
# лишаються при своєму, а спільне «над чим ми зараз працюємо» живе тут, у памʼяті
# потоку, і доклеюється до рядка протоколу в момент запису.
# ⚠ Це НЕ сховище: у файл контекст не лягає, між потоками не ділиться і гине
# разом із прогоном (`clear()` кличе `costs.end_run`).
_local = threading.local()

# ⭐ 663: `ip` — ЗВІДКИ прийшов запит (адреса машини). Кладуть її ворота
# сервера в одному місці на всі двері, так само як «хто»; обробники про неї
# не знають і знати не мусять.
CONTEXT_KEYS = ("actor", "source", "party", "task", "run", "ip")


def context() -> dict:
    return dict(getattr(_local, "ctx", None) or {})


def bind(**kw) -> dict:
    """Додати до контексту те, що щойно стало відомим. Невідомий ключ — ігнор.

    ⚠ ПРОГІН НЕ ЗАТИРАЄ ПОПЕРЕДНІЙ. Один крок роботи людини легко запускає дві-три
    системи. Якби кожна нова затирала попередню, ціна кроку мовчки приписалась би
    ОСТАННЬОМУ прогону — тобто журнал показав би дорогим той, що майже нічого не
    робив. Тому головним лишається ПЕРШИЙ, а всі решта памʼятаються поруч."""
    ctx = context()
    for k, v in kw.items():
        if k not in CONTEXT_KEYS:
            continue
        v = _s(v)
        if not v:
            continue
        if k == "run":
            seen = list(ctx.get("_runs") or [])
            if v not in seen:
                seen.append(v)
            ctx["_runs"] = seen
            ctx.setdefault("run", v)
            continue
        ctx[k] = v
    _local.ctx = ctx
    return dict(ctx)


def runs_seen() -> list:
    """Усі прогони цього кроку роботи (у порядку появи)."""
    return list(context().get("_runs") or [])


# ⛒⛒⛒ ДВА РІЗНІ ЗАБУВАННЯ, І ПЛУТАТИ ЇХ НЕ МОЖНА (зміна 542, 09.09.2026).
# «Над чим я зараз працюю» (контрагент, задача, прогін) належить КРОКУ РОБОТИ і
# мусить забуватись, коли крок скінчився. «Хто цей запит почав» належить
# ЗАПИТУ: воно не змінюється від того, що всередині відкрився новий крок.
# 🩸 Доти обидва стирались однією рукою — і кожен хід чату починався з того, що
# платформа забувала людину, яку сервер щойно назвав. У бойовому журналі це
# видно: 117 рядків про роботу і 25 про гроші стоять БЕЗ ІМЕНІ.
# ⭐ 663: адреса належить ЗАПИТУ так само, як людина: новий крок роботи
# усередині запиту не робить його прибульцем нізвідки.
KEEP_ACROSS_STEPS = ("actor", "ip")


def new_step() -> dict:
    """ПОЧАВСЯ КРОК РОБОТИ: забути крок, ПАМʼЯТАТИ людину.

    ⛒ Кличе той, хто відкриває КРОК (лічильник грошей). Хто відкриває ЗАПИТ
    (сервер, телеграм) — кличе `clear()` і починає з чистого аркуша."""
    keep = {k: v for k, v in context().items()
            if k in KEEP_ACROSS_STEPS and _s(v)}
    _local.ctx = keep
    return dict(keep)


def clear() -> None:
    """Кінець прогону. Інакше «поточна задача» протекла б у наступний прогін і
    журнал почав би приписувати роботу не тому клієнту."""
    _local.ctx = {}


def forget_actor() -> None:
    """Забути саме людину — для каналу, який починає працювати ВІД ІНШОГО."""
    ctx = context()
    ctx.pop("actor", None)
    _local.ctx = ctx


# ⭐⭐⭐ 659 (30.09.2026). РОБОТА, ПЕРЕДАНА В ІНШИЙ ПОТІК, НЕСЕ СВОЇ «ХТО І ЗВІДКИ».
# 🩸 Контекст живе в памʼяті ПОТОКУ. Мозок Task Desk думає в окремому потоці на
# повідку — і там людина зникала: витрати його моделі не мали ні імені, ні
# прогону (сотні рядків «КАНАЛ БЕЗ ЛІЧИЛЬНИКА: complete» у журналі сервера).
# ⛒ КЛАС, А НЕ ЛАТКА: будь-який потік продукту або несе знімок контексту того,
# хто його запустив (`carried`), або є СЛУЖБОВИМ ЦИКЛОМ, що сам називає себе й
# людину на кожному кроці, — і тоді стоїть у переліку нижче з причиною.
# Проба 659 судить кожен `threading.Thread` у продукті за цим законом.
def carried(fn):
    """Обгорнути роботу для іншого потоку: у ньому діятиме ТОЙ САМИЙ контекст,
    що й у потоці, який її запустив (знімок, а не спільний обʼєкт)."""
    snap = context()

    def _run(*a, **kw):
        _local.ctx = dict(snap)
        try:
            return fn(*a, **kw)
        finally:
            _local.ctx = {}
    return _run


SERVICE_LOOPS = {
    "server._scheduler_loop": "розклад автоматизацій: кожна задача сама називає "
                              "свого власника (`engine.automation_runner`, 542)",
    "taskdesk_overdue.loop": "сторож строків пише факти від імені платформи; "
                             "людини-ініціатора в нього немає за природою",
    "taskdesk_digest.loop": "щоденне зведення — робота платформи за годинником, "
                            "адресатів бере з довідника, а не з запиту",
    # ⭐ 739: вечірній контроль — те саме: годинник, довідник, до моделі не ходить.
    "taskdesk_evening.loop": "вечірній контроль — робота платформи за годинником (після 18:00), "
                             "адресатів бере з довідника; до моделі не ходить",
    "taskdesk_telegram._loop": "доставка задач у телеграм: лише надсилає чергу "
                               "повідомлень, до моделі не ходить",
    # ⭐ 693: потік 686 сюди не прийшов — виловила ніч 03.10.2026.
    "taskdesk_email._loop": "доставка задач поштою (686): лише надсилає чергу листів, "
                            "до моделі не ходить",
    "telegram_bot._loop": "бот платформи: кожне повідомлення саме називає людину "
                          "(`protocol.bind(actor=…)` на вході повідомлення)",
    "mail_intake.loop": "приймання пошти за годинником: до моделі не ходить, "
                        "контексту запиту тут не існує",
    "keepawake._loop": "не дає машині заснути; до моделі й до людей не ходить "
                       "зовсім",
}


@contextlib.contextmanager
def step(**kw):
    """КРОК, ПІСЛЯ ЯКОГО КОНТЕКСТ ПОВЕРТАЄТЬСЯ ЯКИМ БУВ (зміна 362, 30.08.2026).

    ⭐ НАВІЩО. Веб-сервер багатопотоковий і тримає зʼєднання відкритим: один
    потік обслуговує кілька запитів підряд. Якби двері просто робили `bind`,
    наступний запит на тому самому потоці мовчки приписався б попередній людині
    — той самий клас помилки, що й ціна кроку, приписана чужому прогону.
    А `clear()` тут не годиться: він витер би й прогін, усередині якого запит
    може жити.

    ⛒ Повертаємо ПОПЕРЕДНІЙ знімок, а не «прибираємо своє»: вкладені кроки
    тоді самі складаються правильно, і жодне поле не треба перелічувати."""
    before = context()
    try:
        bind(**kw)
        yield context()
    finally:
        _local.ctx = dict(before)


# ── Перевірка рядка ──────────────────────────────────────────────────────────
def norm_source(raw) -> tuple:
    """(канонічне джерело, сирий рядок якщо він не з словника)."""
    r = _s(raw)
    if not r:
        return "", ""
    low = r.lower()
    if low in SOURCES:
        return low, ""
    if low in _SOURCE_MAP:
        return _SOURCE_MAP[low], ""
    head = low.split("/")[0].split(":")[0].split("-")[0].strip()
    if head in _SOURCE_MAP:
        return _SOURCE_MAP[head], r
    return S_OTHER, r


def split_outcome(value) -> tuple:
    """«refused: немає доступу до пошти» → ("refused", "немає доступу до пошти")."""
    v = _s(value) or OUT_OK
    kind, _sep, reason = v.partition(":")
    kind = _s(kind).lower()
    if kind not in OUTCOMES:
        raise ProtocolError(
            "Невідомий підсумок «%s». Платформа знає лише: %s. Новий підсумок "
            "заводиться у словнику `protocol.OUTCOMES`, інакше звіт мовчки "
            "порахує поломку успіхом." % (kind, ", ".join(OUTCOMES)))
    return kind, scrub(reason, MAX_REASON)


def norm_changes(changes) -> list:
    """⭐ 663. «Було → стало» як дані: [{field, before, after}, ...].

    Приймає пари-трійки або словники. ⛒ Зміна без різниці — відмова: рядок
    «так → так» — це шум, що ховає справжні зміни. ⛒ Значення проходять той
    самий чистильник секретів, що й причина."""
    out = []
    for c in (changes or []):
        if isinstance(c, dict):
            f, b, a = c.get("field"), c.get("before"), c.get("after")
        elif isinstance(c, (list, tuple)) and len(c) == 3:
            f, b, a = c
        else:
            raise ProtocolError("Зміна «%s» не читається: потрібні поле, було і "
                                "стало." % (_s(c)[:60],))
        f = scrub(f, MAX_CHANGE_FIELD)
        if not f:
            raise ProtocolError("Зміна без назви поля: не видно, ЩО змінилось.")
        b, a = scrub(b, MAX_CHANGE_VALUE), scrub(a, MAX_CHANGE_VALUE)
        if b == a:
            raise ProtocolError("Зміна поля «%s» без різниці («%s» → «%s») — це не "
                                "зміна." % (f, b, a))
        out.append({"field": f, "before": b, "after": a})
    if len(out) > MAX_CHANGES:
        raise ProtocolError("Забагато змін в одному рядку (%d, межа %d): це вже "
                            "не дія, а вивантаження." % (len(out), MAX_CHANGES))
    return out


def norm_ip(value) -> str:
    """⭐ 663. Адреса машини, з якої прийшов запит. Не адреса — відмова:
    у журнал безпеки не лягає текст, схожий на адресу."""
    v = _s(value)
    if not v:
        return ""
    import ipaddress
    try:
        return str(ipaddress.ip_address(v))
    except ValueError:
        raise ProtocolError("«%s» не є адресою машини." % scrub(v, 60))


def validate(action: str, subject, actor="", about=None, outcome=OUT_OK,
             cost_usd=0.0, source="", note="", changes=None, ip="") -> dict:
    """Зібрати чистий рядок або ВІДМОВИТИ з причиною словами.

    Окрема від `write` навмисно: `write` не сміє кидати (журнал не валить роботу),
    а чек мусить БАЧИТИ причину відмови, а не порожній False."""
    act = _s(action)
    if act not in ACTIONS:
        raise ProtocolError(
            "Невідома дія «%s». Платформа знає лише: %s. Нове дієслово заводиться "
            "у словнику `protocol.ACTIONS` свідомо — інакше воно мовчки підміниться "
            "сусіднім, і звіт покаже не те, що сталось." % (act, ", ".join(sorted(ACTIONS))))

    subj = entity.norm(subject)            # невідомий вид сутності — відмова

    seen = []
    for r in (about or []):
        n = entity.norm(r)
        if n != subj and n not in seen:
            seen.append(n)

    act_ref = _s(actor)
    if act_ref:
        k, _i = entity.parse(act_ref)
        if k not in (entity.KIND_PERSON, entity.KIND_SYSTEM):
            raise ProtocolError(
                "Діяч може бути лише людиною або системою, а не %s («%s»). "
                "Контрагент нічого не робить у платформі — він той, ПРО кого дія."
                % (entity.KIND_NAMES[k], act_ref))
        act_ref = entity.norm(act_ref)

    out_kind, reason = split_outcome(outcome)

    try:
        usd = round(float(cost_usd or 0.0), 6)
    except Exception:
        raise ProtocolError("Ціна «%s» не є числом: журнал грошей не вгадує." % cost_usd)
    if usd < 0:
        raise ProtocolError("Відʼємна ціна %s у журналі неможлива." % usd)

    src, src_raw = norm_source(source)

    rec = {
        "at": clock.now(),
        "action": act,
        "actor": act_ref,
        "subject": subj,
        "about": seen,
        "outcome": out_kind,
        "reason": reason,
        "cost_usd": usd,
        "source": src,
    }
    if src_raw:
        rec["source_raw"] = scrub(src_raw, 80)
    n = scrub(note, MAX_REASON)
    if n:
        rec["note"] = n
    # ⭐ 663: поля зʼявляються лише тоді, коли вони є, — старі рядки й старі
    # читачі їх не бачать і не мусять.
    chs = norm_changes(changes)
    if chs:
        rec["changes"] = chs
    where = norm_ip(ip)
    if where:
        rec["ip"] = where
    return rec


# ── Запис ────────────────────────────────────────────────────────────────────
def path_of(action) -> object:
    """⭐ 663. Куди лягає рядок: родина безпеки — у свій файл, решта — у
    загальний протокол. Одне місце, яке це вирішує, — і для запису, і для читання."""
    return _SEC_PATH if _s(action) in SECURITY_ACTIONS else _PATH


def _append(path, rec) -> bool:
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
        return True
    except Exception:
        return False


def _fail(reason: str, raw: dict) -> None:
    """Відхилений рядок не зникає мовчки — він лягає у власний файл невдач.

    Саме тому `write` може не кидати і все одно не бути тихим."""
    _append(_FAIL_PATH, {"at": _now_safe(), "reason": _s(reason)[:400],
                         "raw": {k: _s(v)[:200] for k, v in (raw or {}).items()}})


def _now_safe() -> str:
    try:
        return clock.now()
    except Exception:
        return ""


def write(action: str, subject, actor="", about=None, outcome=OUT_OK,
          cost_usd=0.0, source="", note="", use_context: bool = True,
          changes=None, ip="") -> bool:
    """Записати дію. НІКОЛИ не кидає — але й ніколи не мовчить про відмову.

    Порожні поля доповнюються КОНТЕКСТОМ поточного прогону (див. вище): хто діє,
    звідки прийшла робота, який контрагент/задача/прогін зараз в роботі."""
    ctx = context() if use_context else {}
    try:
        a = list(about or [])
        if use_context:
            for key in ("party", "task", "run"):
                v = _s(ctx.get(key))
                if v and v not in a:
                    a.append(v)
        rec = validate(action, subject,
                       actor=_s(actor) or _s(ctx.get("actor")),
                       about=a, outcome=outcome, cost_usd=cost_usd,
                       source=_s(source) or _s(ctx.get("source")), note=note,
                       changes=changes, ip=_s(ip) or _s(ctx.get("ip")))
    except Exception as exc:
        _fail(str(exc), {"action": action, "subject": subject, "actor": actor,
                         "about": about, "outcome": outcome, "source": source})
        return False
    target = path_of(rec["action"])
    # ⭐ 796: рядок журналу безпеки — з відбитком ланцюжка і ротацією (нижче).
    done = _append_security(rec) if target == _SEC_PATH else _append(target, rec)
    if not done:
        # Диск не пише — робота все одно йде далі. Але слід невдачі теж пробуємо
        # покласти: якщо не вийде і це, ми хоча б не зламали роботу людини.
        _fail("не вдалося дописати у файл протоколу", {"action": action,
                                                       "subject": rec.get("subject")})
        return False
    return True


# ── ⭐⭐⭐ 796. ЖУРНАЛ БЕЗПЕКИ: ЛАНЦЮЖОК ВІДБИТКІВ І РОТАЦІЯ ────────────────────
# 🩸 До 796 журнал безпеки лише дописувався: будь-хто з доступом до теки стану
# міг змінити, видалити чи вставити рядок — і жоден екран цього б не показав
# (паспорт 784, розділ 15). Файл ріс без межі (ОТУ: ~190 МБ на рік).
# ⛒ КОЖЕН РЯДОК НЕСЕ `chain` = SHA-256(відбиток попереднього + зміст рядка).
# Правка, видалення чи вставка рвуть ланцюжок, і `verify_security` називає перше
# місце розриву. Відбиток ставить ОДИН писар (`write`) під власним замком журналу
# безпеки — найвнутрішнім у продукті (усередині нього інших замків не беруть),
# тож він не може стати учасником взаємного блокування.
# ⛒ РОТАЦІЯ: файл, що переріс `SEC_ROTATE_BYTES`, перейменовується в архів
# `security.<РРРРММДД-ГГХХСС>.jsonl` поруч; ланцюжок іде крізь архіви без розриву
# (перший рядок нового файлу тримається останнього рядка архіву). Архіви ніхто
# не видаляє: журнал реєстрації чистить людина, а не платформа.
# ⚠ Межа, названа чесно: відрізаний ХВІСТ (останні рядки) ланцюжок не виявляє —
# його видно лише порівнянням із щоденною копією даних.
CHAIN = "chain"
SEC_LOCK_NAME = ".security_journal.lock"
_SEC_LOCK = threading.Lock()


def _rotate_bytes() -> int:
    try:
        mb = float(config.ENV.get("SECURITY_LOG_ROTATE_MB") or 50)
    except Exception:
        mb = 50.0
    return int(max(1.0, mb) * 1024 * 1024)


SEC_ROTATE_BYTES = _rotate_bytes()


def _canon(rec: dict) -> str:
    return json.dumps({k: v for k, v in rec.items() if k != CHAIN},
                      ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def chain_of(prev: str, rec: dict) -> str:
    """Відбиток рядка: від відбитка попереднього і власного змісту (без `chain`)."""
    return hashlib.sha256((_s(prev) + "\n" + _canon(rec)).encode("utf-8")).hexdigest()


def security_files() -> list:
    """Файли журналу безпеки від найстаршого: архіви за часом, потім поточний."""
    d = _SEC_PATH.parent
    try:
        arch = sorted(p for p in d.glob(_SEC_PATH.stem + ".*" + _SEC_PATH.suffix)
                      if p.name != _SEC_PATH.name)
    except Exception:
        arch = []
    return arch + ([_SEC_PATH] if _SEC_PATH.exists() else [])


def _last_chain_in(p) -> str:
    """Відбиток останнього рядка з відбитком у файлі (читанням із хвоста)."""
    try:
        f = p.open("rb")
    except FileNotFoundError:
        return ""
    rest = b""
    with f:
        f.seek(0, 2)
        pos = f.tell()
        while pos > 0:
            n = min(TAIL_BLOCK, pos)
            pos -= n
            f.seek(pos)
            lines = (f.read(n) + rest).split(b"\n")
            rest = b"" if pos == 0 else lines[0]
            for raw in reversed(lines[1:] if pos > 0 else lines):
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    v = json.loads(raw.decode("utf-8"))
                except Exception:
                    continue
                if isinstance(v, dict) and _s(v.get(CHAIN)):
                    return _s(v.get(CHAIN))
    return ""


def _chain_head() -> str:
    for p in reversed(security_files()):
        c = _last_chain_in(p)
        if c:
            return c
    return ""


def _take_sec_lock():
    """Файловий замок журналу безпеки для сторонніх процесів (як у `one_writer`).
    Ніколи не кидає; покинутий замок забирається за віком."""
    import os
    import time
    try:
        _SEC_PATH.parent.mkdir(parents=True, exist_ok=True)
        p = _SEC_PATH.parent / SEC_LOCK_NAME
    except Exception:
        return None
    deadline = time.time() + 20.0
    while True:
        try:
            fd = os.open(str(p), os.O_CREAT | os.O_EXCL | os.O_RDWR)
            os.close(fd)
            return p
        except FileExistsError:
            try:
                age = time.time() - os.path.getmtime(str(p))
            except Exception:
                age = 0.0
            if age > 60.0:
                try:
                    os.unlink(str(p))
                    continue
                except Exception:
                    return None
            if time.time() > deadline:
                return None
            time.sleep(0.02)
        except Exception:
            return None


def _rotate_if_needed() -> None:
    try:
        if not _SEC_PATH.exists() or _SEC_PATH.stat().st_size < SEC_ROTATE_BYTES:
            return
    except Exception:
        return
    stamp = _s(_now_safe()).replace("-", "").replace(":", "").replace("T", "-")[:15] or "rotated"
    n = 0
    while True:
        name = "%s.%s%s%s" % (_SEC_PATH.stem, stamp, ("-%d" % n) if n else "", _SEC_PATH.suffix)
        target = _SEC_PATH.parent / name
        if not target.exists():
            break
        n += 1
    _SEC_PATH.rename(target)


def _append_security(rec) -> bool:
    """⭐ 796: рядок журналу безпеки — з відбитком, під замком, з ротацією."""
    import os
    try:
        with _SEC_LOCK:
            fl = _take_sec_lock()
            try:
                _rotate_if_needed()
                rec[CHAIN] = chain_of(_chain_head(), rec)
                _SEC_PATH.parent.mkdir(parents=True, exist_ok=True)
                with _SEC_PATH.open("ab") as f:
                    if f.tell() > 0:
                        with _SEC_PATH.open("rb") as r:
                            r.seek(-1, 2)
                            if r.read(1) != b"\n":
                                f.write(b"\n")   # обрізаний рядок не злипається з новим
                    f.write((json.dumps(rec, ensure_ascii=False) + "\n").encode("utf-8"))
            finally:
                if fl:
                    try:
                        os.unlink(str(fl))
                    except Exception:
                        pass
        return True
    except Exception:
        return False


def verify_security() -> dict:
    """⭐ 796: ЦІЛІСТЬ ЖУРНАЛУ БЕЗПЕКИ. Проходить усі файли від найстаршого.
    -> {ok, total, legacy, chained, since, files, broken:{file, line, at, reason}}"""
    prev, seen_chain = "", False
    total = legacy = chained = 0
    since = ""
    files = security_files()
    for p in files:
        try:
            raw = p.read_bytes().split(b"\n")
        except Exception as e:
            return {"ok": False, "total": total, "legacy": legacy, "chained": chained,
                    "since": since, "files": len(files),
                    "broken": {"file": p.name, "line": 0, "at": "",
                               "reason": "файл не читається: %s" % type(e).__name__}}
        for i, ln in enumerate(raw, 1):
            ln = ln.strip()
            if not ln:
                continue
            total += 1

            def broke(why, at=""):
                return {"ok": False, "total": total, "legacy": legacy, "chained": chained,
                        "since": since, "files": len(files),
                        "broken": {"file": p.name, "line": i, "at": at, "reason": why}}
            try:
                v = json.loads(ln.decode("utf-8"))
            except Exception:
                return broke("рядок пошкоджено (не читається)")
            if not isinstance(v, dict):
                return broke("рядок пошкоджено (не запис)")
            c = _s(v.get(CHAIN))
            if not c:
                if seen_chain:
                    return broke("рядок без відбитка після початку ланцюжка (вставлено)", _s(v.get("at")))
                legacy += 1
                continue
            if c != chain_of(prev, v):
                return broke("відбиток не збігається (рядок змінено, видалено або вставлено)",
                             _s(v.get("at")))
            if not seen_chain:
                since = _s(v.get("at"))
            seen_chain = True
            prev = c
            chained += 1
    return {"ok": True, "total": total, "legacy": legacy, "chained": chained,
            "since": since, "files": len(files), "broken": None}


# ── Читання ──────────────────────────────────────────────────────────────────
def _read_lines(path=None) -> list:
    p = path or _PATH
    try:
        raw = p.read_text(encoding="utf-8").splitlines()
    except Exception:
        return []
    out = []
    for ln in raw:
        ln = ln.strip()
        if not ln:
            continue
        try:
            v = json.loads(ln)
        except Exception:
            continue                       # побитий рядок не валить читання решти
        if isinstance(v, dict):
            out.append(v)
    return out


def read(limit: int = 0, action: str = "", since: str = "",
         security: bool = False) -> list:
    """Рядки журналу, свіжіші — в кінці. limit=0 — усе.

    ⭐ 663: `security=True` (або дієслово безпеки) — рядки журналу безпеки.
    ⛒ «Усе про людину» (`about_ref`) журнал безпеки свідомо НЕ читає: входи й
    невдалі спроби — дані для адміністратора, а не стрічка картки."""
    where = path_of(action) if _s(action) else (_SEC_PATH if security else _PATH)
    if where == _SEC_PATH:
        # ⭐ 796: журнал безпеки — архіви ротації і поточний файл, від найстаршого.
        rows = []
        for p in security_files():
            rows += _read_lines(p)
    else:
        rows = _read_lines(where)
    if action:
        rows = [r for r in rows if _s(r.get("action")) == _s(action)]
    if since:
        rows = [r for r in rows if _s(r.get("at")) >= _s(since)]
    return rows[-limit:] if limit else rows


TAIL_BLOCK = 64 * 1024


def read_since(since: str, security: bool = False) -> list:
    """⭐⭐⭐ 665. РЯДКИ, НЕ СТАРШІ ЗА `since`, — ЧИТАННЯМ ХВОСТА ФАЙЛУ.

    Суддя паузи питає журнал безпеки на КОЖНІЙ спробі входу. Читати для цього
    весь файл (у ОТУ — сотні МБ за рік) означало б зробити вхід повільнішим з
    кожним днем. Рядки лягають у файл за часом, тож свіжі — у хвості: читаємо
    блоками від кінця, доки блок ще має хоч один свіжий рядок.
    ⛒ Не зупиняємось на ПЕРШОМУ старому рядку: рядок, дописаний пізніше зі
    старшою датою, не сміє сховати свіжі перед собою. Зупинка — лише коли
    ЦІЛИЙ блок (`TAIL_BLOCK`) не має жодного свіжого рядка. Межа названа:
    понад 64 КБ старих рядків, дописаних у самий кінець, сховали б свіжі —
    так файл не пише жоден писар (відновлення замінює файл, а не дописує).
    Порядок результату — як у файлі.

    ⛒ 795: «файлу ще немає» і «файл не відкривається» — різні відповіді.
    Перше — свіжа установка, рядків справді немає. Друге — поломка (права, диск),
    і вона летить до того, хто питав: суддя паузи мусить про неї знати, а не
    вважати, що невдалих спроб не було. Побитий рядок — не поломка (нижче).

    ⛒ 796: журнал безпеки живе в кількох файлах (ротація). Ідемо від поточного до
    старших, доки файл почався ПІЗНІШЕ за межу вікна: тоді хвіст вікна лежить у
    попередньому архіві, і пауза не губиться на межі файлів."""
    edge = _s(since)
    if not security:
        return _tail_since(_PATH, edge)
    out = []
    for p in reversed(security_files() or [_SEC_PATH]):
        out = _tail_since(p, edge) + out
        first = _first_at(p)
        if first and first < edge:
            break                              # цей файл почався до вікна
    return out


def _first_at(p) -> str:
    """Час першого читабельного рядка файлу («» — порожній чи немає)."""
    try:
        with p.open("rb") as f:
            for raw in f:
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    v = json.loads(raw.decode("utf-8"))
                except Exception:
                    continue
                if isinstance(v, dict) and _s(v.get("at")):
                    return _s(v.get("at"))
    except Exception:
        return ""
    return ""


def _tail_since(p, edge: str) -> list:
    """Рядки одного файлу, не старші за `edge`, — читанням із хвоста (665)."""
    try:
        f = p.open("rb")
    except FileNotFoundError:
        return []
    out, rest = [], b""
    with f:
        f.seek(0, 2)
        pos = f.tell()
        while pos > 0:
            step_ = min(TAIL_BLOCK, pos)
            pos -= step_
            f.seek(pos)
            buf = f.read(step_) + rest
            lines = buf.split(b"\n")
            rest = lines[0] if pos > 0 else b""
            chunk = lines[1:] if pos > 0 else lines
            fresh = []
            for raw in chunk:
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    v = json.loads(raw.decode("utf-8"))
                except Exception:
                    continue                   # побитий рядок не валить читання
                if isinstance(v, dict) and _s(v.get("at")) >= edge:
                    fresh.append(v)
            out = fresh + out
            if not fresh:
                break
    return out


def about_ref(value, limit: int = 0) -> list:
    """⭐ ЗВʼЯЗОК ЧИТАЄТЬСЯ НАЗАД. «Покажи все про Каспера» — це один прохід тут.

    Знаходить рядки, де сутність є або головною річчю, або згадана серед тих,
    кого дія стосується."""
    ref = entity.norm(value)
    rows = [r for r in _read_lines()
            if _s(r.get("subject")) == ref or ref in (r.get("about") or [])]
    return rows[-limit:] if limit else rows


def about_any(values) -> list:
    """⭐ 779: те саме, що `about_ref`, але про КІЛЬКА сутностей одним проходом журналу (картка і злиті в неї
    дублі). Рядок про кількох із них віддається один раз."""
    refs = {entity.norm(v) for v in (values or [])}
    return [r for r in _read_lines()
            if _s(r.get("subject")) in refs or any(x in refs for x in (r.get("about") or []))]


def failures(limit: int = 50) -> list:
    return _read_lines(_FAIL_PATH)[-limit:] if limit else _read_lines(_FAIL_PATH)
