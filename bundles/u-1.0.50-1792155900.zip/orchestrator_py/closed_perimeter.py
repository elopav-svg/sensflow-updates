# -*- coding: utf-8 -*-
"""closed_perimeter.py — ЗАКРИТИЙ КОНТУР: ЖОДНОГО ВИХОДУ ЗА МЕЖІ МЕРЕЖІ ОРГАНІЗАЦІЇ (зміна 800, 15.10.2026).

🩸 ЩО БУЛО. Режим ізоляції (`egress_guard`, власна модель) блокував лише інструменти
оркестратора (пошук, читання сторінок) і лише до згоди оператора. Пошта (SMTP/IMAP),
Telegram, сервіси Google, канал оновлень, хмарні моделі ним не охоплені — їх треба
було вимикати кожен окремо (паспорт 784, розділ 15). Для державної установи «дані не
виходять за периметр» мусить бути властивістю платформи, а не списком налаштувань.

⛒ КЛАС, А НЕ ЛАТКА: ОДИН СУДДЯ — НА РІВНІ МЕРЕЖЕВОГО ЗʼЄДНАННЯ.
Модулів, що виходять у мережу, десятки (моделі, пошта, боти, Google, Prozorro, Рада,
оновлення, Alldevice); вимикач у кожному — латка, яку забудуть у наступному. Тому
`install()` ставить суддю на `socket.socket.connect` — через нього проходить кожне
зʼєднання стандартної бібліотеки (urllib, http.client, smtplib, imaplib, ssl).
Дозволено лише адреси самої мережі організації: локальна машина, приватні діапазони
(10/8, 172.16/12, 192.168/16, fc00::/7), link-local; і явно названі адміністратором
підмережі (`SENSFLOW_CLOSED_ALLOW`). Решта — відмова словами й рядок у журналі виходів.

Вмикає ОДИН рядок `SENSFLOW_CLOSED=1` у `.env.local`; ставить суддю `config` при
завантаженні — тобто кожен процес платформи (сервер, боти, автоматизації, інструменти).

⚠ Межа, названа чесно: запит імені (DNS) робить операційна система, а не Python, —
його цей суддя не бачить; самі дані за межі мережі не йдуть.
"""
import ipaddress
import socket

KEY = "SENSFLOW_CLOSED"
ALLOW_KEY = "SENSFLOW_CLOSED_ALLOW"
TEXT = ("Закритий контур: вихід за межі мережі організації заборонено (%s). "
        "Платформа працює лише з адресами вашої мережі.")

_STATE = {"installed": False, "connect": None, "connect_ex": None}


class ClosedPerimeter(ConnectionRefusedError):
    """Зʼєднання за межі мережі організації в закритому контурі. Наслідник
    `ConnectionRefusedError` (OSError): кожен, хто вже чесно обробляє «мережа
    недоступна», обробить і це — але слова кажуть правду, а не «немає звʼязку»."""


def _env(name: str) -> str:
    try:
        import config
        return str(config.ENV.get(name) or "").strip()
    except Exception:
        return ""


def on() -> bool:
    """Чи ввімкнено закритий контур на цій машині."""
    return _env(KEY) == "1"


def _extra_nets() -> list:
    out = []
    for part in _env(ALLOW_KEY).replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            out.append(ipaddress.ip_network(part, strict=False))
        except ValueError:
            continue                       # сміття в переліку не відчиняє нічого
    return out


def _ip_ok(ip: str, nets=None) -> bool:
    try:
        a = ipaddress.ip_address(str(ip).split("%")[0])
    except ValueError:
        return False
    if getattr(a, "ipv4_mapped", None):
        a = a.ipv4_mapped
    if a.is_unspecified:
        return False
    if a.is_loopback or a.is_link_local or a.is_private:
        return True
    return any(a.version == n.version and a in n for n in (nets if nets is not None else _extra_nets()))


def allowed(host) -> bool:
    """Чи лежить адреса в межах мережі організації. Імʼя — за ВСІМА його адресами:
    хоч одна поза мережею — відмова."""
    h = str(host or "").strip().strip("[]")
    if not h:
        return False
    if h.lower() == "localhost":
        return True
    nets = _extra_nets()
    try:
        ipaddress.ip_address(h.split("%")[0])
        return _ip_ok(h, nets)
    except ValueError:
        pass
    try:
        infos = socket.getaddrinfo(h, None)
    except OSError:
        return False
    addrs = {i[4][0] for i in infos}
    return bool(addrs) and all(_ip_ok(x, nets) for x in addrs)


def _log(host, port) -> None:
    try:
        import egress_guard
        egress_guard.log("blocked", {"tool": "closed_perimeter", "host": str(host)[:120],
                                     "port": port})
    except Exception:
        pass


def _guard(sock, address) -> None:
    fam = getattr(sock, "family", None)
    if fam not in (socket.AF_INET, socket.AF_INET6):
        return                              # локальні сокети (AF_UNIX тощо) — не мережа
    if not on():
        return
    host = address[0] if isinstance(address, tuple) and address else address
    port = address[1] if isinstance(address, tuple) and len(address) > 1 else None
    if not allowed(host):
        _log(host, port)
        raise ClosedPerimeter(TEXT % host)


def install() -> bool:
    """Поставити суддю на кожне мережеве зʼєднання процесу. Повторний виклик — нічого."""
    if _STATE["installed"]:
        return True
    orig, orig_ex = socket.socket.connect, socket.socket.connect_ex

    def connect(self, address):
        _guard(self, address)
        return orig(self, address)

    def connect_ex(self, address):
        _guard(self, address)
        return orig_ex(self, address)

    _STATE.update(installed=True, connect=orig, connect_ex=orig_ex)
    socket.socket.connect = connect
    socket.socket.connect_ex = connect_ex
    return True


def uninstall() -> None:
    """Для проб: зняти суддю."""
    if _STATE["installed"]:
        socket.socket.connect = _STATE["connect"]
        socket.socket.connect_ex = _STATE["connect_ex"]
        _STATE.update(installed=False, connect=None, connect_ex=None)


def status() -> dict:
    """Для екранів: чи ввімкнено й що дозволено понад приватні діапазони."""
    return {"on": on(), "installed": _STATE["installed"],
            "allow": [str(n) for n in _extra_nets()]}
