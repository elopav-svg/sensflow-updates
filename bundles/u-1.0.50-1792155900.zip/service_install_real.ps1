﻿# ============================================================================
#  SensFlow — СПРАВЖНЯ СЛУЖБА WINDOWS (зміна 807, ТЗІ група Б2).
#
#  Для СЕРТИФІКОВАНОЇ конфігурації (посилений профіль: SENSFLOW_HARDENED=1 або
#  закритий контур SENSFLOW_CLOSED=1). Кличе її «Служба - встановити автозапуск»,
#  коли профіль увімкнено; у решти автозапуск лишається завданням Планувальника.
#
#  Що робить:
#   1. служба Windows «SensFlow» (диспетчер служб: стан, зупинка, відновлення),
#      старт — автоматичний з затримкою (мережа й диски встигають піднятись);
#   2. обліковий запис — віртуальний NT SERVICE\SensFlow: найменші права, без
#      пароля, не SYSTEM;
#   3. права на теку платформи — лише SYSTEM, адміністратори і сама служба
#      (ключі, база, журнали не читає звичайний користувач машини);
#   4. впала — диспетчер і сама служба піднімають знову;
#   5. завдання Планувальника ЦІЄЇ теки (якщо було) прибирається — двох
#      автозапусків не буває. Чуже завдання (інша тека) не чіпаємо.
# ============================================================================
param([switch]$NoPause)
. (Join-Path (Split-Path -Parent $PSCommandPath) "service_common.ps1")

function Sf-Pause { if (-not $NoPause) { try { Read-Host "Натисни Enter" | Out-Null } catch {} } }
# ⛒ Тут кожен виклик sc.exe/icacls перевіряється за кодом сам; «зупинка на будь-якій
# помилці» з service_common обірвала б скрипт посеред заведення служби на першому ж
# рядку попередження від icacls (PowerShell 5.1) — і служба лишилась би напівзаведеною.
$ErrorActionPreference = "Continue"

Sf-Head "SensFlow: справжня служба Windows (сертифікована конфігурація)"
if (-not (Sf-RequireEngine)) { exit 2 }
if (-not (Sf-NeedAdmin -ScriptPath $PSCommandPath)) { exit }

$port = Sf-Port
$svc  = $SfService
$acct = "NT SERVICE\$svc"
Sf-Line "Тека платформи : $SfRoot"
Sf-Line "Порт           : $port"
Sf-Trace "служба 807: встановлення почато, тека $SfRoot, порт $port"

# ── 1. PYTHON, ЯКИЙ ПОБАЧИТЬ СЛУЖБА ─────────────────────────────────────────
# Віртуальний обліковий запис не бачить теки профілю людини (AppData). Тому —
# лише Python пакета (python\) або встановлений для всіх.
$py = Sf-FindPython
if (-not $py) {
    Sf-Line "НЕ ЗНАЙШОВ Python. Службу не заведено."
    Sf-Trace "служба 807: СТОП — немає Python"
    Sf-Pause; exit 1
}
if ($py -like "$env:SystemDrive\Users\*") {
    Sf-Line "Python лежить у теці користувача: $py"
    Sf-Line "Служба з найменшими правами його не побачить. Потрібен Python пакета (тека python\)."
    Sf-Line "Нічого не змінено."
    Sf-Trace "служба 807: СТОП — Python у теці користувача ($py)"
    Sf-Pause; exit 1
}
Sf-Line "Python         : $py"

# ── 2. СТАРИЙ АВТОЗАПУСК ЦІЄЇ ТЕКИ ───────────────────────────────────────────
$t = Sf-Task
if ($t -and (Sf-TaskIsOurs)) {
    try { Stop-ScheduledTask -TaskName $SfTask -ErrorAction SilentlyContinue } catch {}
    Unregister-ScheduledTask -TaskName $SfTask -Confirm:$false
    Sf-Line "Завдання Планувальника цієї теки прибрано (замість нього — служба)."
    Sf-Trace "служба 807: завдання Планувальника цієї теки прибрано"
}
$old = Get-Service -Name $svc -ErrorAction SilentlyContinue
if ($old) {
    if ($old.Status -ne "Stopped") { Stop-Service -Name $svc -Force -ErrorAction SilentlyContinue }
    & sc.exe delete $svc | Out-Null
    Start-Sleep -Seconds 2
}
# Порт ЦІЄЇ платформи звільняємо (консоль, запущена руками); вікон за назвою не чіпаємо.
try {
    Get-NetTCPConnection -LocalPort ([int]$port) -State Listen -ErrorAction Stop |
        ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
} catch {}

# ── 3. СЛУЖБА І ПРАВА НА ТЕКУ ────────────────────────────────────────────────
# Шлях — рядком через New-Service: лапки всередині аргументу sc.exe PowerShell 5.1 ламає,
# щойно в шляху з'являється пробіл.
$bin = "`"$py`" -X utf8 `"" + (Join-Path $SfEngine "win_service.py") + "`""
try {
    New-Service -Name $svc -BinaryPathName $bin -DisplayName "SensFlow" -StartupType Automatic `
        -Description "SensFlow: платформа (сертифікована конфігурація)" -ErrorAction Stop | Out-Null
} catch {
    Sf-Line "Windows не завела службу: $($_.Exception.Message). Нічого не змінено."
    Sf-Trace "служба 807: СТОП — New-Service: $($_.Exception.Message)"
    Sf-Pause; exit 1
}
& sc.exe config $svc obj= $acct start= delayed-auto | Out-Null
if ($LASTEXITCODE -ne 0) {
    & sc.exe delete $svc | Out-Null
    Sf-Line "Windows не дала службі обліковий запис $acct (код $LASTEXITCODE). Службу прибрано."
    Sf-Trace "служба 807: СТОП — sc config obj= код $LASTEXITCODE"
    Sf-Pause; exit 1
}
& sc.exe sidtype $svc unrestricted | Out-Null
& sc.exe failure $svc reset= 86400 actions= restart/60000/restart/60000/restart/60000 | Out-Null
# Успадковані права (Users: читання) знімаємо; лишаються SYSTEM, адміністратори і служба —
# на всій теці (вкладене успадковує від кореня само). SID-и, а не назви груп: на російській
# чи англійській Windows назви різні.
$acl = & icacls $SfRoot /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" `
    "${acct}:(OI)(CI)M" /C /Q 2>&1
if ($LASTEXITCODE -ne 0) {
    Sf-Line "Права на теку не встановились: $(($acl | Out-String).Trim())"
    Sf-Trace "служба 807: icacls код $LASTEXITCODE"
}
Sf-Line "Права на теку  : SYSTEM, адміністратори, служба"
Sf-Trace "служба 807: служба заведена, обліковий запис $acct, права на теку обмежено"

# ── 4. ЗАПУСК ───────────────────────────────────────────────────────────────
Start-Service -Name $svc -ErrorAction SilentlyContinue
if (Sf-Alive -Port $port -Seconds 90) {
    Sf-Head "ГОТОВО. Платформа працює справжньою службою Windows"
    Sf-Line "Служба         : $svc (services.msc), обліковий запис $acct"
    Sf-Line "Адреса         : http://127.0.0.1:$port"
    Sf-Line "Журнал         : service.log"
    Sf-Trace "служба 807: ГОТОВО — платформа відповідає на порту $port"
    Sf-Pause; exit 0
}
Sf-Line "Служба заведена, але платформа не відповіла за 90 с. Дивись service.log."
Sf-Trace "служба 807: платформа не відповіла за 90 с"
Sf-Pause; exit 1
