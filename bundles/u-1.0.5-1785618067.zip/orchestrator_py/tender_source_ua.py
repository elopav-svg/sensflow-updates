# -*- coding: utf-8 -*-
"""
tender_source_ua.py — ШАР 1: ОДНА точка входу до тендерних даних України (Prozorro).

Брат-близнюк legal_source_ua.py. Той самий клас гарантії: усе, що система колись
скаже про тендер (номер, дата подання, сума, замовник, вимога), приходить ЗВІДСИ,
а не з голови моделі. Модуль лише ДІСТАЄ факти — він нічого не тлумачить.

ДВА РІЗНІ API Prozorro (не плутати):

  A. Офіційний CDB  https://public-api.prozorro.gov.ua/api/2.5
     - стрічка змін GET /tenders  -> ЛИШЕ id + dateModified (текстового пошуку НЕМАЄ)
     - картка       GET /tenders/{uuid} -> повний обсяг (лоти, критерії, complaints)
     Це ДЖЕРЕЛО ІСТИНИ для індексу.

  B. Пошуковий фронтенду  https://prozorro.gov.ua/api/search/tenders
     - ПОВНОТЕКСТОВИЙ пошук + фільтр статусів
     - ТІЛЬКИ POST (на GET віддає 405)
     - віддає лише tenderID/title/status/procuringEntity — БЕЗ сум, дат подання і ДК
     Це ЗРУЧНИЙ ВХІД (звузити коло), а НЕ джерело істини.

Дисципліна, здобута живою розвідкою 27.07.2026:
  * page рахується з 1 (page=0 -> 422 "The page must be at least 1")
  * per_page жорстко 20, змінити не можна (per_page/limit ігноруються)
  * фільтр дат НЕ працює — дату брати з номера UA-РРРР-ММ-ДД-...
  * сортування — за релевантністю, НЕ строго за датою: часткове гортання дає
    ЗАНИЖЕНІ цифри. Рахувати місячні обсяги можна ЛИШЕ на повному обході.
  * є ліміт частоти: пачка паралельних запитів -> 422/порожнеча. Ходити послідовно
    з паузою (_PAGE_PAUSE).
  * total=10000 — це стеля видачі, а не реальна кількість.

Мережа — виключно через netfetch (спільні ворота виходу). Власного urllib тут немає
свідомо: інакше запит обійде ворота і в режимі Стелс дані потечуть назовні.
"""

import json
import re
import time

import netfetch

CDB_BASE = "https://public-api.prozorro.gov.ua/api/2.5"
SEARCH_URL = "https://prozorro.gov.ua/api/search/tenders"
PORTAL_TENDER = "https://prozorro.gov.ua/tender/"   # людське посилання для звірки

_UA = "AI-Orchestrator/1.0 (SensFlow tender watch)"
_TIMEOUT = 30
_PAGE_PAUSE = 0.25          # пауза між сторінками пошуку — проти ліміту частоти
_SEARCH_PER_PAGE = 20       # задано сервером, не змінюється
_MAX_PAGES_HARD = 200       # запобіжник від нескінченного гортання

# UA-2026-07-21-001050-a  ->  дата оголошення
_TENDER_ID_RE = re.compile(r"^UA-(\d{4})-(\d{2})-(\d{2})-")

_OPEN_STATUSES = (
    "active.tendering",
    "active.enquiries",
    "active.auction",
    "active.qualification",
    "active.pre-qualification",
)


_RATE_WAITS = (5, 15, 40)     # скільки чекати після 429, у секундах
_rate_seen = [False]          # чи вже били по лімітах у цьому прогоні


def _is_rate_limited(exc) -> bool:
    s = str(exc or "").lower()
    return "429" in s or "too many requests" in s


def _sleep_pause():
    """Після першого 429 ходимо ПОВІЛЬНІШЕ до кінця прогону."""
    time.sleep(_PAGE_PAUSE * (4 if _rate_seen[0] else 1))


class TenderRateLimited(Exception):
    """Джерело тимчасово обмежило нас (429). ⭐⭐⭐ 01.08.2026: це НЕ «даних немає»
    і НЕ привід загубити вже зібране. Окремий клас, щоб викликач міг віддати
    ЧАСТКОВИЙ результат із чесною позначкою, а не порожнечу."""


class TenderSourceError(Exception):
    """Джерело не віддало дані. Викликач зобов'язаний зробити чесний стоп,
    а НЕ вигадати відповідь."""


# ---------------------------------------------------------------------------
# Низький рівень
# ---------------------------------------------------------------------------
def _with_backoff(call, what):
    """ОДИН ПИСАР ВИТРИМКИ. Прозорро має ліміт частоти: на 61-й сторінці слова
    «Воїн» він відповів 429 і весь звіт клієнта помер. Ліміт — це «зачекай», а
    не «даних немає»: чекаємо і повторюємо, а якщо не відпустив — кажемо про це
    ОКРЕМИМ класом, щоб зібране не пропало."""
    last = None
    for i, wait in enumerate((0,) + _RATE_WAITS):
        if wait:
            _rate_seen[0] = True
            time.sleep(wait)
        try:
            return call()
        except netfetch.EgressBlocked:
            raise
        except Exception as e:
            last = e
            if not _is_rate_limited(e):
                raise TenderSourceError("%s -> %s" % (what, e))
    raise TenderRateLimited("%s -> джерело обмежило частоту (429) після %d спроб: %s"
                            % (what, len(_RATE_WAITS) + 1, last))


def _get_json(url):
    return _with_backoff(
        lambda: json.loads(netfetch.get_text(url, ua=_UA, timeout=_TIMEOUT)),
        "GET %s" % url)


def _post_json(url, payload=None):
    return _with_backoff(
        lambda: json.loads(netfetch.post_json(url, payload, ua=_UA, timeout=_TIMEOUT)),
        "POST %s" % url)


def announced_date(tender_id):
    """Дата оголошення з номера тендера -> 'DD.MM.YYYY' або None.
    Потрібно, бо фільтр дат у пошуковому API не працює."""
    m = _TENDER_ID_RE.match((tender_id or "").strip())
    if not m:
        return None
    y, mo, d = m.group(1), m.group(2), m.group(3)
    return "%s.%s.%s" % (d, mo, y)


def portal_url(tender_id):
    """Людське посилання на тендер — щоб людина могла звірити очима."""
    return PORTAL_TENDER + (tender_id or "").strip()


# ---------------------------------------------------------------------------
# A. Офіційний CDB — джерело істини
# ---------------------------------------------------------------------------
def feed_page(offset=None, limit=100, descending=False, fields=None):
    """Сторінка стрічки змін.

    fields — додаткові поля запису (opt_fields). ДОВЕДЕНО 27.07.2026:
    fields=("tenderID",) віддає номер і uuid В ОДНОМУ записі, тому індекс
    будується прямим обходом стрічки, без добору картки на кожен тендер.
    ⚠ Сервер має БІЛИЙ СПИСОК: title і value він мовчки викидає — не
    розраховувати на них тут.

    offset — момент часу (unix-секунди) або курсор із next_page. Стрибок
    у часі працює: перевірено offset=1752710400 -> записи за 17.07.2025.
    """
    url = CDB_BASE + "/tenders?limit=%d" % int(limit)
    if descending:
        url += "&descending=1"
    if fields:
        url += "&opt_fields=" + ",".join(fields)
    if offset:
        url += "&offset=" + str(offset)
    data = _get_json(url)
    return {
        "items": data.get("data") or [],
        "next_offset": ((data.get("next_page") or {}).get("offset")),
    }


def _subresource(uuid, name):
    """Субресурс картки (/awards, /bids, ...). Окремий вхід свідомо: відповідь
    маленька і не тягне за собою всю картку на кілька сотень кілобайт."""
    data = _get_json(CDB_BASE + "/tenders/" + str(uuid).strip() + "/" + name)
    got = data.get("data")
    return got if isinstance(got, list) else []


def awards(uuid):
    """Нагороди тендера: ХТО переміг, кого відхилили, за яку суму.
    ДОВЕДЕНО живим запитом 27.07.2026 — назва постачальника, код ЄДРПОУ,
    сума і статус (active / cancelled / unsuccessful) віддаються повністю."""
    return _subresource(uuid, "awards")


def bids(uuid):
    """Пропозиції учасників. initialValue -> value дає ПАДІННЯ ЦІНИ на торгах.
    ⚠ До розкриття Prozorro легально ховає частину полів — порожній список
    означає «ще не розкрито», а НЕ «учасників не було»."""
    return _subresource(uuid, "bids")


def documents(uuid, card=None):
    """⭐ 30.07.2026. ПЕРЕЛІК ФАЙЛІВ ТЕНДЕРНОЇ ДОКУМЕНТАЦІЇ замовника.

    НАВІЩО. Оркестратор пообіцяв клієнту витягти вимоги з документації тендера —
    а дістати сам ПЕРЕЛІК файлів платформа не вміла. Обіцянка без уміння коштує
    довіри; тому вміння стає поруч із awards/bids, а не окремим шаром.

    ОСНОВНИЙ ШЛЯХ — КАРТКА. fetch_card() робить GET /tenders/{uuid} БЕЗ opt_fields,
    тобто сервер віддає повний обсяг, і `documents` лежить прямо в картці. Якщо
    картку вже дістали — передай її сюди (card=...), зайвого запиту не буде.

    ЗАПАСНИЙ ШЛЯХ — субресурс /documents. Ходимо туди ЛИШЕ тоді, коли поля
    `documents` у картці НЕМАЄ ЗОВСІМ (інша версія API, урізана відповідь).
    Порожній СПИСОК запасним шляхом не перекриваємо: [] означає «замовник файлів
    не додав» — це відповідь, а не збій.

    ⚠ Старі версії документів тут НЕ відсіюються: це вже тлумачення, і робить
    його викликач (tender_docs.read_docs). Джерело лише ДІСТАЄ факти.
    """
    if card is None:
        card = fetch_card(uuid)
    got = (card or {}).get("documents")
    if isinstance(got, list):
        return got
    return _subresource(uuid, "documents")


def fetch_card(uuid):
    """ПОВНА картка тендера з офіційного API. Єдине джерело для сум, дат подання,
    кваліфікаційних вимог і скарг (complaints)."""
    data = _get_json(CDB_BASE + "/tenders/" + str(uuid).strip())
    card = data.get("data")
    if not isinstance(card, dict):
        raise TenderSourceError("карта тендера порожня: %s" % uuid)
    return card


# ---------------------------------------------------------------------------
# B. Пошуковий API — звузити коло (НЕ джерело істини)
# ---------------------------------------------------------------------------
FRONT_API = "https://prozorro.gov.ua/api/tenders/"   # двері фронтенду Прозорро


def details_card(tender_id):
    """КАРТКА ПРЯМО ЗА ЛЮДСЬКИМ НОМЕРОМ. ⭐⭐⭐ ДОВЕДЕНО ЖИВИМ ЗАПИТОМ 01.08.2026.

    НАВІЩО. Глибина архіву торгів (переможець, сума перемоги) впиралась у міст
    номерів, а міст знає лише недавнє вікно — тому 42 рядки з 54 у клієнта були
    порожні. Я двічі шукав ці двері й двічі помилявся:
      • `public-api…/tenders/<номер>` -> помилка (це шлях для uuid, не для номера);
      • `prozorro.gov.ua/api/tenders/<номер>` -> 404.
    Правильна адреса має ХВІСТ: `/details`. Знайдено не здогадкою, а зчитуванням
    мережевих запитів самої сторінки Прозорро у браузері Андрія.

    Віддає повну картку, у якій є `id` — той самий внутрішній код, по якому далі
    працюють `awards()` і `fetch_card()`. Тобто МІСТ ДЛЯ ГЛИБИНИ БІЛЬШЕ НЕ
    ПОТРІБЕН: один GET на тендер замість обходу стрічки за місяці.
    """
    tid = (tender_id or "").strip()
    if not tid:
        raise TenderSourceError("порожній номер тендера")
    return _get_json(FRONT_API + _quote(tid) + "/details")


def card_id(tender_id):
    """Номер -> внутрішній код (uuid) або "" . Тиха порожнеча заборонена:
    помилку джерела віддаємо як є, щоб викликач сказав ПРИЧИНУ, а не «немає»."""
    card = details_card(tender_id)
    if not isinstance(card, dict):
        return ""
    return str(card.get("id") or "").strip()


def search_page(text, page=1, statuses=None):
    """Одна сторінка повнотекстового пошуку. page рахується з 1."""
    if page < 1:
        raise TenderSourceError("page рахується з 1 (сервер віддає 422 на page=0)")
    url = SEARCH_URL + "?text=" + _quote(text) + "&page=%d" % int(page)
    for i, st in enumerate(statuses or []):
        url += "&status[%d]=%s" % (i, st)
    data = _post_json(url, {})
    items = data.get("data")
    return {
        "total": data.get("total") or 0,
        "items": items if isinstance(items, list) else [],
    }


def search_all(text, statuses=None, max_pages=_MAX_PAGES_HARD):
    """ПОВНИЙ обхід усіх сторінок.

    Тільки так можна рахувати обсяги: сортування за релевантністю, тож зупинка
    на півдорозі дає занижені цифри. Якщо обхід неповний — це чесно позначено
    у полі complete=False, і викликач НЕ має права називати цифру точною.
    """
    out = []
    first = search_page(text, 1, statuses)
    total = first["total"]
    out.extend(first["items"])
    pages = min(max_pages, -(-total // _SEARCH_PER_PAGE) if total else 1)
    stopped = ""
    for p in range(2, pages + 1):
        _sleep_pause()
        try:
            got = search_page(text, p, statuses)
        except TenderRateLimited as e:
            # ⭐⭐⭐ ЗІБРАНЕ НЕ ГУБИМО. Ліміт джерела — це межа обходу, а не
            # відсутність даних: віддаємо частину і чесно кажемо, що неповно.
            stopped = "джерело обмежило частоту запитів на сторінці %d" % p
            break
        if not got["items"]:
            break
        out.extend(got["items"])
    complete = (not stopped) and len(out) >= min(total, max_pages * _SEARCH_PER_PAGE)
    return {"total": total, "items": out, "complete": complete, "stopped": stopped}


def search_open(text):
    """Лише те, у чому ще МОЖНА взяти участь. Саме це цікавить клієнта щодня."""
    return search_all(text, statuses=list(_OPEN_STATUSES))


def _quote(s):
    from urllib.parse import quote
    return quote((s or "").strip())


# ---------------------------------------------------------------------------
# Зведення для викликача
# ---------------------------------------------------------------------------
_ISO_DATE_RE = re.compile(r"^(\d{4})-(\d{2})-(\d{2})")


def human_date(iso):
    """'2026-08-05T10:00:00+03:00' -> '05.08.2026'. Не розібрали — None."""
    m = _ISO_DATE_RE.match((iso or "").strip())
    return "%s.%s.%s" % (m.group(3), m.group(2), m.group(1)) if m else None


def _money(value):
    """{'amount':.., 'currency':..} -> (сума, валюта). Немає поля — (None, None).
    Вигадувати заборонено: краще порожньо, ніж правдоподібно."""
    if not isinstance(value, dict):
        return None, None
    amt = value.get("amount")
    try:
        amt = float(amt) if amt is not None else None
    except (TypeError, ValueError):
        amt = None
    return amt, (value.get("currency") or None)


def _period_end(period):
    """{'startDate':.., 'endDate':..} -> endDate або None."""
    if not isinstance(period, dict):
        return None
    return period.get("endDate") or None


def brief(item):
    """Нормалізує запис пошуку у плаский вигляд.

    ⚠ ВИПРАВЛЕНО 27.07.2026 живою пробою (`tender_resolve_probe.py`): пошукова
    видача МІСТИТЬ `value` (сума) і `tenderPeriod` (кінець подання). Раніше тут
    стояло amount=None/deadline=None «свідомо» — це було НЕПРАВДОЮ, побудованою
    на неповному спостереженні. Тепер беремо з джерела; немає поля — чесно None.

    Чого тут НЕМАЄ і бути не може: ДК/CPV, кваліфікаційні вимоги, скарги —
    вони лише у fetch_card() (через власний індекс).
    """
    pe = item.get("procuringEntity") or {}
    ident = pe.get("identifier") or {}
    tid = item.get("tenderID") or ""
    amount, currency = _money(item.get("value"))
    deadline = _period_end(item.get("tenderPeriod"))
    enquiry = _period_end(item.get("enquiryPeriod"))
    return {
        "tender_id": tid,
        "title": (item.get("title") or "").strip(),
        "status": item.get("status") or "",
        "buyer": (pe.get("name") or ident.get("legalName") or "").strip(),
        "buyer_kind": pe.get("kind") or "",
        "buyer_code": (ident.get("id") or ""),
        "announced": announced_date(tid),
        "url": portal_url(tid),
        "amount": amount,
        "currency": currency,
        "deadline": human_date(deadline),
        "deadline_iso": deadline,
        "enquiry_until": human_date(enquiry),
    }


# ---------------------------------------------------------------------------
# ОДНЕ ПРАВИЛО: чи клієнт ЩЕ МОЖЕ подати пропозицію
# ---------------------------------------------------------------------------
# Рішення Андрія 27.07.2026: будити клієнта лише там, де він ще МОЖЕ зайти.
# Правило живе в ОДНОМУ місці свідомо — ним користуються і сторож, і розвідник,
# і планувальник. Якби кожен вирішував сам, вони б розійшлися в думках, і клієнт
# отримував би різні відповіді від різних частин системи.
#
# ⚠ Не плутати з _OPEN_STATUSES: там «тендер ще живий» (включно з аукціоном і
# кваліфікацією), а тут — «подання ще ВІДЧИНЕНЕ». Живий прогон 27.07.2026 показав
# тендер у статусі active.auction зі строком подання, що минув учора.
APPLY_STATUSES = (
    "active.tendering",     # приймають пропозиції
    "active.enquiries",     # період запитань, подання попереду
)


def _date_tuple(ddmmyyyy):
    """'05.08.2026' -> (2026, 8, 5). Не розібрали — None."""
    try:
        d, m, y = (ddmmyyyy or "").split(".")
        return (int(y), int(m), int(d))
    except (ValueError, AttributeError):
        return None


def can_still_apply(rec, today=None):
    """Чи клієнт ще може подати пропозицію на цей тендер.

    Дві умови разом: статус приймає пропозиції І строк не минув. Дати немає —
    вирішує статус (вигадувати строк заборонено).
    """
    if (rec or {}).get("status") not in APPLY_STATUSES:
        return False
    a, b = _date_tuple((rec or {}).get("deadline")), _date_tuple(today)
    if a and b and a < b:
        return False
    return True


def search_actionable(text, today=None):
    """Лише те, у що клієнт ЩЕ МОЖЕ зайти. Саме це будить сторож.

    Повертає готові записи brief(), а не сирі: далі з ними працює лише складач.
    dropped — скільки активних тендерів відсіяно (щоб мовчазне звуження було
    ВИДНИМ, а не тихим).
    """
    res = search_all(text, statuses=list(APPLY_STATUSES))
    items = [brief(i) for i in res["items"]]
    live = [b for b in items if can_still_apply(b, today)]
    return {"total": res["total"], "complete": res["complete"],
            "items": live, "dropped": len(items) - len(live)}


# ---------------------------------------------------------------------------
# ОДНІ ДВЕРІ: номер тендера -> запис із джерела
# ---------------------------------------------------------------------------
def resolve(tender_id):
    """Номер, який бачить людина -> запис із ДЖЕРЕЛА (або None).

    Це ЄДИНІ двері, якими звіряч фактів дістає правду про тендер. Сьогодні за
    ними стоїть пошук за номером (доведено 27.07.2026). Коли зʼявиться власний
    індекс, він стане за ці самі двері — звіряч переробляти НЕ доведеться.

    Збіг ЛИШЕ ТОЧНИЙ: пошук нечіткий і на запит про один номер може віддати
    сусідні тендери. Віддати чужий запис як «перевірений» гірше, ніж не
    віддати нічого.

    Немає запису -> None (викликач зобовʼязаний зробити чесний стоп).
    Джерело недоступне -> TenderSourceError (тиха порожнеча заборонена).
    """
    tid = (tender_id or "").strip()
    if not tid:
        return None
    want = tid.upper()
    for it in search_page(tid, 1)["items"]:
        if (it.get("tenderID") or "").strip().upper() == want:
            rec = brief(it)
            uid = index_uuid(want)          # міст, якщо він уже знає цей номер
            if uid:
                rec["uuid"] = uid
            return rec
    return None


def index_uuid(tender_id):
    """uuid із МОСТУ (tender_index), БЕЗ походу в мережу.

    None означає «міст цього номера не знає» — і НЕ означає, що тендера
    немає. Хто саме з трьох станів (found/absent/unknown) — знає tender_index;
    сюди свідомо винесено лише те, що потрібно джерелу.

    Імпорт ліниво і всередині функції: міст знає джерело, джерело не мусить
    знати міст (інакше кільце імпортів). Міст може бути й не встановлений —
    тоді resolve() працює точно як раніше.
    """
    try:
        import tender_index
        res = tender_index.lookup(tender_id)
    except Exception:
        return None
    return res.get("uuid") if res.get("status") == "found" else None


def search_by_profile(profile_queries, today=None):
    """Один прохід сторожа: усі слова профілю -> ОДИН список без дублів.

    ⚠ НАВІЩО ДЕДУПЛІКАЦІЯ. Слова профілю свідомо перетинаються: «Пончо
    антитепловізійне» знайдеться і за «антитепловізійний», і за «пончо».
    Якби кожне слово слало окремо, клієнт отримав би той самий тендер двічі —
    і почав би гортати сповіщення не читаючи. Пропущений тендер коштує грошей
    один раз; втрачена довіра до сповіщень коштує кожного разу.

    Зведення тут, а не в сторожі, свідомо: інакше розвідник і планувальник
    зроблять кожен по-своєму.

    -> {items, per_query, duplicates, dropped, complete}
      per_query  — скільки дало КОЖНЕ слово (видно, яке слово даремне);
      duplicates — скільки збігів прибрано (звуження ВИДИМЕ, як і dropped);
      dropped    — скільки відсіяно за «подання вже зачинене».
    """
    seen, per_query, dropped, raw_count, complete = {}, {}, 0, 0, True
    for q in (profile_queries or []):
        try:
            res = search_actionable(q, today)
        except Exception as e:
            per_query[q] = {"error": type(e).__name__}
            complete = False          # мовчазна порожнеча заборонена
            continue
        per_query[q] = {"found": len(res["items"]), "dropped": res["dropped"],
                        "total": res["total"]}
        dropped += res["dropped"]
        raw_count += len(res["items"])
        complete = complete and res.get("complete", False)
        for b in res["items"]:
            tid = (b or {}).get("tender_id")
            if tid and tid not in seen:
                seen[tid] = b
    # ⭐⭐⭐ 01.08.2026. ПОШУК ДАЄ КАНДИДАТІВ, А НЕ ВІДПОВІДЬ. Повнотекстовий
    # пошук Прозорро знаходить слово і в назві замовника, і в описі: за словом
    # «Воїн» приходять ритуальні послуги та меморіальні дошки. Сторож слав би це
    # клієнту в Telegram так само, як архів клав у таблицю. Суддя ОДИН —
    # `tender_qualify.on_topic`; звуження ВИДИМЕ (`off_topic`), як і решта.
    off_topic = 0
    try:
        import tender_qualify as TQ
        kept = {}
        for tid, b in seen.items():
            if TQ.on_topic((b or {}).get("title"), phrases=profile_queries):
                kept[tid] = b
            else:
                off_topic += 1
        seen = kept
    except Exception:
        off_topic = 0
    return {"items": list(seen.values()), "per_query": per_query,
            "duplicates": raw_count - len(seen) - off_topic, "dropped": dropped,
            "off_topic": off_topic, "complete": complete}
