# -*- coding: utf-8 -*-
"""
taskdesk_people.py — ОРГСТРУКТУРА TASK DESK: підрозділи, посади, працівники.

Крок 1.1 етапу 1 (проєкт: «Аудити та стратегії\TaskDesk_етап1_детальний_проєкт_06.08.2026.md»).
Це фундамент, якого в платформі не було взагалі: сьогодні вона одноосібна й
поняття «працівник», «підрозділ», «хто чий керівник» не існує ніде.

ТРИ ЗАКОНИ, ЗА ЯКИМИ ЦЕЙ ФАЙЛ ЗБУДОВАНО (уклад узятий із `scheduler.py`,
де він уже доведений):
  1. ОДИН НОРМАЛІЗАТОР — `_normalize()`. Будь-який запис, хоч побитий, виходить
     звідси з повним набором полів. Зламаність — це ОЗНАКА (`broken` +
     `broken_reason`), а не окреме життя й не тиша.
  2. ОДИН ЧИТАЧ — `load()`. І людина, і будь-який інший код беруть правду звідси.
     `read_text` цього файла стану є РІВНО В ОДНОМУ місці модуля.
  3. ОДИН ПИСАР — `save()`. Кожна зміна лишає слід в `audit[]`, тому журнал
     оргструктури дописується в одному місці, а не в десяти.

⭐⭐⭐ ГОЛОВНЕ АРХІТЕКТУРНЕ РІШЕННЯ: «ХТО ЧИЙ КЕРІВНИК» НЕ ЗБЕРІГАЄТЬСЯ.
Воно ОБЧИСЛЮЄТЬСЯ з дерева підрозділів при читанні (`manager_of`). Якби керівник
лежав полем у працівника, ми б отримали двох писарів однієї правди: перемістили
підрозділ — і половина карток тихо бреше. Похідні поля не лягають на диск ніколи
(`DERIVED_*`), рівно як у планувальнику.

⚠ ПРАЦІВНИКА НЕ ВИДАЛЯЮТЬ. Звільнений стає неактивним: нових задач не отримує,
але лишається у всіх старих записах. Видалення осиротило б історію задач, а
історія — це те, заради чого Task Desk узагалі будується. Тому функції видалення
працівника в цьому модулі НЕМАЄ (це перевіряє чек деревом коду).
"""

import json
import re
import uuid
from pathlib import Path

import clock          # ОДИН ПИСАР ЧАСУ на весь продукт
import config

# Тека стану Task Desk. У клієнта вона своя; чеки відводять її вбік через
# config.STATE_DIR, тому бойова тека від прогонів не смітиться.
DESK_DIR = config.STATE_DIR / "taskdesk"
PEOPLE_JSON = DESK_DIR / "people.json"

AUDIT_KEEP = 200

# Похідні поля: ОБЧИСЛЮЮТЬСЯ при читанні й НІКОЛИ не лежать на диску.
DERIVED_UNIT = ("broken", "broken_reason", "depth", "path", "head_name")
DERIVED_EMP = ("broken", "broken_reason", "manager_id", "manager_name", "unit_name",
               "position_name", "can_receive_tasks", "direct_report_ids", "photo_url",
               # ⭐ ЗАМІЩЕННЯ (зміна 224): на диску лежить лише ПЕРІОД, а
               # «хто зараз за кого» ОБЧИСЛЮЄТЬСЯ. Зберігати обчислене
               # означало б завести другого писаря, який завтра відстане
               # від календаря.
               "absent_now", "deputy_id", "deputy_name", "absent_from",
               "absent_to", "deputy_broken", "principal_ids", "principal_names")

# Фото працівників лежать поруч зі станом; у картці зберігається лише імʼя файла.
PHOTOS_DIR = DESK_DIR / "photos"

# ⭐ Фото приймається за ВМІСТОМ, а не за назвою: «фото.png», усередині якого
# лежить не картинка, — найдешевший спосіб покласти в теку клієнта що завгодно.
PHOTO_KINDS = (
    (b"\x89PNG\r\n\x1a\n", "png", "image/png"),
    (b"\xff\xd8\xff", "jpg", "image/jpeg"),
    (b"RIFF", "webp", "image/webp"),
)
MAX_PHOTO_BYTES = 2 * 1024 * 1024


class PeopleError(Exception):
    """Відмова писаря, названа людськими словами. Тиші тут не буває."""


# ---------------------------------------------------------------------------
# ОДИН НОРМАЛІЗАТОР
# ---------------------------------------------------------------------------
def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _check_card_fields(fields: dict):
    """Перевірка полів картки. Кожна відмова називає причину словами —
    мовчазне «зрізали й записали» заборонене."""
    b = _s(fields.get("birthday"))
    if b and not re.match(r"^\d{4}-\d{2}-\d{2}$", b):
        raise PeopleError("день народження пишеться як 1980-05-17 (рік-місяць-день); "
                          "у картці людині він показується як 17.05.1980")
    for key, human in (("phone_mobile", "мобільний"), ("phone_work", "робочий")):
        v = _s(fields.get(key))
        if v and len(re.sub(r"\D", "", v)) < 7:
            raise PeopleError("%s телефон «%s» не схожий на номер" % (human, v))
    e = _s(fields.get("email"))
    if e and not re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", e):
        raise PeopleError("пошта «%s» не схожа на адресу" % e)
    ph = _s(fields.get("photo"))
    if ph and ("/" in ph or "\\" in ph or ".." in ph):
        raise PeopleError("у картці зберігається лише імʼя файла фото, не шлях")


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЗАМІЩЕННЯ НА ЧАС ВІДСУТНОСТІ (зміна 224, 26.08.2026).
#
# КОРІНЬ: права в Task Desk прибиті до `id` людини. Людина пішла у відпустку —
# і все, що чекало саме її руки, стоїть. Обхідні шляхи псували правду: або
# адміністратор міняв виконавця (задача назавжди переставала бути задачею Y),
# або постановник переставляв сам — а якщо у відпустці постановник, приймати
# роботу не було кому взагалі.
#
# РІШЕННЯ: не копія задачі й не нова стадія, а ШАР НАД РОЛЯМИ — за формою
# такий самий, як уже наявний шар адміністратора. На диску лежить лише ПЕРІОД
# з делегатом; «хто зараз за кого» рахується з календаря при читанні.
#
# 🩸 Рішення Андрія 26.08.2026: делегат бере ПОВНІ права відсутнього, і кожна
# його дія підписана «Х (заміщує Y)».
# ---------------------------------------------------------------------------
DATE_LEN = 10                       # 2026-09-01


def today() -> str:
    """Сьогоднішня дата ОДНИМ писарем часу. Заміщення живе за календарем, тому
    брати день з `datetime` машини заборонено так само, як і час."""
    return clock.now()[:DATE_LEN]


def _norm_absences(raw) -> list:
    """Періоди відсутності в єдиному вигляді. Побите значення не валить читання
    оргструктури: воно просто не стає періодом."""
    out = []
    for a in (raw or []):
        if not isinstance(a, dict):
            continue
        item = {"id": _s(a.get("id")) or _new_id("abs"),
                "from": _s(a.get("from"))[:DATE_LEN],
                "to": _s(a.get("to"))[:DATE_LEN],
                "delegate_id": _s(a.get("delegate_id")),
                "reason": _s(a.get("reason"))}
        if not (item["from"] and item["to"] and item["delegate_id"]):
            continue
        out.append(item)
    return out


def _active_absence(emp: dict, day: str) -> dict:
    """Період, який триває САМЕ ЗАРАЗ. Кінці включно: «по 14.09» означає, що
    14.09 людини ще немає."""
    for a in (emp.get("absences") or []):
        if a["from"] <= day <= a["to"]:
            return a
    return {}


def _check_absence_dates(date_from: str, date_to: str):
    for v, human in ((date_from, "початок"), (date_to, "кінець")):
        if not re.match(r"^\d{4}-\d{2}-\d{2}$", _s(v)):
            raise PeopleError("%s відсутності пишеться як 2026-09-01 "
                              "(рік-місяць-день)" % human)
    if _s(date_to) < _s(date_from):
        raise PeopleError("кінець відсутності раніший за початок")


def _new_id(prefix: str) -> str:
    return "%s-%s" % (prefix, uuid.uuid4().hex[:8])


def _unit_chain(units_by_id: dict, unit_id: str) -> list:
    """Ланцюг підрозділів від заданого до кореня. Цикл НЕ вішає систему:
    щойно вузол повторився — ланцюг обривається (а сам цикл позначається)."""
    chain, seen = [], set()
    cur = _s(unit_id)
    while cur and cur in units_by_id and cur not in seen:
        seen.add(cur)
        chain.append(cur)
        cur = _s(units_by_id[cur].get("parent_id"))
    return chain


def _normalize(raw) -> dict:
    """ЄДИНЕ представлення оргструктури. Приймає будь-що, віддає повний запис."""
    if not isinstance(raw, dict):
        raw = {}

    units, positions, employees = [], [], []
    for u in (raw.get("units") or []):
        if not isinstance(u, dict):
            continue
        units.append({"id": _s(u.get("id")) or _new_id("unit"),
                      "name": _s(u.get("name")),
                      "parent_id": _s(u.get("parent_id")),
                      "head_employee_id": _s(u.get("head_employee_id"))})
    for p in (raw.get("positions") or []):
        if not isinstance(p, dict):
            continue
        positions.append({"id": _s(p.get("id")) or _new_id("pos"),
                          "name": _s(p.get("name"))})
    for e in (raw.get("employees") or []):
        if not isinstance(e, dict):
            continue
        employees.append({"id": _s(e.get("id")) or _new_id("emp"),
                          "full_name": _s(e.get("full_name")),
                          "unit_id": _s(e.get("unit_id")),
                          "position_id": _s(e.get("position_id")),
                          "email": _s(e.get("email")),
                          "telegram_id": _s(e.get("telegram_id")),
                          # ⭐ Картка працівника (рішення Андрія 06.08.2026).
                          # «У кого в підпорядкуванні» і «ким керує» тут НЕ
                          # зберігаються: вони обчислюються з дерева.
                          "birthday": _s(e.get("birthday")),
                          "phone_mobile": _s(e.get("phone_mobile")),
                          "phone_work": _s(e.get("phone_work")),
                          "photo": _s(e.get("photo")),
                          "active": bool(e.get("active", True)),
                          "hired_at": _s(e.get("hired_at")),
                          "dismissed_at": _s(e.get("dismissed_at")),
                          # ⭐ Періоди відсутності з делегатом (зміна 224).
                          "absences": _norm_absences(e.get("absences"))})

    units_by_id = {u["id"]: u for u in units}
    pos_by_id = {p["id"]: p for p in positions}
    emp_by_id = {e["id"]: e for e in employees}

    # ── підрозділи: глибина, шлях і чесна ознака зламаності ────────────────
    for u in units:
        reasons = []
        parent = u["parent_id"]
        if parent and parent not in units_by_id:
            reasons.append("батьківського підрозділу «%s» немає" % parent)
        chain = _unit_chain(units_by_id, u["id"])
        # Цикл: піднімаючись угору, знову впираємось у себе.
        cur, seen, cycle = _s(u["parent_id"]), set(), False
        while cur and cur in units_by_id and cur not in seen:
            if cur == u["id"]:
                cycle = True
                break
            seen.add(cur)
            cur = _s(units_by_id[cur].get("parent_id"))
        if cycle:
            reasons.append("підрозділ підпорядкований сам собі (кільце в дереві)")
        head = u["head_employee_id"]
        if head and head not in emp_by_id:
            reasons.append("керівника «%s» немає серед працівників" % head)
        if not u["name"]:
            reasons.append("немає назви")
        u["depth"] = len(chain) - 1 if chain else 0
        u["path"] = " / ".join(_s(units_by_id[c]["name"]) for c in reversed(chain))
        u["head_name"] = _s(emp_by_id.get(head, {}).get("full_name"))
        u["broken"] = bool(reasons)
        u["broken_reason"] = "; ".join(reasons)

    # ── працівники: керівник ОБЧИСЛЮЄТЬСЯ, а не зберігається ───────────────
    for e in employees:
        reasons = []
        if not e["full_name"]:
            reasons.append("немає ПІБ")
        if e["unit_id"] and e["unit_id"] not in units_by_id:
            reasons.append("підрозділу «%s» немає" % e["unit_id"])
        if e["position_id"] and e["position_id"] not in pos_by_id:
            reasons.append("посади «%s» немає" % e["position_id"])
        e["unit_name"] = _s(units_by_id.get(e["unit_id"], {}).get("name"))
        e["position_name"] = _s(pos_by_id.get(e["position_id"], {}).get("name"))
        e["manager_id"] = _manager_id(units_by_id, e)
        e["photo_url"] = ("taskdesk/photos/%s" % e["photo"]) if e["photo"] else ""
        e["can_receive_tasks"] = bool(e["active"]) and not reasons
        e["broken"] = bool(reasons)
        e["broken_reason"] = "; ".join(reasons)

    # ── ЗАМІЩЕННЯ: хто зараз відсутній і хто за нього (зміна 224) ─────────
    # ⭐⭐⭐ ЗАМІЩЕННЯ НЕ ТРАНЗИТИВНЕ І НЕ ЛАНЦЮГОВЕ. Ланцюг тут не будується
    # ФІЗИЧНО: список принципалів береться ОДНИМ проходом по тих, хто назвав
    # цю людину делегатом. Якщо делегат сам відсутній — заміщення мертве, а не
    # передається далі: інакше через три картки права розповзлись би по всій
    # компанії, і ніхто б не довів, звідки вони взялись.
    day = today()
    for e in employees:
        act = _active_absence(e, day)
        e["absent_now"] = bool(act)
        e["absent_from"] = _s(act.get("from")) if act else ""
        e["absent_to"] = _s(act.get("to")) if act else ""
        e["deputy_id"] = _s(act.get("delegate_id")) if act else ""
    for e in employees:
        dep = emp_by_id.get(e["deputy_id"]) if e["deputy_id"] else None
        e["deputy_name"] = _s(dep.get("full_name")) if dep else ""
        # Чесна ознака: делегата назвали, а він не може прийняти права.
        why = ""
        if e["absent_now"] and e["deputy_id"]:
            if not dep:
                why = "делегата «%s» немає серед працівників" % e["deputy_id"]
            elif not dep.get("active"):
                why = "делегат звільнений"
            elif dep.get("absent_now"):
                why = "делегат сам відсутній"
        e["deputy_broken"] = why
    for e in employees:
        # Кого ця людина заміщує ПРЯМО ЗАРАЗ.
        # ⛒ ОДИН СТОРОЖ НА ОДНЕ ПРАВИЛО. Тут навмисно НЕМАЄ ні
        # «o["absent_now"]», ні «o["id"] != e["id"]»: перше вже сказане тим, що
        # делегат зʼявляється лише на час періоду (`_active_absence`), друге —
        # тим, що самозаміщення завжди означає «делегат сам відсутній» і ловиться
        # `deputy_broken`. Два сторожі на одне правило — це нуль сторожів:
        # зняття будь-якого поодинці нічого не ламає, і мутація йде непоміченою.
        for_whom = [o["id"] for o in employees
                    if o["deputy_id"] == e["id"] and not o["deputy_broken"]]
        e["principal_ids"] = for_whom
        e["principal_names"] = [_s(emp_by_id.get(i, {}).get("full_name"))
                                for i in for_whom]

    # «Ким керує» — теж обчислюване: прямі підлеглі це ті, для кого ця людина
    # вийшла керівником. Зберігати цей список означало б другого писаря правди.
    reports = {}
    for e in employees:
        if e["manager_id"]:
            reports.setdefault(e["manager_id"], []).append(e["id"])
    for e in employees:
        e["manager_name"] = _s(emp_by_id.get(e["manager_id"], {}).get("full_name"))
        e["direct_report_ids"] = reports.get(e["id"], [])

    return {"units": units, "positions": positions, "employees": employees,
            "audit": [a for a in (raw.get("audit") or []) if isinstance(a, dict)]}


def _manager_id(units_by_id: dict, emp: dict) -> str:
    """Керівник працівника — керівник його підрозділу; якщо працівник САМ
    керівник цього підрозділу, піднімаємось на рівень вище. Кільце в дереві не
    вішає розрахунок: ланцюг уже обірваний у `_unit_chain`."""
    chain = _unit_chain(units_by_id, emp.get("unit_id"))
    for unit_id in chain:
        head = _s(units_by_id[unit_id].get("head_employee_id"))
        if head and head != emp.get("id"):
            return head
    return ""


def _strip_derived(state: dict) -> dict:
    """Те, що лягає на диск: без жодного обчисленого поля."""
    out = {"units": [], "positions": [], "employees": [],
           "audit": list(state.get("audit") or [])}
    for u in state.get("units") or []:
        out["units"].append({k: v for k, v in u.items() if k not in DERIVED_UNIT})
    for p in state.get("positions") or []:
        out["positions"].append(dict(p))
    for e in state.get("employees") or []:
        out["employees"].append({k: v for k, v in e.items() if k not in DERIVED_EMP})
    return out


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ
# ---------------------------------------------------------------------------
def load() -> dict:
    """ЄДИНИЙ ЧИТАЧ оргструктури. Побитий файл не зникає: він повертається
    порожньою структурою з причиною в `unreadable_reason`, і писар відмовиться
    писати поверх нього (fail-closed над чужою роботою)."""
    if not PEOPLE_JSON.exists():
        st = _normalize({})
        st["unreadable_reason"] = ""
        return st
    try:
        raw = json.loads(PEOPLE_JSON.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            st = _normalize({})
            st["unreadable_reason"] = ("у файлі не оргструктура, а %s"
                                       % type(raw).__name__)
            return st
        st = _normalize(raw)
        st["unreadable_reason"] = ""
        return st
    except Exception as e:
        st = _normalize({})
        st["unreadable_reason"] = "файл не читається: %s" % type(e).__name__
        return st


def units() -> list:
    return load()["units"]


def positions() -> list:
    return load()["positions"]


def employees(include_dismissed: bool = False) -> list:
    """⭐ 06.08.2026 (Андрій): звільнений НЕ показується за замовчуванням.
    Він не зник — щоб побачити всіх, треба попросити явно
    (`include_dismissed=True`). Так список працівників лишається списком тих,
    хто працює, а історія нікуди не дівається."""
    out = load()["employees"]
    return out if include_dismissed else [e for e in out if e["active"]]


def employee(emp_id: str) -> dict:
    for e in load()["employees"]:
        if e["id"] == _s(emp_id):
            return e
    return None


def unit(unit_id: str) -> dict:
    for u in load()["units"]:
        if u["id"] == _s(unit_id):
            return u
    return None


def manager_of(emp_id: str) -> str:
    """Хто керівник цього працівника. Обчислюється щоразу з дерева."""
    e = employee(emp_id)
    return e["manager_id"] if e else ""


def direct_reports(emp_id: str) -> list:
    """Ким керує безпосередньо (для картки працівника)."""
    e = employee(emp_id)
    return list(e["direct_report_ids"]) if e else []


def is_manager_of(boss_id: str, emp_id: str, state: dict = None) -> bool:
    """Чи є `boss_id` керівником `emp_id` на будь-якому рівні вгору.
    `state` — уже прочитана оргструктура: щоб не читати файл на кожну пару."""
    st = state or load()
    chain_of = {e["id"]: e["manager_id"] for e in st["employees"]}
    boss_id, seen, cur = _s(boss_id), set(), _s(emp_id)
    while cur and cur not in seen:
        seen.add(cur)
        nxt = chain_of.get(cur, "")
        if not nxt:
            return False
        if nxt == boss_id:
            return True
        cur = nxt
    return False


def subordinates_of(emp_id: str) -> list:
    """Усі, для кого ця людина — керівник (свій підрозділ і все, що нижче)."""
    st = load()
    return [e["id"] for e in st["employees"] if is_manager_of(emp_id, e["id"], st)]


# ⭐⭐⭐ 24.08.2026. ПОРОЖНЯ СИСТЕМА — ЦЕ НЕ ПОМИЛКА, А ПЕРШИЙ КРОК.
# Клієнт, якому щойно відкрили Task Desk, не має ні підрозділів, ні працівників.
# Доти екран задач відповідав йому «Увійдіть під своїм працівником» — глухий
# кут: увійти нема під ким. Тепер відповідь на «чому ще не працює» має ОДНОГО
# писаря, і його однаково питають екран, постановка задачі й телеграм-пульт.
# ⛒ Слова тут, а не в екрані: інакше телеграм казав би своє, а сторінка своє.
SETUP_NO_PEOPLE = "no_people"
SETUP_NOT_EMPLOYEE = "not_employee"
SETUP_READY = "ready"
SETUP_CODE = "setup_needed"          # машинний код для екрана
SETUP_WHERE = "Працівники й підрозділи"


def setup_state(emp_id: str = "") -> dict:
    """ЧОМУ TASK DESK ЩЕ НЕ ПРАЦЮЄ ДЛЯ ЦІЄЇ ЛЮДИНИ І ЩО ЗРОБИТИ ПЕРШИМ.

    Три відповіді, і кожна лікується по-різному:
      • людей ще немає взагалі — заводити оргструктуру;
      • люди є, але цієї людини серед них немає — завести картку на себе;
      • усе гаразд.
    """
    if not employees():
        return {"ready": False, "stage": SETUP_NO_PEOPLE, "code": SETUP_CODE,
                "where": SETUP_WHERE,
                "title": "Task Desk ще порожній",
                "hint": ("Платформа поки не знає ваших людей. Почніть із розділу "
                         "«%s»: заведіть підрозділ і кількох працівників — після "
                         "цього можна ставити задачі." % SETUP_WHERE)}
    if not _s(emp_id) or not employee(_s(emp_id)):
        return {"ready": False, "stage": SETUP_NOT_EMPLOYEE, "code": SETUP_CODE,
                "where": SETUP_WHERE,
                "title": "Вас ще немає в переліку працівників",
                "hint": ("Задачі ставить і виконує працівник компанії, а вашої "
                         "картки в переліку ще немає. Заведіть її в розділі «%s» "
                         "— і зможете ставити задачі." % SETUP_WHERE)}
    return {"ready": True, "stage": SETUP_READY, "code": "", "where": "",
            "title": "", "hint": ""}


def card(emp_id: str) -> dict:
    """КАРТКА ПРАЦІВНИКА (склад узгоджений з Андрієм 06.08.2026).
    Половина картки — обчислена: керівник і підлеглі беруться з дерева, а не
    зберігаються полями."""
    e = employee(emp_id)
    if not e:
        return None
    st = load()
    by_id = {x["id"]: x for x in st["employees"]}
    return {
        "id": e["id"],
        "full_name": e["full_name"],
        "position": e["position_name"],
        "unit": e["unit_name"],
        "birthday": e["birthday"],
        "manager": {"id": e["manager_id"], "name": e["manager_name"]},
        "manages": [{"id": i, "name": _s(by_id.get(i, {}).get("full_name"))}
                    for i in e["direct_report_ids"]],
        "phone_mobile": e["phone_mobile"],
        "phone_work": e["phone_work"],
        "email": e["email"],
        "telegram_id": e["telegram_id"],
        # ⭐ Не лише НАЗВИ, а й ідентифікатори: форма правки має чим заповнити
        # вибір підрозділу й посади. Назва для ока, ідентифікатор для машини.
        "unit_id": e["unit_id"],
        "position_id": e["position_id"],
        "photo_url": e["photo_url"],
        "active": e["active"],
        "dismissed_at": e["dismissed_at"],
        # ⭐ ЗАМІЩЕННЯ (зміна 224) — обидва боки в одному місці: «мене немає, за
        # мене Х» і «я зараз за Y». Другий бік важливіший: саме він пояснює
        # людині, звідки в неї взялись чужі задачі.
        "absences": [dict(a) for a in e["absences"]],
        "absent_now": e["absent_now"],
        "absent_from": e["absent_from"],
        "absent_to": e["absent_to"],
        "deputy": {"id": e["deputy_id"], "name": e["deputy_name"]},
        "deputy_broken": e["deputy_broken"],
        "i_stand_for": [{"id": i, "name": n}
                        for i, n in zip(e["principal_ids"], e["principal_names"])],
    }


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ХТО ЩО МОЖЕ ПРАВИТИ В КАРТЦІ. ОДНА ВІДПОВІДЬ НА ВЕСЬ ПРОДУКТ.
#
# Рішення Андрія 08.08.2026: «людина може правити свої дані. Це норма.»
# Тому картка ділиться НЕ на «читати/писати», а на ДВА ШАРИ:
#   • СВОЄ — як з тобою звʼязатись і коли тебе вітати. Це знає сама людина,
#     і бігати з цим до адміністратора — марна робота для обох.
#   • МІСЦЕ В КОМПАНІЇ — імʼя, посада, підрозділ. Це не про людину, це про
#     структуру: підрозділ тягне за собою керівника, видимість задач і права.
#     Такого собі не призначають.
#
# Цю відповідь питають ОБИДВА: екран — щоб намалювати поля, і код дії — щоб не
# пустити чужого. Друга відповідь у другому місці розійшлася б із першою, і
# зʼявилась би кнопка, яка відмовить, — брехня на екрані.
# ---------------------------------------------------------------------------
SELF_FIELDS = ("phone_mobile", "phone_work", "email", "birthday", "telegram_id")
ADMIN_FIELDS = ("full_name", "unit_id", "position_id")
EDITABLE_FIELDS = SELF_FIELDS + ADMIN_FIELDS

FIELD_NAMES = {
    "full_name": "ПІБ", "unit_id": "підрозділ", "position_id": "посада",
    "phone_mobile": "мобільний телефон", "phone_work": "робочий телефон",
    "email": "пошта", "birthday": "день народження", "telegram_id": "телеграм",
}


def card_rights(actor_emp_id: str, emp_id: str, is_admin: bool = False) -> dict:
    """ЩО САМЕ ця людина може правити в ЦІЙ картці.

    ⭐ Звільненого править лише адміністратор: його картка — вже історія, а не
    його робоче місце."""
    actor_emp_id, emp_id = _s(actor_emp_id), _s(emp_id)
    e = employee(emp_id)
    active = bool(e and e["active"])
    is_self = bool(actor_emp_id) and actor_emp_id == emp_id
    fields = []
    if is_admin:
        fields = list(ADMIN_FIELDS) + list(SELF_FIELDS)
    elif is_self and active:
        fields = list(SELF_FIELDS)
    # ⭐ ВІДСУТНІСТЬ — ОКРЕМЕ ПРАВО, А НЕ ПОЛЕ КАРТКИ. Її заводить сама людина,
    # ЇЇ КЕРІВНИК або адміністратор. Керівник тут не зайвий: людина може зникнути
    # раптово і вже нічого не ввести, а робота стоятиме.
    may_absence = bool(active) and (is_admin or is_self
                                    or (bool(actor_emp_id)
                                        and is_manager_of(actor_emp_id, emp_id)))
    return {"fields": fields,
            "photo": bool(fields),
            "may_edit": bool(fields),
            "absence": may_absence,
            "is_self": is_self,
            "is_admin": bool(is_admin)}


def who_may_edit(field: str) -> str:
    """Відмова завжди називає ТОГО, ХТО Б ЦЕ ЗМІГ. Тиха відмова = вимкнені ворота."""
    return ("адміністратор" if field in ADMIN_FIELDS
            else "сама людина або адміністратор")


def can_receive_tasks(emp_id: str) -> bool:
    """Звільнений лишається в історії, але нових задач не отримує ніколи."""
    e = employee(emp_id)
    return bool(e and e["can_receive_tasks"])


# ---------------------------------------------------------------------------
# ЗАМІЩЕННЯ: ОДИН ЧИТАЧ І ОДИН ПИСАР
# ---------------------------------------------------------------------------
# ⭐ ШВИДКИЙ ЧИТАЧ. `principals_of()` питають на КОЖНУ задачу в списку, тому
# читати й нормалізувати весь файл щоразу не можна. Памʼять тут не бреше: вона
# прибита до відбитка файла (шлях · час · розмір · лічильник наших записів) і
# до ДНЯ — щойно змінилось будь-що з цього, карта будується наново.
_DEPUTY = {"stamp": None, "principals": {}, "deputies": {}}
_WRITES = 0


def _stamp() -> tuple:
    try:
        st = PEOPLE_JSON.stat()
        return (str(PEOPLE_JSON), st.st_mtime_ns, st.st_size, _WRITES, today())
    except OSError:
        return (str(PEOPLE_JSON), 0, 0, _WRITES, today())


def _deputy_maps() -> tuple:
    stamp = _stamp()
    if _DEPUTY["stamp"] != stamp:
        principals, deputies = {}, {}
        for e in load()["employees"]:
            if e["principal_ids"]:
                principals[e["id"]] = tuple(e["principal_ids"])
            if e["absent_now"] and e["deputy_id"] and not e["deputy_broken"]:
                deputies[e["id"]] = {"id": e["deputy_id"], "name": e["deputy_name"],
                                     "from": e["absent_from"], "to": e["absent_to"]}
        _DEPUTY["principals"], _DEPUTY["deputies"] = principals, deputies
        _DEPUTY["stamp"] = stamp
    return _DEPUTY["principals"], _DEPUTY["deputies"]


def principals_of(emp_id: str) -> tuple:
    """КОГО ця людина заміщує прямо зараз. Порожньо — звичайний випадок.

    ⛒ Ланцюг не будується: якщо Y заміщує Z, а X заміщує Y, то X НЕ отримує
    прав Z. Тут повертається рівно один крок, і другого кроку в коді немає."""
    principals, _ = _deputy_maps()
    return principals.get(_s(emp_id), ())


def deputy_of(emp_id: str) -> dict:
    """ХТО ЗАРАЗ ЗА ЦЮ ЛЮДИНУ. Порожньо, якщо вона на місці або делегат не може
    прийняти права (звільнений, сам відсутній) — і тоді це видно словами в
    картці, а не мовчазним «нічого не сталось»."""
    _, deputies = _deputy_maps()
    return dict(deputies.get(_s(emp_id)) or {})


def absences_of(emp_id: str) -> list:
    e = employee(emp_id)
    return list(e["absences"]) if e else []


def set_absence(emp_id: str, date_from: str, date_to: str, delegate_id: str,
                reason: str = "") -> dict:
    """Завести період відсутності з делегатом.

    ⛒ МЕЖІ, БЕЗ ЯКИХ ЦЕ ЗБРОЯ: себе не заміщують · делегатом не буває той, хто
    не може отримувати задачі · кільце (X за Y і Y за X у ті самі дні)
    заборонене · періоди однієї людини не перетинаються · період, що вже
    минув, не заводиться."""
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id, delegate_id = _s(emp_id), _s(delegate_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    if not delegate_id:
        raise PeopleError("відсутність без делегата не заводиться: саме він "
                          "веде роботу, поки людини немає")
    if delegate_id == emp_id:
        raise PeopleError("людина не заміщує сама себе")
    if delegate_id not in by_id:
        raise PeopleError("делегата «%s» немає" % delegate_id)
    _check_absence_dates(date_from, date_to)
    date_from, date_to = _s(date_from), _s(date_to)
    if date_to < today():
        raise PeopleError("цей період уже минув (%s), заводити його нема сенсу"
                          % date_to)
    if not by_id[delegate_id]["can_receive_tasks"]:
        raise PeopleError("«%s» не може бути делегатом: %s"
                          % (by_id[delegate_id]["full_name"],
                             by_id[delegate_id]["broken_reason"] or "звільнений"))
    for a in by_id[emp_id]["absences"]:
        if a["from"] <= date_to and date_from <= a["to"]:
            raise PeopleError("на ці дні відсутність уже заведена (%s — %s): "
                              "два делегати на один день означали б дві "
                              "відповіді на питання «хто зараз за людину»"
                              % (a["from"], a["to"]))
    for a in by_id[delegate_id]["absences"]:
        if a["delegate_id"] == emp_id and a["from"] <= date_to and date_from <= a["to"]:
            raise PeopleError("кільце: «%s» на ці самі дні заміщує «%s». "
                              "Хтось із двох мусить лишитись на місці"
                              % (by_id[delegate_id]["full_name"],
                                 by_id[emp_id]["full_name"]))
    item = {"id": _new_id("abs"), "from": date_from, "to": date_to,
            "delegate_id": delegate_id, "reason": _s(reason)}
    by_id[emp_id]["absences"] = list(by_id[emp_id]["absences"]) + [item]
    save(st, "відсутність «%s» з %s по %s, заміщує «%s»"
         % (by_id[emp_id]["full_name"], date_from, date_to,
            by_id[delegate_id]["full_name"]))
    return employee(emp_id)


def clear_absence(emp_id: str, absence_id: str) -> dict:
    """Прибрати період. Видалення НЕ вгадує форму: id періоду називають прямо."""
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id, absence_id = _s(emp_id), _s(absence_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    have = by_id[emp_id]["absences"]
    left = [a for a in have if a["id"] != absence_id]
    if len(left) == len(have):
        raise PeopleError("такого періоду відсутності в картці немає")
    by_id[emp_id]["absences"] = left
    save(st, "прибрано період відсутності «%s»" % by_id[emp_id]["full_name"])
    return employee(emp_id)


# ---------------------------------------------------------------------------
# ОДИН ПИСАР
# ---------------------------------------------------------------------------
def save(state: dict, reason: str) -> dict:
    """ЄДИНЕ місце у продукті, де оргструктура лягає на диск.

    `reason` — людськими словами, ЩО саме змінилось; лягає в `audit[]`.
    FAIL-CLOSED: якщо на диску лежить нечитабельний файл, писати поверх
    заборонено — врятувати руками ще можна, а затерте вже ні."""
    if not _s(reason):
        raise PeopleError("зміна без причини не пишеться: журнал оргструктури "
                          "мусить лишатись читабельним")
    on_disk = load()
    if on_disk.get("unreadable_reason"):
        raise PeopleError("оргструктура на диску не читається (%s) — писати "
                          "поверх заборонено, поки людина не вирішить її долю"
                          % on_disk["unreadable_reason"])
    st = _normalize(state)
    disk = _strip_derived(st)
    disk["audit"] = list(disk.get("audit") or [])
    disk["audit"].append({"at": clock.now(), "what": _s(reason)[:300]})
    disk["audit"] = disk["audit"][-AUDIT_KEEP:]
    DESK_DIR.mkdir(parents=True, exist_ok=True)
    PEOPLE_JSON.write_text(json.dumps(disk, ensure_ascii=False, indent=2),
                           encoding="utf-8")
    # ⛒ Швидкий читач заміщення памʼятає карту за відбитком файла. Час файла на
    # деяких дисках грубий, тому писар піднімає ще й лічильник: інакше два
    # записи в одну мить лишили б у памʼяті вчорашню правду.
    global _WRITES
    _WRITES += 1
    out = _normalize(disk)
    out["unreadable_reason"] = ""
    return out


# ---------------------------------------------------------------------------
# Дії над оргструктурою (усі проходять через одного писаря)
# ---------------------------------------------------------------------------
def add_unit(name: str, parent_id: str = "", head_employee_id: str = "") -> dict:
    st = load()
    name = _s(name)
    if not name:
        raise PeopleError("підрозділ без назви не заводиться")
    ids = {u["id"] for u in st["units"]}
    if _s(parent_id) and _s(parent_id) not in ids:
        raise PeopleError("батьківського підрозділу «%s» немає" % parent_id)
    if _s(head_employee_id) and _s(head_employee_id) not in {e["id"] for e in st["employees"]}:
        raise PeopleError("керівника «%s» немає серед працівників" % head_employee_id)
    rec = {"id": _new_id("unit"), "name": name, "parent_id": _s(parent_id),
           "head_employee_id": _s(head_employee_id)}
    st["units"].append(rec)
    save(st, "заведено підрозділ «%s»" % name)
    return unit(rec["id"])


def set_unit_parent(unit_id: str, parent_id: str) -> dict:
    """Переміщення гілки. Кільце заборонене ВОРОТАМИ, а не проханням."""
    st = load()
    by_id = {u["id"]: u for u in st["units"]}
    unit_id, parent_id = _s(unit_id), _s(parent_id)
    if unit_id not in by_id:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    if parent_id:
        if parent_id not in by_id:
            raise PeopleError("батьківського підрозділу «%s» немає" % parent_id)
        if parent_id == unit_id:
            raise PeopleError("підрозділ не може бути підпорядкований сам собі")
        # Новий батько не сміє бути нащадком цього ж підрозділу.
        cur, seen = parent_id, set()
        while cur and cur in by_id and cur not in seen:
            if cur == unit_id:
                raise PeopleError("так вийде кільце: «%s» лежить усередині «%s»"
                                  % (by_id[parent_id]["name"], by_id[unit_id]["name"]))
            seen.add(cur)
            cur = _s(by_id[cur].get("parent_id"))
    by_id[unit_id]["parent_id"] = parent_id
    save(st, "підрозділ «%s» переміщено" % by_id[unit_id]["name"])
    return unit(unit_id)


def set_unit_head(unit_id: str, head_employee_id: str) -> dict:
    st = load()
    by_id = {u["id"]: u for u in st["units"]}
    unit_id, head = _s(unit_id), _s(head_employee_id)
    if unit_id not in by_id:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    if head and head not in {e["id"] for e in st["employees"]}:
        raise PeopleError("керівника «%s» немає серед працівників" % head)
    by_id[unit_id]["head_employee_id"] = head
    save(st, "змінено керівника підрозділу «%s»" % by_id[unit_id]["name"])
    return unit(unit_id)


def add_position(name: str) -> dict:
    st = load()
    name = _s(name)
    if not name:
        raise PeopleError("посада без назви не заводиться")
    for p in st["positions"]:
        if p["name"].lower() == name.lower():
            return p
    rec = {"id": _new_id("pos"), "name": name}
    st["positions"].append(rec)
    save(st, "заведено посаду «%s»" % name)
    return rec


def add_employee(full_name: str, unit_id: str = "", position_id: str = "",
                 email: str = "", telegram_id: str = "", birthday: str = "",
                 phone_mobile: str = "", phone_work: str = "", photo: str = "") -> dict:
    st = load()
    full_name = _s(full_name)
    if not full_name:
        raise PeopleError("працівник без ПІБ не заводиться")
    if _s(unit_id) and _s(unit_id) not in {u["id"] for u in st["units"]}:
        raise PeopleError("підрозділу «%s» немає" % unit_id)
    if _s(position_id) and _s(position_id) not in {p["id"] for p in st["positions"]}:
        raise PeopleError("посади «%s» немає" % position_id)
    _check_card_fields({"email": email, "birthday": birthday, "photo": photo,
                        "phone_mobile": phone_mobile, "phone_work": phone_work})
    rec = {"id": _new_id("emp"), "full_name": full_name, "unit_id": _s(unit_id),
           "position_id": _s(position_id), "email": _s(email),
           "telegram_id": _s(telegram_id), "birthday": _s(birthday),
           "phone_mobile": _s(phone_mobile), "phone_work": _s(phone_work),
           "photo": _s(photo), "active": True,
           "hired_at": clock.now(), "dismissed_at": ""}
    st["employees"].append(rec)
    save(st, "заведено працівника «%s»" % full_name)
    return employee(rec["id"])


def update_employee(emp_id: str, **fields) -> dict:
    """Зміна картки. Керівника тут немає й бути не може — він обчислюється."""
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id = _s(emp_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    allowed = {"full_name", "unit_id", "position_id", "email", "telegram_id",
               "birthday", "phone_mobile", "phone_work", "photo"}
    unknown = set(fields) - allowed
    if unknown:
        raise PeopleError("цих полів у картці працівника немає: %s"
                          % ", ".join(sorted(unknown)))
    if "unit_id" in fields and _s(fields["unit_id"]) and \
            _s(fields["unit_id"]) not in {u["id"] for u in st["units"]}:
        raise PeopleError("підрозділу «%s» немає" % fields["unit_id"])
    if "position_id" in fields and _s(fields["position_id"]) and \
            _s(fields["position_id"]) not in {p["id"] for p in st["positions"]}:
        raise PeopleError("посади «%s» немає" % fields["position_id"])
    _check_card_fields(fields)
    for k, v in fields.items():
        by_id[emp_id][k] = _s(v)
    save(st, "змінено картку працівника «%s»" % by_id[emp_id]["full_name"])
    return employee(emp_id)


def dismiss_employee(emp_id: str, reason: str = "") -> dict:
    """Звільнення. Запис НЕ видаляється: історія задач не має осиротіти."""
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id = _s(emp_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    by_id[emp_id]["active"] = False
    by_id[emp_id]["dismissed_at"] = clock.now()
    # Звільнений не лишається керівником підрозділу: інакше дерево віддавало б
    # начальника, якого в компанії вже немає.
    for u in st["units"]:
        if u["head_employee_id"] == emp_id:
            u["head_employee_id"] = ""
    what = "звільнено працівника «%s»" % by_id[emp_id]["full_name"]
    save(st, what + (": %s" % _s(reason) if _s(reason) else ""))
    return employee(emp_id)


def _photo_kind(raw: bytes) -> tuple:
    for magic, ext, mime in PHOTO_KINDS:
        if raw[:len(magic)] == magic:
            if ext == "webp" and raw[8:12] != b"WEBP":
                continue
            return ext, mime
    return "", ""


def set_photo(emp_id: str, raw: bytes) -> dict:
    """Фото працівника. Імʼя файла робимо МИ (з id), а не приймаємо ззовні:
    назва з чужих рук — це шлях у чужу теку."""
    emp = employee(emp_id)
    if not emp:
        raise PeopleError("працівника «%s» немає" % emp_id)
    raw = raw or b""
    if len(raw) > MAX_PHOTO_BYTES:
        raise PeopleError("фото більше за %d МБ — стисніть його"
                          % (MAX_PHOTO_BYTES // (1024 * 1024)))
    ext, _mime = _photo_kind(raw)
    if not ext:
        raise PeopleError("це не схоже на картинку: приймаємо PNG, JPEG або WEBP")
    PHOTOS_DIR.mkdir(parents=True, exist_ok=True)
    for _m, old_ext, _mm in PHOTO_KINDS:      # старе фото іншого роду прибираємо
        old = PHOTOS_DIR / ("%s.%s" % (emp["id"], old_ext))
        if old.exists() and old_ext != ext:
            old.unlink()
    (PHOTOS_DIR / ("%s.%s" % (emp["id"], ext))).write_bytes(raw)
    return update_employee(emp["id"], photo="%s.%s" % (emp["id"], ext))


def photo_bytes(emp_id: str) -> tuple:
    """Фото для показу: (байти, тип). Немає — (None, "")."""
    emp = employee(emp_id)
    if not emp or not emp["photo"]:
        return None, ""
    p = PHOTOS_DIR / emp["photo"]
    if not p.exists():
        return None, ""
    raw = p.read_bytes()
    _ext, mime = _photo_kind(raw)
    return raw, (mime or "application/octet-stream")


def restore_employee(emp_id: str) -> dict:
    st = load()
    by_id = {e["id"]: e for e in st["employees"]}
    emp_id = _s(emp_id)
    if emp_id not in by_id:
        raise PeopleError("працівника «%s» немає" % emp_id)
    by_id[emp_id]["active"] = True
    by_id[emp_id]["dismissed_at"] = ""
    save(st, "поновлено працівника «%s»" % by_id[emp_id]["full_name"])
    return employee(emp_id)
