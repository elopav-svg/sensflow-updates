# -*- coding: utf-8 -*-
"""features.py — ВИМИКАЧ НЕЗАВЕРШЕНОЇ РОБОТИ (етап 2 воріт складу, 05.08.2026).

НАВІЩО. Етап 1 не пускає до клієнта НЕНАЗВАНІ файли. Але дві дірки лишались:
  • ланцюги полізуть усередину файлів, які їдуть у будь-якому разі — діф не
    ріже файл навпіл;
  • повна збірка новому клієнту порівнювати не має з чим.
Отже незавершена робота мусить бути ВИМКНЕНА, а не просто «не привезена».

ОДИН ПИСАР. Питання «чи ця робота ввімкнена» має рівно одну відповідь —
`features.enabled(work_id)`. Хто читає прапорець повз цю функцію, той стає
другим писарем, і рано чи пізно вони розійдуться.

ДЖЕРЕЛА, І ЧОМУ ЇХ ДВА, А НЕ ОДНЕ:
  • У КЛІЄНТА джерело РІВНО ОДНЕ — `features.json` поруч із рушієм. Це похідне
    від реєстру робіт, зроблене при складанні, з відбитком джерела. Немає
    файла — вимкнено все (fail-closed: мовчазна відсутність не вмикає).
  • У НАС (еталон) `features.json` не читається взагалі: там джерело —
    `SENSFLOW_FEATURES` у `.env.local`. Еталон упізнається за наявністю
    `release_works.json`, який за побудовою клієнту НЕ ЇДЕ.
  • ЗА ЗАМОВЧУВАННЯМ ВИМКНЕНО СКРІЗЬ, включно з еталоном: щоб ми бачили рівно
    те, що бачить клієнт, і не дізнавались про різницю від нього.
"""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
FEATURES_JSON = HERE / "features.json"
WORKS_JSON = HERE / "release_works.json"

_ENV_KEY = "SENSFLOW_FEATURES"


def is_master() -> bool:
    """Це еталон розробки (у клієнта реєстру робіт немає — він не їде)."""
    return WORKS_JSON.exists()


def _from_env() -> set:
    try:
        import config
        raw = str(config.ENV.get(_ENV_KEY) or "")
    except Exception:
        raw = ""
    return {x.strip() for x in raw.replace(";", ",").split(",") if x.strip()}


def _from_file() -> set:
    try:
        data = json.loads(FEATURES_JSON.read_text(encoding="utf-8"))
    except Exception:
        return set()          # немає/зламаний файл -> вимкнено все
    got = data.get("enabled")
    if not isinstance(got, list):
        return set()
    return {str(x).strip() for x in got if str(x).strip()}


def enabled(work_id) -> bool:
    """ЄДИНА відповідь на «чи ця робота ввімкнена». За замовчуванням — ні."""
    wid = str(work_id or "").strip()
    if not wid:
        return False
    return wid in (_from_env() if is_master() else _from_file())


def active() -> set:
    """Що зараз увімкнено (для звіту людині, не для рішень у коді)."""
    return set(_from_env() if is_master() else _from_file())


def asks_switch(work: dict, root=None) -> bool:
    """ЧИ РОБОТА СПРАВДІ ПИТАЄ СВІЙ ВИМИКАЧ.

    Вимикач, якого ніхто не питає, — декорація: файл у пакеті лежить, прапорець
    у нулі, а функція працює. Тому дивимось у ДЕРЕВО КОДУ файлів самої роботи:
    має бути виклик features.enabled("<її id>"). Рядок у тексті не рахуємо —
    він буває і в коментарі.
    """
    import ast
    base = Path(root or HERE.parent)
    wid = str(work.get("id") or "")
    files = []
    for rel in (work.get("paths") or []):
        p = base / rel
        if p.is_file() and p.suffix == ".py":
            files.append(p)
        elif p.is_dir():
            files.extend(p.rglob("*.py"))
    for f in files:
        try:
            tree = ast.parse(f.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            continue
        # ⭐ 05.08.2026. Ворота мусять розуміти й КОНСТАНТУ модуля, а не лише голий
        # рядок: `WORK_ID = "chains"` + `features.enabled(WORK_ID)` — це один писар
        # id, і вимагати від нього дублювати рядок означало б плодити другого.
        consts = {}
        for n in tree.body:
            if isinstance(n, ast.Assign) and isinstance(n.value, ast.Constant):
                for t in n.targets:
                    if isinstance(t, ast.Name) and isinstance(n.value.value, str):
                        consts[t.id] = n.value.value
        for n in ast.walk(tree):
            if not isinstance(n, ast.Call):
                continue
            name = getattr(n.func, "attr", None) or getattr(n.func, "id", None)
            if name != "enabled" or not n.args:
                continue
            a0 = n.args[0]
            if isinstance(a0, ast.Constant) and str(a0.value) == wid:
                return True
            if isinstance(a0, ast.Name) and consts.get(a0.id) == wid:
                return True
    return False


def snapshot(works: dict, source_sha: str = "", built: str = "") -> str:
    """ЩО КЛАСТИ КЛІЄНТОВІ. Похідне від реєстру робіт, з відбитком джерела:
    похідне значення без відбитка — початок другої правди.

    Увімкненою їде лише робота, яка МАЄ вимикач (`flag`) і ПОЗНАЧЕНА завершеною
    (`done`). Зрілість — властивість продукту, вона живе в реєстрі; склад релізу
    (--works) відповідає на інше питання і сюди не втручається.
    """
    on = sorted(wid for wid, w in (works or {}).items()
                if w.get("flag") and w.get("done"))
    return json.dumps({
        "_": "ПОХІДНЕ від release_works.json. Рукою не правити: перезапишеться "
             "при наступному складанні.",
        "source_sha256": source_sha,
        "built": built,
        "enabled": on,
    }, ensure_ascii=False, indent=2)
