# -*- coding: utf-8 -*-
"""platform_numbers.py — ЧИСЛА ПРО ПЛАТФОРМУ РАХУЄ МАШИНА (зміна 243, 27.08.2026).

⭐⭐⭐ НАВІЩО. У документах для клієнта числа стояли ТЕКСТОМ: «у типовий набір
входить 18 систем», «проганяє 118 автоматичних самоперевірок». Кожне з них було
правдою в день, коли його написали, — і засохло на місці, поки платформа йшла
далі (насправді 19 і 148). Ніхто не збрехав; документ став неправдою сам.

🩸 ЧОМУ ЦЕ ДОРОГО, А НЕ ПРОСТО НЕОХАЙНО:
  • ми применшуємо себе рівно там, де продаємо якість;
  • клієнт МОЖЕ ПЕРЕВІРИТИ: у нього є збірка, він порахує теки систем. Одне
    розходження ставить під сумнів усі інші наші числа — зокрема ті, які він
    перевірити не може;
  • це той самий клас, який ми вигнали з коду: ДВА ПИСАРІ ОДНІЄЇ ПРАВДИ. У
    коді похідне не зберігається, а рахується. У документах — зберігалось.

⛒ ЩО РОБИТЬ ЦЕЙ ФАЙЛ. Рахує числа З ДИСКА (єдиний писар) і звіряє з тим, що
написано в документах. `--fix` вписує свіже число на місце зівʼялого.

⛔ ЧОГО ВІН НЕ РОБИТЬ. Не чіпає ІСТОРІЮ: датовані зрізи (бриф зустрічі 19.08,
«ЩО ТУТ ЛЕЖИТЬ» з рядком «115 → 136») лишаються як були. Там число — не
твердження про сьогодні, а запис про той день; переписати його означало б
підробити власний слід.

⚠ FAIL-CLOSED. Не вдалося ПОРАХУВАТИ — це відмова з причиною, а не нуль.
Не знайшлось речення в документі — теж відмова: обіцянка, якої ми не бачимо,
не є обіцянкою, яку ми тримаємо.

Запуск: python3 platform_numbers.py            — показати числа й розходження
        python3 platform_numbers.py --fix      — вписати свіжі числа
"""
import ast
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent          # orchestrator_py
ROOT = HERE.parent                              # AI_Orchestrator_Platform
DOCS = ROOT.parent                              # тека проєкту з документами


class NumbersError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнений сторож."""


# ── ЖИВІ ЧИСЛА: КОЖНЕ РАХУЄТЬСЯ З ДИСКА ─────────────────────────────────────
def checks() -> int:
    """Скільки самоперевірок у наборі. Питаємо САМ ПЕРЕЛІК, а не рахуємо файли:
    чек, який лежить у теці, але не внесений у набір, не проганяється — і
    хвалитись ним було б брехнею."""
    src = (HERE / "selfcheck.py").read_text(encoding="utf-8")
    for node in ast.parse(src).body:
        if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", "") == "CHECKS":
            return len(node.value.elts)
    raise NumbersError("У selfcheck.py не знайдено переліку CHECKS — рахувати нічого.")


def _systems() -> list:
    p = ROOT / "registry" / "systems.json"
    d = json.loads(p.read_text(encoding="utf-8"))
    rows = d.get("systems") if isinstance(d, dict) else d
    if not isinstance(rows, list) or not rows:
        raise NumbersError("Реєстр систем порожній або не читається: %s" % p)
    return rows


def systems_total() -> int:
    return len(_systems())


def systems_active() -> int:
    return len([s for s in _systems() if str(s.get("status", "")).strip() == "active"])


def systems_review() -> int:
    return systems_total() - systems_active()


def product_systems() -> int:
    """Скільки систем їде в типовий продуктовий набір. Правду знає той, хто
    збирає пакет, — тому питаємо ЙОГО перелік, а не свій список у голові."""
    # ⛒ 561г: суддя складу переїхав у `product_scope` (561в). Адреса теж
    # має одного писаря — інакше лічильник рахує вчорашню платформу.
    src = (HERE / "product_scope.py").read_text(encoding="utf-8")
    for node in ast.parse(src).body:
        if isinstance(node, ast.Assign) and getattr(node.targets[0], "id", "") == "PRODUCT_SYSTEMS":
            names = ast.literal_eval(node.value)
            if not names:
                raise NumbersError("PRODUCT_SYSTEMS порожній — це не число, це аварія.")
            return len(names)
    raise NumbersError("У product_scope.py не знайдено PRODUCT_SYSTEMS.")


LIVE = {
    "checks": (checks, "самоперевірок у наборі"),
    "systems_total": (systems_total, "систем у реєстрі"),
    "systems_active": (systems_active, "з них active"),
    "systems_review": (systems_review, "з них needs_review"),
    "product_systems": (product_systems, "систем у типовому наборі"),
}


def live() -> dict:
    return {k: fn() for k, (fn, _) in LIVE.items()}


# ── ДЕ ЦІ ЧИСЛА ОБІЦЯНІ ЛЮДЯМ ───────────────────────────────────────────────
# ⛒ ЗАКРИТИЙ ПЕРЕЛІК. Документ, якого тут немає, ніхто не стереже — тому новий
# документ із числом заводиться ТУТ, свідомо, а не «якось потім».
# Кожна обіцянка: файл · навіщо · вираз із дужками · які живі числа в дужках.
CLAIMS = [
    {"doc": "Презентаційні матеріали/SensFlow_опис_платформи_для_клієнта.docx",
     "why": "документ, який читає КЛІЄНТ: скільки систем у типовому наборі",
     "re": r"У типовий набір входить (\d+) систем",
     "keys": ["product_systems"]},

    {"doc": "Презентаційні матеріали/SensFlow_опис_платформи_для_клієнта.docx",
     "why": "документ, який читає КЛІЄНТ: скільки самоперевірок перед видачею",
     "re": r"проганяє (\d+) автоматичних самоперевірок",
     "keys": ["checks"]},

    {"doc": "Презентаційні матеріали/SensFlow_повний_опис_платформи.md",
     "why": "наш паспорт: розмір набору самоперевірок",
     "re": r"Набір самоперевірок — (\d+) чеків",
     "keys": ["checks"]},

    {"doc": "Презентаційні матеріали/SensFlow_повний_опис_платформи.md",
     "why": "наш паспорт: склад реєстру систем",
     "re": r"У реєстрі \*\*(\d+) систем: (\d+) active і (\d+) у стані",
     "keys": ["systems_total", "systems_active", "systems_review"]},

    {"doc": "Презентаційні матеріали/SensFlow_повний_опис_платформи.md",
     "why": "наш паспорт: скільки їде в продуктовий набір",
     "re": r"У типовий продуктовий набір їдуть \*\*(\d+)\*\*",
     "keys": ["product_systems"]},

    {"doc": "Презентаційні матеріали/SensFlow_повний_опис_платформи.md",
     "why": "наш паспорт: підсумковий рядок «готово й доведено живим»",
     "re": r"(\d+) систем у реєстрі \((\d+) active, (\d+) у типовому наборі\)",
     "keys": ["systems_total", "systems_active", "product_systems"]},
]


def docs_present() -> bool:
    """Чи ці документи взагалі є на цій машині. У клієнта їх немає — і це не
    вада: там нема чого звіряти. Але й «зелено» тоді кажемо ВГОЛОС, а не мовчки."""
    return (DOCS / "Презентаційні матеріали").is_dir()


# ⛒⛒⛒ 551. ОДИН ПОГЛЯД НА ДОКУМЕНТ — ДЛЯ ЧИТАЧА І ДЛЯ ПИСАРЯ.
# Живий випадок 10.09.2026: сторож бачив застаріле число в клієнтському .docx, а
# вписати його не міг НІКОЛИ. Читач склеював абзаци і бачив ціле речення; писар
# ходив по шматках (`runs`), на які Word ріже абзац — а речення лежало в пʼяти
# шматках одразу. Два різні погляди на той самий текст = сторож, який показує те,
# чого писар не дістане. Тому з чого складається документ, каже ОДНЕ місце.
def _docx_blocks(doc):
    """Усі абзаци документа, включно з тими, що всередині таблиць.
    🩸 Раніше читач дивився лише на `doc.paragraphs` — число в таблиці не стеріг
    НІХТО. Тепер його бачать обоє, бо джерело переліку одне."""
    out = list(doc.paragraphs)
    for tb in doc.tables:
        for row in tb.rows:
            for cell in row.cells:
                out.extend(cell.paragraphs)
    return out


def _read(path: Path) -> str:
    if path.suffix.lower() == ".docx":
        import docx
        return "\n".join(p.text for p in _docx_blocks(docx.Document(str(path))))
    return path.read_text(encoding="utf-8")


def audit() -> list:
    """Кожна обіцянка проти живого числа. Порожньо — усе сходиться."""
    now = live()
    bad = []
    for c in CLAIMS:
        path = DOCS / c["doc"]
        if not path.exists():
            bad.append({"doc": c["doc"], "why": c["why"], "gone": True,
                        "said": "файла немає"})
            continue
        m = re.search(c["re"], _read(path))
        if not m:
            bad.append({"doc": c["doc"], "why": c["why"], "gone": True,
                        "said": "речення не знайдено (його переписали?)"})
            continue
        for i, key in enumerate(c["keys"]):
            said, real = int(m.group(i + 1)), now[key]
            if said != real:
                bad.append({"doc": c["doc"], "why": c["why"], "key": key,
                            "said": said, "real": real})
    return bad


def _edits(text: str, claim: dict, now: dict) -> list:
    """⛒⛒⛒ 558. ОДИН ПИСАР МЕЖ ПРАВКИ.

    Де стоїть число, скільки символів воно займає і чим його замінити — у
    координатах ЦЬОГО тексту. Це ЄДИНЕ місце, де межі правки народжуються.

    🩸 ТУТ БУЛА ПАСТКА НА ДВА КРОКИ. 551б прибрала перешук речення в новому
    рядку, але писар абзацу однаково ВІДНОВЛЮВАВ межі здогадом — спільним
    початком і спільним хвостом старого й нового рядка. Здогад стискається в
    НУЛЬ, щойно старе число виявиться хвостом нового («7» → «207», «7» → «17»):
    правка перетворюється на вставку МІЖ шматками, а вставка на межі шматків не
    належить жодному з них — і не вписувалось НІЧОГО, мовчки. Межі не
    відновлюють здогадом; їх беруть звідти, де вони відомі точно.

    Перелік іде З КІНЦЯ: правка пізнішого числа не зсуває зміщень ранішого."""
    m = re.search(claim["re"], text)
    if not m:
        return []
    out = []
    for i, key in enumerate(claim["keys"]):
        old = m.group(i + 1)
        if int(old) != now[key]:
            out.append((m.start(i + 1), m.end(i + 1), str(now[key])))
    out.sort(key=lambda e: e[0], reverse=True)
    return out


def _swap(text: str, claim: dict, now: dict):
    """Підміна ЛИШЕ цифр у знайденому реченні — решта тексту недоторкана."""
    edits = _edits(text, claim, now)
    for at, end, piece in edits:
        text = text[:at] + piece + text[end:]
    return text, len(edits)


def _swap_paragraph(par, claim: dict, now: dict) -> int:
    """⛒ 551. ПРАВИМО АБЗАЦ ЦІЛКОМ, А НЕ ПО ШМАТКАХ.

    Word ріже абзац на шматки (`runs`) як йому зручно — живе речення лежало в
    ПʼЯТИ. Тому число шукається на СКЛЕЄНОМУ тексті абзацу, тобто рівно на
    тому, що бачить сторож, а назад лягає за ТИМИ САМИМИ зміщеннями, які дав
    `_edits` (558): новий текст іде в шматок, де число ПОЧИНАЄТЬСЯ (його
    форматування зберігається), а хвіст числа вирізається з наступних шматків.
    Повертає кількість вписаних чисел."""
    runs = list(par.runs)
    if not runs:
        return 0
    text = "".join(r.text for r in runs)
    written = 0
    for at, end, piece in _edits(text, claim, now):
        pos, placed = 0, False
        for r in runs:
            r_start, r_end = pos, pos + len(r.text)
            pos = r_end
            if r_end <= at or r_start >= end:
                continue                      # шматок поза числом
            cut_a = max(at, r_start) - r_start
            cut_b = min(end, r_end) - r_start
            if not placed:
                r.text = r.text[:cut_a] + piece + r.text[cut_b:]
                placed = True
            else:
                r.text = r.text[:cut_a] + r.text[cut_b:]
        written += 1 if placed else 0
    return written


def fix() -> tuple:
    """Вписати свіжі числа. Повертає (зроблено, НЕ ВДАЛОСЯ).

    🩸 551. Невдача більше не мовчить. Раніше «не зміг вписати» і «не було чого
    вписувати» виглядали однаково — порожнім рядком, — і людина бачила зелений
    рапорт про частково зроблену роботу."""
    now = live()
    done, failed = [], []
    for c in CLAIMS:
        path = DOCS / c["doc"]
        if not path.exists():
            continue
        want = _swap(_read(path), c, now)[1]      # скільки чисел МАЄ змінитись
        if not want:
            continue
        if path.suffix.lower() == ".docx":
            import docx
            d = docx.Document(str(path))
            changed = 0
            for par in _docx_blocks(d):
                changed += _swap_paragraph(par, c, now)
            if changed:
                d.save(str(path))
                done.append("%s — %d число(а)" % (c["doc"], changed))
            if changed < want:
                failed.append("%s — %s: треба було вписати %d, вписано %d"
                              % (c["doc"], c["why"], want, changed))
        else:
            src = path.read_text(encoding="utf-8")
            new, n = _swap(src, c, now)
            if n:
                path.write_text(new, encoding="utf-8")
                done.append("%s — %d число(а)" % (c["doc"], n))
            if n < want:
                failed.append("%s — %s: треба було вписати %d, вписано %d"
                              % (c["doc"], c["why"], want, n))
    return done, failed


def main() -> int:
    print("ЖИВІ ЧИСЛА ПЛАТФОРМИ (рахуються з диска)")
    for k, (fn, name) in LIVE.items():
        print("  %-18s %s: %d" % (k, name, fn()))
    if not docs_present():
        print("\nДокументів на цій машині немає — звіряти нема з чим (це не вада).")
        return 0
    if "--fix" in sys.argv:
        done, failed = fix()
        if failed:
            # 🩸 551. ТИХА ВІДМОВА — ВИМКНЕНИЙ СТОРОЖ. Кажемо вголос і одразу.
            print("\nНЕ ВДАЛОСЯ ВПИСАТИ:")
            for f in failed:
                print("   " + f)
        print("\nВПИСАНО:")
        for d in done or ["нічого — усе вже свіже"]:
            print("  " + d)
    bad = audit()
    print("\nЗВІРКА З ДОКУМЕНТАМИ:")
    if not bad:
        print("  усі числа в документах збігаються з життям")
        return 0
    for b in bad:
        if b.get("gone"):
            print("  [X] %s — %s (%s)" % (b["doc"], b["said"], b["why"]))
        else:
            print("  [X] %s: написано %s, насправді %s — %s"
                  % (b["doc"], b["said"], b["real"], b["why"]))
    return 1


if __name__ == "__main__":
    sys.exit(main())
