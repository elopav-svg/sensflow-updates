(function () {
  const apiBase = window.location.protocol === "file:" ? "http://127.0.0.1:8787" : "";

  async function analyze({ task }) {
    const response = await fetch(`${apiBase}/api/orchestrator/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ task })
    });
    if (!response.ok) throw new Error(`Orchestrator analyze failed: ${response.status}`);
    return response.json();
  }

  async function registry() {
    const response = await fetch(`${apiBase}/api/registry`);
    if (!response.ok) throw new Error(`Registry load failed: ${response.status}`);
    return response.json();
  }

  async function connectors() {
    const response = await fetch(`${apiBase}/api/connectors`);
    if (!response.ok) throw new Error(`Connectors load failed: ${response.status}`);
    return response.json();
  }

  async function runs({ limit } = {}) {
    const query = limit ? `?limit=${encodeURIComponent(limit)}` : "";
    const response = await fetch(`${apiBase}/api/runs${query}`);
    if (!response.ok) throw new Error(`Runs load failed: ${response.status}`);
    return response.json();
  }

  async function platformHealth() {
    const response = await fetch(`${apiBase}/api/platform/health`);
    if (!response.ok) throw new Error(`Platform health failed: ${response.status}`);
    return response.json();
  }

  async function execute({ task, systemId, runId, executionMode, files }) {
    const form = new FormData();
    form.append("task", task || "");
    form.append("systemId", systemId || "");
    form.append("runId", runId || "");
    form.append("executionMode", executionMode || "production_multiagent");
    Array.from(files || []).forEach((file) => form.append("files", file, file.name));

    const response = await fetch(`${apiBase}/api/orchestrator/execute`, {
      method: "POST",
      body: form
    });
    if (!response.ok) throw new Error(`Orchestrator execute failed: ${response.status}`);
    return response.json();
  }

  async function submitToCodex({ task, files, channel, threadId, handoffKind, responseStyle }) {
    const form = new FormData();
    form.append("task", task || "");
    form.append("channel", channel || "console_chat");
    form.append("threadId", threadId || "");
    form.append("sourceLabel", "Консоль AI Orchestrator");
    form.append("handoffKind", handoffKind || "task");
    form.append("responseStyle", responseStyle || "");
    Array.from(files || []).forEach((file) => form.append("files", file, file.name));

    const response = await fetch(`${apiBase}/api/codex/submit`, {
      method: "POST",
      body: form
    });
    if (!response.ok) throw new Error(`Codex handoff failed: ${response.status}`);
    return response.json();
  }

  async function codexPackages({ limit } = {}) {
    const query = limit ? `?limit=${encodeURIComponent(limit)}` : "";
    const response = await fetch(`${apiBase}/api/codex/packages${query}`);
    if (!response.ok) throw new Error(`Codex packages load failed: ${response.status}`);
    return response.json();
  }

  async function codexResult({ runId }) {
    const response = await fetch(`${apiBase}/api/codex/result?runId=${encodeURIComponent(runId || "")}`);
    if (!response.ok) throw new Error(`Codex result load failed: ${response.status}`);
    return response.json();
  }

  async function desktopBridge() {
    const response = await fetch(`${apiBase}/api/codex/desktop-bridge`);
    if (!response.ok) throw new Error(`Desktop bridge status failed: ${response.status}`);
    return response.json();
  }

  async function claimCodexPackage({ runId, workerId } = {}) {
    const response = await fetch(`${apiBase}/api/codex/claim`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ runId, workerId })
    });
    if (!response.ok) throw new Error(`Codex claim failed: ${response.status}`);
    return response.json();
  }

  async function heartbeatCodexPackage({ runId, workerId, status, note } = {}) {
    const response = await fetch(`${apiBase}/api/codex/heartbeat`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ runId, workerId, status, note })
    });
    if (!response.ok) throw new Error(`Codex heartbeat failed: ${response.status}`);
    return response.json();
  }

  async function buildSystem({ task, proposedSystem }) {
    const response = await fetch(`${apiBase}/api/orchestrator/build-system`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ task, proposedSystem })
    });
    if (!response.ok) throw new Error(`System build failed: ${response.status}`);
    return response.json();
  }

  async function smokeSystem({ systemId, task, activateOnSuccess }) {
    const response = await fetch(`${apiBase}/api/orchestrator/smoke-system`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ systemId, task, activateOnSuccess })
    });
    if (!response.ok) throw new Error(`System smoke-run failed: ${response.status}`);
    return response.json();
  }

  async function createAutomation({ task, automation }) {
    const response = await fetch(`${apiBase}/api/orchestrator/create-automation`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ task, automation })
    });
    if (!response.ok) throw new Error(`Automation create failed: ${response.status}`);
    return response.json();
  }

  async function automations() {
    const response = await fetch(`${apiBase}/api/automations`);
    if (!response.ok) throw new Error(`Automations load failed: ${response.status}`);
    return response.json();
  }

  async function runAutomation({ automationId }) {
    const response = await fetch(`${apiBase}/api/automations/run`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ automationId })
    });
    if (!response.ok) throw new Error(`Automation run failed: ${response.status}`);
    return response.json();
  }

  async function setAutomationScheduler({ automationId, enabled }) {
    const response = await fetch(`${apiBase}/api/automations/scheduler`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ automationId, enabled })
    });
    if (!response.ok) throw new Error(`Automation scheduler update failed: ${response.status}`);
    return response.json();
  }

  window.OrchestratorClient = {
    apiBase,
    registry,
    connectors,
    runs,
    platformHealth,
    analyze,
    execute,
    submitToCodex,
    codexPackages,
    codexResult,
    desktopBridge,
    claimCodexPackage,
    heartbeatCodexPackage,
    buildSystem,
    smokeSystem,
    createAutomation,
    automations,
    runAutomation,
    setAutomationScheduler
  };
})();
