const registry = {
  systems: [
    {
      id: "copywriter",
      name: "Копірайтерська система",
      category: "content",
      status: "active",
      root_path: "Проєкт копірайтер",
      description: "Дослідження, написання, адаптація і критика нерегуляторного контенту.",
      orchestration_mode: "iterative",
      agents: ["AgentResearch", "AgentWritter", "AgentSyle", "AgentCritic"],
      sensitive: false,
      triggers: ["пост", "стаття", "контент", "linkedin", "telegram", "копірайтинг", "адаптуй текст", "допис", "соцмережі"]
    },
    {
      id: "legal_assistant",
      name: "Юрист-асистент",
      category: "legal",
      status: "active",
      root_path: "Проект Юрист асистент",
      description: "Юридичний, нормативний і регуляторний аналіз документів, вимог, стандартів і правових ризиків.",
      orchestration_mode: "human_in_loop",
      agents: ["AgentSearchData", "AgentStructData"],
      sensitive: true,
      triggers: [
        "договір", "договор", "контракт", "угода", "юрист", "позов", "претензія", "правовий ризик", "суд", "закон",
        "статут", "устав", "товариство", "садове", "кооператив", "член", "внески",
        "ділянка", "виключити", "виключення", "повідомити", "правління", "збори",
        "протокол", "оренда", "борг", "скарга", "юридичний"
      ]
    },
    {
      id: "recruiting",
      name: "Рекрутингова система",
      category: "recruiting",
      status: "active",
      root_path: "Проект Рекрутинг",
      description: "Вакансії, пошук кандидатів, скоринг резюме і підготовка інтерв'ю.",
      orchestration_mode: "hybrid",
      agents: ["AgentWritingVac", "AgentSearching", "AgentScoring", "AgentPreparing"],
      sensitive: true,
      triggers: ["вакансія", "резюме", "cv", "кандидат", "співбесіда", "рекрутинг", "найм", "посада"]
    },
    {
      id: "software_development",
      name: "Розробка програмного забезпечення",
      category: "software_development",
      status: "active",
      root_path: "Проект розробка ПО",
      description: "Конвеєр розробки ПЗ від карти програми до збірки.",
      orchestration_mode: "sequential",
      agents: ["AgentEngineer", "AgentDeveloper", "AgentDesigner", "AgentCompiler", "AgentCleaner"],
      sensitive: false,
      triggers: ["програма", "застосунок", "розробка", "інтерфейс", "backend", "frontend", "зібрати програму", "додаток", "сайт"]
    },
    {
      id: "founder_dashboard",
      name: "Дашборд для власника",
      category: "dashboard",
      status: "active",
      root_path: "Проект дашборды для учредителя\\Дашборд для учредителя",
      description: "Опитувальник, структурований звіт і дашборд для власника.",
      orchestration_mode: "sequential",
      agents: ["AgentPrepair", "AgentDevelopReport", "AgentDevelopDashBoard"],
      sensitive: true,
      triggers: ["дашборд", "власник", "kpi", "звіт", "управлінський", "показники", "аналітика", "фінанси"]
    },
    {
      id: "marketing_content",
      name: "Маркетинговий конвеєр",
      category: "marketing",
      status: "active",
      root_path: "Проект Маркетинг",
      description: "Ринкове дослідження, контент-план, тексти і зображення.",
      orchestration_mode: "sequential",
      agents: ["AgentResearcher", "AgentContentPlan", "AgentWriter", "AgentCreatorimg"],
      sensitive: false,
      triggers: ["маркетинг", "контент-план", "ринок", "конкуренти", "просування", "зображення", "кампанія"]
    },
    {
      id: "excel_financial_modeling",
      name: "Excel і фінансове моделювання",
      category: "finance_excel",
      status: "needs_review",
      root_path: "Проект Codex модель виробництва",
      description: "Аналіз і модифікація XLSX-моделей, бюджетів, балансів.",
      orchestration_mode: "single_agent",
      agents: [],
      sensitive: true,
      triggers: ["excel", "xlsx", "табель", "зарплата", "фінмодель", "бюджет", "баланс", "модель", "таблиця"]
    },
    {
      id: "garmin_health",
      name: "Garmin Health Analytics",
      category: "health",
      status: "active",
      root_path: "Проект Здоров'я Garmin",
      description: "Обробка Garmin-даних, health-аналітика і HTML-звіти.",
      orchestration_mode: "single_agent",
      agents: [],
      sensitive: true,
      triggers: ["garmin", "здоров", "сон", "hrv", "пульс", "body battery", "тренування", "стрес"]
    },
    {
      id: "system_builder",
      name: "Будівник мультиагентських систем",
      category: "system_development",
      status: "active",
      root_path: "Проект Розробка Систем",
      description: "Створення нових мультиагентських систем: аналіз, промпти, структура папок, system.yaml і реєстрація.",
      orchestration_mode: "sequential",
      agents: ["AgentAnalyst", "AgentPromptWriter", "AgentStructureCreator"],
      sensitive: false,
      triggers: ["створити мультиагентську систему", "нова система агентів", "розробка систем", "agent builder", "system.yaml", "промпти агентів", "структура системи"]
    }
  ]
};

const state = {
  view: "home",
  selectedId: "copywriter",
  pendingRun: null,
  pendingSmokeSystem: null,
  activeChatId: null,
  chats: [],
  mockRuns: [],
  runs: [],
  automations: [],
  connectors: [],
  desktopBridge: null,
  platformHealth: null
};

const elements = {
  navItems: document.querySelectorAll(".nav-item"),
  views: document.querySelectorAll(".view"),
  viewTitle: document.getElementById("viewTitle"),
  compactStats: document.getElementById("compactStats"),
  platformHealthDashboard: document.getElementById("platformHealthDashboard"),
  pulseSystemStatus: document.getElementById("pulseSystemStatus"),
  pulseOrchestratorStatus: document.getElementById("pulseOrchestratorStatus"),
  pulseConnectorStatus: document.getElementById("pulseConnectorStatus"),
  homeSystemGrid: document.getElementById("homeSystemGrid"),
  chatArchive: document.getElementById("chatArchive"),
  chatMessages: document.getElementById("chatMessages"),
  resultPanel: document.getElementById("resultPanel"),
  newChatButton: document.getElementById("newChatButton"),
  newRequestButton: document.getElementById("newRequestButton"),
  systemGrid: document.getElementById("systemGrid"),
  searchInput: document.getElementById("searchInput"),
  categoryFilter: document.getElementById("categoryFilter"),
  taskInput: document.getElementById("taskInput"),
  taskFiles: document.getElementById("taskFiles"),
  fileStatus: document.getElementById("fileStatus"),
  routeButton: document.getElementById("routeButton"),
  clearTaskButton: document.getElementById("clearTaskButton"),
  connectorGrid: document.getElementById("connectorGrid"),
  addSystemButton: document.getElementById("addSystemButton"),
  addSystemDialog: document.getElementById("addSystemDialog"),
  addSystemForm: document.getElementById("addSystemForm"),
  closeAddSystemButton: document.getElementById("closeAddSystemButton"),
  manifestPreview: document.getElementById("manifestPreview"),
  previewManifestButton: document.getElementById("previewManifestButton"),
  newSystemFolder: document.getElementById("newSystemFolder"),
  folderStatus: document.getElementById("folderStatus"),
  importSummary: document.getElementById("importSummary"),
  infoDialog: document.getElementById("infoDialog"),
  infoTitle: document.getElementById("infoTitle"),
  infoBody: document.getElementById("infoBody"),
  closeInfoButton: document.getElementById("closeInfoButton"),
  validateButton: document.getElementById("validateButton"),
  mockRunButton: document.getElementById("mockRunButton"),
  bridgeStatusPanel: document.getElementById("bridgeStatusPanel"),
  runList: document.getElementById("runList"),
  automationList: document.getElementById("automationList"),
  refreshAutomationsButton: document.getElementById("refreshAutomationsButton"),
  addConnectorButton: document.getElementById("addConnectorButton"),
  addSkillButton: document.getElementById("addSkillButton"),
  connectorDialog: document.getElementById("connectorDialog"),
  connectorDialogTitle: document.getElementById("connectorDialogTitle"),
  connectorDialogText: document.getElementById("connectorDialogText"),
  closeConnectorDialogButton: document.getElementById("closeConnectorDialogButton"),
  connectorDialogOkButton: document.getElementById("connectorDialogOkButton")
};

const categoryNames = {
  content: "Контент",
  legal: "Юридичні задачі",
  recruiting: "Рекрутинг",
  software_development: "Розробка ПЗ",
  dashboard: "Дашборди",
  marketing: "Маркетинг",
  finance_excel: "Excel / фінанси",
  health: "Здоров'я",
  documents: "Документи",
  operations: "Операційні задачі",
  system_development: "Розробка систем",
  generated: "Створені системи",
  custom: "Інше"
};

const statusNames = {
  active: "активна",
  needs_review: "перевірити",
  draft: "чернетка"
};

const modeNames = {
  iterative: "ітераційна",
  human_in_loop: "з дозволом користувача",
  hybrid: "змішана",
  sequential: "послідовна",
  single_agent: "один агент"
};

function categoryLabel(value) {
  return categoryNames[value] || value.replaceAll("_", " ");
}

function statusLabel(value) {
  return statusNames[value] || value;
}

function modeLabel(value) {
  return modeNames[value] || value;
}

function badge(text, type = "") {
  return `<span class="badge ${type}">${text}</span>`;
}

function statusBadge(status) {
  const type = status === "active" ? "active" : status === "needs_review" ? "review" : "";
  return badge(statusLabel(status), type);
}

function systemPriority(system) {
  return Number.isFinite(system.priority) ? system.priority : registry.systems.indexOf(system) + 1;
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function paragraphsToHtml(value) {
  return escapeHtml(value)
    .split("\n")
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => `<p>${line}</p>`)
    .join("");
}

function renderCompactStats() {
  if (!elements.compactStats) return;
  const total = registry.systems.length;
  const active = registry.systems.filter((item) => item.status === "active").length;
  const review = registry.systems.filter((item) => item.status === "needs_review").length;
  elements.compactStats.innerHTML = `
    <span>${total} систем</span>
    <span>${active} активних</span>
    <span>${review} потребує перевірки</span>
  `;
}

function renderPulseStatus() {
  const health = state.platformHealth;
  const summary = health?.summary;
  if (elements.pulseSystemStatus) {
    elements.pulseSystemStatus.textContent = health
      ? health.ok ? "здорово" : `${summary.systems_with_errors} помил.`
      : "Онлайн";
  }
  if (elements.pulseOrchestratorStatus) {
    elements.pulseOrchestratorStatus.textContent = "активний";
  }
  if (elements.pulseConnectorStatus) {
    elements.pulseConnectorStatus.textContent = summary
      ? `${summary.connectors_connected} / ${summary.connectors_total}`
      : `${state.connectors.filter((item) => ["connected", "optional", "planned"].includes(item.status)).length || "..."} / ${state.connectors.length || "..."}`;
  }
}

function renderPlatformHealthDashboard() {
  if (!elements.platformHealthDashboard) return;
  const health = state.platformHealth;
  if (!health) {
    elements.platformHealthDashboard.innerHTML = `
      <div class="health-panel">
        <div>
          <p class="eyebrow">Platform Health</p>
          <h3>Перевірка ще не виконана</h3>
          <p>Натисни “Перевірити реєстр”, щоб отримати стан систем, runs, artifacts і конекторів.</p>
        </div>
      </div>
    `;
    renderPulseStatus();
    return;
  }
  const s = health.summary;
  const issueSystems = health.systems
    .filter((system) => system.severity !== "ok")
    .slice(0, 6);
  elements.platformHealthDashboard.innerHTML = `
    <div class="health-panel ${health.ok ? "healthy" : "needs-attention"}">
      <div class="health-title">
        <div>
          <p class="eyebrow">Platform Health</p>
          <h3>${health.ok ? "Платформа в робочому стані" : "Є питання до реєстру"}</h3>
          <p>Остання перевірка: ${escapeHtml(formatDateTime(health.checked_at))}</p>
        </div>
        ${badge(health.ok ? "ok" : "needs attention", health.ok ? "active" : "review")}
      </div>
      <div class="health-metrics">
        <div><span>Системи</span><strong>${s.total_systems}</strong></div>
        <div><span>Активні</span><strong>${s.active_systems}</strong></div>
        <div><span>Needs review</span><strong>${s.needs_review_systems}</strong></div>
        <div><span>Generated</span><strong>${s.generated_systems}</strong></div>
        <div><span>Warnings</span><strong>${s.systems_with_warnings}</strong></div>
        <div><span>Errors</span><strong>${s.systems_with_errors}</strong></div>
      </div>
      ${issueSystems.length ? `
        <div class="health-issues">
          <h4>Потребують уваги</h4>
          ${issueSystems.map((system) => `
            <div class="health-issue">
              <strong>${escapeHtml(system.name || system.id)}</strong>
              <span>${escapeHtml(system.issues.map((issue) => issue.message).join("; "))}</span>
            </div>
          `).join("")}
        </div>
      ` : ""}
    </div>
  `;
  renderPulseStatus();
}

function renderFilters() {
  const categories = [...new Set(registry.systems.map((item) => item.category))].sort();
  elements.categoryFilter.innerHTML = `<option value="all">Усі категорії</option>` + categories
    .map((category) => `<option value="${category}">${categoryLabel(category)}</option>`)
    .join("");
}

function filteredSystems() {
  const query = elements.searchInput.value.trim().toLowerCase();
  const category = elements.categoryFilter.value;
  return registry.systems.filter((system) => {
    const matchesCategory = category === "all" || system.category === category;
    const searchable = `${system.name} ${system.description} ${system.category} ${system.agents.join(" ")}`.toLowerCase();
    return matchesCategory && searchable.includes(query);
  });
}

function systemCard(system, compact = false) {
  const sensitive = system.sensitive ? badge("потребує дозволу", "sensitive") : "";
  const agentsText = system.agents.length ? `${system.agents.length} агентів` : "1 агент";
  return `
    <article class="system-card" data-system-id="${system.id}">
      <div class="system-card-signal">
        <span>${categoryLabel(system.category)}</span>
        ${statusBadge(system.status)}
      </div>
      <div class="system-card-head">
        <div>
          <h3>${system.name}</h3>
          <p>${system.description}</p>
        </div>
        <div class="badges">
          ${sensitive}
        </div>
      </div>
      <div class="system-meta">
        <span>${categoryLabel(system.category)}</span>
        <span>${modeLabel(system.orchestration_mode)}</span>
        <span>${agentsText}</span>
      </div>
      <div class="card-actions">
        <button class="primary-button choose-system" type="button" data-system-id="${system.id}">Обрати</button>
        <button class="secondary-button info-system" type="button" data-system-id="${system.id}">Інфо</button>
      </div>
    </article>
  `;
}

function bindSystemButtons(scope = document) {
  scope.querySelectorAll(".info-system").forEach((button) => {
    button.addEventListener("click", () => showInfo(button.dataset.systemId));
  });
  scope.querySelectorAll(".choose-system").forEach((button) => {
    button.addEventListener("click", () => chooseSystem(button.dataset.systemId));
  });
}

function renderHomeSystems() {
  if (!elements.homeSystemGrid) return;
  elements.homeSystemGrid.innerHTML = registry.systems
    .slice()
    .sort((a, b) => systemPriority(a) - systemPriority(b))
    .map((system) => systemCard(system, true))
    .join("");
  bindSystemButtons(elements.homeSystemGrid);
}

function renderSystemCatalog() {
  elements.systemGrid.innerHTML = filteredSystems().map((system) => systemCard(system)).join("");
  bindSystemButtons(elements.systemGrid);
}

function createChat(systemId = "unassigned", firstTask = "") {
  const now = new Date();
  const chat = {
    id: `chat-${now.toISOString().replaceAll(":", "-").slice(0, 19)}-${state.chats.length + 1}`,
    systemId,
    title: firstTask ? firstTask.slice(0, 54) : "Новий чат",
    createdAt: now,
    messages: [],
    result: ""
  };
  state.chats.unshift(chat);
  state.activeChatId = chat.id;
  return chat;
}

function currentChat() {
  if (!state.activeChatId) {
    return createChat();
  }
  return state.chats.find((chat) => chat.id === state.activeChatId) || createChat();
}

function addChatMessage(role, content, options = {}) {
  const chat = currentChat();
  const id = `msg-${Date.now()}-${Math.random().toString(16).slice(2)}`;
  chat.messages.push({
    id,
    role,
    content,
    html: options.html || "",
    actions: options.actions || [],
    time: new Date()
  });
  renderChat();
  renderArchive();
  return id;
}

function updateChatMessage(messageId, updates = {}) {
  const chat = currentChat();
  const message = chat.messages.find((item) => item.id === messageId);
  if (!message) return;
  Object.assign(message, updates);
  renderChat();
  renderArchive();
}

function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function lastUserTask() {
  const chat = currentChat();
  const last = chat.messages.slice().reverse().find((message) => message.role === "user" && message.content);
  return last?.content || "";
}

function renderChat() {
  if (!elements.chatMessages) return;
  const chat = currentChat();
  if (!chat.messages.length) {
    elements.chatMessages.innerHTML = `
      <div class="message assistant">
        <div class="message-bubble">
          <div class="welcome-card">
            <span class="eyebrow small">Оркестратор готовий</span>
            <h3>Сформулюй задачу природною мовою</h3>
            <p>Я визначу шлях виконання, погоджу запуск і поверну перевірений результат у цю консоль.</p>
            <div class="flow-steps" aria-label="Цикл виконання">
              <span>Аналіз</span>
              <span>Вибір</span>
              <span>Виконання</span>
              <span>Перевірка</span>
            </div>
          </div>
        </div>
      </div>
    `;
    return;
  }

  elements.chatMessages.innerHTML = chat.messages.map((message) => {
    const body = message.html || paragraphsToHtml(message.content);
    const actions = message.actions.length
      ? `<div class="message-actions">${message.actions.map((action) => `
          <button class="${action.kind === "primary" ? "primary-button" : "secondary-button"} ${action.className}" type="button" data-system-id="${action.systemId || ""}">${action.label}</button>
        `).join("")}</div>`
      : "";
    return `
      <div class="message ${message.role}">
        <div class="message-bubble">
          ${body}
          ${actions}
        </div>
      </div>
    `;
  }).join("");
  elements.chatMessages.scrollTop = elements.chatMessages.scrollHeight;
  bindSystemButtons(elements.chatMessages);
  bindRunButtons(elements.chatMessages);
}

function renderArchive() {
  if (!elements.chatArchive) return;
  const groups = registry.systems
    .map((system) => ({
      system,
      chats: state.chats.filter((chat) => chat.systemId === system.id)
    }))
    .filter((group) => group.chats.length);
  const unassigned = state.chats.filter((chat) => chat.systemId === "unassigned");

  if (!groups.length && !unassigned.length) {
    elements.chatArchive.innerHTML = `<div class="archive-empty">Ще немає чатів</div>`;
    return;
  }

  const groupHtml = groups.map((group) => `
    <div class="archive-group">
      <h4>${group.system.name}</h4>
      ${group.chats.map((chat) => archiveButton(chat)).join("")}
    </div>
  `).join("");
  const unassignedHtml = unassigned.length
    ? `<div class="archive-group"><h4>Без системи</h4>${unassigned.map((chat) => archiveButton(chat)).join("")}</div>`
    : "";

  elements.chatArchive.innerHTML = groupHtml + unassignedHtml;
  elements.chatArchive.querySelectorAll(".archive-chat").forEach((button) => {
    button.addEventListener("click", () => {
      state.activeChatId = button.dataset.chatId;
      renderChat();
      renderArchive();
      renderResultPanel(currentChat().result);
    });
  });
}

function archiveButton(chat) {
  const active = chat.id === state.activeChatId ? "active" : "";
  return `
    <button class="archive-chat ${active}" type="button" data-chat-id="${chat.id}">
      <span>${escapeHtml(chat.title)}</span>
      <small>${chat.messages.length} повідомл.</small>
    </button>
  `;
}

function renderResultPanel(resultHtml = "") {
  if (!elements.resultPanel) return;
  elements.resultPanel.innerHTML = resultHtml || `
    <div class="soft-empty">
      <span class="empty-signal"></span>
      <h3>Очікую задачу</h3>
      <p>Фінальний матеріал з'явиться після перевірки результату.</p>
      <div class="flow-steps compact" aria-label="Цикл виконання">
        <span>Аналіз</span>
        <span>Вибір</span>
        <span>Виконання</span>
        <span>Перевірка</span>
      </div>
    </div>
  `;
}

function renderFlowSteps(activeIndex = 0) {
  const steps = ["Аналіз", "Вибір", "Виконання", "Перевірка"];
  return `
    <div class="flow-steps compact tracked" aria-label="Цикл виконання">
      ${steps.map((step, index) => {
        const stateClass = index < activeIndex ? "done" : index === activeIndex ? "active" : "";
        return `<span class="${stateClass}">${step}</span>`;
      }).join("")}
    </div>
  `;
}

function renderProcessPanel(title, text, activeIndex = 0) {
  if (!elements.resultPanel) return;
  elements.resultPanel.innerHTML = `
    <div class="soft-empty process-state">
      <span class="empty-signal"></span>
      <h3>${escapeHtml(title)}</h3>
      <p>${escapeHtml(text)}</p>
      ${renderFlowSteps(activeIndex)}
    </div>
  `;
}

function formatFileSize(bytes) {
  if (!Number.isFinite(bytes)) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function renderFileStatus() {
  if (!elements.fileStatus) return;
  const files = selectedTaskFiles();
  if (!files.length) {
    elements.fileStatus.classList.remove("has-files");
    elements.fileStatus.textContent = "Файли не додані";
    return;
  }
  const totalSize = files.reduce((sum, file) => sum + (file.size || 0), 0);
  const names = files.slice(0, 3).map((file) => file.name).join(", ");
  const rest = files.length > 3 ? ` та ще ${files.length - 3}` : "";
  elements.fileStatus.classList.add("has-files");
  elements.fileStatus.textContent = `Додано ${files.length} файл(ів): ${names}${rest} · ${formatFileSize(totalSize)}`;
}

function startNewChat() {
  createChat();
  state.pendingRun = null;
  elements.taskInput.value = "";
  if (elements.taskFiles) elements.taskFiles.value = "";
  renderFileStatus();
  renderChat();
  renderArchive();
  renderResultPanel();
}

function chooseSystem(systemId) {
  const system = registry.systems.find((item) => item.id === systemId);
  if (!system) return;

  state.selectedId = systemId;
  if (elements.infoDialog.open) elements.infoDialog.close();
  if (elements.addSystemDialog.open) elements.addSystemDialog.close();

  const taskText = elements.taskInput.value.trim() || state.pendingRun?.task || lastUserTask();
  if (taskText) {
    const chat = currentChat();
    chat.systemId = system.id;
    chat.title = taskText.slice(0, 54);
    state.pendingRun = {
      task: taskText,
      systemId: system.id,
      confidence: "manual",
      rationale: "Систему обрав користувач."
    };
    addChatMessage("assistant", "", {
      html: renderOrchestratorDecision(
      { system, confidence: "manual", intent: "ручний вибір системи", rationale: "Систему обрав користувач." },
      []
      ),
      actions: []
    });
    setView("home");
    return;
  }

  const chat = currentChat();
  chat.systemId = system.id;
  addChatMessage("assistant", `Обрано систему: ${system.name}. Опиши задачу в полі повідомлення, і я запущу її через цю систему.`);
  setView("home");
}

function buildClarifiedTask(originalTask, answer, questions = []) {
  const questionBlock = questions.length
    ? `\n\nПитання системи до користувача:\n${questions.map((item, index) => `${index + 1}. ${item}`).join("\n")}`
    : "";
  return `${originalTask}${questionBlock}\n\nВідповіді користувача на інтерв'ю / уточнення:\n${answer}`;
}

function showInfo(systemId) {
  const system = registry.systems.find((item) => item.id === systemId);
  if (!system) return;

  const agentList = system.agents.length
    ? system.agents.map((agent) => badge(agent)).join("")
    : badge("один агент");

  elements.infoTitle.textContent = system.name;
  elements.infoBody.innerHTML = `
    <p class="dialog-lead">${system.description}</p>
    <div class="detail-grid">
      <div class="info-block"><span>ID</span><strong>${system.id}</strong></div>
      <div class="info-block"><span>Категорія</span><strong>${categoryLabel(system.category)}</strong></div>
      <div class="info-block"><span>Статус</span><strong>${statusLabel(system.status)}</strong></div>
      <div class="info-block"><span>Режим</span><strong>${modeLabel(system.orchestration_mode)}</strong></div>
      <div class="info-block"><span>Доступ</span><strong>${system.sensitive ? "потребує дозволу перед запуском" : "без додаткового дозволу"}</strong></div>
      <div class="info-block wide"><span>Папка</span><strong>${system.root_path}</strong></div>
    </div>
    <h4>Агенти</h4>
    <div class="pill-row">${agentList}</div>
    <div class="dialog-actions">
      <button class="primary-button choose-system" type="button" data-system-id="${system.id}">Обрати систему</button>
    </div>
  `;
  bindSystemButtons(elements.infoBody);
  elements.infoDialog.showModal();
}

function normalizeText(text) {
  return text
    .toLowerCase()
    .replace(/[.,:;!?()[\]{}"«»]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function hasCopywriterInterviewAnswers(task) {
  const text = normalizeText(task || "");
  return [
    "відповіді користувача",
    "відповіді на інтерв",
    "відповідаю",
    "цільова аудиторія",
    "аудиторія",
    "кейс",
    "практики",
    "парадокс",
    "помилка",
    "інсайт",
    "тон"
  ].some((marker) => text.includes(marker)) && text.length > 240;
}

function copywriterInterviewQuestions(task) {
  if (hasCopywriterInterviewAnswers(task)) return [];
  const topic = task.length > 120 ? `${task.slice(0, 120)}...` : task;
  return [
    `Який конкретний приклад з твого досвіду пов'язаний з темою "${topic}"? Що відбувалось і чим закінчилось?`,
    "Хто цільова аудиторія цього матеріалу і який рівень її обізнаності?",
    "Яка головна мета тексту: навчити, залучити, прогріти, продати, спровокувати дискусію чи підготувати до наступної дії?",
    "Для яких каналів готуємо матеріал: LinkedIn, Telegram, блог, Facebook, Instagram або кілька одразу?",
    "Який тон потрібен: експертний, особистий, провокативний, дружній, жорсткий управлінський чи нейтральний?",
    "Що у цій темі люди зазвичай недооцінюють або розуміють неправильно?"
  ];
}

function renderCodexReturnedMarkdown(markdown, result) {
  const body = String(markdown || result?.summary || "").trim();
  if (!elements.resultPanel || !body) return;
  const html = `
    <div class="result-document">
      <div class="result-meta">
        ${badge("Codex", "active")}
        ${badge(result?.status || "completed", result?.status === "completed" ? "active" : "review")}
      </div>
      <div class="direct-answer">
        ${paragraphsToHtml(body.replace(/^#\s+.*$/m, "").trim() || body)}
      </div>
    </div>
  `;
  elements.resultPanel.innerHTML = html;
  currentChat().result = html;
  addChatMessage("assistant", body);
}

async function readArtifactText(artifact) {
  if (!artifact?.url) return "";
  const response = await fetch(artifact.url);
  if (!response.ok) return "";
  return response.text();
}

function startCodexResultPolling(runId) {
  if (!runId || !window.OrchestratorClient?.codexResult) return;
  let attempts = 0;
  const maxAttempts = 120;
  let waitingShown = false;
  const poll = async () => {
    attempts += 1;
    try {
      const response = await window.OrchestratorClient.codexResult({ runId });
      const result = response.result;
      if (result?.status) {
        const artifacts = Array.isArray(response.artifacts) ? response.artifacts : [];
        const finalMarkdownArtifact = artifacts.find((artifact) => artifact.filename === "final_result.md");
        const markdown = await readArtifactText(finalMarkdownArtifact);
        renderCodexReturnedMarkdown(markdown, result);
        state.pendingRun = null;
        await refreshRuns();
        renderArchive();
        return;
      }
    } catch (error) {
      console.warn("Codex result polling failed.", error);
    }
    if (!waitingShown && attempts >= 5 && state.pendingRun?.runId === runId && elements.resultPanel) {
      waitingShown = true;
      elements.resultPanel.innerHTML = `
        <div class="result-document codex-handoff compact-handoff">
          <div class="result-meta">
            ${badge("Codex", "review")}
            ${badge(runId)}
          </div>
          <h3>Очікую відповідь</h3>
          <p>Запит передано, але Codex worker ще не повернув результат.</p>
        </div>
      `;
    }
    if (state.pendingRun?.runId === runId && attempts < maxAttempts) {
      window.setTimeout(poll, 2000);
    }
  };
  window.setTimeout(poll, 1200);
}

async function routeTask() {
  const taskText = elements.taskInput.value.trim();
  const query = normalizeText(taskText);
  if (!query) {
    addChatMessage("assistant", "Напиши задачу одним повідомленням. Я визначу систему, поясню вибір і після погодження поверну результат.");
    return;
  }

  const chat = currentChat();
  if (chat.title === "Новий чат") chat.title = taskText.slice(0, 54);
  addChatMessage("user", taskText);
  elements.taskInput.value = "";

  if (state.pendingRun?.awaitingInput) {
    elements.routeButton.disabled = true;
    const pending = state.pendingRun;
    state.pendingRun = {
      ...pending,
      task: buildClarifiedTask(pending.originalTask || pending.task, taskText, pending.questions || []),
      awaitingInput: false
    };
    addChatMessage("assistant", "Отримав уточнення і передаю їх назад у ту саму агентську систему через оркестратора.");
    try {
      await approveRun(state.pendingRun.systemId, state.pendingRun.executionMode || "production_multiagent");
    } finally {
      elements.routeButton.disabled = false;
    }
    return;
  }

  elements.routeButton.disabled = true;
  renderProcessPanel("Передаю Codex", "Очікую відповідь.", 0);

  const thinkingId = addChatMessage("assistant", "", {
    html: renderThinkingState(taskText)
  });

  try {
    await delay(900);
    const handoff = await submitTaskToCodexControlPlane(taskText);
    await delay(300);
    state.pendingRun = {
      task: taskText,
      runId: handoff.runId,
      status: handoff.status,
      packageDir: handoff.packageDir,
      outputDir: handoff.outputDir,
      source: "codex_control_plane"
    };
    chat.systemId = "codex_global_orchestrator";
    updateChatMessage(thinkingId, { html: renderCodexHandoffDecision(handoff) });
    renderCodexHandoffPanel(handoff);
    renderProcessPanel("Передано Codex", "Очікую відповідь.", 1);
    startCodexResultPolling(handoff.runId);
    renderArchive();
  } catch (error) {
    console.error(error);
    renderProcessPanel("Аналіз не завершено", "Перевір, чи запущений backend Orchestrator API, і повтори запит.", 0);
    updateChatMessage(thinkingId, {
      html: `
        <div class="execution-card">
          <span class="eyebrow small">Помилка оркестратора</span>
          <h3>Не вдалося завершити аналіз</h3>
          <p>Спробуй ще раз або перевір, чи запущений backend Orchestrator API.</p>
        </div>
      `
    });
  } finally {
    elements.routeButton.disabled = false;
  }
}

async function analyzeTaskWithGlobalOrchestrator(taskText, query) {
  if (window.OrchestratorClient) {
    try {
      const response = await window.OrchestratorClient.analyze({ task: taskText });
      if (response?.ok && response.decision) {
        if (!response.decision.ok || !response.decision.best) {
          return {
            best: null,
            alternatives: [],
            intent: response.decision.intent,
            status: response.decision.status,
            reason: response.decision.reason,
            directAnswer: response.decision.direct_answer,
            requiredConnector: response.decision.required_connector,
            proposedSystem: response.decision.proposed_system,
            automation: response.decision.automation,
            questions: response.decision.questions || [],
            nextAction: response.decision.next_action,
            source: response.decision.source || "codex_global_orchestrator_api",
            needsUserChoice: response.decision.needsUserChoice !== false
          };
        }
        const best = mapRuntimeDecision(response.decision.best);
        const alternatives = (response.decision.alternatives || []).map(mapRuntimeDecision).filter(Boolean);
        return {
          best,
          alternatives,
          intent: response.decision.intent,
          status: response.decision.status,
          questions: response.decision.questions || [],
          nextAction: response.decision.next_action,
          source: response.decision.source || "codex_global_orchestrator_api"
        };
      }
    } catch (error) {
      console.warn("Global Orchestrator API unavailable.", error);
      return {
        best: null,
        alternatives: [],
        intent: {
          confidence: "low",
          intent: "оркестратор недоступний",
          rationale: "UI не буде самостійно обирати систему без Global Orchestrator API."
        },
        source: "ui_no_orchestrator_runtime",
        status: "needs_orchestrator_runtime",
        needsUserChoice: true
      };
    }
  }

  return {
    best: null,
    alternatives: [],
    intent: {
      confidence: "low",
      intent: "оркестратор не підключений",
      rationale: "Немає доступного Global Orchestrator API. UI не виконує локальну маршрутизацію."
    },
    source: "ui_no_orchestrator_runtime",
    status: "needs_orchestrator_runtime",
    needsUserChoice: true
  };
}

async function submitTaskToCodexControlPlane(taskText, options = {}) {
  if (!window.OrchestratorClient?.submitToCodex) {
    throw new Error("Codex Control Plane API недоступний.");
  }
  const chat = currentChat();
  const response = await window.OrchestratorClient.submitToCodex({
    task: taskText,
    files: selectedTaskFiles(),
    channel: options.channel || "console_chat",
    threadId: chat.id,
    handoffKind: options.handoffKind || "task",
    responseStyle: options.responseStyle || ""
  });
  if (!response?.ok) {
    throw new Error(response?.error || "Codex Control Plane не прийняв задачу.");
  }
  return response;
}

function renderCodexHandoffDecision(handoff) {
  return `
    <div class="execution-card codex-handoff-card compact-handoff">
      <div class="decision-grid">
        <div>
          <span class="eyebrow small">Codex</span>
          <h3>Передано Codex</h3>
          <p>Очікую відповідь.</p>
          <p class="muted">Run ID: <strong>${escapeHtml(handoff.runId)}</strong></p>
        </div>
        <div class="decision-side">
          ${badge("очікує", "active")}
        </div>
      </div>
    </div>
  `;
}

function renderCodexHandoffPanel(handoff) {
  if (!elements.resultPanel) return;
  elements.resultPanel.innerHTML = `
    <div class="result-document codex-handoff">
      <div class="result-meta">
        ${badge("Codex", "active")}
        ${badge(handoff.runId)}
      </div>
      <h3>Очікую відповідь</h3>
      <p>Запит передано Codex.</p>
    </div>
  `;
}

function mapRuntimeDecision(item) {
  if (!item?.system) return null;
  const localSystem = registry.systems.find((system) => system.id === item.system.id) || item.system;
  return {
    system: localSystem,
    confidence: item.confidence || "medium",
    intent: item.intent || "",
    expectedResult: item.expected_result || "",
    rationale: item.rationale || "",
    semanticAnalysis: item.semantic_analysis || {}
  };
}

function renderOrchestratorDecision(best, alternatives) {
  const { system, confidence, intent, expectedResult, rationale, semanticAnalysis } = best;
  const files = selectedTaskFiles();
  const requiredInput = requiredInputFor(system, files);
  const cleanRationale = String(rationale || "її роль найкраще відповідає наміру задачі").replace(/[.。]\s*$/, "");
  const shortIntent = String(intent || "запит на виконання задачі");
  const compactIntent = shortIntent.length > 170 ? `${shortIntent.slice(0, 170).trim()}...` : shortIntent;
  const shortExpected = String(expectedResult || "");
  const compactExpected = shortExpected.length > 150 ? `${shortExpected.slice(0, 150).trim()}...` : shortExpected;
  const shortRationale = cleanRationale.length > 220 ? `${cleanRationale.slice(0, 220).trim()}...` : cleanRationale;
  const subject = String(semanticAnalysis?.subject_matter || "");
  const shortSubject = subject.length > 150 ? `${subject.slice(0, 150).trim()}...` : subject;
  const formCheck = String(semanticAnalysis?.domain_over_form_check || "");
  const shortFormCheck = formCheck.length > 160 ? `${formCheck.slice(0, 160).trim()}...` : formCheck;
  const semanticHtml = semanticAnalysis && Object.keys(semanticAnalysis).length
    ? `<div class="semantic-brief">
        <span>${escapeHtml(semanticAnalysis.primary_domain || "domain")}</span>
        ${shortSubject ? `<p><strong>Предмет:</strong> ${escapeHtml(shortSubject)}</p>` : ""}
        ${shortFormCheck ? `<p><strong>Перевірка форми:</strong> ${escapeHtml(shortFormCheck)}</p>` : ""}
      </div>`
    : "";
  const alternativeHtml = alternatives.length
    ? `<div class="route-alt"><span>Альтернативи:</span> ${alternatives.map((item) => item.system.name).join(" · ")}</div>`
    : "";
  const confidenceLabel = {
    high: "висока впевненість",
    medium: "середня впевненість",
    low: "потрібне уточнення",
    manual: "ручний вибір",
    possible: "можлива допоміжна система"
  }[confidence] || "семантичний вибір";

  return `
    <div class="execution-card">
      <div class="decision-grid">
        <div>
          <span class="eyebrow small">Вибір оркестратора</span>
          <h3>${system.name}</h3>
          <p>${system.description}</p>
          <p class="muted">Я зрозумів задачу як: <strong>${escapeHtml(compactIntent)}</strong>.</p>
          ${compactExpected ? `<p class="muted">Очікуваний результат: <strong>${escapeHtml(compactExpected)}</strong>.</p>` : ""}
          ${semanticHtml}
          ${alternativeHtml}
        </div>
        <div class="decision-side">
          ${badge(confidenceLabel)}
          ${badge(system.sensitive ? "потрібне погодження" : "можна запускати", system.sensitive ? "sensitive" : "active")}
          ${badge(modeLabel(system.orchestration_mode))}
          ${badge(categoryLabel(system.category))}
        </div>
      </div>
      ${requiredInput}
      <div class="card-actions">
        <button class="primary-button approve-run" type="button" data-system-id="${system.id}" data-execution-mode="production_multiagent">Запустити систему агентів</button>
        <button class="secondary-button approve-run" type="button" data-system-id="${system.id}" data-execution-mode="codex_adapter">Виконати через Codex adapter</button>
        <button class="secondary-button info-system" type="button" data-system-id="${system.id}">Інфо</button>
      </div>
      <details class="decision-details">
        <summary>Деталі рішення</summary>
        <p class="muted">Чому саме ця система: ${escapeHtml(cleanRationale)}.</p>
        <div class="run-plan">
          <h4>Що буде зроблено після погодження</h4>
          <ol>
            ${executionSteps(system).map((step) => `<li>${step}</li>`).join("")}
          </ol>
        </div>
      </details>
    </div>
  `;
}

function renderThinkingState(taskText) {
  return `
    <div class="execution-card thinking-card compact-handoff">
      <span class="eyebrow small">Codex</span>
      <h3>Передаю запит</h3>
      <p class="muted">Очікую відповідь.</p>
    </div>
  `;
}

function renderNoSystemDecision(routed) {
  if (routed?.directAnswer) return renderDirectOrchestratorAnswer(routed);
  const intentText = routed?.intent?.intent || "потрібне уточнення";
  const rationale = routed?.intent?.rationale || "Я не бачу достатньо контексту, щоб чесно обрати одну з наявних систем.";
  const reason = routed?.reason || "";
  const isQuotaError = reason === "llm_quota_or_billing_error";
  const isRuntimeMissing = routed?.source === "ui_no_orchestrator_runtime" || routed?.intent?.intent?.includes("оркестратор") || routed?.status === "needs_orchestrator_runtime";
  const needsConnector = routed?.status === "needs_external_connector" || routed?.reason === "orchestrator_needs_external_connector";
  const proposesSystemBuild = routed?.status === "propose_system_build" || routed?.reason === "orchestrator_proposes_system_build";
  const proposesAutomation = routed?.status === "propose_automation" || routed?.reason === "orchestrator_proposes_automation";
  const title = isQuotaError
    ? "OpenAI quota або billing не дозволяє запустити оркестратор"
    : isRuntimeMissing
    ? "Мислячий оркестратор не підключений"
    : needsConnector
    ? "Потрібен зовнішній конектор"
    : proposesSystemBuild
    ? "Доцільно створити нову систему"
    : proposesAutomation
    ? "Доцільно створити heartbeat-задачу"
    : "Я не буду вгадувати систему";
  const lead = isQuotaError
    ? "Backend дістався OpenAI API, але API повернув помилку квоти або billing. Семантичний оркестратор не запускав вибір системи, щоб не імітувати мислення локальними правилами."
    : isRuntimeMissing
    ? "UI не має права самостійно маршрутизувати запит. Потрібно запустити backend з LLM-runtime, який виконує GLOBAL_ORCHESTRATOR_PROMPT.md."
    : needsConnector
    ? `Для чесної відповіді потрібен актуальний зовнішній доступ${routed.requiredConnector ? `: ${escapeHtml(routed.requiredConnector)}` : ""}. Я не буду вигадувати живі дані без підключеного джерела.`
    : proposesSystemBuild
    ? "Це схоже на складний процес із ролями, входами, виходами і критеріями якості. Краще створити окрему мультиагентську систему, ніж разово виконувати задачу вручну."
    : proposesAutomation
    ? "Це схоже на регулярний цикл контролю або моніторингу. Його краще оформити як heartbeat-задачу з ритмом, перевірками, журналом і правилами ескалації."
    : rationale;
  const proposalHtml = proposesSystemBuild && routed.proposedSystem
    ? renderSystemBuildProposal(routed.proposedSystem)
    : proposesAutomation && routed.automation
    ? renderAutomationProposal(routed.automation)
    : "";
  const questions = (routed?.questions || []).length
    ? `<div class="run-plan"><h4>Питання оркестратора</h4><ol>${routed.questions.map((question) => `<li>${escapeHtml(question)}</li>`).join("")}</ol></div>`
    : "";
  const topSystems = registry.systems
    .filter((system) => system.status === "active")
    .map((system) => `<button class="secondary-button choose-system" type="button" data-system-id="${system.id}">${system.name}</button>`)
    .join("");
  const proposalActions = proposesSystemBuild
    ? `<div class="card-actions"><button class="primary-button approve-system-build" type="button">Створити систему</button><button class="secondary-button" type="button" data-start-new-request>Уточнити задачу</button></div>`
    : proposesAutomation
    ? `<div class="card-actions"><button class="primary-button approve-automation" type="button">Створити heartbeat</button><button class="secondary-button" type="button" data-start-new-request>Уточнити задачу</button></div>`
    : "";

  return `
    <div class="execution-card">
      <span class="eyebrow small">Рішення оркестратора</span>
      <h3>${title}</h3>
      <p class="muted">Я зрозумів задачу як: <strong>${intentText}</strong>.</p>
      <p>${lead}</p>
      ${proposalHtml}
      ${questions}
      <div class="input-warning">
        <strong>${isQuotaError ? "Потрібно перевірити оплату або ліміти OpenAI API." : needsConnector ? "Потрібно підключити або дозволити джерело даних." : proposesSystemBuild ? "Потрібне погодження на побудову системи." : proposesAutomation ? "Потрібне погодження на створення heartbeat." : "Потрібен вибір або уточнення."}</strong>
        <span>${isQuotaError ? "Після відновлення квоти повтори запит, і оркестратор виконає семантичний аналіз через GLOBAL_ORCHESTRATOR_PROMPT.md." : needsConnector ? "Після підключення конектора оркестратор зможе виконати запит без підміни результату здогадкою." : proposesSystemBuild ? "Після погодження оркестратор має запустити Будівник мультиагентських систем: створити структуру, контракти, промпти, adapter stub, smoke test і додати систему в реєстр." : proposesAutomation ? "Після погодження оркестратор має створити регулярний task contract: cadence, trigger, checks, success criteria, журнал і правила звернення до користувача." : "Ти можеш вручну обрати систему нижче, і я продовжу з уже написаною задачею без повторного введення."}</span>
      </div>
      ${proposalActions}
      <div class="card-actions wrap ${isQuotaError || needsConnector || proposesSystemBuild || proposesAutomation ? "hidden" : ""}">
        ${topSystems}
      </div>
    </div>
  `;
}

function listItems(items) {
  return (items || []).length
    ? `<ul>${items.map((item) => `<li>${escapeHtml(item)}</li>`).join("")}</ul>`
    : "";
}

function renderSystemBuildProposal(proposedSystem) {
  const agents = (proposedSystem.agents || []).length
    ? `<ul>${proposedSystem.agents.map((agent) => `<li><strong>${escapeHtml(agent.name || "Agent")}</strong>: ${escapeHtml(agent.role || "")}</li>`).join("")}</ul>`
    : "";
  return `
    <div class="proposal-card">
      <h4>${escapeHtml(proposedSystem.name || "Нова мультиагентська система")}</h4>
      ${proposedSystem.goal ? `<p>${escapeHtml(proposedSystem.goal)}</p>` : ""}
      ${proposedSystem.why_existing_systems_are_not_enough ? `<p class="muted"><strong>Чому потрібна нова система:</strong> ${escapeHtml(proposedSystem.why_existing_systems_are_not_enough)}</p>` : ""}
      <details class="proposal-details">
        <summary>Архітектура системи</summary>
        <div class="proposal-grid">
          <div><strong>Агенти</strong>${agents}</div>
          <div><strong>Входи</strong>${listItems(proposedSystem.inputs)}</div>
          <div><strong>Результати</strong>${listItems(proposedSystem.outputs)}</div>
          <div><strong>Обмеження</strong>${listItems(proposedSystem.constraints)}</div>
        </div>
        ${proposedSystem.smoke_test ? `<p class="muted"><strong>Smoke test:</strong> ${escapeHtml(proposedSystem.smoke_test)}</p>` : ""}
      </details>
    </div>
  `;
}

function renderAutomationProposal(automation) {
  return `
    <div class="proposal-card">
      <h4>${escapeHtml(automation.name || "Heartbeat-задача")}</h4>
      <details class="proposal-details">
        <summary>Параметри автоматизації</summary>
        <div class="proposal-grid">
          <div><strong>Ритм</strong><p>${escapeHtml(automation.cadence || "потрібно погодити")}</p></div>
          <div><strong>Тригер</strong><p>${escapeHtml(automation.trigger || "потрібно погодити")}</p></div>
          <div><strong>Система / adapter</strong><p>${escapeHtml(automation.target_system_or_adapter || "потрібно визначити")}</p></div>
          <div><strong>Ескалація</strong><p>${escapeHtml(automation.human_escalation || "питати користувача при нестачі даних або помилках")}</p></div>
          <div><strong>Перевірки</strong>${listItems(automation.checks)}</div>
          <div><strong>Критерії успіху</strong>${listItems(automation.success_criteria)}</div>
        </div>
      </details>
    </div>
  `;
}

function renderDirectOrchestratorAnswer(routed) {
  const answer = String(routed.directAnswer || "")
    .split(/\n{2,}/)
    .map((paragraph) => `<p>${escapeHtml(paragraph)}</p>`)
    .join("");

  return `
    <div class="execution-card">
      <span class="eyebrow small">Відповідь оркестратора</span>
      <h3>Коротко про мої можливості</h3>
      <div class="direct-answer">
        ${answer}
      </div>
    </div>
  `;
}

function selectedTaskFiles() {
  return Array.from(elements.taskFiles?.files || []);
}

function requiredInputFor(system, files) {
  const needsDocument = ["legal_assistant", "ceo_profile"].includes(system.id);
  if (!needsDocument || files.length) {
    return "";
  }

  return `
    <div class="input-warning">
      <strong>Для повного виконання потрібен файл.</strong>
      <span>Оркестратор обрав правильну систему, але аналіз договору, статуту або іншого документа потребує завантаженого файлу чи тексту документа.</span>
    </div>
  `;
}

function executionSteps(system) {
  const templates = {
    legal_assistant: [
      "Прийняти документ або текст задачі як вхідні дані.",
      "Передати задачу юридичній системі: пошук норм, релевантної практики і локальної Wiki-бази.",
      "Структурувати висновок: суть питання, правові підстави, ризики, алгоритм дій і що треба уточнити.",
      "Повернути користувачу проєкт відповіді або правову позицію для перевірки."
    ],
    software_development: [
      "Знайти потрібний проєкт або модуль у workspace.",
      "Прочитати релевантний код і визначити мінімальний обсяг змін.",
      "Внести зміни, запустити доступну перевірку і підготувати короткий звіт."
    ],
    copywriter: [
      "Зібрати контекст задачі та цільову аудиторію.",
      "Підготувати чернетку тексту.",
      "Прогнати критику стилю, ясності й користі для читача.",
      "Повернути готову версію і, за потреби, варіанти."
    ],
    recruiting: [
      "Уточнити вакансію або профіль кандидата.",
      "Запустити агентів пошуку, скорингу і підготовки інтерв'ю.",
      "Повернути короткий список дій, ризиків і наступних кроків."
    ],
    founder_dashboard: [
      "Зібрати джерела даних або структуру показників.",
      "Підготувати управлінський звіт і логіку дашборду.",
      "Повернути висновки, KPI і файл/макет для подальшої роботи."
    ],
    marketing_content: [
      "Визначити ринок, аудиторію і ціль кампанії.",
      "Запустити дослідження, контент-план і генерацію матеріалів.",
      "Повернути готовий план або пакет матеріалів."
    ],
    excel_financial_modeling: [
      "Прийняти таблицю або опис моделі.",
      "Перевірити структуру, формули і потрібні розрахунки.",
      "Повернути оновлену модель або список точних правок."
    ],
    garmin_health: [
      "Прийняти експорт Garmin або опис показників.",
      "Проаналізувати сон, HRV, пульс, навантаження і стрес.",
      "Повернути звіт із висновками та обережними рекомендаціями."
    ],
    ceo_profile: [
      "Прийняти вимоги до посади або поточний документ.",
      "Зібрати структуру ролі, KPI, відповідальність і критерії погодження.",
      "Повернути DOCX-ready структуру або правки до документа."
    ],
    salary_region_review: [
      "Agent001 консолідує Excel-дані по містах, зарплатах і датах.",
      "Agent002 розраховує абсолютну і відносну зміну зарплат.",
      "Agent003 готує PPTX-презентацію з висновками.",
      "AgentCleaner збирає файли виконання і створює report.md."
    ],
    project_clean: [
      "Знайти файли у Input та Output агентів.",
      "Сконсолідувати результати у logs.",
      "Створити report.md із джерелами і коротким описом файлів."
    ],
    system_builder: [
      "AgentAnalyst аналізує опис нової системи.",
      "AgentPromptWriter пише PROMPT.md для агентів.",
      "AgentStructureCreator створює структуру, system.yaml і запис для реєстру."
    ]
  };

  return templates[system.id] || [
    "Зібрати вхідні дані задачі.",
    "Запустити обрану систему за її manifest.",
    "Повернути результат, файли і журнал виконання."
  ];
}

function expectedResult(system) {
  const results = {
    legal_assistant: "юридичний висновок, ризики, алгоритм дій і перелік питань, які треба уточнити",
    software_development: "внесені зміни в коді, перевірка і короткий технічний звіт",
    copywriter: "готовий текст або кілька редакцій під потрібний канал",
    recruiting: "структурований рекрутинговий результат: вакансія, кандидати, скоринг або план інтерв'ю",
    founder_dashboard: "звіт, KPI-логіка або дашборд для власника",
    marketing_content: "контент-план, маркетинговий аналіз або пакет матеріалів",
    excel_financial_modeling: "оновлена таблиця, модель або перелік виправлень",
    garmin_health: "health-звіт із висновками за даними Garmin",
    ceo_profile: "структура або готовий текст профілю посади",
    salary_region_review: "XLSX-розрахунки, презентація PPTX і звіт по файлах",
    project_clean: "logs/report.md і централізовано зібрані файли виконання",
    system_builder: "blueprint нової системи, PROMPT.md, system.yaml і структура папок"
  };
  return results[system.id] || "готовий результат задачі та журнал виконання";
}

function normalizeSystemEntry(system) {
  return {
    id: system.id,
    name: system.name,
    category: system.category || "generated",
    status: system.status || "needs_review",
    root_path: system.root_path || "",
    description: system.description || "Система створена оркестратором.",
    orchestration_mode: system.orchestration_mode || "sequential",
    agents: Array.isArray(system.agents) ? system.agents : [],
    priority: system.priority || registry.systems.length + 1,
    sensitive: Boolean(system.sensitive),
    triggers: Array.isArray(system.triggers) ? system.triggers : []
  };
}

function upsertSystem(system) {
  if (!system?.id) return;
  const normalized = normalizeSystemEntry(system);
  const index = registry.systems.findIndex((item) => item.id === normalized.id);
  if (index >= 0) {
    registry.systems[index] = { ...registry.systems[index], ...normalized };
  } else {
    registry.systems.push(normalized);
  }
  renderCompactStats();
  renderFilters();
  renderHomeSystems();
  renderSystemCatalog();
}

async function approveSystemBuild() {
  if (!state.pendingRun?.proposedSystem) {
    addChatMessage("assistant", "Немає підготовленого blueprint нової системи. Сформулюй задачу ще раз, і я спочатку спроєктую систему.");
    return;
  }

  addChatMessage("assistant", "Погодження отримано. Запускаю Будівник мультиагентських систем: структура, промпти, контракт, manifest, smoke test і реєстр.");
  renderProcessPanel("Створення системи", "Будівник формує папки, агентські PROMPT.md, system.yaml і draft-запис у реєстрі.", 2);

  try {
    const response = await window.OrchestratorClient.buildSystem({
      task: state.pendingRun.task,
      proposedSystem: state.pendingRun.proposedSystem
    });
    const build = response.build;
    if (build?.system) {
      upsertSystem(build.system);
      state.selectedId = build.system.id;
      currentChat().systemId = build.system.id;
      state.pendingSmokeSystem = {
        systemId: build.system.id,
        task: state.pendingRun.proposedSystem?.smoke_test || `Smoke test для системи ${build.system.name}`
      };
    }
    const resultHtml = build?.resultHtml || "<p>Систему створено, але backend не повернув HTML-звіт.</p>";
    currentChat().result = resultHtml;
    renderResultPanel(resultHtml);
    addChatMessage("assistant", "Систему створено як draft і додано в каталог. Наступний правильний крок - перший контрольний smoke-run.");
    addChatMessage("assistant", "", { html: resultHtml });
    if (build?.system) {
      addChatMessage("assistant", "", {
        html: `
          <div class="decision-card">
            <p class="eyebrow">Наступний крок</p>
            <h3>Запустити перший smoke-run?</h3>
            <p>Я перевірю manifest, prompt contracts, agent sequence, artifacts і після успішного quality gate переведу систему в active.</p>
            <div class="card-actions">
              <button class="primary-button run-system-smoke" type="button" data-system-id="${escapeHtml(build.system.id)}">Запустити smoke-run</button>
            </div>
          </div>
        `
      });
    }
    await refreshRuns();
    await refreshPlatformHealth();
    renderArchive();
  } catch (error) {
    console.error(error);
    renderProcessPanel("Створення не завершено", "Backend не зміг створити систему. Деталі записані в console.", 2);
    addChatMessage("assistant", "Не зміг створити систему через backend. Перевір, чи сервер запущений, і повтори погодження.");
  }
}

async function approveAutomation() {
  if (!state.pendingRun?.automation) {
    addChatMessage("assistant", "Немає підготовленого contract heartbeat-задачі. Сформулюй регулярну потребу ще раз, і я спочатку спроєктую автоматизацію.");
    return;
  }

  addChatMessage("assistant", "Погодження отримано. Створюю heartbeat-контракт: cadence, trigger, checks, success criteria, журнал і правила ескалації.");
  renderProcessPanel("Створення heartbeat", "Формую draft регулярної задачі. Scheduler ще не вмикаю без окремого погодження.", 2);

  try {
    const response = await window.OrchestratorClient.createAutomation({
      task: state.pendingRun.task,
      automation: state.pendingRun.automation
    });
    const automation = response.automation;
    const resultHtml = automation?.resultHtml || "<p>Heartbeat створено, але backend не повернув HTML-звіт.</p>";
    currentChat().result = resultHtml;
    renderResultPanel(resultHtml);
    addChatMessage("assistant", "Heartbeat-задачу створено як draft. Вона ще не працює у фоні, доки ми не підключимо scheduler або канал запуску.");
    addChatMessage("assistant", "", { html: resultHtml });
    await refreshAutomations();
    await refreshPlatformHealth();
    renderArchive();
  } catch (error) {
    console.error(error);
    renderProcessPanel("Heartbeat не створено", "Backend не зміг створити automation contract. Деталі записані в console.", 2);
    addChatMessage("assistant", "Не зміг створити heartbeat-задачу через backend. Перевір, чи сервер запущений, і повтори погодження.");
  }
}

async function runSystemSmoke(systemId) {
  const pending = state.pendingSmokeSystem?.systemId === systemId ? state.pendingSmokeSystem : null;
  const system = registry.systems.find((item) => item.id === systemId);
  if (!system) {
    addChatMessage("assistant", "Не знайшов систему для smoke-run у локальному каталозі. Онови реєстр і повтори.");
    return;
  }
  const task = pending?.task || `Smoke test для системи ${system.name}`;
  addChatMessage("assistant", `Запускаю перший smoke-run для системи: ${system.name}.`);
  renderProcessPanel("Smoke-run нової системи", "Перевіряю manifest, prompt contracts, adapter stub, agent sequence, artifacts і quality gate.", 2);
  try {
    const response = await window.OrchestratorClient.smokeSystem({
      systemId,
      task,
      activateOnSuccess: true
    });
    const execution = response.execution;
    if (execution?.system) {
      upsertSystem(execution.system);
      state.selectedId = execution.system.id;
      currentChat().systemId = execution.system.id;
    }
    const resultHtml = execution?.resultHtml || "<p>Smoke-run завершено, але backend не повернув HTML-звіт.</p>";
    currentChat().result = resultHtml;
    renderResultPanel(resultHtml);
    addChatMessage("assistant", response.activated
      ? "Smoke-run пройдено. Систему переведено в active і журнал оновлено."
      : "Smoke-run завершено, але система лишається needs_review. Причини показані у quality gate.");
    addChatMessage("assistant", "", { html: resultHtml });
    state.pendingSmokeSystem = null;
    await refreshRuns();
    await refreshRegistryFromBackend();
    await refreshPlatformHealth();
    renderHomeSystems();
    renderSystemCatalog();
    renderArchive();
  } catch (error) {
    console.error(error);
    renderProcessPanel("Smoke-run не завершено", "Backend не зміг виконати контрольний запуск нової системи.", 2);
    addChatMessage("assistant", "Smoke-run не завершено. Перевір backend і повтори запуск.");
  }
}

async function approveRun(systemId, executionMode = "production_multiagent") {
  const system = registry.systems.find((item) => item.id === systemId);
  if (!system || !state.pendingRun) return;

  state.selectedId = systemId;
  const now = new Date();
  const runId = state.pendingRun.runId || `run-${now.toISOString().replaceAll(":", "-").slice(0, 19)}`;
  state.pendingRun.runId = runId;
  const files = selectedTaskFiles();
  const chat = currentChat();
  chat.systemId = system.id;
  const modeText = executionMode === "production_multiagent" ? "через production multiagent систему" : "через Codex adapter";
  addChatMessage("assistant", `Погодження отримано. Пробую виконання ${modeText}: ${system.name}.`);
  renderProcessPanel("Виконання запущено", `${system.name} отримала задачу. Очікую результат і перевірку якості.`, 2);
  const { execution, verification } = await executeTaskWithGlobalOrchestrator(system, state.pendingRun.task, files, runId, executionMode);
  const status = verification.ok
    ? "виконано і перевірено"
    : verification.needsInput || execution.status === "needs_input"
      ? "очікує уточнення від користувача"
      : execution.runtime.connected ? "не підтверджено: результат не створено" : "не підтверджено: система не підключена";

  state.mockRuns.unshift({
    id: runId,
    system: system.name,
    status
  });
  await refreshRuns();
  await refreshPlatformHealth();
  renderMockRuns();

  if (execution.status === "adapter_required") {
    addChatMessage("assistant", "Production multiagent runner для цієї системи ще не підключений. Я не буду виконувати задачу сам, бо ти обрав запуск системи агентів.");
  } else if (verification.ok) {
    addChatMessage("assistant", "Результат отримано, перевірено і розміщено в зоні виконання.");
  } else if (verification.needsInput || execution.status === "needs_input") {
    const questions = execution.questions || [];
    state.pendingRun = {
      ...state.pendingRun,
      originalTask: state.pendingRun.originalTask || state.pendingRun.task,
      systemId: system.id,
      executionMode,
      awaitingInput: true,
      questions,
      runId
    };
    const questionList = questions.length
      ? `<ol>${questions.map((question) => `<li>${escapeHtml(question)}</li>`).join("")}</ol>`
      : "<p>Система попросила уточнення, але не повернула список питань.</p>";
    addChatMessage("assistant", "", {
      html: `
        <div class="decision-card warning">
          <p class="eyebrow">Питання від агентської системи</p>
          <h3>Потрібна відповідь користувача</h3>
          <p>${escapeHtml(system.name)} зупинилась у штатному human-in-loop кроці. Відповідай наступним повідомленням, і я поверну відповідь у цей самий run.</p>
          ${questionList}
        </div>
      `
    });
  } else if (execution.runtime.connected) {
    addChatMessage("assistant", "Adapter системи підключений, але результат не пройшов перевірку. Я розміщую причину в зоні виконання.");
  } else {
    addChatMessage("assistant", "Реальне виконання системою не підтверджено. Я розміщую діагностику і локальну MVP-чернетку окремо, щоб не видавати її за результат агентської системи.");
  }

  const resultHtml = execution.resultHtml;
  chat.result = resultHtml;
  addChatMessage("assistant", "", { html: resultHtml });
  renderResultPanel(resultHtml);
  if (verification.ok) {
    state.pendingRun = null;
  }
  renderArchive();
}

async function executeTaskWithGlobalOrchestrator(system, task, files, runId, executionMode = "production_multiagent") {
  if (window.OrchestratorClient) {
    try {
      const response = await window.OrchestratorClient.execute({
        task,
        systemId: system.id,
        runId,
        executionMode,
        files
      });
      if (response?.ok && response.execution) {
        return {
          execution: response.execution,
          verification: response.verification || verifyExecutionResult(response.execution)
        };
      }
    } catch (error) {
      console.warn("Global Orchestrator API execution unavailable, using browser fallback.", error);
    }
  }

  const execution = await executeSystem(system, task, files, runId);
  return {
    execution,
    verification: verifyExecutionResult(execution)
  };
}

function systemRuntime(system) {
  const adapterId = system.adapter?.id || `${system.id}_adapter`;
  const adapterType = system.adapter?.type || (system.id === "founder_dashboard" ? "local_file_adapter" : "local_mvp_adapter");
  return {
    connected: true,
    mode: adapterType,
    adapter: adapterId,
    reason: system.id === "founder_dashboard"
      ? "локальний browser adapter для CSV/TSV/JSON даних підключений"
      : "Codex Global Orchestrator підключив локальний MVP adapter для виконання і перевірки результату"
  };
}

async function executeSystem(system, task, files, runId) {
  const runtime = systemRuntime(system);

  if (system.id === "copywriter") {
    const questions = copywriterInterviewQuestions(task);
    if (questions.length) {
      return {
        runId,
        system,
        runtime,
        status: "needs_input",
        verified: false,
        source: runtime.mode,
        questions,
        resultHtml: `
          <article class="result-document execution-warning">
            <div class="result-meta">${badge(system.name, "sensitive")}${badge(runId)}${badge("needs_input")}</div>
            <h3>Копірайтерській системі потрібне інтерв'ю</h3>
            <p>AgentWritter не починає текст без відповідей користувача. Це штатний human-in-loop крок системи.</p>
            <ol>${questions.map((question) => `<li>${escapeHtml(question)}</li>`).join("")}</ol>
          </article>
        `
      };
    }
  }

  if (system.id === "founder_dashboard" && runtime.connected) {
    return executeFounderDashboard(system, task, files, runId, runtime);
  }

  if (runtime.connected) {
    const fileContext = await readTaskFileContext(files);
    const resultHtml = generateTaskResult(system, task, files, runId, {
      source: runtime.mode,
      fileContext
    });
    return {
      runId,
      system,
      runtime,
      verified: Boolean(resultHtml && resultHtml.trim()),
      source: runtime.mode,
      resultHtml
    };
  }

  const draftHtml = generateTaskResult(system, task, files, runId, { asDraft: true });

  if (!runtime.connected) {
    return {
      runId,
      system,
      runtime,
      verified: false,
      source: "mvp_local_draft",
      resultHtml: executionNotConnectedResult(system, task, files, runId, runtime, draftHtml)
    };
  }

  return {
    runId,
    system,
    runtime,
    verified: true,
    source: "system_adapter",
    resultHtml: generateTaskResult(system, task, files, runId)
  };
}

function verifyExecutionResult(execution) {
  const hasHtml = Boolean(execution.resultHtml && execution.resultHtml.trim().length > 0);
  const fromConnectedSystem = execution.runtime.connected && execution.source !== "mvp_local_draft";
  return {
    ok: hasHtml && fromConnectedSystem && execution.verified !== false,
    hasHtml,
    fromConnectedSystem,
    needsInput: execution.status === "needs_input"
  };
}

async function executeFounderDashboard(system, task, files, runId, runtime) {
  if (!files.length) {
    return {
      runId,
      system,
      runtime,
      verified: false,
      source: "local_file_adapter",
      resultHtml: dashboardAdapterIssue(system, runId, "Для побудови дашборду потрібен файл з даними у форматі CSV, TSV або JSON.")
    };
  }

  const file = files[0];
  const fileName = file.name || "data";
  const extension = fileName.split(".").pop().toLowerCase();

  if (["xlsx", "xls"].includes(extension)) {
    return {
      runId,
      system,
      runtime,
      verified: false,
      source: "local_file_adapter",
      resultHtml: dashboardAdapterIssue(
        system,
        runId,
        "Локальний browser adapter підключений, але XLSX поки не підтримується без backend-парсера або бібліотеки. Збережи файл як CSV/TSV або підключимо backend adapter для XLSX."
      )
    };
  }

  try {
    const text = await readTextFile(file);
    const dataset = parseDataset(text, fileName);
    const profile = profileDataset(dataset.rows);
    const dashboardHtml = renderDashboardResult(system, task, runId, fileName, dataset, profile);
    return {
      runId,
      system,
      runtime,
      verified: dataset.rows.length > 0,
      source: "local_file_adapter",
      resultHtml: dashboardHtml
    };
  } catch (error) {
    return {
      runId,
      system,
      runtime,
      verified: false,
      source: "local_file_adapter",
      resultHtml: dashboardAdapterIssue(system, runId, error.message || "Не вдалося прочитати файл.")
    };
  }
}

function readTextFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Не вдалося прочитати файл у браузері."));
    reader.readAsText(file, "utf-8");
  });
}

async function readTaskFileContext(files) {
  const readableExtensions = new Set(["txt", "md", "csv", "tsv", "json", "html", "xml"]);
  const contexts = [];

  for (const file of files.slice(0, 3)) {
    const extension = (file.name || "").split(".").pop().toLowerCase();
    if (!readableExtensions.has(extension)) {
      contexts.push({
        name: file.name,
        supported: false,
        text: "",
        note: "Формат не читається локальним browser adapter без backend-парсера."
      });
      continue;
    }

    try {
      const text = await readTextFile(file);
      contexts.push({
        name: file.name,
        supported: true,
        text: text.slice(0, 12000),
        note: ""
      });
    } catch (error) {
      contexts.push({
        name: file.name,
        supported: false,
        text: "",
        note: error.message || "Не вдалося прочитати файл."
      });
    }
  }

  return contexts;
}

function parseDataset(text, fileName) {
  const trimmed = text.trim();
  if (!trimmed) throw new Error("Файл порожній.");

  const extension = fileName.split(".").pop().toLowerCase();
  if (extension === "json" || trimmed.startsWith("{") || trimmed.startsWith("[")) {
    const parsed = JSON.parse(trimmed);
    const rows = Array.isArray(parsed)
      ? parsed
      : Array.isArray(parsed.rows)
        ? parsed.rows
        : Array.isArray(parsed.data)
          ? parsed.data
          : [parsed];
    return { type: "json", rows: normalizeRows(rows) };
  }

  const delimiter = detectDelimiter(trimmed);
  return { type: delimiter === "\t" ? "tsv" : "csv", rows: parseDelimited(trimmed, delimiter) };
}

function normalizeRows(rows) {
  return rows
    .filter((row) => row && typeof row === "object")
    .map((row) => Object.fromEntries(Object.entries(row).map(([key, value]) => [String(key), value ?? ""])));
}

function detectDelimiter(text) {
  const firstLine = text.split(/\r?\n/)[0] || "";
  const candidates = [",", ";", "\t"];
  return candidates
    .map((delimiter) => ({ delimiter, count: firstLine.split(delimiter).length }))
    .sort((a, b) => b.count - a.count)[0].delimiter;
}

function parseDelimited(text, delimiter) {
  const lines = text.split(/\r?\n/).filter((line) => line.trim().length);
  if (lines.length < 2) throw new Error("У файлі має бути рядок заголовків і хоча б один рядок даних.");

  const headers = splitDelimitedLine(lines[0], delimiter).map((header, index) => header.trim() || `column_${index + 1}`);
  return lines.slice(1).map((line) => {
    const values = splitDelimitedLine(line, delimiter);
    return Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ""]));
  });
}

function splitDelimitedLine(line, delimiter) {
  const result = [];
  let current = "";
  let quoted = false;

  for (let index = 0; index < line.length; index += 1) {
    const char = line[index];
    const next = line[index + 1];
    if (char === '"' && quoted && next === '"') {
      current += '"';
      index += 1;
    } else if (char === '"') {
      quoted = !quoted;
    } else if (char === delimiter && !quoted) {
      result.push(current);
      current = "";
    } else {
      current += char;
    }
  }
  result.push(current);
  return result.map((value) => value.trim());
}

function profileDataset(rows) {
  if (!rows.length) throw new Error("Після парсингу не знайдено рядків даних.");

  const columns = Object.keys(rows[0]);
  const profiles = columns.map((column) => {
    const values = rows.map((row) => row[column]).filter((value) => value !== null && value !== undefined && String(value).trim() !== "");
    const numericValues = values.map(toNumber).filter((value) => Number.isFinite(value));
    const uniqueValues = new Set(values.map((value) => String(value))).size;
    return {
      name: column,
      count: values.length,
      unique: uniqueValues,
      type: numericValues.length >= Math.max(2, values.length * 0.65) ? "number" : "text",
      numericValues
    };
  });

  return {
    rowCount: rows.length,
    columnCount: columns.length,
    columns: profiles,
    numericColumns: profiles.filter((column) => column.type === "number"),
    textColumns: profiles.filter((column) => column.type !== "number")
  };
}

function toNumber(value) {
  if (typeof value === "number") return value;
  const normalized = String(value)
    .replace(/\s/g, "")
    .replace(",", ".")
    .replace(/[^\d.-]/g, "");
  return normalized ? Number(normalized) : Number.NaN;
}

function formatNumber(value) {
  return new Intl.NumberFormat("uk-UA", { maximumFractionDigits: 2 }).format(value);
}

function renderDashboardResult(system, task, runId, fileName, dataset, profile) {
  const primaryMetrics = profile.numericColumns.slice(0, 4).map((column) => {
    const sum = column.numericValues.reduce((acc, value) => acc + value, 0);
    const avg = sum / column.numericValues.length;
    return `
      <article class="dashboard-kpi">
        <span>${escapeHtml(column.name)}</span>
        <strong>${formatNumber(sum)}</strong>
        <small>Сума · середнє ${formatNumber(avg)}</small>
      </article>
    `;
  }).join("");

  const categoryColumn = profile.textColumns.find((column) => column.unique > 1 && column.unique <= Math.min(12, profile.rowCount));
  const categoryHtml = categoryColumn ? renderCategoryBreakdown(dataset.rows, categoryColumn.name) : "";
  const columnsHtml = profile.columns.map((column) => `
    <tr>
      <td>${escapeHtml(column.name)}</td>
      <td>${column.type === "number" ? "числова" : "текстова"}</td>
      <td>${formatNumber(column.count)}</td>
      <td>${formatNumber(column.unique)}</td>
    </tr>
  `).join("");

  return `
    <article class="result-document dashboard-result">
      <div class="result-meta">
        ${badge(system.name, "active")}
        ${badge(runId)}
        ${badge("local_file_adapter", "active")}
        ${badge(escapeHtml(fileName))}
      </div>
      <h3>Дашборд для власника</h3>
      <p><strong>Задача:</strong> ${escapeHtml(task)}</p>
      <section class="dashboard-kpi-grid">
        <article class="dashboard-kpi">
          <span>Рядки</span>
          <strong>${formatNumber(profile.rowCount)}</strong>
          <small>завантажено з файлу</small>
        </article>
        <article class="dashboard-kpi">
          <span>Колонки</span>
          <strong>${formatNumber(profile.columnCount)}</strong>
          <small>${formatNumber(profile.numericColumns.length)} числових</small>
        </article>
        ${primaryMetrics}
      </section>
      ${categoryHtml}
      <section>
        <h4>Структура даних</h4>
        <div class="table-wrap">
          <table class="data-profile-table">
            <thead>
              <tr><th>Поле</th><th>Тип</th><th>Заповнено</th><th>Унікальних</th></tr>
            </thead>
            <tbody>${columnsHtml}</tbody>
          </table>
        </div>
      </section>
      <section>
        <h4>Висновок оркестратора</h4>
        <p>Система підключилась через локальний файловий adapter, прочитала дані, побудувала базові KPI та перевірила, що результат не порожній. Для наступної ітерації варто додати backend adapter для XLSX, збереження HTML-файлу дашборду та налаштовувані KPI власника.</p>
      </section>
    </article>
  `;
}

function renderCategoryBreakdown(rows, columnName) {
  const counts = rows.reduce((acc, row) => {
    const value = String(row[columnName] || "порожньо").trim() || "порожньо";
    acc[value] = (acc[value] || 0) + 1;
    return acc;
  }, {});
  const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 8);
  const max = Math.max(...entries.map((entry) => entry[1]), 1);

  return `
    <section>
      <h4>Розподіл за полем "${escapeHtml(columnName)}"</h4>
      <div class="bar-list">
        ${entries.map(([label, count]) => `
          <div class="bar-row">
            <span>${escapeHtml(label)}</span>
            <div><i style="width: ${(count / max) * 100}%"></i></div>
            <strong>${formatNumber(count)}</strong>
          </div>
        `).join("")}
      </div>
    </section>
  `;
}

function dashboardAdapterIssue(system, runId, message) {
  return `
    <article class="result-document execution-warning">
      <div class="result-meta">
        ${badge(system.name, "sensitive")}
        ${badge(runId)}
        ${badge("adapter підключений")}
        ${badge("результат не створено")}
      </div>
      <h3>Дашборд не побудовано</h3>
      <p>${escapeHtml(message)}</p>
    </article>
  `;
}

function combinedFileText(fileContext) {
  return (fileContext || [])
    .filter((item) => item.supported && item.text)
    .map((item) => `Файл: ${item.name}\n${item.text}`)
    .join("\n\n")
    .trim();
}

function executionNotConnectedResult(system, task, files, runId, runtime, draftHtml) {
  return `
    <article class="result-document execution-warning">
      <div class="result-meta">
        ${badge(system.name, "sensitive")}
        ${badge(runId)}
        ${badge("не підтверджено")}
      </div>
      <h3>Реальне виконання не відбулося</h3>
      <p><strong>Причина:</strong> ${escapeHtml(runtime.reason)}.</p>
      <p>Оркестратор перевірив результат і не може позначити його як виконаний агентською системою, бо adapter <strong>${escapeHtml(runtime.adapter)}</strong> не підключений.</p>
      <h4>Що потрібно для чесного виконання</h4>
      <ol>
        <li>Підключити backend/MCP adapter для системи <strong>${escapeHtml(system.name)}</strong>.</li>
        <li>Передати в adapter задачу, файли і manifest системи.</li>
        <li>Отримати структурований результат від системи.</li>
        <li>Провести верифікацію: результат не порожній, відповідає задачі, має джерело <strong>system_adapter</strong>.</li>
        <li>Тільки після цього розмістити його як фінальний результат.</li>
      </ol>
      <details class="run-package" open>
        <summary>Локальна MVP-чернетка, не результат системи</summary>
        ${draftHtml}
      </details>
    </article>
  `;
}

function generateTaskResult(system, task, files, runId, options = {}) {
  const source = options.source || "system_adapter";
  const meta = `
    <div class="result-meta">
      ${badge(system.name, "active")}
      ${badge(runId)}
      ${badge(source, "active")}
      ${options.asDraft ? badge("MVP-чернетка", "review") : ""}
      ${files.length ? badge(`${files.length} файл(ів)`) : ""}
    </div>
  `;
  const fileContext = options.fileContext || [];

  if (system.id === "copywriter") {
    return `${meta}${generateArticle(task)}`;
  }

  if (system.id === "legal_assistant") {
    const readableText = combinedFileText(fileContext);
    const needsFile = !readableText && /догов|договор|контракт|угод|статут|документ/i.test(task);
    if (needsFile) {
      return `
        ${meta}
        <article class="result-document">
          <h3>Юридична система готова до аналізу</h3>
          <p>Для аналізу договору або статуту потрібен сам текст документа. Без нього я можу описати методику, але не можу чесно зробити правовий висновок щодо умов, ризиків і формулювань.</p>
          <h4>Що потрібно додати</h4>
          <ol>
            <li>Завантаж файл договору або встав текст документа в чат.</li>
            <li>Напиши, що саме перевірити: ризики, розірвання, відповідальність, оплату, строки, підсудність, повноваження сторін.</li>
            <li>Після цього юридична система поверне висновок, ризики, питання для уточнення і рекомендовані правки.</li>
          </ol>
        </article>
      `;
    }
    return `${meta}${generateLegalResult(task, readableText)}`;
  }

  if (system.id === "software_development") {
    return `${meta}${generateSoftwareResult(task)}`;
  }

  if (system.id === "cosmetocard") {
    return `${meta}${generateCosmetoCardResult(task)}`;
  }

  if (system.id === "recruiting") {
    return `${meta}${generateRecruitingResult(task, combinedFileText(fileContext))}`;
  }

  if (system.id === "marketing_content") {
    return `${meta}${generateMarketingResult(task, combinedFileText(fileContext))}`;
  }

  if (system.id === "excel_financial_modeling") {
    return `${meta}${generateFinancialModelResult(task, fileContext)}`;
  }

  if (system.id === "garmin_health") {
    return `${meta}${generateGarminResult(task, fileContext)}`;
  }

  if (system.id === "ceo_profile") {
    return `${meta}${generateCeoProfileResult(task, combinedFileText(fileContext))}`;
  }

  return `${meta}${genericStructuredResult(expectedResult(system), task, executionSteps(system))}`;
}

function generateArticle(task) {
  const lower = task.toLowerCase();
  let topic = "роль оркестратора в мультиагентських системах";
  if (lower.includes("про ")) {
    topic = task.slice(lower.indexOf("про ") + 4).replace(/[.?!]+$/g, "").trim() || topic;
  }

  return `
    <article class="result-document">
      <h3>Коротка стаття: ${escapeHtml(topic)}</h3>
      <p>Сучасні AI-системи дедалі частіше складаються не з одного універсального помічника, а з кількох спеціалізованих агентів. Один агент шукає дані, інший структурує інформацію, третій пише текст, четвертий перевіряє результат. Але без оркестратора така система швидко перетворюється на набір розрізнених інструментів.</p>
      <p>Оркестратор виконує роль керівника процесу. Він приймає задачу від користувача, визначає її тип, обирає потрібну агентську систему, погоджує критичні дії та стежить, щоб робота завершилась конкретним результатом. Саме він відповідає за перехід від запиту до виконання: не просто “порадити, кого залучити”, а довести задачу до готового тексту, документа, аналізу, коду або звіту.</p>
      <p>Практична цінність такого підходу в тому, що користувач не має пам'ятати, яка система за що відповідає. Він формулює потребу звичайною мовою, а оркестратор бере на себе маршрутизацію, контроль якості та збереження історії роботи. У результаті мультиагентська платформа стає не каталогом агентів, а робочим середовищем для вирішення задач.</p>
      <p>Найсильніша модель - це діалогове вікно, де видно хід думки, погодження, проміжні рішення й фінальний результат. Саме тоді оркестратор стає не декоративним шаром над системами, а справжнім центром управління роботою.</p>
    </article>
  `;
}

function generateLegalResult(task, sourceText) {
  const hasSource = Boolean(sourceText);
  return `
    <article class="result-document">
      <h3>Юридичний висновок</h3>
      <p><strong>Питання:</strong> ${escapeHtml(task)}</p>
      <h4>Короткий висновок</h4>
      <p>${hasSource
        ? "Наданий документ можна аналізувати по суті. Насамперед треба перевірити предмет, повноваження сторін, строки, оплату, відповідальність, порядок розірвання та докази повідомлень."
        : "Для остаточного правового висновку потрібен текст документа або фактичні дані. Нижче наведено робочий алгоритм перевірки."}</p>
      <h4>Зони ризику</h4>
      <ol>
        <li>Нечіткий предмет або відсутність конкретних зобов'язань сторін.</li>
        <li>Неузгоджені строки оплати, виконання або повідомлення.</li>
        <li>Відповідальність сформульована односторонньо або без меж.</li>
        <li>Немає зрозумілого порядку припинення, розірвання чи виключення сторони.</li>
      </ol>
      <h4>Алгоритм дій</h4>
      <ol>
        <li>Виділити фактичну підставу вимоги або ризику.</li>
        <li>Зіставити її з договором, статутом або законом.</li>
        <li>Підготувати докази: листування, акти, протоколи, повідомлення, платіжні документи.</li>
        <li>Сформувати письмову позицію: вимога, заперечення, претензія або проєкт рішення.</li>
      </ol>
      ${hasSource ? `<h4>Фрагмент джерела</h4><p>${escapeHtml(sourceText.slice(0, 700))}</p>` : ""}
    </article>
  `;
}

function generateSoftwareResult(task) {
  return `
    <article class="result-document">
      <h3>Технічне рішення</h3>
      <p><strong>Задача:</strong> ${escapeHtml(task)}</p>
      <h4>План реалізації</h4>
      <ol>
        <li>Знайти відповідний модуль, entrypoint і місце інтеграції.</li>
        <li>Внести мінімальні зміни без зачіпання сторонніх файлів.</li>
        <li>Додати перевірку: синтаксис, збірка або browser-flow залежно від типу задачі.</li>
        <li>Повернути список змін, перевірок і відомих обмежень.</li>
      </ol>
      <h4>Результат MVP</h4>
      <p>Система сформувала технічну карту виконання і готова перейти до редагування коду, якщо задача містить конкретний файл, помилку або бажану поведінку.</p>
    </article>
  `;
}

function generateCosmetoCardResult(task) {
  return `
    <article class="result-document">
      <h3>CosmetoCard: план виконання</h3>
      <p><strong>Задача:</strong> ${escapeHtml(task)}</p>
      <h4>Контрольні блоки</h4>
      <ol>
        <li>Перевірити ліцензування й межі доступу користувача.</li>
        <li>Окремо тримати Android, iOS і Windows build-потоки.</li>
        <li>Не передавати приватні ключі або генератор ліцензій без явного рішення власника.</li>
        <li>Перед релізом перевірити package id, permissions, підпис і інструкцію встановлення.</li>
      </ol>
      <p>Для практичного виконання наступний крок - обрати конкретну платформу або файл збірки.</p>
    </article>
  `;
}

function generateRecruitingResult(task, sourceText) {
  return `
    <article class="result-document">
      <h3>Рекрутингова задача</h3>
      <p><strong>Запит:</strong> ${escapeHtml(task)}</p>
      <h4>Профіль пошуку</h4>
      <ol>
        <li>Уточнити роль, рівень, формат роботи, оплату і must-have навички.</li>
        <li>Сформувати scorecard: досвід, hard skills, soft skills, мотивація, ризики.</li>
        <li>Підготувати короткий outreach і структуру інтерв'ю.</li>
        <li>Повернути short-list або матрицю оцінки кандидатів.</li>
      </ol>
      <h4>Питання для інтерв'ю</h4>
      <ol>
        <li>Які задачі кандидат вирішував найближче до нашої ролі?</li>
        <li>Де він був власником результату, а де лише учасником?</li>
        <li>Які обмеження або конфлікти доводилось проходити?</li>
      </ol>
      ${sourceText ? `<h4>Вхідний контекст</h4><p>${escapeHtml(sourceText.slice(0, 600))}</p>` : ""}
    </article>
  `;
}

function generateMarketingResult(task, sourceText) {
  return `
    <article class="result-document">
      <h3>Маркетинговий план</h3>
      <p><strong>Запит:</strong> ${escapeHtml(task)}</p>
      <h4>Позиціонування</h4>
      <p>Фокус - не на переліку функцій, а на ситуації клієнта: проблема, бажаний результат, доказ і простий наступний крок.</p>
      <h4>Контент-план</h4>
      <ol>
        <li>Проблемний пост: що болить у клієнта зараз.</li>
        <li>Експертний пост: як правильно оцінити рішення.</li>
        <li>Кейс або приклад: до і після.</li>
        <li>Offer-пост: чітка пропозиція і дія.</li>
      </ol>
      <h4>Метрики</h4>
      <p>Оцінювати охоплення, переходи, заявки, конверсію в консультацію та якість лідів.</p>
      ${sourceText ? `<h4>Бриф</h4><p>${escapeHtml(sourceText.slice(0, 700))}</p>` : ""}
    </article>
  `;
}

function generateFinancialModelResult(task, fileContext) {
  const text = combinedFileText(fileContext);
  let datasetHtml = "";
  if (text) {
    try {
      const fileName = fileContext.find((item) => item.supported)?.name || "data.csv";
      const dataset = parseDataset(text.replace(/^Файл:.*\n/, ""), fileName);
      const profile = profileDataset(dataset.rows);
      datasetHtml = `<h4>Профіль таблиці</h4><p>Рядків: <strong>${formatNumber(profile.rowCount)}</strong>, колонок: <strong>${formatNumber(profile.columnCount)}</strong>, числових полів: <strong>${formatNumber(profile.numericColumns.length)}</strong>.</p>`;
    } catch {
      datasetHtml = "<p>Файл прочитано як текст, але табличну структуру не вдалося надійно розпізнати.</p>";
    }
  }

  return `
    <article class="result-document">
      <h3>Фінансова модель / Excel-аналіз</h3>
      <p><strong>Задача:</strong> ${escapeHtml(task)}</p>
      ${datasetHtml}
      <h4>Перевірки моделі</h4>
      <ol>
        <li>Відокремити вхідні дані, припущення, розрахунки і вихідні показники.</li>
        <li>Перевірити формули на ручні числа, пропуски і змішані одиниці.</li>
        <li>Виділити KPI: виручка, витрати, маржа, cash gap, точка беззбитковості.</li>
        <li>Повернути список правок і рекомендовану структуру листів.</li>
      </ol>
    </article>
  `;
}

function generateGarminResult(task, fileContext) {
  const text = combinedFileText(fileContext);
  let parsedNote = "Дані не завантажені або не в табличному форматі; результат побудовано як чекліст аналізу.";
  if (text) {
    try {
      const fileName = fileContext.find((item) => item.supported)?.name || "garmin.csv";
      const dataset = parseDataset(text.replace(/^Файл:.*\n/, ""), fileName);
      parsedNote = `Завантажено ${formatNumber(dataset.rows.length)} рядків health-даних.`;
    } catch {
      parsedNote = "Файл прочитано, але структуру Garmin-експорту треба уточнити.";
    }
  }

  return `
    <article class="result-document">
      <h3>Garmin Health Analytics</h3>
      <p><strong>Задача:</strong> ${escapeHtml(task)}</p>
      <p>${escapeHtml(parsedNote)}</p>
      <h4>Що аналізувати</h4>
      <ol>
        <li>Сон: тривалість, регулярність, якість відновлення.</li>
        <li>HRV: тренд, просідання, зв'язок зі стресом і навантаженням.</li>
        <li>Пульс і Body Battery: ознаки перевтоми або відновлення.</li>
        <li>Тренування: баланс навантаження і відпочинку.</li>
      </ol>
      <p>Це не медична порада; висновки слід використовувати як wellness-аналітику.</p>
    </article>
  `;
}

function generateCeoProfileResult(task, sourceText) {
  return `
    <article class="result-document">
      <h3>Профіль посади CEO</h3>
      <p><strong>Задача:</strong> ${escapeHtml(task)}</p>
      <h4>Місія ролі</h4>
      <p>CEO відповідає за цілісне управління бізнесом: стратегія, команда, фінансовий результат, операційна дисципліна і розвиток системи управління.</p>
      <h4>Ключові зони відповідальності</h4>
      <ol>
        <li>Стратегія і пріоритети компанії.</li>
        <li>Фінансовий результат, бюджет і управлінські KPI.</li>
        <li>Команда керівників і культура відповідальності.</li>
        <li>Операційна модель, процеси і контроль виконання.</li>
        <li>Комунікація з власником та погодження ключових рішень.</li>
      </ol>
      <h4>KPI</h4>
      <p>Виручка, EBITDA/маржа, cash flow, виконання стратегічних проєктів, стабільність команди, якість управлінської звітності.</p>
      ${sourceText ? `<h4>Вхідний документ</h4><p>${escapeHtml(sourceText.slice(0, 700))}</p>` : ""}
    </article>
  `;
}

function genericStructuredResult(title, task, steps) {
  return `
    <article class="result-document">
      <h3>${escapeHtml(title)}</h3>
      <p><strong>Задача:</strong> ${escapeHtml(task)}</p>
      <div class="detail-grid">
        <div class="info-block"><span>Статус</span><strong>виконано на рівні MVP</strong></div>
        <div class="info-block"><span>Формат</span><strong>структурований результат</strong></div>
      </div>
      <h4>Результат</h4>
      <p>Оркестратор визначив потрібний напрям роботи і сформував практичний план виконання. У повній інтеграції цей блок буде замінено результатом відповідної агентської системи з файлами, перевірками і журналом дій.</p>
      <h4>Алгоритм</h4>
      <ol>
        ${steps.map((step) => `<li>${escapeHtml(step)}</li>`).join("")}
      </ol>
      <h4>Наступний крок</h4>
      <p>Для повного виконання підключена система має отримати потрібні джерела: файл, папку проєкту, таблицю, бриф або інший конкретний матеріал.</p>
    </article>
  `;
}

function renderRunPackage(system, runId, files) {
  const fileList = files.length
    ? files.map((file) => `<li>${escapeHtml(file.name)}</li>`).join("")
    : "<li>Файли не додані.</li>";

  return `
    <details class="run-package">
      <summary>Технічний run-пакет</summary>
      <div class="run-plan">
        <h4>Алгоритм</h4>
        <ol>
          ${executionSteps(system).map((step) => `<li>${step}</li>`).join("")}
        </ol>
      </div>
      <div class="run-plan">
        <h4>Вхідні файли</h4>
        <ul>${fileList}</ul>
      </div>
    </details>
  `;
}

function buildRunPrompt(system, task, files) {
  const fileLine = files.length
    ? files.map((file) => file.name).join(", ")
    : "файли не додані; якщо без них задачу неможливо виконати, спочатку запитай документ або потрібні дані";

  return `Система: ${system.name}
Задача користувача: ${task}
Вхідні файли: ${fileLine}

Виконай задачу по суті, не обмежуйся рекомендацією системи.
Поверни результат у структурі:
1. Короткий висновок.
2. Детальний аналіз.
3. Покроковий алгоритм дій.
4. Ризики або обмеження.
5. Що потрібно від користувача, якщо даних недостатньо.`;
}

function bindRunButtons(scope = document) {
  scope.querySelectorAll(".approve-run").forEach((button) => {
    button.addEventListener("click", () => approveRun(button.dataset.systemId, button.dataset.executionMode));
  });
  scope.querySelectorAll(".approve-system-build").forEach((button) => {
    button.addEventListener("click", () => approveSystemBuild());
  });
  scope.querySelectorAll(".approve-automation").forEach((button) => {
    button.addEventListener("click", () => approveAutomation());
  });
  scope.querySelectorAll(".run-system-smoke").forEach((button) => {
    button.addEventListener("click", () => runSystemSmoke(button.dataset.systemId));
  });
  scope.querySelectorAll("[data-start-new-request]").forEach((button) => {
    button.addEventListener("click", () => startNewChat());
  });
}

function connectorAction(connector) {
  if (connector.status === "connected" || connector.action === "oauth_connected") {
    return `
      <div class="connector-actions">
        <span class="connector-connected">Підключено</span>
      </div>
    `;
  }
  if (!connector.auth_url) return "";
  const needsAuth = ["authorization_required", "needs_key"].includes(connector.status)
    || connector.action === "oauth_required"
    || connector.action === "connector_flow";
  if (!needsAuth) return "";
  return `
    <div class="connector-actions">
      <a class="primary-button connector-auth-link" href="${escapeHtml(connector.auth_url)}" target="_blank" rel="noopener noreferrer">
        Підключити конектор
      </a>
    </div>
  `;
}

function renderConnectors() {
  const connectors = state.connectors.length ? state.connectors : [
    { id: "openai_runtime", name: "OpenAI Runtime", label: "невідомо", status: "unknown", description: "Очікується відповідь backend.", detail: "" }
  ];
  elements.connectorGrid.innerHTML = connectors.map((connector) => `
    <article class="connector">
      <div class="connector-head">
        <h3>${connector.name}</h3>
        ${badge(connector.label || connector.status, connector.status === "connected" ? "active" : connector.status === "authorization_required" ? "review" : "")}
      </div>
      <p>${connector.description || connector.use || ""}</p>
      ${connector.detail && connector.detail !== connector.description ? `<p class="connector-detail">${connector.detail}</p>` : ""}
      ${Array.isArray(connector.instructions) && connector.instructions.length ? `
        <ol class="connector-instructions">
          ${connector.instructions.map((step) => `<li>${escapeHtml(step)}</li>`).join("")}
        </ol>
      ` : ""}
      ${connectorAction(connector)}
      <div class="connector-meta">
        ${badge(connector.scope || "core")}
        ${badge(connector.action || "automatic")}
      </div>
    </article>
  `).join("");
}

function renderDesktopBridge() {
  if (!elements.bridgeStatusPanel) return;
  const bridge = state.desktopBridge;
  if (!bridge) {
    elements.bridgeStatusPanel.innerHTML = `
      <div class="bridge-head">
        <div>
          <p class="eyebrow">Codex Desktop Bridge</p>
          <h3>Bridge status unavailable</h3>
          <p>Start the local orchestrator backend to see queue, worker and heartbeat state.</p>
        </div>
        ${badge("offline", "review")}
      </div>
    `;
    return;
  }
  const status = bridge.bridge?.status || "unknown";
  const statusType = status === "running" ? "active" : status === "idle" ? "" : "review";
  const activeRows = (bridge.active || []).map((item) => `
    <div class="bridge-run">
      <strong>${escapeHtml(item.run_id)}</strong>
      <span>${escapeHtml(item.worker?.worker_id || "desktop_codex")} · ${escapeHtml(item.bridge_health || item.status)}</span>
      <small>${escapeHtml(item.worker?.note || item.task || "")}</small>
    </div>
  `).join("");
  elements.bridgeStatusPanel.innerHTML = `
    <div class="bridge-head">
      <div>
        <p class="eyebrow">Codex Desktop Bridge</p>
        <h3>Desktop worker handoff</h3>
        <p>The platform queues packages; Codex Desktop claims, heartbeats, writes artifacts and completes the run through the bridge contract.</p>
      </div>
      ${badge(status, statusType)}
    </div>
    <div class="bridge-metrics">
      <div><span>Queued</span><strong>${bridge.summary?.queued || 0}</strong></div>
      <div><span>Active</span><strong>${bridge.summary?.active || 0}</strong></div>
      <div><span>Completed</span><strong>${bridge.summary?.completed || 0}</strong></div>
    </div>
    ${activeRows ? `<div class="bridge-active">${activeRows}</div>` : `
      <p class="muted">${bridge.next ? `Next package: ${escapeHtml(bridge.next.run_id)}` : "No package is waiting for Codex Desktop."}</p>
    `}
    <details class="decision-details">
      <summary>Bridge commands</summary>
      <pre class="trace-box">${escapeHtml(Object.values(bridge.commands || {}).join("\n"))}</pre>
    </details>
  `;
}

async function refreshDesktopBridge() {
  if (!window.OrchestratorClient?.desktopBridge) return;
  try {
    state.desktopBridge = await window.OrchestratorClient.desktopBridge();
  } catch (error) {
    console.warn("Desktop bridge status unavailable.", error);
    state.desktopBridge = null;
  }
  renderDesktopBridge();
}

function renderMockRuns() {
  const runs = state.runs.length ? state.runs : state.mockRuns.map((run) => ({
    id: run.id,
    system_name: run.system,
    status: run.status,
    artifact_count: 0,
    agent_execution: [],
    quality_gate: null,
    artifacts: [],
    modified_at: null,
    explanation: "Локальна чернетка запуску, ще не синхронізована з backend-журналом."
  }));
  if (!runs.length) {
    elements.runList.innerHTML = `
      <div class="soft-empty compact-empty">
        <h3>Журнал ще порожній</h3>
        <p>Після першого виконання тут з'явиться run trace, перевірка якості і файли результату.</p>
      </div>
    `;
    return;
  }
  elements.runList.innerHTML = runs.map((run) => `
    <article class="run-item">
      <div class="run-item-head">
        <strong>${escapeHtml(run.id)}</strong>
        ${badge(run.status || "unknown", run.status === "completed" || run.status === "виконано і перевірено" ? "active" : "review")}
      </div>
      <p>${escapeHtml(run.system_name || run.system || "Невідома система")}</p>
      <div class="system-meta">
        <span>${escapeHtml(formatDateTime(run.modified_at))}</span>
        <span>${escapeHtml(String(run.artifact_count || run.artifacts?.length || 0))} artifacts</span>
        <span>${escapeHtml(String(run.agent_execution?.length || 0))} agent steps</span>
        ${run.codex_worker ? `<span>worker: ${escapeHtml(run.codex_worker.status || run.codex_worker.worker_id || "codex")}</span>` : ""}
      </div>
      <div class="card-actions">
        <button class="secondary-button small-button show-run-trace" type="button" data-run-id="${escapeHtml(run.id)}">Trace</button>
        ${(run.artifacts || []).slice(0, 1).map((artifact) => `<a class="download-link compact-link" href="${artifact.url}" target="_blank" rel="noreferrer">Відкрити результат</a>`).join("")}
      </div>
    </article>
  `).join("");
  elements.runList.querySelectorAll(".show-run-trace").forEach((button) => {
    button.addEventListener("click", () => showRunTrace(button.dataset.runId));
  });
}

function renderQualityGate(gate) {
  if (!gate) return "<p>Quality gate не знайдено.</p>";
  const checks = Array.isArray(gate.checks) ? gate.checks : [];
  return `
    <div class="trace-section">
      <h4>Перевірка якості</h4>
      ${badge(gate.ok ? "пройдено" : "потребує уваги", gate.ok ? "active" : "review")}
      ${checks.length ? `<ul class="trace-list">${checks.map((check) => `<li><span>${escapeHtml(check.label || "check")}</span>${badge(check.ok ? "ok" : "fail", check.ok ? "active" : "review")}</li>`).join("")}</ul>` : ""}
    </div>
  `;
}

function renderAgentTrace(steps) {
  if (!Array.isArray(steps) || !steps.length) return "<p>Агентські кроки не записані.</p>";
  return `
    <div class="trace-section">
      <h4>Агентська послідовність</h4>
      <ol class="trace-list ordered">
        ${steps.map((step) => `
          <li>
            <span>${escapeHtml(step.agent || "Agent")}</span>
            ${badge(step.status || "unknown", step.status === "completed" ? "active" : "review")}
            ${step.output_file ? `<small>${escapeHtml(step.output_file)}</small>` : ""}
          </li>
        `).join("")}
      </ol>
    </div>
  `;
}

function renderRunArtifacts(run) {
  const artifacts = Array.isArray(run.artifacts) ? run.artifacts : [];
  if (!artifacts.length) return "<p>Файли результату не знайдені.</p>";
  return `
    <div class="trace-section">
      <h4>Artifacts</h4>
      <div class="artifact-list">
        ${artifacts.map((artifact) => `<a class="download-link" href="${artifact.url}" target="_blank" rel="noreferrer">${escapeHtml(artifact.filename)}</a>`).join("")}
      </div>
    </div>
  `;
}

function showRunTrace(runId) {
  const mock = state.mockRuns.find((item) => item.id === runId);
  const run = state.runs.find((item) => item.id === runId) || (mock ? {
    id: mock.id,
    system_name: mock.system,
    status: mock.status,
    agent_execution: [],
    artifacts: [],
    quality_gate: null,
    explanation: "Локальна чернетка запуску, ще не синхронізована з backend-журналом."
  } : null);
  if (!run) return;
  elements.infoTitle.textContent = `Run trace: ${run.id}`;
  elements.infoBody.innerHTML = `
    <div class="run-trace">
      <div class="trace-summary">
        <h3>${escapeHtml(run.system_name || run.system || "Невідома система")}</h3>
        <p>${escapeHtml(run.explanation || "Trace збережено у run-пакеті.")}</p>
        <div class="system-meta">
          <span>${escapeHtml(run.runtime_adapter || run.adapter_id || "adapter не вказано")}</span>
          <span>${escapeHtml(formatDateTime(run.modified_at))}</span>
          <span>${run.production_multiagent_executed ? "production multiagent" : run.mvp_backend_adapter_executed ? "Codex adapter" : "trace only"}</span>
          ${run.codex_worker ? `<span>${escapeHtml(run.codex_worker.worker_id || "codex_worker")} · ${escapeHtml(run.codex_worker.status || "claimed")}</span>` : ""}
        </div>
      </div>
      ${renderAgentTrace(run.agent_execution)}
      ${renderQualityGate(run.quality_gate)}
      ${renderRunArtifacts(run)}
    </div>
  `;
  elements.infoDialog.showModal();
}

function formatDateTime(value) {
  if (!value) return "не заплановано";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;
  return date.toLocaleString("uk-UA", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}

function renderAutomations() {
  if (!elements.automationList) return;
  if (!state.automations.length) {
    elements.automationList.innerHTML = `
      <div class="soft-empty compact-empty">
        <h3>Heartbeat ще не створено</h3>
        <p>Коли оркестратор запропонує регулярний task contract і ти погодиш, він з'явиться тут.</p>
      </div>
    `;
    return;
  }
  elements.automationList.innerHTML = state.automations.map((automation) => `
    <article class="automation-item">
      <div class="automation-head">
        <div>
          <strong>${escapeHtml(automation.name || automation.id)}</strong>
          <p>${escapeHtml(automation.cadence || "ритм потребує погодження")}</p>
        </div>
        ${badge(automation.scheduler?.enabled ? "active" : (automation.status || "draft"), automation.scheduler?.enabled ? "active" : "review")}
      </div>
      <div class="system-meta">
        <span>${escapeHtml(automation.trigger || "trigger pending")}</span>
        <span>${escapeHtml(automation.target_system_or_adapter || "target pending")}</span>
      </div>
      <div class="automation-schedule">
        <span>Наступний запуск</span>
        <strong>${escapeHtml(formatDateTime(automation.scheduler?.next_run_at))}</strong>
      </div>
      <div class="card-actions">
        <button class="primary-button run-automation" type="button" data-automation-id="${escapeHtml(automation.id)}">Smoke-run</button>
        <button class="secondary-button toggle-automation" type="button" data-automation-id="${escapeHtml(automation.id)}" data-enabled="${automation.scheduler?.enabled ? "false" : "true"}">${automation.scheduler?.enabled ? "Пауза" : "Увімкнути"}</button>
      </div>
    </article>
  `).join("");
  elements.automationList.querySelectorAll(".run-automation").forEach((button) => {
    button.addEventListener("click", () => runAutomation(button.dataset.automationId));
  });
  elements.automationList.querySelectorAll(".toggle-automation").forEach((button) => {
    button.addEventListener("click", () => toggleAutomationScheduler(button.dataset.automationId, button.dataset.enabled === "true"));
  });
}

async function refreshAutomations() {
  if (!window.OrchestratorClient?.automations) return;
  try {
    const response = await window.OrchestratorClient.automations();
    state.automations = Array.isArray(response.automations) ? response.automations : [];
  } catch (error) {
    console.warn("Automations unavailable.", error);
    state.automations = [];
  }
  renderAutomations();
}

async function refreshRuns() {
  if (!window.OrchestratorClient?.runs) return;
  try {
    const response = await window.OrchestratorClient.runs({ limit: 80 });
    state.runs = Array.isArray(response.runs) ? response.runs : [];
  } catch (error) {
    console.warn("Run history unavailable.", error);
  }
  await refreshDesktopBridge();
  renderMockRuns();
}

function healthIssueLabel(issue) {
  return issue.level === "error" ? "помилка" : "попередження";
}

function showPlatformHealthDialog(health) {
  if (!health) return;
  const s = health.summary || {};
  const issueRows = (health.issues || []).slice(0, 20).map((issue) => `
    <div class="health-issue">
      <strong>${escapeHtml(issue.system_id)} · ${healthIssueLabel(issue)}</strong>
      <span>${escapeHtml(issue.message)}</span>
    </div>
  `).join("");
  const recentRuns = (s.recent_runs || []).slice(0, 6).map((run) => `
    <div class="health-issue">
      <strong>${escapeHtml(run.system_name || run.system_id || run.id)}</strong>
      <span>${escapeHtml(run.status)} · ${escapeHtml(run.id)} · ${run.artifact_count || 0} файлів</span>
    </div>
  `).join("");

  elements.infoTitle.textContent = "Перевірка платформи";
  elements.infoBody.innerHTML = `
    <div class="health-dialog">
      <div class="health-metrics">
        <div><span>Системи</span><strong>${s.total_systems || 0}</strong></div>
        <div><span>Активні</span><strong>${s.active_systems || 0}</strong></div>
        <div><span>Помилки</span><strong>${s.systems_with_errors || 0}</strong></div>
        <div><span>Попередження</span><strong>${s.systems_with_warnings || 0}</strong></div>
        <div><span>Runs OK</span><strong>${s.completed_runs || 0}</strong></div>
        <div><span>Runs failed</span><strong>${s.failed_runs || 0}</strong></div>
      </div>
      <section class="health-issues">
        <h4>${health.ok ? "Критичних проблем не знайдено" : "Що потребує уваги"}</h4>
        ${issueRows || "<p>Реєстр, generated contracts і базові artifacts виглядають узгоджено.</p>"}
      </section>
      <section class="health-issues">
        <h4>Останні запуски</h4>
        ${recentRuns || "<p>Журнал запусків поки порожній.</p>"}
      </section>
    </div>
  `;
  elements.infoDialog.showModal();
}

async function refreshPlatformHealth({ showDialog = false } = {}) {
  if (!window.OrchestratorClient?.platformHealth) return;
  try {
    const health = await window.OrchestratorClient.platformHealth();
    state.platformHealth = health;
    renderPlatformHealthDashboard();
    if (showDialog) showPlatformHealthDialog(health);
  } catch (error) {
    console.warn("Platform health unavailable.", error);
    if (showDialog) {
      elements.infoTitle.textContent = "Перевірка недоступна";
      elements.infoBody.innerHTML = `
        <p>Backend не повернув стан платформи. Перевір, чи запущений сервер оркестратора.</p>
        <pre class="trace-box">${escapeHtml(error.message || String(error))}</pre>
      `;
      elements.infoDialog.showModal();
    }
  }
}

async function runAutomation(automationId) {
  const automation = state.automations.find((item) => item.id === automationId);
  addChatMessage("assistant", `Запускаю ручний smoke-run heartbeat: ${automation?.name || automationId}.`);
  renderProcessPanel("Heartbeat smoke-run", "Виконую регулярну задачу вручну, записую run log і перевіряю результат.", 2);
  try {
    const response = await window.OrchestratorClient.runAutomation({ automationId });
    const resultHtml = response.execution?.resultHtml || "<p>Heartbeat smoke-run завершено без HTML-звіту.</p>";
    currentChat().result = resultHtml;
    renderResultPanel(resultHtml);
    addChatMessage("assistant", "Heartbeat smoke-run завершено. Журнал оновлено.");
    addChatMessage("assistant", "", { html: resultHtml });
    await refreshAutomations();
    await refreshRuns();
    await refreshPlatformHealth();
  } catch (error) {
    console.error(error);
    renderProcessPanel("Heartbeat не виконано", "Не вдалося виконати ручний smoke-run. Перевір backend і automation contract.", 2);
    addChatMessage("assistant", "Не вдалося виконати heartbeat smoke-run. Деталі є в console.");
  }
}

async function toggleAutomationScheduler(automationId, enabled) {
  const automation = state.automations.find((item) => item.id === automationId);
  addChatMessage("assistant", `${enabled ? "Увімкнення" : "Пауза"} heartbeat scheduler: ${automation?.name || automationId}.`);
  try {
    await window.OrchestratorClient.setAutomationScheduler({ automationId, enabled });
    await refreshAutomations();
    addChatMessage("assistant", enabled
      ? "Heartbeat scheduler увімкнено. Автоматизація чекатиме next_run_at і не виконуватиме зовнішніх дій без правил contract."
      : "Heartbeat scheduler поставлено на паузу.");
  } catch (error) {
    console.error(error);
    addChatMessage("assistant", "Не вдалося змінити стан heartbeat scheduler. Перевір backend і automation contract.");
  }
}

function setView(view) {
  state.view = view;
  elements.navItems.forEach((button) => button.classList.toggle("active", button.dataset.view === view));
  elements.views.forEach((section) => section.classList.remove("active"));
  document.getElementById(`${view}View`).classList.add("active");

  const titles = {
    home: "Вирішення задач",
    systems: "Каталог систем",
    runs: "Журнал запусків",
    connectors: "Конектори та скіли",
    about: "Про платформу"
  };
  elements.viewTitle.textContent = titles[view];
  if (view === "connectors") {
    refreshConnectorsFromBackend().then(renderConnectors).catch(() => renderConnectors());
  }
  if (view === "runs") {
    refreshRuns();
  }
  if (view === "systems") {
    refreshPlatformHealth();
  }
  document.querySelectorAll(".admin-action").forEach((button) => {
    button.classList.toggle("hidden", view === "home");
  });
}

function slugifySystemName(name) {
  const translit = {
    а: "a", б: "b", в: "v", г: "h", ґ: "g", д: "d", е: "e", є: "ye", ж: "zh", з: "z",
    и: "y", і: "i", ї: "yi", й: "y", к: "k", л: "l", м: "m", н: "n", о: "o", п: "p",
    р: "r", с: "s", т: "t", у: "u", ф: "f", х: "kh", ц: "ts", ч: "ch", ш: "sh",
    щ: "shch", ь: "", ю: "yu", я: "ya", ы: "y", э: "e", ё: "yo", ъ: ""
  };
  return name
    .toLowerCase()
    .split("")
    .map((char) => translit[char] ?? char)
    .join("")
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 48) || "new_system";
}

function selectedFolderInfo() {
  const files = Array.from(elements.newSystemFolder.files || []);
  if (!files.length) {
    return { files, rootName: "", hasManifest: false, manifestPath: "" };
  }

  const firstPath = files[0].webkitRelativePath || files[0].name;
  const rootName = firstPath.includes("/") ? firstPath.split("/")[0] : "selected_folder";
  const manifestFile = files.find((file) => {
    const path = (file.webkitRelativePath || file.name).toLowerCase();
    return path.endsWith("/system.yaml") || path === "system.yaml";
  });

  return {
    files,
    rootName,
    hasManifest: Boolean(manifestFile),
    manifestPath: manifestFile ? manifestFile.webkitRelativePath || manifestFile.name : ""
  };
}

function updateFolderStatus() {
  const info = selectedFolderInfo();
  if (!info.files.length) {
    elements.folderStatus.textContent = "Папку ще не обрано";
    elements.importSummary.hidden = true;
    return;
  }

  elements.folderStatus.textContent = `Обрано: ${info.rootName}`;
  elements.importSummary.hidden = false;
  elements.importSummary.innerHTML = `
    <strong>${info.rootName}</strong>
    <span>${info.files.length} файлів</span>
    <span>${info.hasManifest ? `manifest знайдено: ${info.manifestPath}` : "manifest не знайдено - буде створено з шаблону"}</span>
  `;
}

function buildManifestPreview() {
  const name = document.getElementById("newSystemName").value || "Назва нової системи";
  const id = slugifySystemName(name);
  const folder = selectedFolderInfo();
  const rootPath = folder.rootName || "Оберіть папку";

  return `schema_version: "1.0"
id: ${id}
name: "${name}"
category: custom
status: draft
root_path: "${rootPath}"
description: "Опис буде уточнено після аналізу папки системи."
entry_agent: AgentOrchestrator
orchestration_mode: sequential
manifest_source: "${folder.hasManifest ? folder.manifestPath : "буде створено з шаблону"}"
global_orchestrator:
  id: codex
  semantic_routing: true
  allow_direct_codex_execution: true
execution:
  adapter_id: ${id}_adapter
  adapter_type: local_mvp_adapter
  production_adapter_status: not_connected
  result_contract:
    final_result_required: true
    result_must_be_user_visible: true
    allowed_sources: ["system_adapter", "local_mvp_adapter"]
  verification_rules:
    - "Result is not empty"
    - "Result answers the task"
    - "Result source is declared"
    - "Result is placed in chat and result workspace"
fallback:
  local_mvp_adapter:
    enabled: true
    label: local_mvp_adapter
`;
}

function addDraftSystem(event) {
  event.preventDefault();
  const name = document.getElementById("newSystemName").value.trim();
  const folder = selectedFolderInfo();
  const id = slugifySystemName(name);

  if (!name || !folder.files.length) return;

  registry.systems.push({
    id,
    name,
    category: "custom",
    status: "draft",
    root_path: folder.rootName,
    description: folder.hasManifest ? "Система додана з наявним manifest." : "Система додана як чернетка, manifest буде створено з шаблону.",
    orchestration_mode: "sequential",
    agents: [],
    sensitive: false,
    triggers: [name.toLowerCase()],
    adapter: {
      id: `${id}_adapter`,
      type: "local_mvp_adapter",
      status: "ready",
      result_contract: "final_result_required"
    },
    priority: registry.systems.length + 1
  });

  elements.addSystemForm.reset();
  elements.manifestPreview.hidden = true;
  elements.folderStatus.textContent = "Папку ще не обрано";
  elements.importSummary.hidden = true;
  elements.addSystemDialog.close();
  renderCompactStats();
  renderFilters();
  renderHomeSystems();
  renderSystemCatalog();
  chooseSystem(id);
  refreshPlatformHealth();
}

function openConnectorDialog(kind) {
  const isSkill = kind === "skill";
  elements.connectorDialogTitle.textContent = isSkill ? "Налаштування скілів" : "Налаштування конекторів";
  elements.connectorDialogText.textContent = isSkill
    ? "Скіли мають підключатися через окремий розділ налаштувань платформи: встановлення, версія, опис можливостей і список систем, які можуть їх використовувати."
    : "Базові конектори платформи вже вбудовані й використовуються автоматично. Приватні сервіси на кшталт Google Drive, GitHub або Slack авторизуються один раз у налаштуваннях, після чого оркестратор сам обирає їх за потреби.";
  elements.connectorDialog.showModal();
}

async function refreshRegistryFromBackend() {
  if (!window.OrchestratorClient?.registry) return;
  try {
    const response = await window.OrchestratorClient.registry();
    if (!response?.ok || !Array.isArray(response.systems)) return;
    registry.systems.splice(0, registry.systems.length, ...response.systems.map(normalizeSystemEntry));
  } catch (error) {
    console.warn("Backend registry unavailable, using bundled UI registry.", error);
  }
}

async function refreshConnectorsFromBackend() {
  if (!window.OrchestratorClient?.connectors) return;
  try {
    const response = await window.OrchestratorClient.connectors();
    if (!response?.ok || !Array.isArray(response.connectors)) return;
    state.connectors = response.connectors;
  } catch (error) {
    console.warn("Backend connectors unavailable.", error);
  }
}

async function refreshConnectorCards() {
  await refreshConnectorsFromBackend();
  renderConnectors();
  renderCompactStats();
}

async function init() {
  await refreshRegistryFromBackend();
  await refreshConnectorsFromBackend();
  await refreshRuns();
  await refreshAutomations();
  await refreshPlatformHealth();
  renderCompactStats();
  renderFilters();
  renderHomeSystems();
  renderSystemCatalog();
  renderConnectors();
  renderMockRuns();
  startNewChat();

  elements.navItems.forEach((button) => {
    button.addEventListener("click", () => setView(button.dataset.view));
  });

  elements.searchInput.addEventListener("input", renderSystemCatalog);
  elements.categoryFilter.addEventListener("change", renderSystemCatalog);
  elements.routeButton.addEventListener("click", routeTask);
  elements.clearTaskButton.addEventListener("click", () => {
    elements.taskInput.value = "";
    if (elements.taskFiles) elements.taskFiles.value = "";
    renderFileStatus();
    state.pendingRun = null;
  });
  if (elements.taskFiles) elements.taskFiles.addEventListener("change", renderFileStatus);
  elements.newChatButton.addEventListener("click", startNewChat);
  elements.newRequestButton.addEventListener("click", startNewChat);
  elements.taskInput.addEventListener("keydown", (event) => {
    if (event.ctrlKey && event.key === "Enter") routeTask();
  });

  elements.validateButton.addEventListener("click", () => refreshPlatformHealth({ showDialog: true }));

  elements.addSystemButton.addEventListener("click", () => elements.addSystemDialog.showModal());
  elements.closeAddSystemButton.addEventListener("click", () => elements.addSystemDialog.close());
  elements.addSystemForm.addEventListener("submit", addDraftSystem);
  elements.newSystemFolder.addEventListener("change", updateFolderStatus);
  elements.previewManifestButton.addEventListener("click", () => {
    elements.manifestPreview.textContent = buildManifestPreview();
    elements.manifestPreview.hidden = false;
  });

  elements.closeInfoButton.addEventListener("click", () => elements.infoDialog.close());
  elements.infoDialog.addEventListener("click", (event) => {
    if (event.target === elements.infoDialog) elements.infoDialog.close();
  });

  elements.mockRunButton.addEventListener("click", () => refreshRuns());
  if (elements.refreshAutomationsButton) {
    elements.refreshAutomationsButton.addEventListener("click", () => refreshAutomations());
  }

  elements.addConnectorButton.addEventListener("click", () => openConnectorDialog("connector"));
  elements.addSkillButton.addEventListener("click", () => openConnectorDialog("skill"));
  elements.closeConnectorDialogButton.addEventListener("click", () => elements.connectorDialog.close());
  elements.connectorDialogOkButton.addEventListener("click", () => elements.connectorDialog.close());
  window.addEventListener("focus", refreshConnectorCards);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden) refreshConnectorCards();
  });
  setView("home");
}

init();
