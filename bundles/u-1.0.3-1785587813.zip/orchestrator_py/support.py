"""
support.py — журнал годин техпідтримки з місячним лімітом за ліцензією.

Ліцензія може задавати квоту годин підтримки на місяць (поле sh у ключі). Цей
модуль веде журнал наданих годин і рахує використане за поточний місяць, щоб
підтримка була прозорою й не зловживалась. Квота 0 = не задано (не відстежуємо).
"""
import json
from datetime import date

import config

_PATH = config.RUNS_DIR / "_support_log.json"


def _load() -> list:
    try:
        return json.loads(_PATH.read_text(encoding="utf-8"))
    except Exception:
        return []


def _save(entries: list):
    try:
        _PATH.parent.mkdir(parents=True, exist_ok=True)
        _PATH.write_text(json.dumps(entries, ensure_ascii=False, indent=2), encoding="utf-8")
    except Exception:
        pass


def _month_key(d: date = None) -> str:
    d = d or date.today()
    return f"{d.year:04d}-{d.month:02d}"


def log(hours, note: str = "") -> dict:
    """Записати надані години підтримки (дата — сьогодні)."""
    try:
        hours = round(float(hours), 2)
    except Exception:
        return None
    if hours <= 0:
        return None
    e = {"date": date.today().isoformat(), "hours": hours, "note": (note or "").strip()[:200]}
    entries = _load()
    entries.append(e)
    _save(entries)
    return e


def used_this_month() -> float:
    mk = _month_key()
    return round(sum(float(e.get("hours", 0) or 0) for e in _load()
                     if str(e.get("date", "")).startswith(mk)), 2)


def quota() -> int:
    """Місячна квота годин підтримки з ліцензії (0 = не задано)."""
    try:
        import license as _lic
        return int(_lic.entitlement().get("support_hours", 0) or 0)
    except Exception:
        return 0


def summary() -> dict:
    q = quota()
    used = used_this_month()
    mk = _month_key()
    recent = [e for e in _load() if str(e.get("date", "")).startswith(mk)]
    return {"month": mk, "quota": q, "used": used, "tracked": q > 0,
            "left": (round(q - used, 2) if q > 0 else None),
            "over": (q > 0 and used > q), "entries": recent[-20:]}
