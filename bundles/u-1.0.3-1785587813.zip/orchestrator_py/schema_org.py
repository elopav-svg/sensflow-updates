# -*- coding: utf-8 -*-
"""Детермінований будівник schema.org JSON-LD — брат artifacts.xlsxmodel_to_xlsx.

Контракт «модель → рендер»: SEO-стратег віддає КОМПАКТНУ модель у блоці
```schemaorg (які типи + поля, значення ЛИШЕ з реального витягу сторінки), а
повний валідний JSON-LD детерміновано збирає цей модуль. Це лікує три корені
SEO-флагмана (13.07.2026):

  #2 ОБРИВ JSON — стратег більше не виписує важкі JSON-LD руками у своєму
     3000-токенному кроці (саме там чернетку різало посеред schema). Модель
     крихітна → крок не впирається в ліміт → хвостові розділи не гинуть.
  #3 ПЛЕЙСХОЛДЕРИ URL — поля, для яких на сторінці НЕМАЄ реальних даних
     (логотип, соцмережі, ціни), у JSON НЕ потрапляють заглушками «[...]».
     Вони виносяться в людський чек-лист «Дозаповнити перед публікацією».
  (#1 контракт — закривають правки промптів: єдине джерело про сторінку —
     живий витяг движка, а не статичні Input-файли.)

Єдине джерело значень — facts (реальний структурований витяг tools.read_page_seo),
а не вигадки агента. Порожній/невалідний блок НЕ віддається користувачу сирим.
"""
import json
import re

# Блок моделі у фіналі (як ```xlsxmodel). Терпимо до 3+ бектиків і регістру.
_FENCE_RE = re.compile(r"```+[ \t]*schemaorg[ \t]*\r?\n(.*?)```+", re.S | re.I)

# Ознаки «несправжнього» значення (плейсхолдер/невпевненість) — такі значення
# ніколи не пускаємо в JSON; вони йдуть у чек-лист «дозаповнити».
_PLACEHOLDER_RE = re.compile(r"\[[^\]]*\]|не підтверджено|вилучено|\bTODO\b|\bXXX\b", re.I)

# Рекомендовані поля типів, яких на сторінці часто фізично немає. Якщо агент їх
# не дав (або дав плейсхолдером) — це рядок чек-листа, а не діра в JSON.
_FILL_HINTS = {
    "Organization": {
        "logo": "URL логотипу — повна адреса файла лого з сайту",
        "sameAs": "посилання на офіційні соцмережі (лише реальні; порожнє — краще, ніж вигадане)",
    },
    "Product": {
        "image": "URL фото продукту",
        "offers": "ціна + валюта (напр. 'price': 2500, 'priceCurrency': 'UAH')",
    },
}

# Порядок @-ключів для стабільного, читабельного виводу.
_KEY_ORDER = ["@context", "@type", "name", "url", "logo", "image", "description",
              "brand", "offers", "contactPoint", "sameAs", "mainEntity"]


def _clean_value(v):
    """Значення, що містить плейсхолдер/невпевненість → None (не в JSON)."""
    if isinstance(v, str):
        if not v.strip() or _PLACEHOLDER_RE.search(v):
            return None
        return v.strip()
    if isinstance(v, list):
        out = [x for x in (_clean_value(i) for i in v) if x is not None]
        return out or None
    if isinstance(v, dict):
        out = {k: cv for k, cv in ((k, _clean_value(x)) for k, x in v.items()) if cv is not None}
        return out or None
    return v  # числа/булеві лишаємо як є


def _parse(raw: str):
    """Розбирає JSON моделі; салвадж — перша збалансована {…}. None, якщо не JSON."""
    raw = (raw or "").strip()
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        pass
    i = raw.find("{")
    j = raw.rfind("}")
    if i != -1 and j != -1 and j > i:
        try:
            return json.loads(raw[i:j + 1])
        except Exception:
            return None
    return None


def _order_keys(d: dict) -> dict:
    """Впорядковує ключі для стабільного виводу (без втрати нестандартних)."""
    ordered = {k: d[k] for k in _KEY_ORDER if k in d}
    for k, v in d.items():
        if k not in ordered:
            ordered[k] = v
    return ordered


def _page_url(facts: dict) -> str:
    facts = facts or {}
    return (facts.get("canonical") or facts.get("url") or "").strip()


def _build_block(block: dict, facts: dict):
    """Один блок моделі → (jsonld_dict|None, [рядки_чек-листа]).

    Значення бере з полів агента (очищених від плейсхолдерів) + збагачує
    реальними фактами сторінки. Чого нема реального — у чек-лист."""
    facts = facts or {}
    btype = (block.get("type") or "").strip()
    if not btype:
        return None, []
    fields = _clean_value(block.get("fields") or {}) or {}
    jd = {"@context": "https://schema.org", "@type": btype}
    jd.update(fields)

    # Збагачення реальними фактами (тільки якщо агент не дав своє).
    if "url" not in jd and btype in ("Organization", "WebSite", "Product", "WebPage"):
        u = _page_url(facts)
        if u:
            jd["url"] = u

    todo = []

    # FAQPage: будуємо mainEntity з faq:[{q,a}] (реальні питання/відповіді).
    if btype == "FAQPage":
        faq = block.get("faq") or []
        qa = []
        for item in faq:
            q = _clean_value((item or {}).get("q"))
            a = _clean_value((item or {}).get("a"))
            if q and a:
                qa.append({"@type": "Question", "name": q,
                           "acceptedAnswer": {"@type": "Answer", "text": a}})
        if qa:
            jd["mainEntity"] = qa
        else:
            todo.append("FAQPage → додати 3–5 реальних пар «питання → коротка відповідь» "
                        "(з наявних H2/FAQ сторінки)")

    # Рекомендовані, але часто відсутні поля → чек-лист (не заглушка в JSON).
    for fname, hint in _FILL_HINTS.get(btype, {}).items():
        if fname not in jd:
            todo.append(f"{btype} → {fname}: {hint}")

    return _order_keys(jd), todo


def build_jsonld(model: dict, facts: dict):
    """Модель → (markdown_рендер, to_fill[]). markdown містить валідні ```json
    блоки + секцію «Дозаповнити перед публікацією». Порожня модель → (None, [])."""
    if not isinstance(model, dict):
        return None, []
    blocks = model.get("blocks")
    if not isinstance(blocks, list) or not blocks:
        return None, []
    parts, to_fill = [], []
    for block in blocks:
        if not isinstance(block, dict):
            continue
        jd, todo = _build_block(block, facts)
        if jd is None:
            continue
        label = jd.get("@type", "schema")
        parts.append(f"**schema.org: {label}** — готова розмітка (встав у `<head>` сторінки):\n\n"
                     "```json\n" + json.dumps(jd, ensure_ascii=False, indent=2) + "\n```")
        to_fill.extend(todo)
    if not parts:
        return None, to_fill
    md = "\n\n".join(parts)
    if to_fill:
        md += ("\n\n### ⚠ Дозаповнити перед публікацією\n"
               "Ці поля не вставлено в розмітку, бо їх не було на сторінці. "
               "Впиши реальні значення (не вигадуй) перед тим, як публікувати:\n"
               + "\n".join(f"- {t}" for t in to_fill))
    return md, to_fill


def check_schema(md: str):
    """Валідація блоку ```schemaorg БЕЗ побічних ефектів → (ok, err)."""
    if not md or "schemaorg" not in md:
        return False, "немає блоку ```schemaorg"
    m = _FENCE_RE.search(md)
    if not m:
        return False, "немає блоку ```schemaorg"
    model = _parse(m.group(1))
    if not isinstance(model, dict):
        return False, "блок schemaorg не є валідним JSON-обʼєктом"
    blocks = model.get("blocks")
    if not isinstance(blocks, list) or not blocks:
        return False, "у моделі немає непорожнього списку blocks"
    if not any(isinstance(b, dict) and (b.get("type") or "").strip() for b in blocks):
        return False, "жоден блок не має поля type"
    return True, ""


def materialize(md: str, facts: dict, emit=None):
    """Замінює блок ```schemaorg у фіналі на валідний JSON-LD + чек-лист.
    Невалідний/порожній блок НЕ лишаємо сирим — ставимо чесну примітку.
    Якщо блоку немає — повертаємо md незмінним."""
    if not md or "schemaorg" not in md:
        return md
    m = _FENCE_RE.search(md)
    if not m:
        return md
    model = _parse(m.group(1))
    rendered, _ = build_jsonld(model, facts) if isinstance(model, dict) else (None, [])
    if not rendered:
        rendered = ("> ⚠ **schema.org-розмітку не сформовано:** модель порожня або "
                    "невалідна. Перезапустіть задачу або додайте реальні дані сторінки.")
    return md[:m.start()] + rendered + md[m.end():]
