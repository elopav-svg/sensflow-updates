# -*- coding: utf-8 -*-
"""
tender_qualify.py — КВАЛІФІКАТОР: СОРТУЄ, АЛЕ НІЧОГО НЕ ВИКИДАЄ.

ЧОМУ ЦЕЙ МОДУЛЬ ІСНУЄ (дисципліна 4 питань, Статут №15, 27.07.2026).

  КЛАС ПРОБЛЕМИ: слова профілю ловлять і товар клієнта, і сусідній ринок.
  «маскувальна сітка» дає 1043 закупівлі, і виробник сам позначив частину з них
  як чужі. Без сортування клієнт отримує сповіщення, у якому його товар лежить
  упереміш із капремонтом доріг — і перестає їх читати. Пропущений тендер
  коштує грошей один раз; втрачена довіра до сповіщень коштує щоразу.

  ТОЧКА РІШЕННЯ: між пошуком і складачем повідомлення. Не всередині сторожа
  (тоді звіт і кабінет сортуватимуть по-своєму) і не всередині складача (тоді
  судження змішається з фактами).

  ВСІ КАНАЛИ: Telegram-сповіщення, майбутні файл-звіт і кабінет, проба.

  ЧИ ПРОТЕЧЕ МАЙБУТНІЙ КАНАЛ: ні — будь-хто, кому потрібен порядок, бере його
  тут; іншого джерела порядку немає.

⭐⭐ ГОЛОВНЕ ПРАВИЛО: НІЧОГО НЕ ЗНИКАЄ.
  Вимірювання 27.07.2026 на 37 зразках виробника показало, що автоматично
  ВИКИДАТИ не можна в принципі: 33 пари назв виявились схожими за словами й
  протилежними за суттю («маскувальна сітка» = наше, «основа для маскувальної
  сітки» = НЕ наше; схожість 0.67). Будь-який поріг, що зрізав половину шуму,
  викидав і справжній товар клієнта.
  Тому вердикт тут — це ПОРЯДОК І ПОЗНАЧКА, а не видалення. Сума трьох списків
  завжди дорівнює входу; це стереже чек. Помилка кваліфікатора коштує уваги
  людини, а не втраченого тендера [[feedback_no_architectural_lying]].

🔴 FAIL-OPEN, А НЕ FAIL-CLOSED — і це свідомо інакше, ніж у вартового.
  Вартовий на виході мовчить, коли не впевнений: там ціна помилки — неправда
  клієнту. Тут ціна помилки — непоказаний тендер, тому невпевненість штовхає
  НАГОРУ, у «не знаю», а не вниз. Джерело судження недоступне -> усе стає
  «не знаю», complete=False, і це видно людині.

⚠ ВЕРДИКТ МОДЕЛІ — НЕ СУДЖЕННЯ ВИРОБНИКА.
  Модель лише впорядковує. У профіль її вердикт не потрапляє НІКОЛИ:
  зразком стає тільки те, що сказала людина [[feedback_producer_decides_product_fit]].
"""
import json
import re

OURS = "ours"
NOT_OURS = "not_ours"
UNSURE = "unsure"

# Скільки зразків кожного боку показуємо судді. Більше — дорожчий запит без
# помітної користі: зразки однотипні.
MAX_EXAMPLES = 25
MAX_TITLE = 160

_SYSTEM = (
    u"Ти сортувальник тендерних оголошень для конкретного виробника.\n"
    u"Тобі дано ПРИКЛАДИ, які сам виробник позначив як «наше» і «не наше».\n"
    u"Твоя робота — за назвою закупівлі сказати, чи це схоже на його товар.\n\n"
    u"ПРАВИЛА:\n"
    u"1. Ти НІЧОГО не викидаєш. Твій вердикт — це лише порядок показу.\n"
    u"2. Якщо сумніваєшся — кажи «unsure». Це нормальна відповідь, не поразка.\n"
    u"   Краще показати зайве, ніж сховати справжній тендер.\n"
    u"3. Судиш ЛИШЕ за схожістю з прикладами виробника. Власних уявлень про\n"
    u"   маскування не додавай.\n"
    u"4. «why» — максимум 8 слів, простою мовою, українською.\n\n"
    u"Відповідь — СУВОРО JSON: {\"items\":[{\"i\":<номер>,\"verdict\":\"ours|not_ours|unsure\","
    u"\"why\":\"...\"}]}"
)


def _short(t):
    t = u" ".join((t or u"").split())
    return t[:MAX_TITLE]


def _title_of(item):
    if isinstance(item, dict):
        return item.get("title") or item.get("name") or u""
    return item or u""


def build_prompt(items, ours, not_ours):
    """Текст запиту до судді. Винесено окремо, щоб чек міг його прочитати."""
    lines = [u"ПРИКЛАДИ ВИРОБНИКА — ЦЕ ЙОГО ТОВАР:"]
    lines += [u"  + %s" % _short(t) for t in ours[:MAX_EXAMPLES]] or [u"  (немає)"]
    lines.append(u"")
    lines.append(u"ПРИКЛАДИ ВИРОБНИКА — ЦЕ НЕ ЙОГО ТОВАР:")
    lines += [u"  - %s" % _short(t) for t in not_ours[:MAX_EXAMPLES]] or [u"  (немає)"]
    lines.append(u"")
    lines.append(u"ОЦІНИ ЦІ НАЗВИ:")
    for n, it in enumerate(items, 1):
        lines.append(u"  %d. %s" % (n, _short(_title_of(it))))
    return u"\n".join(lines)


def _model_judge(prompt):
    """Суддя за замовчуванням — дешевий воркер. Мережа лише через llm/netfetch."""
    import config
    import llm
    return llm.judge_json(_SYSTEM, prompt, temperature=0.0,
                          model=config.GEMINI_WORKER_MODEL,
                          purpose="кваліфікація тендера")


# ───────────────────────────────────────────────────────────────────────────
# ⚡ ШВИДКИЙ ШЛЯХ — те, що можна вирішити БЕЗ моделі, взагалі до неї не йде.
#
# Два джерела безкоштовної впевненості, обидва — судження ЛЮДИНИ, не моделі:
#   1. ТОЧНИЙ ЗБІГ зі зразком виробника. Якщо він уже сказав про цю саму назву
#      «наше» — його слово і є вердикт. Питати модель про те, на що вже
#      відповіла людина, — платити за гірший результат.
#   2. ОЗНАКА з профілю («чохол + антитепловізійний»). Ознака НІЧОГО не
#      звужує: не спрацювала — питаємо далі, а не відкидаємо.
# ───────────────────────────────────────────────────────────────────────────
def _words(text):
    return [w.lower() for w in re.findall(u"[\\w']+", text or u"", re.UNICODE)]


def _norm(text):
    """Ключ «це та сама назва»: без регістру, розділових, цифр і хвостів."""
    ws = [w for w in _words((text or u"").replace(u"…", u" "))
          if len(w) >= 3 and not any(c.isdigit() for c in w)]
    return u" ".join(sorted(ws))


def _sign_hits(title, sign):
    """Усі слова ознаки присутні в назві (за основою слова)?"""
    ws = _words(title)
    for need in (sign.get("words") or []):
        stem = need[:6]
        if not any(w.startswith(stem) or stem.startswith(w[:6]) and len(w) >= 4 for w in ws):
            return False
    return True


def fast_verdict(title, by_sample, signs_list):
    """-> (вердикт, чому, хто) або (None, None, None), якщо швидко не вирішується."""
    key = _norm(title)
    if key and key in by_sample:
        s = by_sample[key]
        return (s.get("verdict"), u"виробник уже казав про цю саму назву",
                s.get("decided_by") or u"людина (зразок)")
    for sg in (signs_list or []):
        if _sign_hits(title, sg):
            return (sg.get("verdict"), u"ознака: %s" % u" + ".join(sg.get("words") or []),
                    sg.get("decided_by") or u"людина (ознака)")
    return (None, None, None)


def sort(items, samples=None, judge=None, profile=None, signs=None):
    """Список знахідок -> три списки В ТОМУ Ж СКЛАДІ.

    items    — записи пошуку (dict з 'title'); порядок входу зберігається.
    samples  — зразки людини [{title, verdict}]; None -> беремо з профілю.
    judge    — функція(prompt)->dict; None -> дешева модель. Підміна потрібна
               чеку: він мусить перевіряти ПОВЕДІНКУ, не мережу.

    -> {"ours": [...], "unsure": [...], "not_ours": [...],
        "complete": bool, "why_incomplete": str|None, "judged_by": str,
        "counts": {...}}
    Кожен запис отримує поля verdict / why / verdict_by (вхід не мутуємо).
    """
    items = list(items or [])
    if samples is None:                      # явно передані зразки профіль не чіпають
        try:
            import tender_profile
            samples = tender_profile.samples(profile=profile)
        except Exception:
            samples = []
    ours = [s.get("title") for s in (samples or []) if s.get("verdict") == OURS]
    not_ours = [s.get("title") for s in (samples or []) if s.get("verdict") == NOT_OURS]

    def _all_unsure(why, by):
        out = [dict(it, verdict=UNSURE, why=why, verdict_by=by) if isinstance(it, dict)
               else {"title": it, "verdict": UNSURE, "why": why, "verdict_by": by}
               for it in items]
        return {"ours": [], "unsure": out, "not_ours": [],
                "complete": False, "why_incomplete": why, "judged_by": by,
                "counts": {OURS: 0, UNSURE: len(out), NOT_OURS: 0}}

    if not items:
        return {"ours": [], "unsure": [], "not_ours": [], "complete": True,
                "why_incomplete": None, "judged_by": u"—",
                "counts": {OURS: 0, UNSURE: 0, NOT_OURS: 0}}

    # 🔴 БЕЗ ЗРАЗКІВ ЛЮДИНИ НЕ СУДИМО. Інакше судитиме модель зі своїх уявлень —
    # рівно та помилка, що вже коштувала клієнту тендера.
    if not ours and not not_ours:
        return _all_unsure(u"немає зразків «наше/не наше» від виробника",
                           u"ніхто (немає на чому судити)")

    # ── ШВИДКИЙ ШЛЯХ: те, що вже вирішила ЛЮДИНА, до моделі не йде ──
    by_sample = {}
    for sm in (samples or []):
        k = _norm(sm.get("title"))
        if k:
            by_sample.setdefault(k, sm)
    # ⚠ Ознаки беремо з профілю ЛИШЕ якщо їх не передали явно. Інакше чек,
    # який передає власні зразки, мовчки тягнув би ще й бойові ознаки Каспера —
    # і перевіряв би не те, що думає, що перевіряє.
    if signs is None:
        try:
            import tender_profile
            signs_list = tender_profile.signs(profile=profile)
        except Exception:
            signs_list = []
    else:
        signs_list = signs

    groups = {OURS: [], UNSURE: [], NOT_OURS: []}
    to_judge, judge_pos = [], []
    for it in items:
        v, why, who = fast_verdict(_title_of(it), by_sample, signs_list)
        if v:
            rec = (dict(it) if isinstance(it, dict) else {"title": it})
            rec.update({"verdict": v, "why": why, "verdict_by": who})
            groups[v].append(rec)
        else:
            to_judge.append(it)
            judge_pos.append(it)
    fast_n = len(items) - len(to_judge)

    if not to_judge:
        return {"ours": groups[OURS], "unsure": groups[UNSURE], "not_ours": groups[NOT_OURS],
                "complete": True, "why_incomplete": None,
                "judged_by": u"людина (зразки й ознаки), без моделі",
                "fast": fast_n, "asked_model": 0,
                "counts": {k: len(v) for k, v in groups.items()}}

    items_for_model = to_judge
    prompt = build_prompt(items_for_model, ours, not_ours)
    try:
        raw = (judge or _model_judge)(prompt)
    except Exception as e:
        return _merge_unsure(groups, items_for_model, fast_n,
                             u"суддя недоступний: %s" % type(e).__name__)
    if not isinstance(raw, dict):
        return _merge_unsure(groups, items_for_model, fast_n,
                             u"суддя відповів не JSON")

    by_index = {}
    for r in (raw.get("items") or []):
        try:
            i = int(r.get("i"))
        except (TypeError, ValueError):
            continue
        v = str(r.get("verdict") or "").strip()
        if v not in (OURS, NOT_OURS, UNSURE):
            v = UNSURE
        by_index[i] = (v, u" ".join(str(r.get("why") or u"").split())[:80])

    who = u"модель (сортує) на зразках виробника"
    missed = 0
    for n, it in enumerate(items_for_model, 1):
        v, why = by_index.get(n, (UNSURE, u"суддя пропустив цю позицію"))
        if n not in by_index:
            missed += 1
        rec = (dict(it) if isinstance(it, dict) else {"title": it})
        rec.update({"verdict": v, "why": why, "verdict_by": who})
        groups[v].append(rec)

    complete = (missed == 0)
    return {"ours": groups[OURS], "unsure": groups[UNSURE], "not_ours": groups[NOT_OURS],
            "complete": complete,
            "why_incomplete": (u"суддя не оцінив %d позицій" % missed) if missed else None,
            "judged_by": (u"людина + %s" % who) if fast_n else who,
            "fast": fast_n, "asked_model": len(items_for_model),
            "counts": {k: len(v) for k, v in groups.items()}}


def _merge_unsure(groups, rest, fast_n, why):
    """Суддя підвів — але те, що вже вирішила ЛЮДИНА, лишається. Решта -> «не знаю»."""
    for it in rest:
        rec = (dict(it) if isinstance(it, dict) else {"title": it})
        rec.update({"verdict": UNSURE, "why": why, "verdict_by": u"—"})
        groups[UNSURE].append(rec)
    return {"ours": groups[OURS], "unsure": groups[UNSURE], "not_ours": groups[NOT_OURS],
            "complete": False, "why_incomplete": why,
            "judged_by": u"людина (зразки й ознаки); модель не відповіла",
            "fast": fast_n, "asked_model": len(rest),
            "counts": {k: len(v) for k, v in groups.items()}}


def order(result):
    """Порядок показу людині: своє -> не знаю -> чуже. Нічого не втрачено."""
    return list(result["ours"]) + list(result["unsure"]) + list(result["not_ours"])


def summary(result):
    """Рядок для людини: скільки чого. Звуження мусить бути ВИДИМИМ."""
    c = result["counts"]
    s = u"схоже на ваше — %d, не впевнений — %d, схоже на чуже — %d" % (
        c[OURS], c[UNSURE], c[NOT_OURS])
    if not result["complete"]:
        s += u" (⚠ %s)" % (result.get("why_incomplete") or u"сортування неповне")
    return s
