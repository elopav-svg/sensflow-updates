"""
inbound.py — інбаунд-сигнал (Фаза 4 дизайну Сервіс-центру).

Єдина точка обробки вхідних повідомлень від клієнтів: зіставляє відправника з
карткою CRM за каналом (Telegram chat_id/юзернейм або email) і піднімає на ній
позначку «потребує уваги», яка спалахує бейджем на канбані.

Використовується:
  • telegram_bot.py — у процесі, коли авторизований клієнт пише боту;
  • inbound_cli.py / ендпоінт /api/crm/inbound — ранкова автоперевірка пошти.

Якщо картки немає:
  • пошта (create_if_missing) → створюється картка «Новий клієнт» (це новий лід);
  • Telegram → вхідне лягає в чергу crm.inbox() (власник привʼяже/створить вручну).

Лише stdlib + crm. Нічого не надсилає назовні.
"""

import crm


def from_telegram(chat_id, username: str = "", name: str = "", text: str = "") -> dict:
    """Вхідне з Telegram. Повертає {matched, customer}."""
    cust = crm.find_by_telegram(chat_id)
    if not cust and username:
        cust = crm.find_by_telegram_user(username)
    if cust:
        crm.note_inbound(cust, "telegram", text)
        # Доприбʼємо chat_id, якщо картку знайшли лише за юзернеймом.
        if not str((crm.get_client(cust).get("channels") or {}).get("telegram_id") or "").strip():
            crm.link_telegram(cust, chat_id, username)
        return {"matched": True, "customer": cust}
    crm.record_unmatched("telegram", str(chat_id), name or username, text)
    return {"matched": False, "customer": ""}


def from_email(email: str, name: str = "", subject: str = "", preview: str = "",
               org: str = "", create_if_missing: bool = True) -> dict:
    """Вхідне з пошти. Повертає {matched, created, customer}."""
    email = (email or "").strip()
    cust = crm.find_by_email(email)
    if cust:
        crm.note_inbound(cust, "email", subject or preview)
        return {"matched": True, "created": False, "customer": cust}
    if create_if_missing and email:
        cname = (org or name or email).strip()
        # Уникаємо колізії імен: якщо така картка вже є з ІНШОЮ поштою — додаємо адресу.
        crm.ensure_client(cname, stage="Новий клієнт")
        prof = dict((crm.get_client(cname) or {}).get("profile") or {})
        if not (prof.get("email") or "").strip():
            prof["email"] = email
        if org and not (prof.get("org") or "").strip():
            prof["org"] = org
        crm.set_profile(cname, prof)
        crm.link_email(cname, email)
        crm.note_inbound(cname, "email", subject or preview)
        return {"matched": False, "created": True, "customer": cname}
    crm.record_unmatched("email", email, name, subject or preview)
    return {"matched": False, "created": False, "customer": ""}
