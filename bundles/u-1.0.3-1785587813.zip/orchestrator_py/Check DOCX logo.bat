@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Checking SensFlow DOCX logo (generates a test Word file on your Desktop)...
echo.
python "_check_docx_logo.py"
echo.
pause
