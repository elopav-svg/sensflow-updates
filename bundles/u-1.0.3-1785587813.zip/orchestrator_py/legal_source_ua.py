# -*- coding: utf-8 -*-
"""
legal_source_ua.py - ШАР 1: офіційне першоджерело норм права України.

Навіщо: юрист-звіряч раніше брав «чинну редакцію» норми із ЗАГАЛЬНОГО веб-пошуку
(агрегатори) -> низька релевантність і ризик подати неофіційне за факт. Тут -
прямий доступ до ОФІЦІЙНОЇ бази «Законодавство України» ВРУ:
    повний текст:  https://data.rada.gov.ua/laws/show/<nreg>.txt
Доступ БЕЗ реєстрації працює лише з User-Agent "OpenData" (перевірено наживо на
машині Андрія 13.07.2026: text/plain; charset=utf-8, ~1.3 МБ для КК). Формат
.json офіційно НЕ підтримується (сайт віддає редирект) - тому картку не тягнемо,
а назву/редакцію беремо з відомого реєстру + самого тексту.

Що робить lookup():
    1) визначає документ (nreg) із запиту - за назвою кодексу / посиланням / номером;
    2) визначає номер статті із запиту (якщо є);
    3) тягне офіційний текст і ВИТЯГАЄ САМЕ ПОТРІБНУ СТАТТЮ (а не початок кодексу);
    4) віддає блок «ОФІЦІЙНЕ ДЖЕРЕЛО ... текст статті ...» + пряме посилання.
Не знайшло документ/норму -> ok:False (викликач падає на звичайний веб-пошук).
"""

import re
import json
import urllib.request
import urllib.error

import netfetch  # спільний надійний читач (розпакування gzip/deflate/br)

API_BASE = "https://data.rada.gov.ua/laws/show"       # машинний доступ (.txt) з UA "OpenData"
PORTAL_BASE = "https://zakon.rada.gov.ua/laws/show"   # людське посилання для звірки
_UA = "OpenData"
_TIMEOUT = 30
_ARTICLE_BUDGET = 8000   # макс. символів тіла статті
_DOC_BUDGET = 12000      # макс. символів, якщо статтю не вказано

# Реєстраційні номери головних кодексів - ЗВІРЕНІ за адресами zakon.rada.
CODE_NREG = {
    "цивільний кодекс": "435-15",
    "цивільного кодексу": "435-15",
    "цк україни": "435-15",
    "цку": "435-15",
    "кримінальний кодекс": "2341-14",
    "кримінального кодексу": "2341-14",
    "кк україни": "2341-14",
    "кодекс законів про працю": "322-08",
    "кзпп": "322-08",
    "сімейний кодекс": "2947-14",
    "сімейного кодексу": "2947-14",
    "ск україни": "2947-14",
    # ⭐ 28.07.2026. Раніше тут жили ЛИШЕ кодекси — тому звіряч цитат на
    # «ст. 18 Закону про публічні закупівлі» писав «невідомий кодекс» і мовчки
    # пропускав неперевірену норму. Закони — теж першоджерело на rada.
    # Обидва номери взяті НЕ зі стелі: вони вже стоять у звіреній базі норм
    # knowledge_packs\tender_law\regimes.json і підтверджені живою звіркою.
    "про публічні закупівлі": "922-19",
    "922-viii": "922-19",
    "922-19": "922-19",
    "постанови кабінету міністрів україни 1275": "1275-2022-п",
    "постанова кабінету міністрів україни 1275": "1275-2022-п",
    "постанови кму 1275": "1275-2022-п",
    "постанови кму від 11 11 2022 1275": "1275-2022-п",
    "1275-2022-п": "1275-2022-п",
    # ⭐ 28.07.2026 (зміна 19). Три акти, без яких юрист мовчав на 94 % тендерів:
    # відкриті торги й пряма закупівля живуть за Особливостями 1178, електронний
    # каталог — за Порядком 822, оборонний звіт — за Законом 808-IX. Номер 808-20
    # НЕ виведений логікою: він узятий з посилання в тексті самої постанови 1275.
    "особливості 1178": "1178-2022-п",
    "особливостей 1178": "1178-2022-п",
    "особливостями 1178": "1178-2022-п",
    "постанова кму 1178": "1178-2022-п",
    "постанови кму 1178": "1178-2022-п",
    "1178-2022-п": "1178-2022-п",
    "електронного каталогу": "822-2020-п",
    "постанова кму 822": "822-2020-п",
    "постанови кму 822": "822-2020-п",
    "822-2020-п": "822-2020-п",
    "про оборонні закупівлі": "808-20",
    "808-ix": "808-20",
    "808-20": "808-20",
}

# Єдине ім'я реєстру для всіх модулів: тут не лише кодекси, а будь-які акти.
ACT_NREG = CODE_NREG

# Людські назви за реєстр. номером (бо .json-картку офіційно не віддає).
NREG_TITLE = {
    "435-15": "Цивільний кодекс України",
    "2341-14": "Кримінальний кодекс України",
    "322-08": "Кодекс законів про працю України",
    "2947-14": "Сімейний кодекс України",
    "922-19": "Закон України «Про публічні закупівлі» (922-VIII)",
    "1275-2022-п": "Постанова КМУ № 1275 від 11.11.2022",
    "1178-2022-п": "Особливості публічних закупівель на період воєнного стану "
                   "(постанова КМУ № 1178 від 12.10.2022)",
    "822-2020-п": "Порядок формування та використання електронного каталогу "
                  "(постанова КМУ № 822 від 14.09.2020)",
    "808-20": "Закон України «Про оборонні закупівлі» (808-IX)",
}

# ── ОДИН РЕЄСТР, А НЕ ДВА ────────────────────────────────────────────────────
# ⭐ 28.07.2026. Головний убивця цього проєкту — два писарі однієї правди. Акт міг
# стояти у звіреній базі норм і бути НЕВІДОМИМ ось цьому модулю; тоді юрист казав
# «невідомий кодекс» на власну ж норму. Тому база норм ДОЛИВАЄТЬСЯ сюди: додав
# режим у regimes.json — його акт автоматично став відомий усій системі.
_PACK_ACTS_MERGED = False


def merge_pack_acts():
    """Доливає акти зі звіреної бази норм у реєстр. Виконується один раз."""
    global _PACK_ACTS_MERGED
    if _PACK_ACTS_MERGED:
        return CODE_NREG
    _PACK_ACTS_MERGED = True
    try:
        import tender_legal
        pack = tender_legal.load_pack()
    except Exception:
        return CODE_NREG
    for entry in (pack.get("regimes") or {}).values():
        rows = list(entry.get("norms") or []) + list(entry.get("not_available") or [])
        for n in rows:
            nreg = (n.get("nreg") or "").strip()
            if not nreg:
                continue
            CODE_NREG.setdefault(nreg.lower(), nreg)
            act = (n.get("act") or "").strip()
            if act:
                CODE_NREG.setdefault(act.lower(), nreg)
                NREG_TITLE.setdefault(nreg, act)
    return CODE_NREG

_NREG_RE = re.compile(r"\b(\d{1,5}[а-яіїєґ]?-\d{1,3})\b", re.IGNORECASE)
_URL_NREG_RE = re.compile(r"zakon\.rada\.gov\.ua/laws/show/([0-9a-zA-Zа-яіїєґ\-]+)",
                          re.IGNORECASE)
# Номер статті із запиту: «стаття 118», «статті 117», «ст 118», «ст. 118».
_ARTICLE_RE = re.compile(r"(?:статт[іяювео]\w*|\bст\.?)\s*№?\s*(\d+)", re.IGNORECASE)
# Чинна редакція, якщо трапиться в тексті: «Редакція від 15.04.2026».
_REVISION_RE = re.compile(r"[Рр]едакці[яії]\s+від\s+(\d{2}\.\d{2}\.\d{4})")
# Заголовок статті в тексті: «Стаття 118» на початку рядка (не 118-1, не 1181).
_HEADING_RE = re.compile(r"(?m)^[ \t]*Стаття\s+(\d+)(?![\d\-])")
# Запасний (нестрогий) заголовок: «Стаття 118» будь-де в рядку — на випадок, коли
# офіційний .txt не тримає заголовки рівно на початку рядка (тоді строгий дає порожньо).
_HEADING_LOOSE_RE = re.compile(r"Стаття\s+(\d+)(?![\d\-])")


def _http_get(url):
    # Через спільний читач — ОДНАКОВО з рештою систем (без винятків): UA "OpenData"
    # (data.rada без нього віддає редирект) + розпакування у decode_response.
    return netfetch.get_text(url, ua=_UA, timeout=_TIMEOUT)


def resolve_nreg(task):
    """Реєстраційний номер документа із запиту: посилання -> назва кодексу -> явний nreg."""
    if not task:
        return None
    merge_pack_acts()
    t = task.lower()
    m = _URL_NREG_RE.search(task)
    if m:
        return m.group(1)
    for name, nreg in CODE_NREG.items():
        if name in t:
            return nreg
    m = _NREG_RE.search(task)
    if m:
        return m.group(1)
    return None


def resolve_article(task):
    """Номер статті із запиту або None."""
    if not task:
        return None
    m = _ARTICLE_RE.search(task)
    return m.group(1) if m else None


def _nreg_path(nreg):
    """Реєстраційний номер у безпечному для URL вигляді.

    ⚠ 28.07.2026: постанови КМУ мають у номері українську літеру —
    «1275-2022-п». Сирим текстом у шляху вона давала «текст не отримано»,
    і ми думали, що акта немає. Акт був — не вистачало кодування.
    Латинські номери (922-19) лишаються без змін.
    """
    from urllib.parse import quote
    return quote(str(nreg).strip(), safe="-_.")


def fetch_text(nreg):
    """Офіційний повний текст документа (TXT). '' при невдачі (не кидає)."""
    try:
        return _http_get(API_BASE + "/" + _nreg_path(nreg) + ".txt")
    except Exception:
        return ""


def fetch_card(nreg):
    """Офіційна .json-картка документа (працює з User-Agent "OpenData"). {} при невдачі.
    Ключове поле `datred` = дата чинної редакції (YYYYMMDD), звірено 13.07.2026."""
    try:
        data = json.loads(_http_get(API_BASE + "/" + _nreg_path(nreg) + ".json"))
    except Exception:
        return {}
    if isinstance(data, list):
        data = data[0] if data else {}
    return data if isinstance(data, dict) else {}


def _fmt_date(v):
    """20260415 -> 15.04.2026; інакше None (нічого не вигадуємо)."""
    s = str(v or "").strip()
    if re.match(r"^20\d{6}$", s):
        return s[6:8] + "." + s[4:6] + "." + s[0:4]
    return None


def _longest_segment(full_text, matches, art_num):
    """Найдовший сегмент від заголовка потрібного номера до наступного заголовка
    (найдовший — щоб не сплутати з коротким рядком «Змісту»)."""
    best = ""
    for i, m in enumerate(matches):
        if m.group(1) != str(art_num):
            continue
        start = m.start()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(full_text)
        seg = full_text[start:end].strip()
        if len(seg) > len(best):
            best = seg
    return best


def extract_article(full_text, art_num):
    """Тіло конкретної статті: від заголовка «Стаття N» до наступного заголовка.
    Спершу строгий заголовок (на початку рядка); якщо порожньо — запасний нестрогий
    (заголовок будь-де в рядку), щоб витягти статтю навіть із «злитого» офіційного .txt."""
    if not full_text or not art_num:
        return ""
    best = _longest_segment(full_text, list(_HEADING_RE.finditer(full_text)), art_num)
    if not best:
        best = _longest_segment(full_text, list(_HEADING_LOOSE_RE.finditer(full_text)), art_num)
    if len(best) > _ARTICLE_BUDGET:
        best = best[:_ARTICLE_BUDGET] + "\n...[стаття скорочена; повний текст - за офіційним посиланням]"
    return best


def lookup(task):
    """Головний вхід ШАРУ 1. ok:True з офіційним блоком, або ok:False (тоді викликач
    падає на звичайний веб-пошук)."""
    nreg = resolve_nreg(task)
    if not nreg:
        return {"ok": False,
                "note": "офіційне джерело: не вдалося визначити документ (норму) із запиту"}

    full = fetch_text(nreg)
    portal_url = PORTAL_BASE + "/" + nreg
    if not full:
        return {"ok": False,
                "note": "офіційне джерело недоступне для документа " + nreg + " (мережа / ліміт / формат)"}

    title = NREG_TITLE.get(nreg) or ("офіційний документ № " + nreg)
    card = fetch_card(nreg)
    revision = _fmt_date(card.get("datred")) if card else None
    if not revision:
        mrev = _REVISION_RE.search(full)
        revision = mrev.group(1) if mrev else None
    art = resolve_article(task)
    art_text = extract_article(full, art) if art else ""

    head = [
        "## ОФІЦІЙНЕ ДЖЕРЕЛО ПРАВА (data.rada.gov.ua - база «Законодавство України» ВРУ)",
        "Документ: " + title + " (реєстр. № " + nreg + ").",
    ]
    if revision:
        head.append("Чинна редакція: " + revision + ".")
    else:
        head.append("[!] Дату чинної редакції автоматично не підтверджено - звір за офіційним посиланням.")
    head.append("Це ЄДИНЕ джерело правди про норму. Будь-який інший опис її змісту / номера / "
                "редакції (з памʼяті чи агрегаторів) ІГНОРУЙ. Чого немає в цьому витягу - "
                "не стверджуй як факт.")
    head.append("Подавай це користувачу ЯК ОФІЦІЙНЕ ДЖЕРЕЛО (База «Законодавство України», ВРУ) "
                "з посиланням. НЕ називай це «веб-пошуком» і НЕ пиши, що сторінку не відкрито / "
                "повернуто бінарний файл (PDF/JS) - офіційний текст уже отримано тут.")
    head.append(
        "ЗАСТЕРЕЖЕННЯ ПРО СВІЖІСТЬ формулюй ЧЕСНО Й ТОЧНО так: «Текст підтверджено з "
        "офіційного джерела (База «Законодавство України», ВРУ)"
        + ((", чинна редакція " + revision) if revision else "")
        + "; можливі пізніші правки додатково не звірялися — перед використанням звір за "
        "офіційним посиланням.» КАТЕГОРИЧНО НЕ пиши «не було доступу до веб-пошуку» / "
        "«живий веб-пошук недоступний» / «пошук вимкнено»: це вводить користувача в оману, "
        "бо норму взято з ОФІЦІЙНОЇ бази напряму, а НЕ з веб-пошуку. Йдеться лише про те, що "
        "додаткову звірку пізніших правок не проводили, — саме так це й називай.")

    body = ""
    if art and art_text:
        body = "\n\n### Офіційний текст статті " + art + ":\n" + art_text
    elif art and not art_text:
        head.append("[!] Статтю " + art + " в офіційному тексті автоматично не виділив - "
                    "відкрий за посиланням і звір вручну.")
    else:
        snippet = full.strip()
        if len(snippet) > _DOC_BUDGET:
            snippet = snippet[:_DOC_BUDGET] + "\n...[документ великий; повний - за офіційним посиланням]"
        body = "\n\n### Офіційний текст (витяг):\n" + snippet

    block = "\n".join(head) + body + "\n\nОфіційне посилання для звірки: " + portal_url
    return {"ok": True, "block": block,
            "sources": [{"title": title + " (офіційне джерело)", "url": portal_url}],
            "revision": revision}


def lookup_user(task):
    """Те саме офіційне джерело, але у ЧИСТОМУ, ЛЮДСЬКОМУ вигляді — без внутрішніх
    інструкцій моделі (ІГНОРУЙ / подавай як... тощо). Для прямого показу користувачу,
    коли відповідь віддається В ОБХІД моделі (режим максимального збереження).
    Повертає {ok, md, sources, revision, article, extracted} або {ok:False, note}."""
    nreg = resolve_nreg(task)
    if not nreg:
        return {"ok": False, "note": "не вдалося визначити документ (норму) із запиту"}
    full = fetch_text(nreg)
    portal_url = PORTAL_BASE + "/" + nreg
    if not full:
        return {"ok": False, "note": "офіційне джерело недоступне для документа " + nreg +
                " (мережа / ліміт / формат)"}
    title = NREG_TITLE.get(nreg) or ("офіційний документ № " + nreg)
    card = fetch_card(nreg)
    revision = _fmt_date(card.get("datred")) if card else None
    if not revision:
        mrev = _REVISION_RE.search(full)
        revision = mrev.group(1) if mrev else None
    art = resolve_article(task)
    art_text = extract_article(full, art) if art else ""

    src_line = "Офіційне джерело: База «Законодавство України» (Верховна Рада України)"
    if revision:
        src_line += ", чинна редакція " + revision
    src_line += "."

    lines = [title + (" — стаття " + art if art else ""), src_line, ""]
    if art and art_text:
        lines.append(art_text)
    elif art and not art_text:
        lines.append("Статтю " + art + " не вдалося автоматично виділити з офіційного тексту "
                     "(можливо, її виключено або офіційний текст має нетипову структуру). "
                     "Повний чинний текст — за офіційним посиланням нижче.")
    else:
        snippet = full.strip()
        if len(snippet) > _DOC_BUDGET:
            snippet = snippet[:_DOC_BUDGET] + "\n…[документ великий; повний — за офіційним посиланням]"
        lines.append(snippet)
    lines.append("")
    lines.append("Офіційне посилання для звірки: " + portal_url)
    if revision:
        lines.append("Текст підтверджено з офіційного джерела; пізніші правки додатково не "
                     "звірялися — перед використанням звір за офіційним посиланням.")

    return {"ok": True, "md": "\n".join(lines),
            "sources": [{"title": title + " (офіційне джерело)", "url": portal_url}],
            "revision": revision, "article": art, "extracted": bool(art_text)}
