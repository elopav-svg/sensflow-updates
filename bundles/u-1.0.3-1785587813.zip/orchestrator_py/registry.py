"""
registry.py — читання реєстру систем і стану конекторів.

Повторно використовує ваш існуючий registry/systems.json (BOM-safe) і
config/connectors/*.token.json. Нічого не переписує без явного запиту.
"""

import json
from pathlib import Path

import config


# ---------------------------------------------------------------------------
# Системи
# ---------------------------------------------------------------------------
def _read_json_bom_safe(path: Path, fallback):
    if not path.exists():
        return fallback
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except Exception:
        return fallback


def load_registry() -> dict:
    """Повертає повний обʼєкт реєстру {schema_version, base_path, systems:[...]}."""
    data = _read_json_bom_safe(config.REGISTRY_JSON, {"systems": []})
    if isinstance(data, list):
        data = {"systems": data}
    data.setdefault("systems", [])
    return data


def load_systems() -> list:
    return load_registry().get("systems", [])


def find_system(system_id: str):
    for s in load_systems():
        if s.get("id") == system_id:
            return s
    return None


def system_root(system: dict) -> Path:
    """Абсолютний шлях до папки системи — стійкий і на платформі, і в клієнтській збірці.

    Розкладка платформи й зібраного пакета різна (у пакеті generated_systems лежить
    у корені, без префікса з назвою кореня). Тому резолвимо за списком
    кандидатів і повертаємо ПЕРШИЙ, що реально існує:
      1) буквальний root_path відносно WORKSPACE_ROOT (стара поведінка платформи);
      2) той самий root_path відносно PLATFORM_ROOT (клієнтська розкладка);
      3) хвіст generated_systems/<...> відносно PLATFORM_ROOT;
      4) generated_systems/<id> відносно PLATFORM_ROOT (запасний за id).
    Якщо нічого не існує — повертаємо перший осмислений варіант (не падаємо)."""
    rp = (system or {}).get("root_path", "")
    sid = (system or {}).get("id", "")
    candidates = []
    if rp:
        rpp = rp.replace("\\", "/")
        p = Path(rpp)
        if p.is_absolute():
            candidates.append(p)
        else:
            candidates.append((config.WORKSPACE_ROOT / rpp).resolve())
            candidates.append((config.PLATFORM_ROOT / rpp).resolve())
            tail = rpp.split("generated_systems/", 1)[-1]
            if tail and tail != rpp:
                candidates.append((config.PLATFORM_ROOT / "generated_systems" / tail).resolve())
    if sid:
        candidates.append((config.PLATFORM_ROOT / "generated_systems" / sid).resolve())
    for c in candidates:
        if c.exists():
            return c
    if candidates:
        return candidates[0]
    return config.WORKSPACE_ROOT


def compact_system_profile(system: dict) -> dict:
    """Стислий профіль для передачі в промпт оркестратора (без зайвого шуму)."""
    return {
        "id": system.get("id"),
        "name": system.get("name"),
        "category": system.get("category"),
        "status": system.get("status"),
        "description": system.get("description"),
        "orchestration_mode": system.get("orchestration_mode"),
        "agents": system.get("agents", []),
        "sensitive": bool(system.get("sensitive", False)),
        "triggers": system.get("triggers", [])[:12],
    }


def registry_snapshot_for_prompt() -> list:
    return [compact_system_profile(s) for s in load_systems()]


def save_registry(registry: dict):
    """Записує реєстр у UTF-8 БЕЗ BOM (виправляє кореневу причину mojibake)."""
    config.REGISTRY_JSON.parent.mkdir(parents=True, exist_ok=True)
    config.REGISTRY_JSON.write_text(
        json.dumps(registry, ensure_ascii=False, indent=2), encoding="utf-8"
    )


def add_system(entry: dict):
    """Додає нову систему в реєстр зі статусом needs_review (за контрактом білдера)."""
    reg = load_registry()
    systems = reg.get("systems", [])
    # уникнути дублю id
    existing_ids = {s.get("id") for s in systems}
    if entry.get("id") in existing_ids:
        # додати суфікс
        base = entry["id"]
        i = 2
        while f"{base}_{i}" in existing_ids:
            i += 1
        entry["id"] = f"{base}_{i}"
    systems.append(entry)
    reg["systems"] = systems
    save_registry(reg)
    return entry


def update_system_status(system_id: str, status: str) -> bool:
    reg = load_registry()
    changed = False
    for s in reg.get("systems", []):
        if s.get("id") == system_id:
            s["status"] = status
            changed = True
    if changed:
        save_registry(reg)
    return changed


# ---------------------------------------------------------------------------
# Джерело істини стану — у ПАПЦІ системи (.sf_state.json)
# ---------------------------------------------------------------------------
# Кореневий фікс оновлень (10.07.2026): реєстр — це похідний КЕШ, який
# оновлення затирає. Щоб статус і налаштування системи (особливо клієнтської)
# переживали наше оновлення, вони живуть у самій папці системи, яку оновлення
# не чіпає (generated_systems не входить у бандл). Реєстр перебудовується з
# папок + цього стану на кожному старті.
STATE_FILE = ".sf_state.json"

# Поля, які вважаємо «живим станом» системи (переживають оновлення).
_STATE_FIELDS = ("status", "triggers", "priority", "sensitive", "name", "roles")


def state_path(system: dict) -> Path:
    """Шлях до .sf_state.json у папці системи."""
    return system_root(system) / STATE_FILE


def read_folder_state(system: dict) -> dict:
    """Живий стан із папки системи. {} якщо файлу немає/не читається."""
    p = state_path(system)
    data = _read_json_bom_safe(p, {})
    return data if isinstance(data, dict) else {}


def write_folder_state(system: dict, patch: dict) -> bool:
    """Зливає patch у .sf_state.json папки системи (папка = джерело істини).
    Створює файл за потреби. Повертає True при успіху."""
    root = system_root(system)
    if not root.exists():
        return False
    state = read_folder_state(system)
    for k, v in (patch or {}).items():
        state[k] = v
    state["updated"] = _today()
    try:
        (root / STATE_FILE).write_text(
            json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False


def save_state_from_entry(system: dict) -> bool:
    """Зберігає у папку живі поля вже наявного запису реєстру (разова міграція
    для систем, у яких .sf_state.json ще немає — щоб вони теж пережили оновлення)."""
    patch = {k: system.get(k) for k in _STATE_FIELDS if system.get(k) is not None}
    return write_folder_state(system, patch)


def _today() -> str:
    try:
        from datetime import date
        return date.today().isoformat()
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# ПАСПОРТ ЗДАТНОСТЕЙ РОЛЕЙ (статичний шар контракту наміру, 10.07.2026)
# ---------------------------------------------------------------------------
# Кожна система декларує, ЩО ВМІЮТЬ її ролі (дослідник/рахувальник/критик) і які
# інструменти їм дозволені: calculator, web ("always"|"per_intent"), page_read.
# Інструмент вмикається лише на ПЕРЕТИНІ: роль вміє І контракт наміру (від мозку)
# вимагає. Паспорт живе в .sf_state.json папки системи (переживає оновлення),
# реєстр — кеш. Сіяч нижче — РАЗОВА міграція: колишні keyword-евристики executor
# виконують тут свою останню роботу й більше ніде не живуть.
_ROLE_CRITIC_KW = ("critic", "review", "quality", "критик", "рецензент", "контролер",
                   "verdict", "оцінк")
_ROLE_COMPUTE_KW = ("model", "modeler", "calc", "compute", "модел", "обчисл",
                    "рахун", "розрах")
_ROLE_RESEARCH_KW = ("research", "search", "find", "finder", "lookup", "locat",
                     "monitor", "scout", "intel", "data", "news", "market", "trend",
                     "analyst", "дослід", "пошук", "знайд", "розвід", "монітор",
                     "ринок", "новин", "джерел", "збір", "аналіт")
_ROLE_EDITOR_KW = ("style", "writ", "edit", "стиль", "редакт", "writer", "укладач")
_LEGAL_SYS_KW = ("legal", "юрист", "юридич", "прав")
_VERIFY_ROLE_KW = ("verif", "звір", "перевір", "checker")
BUILDER_ID = "system_builder"


def _kw(text: str, kws) -> bool:
    t = (text or "").lower()
    return any(k in t for k in kws)


def seed_roles(entry: dict, specs: dict = None) -> dict:
    """Сіяч паспорта ролей системи. Якщо переданий specs={aid:{kind,web}} —
    ЯВНА декларація Будівника (структурний агент) перекриває вгадування за
    назвою; евристика лишається ДРУГИМ рубежем, коли декларації нема.
    Будівник — БЕЗ інструментів (він робить системи, не контент).
    Одноагентні системи — універсал (calculator + web per_intent): воротами є
    контракт наміру від мозку, а не здогадки за словами."""
    sid = (entry or {}).get("id", "")
    blob = " ".join(str((entry or {}).get(k, "") or "")
                    for k in ("id", "category", "name")).lower()
    legal = _kw(blob, _LEGAL_SYS_KW)
    seo = ("seo" in blob or "geo" in blob)
    builder = (sid == BUILDER_ID)
    agents = (entry or {}).get("agents") or ["AgentMain"]
    specs = specs or {}
    _VALID_KINDS = ("research", "compute", "critic", "editor", "generalist")
    roles = {}
    for aid in agents:
        spec = specs.get(aid) if isinstance(specs.get(aid), dict) else {}
        decl_kind = str(spec.get("kind") or "").strip().lower()
        if decl_kind in _VALID_KINDS:
            kind = decl_kind          # явна декларація Будівника перекриває вгадування
        elif _kw(aid, _ROLE_CRITIC_KW):
            kind = "critic"
        elif _kw(aid, _ROLE_COMPUTE_KW):
            kind = "compute"
        elif _kw(aid, _ROLE_RESEARCH_KW):
            kind = "research"
        elif _kw(aid, _ROLE_EDITOR_KW):
            kind = "editor"
        else:
            kind = "generalist"
        tools = {}
        if not builder:
            if len(agents) == 1:
                tools = {"calculator": True, "web": "per_intent"}
            else:
                if kind == "compute":
                    tools["calculator"] = True
                if kind == "research":
                    tools["web"] = "per_intent"
                # Юр-звірка норм — інваріант: живе офіційне джерело ЗАВЖДИ,
                # незалежно від наміру задачі (колишній _force_legal_web).
                if legal and (kind == "research" or _kw(aid, _VERIFY_ROLE_KW)):
                    tools["web"] = "always"
            if seo:
                tools["page_read"] = True
                tools.setdefault("web", "per_intent")
                # SEO-розвідка конкурентів — інваріант (як юр-звірка норм):
                # головний продукт кроку (прогалини проти конкурентів, SERP) без
                # живого вебу неможливий, тож не лишаємо його на розсуд наміру.
                if kind == "research":
                    tools["web"] = "always"
            # ЯВНА декларація вебу від Будівника — ОСТАННЄ слово (явний контракт,
            # а не здогадка за назвою): always/per_intent вмикає, none вимикає.
            decl_web = str(spec.get("web") or "").strip().lower()
            if decl_web in ("always", "per_intent"):
                tools["web"] = decl_web
            elif decl_web in ("none", "off", "false", "no"):
                tools.pop("web", None)
        roles[aid] = {"kind": kind, "tools": tools}
    return roles


def get_roles(system: dict) -> dict:
    """Паспорт ролей системи: з реєстру-кешу → з папки → сіяч на льоту.
    Гарантує executor-у паспорт ЗАВЖДИ (навіть до міграції)."""
    r = (system or {}).get("roles")
    if isinstance(r, dict) and r:
        return r
    st = read_folder_state(system) if system else {}
    r = st.get("roles")
    if isinstance(r, dict) and r:
        return r
    return seed_roles(system or {})


# ---------------------------------------------------------------------------
# Конектори
# ---------------------------------------------------------------------------
# Базові сервіси платформи (за GLOBAL_ORCHESTRATOR_PROMPT) — завжди доступні логічно.
BASE_CONNECTORS = [
    {"id": "llm_runtime", "name": "LLM Runtime (мозок)", "type": "base"},
    {"id": "web_search", "name": "Веб-пошук", "type": "base"},
    {"id": "local_files", "name": "Локальні файли", "type": "base"},
    {"id": "spreadsheet_parser", "name": "Парсер таблиць CSV/XLSX/JSON", "type": "base"},
    {"id": "document_renderer", "name": "Рендер документів MD/HTML", "type": "base"},
    {"id": "artifact_store", "name": "Сховище артефактів", "type": "base"},
]

# Приватні конектори, які потребують окремої авторизації (OAuth-токени на диску).
PRIVATE_CONNECTORS = [
    {"id": "google_drive", "name": "Google Drive", "type": "private"},
    {"id": "github", "name": "GitHub", "type": "private"},
    {"id": "slack", "name": "Slack", "type": "private"},
    {"id": "telegram", "name": "Telegram", "type": "private"},
]


def _token_present(connector_id: str) -> bool:
    token_path = config.CONNECTORS_DIR / f"{connector_id}.token.json"
    if not token_path.exists():
        return False
    data = _read_json_bom_safe(token_path, {})
    return bool(data.get("access_token") or data.get("token"))


def connector_inventory() -> list:
    """Повний стан конекторів для UI. Не повертає самі токени."""
    inv = []
    # Базовий мозок залежить від наявності ключа LLM
    for c in BASE_CONNECTORS:
        status = "connected"
        if c["id"] == "llm_runtime":
            status = "connected" if config.provider_ready() else "not_configured"
        elif c["id"] == "web_search":
            status = "connected" if config.web_search_ready() else "not_configured"
        inv.append({**c, "status": status})
    for c in PRIVATE_CONNECTORS:
        inv.append({**c, "status": "connected" if _token_present(c["id"]) else "not_connected"})
    return inv
