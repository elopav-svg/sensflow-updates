# -*- coding: utf-8 -*-
"""
tender_profile.py — ПРОФІЛЬ ПРОДУКЦІЇ КЛІЄНТА (одні двері до «що ми продаємо»).

НАВІЩО (дисципліна 4 питань, Статут №15).
  КЛАС проблеми: асортимент клієнта змінюється, і кожна частина системи —
  сторож, розвідник, планувальник — потребує відповіді на те саме питання
  «за якими словами шукати». Якби кожна вирішувала сама, вони б розійшлися,
  і клієнт отримував би різні відповіді від різних частин платформи.
  ТОЧКА РІШЕННЯ: одне сховище, одні двері — queries().

⭐ ГОЛОВНА ГАРАНТІЯ — ЖОДНОГО ТИХОГО РОЗШИРЕННЯ.
  Небезпека не в самому додаванні товару, а в СЛОВАХ ПОШУКУ. «Пончо» саме по
  собі знайде мало: у Прозоро це «накидка маскувальна», «пончо термостійке».
  Якщо система тихо вигадає синоніми, сторож або пропустить тендери (і цього
  НІХТО не побачить), або заллє клієнта сміттям.
  Тому слово потрапляє в профіль ЛИШЕ якщо:
    1. його показали людині разом із ПРОБНИМ ПОШУКОМ — скільки оголошень воно
       знаходить прямо зараз (реальне число з джерела, не оцінка);
    2. людина його підтвердила.
  Незапробоване слово не зберігається — це fail-closed, як і скрізь у нас.
  Той самий принцип, що й `dropped` у відборі тендерів: усе видно очима.

ЧЕСНА МЕЖА: пробний пошук показує стан НА МОМЕНТ додавання. Він не обіцяє, що
слово ловитиме все й завжди — він лише не дає завести слово наосліп.

Лише stdlib. Мережі тут немає: пошук приходить ззовні (searcher), тож модуль
тестується офлайн і не обходить ворота виходу.
"""

import json
import re
from datetime import datetime
from pathlib import Path

# ⭐ 29.07.2026. ПИШЕМО у теку стану, ЧИТАЄМО — з готових пакетів рушія.
# Раніше було одне місце на обидва, і тимчасовий профіль чека
# (`_selfcheck_tmp_samples`) осідав у бойових `knowledge_packs` — а звідти
# поїхав клієнту в пакеті. Тепер під час чеків запис відводиться вбік
# (config.STATE_DIR), а справжні профілі й далі читаються там, де лежать:
# без цього накладення чеки втратили б доступ до реального `tender_casper`.
try:
    import config
    PACKS_DIR = config.STATE_DIR / "knowledge_packs"          # куди ПИШЕМО
    BUILTIN_PACKS_DIR = config.ENGINE_DIR / "knowledge_packs"  # звідки ЧИТАЄМО готове
except Exception:                                    # тест може йти без config
    PACKS_DIR = Path(__file__).resolve().parent / "knowledge_packs"
    BUILTIN_PACKS_DIR = PACKS_DIR

DEFAULT_PROFILE = "tender_casper"
_MIN_QUERY_LEN = 3


def _path(profile=None, for_write=False):
    """Шлях до профілю. Запис — завжди у теку стану. Читання — спершу стан,
    тоді готові пакети рушія (щоб чеки бачили справжній профіль клієнта)."""
    name = profile or DEFAULT_PROFILE
    p = PACKS_DIR / name / "products.json"
    if for_write or PACKS_DIR == BUILTIN_PACKS_DIR or p.exists():
        return p
    b = BUILTIN_PACKS_DIR / name / "products.json"
    return b if b.exists() else p


def _now():
    return datetime.now().strftime("%d.%m.%Y")


def load(profile=None):
    """Профіль із диска. Немає файлу — порожній профіль (це НЕ помилка)."""
    p = _path(profile)
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("profile", profile or DEFAULT_PROFILE)
    d.setdefault("products", [])
    return d


def _save(d, profile=None):
    p = _path(profile, for_write=True)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(p.name + ".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)


def products(profile=None):
    return load(profile).get("products", [])


def queries(profile=None):
    """ЄДИНЕ джерело слів пошуку для сторожа, розвідника й планувальника.
    Повертає лише ПІДТВЕРДЖЕНІ людиною слова — інших у файлі бути й не може."""
    out = []
    for p in products(profile):
        for q in (p.get("queries") or []):
            if q not in out:
                out.append(q)
    return out


def _clean(words):
    """Нормалізує список слів: обрізає, прибирає порожні й дублі, знімає
    надто короткі (пошук по «пе» дав би сміття)."""
    out = []
    for w in (words or []):
        w = re.sub(r"\s+", " ", str(w or "")).strip()
        if len(w) >= _MIN_QUERY_LEN and w.lower() not in {x.lower() for x in out}:
            out.append(w)
    return out


def probe(words, searcher, today=None):
    """ПРОБНИЙ ПОШУК: скільки оголошень кожне слово знаходить ПРЯМО ЗАРАЗ.

    searcher(word) -> число знайденого, або {'total': N}, або список записів.
    ⚠ Три форми свідомо: жива проба бере `total` з першої сторінки (286 знахідок),
    а не довжину списку (20 на сторінці). Записати в профіль 20 замість 286 —
    це тиха неправда про те, наскільки слово робоче.
    Помилка джерела не ховається: слово отримує found=None і статус 'error' —
    підтвердити його не можна, бо ми не знаємо, чи воно робоче.
    """
    out = []
    for w in _clean(words):
        try:
            found = searcher(w)
            if isinstance(found, dict):
                n, items = int(found.get("total") or 0), (found.get("items") or [])
            elif isinstance(found, (int, float)):
                n, items = int(found), []
            else:
                items = found or []
                n = len(items)
            sample = [r.get("title") for r in items[:3] if isinstance(r, dict)]
            out.append({"query": w, "found": n, "sample": sample,
                        "status": "ok" if n else "empty", "checked": today or _now()})
        except Exception as e:
            out.append({"query": w, "found": None, "sample": [],
                        "status": "error", "error": type(e).__name__, "checked": today or _now()})
    return out


def add_product(name, probes, confirmed_by, profile=None, note="",
                fit_decided_by=None, fit_from_producer=False):
    """Додає товар. -> (ok, повідомлення, картка|None).

    ⭐ ВОРОТА: пускаємо лише слова зі станом 'ok' у пробі (тобто реально щось
    знаходять) І лише за наявності підпису людини. Слово без проби, з помилкою
    джерела або з нулем знахідок у профіль НЕ потрапляє — мовчазне слово-пустушка
    гірше за його відсутність: воно створює ілюзію, що напрям прикрито.
    """
    name = re.sub(r"\s+", " ", str(name or "")).strip()
    if not name:
        return False, "Порожня назва товару.", None
    if not str(confirmed_by or "").strip():
        return False, "Немає підтвердження людини — слова пошуку не зберігаються.", None
    if not probes:
        return False, "Немає пробного пошуку — слова наосліп не зберігаються.", None
    # 🔴 ХТО ВИРІШИВ, ЩО ЦЕ ЇХНІЙ ТОВАР (додано 27.07.2026 після реальної втрати
    # тендера клієнтом). Проба показує, ЩО слово знаходить; вона не може сказати,
    # чи це товар клієнта. Це судження робить людина — і воно мусить бути
    # ІМЕННИМ. Саме безіменне судження (я вирішив за виробника, що «чохли до НРК»
    # — чужий товар) коштувало клієнту тендера.
    if not str(fit_decided_by or "").strip():
        return False, ("Не вказано, ХТО вирішив, що це товар клієнта. "
                       "Придатність товару — не здогад платформи."), None

    good = [p["query"] for p in probes if p.get("status") == "ok"]
    # ⚠ Відхилення теж мусить бути ВИДИМИМ. Слово можуть відкинути дві сили:
    # джерело (нуль знахідок, помилка) і ЛЮДИНА (слово надто широке, тягне чужий
    # товар). Друге небезпечніше, бо не лишає сліду в числах — тому причина
    # людини пишеться в картку поруч із рештою, а не губиться в розмові.
    rejected = [{"query": p.get("query"), "why": p.get("why") or p.get("status"),
                 "found": p.get("found")} for p in probes if p.get("status") != "ok"]
    if not good:
        return False, ("Жодне слово нічого не знайшло — товар не додано. "
                       "Спробуйте інші формулювання (як пишуть у самих оголошеннях)."), None

    d = load(profile)
    card = {
        "name": name,
        "queries": good,
        "rejected": rejected,          # видимо: що НЕ взяли і чому
        "probe": [{"query": p.get("query"), "found": p.get("found"),
                   "status": p.get("status")} for p in probes],
        "confirmed_by": str(confirmed_by).strip(),
        "fit_decided_by": str(fit_decided_by).strip(),
        "fit_from_producer": bool(fit_from_producer),
        "added": _now(),
        "note": str(note or "").strip(),
    }
    d["products"] = [p for p in d.get("products", [])
                     if (p.get("name") or "").lower() != name.lower()] + [card]
    _save(d, profile)
    return True, "Додано «%s»: слів пошуку %d, відхилено %d." % (name, len(good), len(rejected)), card


# ───────────────────────────────────────────────────────────────────────────
# ⭐ ЗРАЗКИ «НАШЕ / НЕ НАШЕ» — розмітка ВИРОБНИКА на живих назвах (27.07.2026)
#
# ЧОМУ ЦЕ ТУТ (дисципліна 4 питань, Статут №15):
#   КЛАС: судження виробника про КОНКРЕТНІ позиції ніде не зберігалось. Ми
#   зберігали лише слова пошуку — тобто підсумок судження, а не саме судження.
#   Коли Подервінскас розмітив 20 живих назв на «наше / не наше», це знання
#   жило рівно в одному docx у теці й зникло б разом із ним.
#   ТОЧКА РІШЕННЯ: профіль продукції — єдине місце, де живе знання про те, що
#   є товаром клієнта. Класти зразки в окремий файл поруч = створити другу
#   правду, яка розійдеться з першою.
#   ВСІ КАНАЛИ: Кваліфікатор (відсів шуму), проба слів, опис профілю.
#   МАЙБУТНІЙ КАНАЛ: бере зразки звідси, іншого джерела немає.
#
# 🔴 FAIL-CLOSED, як і з товаром: зразок без ІМЕНІ того, хто виніс вердикт,
# у профіль не потрапляє. Знеособлений зразок — це моя думка, видана за думку
# виробника, а саме це вже коштувало клієнту тендера.
# ───────────────────────────────────────────────────────────────────────────
OURS = "ours"
NOT_OURS = "not_ours"
_VERDICTS = (OURS, NOT_OURS)


def add_samples(items, decided_by, source="", profile=None, query=None):
    """Додає зразки. items — [{title, verdict, tenderID?}]. -> (ok, повідомлення, скільки).

    Дублі за (назва, вердикт) не множаться. Суперечність (та сама назва з
    протилежним вердиктом) НЕ вирішується мовчки: повертаємо помилку, бо
    тихий вибір одного з двох суджень людини — це і є вигадування за неї.
    """
    who = str(decided_by or "").strip()
    if not who:
        return False, ("Не вказано, ХТО виніс вердикт. Зразок без імені — "
                       "це здогад платформи, а не судження людини."), 0
    clean = []
    for it in (items or []):
        title = re.sub(r"\s+", " ", str((it or {}).get("title") or "")).strip()
        verdict = str((it or {}).get("verdict") or "").strip()
        if not title:
            continue
        if verdict not in _VERDICTS:
            return False, "Невідомий вердикт «%s» для «%s»." % (verdict, title[:40]), 0
        clean.append({"title": title, "verdict": verdict,
                      "tenderID": str((it or {}).get("tenderID") or "").strip(),
                      "query": str(query or (it or {}).get("query") or "").strip(),
                      "decided_by": who, "source": str(source or "").strip(),
                      "added": _now()})
    if not clean:
        return False, "Немає жодного зразка з назвою.", 0

    d = load(profile)
    have = d.get("samples") or []
    by_title = {}
    for old in have:
        by_title.setdefault(old.get("title"), set()).add(old.get("verdict"))
    added = 0
    for c in clean:
        seen = by_title.get(c["title"], set())
        if c["verdict"] in seen:
            continue
        if seen:
            return False, ("Суперечність: «%s» уже позначено як %s, а тепер %s. "
                           "Розв'язати має людина, не код."
                           % (c["title"][:40], ", ".join(sorted(seen)), c["verdict"])), 0
        have.append(c)
        by_title.setdefault(c["title"], set()).add(c["verdict"])
        added += 1
    d["samples"] = have
    _save(d, profile)
    return True, "Зразків додано: %d (усього %d)." % (added, len(have)), added


# ───────────────────────────────────────────────────────────────────────────
# ⚡ ОЗНАКИ — «якщо в назві є ЦІ слова разом, то це точно наше»
#
# ЧОМУ ОКРЕМО ВІД СЛІВ ПОШУКУ (Статут №15, 27.07.2026, ідея Андрія).
#   Слово пошуку і ознака — РІЗНІ речі, і плутати їх дорого.
#   Вимірювання на 17 позиціях виробника: пара «чохол + антитепловізійний»
#   зрізає 20 шумів із 20, але знаходить лише 1 із 17 його позицій — і серед
#   утрачених «Чохол маскувальний для НРК», тобто той самий тендер, у якому
#   Каспер програв. Причина: «антитепловізійний» пишуть ВИРОБНИКИ, а замовники
#   пишуть «маскувальний». З 17 позицій це слово є лише в 6.
#   ➜ Як слово ПОШУКУ пара сліпа. Як ОЗНАКА впевненості — точна.
#   Тому ознака нічого не звужує: вона лише каже «це напевно ваше» і economить
#   виклик моделі. Не знайшлась — рішення ухвалює хтось інший, а не «не наше».
# ───────────────────────────────────────────────────────────────────────────
def add_sign(words, verdict, decided_by, profile=None, note=""):
    """Ознака = набір слів, які мусять бути в назві РАЗОМ. -> (ok, повідомлення).

    Fail-closed так само, як усюди: без імені того, хто вирішив, не пишеться.
    """
    who = str(decided_by or "").strip()
    if not who:
        return False, "Не вказано, ХТО вирішив. Ознака без імені не зберігається."
    if verdict not in _VERDICTS:
        return False, "Невідомий вердикт «%s»." % verdict
    ws = [re.sub(r"\s+", " ", str(w or "")).strip().lower() for w in (words or [])]
    ws = [w for w in ws if len(w) >= 3]
    if len(ws) < 2:
        return False, ("Ознака з одного слова — це слово пошуку, а не ознака. "
                       "Потрібно щонайменше два слова разом.")
    d = load(profile)
    have = d.get("signs") or []
    key = tuple(sorted(ws))
    if any(tuple(sorted(x.get("words") or [])) == key for x in have):
        return True, "Така ознака вже є."
    have.append({"words": ws, "verdict": verdict, "decided_by": who,
                 "note": str(note or "").strip(), "added": _now()})
    d["signs"] = have
    _save(d, profile)
    return True, "Ознаку додано: %s -> %s." % (" + ".join(ws), verdict)


# ───────────────────────────────────────────────────────────────────────────
# 👁 НАШІ ТЕНДЕРИ — ті, куди клієнт УЖЕ подався
#
# ЧОМУ ЦЕ ОКРЕМИЙ СПИСОК (Статут №15, 27.07.2026).
#   Сторож дивиться лише на НОВІ оголошення. За долею вже поданих пропозицій
#   не стежив НІХТО — Каспер міг дізнатися про рішення по своєму тендеру
#   випадково. Це і є робота Захисника, і йому потрібен вхід: за чим стежимо.
#   Шукати наш ЄДРПОУ по всьому Прозоро — це обхід мільйонів карток заради
#   кількох; список ведеться руками, поки клієнт не дасть свій перелік.
# ───────────────────────────────────────────────────────────────────────────
def add_watch(tender_id, added_by, why="", uuid="", profile=None):
    """Взяти тендер під нагляд Захисника. -> (ok, повідомлення)."""
    tid = re.sub(r"\s+", "", str(tender_id or "")).upper()
    if not tid:
        return False, "Порожній номер тендера."
    who = str(added_by or "").strip()
    if not who:
        return False, "Не вказано, ХТО додав тендер під нагляд."
    d = load(profile)
    have = d.get("watched") or []
    if any((w.get("tender_id") or "").upper() == tid for w in have):
        return True, "Тендер %s уже під наглядом." % tid
    have.append({"tender_id": tid, "uuid": str(uuid or "").strip(),
                 "why": str(why or "").strip(), "added_by": who, "added": _now()})
    d["watched"] = have
    _save(d, profile)
    return True, "Під нагляд узято: %s." % tid


def watched(profile=None):
    return load(profile).get("watched") or []


def signs(profile=None):
    return load(profile).get("signs") or []


def samples(verdict=None, profile=None):
    """Зразки з профілю. verdict=None — усі."""
    out = (load(profile).get("samples") or [])
    if verdict is None:
        return out
    return [s for s in out if s.get("verdict") == verdict]


def samples_stats(profile=None):
    """-> {ours, not_ours, decided_by: [імена]}"""
    ss = samples(profile=profile)
    return {"ours": len([s for s in ss if s.get("verdict") == OURS]),
            "not_ours": len([s for s in ss if s.get("verdict") == NOT_OURS]),
            "decided_by": sorted({s.get("decided_by") for s in ss if s.get("decided_by")})}


def remove_product(name, profile=None):
    d = load(profile)
    before = len(d.get("products", []))
    d["products"] = [p for p in d.get("products", [])
                     if (p.get("name") or "").lower() != str(name or "").lower()]
    _save(d, profile)
    return before != len(d["products"])


def describe(profile=None):
    """Людський опис профілю — що система шукає від імені клієнта."""
    d = load(profile)
    ps = d.get("products", [])
    if not ps:
        return "Профіль продукції порожній: система поки не знає, що шукати."
    lines = ["Профіль продукції «%s» — %d товар(ів):" % (d.get("profile"), len(ps))]
    for p in ps:
        lines.append("— %s: шукаємо за %s (додано %s, підтвердив: %s)"
                     % (p.get("name"), ", ".join("«%s»" % q for q in p.get("queries") or []),
                        p.get("added"), p.get("confirmed_by")))
        if p.get("fit_from_producer"):
            lines.append("   придатність підтвердив ВИРОБНИК: %s" % p.get("fit_decided_by"))
        else:
            lines.append("   ⚠ ПРИПУЩЕННЯ: придатність вирішив не виробник (%s) — "
                         "може ловити чужий товар або пропускати свій"
                         % (p.get("fit_decided_by") or "невідомо хто"))
        if p.get("rejected"):
            lines.append("   не взяли: " + ", ".join("«%s» (%s)" % (r.get("query"), r.get("why"))
                                                     for r in p["rejected"]))
    st = samples_stats(profile)
    if st["ours"] or st["not_ours"]:
        lines.append("Зразки від людини: наше — %d, не наше — %d (вирішили: %s)."
                     % (st["ours"], st["not_ours"], "; ".join(st["decided_by"]) or "?"))
    else:
        lines.append("⚠ Зразків «наше/не наше» немає — відсівати шум нема на чому.")
    return "\n".join(lines)


# ───────────────────────────────────────────────────────────────────────────
# ⚠ ПРИПУЩЕННЯ ПРО ТОВАР — мають бути ВИДИМИМИ, як і все інше в нас.
#
# Проба з Прозоро доводить, що слово ЩОСЬ знаходить. Вона не доводить, що
# знайдене — товар КЛІЄНТА. Це судження робить людина, і поки його зробив не
# виробник, картка лишається припущенням. Тихе припущення небезпечніше за
# відсутність слова: воно створює відчуття, що напрям прикрито.
# ───────────────────────────────────────────────────────────────────────────
def assumptions(profile=None):
    """Картки, придатність яких вирішив НЕ виробник. -> [{name, who}]"""
    out = []
    for p in products(profile):
        if not p.get("fit_from_producer"):
            out.append({"name": p.get("name"),
                        "who": p.get("fit_decided_by") or "невідомо хто"})
    return out


def unknown_origin(profile=None):
    """Картки, де взагалі не записано, хто судив про придатність. -> [name]"""
    return [p.get("name") for p in products(profile)
            if not str(p.get("fit_decided_by") or "").strip()]
