# -*- coding: utf-8 -*-
"""
tender_materials.py — ДОРОГА КЛІЄНТА ДО БАЗИ ЗНАНЬ ПРО ТОВАР.

ЗАМОВЛЕННЯ КЛІЄНТА, пункт 5: «шлях наповнення бази знань матеріалами про
товар». Досі механізм існував лише всередині (products.json), а дороги для
людини не було: клієнт не знав, куди класти ТУ, сертифікати, фото й описи.

ЯК ЦЕ ПРАЦЮЄ (одна папка, жодних форм):
    knowledge_packs\\tender_casper\\Матеріали про товар\\
Клієнт кладе туди файли. Скрипт складає опис того, що є, і — головне —
чесно каже, ЧОГО БРАКУЄ для тендерного пакета.

ЧОМУ ВАЖЛИВО, ЩО ВІН КАЖЕ ПРО ДІРКИ. Пакет на участь у тендері збирається
з документів учасника. Якщо система мовчки працює на половині матеріалів,
клієнт дізнається про брак на подачі — коли пізно. Тому «чого немає» тут
такий самий результат, як «що є».
"""
import io
import json
import os
import datetime

PACK_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                        "knowledge_packs", "tender_casper")
MATERIALS_DIR = os.path.join(PACK_DIR, "Матеріали про товар")
INDEX_FILE = os.path.join(PACK_DIR, "materials_index.json")

# Що потрібно для тендерного пакета. Ключ -> слова, за якими впізнаємо файл.
WANTED = [
    ("Технічні умови (ТУ) або технічний опис", ("ту", "техн", "тз", "специф")),
    ("Сертифікати / висновки / протоколи випробувань", ("сертиф", "висновок", "протокол", "випроб")),
    ("Фото товару", ("фото", "photo", "img", "jpg", "jpeg", "png")),
    ("Опис товару для замовника (текстом)", ("опис", "презент", "каталог", "буклет")),
    ("Раніше подані тендерні пропозиції (зразки)", ("пропозиц", "форма", "додаток", "тендер")),
]

SKIP = (".tmp", ".part", "~$", "desktop.ini", "thumbs.db")


def _looks_like(name, words):
    low = name.lower()
    return any(w in low for w in words)


def scan(folder=None):
    """Що лежить у папці матеріалів. Папки немає -> це не помилка, а «порожньо»."""
    folder = folder or MATERIALS_DIR
    files = []
    if os.path.isdir(folder):
        for root, _dirs, names in os.walk(folder):
            for name in sorted(names):
                if name.lower().startswith("~$") or name.lower().endswith(SKIP):
                    continue
                path = os.path.join(root, name)
                try:
                    size = os.path.getsize(path)
                    mtime = os.path.getmtime(path)
                except OSError:
                    continue
                files.append({
                    "name": name,
                    "rel": os.path.relpath(path, folder),
                    "bytes": size,
                    "added": datetime.datetime.fromtimestamp(mtime).strftime("%d.%m.%Y"),
                })
    return files


def gaps(files):
    """Чого бракує. Повертає список позицій, яким не знайшлось жодного файла."""
    missing = []
    for label, words in WANTED:
        if not any(_looks_like(f["name"], words) for f in files):
            missing.append(label)
    return missing


def build_index(folder=None, out_path=None):
    files = scan(folder)
    data = {
        "updated": datetime.datetime.now().strftime("%d.%m.%Y %H:%M"),
        "folder": folder or MATERIALS_DIR,
        "files": files,
        "have": [label for label, words in WANTED
                 if any(_looks_like(f["name"], words) for f in files)],
        "missing": gaps(files),
    }
    out_path = out_path or INDEX_FILE
    with io.open(out_path, "w", encoding="utf-8") as fh:
        fh.write(json.dumps(data, ensure_ascii=False, indent=2))
    return data


def report(data):
    lines = []
    lines.append("МАТЕРІАЛИ ПРО ТОВАР — що система бачить")
    lines.append("Папка: %s" % data["folder"])
    lines.append("Файлів: %d" % len(data["files"]))
    lines.append("")
    for f in data["files"][:40]:
        lines.append("  + %-45s %8d Б  (додано %s)" % (f["rel"][:45], f["bytes"], f["added"]))
    if len(data["files"]) > 40:
        lines.append("  ... і ще %d" % (len(data["files"]) - 40))
    lines.append("")
    if data["have"]:
        lines.append("Є:")
        for h in data["have"]:
            lines.append("  OK   %s" % h)
    if data["missing"]:
        lines.append("")
        lines.append("БРАКУЄ для тендерного пакета:")
        for m in data["missing"]:
            lines.append("  ---  %s" % m)
        lines.append("")
        lines.append("Це не помилка. Це список того, що варто попросити у виробника.")
    else:
        lines.append("")
        lines.append("Усе, що потрібно для пакета, у папці є.")
    return "\n".join(lines)


if __name__ == "__main__":
    import run_log
    run_log.start("tender_materials")
    if not os.path.isdir(MATERIALS_DIR):
        os.makedirs(MATERIALS_DIR)
        print("Створено папку для матеріалів:")
        print("  %s" % MATERIALS_DIR)
        print("")
    data = build_index()
    print(report(data))
