@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Checking SensFlow HTML branding (generates report + dashboard on your Desktop)...
echo.
python "_check_html_logo.py"
echo.
pause
