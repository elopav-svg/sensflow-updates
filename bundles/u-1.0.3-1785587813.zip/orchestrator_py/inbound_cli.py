"""
inbound_cli.py — командний рядок для ранкової автоперевірки пошти (Фаза 4).

Викликається із задачі за розкладом: вона читає Gmail і для кожного реального
листа клієнта/ліда запускає цей CLI. Той зіставляє адресу з карткою CRM і
піднімає позначку «потребує уваги» (або створює «Новий клієнт» для нового ліда).

Запускати з теки orchestrator_py (щоб config знайшов корінь платформи):
  python inbound_cli.py --email ivan@firma.ua --name "Іван" --org "Фірма" \
      --subject "Заявка SensFlow" --preview "Хочемо демо"

Вивід — рядок JSON: {"matched":..., "created":..., "customer":...}.
Прапорець --no-create вимикає створення нової картки (лише підняти наявну).
"""

import argparse
import json
import sys

import inbound


def main() -> int:
    p = argparse.ArgumentParser(description="Інбаунд-сигнал з пошти у CRM")
    p.add_argument("--channel", default="email", choices=["email", "telegram"])
    p.add_argument("--email", default="")
    p.add_argument("--name", default="")
    p.add_argument("--org", default="")
    p.add_argument("--subject", default="")
    p.add_argument("--preview", default="")
    p.add_argument("--chat-id", default="")
    p.add_argument("--username", default="")
    p.add_argument("--no-create", action="store_true",
                   help="не створювати картку, якщо клієнта не знайдено")
    a = p.parse_args()

    if a.channel == "telegram":
        res = inbound.from_telegram(a.chat_id, username=a.username, name=a.name, text=a.preview)
    else:
        if not a.email.strip():
            print(json.dumps({"error": "no_email"}, ensure_ascii=False))
            return 2
        res = inbound.from_email(a.email, name=a.name, subject=a.subject,
                                 preview=a.preview, org=a.org,
                                 create_if_missing=not a.no_create)
    print(json.dumps(res, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
