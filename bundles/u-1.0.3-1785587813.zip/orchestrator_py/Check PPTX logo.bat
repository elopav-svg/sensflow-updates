@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo Checking SensFlow PPTX branding (generates a test deck on your Desktop)...
echo.
python "_check_pptx_logo.py"
echo.
pause
