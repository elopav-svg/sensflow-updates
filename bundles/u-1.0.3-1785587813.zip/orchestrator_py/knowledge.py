"""
knowledge.py — семантична база знань систем (тека `Knowledge/` у корені системи).

Дозволяє «навчати» систему: додавати іменовані фрагменти знань (фреймворки,
методології, довідки) розмовою через оркестратор, а під час запуску —
підмішувати РЕЛЕВАНТНІ фрагменти в контекст агентів.

Пошук — СЕМАНТИЧНИЙ (ембединги + косинусна близькість), із запасним
keyword-варіантом, якщо ембединги недоступні. Кожен запис позначається
джерелом і датою (для чесності й аудиту).

Вектори зберігаються у `Knowledge/_index.json`. Без важких бібліотек —
ембединги беруться через дешевий API (OpenAI/Gemini), косинус — на чистому Python.
"""

import json
import re
from datetime import datetime

import config
import llm
import registry
import store


# ⭐⭐⭐ 30.07.2026. ДЕ ЛЕЖИТЬ БАЗА ЗНАНЬ СИСТЕМИ — РІШЕННЯ ОДНОГО РЕЗОЛВЕРА.
# Живий випадок: «Юрист-асистент» тримає свою звірену базу норм у `Database/Wiki`,
# а платформа шукала виключно теку `Knowledge`, якої в цій системі немає. Тому
# агент, чий промпт прямо каже «твоє джерело — Database/Wiki», НІКОЛИ його не
# бачив — і за власним правилом мусив мовчати про строки. Ніхто цього не помічав,
# бо порожня база виглядає точно як база без потрібного фрагмента.
# Перелік імен — ОДИН, у порядку переваги; хто додасть третє ім'я, додасть його тут.
KDIR_NAMES = ("Knowledge", "Database")


# ⭐⭐⭐ 30.07.2026. ЧИТАЄМО РЕКУРСИВНО. Було `glob("*.md")` — лише верхній рівень.
# У «Юриста» вся база лежить у `Database/Wiki` і `Database/Templates`: 69 файлів у
# підтеках і РІВНО ОДИН зверху. Тобто агент, чий промпт прямо посилається на
# `Database/Wiki/ТЕНДЕРНІ_НОРМИ_звірені.md`, бачив 1 файл із 69 — і за власним
# правилом мусив мовчати про строки. Виправлення назви теки (KDIR_NAMES) полагодило
# ПОВЕРХ, а глибину — ні. База знань, прочитана на один файл, гірша за відсутню:
# вона виглядає як наявна.
def _kdir(system: dict):
    root = registry.system_root(system)
    for name in KDIR_NAMES:
        d = root / name
        try:
            if d.exists():
                return d
        except Exception:
            continue
    return root / KDIR_NAMES[0]


def _index_path(system: dict):
    return _kdir(system) / "_index.json"


def _load_index(system: dict) -> list:
    p = _index_path(system)
    if not p.exists():
        return []
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return []


def _save_index(system: dict, entries: list):
    _index_path(system).write_text(json.dumps(entries, ensure_ascii=False), encoding="utf-8")


def _chunk(text: str, target: int = 900) -> list:
    """Ділить текст на змістові шматки ~target символів по межах абзаців."""
    paras = [p.strip() for p in re.split(r"\n\s*\n", text or "") if p.strip()]
    chunks, cur = [], ""
    for p in paras:
        if not cur:
            cur = p
        elif len(cur) + len(p) + 2 <= target:
            cur = cur + "\n\n" + p
        else:
            chunks.append(cur)
            cur = p
        while len(cur) > target * 1.8:  # розрізати дуже довгий абзац
            chunks.append(cur[:target])
            cur = cur[target:]
    if cur.strip():
        chunks.append(cur)
    return chunks or ([text] if (text or "").strip() else [])


def _cosine(a, b) -> float:
    if not a or not b:
        return 0.0
    s = da = db = 0.0
    for x, y in zip(a, b):
        s += x * y; da += x * x; db += y * y
    if da == 0 or db == 0:
        return 0.0
    return s / ((da ** 0.5) * (db ** 0.5))


def add(system: dict, title: str, content: str, source: str = "") -> dict:
    """Додає запис у базу знань: пише .md, чанкує й ембедить для семантичного пошуку."""
    d = _kdir(system)
    d.mkdir(parents=True, exist_ok=True)
    slug = store.slugify(title or "", 40) or datetime.now().strftime("entry-%H%M%S")
    path = d / f"{slug}.md"
    i = 2
    while path.exists():
        path = d / f"{slug}-{i}.md"
        i += 1
    header = (f"# {title}\n\n> Джерело: {source or 'не вказано'} · "
              f"додано {datetime.now().strftime('%Y-%m-%d')}\n\n")
    path.write_text(header + (content or ""), encoding="utf-8")

    chunks = _chunk(content or "")
    embedded = False
    if config.embeddings_ready() and chunks:
        try:
            vecs = llm.embed([f"{title}\n{c}" for c in chunks])
            entries = _load_index(system)
            for idx, (c, v) in enumerate(zip(chunks, vecs)):
                entries.append({"file": path.name, "idx": idx, "title": title, "text": c, "vec": v})
            _save_index(system, entries)
            embedded = True
        except Exception:
            pass  # лишається keyword-пошук
    return {"title": title, "file": path.name, "chars": len(content or ""),
            "chunks": len(chunks), "embedded": embedded}


def list_entries(system: dict) -> list:
    d = _kdir(system)
    if not d.exists():
        return []
    out = []
    for p in sorted(d.rglob("*.md")):
        try:
            txt = p.read_text(encoding="utf-8", errors="replace")
        except Exception:
            continue
        first = ""
        for line in txt.splitlines():
            if line.strip():
                first = line.lstrip("# ").strip()
                break
        out.append({"title": first or p.stem, "file": p.name, "chars": len(txt)})
    return out


def has_knowledge(system: dict) -> bool:
    d = _kdir(system)
    return d.exists() and any(d.rglob("*.md"))


def _keyword_load(system: dict, query: str, max_chars: int) -> str:
    d = _kdir(system)
    texts = []
    for p in sorted(d.rglob("*.md")):
        try:
            texts.append(p.read_text(encoding="utf-8", errors="replace"))
        except Exception:
            pass
    if not texts:
        return ""
    words = set(re.findall(r"\w{4,}", (query or "").lower()))

    def score(txt):
        if not words:
            return 0
        t = txt.lower()
        return sum(t.count(w) for w in words)

    ranked = sorted(texts, key=score, reverse=True)
    out, total = [], 0
    for txt in ranked:
        if out and total + len(txt) > max_chars:
            break
        out.append(txt); total += len(txt)
    return "\n\n---\n\n".join(out)[:max_chars]


def load_relevant(system: dict, query: str, max_chars: int = 6000, top_k: int = 6) -> str:
    """Релевантні фрагменти бази знань. Семантично (ембединги), keyword — запасний."""
    d = _kdir(system)
    if not d.exists():
        return ""
    entries = _load_index(system)
    if entries and config.embeddings_ready() and any(e.get("vec") for e in entries):
        try:
            qv = llm.embed([query or ""])[0]
            scored = sorted(entries, key=lambda e: _cosine(qv, e.get("vec") or []), reverse=True)
            out, total = [], 0
            for e in scored[: max(top_k, 1)]:
                t = e.get("text", "")
                if out and total + len(t) > max_chars:
                    break
                out.append(t); total += len(t)
            if out:
                return "\n\n---\n\n".join(out)[:max_chars]
        except Exception:
            pass  # падаємо на keyword
    return _keyword_load(system, query, max_chars)
