"""ПАУЗА ПРОГОНУ ЗА ВАРТІСТЮ: напрацьоване не згорає.

28.07.2026 (зміна 20, вимога Андрія). Раніше межа вартості просто ОБРИВАЛА
роботу: «підняти межу — рядок MAX_RUN_USD у файлі .env.local». Для клієнта це
означало дві однаково погані речі: лізти у службові файли або платити ЩЕ РАЗ за
те, що вже оплачено.

Слова Андрія: «Клієнт не буде нічого писати у службових файлах. Йому легше мені
подзвонити та обматюкати. Система повинна зупинитися й повідомити про
досягнення планки, з пропозицією або зібрати з того, що є, або підняти планку —
це вияв поваги до клієнта та його свідомий вибір.»

Тому прогін не обривається, а СТАЄ НА ПАУЗУ: сюди лягає все напрацьоване
(план, готові етапи, місце зупинки), і продовження починається САМЕ З ЦЬОГО
місця. Клієнт двічі не платить.
"""

import json
import time
import uuid
from pathlib import Path

DIR = Path(__file__).resolve().parent / "runs_paused"
KEEP_DAYS = 7


def _dir():
    DIR.mkdir(parents=True, exist_ok=True)
    return DIR


def save(state: dict) -> str:
    """Кладе стан прогону на паузу й повертає його ключ."""
    rid = uuid.uuid4().hex[:12]
    body = dict(state or {})
    body["saved_at"] = time.time()
    (_dir() / ("%s.json" % rid)).write_text(
        json.dumps(body, ensure_ascii=False, default=str), encoding="utf-8")
    return rid


def load(rid: str):
    """Стан прогону або None. Чужий/застарілий ключ — це None, а не виняток:
    краще чесно сказати «продовжити нічого», ніж упасти клієнту в обличчя."""
    if not rid or not str(rid).isalnum():
        return None
    p = _dir() / ("%s.json" % rid)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def drop(rid: str):
    """Прибирає стан після успішного продовження — щоб пауза не жила вічно."""
    try:
        p = _dir() / ("%s.json" % rid)
        if p.exists():
            p.unlink()
    except Exception:
        pass


def purge(days: int = KEEP_DAYS) -> int:
    """Старі паузи прибираються самі (клієнт до них уже не повернеться)."""
    n, edge = 0, time.time() - days * 86400
    try:
        for p in _dir().glob("*.json"):
            if p.stat().st_mtime < edge:
                p.unlink()
                n += 1
    except Exception:
        pass
    return n
