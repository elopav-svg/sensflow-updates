"""
builder.py — Будівник систем. Створює НОВУ мультиагентську систему за вашим
docs/SYSTEM_BUILDER_CONTRACT.md, коли оркестратор повертає propose_system_build.

Створює окрему папку проєкту в корені робочого простору (не ховає всередині
платформи), генерує промпти агентів за контрактом РОЛЬ/КОНТЕКСТ/ЗАПИТ/
ОБМЕЖЕННЯ/ФОРМАТ ВІДПОВІДІ, реєструє систему зі статусом needs_review.
"""

import json
import re
from datetime import datetime
from pathlib import Path

import config
import llm
import registry


def _slug(value: str, fallback="generated_system") -> str:
    if not value:
        return fallback
    s = value.lower()
    s = re.sub(r"[^a-z0-9а-яіїєґ]+", "_", s, flags=re.IGNORECASE)
    s = re.sub(r"_+", "_", s).strip("_")
    # транслітерація мінімальна: лишаємо латиницю/цифри, кирилицю замінюємо
    s = re.sub(r"[^a-z0-9_]+", "", s)
    return s or fallback


def _builder_system_prompt() -> str:
    contract = ""
    if config.BUILDER_CONTRACT.exists():
        contract = config.BUILDER_CONTRACT.read_text(encoding="utf-8-sig")
    return (
        contract
        + "\n\n## ТЕХНІЧНА ВИМОГА\n"
        "На основі специфікації нової системи згенеруй ПОВНІ файли. "
        "Поверни РІВНО ОДИН JSON-обʼєкт:\n"
        "{\n"
        '  "system_id": "stable_snake_case_latin_id",\n'
        '  "project_folder": "Проект <Назва>",\n'
        '  "name": "людська назва",\n'
        '  "category": "одна категорія",\n'
        '  "description": "стислий семантичний опис",\n'
        '  "orchestration_mode": "sequential|iterative|hybrid|human_in_loop",\n'
        '  "triggers": ["короткі тригери з можливостей, не сире джерело"],\n'
        '  "root_prompt": "повний root PROMPT.md з РОЛЬ/КОНТЕКСТ/ЗАПИТ/ОБМЕЖЕННЯ/ФОРМАТ ВІДПОВІДІ",\n'
        '  "system_contract": "SYSTEM_CONTRACT.md",\n'
        '  "runbook": "RUNBOOK.md",\n'
        '  "smoke_test": "SMOKE_TEST.md",\n'
        '  "agents": [\n'
        '    {"id":"agentname","role":"роль","prompt":"PROMPT.md з усіма 5 розділами + місце в конвеєрі, входи, виходи, коли спинятись, формат передачі далі, перевірки якості"}\n'
        "  ]\n"
        "}\n"
        "Промпти мають бути ТРАНСФОРМАЦІЄЮ матеріалів, а не копією сирого тексту."
    )


def build_system(proposed_system: dict, task: str, files_context: str = "") -> dict:
    """⛔ ВИВЕДЕНО З ЛАДУ (10.07.2026, «одні двері»). Старий одно-JSON шлях
    просив модель видати ВСЮ систему одним гігантським JSON → на великих
    системах обрізався лімітом ходу → «Незбалансований JSON» (3 обриви 10.07).
    ЄДИНИЙ шлях побудови: run_system(system_builder) → executor._build_for_real
    (3 агенти → контракт «дані → рендер» → матеріалізація → замок чесності).
    Запобіжник лишено свідомо: будь-який забутий виклик падає чесно і показно,
    а не будує систему в обхід конвеєра."""
    return {"ok": False, "note": (
        "Старий одно-JSON шлях Будівника виведено з ладу (одні двері, 10.07.2026). "
        "Побудова йде ЛИШЕ через run_system(system_id='system_builder').")}


def _legacy_build_system_disabled(proposed_system: dict, task: str, files_context: str = "") -> dict:
    """Мертвий код старого шляху — збережено лише для історії, НЕ викликати."""
    if not config.provider_ready():
        return {"ok": False, "note": "LLM-мозок не налаштований — будівник не може згенерувати промпти."}

    spec = json.dumps(proposed_system or {}, ensure_ascii=False, indent=1)
    user = (
        f"## ЗАПИТ КОРИСТУВАЧА\n{task}\n\n"
        f"## СПЕЦИФІКАЦІЯ НОВОЇ СИСТЕМИ (від оркестратора)\n{spec}\n\n"
        + (f"## ДОДАНІ МАТЕРІАЛИ\n{files_context}\n" if files_context else "")
    )

    try:
        blueprint = llm.judge_json(_builder_system_prompt(), user, temperature=0.2,
                                   model=config.brain_model(),
                                   purpose="проєкт нової системи")
    except llm.LLMError as e:
        return {"ok": False, "note": f"Будівник не зміг згенерувати систему: {e}"}

    system_id = _slug(blueprint.get("system_id") or blueprint.get("name") or "generated_system")
    folder_name = blueprint.get("project_folder") or f"Проект {blueprint.get('name', system_id)}"
    project_path = (config.WORKSPACE_ROOT / folder_name).resolve()
    agents_dir = project_path / "Agents"
    (project_path / "Memory").mkdir(parents=True, exist_ok=True)
    agents_dir.mkdir(parents=True, exist_ok=True)

    files_written = []

    def _w(path: Path, content: str):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content or "", encoding="utf-8")
        files_written.append(str(path))

    _w(project_path / "PROMPT.md", blueprint.get("root_prompt", ""))
    _w(project_path / "SYSTEM_CONTRACT.md", blueprint.get("system_contract", ""))
    _w(project_path / "RUNBOOK.md", blueprint.get("runbook", ""))
    _w(project_path / "SMOKE_TEST.md", blueprint.get("smoke_test", ""))
    _w(project_path / "Memory" / "MEMORY.md", f"# Memory — {blueprint.get('name','')}\n")
    _w(project_path / "Memory" / "HEARTBEAT.md", "# Heartbeat\n")

    agent_ids = []
    for agent in blueprint.get("agents", []):
        aid = _slug(agent.get("id") or agent.get("role") or "agent")
        agent_ids.append(aid)
        _w(agents_dir / aid / "PROMPT.md", agent.get("prompt", ""))
        (agents_dir / aid / "Input").mkdir(parents=True, exist_ok=True)
        (agents_dir / aid / "Output").mkdir(parents=True, exist_ok=True)

    # system.yaml (мінімальний валідний)
    system_yaml = _render_system_yaml(blueprint, system_id, folder_name, agent_ids)
    _w(project_path / "system.yaml", system_yaml)

    # adapter_stub.json
    _w(
        project_path / "adapter_stub.json",
        json.dumps(
            {"adapter_id": f"{system_id}_adapter", "adapter_type": "generated_system_adapter",
             "status": "needs_review"},
            ensure_ascii=False, indent=2,
        ),
    )

    # Реєстрація зі статусом needs_review (за контрактом)
    entry = {
        "id": system_id,
        "name": blueprint.get("name", system_id),
        "category": blueprint.get("category", "generated"),
        "status": "needs_review",
        "root_path": folder_name,
        "description": blueprint.get("description", ""),
        "orchestration_mode": blueprint.get("orchestration_mode", "sequential"),
        "agents": agent_ids,
        "priority": 50,
        "sensitive": False,
        "triggers": blueprint.get("triggers", [])[:12],
        "created_by": "python_system_builder",
        "created_at": datetime.now().isoformat(),
    }
    entry = registry.add_system(entry)

    return {
        "ok": True,
        "system_id": entry["id"],
        "project_path": str(project_path),
        "registry_entry": entry,
        "files": files_written,
        "note": "Система створена зі статусом needs_review. Після успішного smoke-run можна активувати.",
    }


def _render_system_yaml(bp, system_id, folder_name, agent_ids) -> str:
    def yml_list(items, indent="  "):
        return "\n".join(f'{indent}- "{str(i)}"' for i in items) if items else f"{indent}[]"

    agents_block = ""
    for aid in agent_ids:
        agents_block += (
            f"  - id: {aid}\n"
            f'    prompt_path: "Agents/{aid}/PROMPT.md"\n'
            f"    required: true\n"
        )
    return (
        'schema_version: "1.0"\n'
        f"id: {system_id}\n"
        f'name: "{bp.get("name","")}"\n'
        f'category: {bp.get("category","generated")}\n'
        "status: needs_review\n"
        f'version: "0.1.0"\n'
        f'root_path: "{folder_name}"\n'
        f'description: "{bp.get("description","")}"\n'
        f'entry_agent: {agent_ids[0] if agent_ids else "agentmain"}\n'
        f'orchestration_mode: {bp.get("orchestration_mode","sequential")}\n'
        "triggers:\n  keywords:\n"
        + yml_list(bp.get("triggers", []), "    ")
        + "\nagents:\n"
        + (agents_block or "  []\n")
        + "verification_rules:\n"
        '  - "Результат не порожній."\n'
        '  - "Результат відповідає задачі."\n'
        '  - "Конвеєр агентів видно у трасуванні запуску."\n'
    )


# ---------------------------------------------------------------------------
# Матеріалізація результату СИСТЕМИ-Будівника (її 3 агенти).
# Третій агент (AgentStructureCreator) за контрактом повертає JSON
# {files_to_create:[{path,content}], registry_entry:{...}}. Тут ми його
# ДЕТЕРМІНОВАНО пишемо на диск — без ще одного виклику LLM. Так система-Будівник
# стає ПОВНОЦІННОЮ: агенти проєктують, сервер лише матеріалізує байти.
# ---------------------------------------------------------------------------
def _extract_json_block(text: str):
    """Витягує JSON-обʼєкт із тексту: спершу ```json…```, потім ```…```,
    інакше — від першої '{' до останньої '}'. Повертає dict або None."""
    if not text:
        return None
    m = re.search(r"```json\s*(\{.*?\})\s*```", text, re.S)
    if not m:
        m = re.search(r"```\s*(\{.*?\})\s*```", text, re.S)
    raw = m.group(1) if m else None
    if raw is None:
        i, j = text.find("{"), text.rfind("}")
        raw = text[i:j + 1] if (i != -1 and j > i) else None
    if not raw:
        return None
    try:
        return json.loads(raw)
    except Exception:
        return None


def _safe_rel(path: str):
    """Безпечний відносний шлях: без абсолютних, без диску 'C:/', без '..'.
    Повертає None для порожнього/небезпечного (захист від запису поза текою)."""
    p = str(path or "").replace("\\", "/").strip()
    p = re.sub(r"^[A-Za-z]:/", "", p)          # прибрати абсолютний диск
    p = p.lstrip("/")
    parts = [seg for seg in p.split("/") if seg not in ("", ".")]
    if not parts or any(seg == ".." for seg in parts):
        return None
    return "/".join(parts)


# Машинні блоки Райтера з повними текстами промптів (контракт «дані → рендер»:
# Структуролог посилається на них через content_from, а не дублює тексти в JSON —
# інакше багатоагентна система рве JSON лімітом ходу; корінь обриву 10.07 ~21:30).
_PROMPT_BLOCK_RE = re.compile(
    r"<<<AGENT_PROMPT\s+id=([\w\-]+)\s*>>>\s*\n(.*?)<<<END_AGENT_PROMPT>>>",
    re.S)


def parse_prompt_blocks(text: str) -> dict:
    """Витягає блоки <<<AGENT_PROMPT id=X>>> … <<<END_AGENT_PROMPT>>> з виводу
    Райтера. Повертає {id: повний_текст_промпту}."""
    out = {}
    for m in _PROMPT_BLOCK_RE.finditer(text or ""):
        out[m.group(1).strip()] = (m.group(2) or "").strip() + "\n"
    return out


def required_prompt_ids(struct_raw: str) -> list:
    """Які id блоків Райтера ПОТРІБНІ структурі Структуролога (усі content_from
    без інлайнового content). Порядок збережено, без дублів."""
    data = _extract_json_block(struct_raw or "")
    if not isinstance(data, dict):
        return []
    out = []
    for f in (data.get("files_to_create") or []):
        if not isinstance(f, dict):
            continue
        src = f.get("content_from")
        if src and not f.get("content"):
            s = str(src).strip()
            if s and s not in out:
                out.append(s)
    return out


def refill_missing_blocks(needed: list, sources: dict, ask_fn, emit=None,
                          max_refills: int = 8) -> dict:
    """ДОЗАПИТ відсутніх блоків Райтера — ПО ОДНОМУ за хід (корінь обриву 10.07
    ~23:00: 5 повних промптів не влазять в ОДИН хід Райтера; правило філософії —
    розмір системи не має залежати від жодного одиничного ходу).
    ask_fn(mid) -> текст із блоком <<<AGENT_PROMPT id=mid>>>. Стеля спроб — кодом
    (max_refills), по одній спробі на блок: петля неможлива. Блок, якого нема і
    після дозапиту, чесно завалить матеріалізацію поіменно (existing-перевірка)."""
    sources = dict(sources or {})
    missing = [i for i in (needed or []) if i not in sources]
    for mid in missing[:max_refills]:
        if emit:
            try:
                emit(f"🧩 Райтер: дозаписую промпт «{mid}» окремим ходом…")
            except Exception:
                pass
        try:
            txt = ask_fn(mid) or ""
        except Exception:
            continue  # чесний провал поіменно зробить матеріалізатор
        got = parse_prompt_blocks(txt)
        if mid in got:
            sources[mid] = got[mid]
    return sources


def materialize_agent_output(struct_raw: str, task: str = "", emit=None, sources=None) -> dict:
    """Пише на диск систему, спроєктовану агентами Будівника, і реєструє її
    (needs_review). Приймає СИРИЙ вивід AgentStructureCreator; sources — повні
    тексти промптів із блоків Райтера ({id: text}) для елементів content_from.
    Повертає {ok, system_id, project_path, files, registry_entry, note}."""
    data = _extract_json_block(struct_raw or "")
    if not isinstance(data, dict):
        return {"ok": False, "note": "структурний агент не повернув парсабельний JSON."}
    rels, missing_src = [], []
    for f in (data.get("files_to_create") or []):
        rel = _safe_rel((f or {}).get("path"))
        if not rel:
            continue
        content = (f or {}).get("content", "")
        src = (f or {}).get("content_from")
        if (not content) and src:
            content = (sources or {}).get(str(src).strip(), "")
            if not content:
                missing_src.append(str(src).strip())
                continue
        rels.append((rel, content))
    if missing_src:
        return {"ok": False, "note": "у виводі Райтера немає блоків промптів для: "
                                     + ", ".join(sorted(set(missing_src)))
                                     + " (очікуються блоки <<<AGENT_PROMPT id=…>>>)."}
    if not rels:
        return {"ok": False, "note": "немає валідних files_to_create."}

    project_folder = rels[0][0].split("/", 1)[0]
    base = (config.WORKSPACE_ROOT / project_folder).resolve()
    ws = config.WORKSPACE_ROOT.resolve()
    if base != ws and ws not in base.parents:
        return {"ok": False, "note": "тека проєкту поза робочим простором."}

    written, agent_ids = [], []
    for rel, content in rels:
        if rel.split("/", 1)[0] != project_folder:
            continue  # усі файли — лише в межах однієї теки проєкту
        target = (config.WORKSPACE_ROOT / rel).resolve()
        if target != base and base not in target.parents:
            continue  # захист від виходу за межі теки проєкту
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content or "", encoding="utf-8")
        written.append(str(target))
        seg = rel.split("/")
        if len(seg) >= 4 and seg[1] in ("Agents", "agents") and seg[3] in ("PROMPT.md", "CLAUDE.md"):
            agent_ids.append(seg[2])
    if not written:
        return {"ok": False, "note": "жодного файла не записано (safety-фільтр)."}

    e = data.get("registry_entry") or {}
    sid = _slug(e.get("id") or e.get("name") or project_folder)
    entry = {
        "id": sid,
        "name": e.get("name") or project_folder,
        "category": e.get("category") or "generated",
        "status": "needs_review",                       # завжди — за контрактом білдера
        "root_path": project_folder,
        "description": e.get("description", ""),
        "orchestration_mode": e.get("orchestration_mode", "sequential"),
        "agents": e.get("agents") or sorted(set(agent_ids)) or ["AgentMain"],
        "priority": e.get("priority", 50),
        "sensitive": bool(e.get("sensitive", False)),
        "triggers": (e.get("triggers") or [])[:12],
        "created_by": "system_builder_agents",
        "created_at": datetime.now().isoformat(),
    }
    entry = registry.add_system(entry)
    return {"ok": True, "system_id": entry["id"], "project_path": str(base),
            "files": written, "registry_entry": entry,
            "note": "створено агентами Будівника (needs_review)."}


# ---------------------------------------------------------------------------
# КОНТРАКТ «СПИСОК АГЕНТІВ → ДЕТЕРМІНОВАНА РОЗКЛАДКА» (10.07.2026, пізній вечір).
# Корінь провалів Будівника: успіх залежав від ОДНОГО великого JSON структурного
# агента (files_to_create). На великій системі він обривався → непарсабельний →
# смерть, і сітка дозапиту вимикалась (needed бралось із того ж JSON). Тепер
# критичний вивід — КРИХІТНИЙ список агентів (стійкий до обриву + салваж), а всю
# розкладку файлів сервер будує сам. Єдиний важливий LLM-вивід — тексти промптів
# (Райтер), і їх дозапитуємо по одному.
# ---------------------------------------------------------------------------
def _salvage_agent_ids(struct_raw: str, writer_raw: str) -> list:
    """Best-effort список id агентів навіть з ОБІРВАНОГО struct_raw/writer_raw:
    з блоків Райтера (відкривні теги, навіть без закриття) + з тексту структури
    (шляхи Agents/<id>/PROMPT.md і content_from). Порядок збережено, без MAIN/дублів."""
    ids = []

    def _add(x):
        x = (x or "").strip()
        if x and x != "MAIN" and x not in ids:
            ids.append(x)

    for m in re.finditer(r"<<<AGENT_PROMPT\s+id=([\w\-]+)", writer_raw or ""):
        _add(m.group(1))
    for m in re.finditer(r"Agents/([\w\-]+)/PROMPT\.md", struct_raw or ""):
        _add(m.group(1))
    for m in re.finditer(r'"content_from"\s*:\s*"([\w\-]+)"', struct_raw or ""):
        _add(m.group(1))
    return ids


def parse_build_meta(struct_raw: str, writer_raw: str = "") -> dict:
    """Повертає {'system': {...}, 'agents': [ordered ids], 'agent_roles': {...}} —
    стійко до обриву. Приймає і НОВИЙ формат ({agents, system, agent_roles}), і
    СТАРИЙ ({files_to_create, registry_entry}); чого бракує — салважить регексом.
    agent_roles = {aid: {kind, web}} — ЯВНИЙ паспорт здатностей від структурного
    агента (щоб executor не вгадував веб/калькулятор за назвою). Необовʼязковий:
    коли його нема (напр. JSON обірвався) — спрацьовує евристика registry.seed_roles."""
    system, agents, agent_roles = {}, [], {}
    data = _extract_json_block(struct_raw or "")
    if isinstance(data, dict):
        if isinstance(data.get("agents"), list):
            for a in data["agents"]:
                if isinstance(a, str) and a.strip():
                    agents.append(a.strip())
                elif isinstance(a, dict) and (a.get("id") or a.get("name")):
                    aid = str(a.get("id") or a.get("name")).strip()
                    agents.append(aid)
                    if a.get("kind") or a.get("web"):
                        agent_roles[aid] = {"kind": a.get("kind"), "web": a.get("web")}
        ar = data.get("agent_roles")
        if isinstance(ar, dict):
            for k, v in ar.items():
                kk = str(k).strip()
                if not kk:
                    continue
                if isinstance(v, dict):
                    agent_roles[kk] = {"kind": v.get("kind") or v.get("role"),
                                       "web": v.get("web")}
                elif isinstance(v, str) and v.strip():
                    agent_roles[kk] = {"kind": v.strip()}
        if isinstance(data.get("system"), dict):
            system = dict(data["system"])
        e = data.get("registry_entry") or {}
        if isinstance(e, dict):
            if not system:
                system = {k: e.get(k) for k in ("id", "name", "category", "description",
                                                "orchestration_mode", "triggers",
                                                "priority", "sensitive")
                          if e.get(k) is not None}
            if not agents and isinstance(e.get("agents"), list):
                for a in e["agents"]:
                    if isinstance(a, dict) and (a.get("id") or a.get("name")):
                        agents.append(str(a.get("id") or a.get("name")).strip())
                    elif isinstance(a, str) and a.strip():
                        agents.append(a.strip())
    for aid in _salvage_agent_ids(struct_raw, writer_raw):
        if aid not in agents:
            agents.append(aid)
    agents = [a for a in agents if a and a != "MAIN"]
    agent_roles = {k: v for k, v in agent_roles.items() if k and k != "MAIN"}
    if not system.get("id") and not system.get("name"):
        m = re.search(r'"id"\s*:\s*"([\w\-]+)"', struct_raw or "")
        if m:
            system["id"] = m.group(1)
    return {"system": system, "agents": agents, "agent_roles": agent_roles}


def _default_root_prompt(system: dict, agents: list) -> str:
    name = (system or {}).get("name", "")
    desc = (system or {}).get("description", "")
    return (f"# {name}\n\n## РОЛЬ\nГоловний оркестратор системи «{name}». "
            f"Керуй агентами конвеєра: {', '.join(agents)}.\n\n"
            f"## ЗАПИТ\n{desc}\nПередавай роботу агентам по черзі, збирай і віддавай "
            "фінальний результат.\n\n## ФОРМАТ ВІДПОВІДІ\nЗрозумілий результат для "
            "користувача + короткий слід роботи агентів.")


def materialize_from_agents(meta: dict, prompts: dict, task: str = "", emit=None) -> dict:
    """Пише систему на диск ДЕТЕРМІНОВАНО зі СПИСКУ АГЕНТІВ (не з крихкого
    files_to_create). prompts = {id: текст} з блоків Райтера (MAIN + агенти),
    вже дозаписані по одному. Повертає {ok, system_id, project_path, files,
    registry_entry, note}."""
    system = dict((meta or {}).get("system") or {})
    agents = [a for a in ((meta or {}).get("agents") or []) if a and a != "MAIN"]
    prompts = prompts or {}
    if not agents:
        return {"ok": False, "note": "не вдалося визначити жодного агента системи "
                                     "(список агентів порожній навіть після салважу)."}
    missing = [a for a in agents if not (prompts.get(a) or "").strip()]
    if missing:
        return {"ok": False, "note": "після дозапиту бракує повних промптів для агентів: "
                                     + ", ".join(missing)
                                     + " (очікуються блоки <<<AGENT_PROMPT id=…>>> від Райтера)."}
    folder = _slug(system.get("id") or system.get("name") or _slug(task[:40]))
    base = (config.WORKSPACE_ROOT / folder).resolve()
    ws = config.WORKSPACE_ROOT.resolve()
    if base != ws and ws not in base.parents:
        return {"ok": False, "note": "тека проєкту поза робочим простором."}
    root_prompt = (prompts.get("MAIN") or "").strip() or _default_root_prompt(system, agents)

    files_plan = [
        (f"{folder}/PROMPT.md", root_prompt),
        (f"{folder}/Input/.gitkeep", ""),
        (f"{folder}/Output/.gitkeep", ""),
        (f"{folder}/Memory/MEMORY.md", "# Memory\n"),
        (f"{folder}/system.yaml",
         _render_system_yaml(system, _slug(system.get("id") or folder), folder, agents)),
    ]
    for aid in agents:
        files_plan += [
            (f"{folder}/Agents/{aid}/PROMPT.md", prompts.get(aid, "")),
            (f"{folder}/Agents/{aid}/Input/.gitkeep", ""),
            (f"{folder}/Agents/{aid}/Output/.gitkeep", ""),
            (f"{folder}/Agents/{aid}/Memory/MEMORY.md", "# Memory\n"),
        ]

    written = []
    for rel, content in files_plan:
        rel = _safe_rel(rel)
        if not rel or rel.split("/", 1)[0] != folder:
            continue
        target = (config.WORKSPACE_ROOT / rel).resolve()
        if target != base and base not in target.parents:
            continue
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content or "", encoding="utf-8")
        written.append(str(target))
    if not written:
        return {"ok": False, "note": "жодного файла не записано (safety-фільтр)."}

    sid = _slug(system.get("id") or system.get("name") or folder)
    entry = {
        "id": sid,
        "name": system.get("name") or folder,
        "category": system.get("category") or "generated",
        "status": "needs_review",
        "root_path": folder,
        "description": system.get("description", ""),
        "orchestration_mode": system.get("orchestration_mode", "sequential"),
        "agents": agents,
        "priority": system.get("priority", 50),
        "sensitive": bool(system.get("sensitive", False)),
        "triggers": (system.get("triggers") or [])[:12],
        "created_by": "system_builder_agents",
        "created_at": datetime.now().isoformat(),
    }
    # ЯВНИЙ ПАСПОРТ ЗДАТНОСТЕЙ (11.07.2026): щоб збудована система НЕ залежала від
    # вгадування executor-ом за назвами агентів (корінь «порожнього наповнення»:
    # дослідник AgentObjectFinder не збігся з ключем → нуль вебу → структура без
    # даних). Декларація структурного агента (meta.agent_roles) перекриває
    # евристику; евристика лишається другим рубежем.
    entry["roles"] = registry.seed_roles(entry, specs=(meta or {}).get("agent_roles"))
    entry = registry.add_system(entry)
    # Паспорт — і в папку системи (.sf_state.json), щоб пережив наші оновлення
    # (реєстр — кеш; поле roles уже в _STATE_FIELDS). Тиха спроба — не валить білд.
    try:
        registry.write_folder_state(entry, {"roles": entry.get("roles") or {}})
    except Exception:
        pass
    return {"ok": True, "system_id": entry["id"], "project_path": str(base),
            "files": written, "registry_entry": entry,
            "note": f"створено детерміновано зі списку агентів ({len(agents)} аг., needs_review)."}
