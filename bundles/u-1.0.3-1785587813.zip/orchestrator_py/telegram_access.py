"""
telegram_access.py — динамічне керування доступом до Telegram-бота.

Білий список авторизованих chat_id + черга заявок від неавторизованих.
Зберігається у <стан>/runs/_telegram_access.json. Зміни підхоплюються БЕЗ рестарту:
бот звіряє доступ із файлом на кожному повідомленні, а консоль пише в той самий файл.

Бутстрап: ID з .env.local (TELEGRAM_ALLOWED_CHAT_IDS) завжди дозволені — щоб
не втратити доступ, навіть якщо файл видалити.
"""

import json
from datetime import datetime

import config

# ⭐ 31.07.2026. СПИСОК ДОСТУПУ ЙДЕ ЗА ПЕРЕМИКАЧЕМ СТАНУ (`config.STATE_DIR`).
# У БОЮ STATE_DIR == ENGINE_DIR, тому шлях лишається той самий, що й був
# (`<рушій>\runs\_telegram_access.json`) — жоден клієнтський файл не переїжджає.
# Але чек чи проба (процес `*_test.py` / `*_probe.py`, або раннер із
# SENSFLOW_STATE_DIR) дістає власну теку стану і більше НЕ ПИШЕ в БОЙОВИЙ список
# довірених. Клас той самий, що й з автоматизаціями-привидами: писар стану має
# слухати ОДИН перемикач [[project_state_isolation]].
_PATH = config.STATE_DIR / "runs" / "_telegram_access.json"


def _env_ids() -> set:
    raw = (config.ENV.get("TELEGRAM_ALLOWED_CHAT_IDS") or "").replace(";", ",")
    out = set()
    for p in raw.split(","):
        p = p.strip()
        if p.lstrip("-").isdigit():
            out.add(int(p))
    return out


def _load() -> dict:
    try:
        d = json.loads(_PATH.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    d.setdefault("allowed", [])
    d.setdefault("pending", [])
    return d


def _save(d) -> bool:
    try:
        _PATH.parent.mkdir(parents=True, exist_ok=True)
        _PATH.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
        return True
    except Exception:
        return False


def is_allowed(chat_id) -> bool:
    try:
        chat_id = int(chat_id)
    except Exception:
        return False
    if chat_id in _env_ids():
        return True
    return any(a.get("id") == chat_id for a in _load().get("allowed", []))


def allow(chat_id, label: str = "") -> dict:
    chat_id = int(chat_id)
    d = _load()
    if not any(a.get("id") == chat_id for a in d["allowed"]):
        d["allowed"].append({"id": chat_id, "label": (label or "").strip(),
                             "added": datetime.now().isoformat(timespec="seconds")})
    d["pending"] = [p for p in d["pending"] if p.get("id") != chat_id]
    _save(d)
    return snapshot()


def revoke(chat_id) -> dict:
    chat_id = int(chat_id)
    d = _load()
    d["allowed"] = [a for a in d["allowed"] if a.get("id") != chat_id]
    _save(d)
    return snapshot()


def record_pending(chat_id, name: str = "") -> None:
    """Фіксує спробу доступу від неавторизованого (для черги схвалення в консолі)."""
    try:
        chat_id = int(chat_id)
    except Exception:
        return
    d = _load()
    if any(a.get("id") == chat_id for a in d["allowed"]) or chat_id in _env_ids():
        return
    now = datetime.now().isoformat(timespec="seconds")
    for p in d["pending"]:
        if p.get("id") == chat_id:
            if name:
                p["name"] = name
            p["last_seen"] = now
            _save(d)
            return
    d["pending"].append({"id": chat_id, "name": (name or "").strip(), "last_seen": now})
    _save(d)


def dismiss_pending(chat_id) -> dict:
    chat_id = int(chat_id)
    d = _load()
    d["pending"] = [p for p in d["pending"] if p.get("id") != chat_id]
    _save(d)
    return snapshot()


def owner_ids() -> list:
    """Chat_id власника(ів) для ескалацій — бутстрап-ID з .env.local (TELEGRAM_ALLOWED_CHAT_IDS)."""
    return sorted(_env_ids())


def snapshot() -> dict:
    """Повний стан для UI: дозволені (вкл. ID з .env.local) + заявки."""
    d = _load()
    out_allowed = []
    have = set()
    for i in sorted(_env_ids()):
        out_allowed.append({"id": i, "label": "з .env.local", "added": "", "from_env": True})
        have.add(i)
    for a in d.get("allowed", []):
        if a.get("id") not in have:
            out_allowed.append({**a, "from_env": False})
    return {"allowed": out_allowed, "pending": d.get("pending", [])}
