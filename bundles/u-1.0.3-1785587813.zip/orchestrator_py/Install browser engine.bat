@echo off
chcp 65001>nul
cd /d "%~dp0"
echo ============================================================
echo    SensFlow - install local browser engine (Playwright)
echo ============================================================
echo.
echo This installs a local headless browser that lets SensFlow read
echo modern JavaScript websites directly on THIS computer. One time.
echo Nothing is sent to any third-party service.
echo Download size: a few hundred MB. Please be patient.
echo.
python --version >nul 2>&1
if errorlevel 1 (
  echo [!] Python not found in PATH. Install Python 3.9+ first, then rerun.
  pause
  exit /b 1
)
echo [1/2] Installing Playwright library...
python -m pip install --upgrade playwright
if errorlevel 1 (
  echo [!] pip install failed. Check your internet connection and rerun.
  pause
  exit /b 1
)
echo.
echo [2/2] Downloading Chromium browser (this is the big part)...
python -m playwright install chromium
if errorlevel 1 (
  echo [!] Browser download failed. Check your internet connection and rerun.
  pause
  exit /b 1
)
echo.
echo [OK] Local browser engine installed.
echo      You can close this window and use SensFlow as usual.
echo      JavaScript sites will now be read automatically when needed.
pause
