# -*- coding: utf-8 -*-
"""
tender_legal_doc.py — ПАПІР «ЯК ДІЯТИ» по конкретному тендеру (DOCX).

ЩО ЦЕ. Той самий документ, який 27.07.2026 я зібрав руками і який клієнту
став у пригоді: що діється в тендері прямо зараз, за якими правилами
живе САМЕ ЦЯ процедура, чого в ній НЕМАЄ, і що робити по кроках.
Тепер його складає система.

ЧОМУ ТУТ НЕМАЄ МОДЕЛІ (Статут №15, питання 2 — точка рішення).
  Жодне число, жоден строк і жодна цитата в цьому документі не вигадані:
    - факти (суми, статуси, час, вимоги замовника) — з офіційного API;
    - строки й заборони — з tender_legal, тобто з бази звірених норм;
    - зʼязок «норма -> ваш тендер» — арифметика на датах.
  Модель не викликається взагалі. Тому папір коштує 0 грн і не фантазує.

FAIL-CLOSED. Немає підтвердженого режиму закупівлі -> документа НЕ БУДЕ.
  Замість красивого папера з чужими строками користувач отримує рівно
  один рядок: чого бракує. Це і є лікування помилки 27.07.2026.

ВСІ КАНАЛИ. Назва тендера подається людині лише через tender_render —
  сира назва на 1395 знаків не потрапить ані в Telegram, ані сюди.
"""
import datetime
import os

import tender_legal
import tender_message
import tender_render

try:
    import tender_source_ua as src
except Exception:                                    # джерело може бути недоступне
    src = None


class TenderDocError(Exception):
    pass


# ---------------------------------------------------------------------------
# 1. Дати й гроші — в людському вигляді
# ---------------------------------------------------------------------------
def _dt(iso):
    """ISO -> datetime. Не розпарсилось -> None, а не «сьогодні»."""
    if not iso:
        return None
    txt = str(iso).strip()
    for cut in (19, 10):
        try:
            return datetime.datetime.strptime(txt[:cut],
                                              "%Y-%m-%dT%H:%M:%S" if cut == 19 else "%Y-%m-%d")
        except Exception:
            continue
    return None


def human_dt(iso, with_time=True):
    d = _dt(iso)
    if not d:
        return "—"
    return d.strftime("%d.%m.%Y, %H:%M") if with_time else d.strftime("%d.%m.%Y")


# Код валюти з API -> те, як гроші називає людина.
_CURRENCY = {"UAH": "грн", "ГРН": "грн", "USD": "дол.", "EUR": "євро"}


def money(value):
    val = (value or {}).get("amount")
    if val is None:
        return "—"
    cur = ((value or {}).get("currency") or "UAH").upper()
    try:
        return ("{:,.0f}".format(float(val)).replace(",", " ") + " "
                + _CURRENCY.get(cur, cur))
    except Exception:
        return str(val)


# ---------------------------------------------------------------------------
# 2. Що діється в тендері — суто з фактів
# ---------------------------------------------------------------------------
def _bid_value(bid):
    """Сума пропозиції учасника.

    ⚠ Живий прогін 28.07.2026: у МУЛЬТИЛОТОВІЙ закупівлі (а тендер Каспера саме
    такий) поля `value` в пропозиції немає — гроші лежать у `lotValues`. Через це
    всі три учасники показувались людині з прочерком замість суми. Беремо
    `value`, а якщо його немає — складаємо лоти (валюта береться з першого).
    """
    bid = bid or {}
    if bid.get("value"):
        return bid["value"]
    lots = [lv.get("value") for lv in (bid.get("lotValues") or []) if lv.get("value")]
    if not lots:
        return None
    total, currency = 0.0, None
    for v in lots:
        try:
            total += float(v.get("amount") or 0)
        except Exception:
            return None
        currency = currency or v.get("currency")
    return {"amount": total, "currency": currency}


def situation(card, awards, our_edrpou=None, today=None, bids=None):
    """Розкладає картку й нагороди на події. Нічого не оцінює."""
    today = today or datetime.datetime.now()
    events, demands = [], []
    leader = None

    for aw in awards or []:
        sup = (aw.get("suppliers") or [{}])[0]
        ident = (sup.get("identifier") or {}).get("id")
        row = {
            "status": aw.get("status"),
            "supplier": sup.get("name") or "—",
            "edrpou": ident,
            "amount": money(aw.get("value")),
            "date": human_dt(aw.get("date")),
            "ours": bool(our_edrpou and ident and str(ident) == str(our_edrpou)),
        }
        if aw.get("status") == "pending" and leader is None:
            leader = row
        events.append(row)

        for ms in aw.get("milestones") or []:
            due = _dt(ms.get("dueDate"))
            left = None
            if due:
                left = round((due - today).total_seconds() / 3600.0, 1)
            demands.append({
                "supplier": row["supplier"],
                "code": ms.get("code"),
                "status": ms.get("status"),
                "due": human_dt(ms.get("dueDate")),
                "hours_left": left,
                "text": (ms.get("description") or "").strip(),
                "ours": row["ours"],
            })

    people = []
    for b in bids or []:
        tenderer = (b.get("tenderers") or [{}])[0]
        ident = (tenderer.get("identifier") or {}).get("id")
        people.append({
            "name": tenderer.get("name") or "—",
            "amount": money(_bid_value(b)),
            "ours": bool(our_edrpou and ident and str(ident) == str(our_edrpou)),
        })

    return {"awards": events, "demands": demands, "leader": leader,
            "participants": people,
            "contracts": list(card.get("contracts") or [])}


# ---------------------------------------------------------------------------
# 3. Кроки — з правил, не з натхнення
# ---------------------------------------------------------------------------
def steps(pos, sit):
    """Кроки виводяться з норм і фактів. Кожен крок каже, ЧОМУ він є."""
    out = []
    ids = {n["id"] for n in pos.get("norms") or []}

    hot = [d for d in sit["demands"] if d.get("hours_left") is not None
           and d["hours_left"] > 0 and not d["ours"]]
    if hot and "subject_change_reject" in ids:
        d = hot[0]
        out.append({
            "title": "Подивитись, що саме виправив конкурент",
            "why": ("замовник виставив йому вимогу усунути невідповідність "
                    "(строк — до %s). Норма каже: якщо при виправленні "
                    "змінено найменування, марку чи модель товару, замовник "
                    "ВІДХИЛЯЄ пропозицію." % d["due"]),
            "what": "Відкрити сторінку тендера й завантажити його виправлений файл.",
        })
        out.append({
            "title": "Якщо найменування зʼявилось або змінилось — звернутись до замовника",
            "why": "це підстава для відхилення, а не прохання про ласку.",
            "what": ("Звернення через електронну систему з посиланням на норму. "
                     "Строк відповіді замовника — у таблиці правил вище."),
        })

    if "one_demand_only" in ids and hot:
        out.append({
            "title": "Другої вимоги конкуренту не буде",
            "why": "норма прямо забороняє виставляти вимогу одному учаснику більше одного разу.",
            "what": "Не чекати, що замовник дасть йому ще одну спробу.",
        })

    # ⚠ Постійне правило — це НЕ дія за ситуацією. Якщо змішати їх в одну
    # купу, документ ніколи не зможе сказати «зараз робити нічого» — а це
    # теж чесна відповідь, і клієнту вона потрібна.
    if not out:
        out.append({
            "title": "Активних дій зараз немає",
            "why": "у тендері не видно ані вимог до учасників, ані наміру укласти договір.",
            "what": "Тримати тендер під наглядом Захисника.",
        })

    if "contract_next_day" in ids:
        out.append({
            "title": "Постійно: стежити щодня — вікно вузьке",
            "why": "договір тут можна підписати вже наступного дня після повідомлення про намір.",
            "what": "Сторож перевіряє статус автоматично; реагувати треба в межах доби.",
        })
    return out


# ---------------------------------------------------------------------------
# 4. Складання DOCX
# ---------------------------------------------------------------------------
def build(tender_id, card, awards, out_path, our_edrpou=None, today=None,
          pack=None, bids=None):
    """Складає документ. Немає звіреного режиму -> документа НЕ БУДЕ."""
    from docx import Document
    from docx.shared import Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    pos = tender_legal.position(card, pack=pack)
    if not pos["ok"]:
        raise TenderDocError(pos["stop"])

    today = today or datetime.datetime.now()
    sit = situation(card, awards, our_edrpou=our_edrpou, today=today, bids=bids)
    doc = Document()
    base = doc.styles["Normal"]
    base.font.name = "Calibri"
    base.font.size = Pt(11)

    h = doc.add_heading("Тендер %s" % tender_id, level=0)
    h.alignment = WD_ALIGN_PARAGRAPH.LEFT
    doc.add_paragraph(tender_render.short_title(card.get("title") or ""))
    sub = doc.add_paragraph("Правила цієї закупівлі та план дій · %s"
                            % today.strftime("%d.%m.%Y"))
    sub.runs[0].italic = True

    doc.add_heading("1. Що це за закупівля", level=1)
    ent = (card.get("procuringEntity") or {}).get("name") or "—"
    # ⚠ Підписи полів людині живуть В ОДНОМУ місці — у складачі повідомлень.
    # Якби я написав власні підписи тут, у продукті зʼявилося б два словники
    # людських формулювань, і чек одних воріт (блок 10) справедливо впав би.
    # Беремо готові константи. (Сам літерал підпису тут не пишу — навіть у
    # коментарі: чек сканує ВЕСЬ файл, і він має рацію.)
    doc.add_paragraph("%s %s" % (tender_message.LABEL_BUYER, ent))
    doc.add_paragraph("Тип закупівлі: %s" % (pos.get("label") or pos["regime"]))
    doc.add_paragraph("Правова основа: %s" % (pos.get("basis") or "—"))
    doc.add_paragraph("%s %s" % (tender_message.LABEL_AMOUNT, money(card.get("value"))))

    doc.add_heading("2. Що відбувається зараз", level=1)
    if not sit["awards"]:
        doc.add_paragraph("Нагород ще немає — переможця не визначено.")
    for row in sit["awards"]:
        mark = " (ВАША пропозиція)" if row["ours"] else ""
        p = doc.add_paragraph(style="List Bullet")
        p.add_run("%s — %s, %s, статус «%s»%s"
                  % (row["date"], row["supplier"], row["amount"], row["status"], mark))
    for d in sit["demands"]:
        p = doc.add_paragraph(style="List Bullet")
        left = ""
        if d.get("hours_left") is not None:
            left = (" — лишилось приблизно %.0f год" % d["hours_left"]) if d["hours_left"] > 0 \
                else " — строк уже минув"
        p.add_run("Вимога замовника до учасника «%s», строк до %s%s"
                  % (d["supplier"], d["due"], left))
        if d["text"]:
            doc.add_paragraph(tender_render.short_title(d["text"], 400))
    doc.add_paragraph("Договір: %s" % ("укладено" if sit["contracts"] else "не укладено"))
    # ⚠ Живий прогін 28.07.2026 показав дірку: Прозорро віддає нагороду ЛИШЕ на
    # поточного лідера, тому пропозиція клієнта в цьому розділі не зʼявлялась
    # взагалі — людина не бачила, ДЕ ВОНА СТОЇТЬ. Мовчання тут гірше за рядок.
    if not any(a["ours"] for a in sit["awards"]):
        doc.add_paragraph(
            "Вашої пропозиції серед нагород немає: майданчик визначає нагороду "
            "лише на поточного лідера. Якщо його відхилять, наступного за ціною "
            "система визначить автоматично — див. таблицю правил нижче.")
    if sit.get("participants"):
        doc.add_paragraph("Учасники, яких віддає майданчик:")
        for b in sit["participants"]:
            p = doc.add_paragraph(style="List Bullet")
            p.add_run("%s — %s%s" % (b["name"], b["amount"],
                                     " (ВАША пропозиція)" if b["ours"] else ""))

    doc.add_heading("3. Правила саме цієї процедури", level=1)
    table = doc.add_table(rows=1, cols=3)
    table.style = "Table Grid"
    hdr = table.rows[0].cells
    hdr[0].text = "Що"
    hdr[1].text = "Строк / правило"
    hdr[2].text = "Норма (звірено з оригіналом)"
    for n in pos["norms"]:
        cells = table.add_row().cells
        cells[0].text = n.get("topic") or ""
        cells[1].text = n.get("value") or ""
        cell = "%s, %s (звірено %s)" % (n.get("act") or "", n.get("ref") or "",
                                        n.get("checked_at") or "")
        if n.get("live_note"):
            cell += "\n[!] " + n["live_note"]
        cells[2].text = cell
    for row in table.rows:
        row._tr.get_or_add_trPr().append(_cant_split())

    if pos["not_available"]:
        doc.add_heading("4. Чого в цій процедурі НЕМАЄ", level=1)
        for n in pos["not_available"]:
            p = doc.add_paragraph(style="List Bullet")
            p.add_run("%s: %s. " % (n.get("topic"), n.get("value"))).bold = True
            p.add_run("Чому: %s." % n.get("why"))
            if n.get("instead"):
                doc.add_paragraph("Замість цього: %s" % n["instead"])

    doc.add_heading("%d. Що робити" % (5 if pos["not_available"] else 4), level=1)
    for i, st in enumerate(steps(pos, sit), 1):
        p = doc.add_paragraph()
        p.add_run("Крок %d. %s" % (i, st["title"])).bold = True
        doc.add_paragraph("Чому: %s" % st["why"])
        doc.add_paragraph("Що зробити: %s" % st["what"])

    doc.add_heading("Звідки взяті дані", level=1)
    doc.add_paragraph("Факти про тендер — офіційний майданчик Prozorro, "
                      "завантажено %s." % today.strftime("%d.%m.%Y, %H:%M"))
    doc.add_paragraph("Норми — база «Законодавство України» (Верховна Рада). "
                      "Дата звірки кожної норми стоїть у таблиці.")
    doc.add_paragraph("Цей документ склала система без участі мовної моделі: "
                      "числа взяті з API, строки — з бази звірених норм.")

    out_dir = os.path.dirname(os.path.abspath(out_path))
    if out_dir and not os.path.isdir(out_dir):
        os.makedirs(out_dir)
    doc.save(out_path)
    return out_path


def _cant_split():
    """Рядок таблиці не рветься між сторінками (домовленість 27.07.2026)."""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    el = OxmlElement("w:cantSplit")
    el.set(qn("w:val"), "true")
    return el


def run(tender_id, out_path, our_edrpou=None, today=None):
    """Жива збірка: сам ходить у Прозорро. Потребує мережі."""
    if src is None:
        raise TenderDocError("джерело тендерів недоступне")
    uuid = src.index_uuid(tender_id) or src.resolve(tender_id)
    if isinstance(uuid, dict):
        uuid = uuid.get("uuid")
    if not uuid:
        raise TenderDocError("номер %s не розвʼязано в uuid" % tender_id)
    card = src.fetch_card(uuid)
    awards = src.awards(uuid)
    try:
        bids = src.bids(uuid)
    except Exception:
        bids = []
    return build(tender_id, card, awards, out_path,
                 our_edrpou=our_edrpou, today=today, bids=bids)
