# -*- coding: utf-8 -*-
"""
tender_analytics.py — РАХУЄ КОД, НЕ МОДЕЛЬ.

НАВІЩО ОКРЕМИЙ МОДУЛЬ (дисципліна 4 питань, Статут №15).
  КЛАС проблеми: аналітичний висновок містить числа, яких НЕМА В ЖОДНІЙ картці —
  «середня ціна», «скільки закупівель», «скільки замовників». Звіряч фактів
  (tender_fact_check) звіряє факт проти ОДНІЄЇ картки тендера; у середньої ціни
  картки немає, звіряти нема з чим. Отже аналітика — це той самий «майбутній
  канал», крізь який вигадане число вийшло б повз наші ворота.
  ТОЧКА РІШЕННЯ: жодне агреговане число не має права народитися в тексті моделі.
  Його рахує цей модуль з карток джерела, а звіряч потім ПЕРЕРАХОВУЄ і порівнює.

ПЕЧАТКА ДОКАЗОВОСТІ. Кожна метрика несе: скільки карток реально враховано, зі
скількох у вибірці, і сама вибірка друкується списком номерів. Людина може
перерахувати руками; код перераховує автоматично.

⚠ ЧЕСНА МЕЖА — ЧОГО ТУТ НЕМАЄ І ЧОМУ.
  Кількості учасників і «ціна впала на X %» тут НЕМАЄ. Пошукова видача Прозоро
  (`brief()`) полів `bids`/`awards` не віддає — вони лише в повній картці
  (`fetch_card`), а до неї потрібен власний індекс tenderID→uuid, якого ще немає.
  Вигадувати ці числа заборонено: краще менше метрик, ніж правдоподібні.
  Коли зʼявиться індекс — метрики додаються сюди, і ворота їх підхоплять самі.

Лише stdlib. Мережі тут немає свідомо: на вхід ідуть уже здобуті картки.
"""


def _amounts(records):
    """Суми з карток, де сума РЕАЛЬНО є. Порожнє поле не перетворюємо на 0 —
    нуль спотворив би середнє й став би тихою неправдою."""
    out = []
    for r in (records or []):
        a = (r or {}).get("amount")
        if a is None:
            continue
        try:
            out.append(float(a))
        except (TypeError, ValueError):
            continue
    return sorted(out)


def _median(vals):
    n = len(vals)
    if not n:
        return None
    mid = n // 2
    return vals[mid] if n % 2 else (vals[mid - 1] + vals[mid]) / 2.0


def fmt_money(amount, currency="UAH"):
    """1234567.891 -> '1 234 567.89 UAH'. Формат один на всю платформу."""
    if amount is None:
        return None
    left, right = ("%.2f" % float(amount)).split(".")
    sign = "-" if left.startswith("-") else ""
    left = left.lstrip("-")
    groups = []
    while len(left) > 3:
        groups.insert(0, left[-3:])
        left = left[:-3]
    groups.insert(0, left)
    return "%s%s.%s %s" % (sign, " ".join(groups), right, currency or "UAH")


def _currency(records):
    """Валюта вибірки. Різні валюти -> None (змішувати НЕ можна)."""
    cur = {(r or {}).get("currency") for r in (records or []) if (r or {}).get("amount") is not None}
    cur.discard(None)
    return cur.pop() if len(cur) == 1 else None


# Порядок = порядок у повідомленні. Ключ — машинний, label — людський.
METRIC_KEYS = ("count", "sum_amount", "mean_amount", "median_amount",
               "min_amount", "max_amount", "buyers_count")

_LABELS = {
    "count": "Закупівель у вибірці",
    "sum_amount": "Сумарна очікувана вартість",
    "mean_amount": "Середня очікувана вартість",
    "median_amount": "Медіанна очікувана вартість",
    "min_amount": "Найменша очікувана вартість",
    "max_amount": "Найбільша очікувана вартість",
    "buyers_count": "Різних замовників",
}


def compute(records, keys=None):
    """Рахує метрики з карток. -> [{key,label,value,text,used,total}].

    used  — скільки карток реально дали число (напр. сума є не всюди).
    total — розмір вибірки.
    Метрика, яку порахувати нема з чого (used=0), НЕ повертається взагалі —
    порожнє місце чесніше за нуль.
    """
    records = [r for r in (records or []) if r]
    total = len(records)
    amounts = _amounts(records)
    cur = _currency(records)
    buyers = {(r.get("buyer") or "").strip() for r in records}
    buyers.discard("")

    raw = {
        "count": (total, total),
        "sum_amount": (sum(amounts) if amounts else None, len(amounts)),
        "mean_amount": ((sum(amounts) / len(amounts)) if amounts else None, len(amounts)),
        "median_amount": (_median(amounts), len(amounts)),
        "min_amount": (amounts[0] if amounts else None, len(amounts)),
        "max_amount": (amounts[-1] if amounts else None, len(amounts)),
        "buyers_count": (len(buyers) if buyers else None, total if buyers else 0),
    }

    out = []
    for k in (keys or METRIC_KEYS):
        if k not in raw:
            continue
        value, used = raw[k]
        if value is None or used == 0:
            continue
        text = (fmt_money(value, cur) if k.endswith("_amount") and cur
                else (fmt_money(value, "") .strip() if k.endswith("_amount") else str(int(value))))
        out.append({"key": k, "label": _LABELS[k], "value": float(value),
                    "text": text, "used": used, "total": total})
    return out


def value_of(records, key):
    """Значення однієї метрики (для перерахунку звірячем). Немає — None."""
    for m in compute(records, keys=(key,)):
        if m["key"] == key:
            return m
    return None
