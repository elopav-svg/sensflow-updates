# -*- coding: utf-8 -*-
"""
tender_defender.py — ЗАХИСНИК: стежить за долею ВЖЕ ПОДАНИХ пропозицій.

ЧОМУ ЦЕЙ МОДУЛЬ ІСНУЄ (дисципліна 4 питань, Статут №15, 27.07.2026).

  КЛАС ПРОБЛЕМИ: сторож дивиться лише на НОВІ оголошення. За тим, що
  відбувається з тендером, куди клієнт УЖЕ подався, не стежив ніхто.
  Каспер дізнався про програш власного тендера сам і сказав про це в розмові —
  система про це не знала й знати не могла. Найдорожчі події трапляються ПІСЛЯ
  подання: визначення переможця, відкриття вікна на скаргу, відхилення
  переможця (і тоді черга доходить до наступного — а Каспер саме другий).

  ТОЧКА РІШЕННЯ: тут. Один модуль знає, ЩО вважати подією і коли бити на сполох.
  Не в сторожі (він про інше) і не в повідомленні (воно про подачу фактів).

  ВСІ КАНАЛИ: Telegram, майбутні звіт і кабінет — усі беруть події звідси.

  ЧИ ПРОТЕЧЕ МАЙБУТНІЙ КАНАЛ: ні. Події — тут, факти — з джерела, текст — через
  ті самі ворота повідомлення з печаткою.

⭐ ЩО САМЕ ВВАЖАЄМО ПОДІЄЮ (усе — ФАКТИ З ДЖЕРЕЛА, не тлумачення):
  1. `complaint_window`  — у нагороді ЗʼЯВИВСЯ `complaintPeriod`. Доведено
     27.07.2026 на 13 нагородах: він виникає рівно в момент публікації рішення
     і триває ≈5 днів. Це найдорожча подія: вікно коротке.
  2. `award_status`      — статус нагороди змінився (pending -> active /
     unsuccessful / cancelled).
  3. `new_award`         — зʼявилась НОВА нагорода: попереднього переможця
     відхилили, черга зрушила. Для того, хто другий, це шанс.
  4. `period_ends_soon`  — `period` (строк рішення ЗАМОВНИКА) спливає скоро.

🔴 ЧОГО ЦЕЙ МОДУЛЬ НЕ РОБИТЬ І НЕ БУДЕ:
  Він НЕ тлумачить закон. `complaintPeriod` він називає «вікном, у яке за
  даними майданчика подають скарги», а не «строком оскарження за законом» —
  правова природа не встановлена, доступ до тексту постанови в нас закритий.
  Хто плутає факт майданчика з нормою закону, той підставляє клієнта.
  [[project_casper_words_and_lost_tender]]

🔩 ПАМʼЯТЬ: подія шлеться ОДИН раз. Ознака події — її відбиток (fingerprint),
  а не час: якщо нічого не змінилось, повторного сповіщення немає.
"""
import json
import os
from datetime import datetime

STATE_FILE = "tender_defender_state.json"

COMPLAINT_WINDOW = "complaint_window"
AWARD_STATUS = "award_status"
NEW_AWARD = "new_award"
PERIOD_SOON = "period_ends_soon"

# За скільки днів до кінця `period` нагадувати.
SOON_DAYS = 3


def _state_path():
    return os.path.join(os.path.dirname(os.path.abspath(__file__)), STATE_FILE)


def load_state(path=None):
    try:
        with open(path or _state_path(), encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"tenders": {}, "sent": []}


def save_state(state, path=None):
    with open(path or _state_path(), "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=1)


def _iso_to_ddmmyyyy(s):
    """'2026-08-04T00:00:00+03:00' -> '04.08.2026'. Не розібрали -> None."""
    try:
        return "%s.%s.%s" % (s[8:10], s[5:7], s[0:4])
    except Exception:
        return None


def _days_left(iso, today=None):
    try:
        end = datetime(int(iso[0:4]), int(iso[5:7]), int(iso[8:10]))
    except Exception:
        return None
    now = today or datetime.now()
    return (end - datetime(now.year, now.month, now.day)).days


def snapshot(award_list):
    """Сирі нагороди -> нормалізований знімок. Тільки поля, які ми показуємо."""
    out = {}
    for a in (award_list or []):
        if not isinstance(a, dict):
            continue
        sup = (a.get("suppliers") or [{}])[0] or {}
        ident = sup.get("identifier") or {}
        cp = a.get("complaintPeriod") or {}
        per = a.get("period") or {}
        val = a.get("value") or {}
        out[str(a.get("id") or "")] = {
            "status": a.get("status") or "",
            "date": a.get("date") or "",
            "supplier": sup.get("name") or "",
            "edrpou": str(ident.get("id") or ""),
            "amount": val.get("amount"),
            "currency": val.get("currency") or "UAH",
            "complaint_start": cp.get("startDate") or "",
            "complaint_end": cp.get("endDate") or "",
            "period_end": per.get("endDate") or "",
        }
    return out


def _fp(kind, tender_id, award_id, extra=""):
    """Відбиток події: те саме -> не шлемо вдруге."""
    return "|".join([kind, str(tender_id), str(award_id), str(extra)])


def diff(tender_id, old, new, today=None):
    """Старий і новий знімки -> список подій. Порядок — від найдорожчої."""
    events = []
    old = old or {}
    for aid, cur in (new or {}).items():
        was = old.get(aid)

        if was is None and old:
            # Нова нагорода при вже відомій історії = черга зрушила.
            events.append({"kind": NEW_AWARD, "tender_id": tender_id, "award_id": aid,
                           "fp": _fp(NEW_AWARD, tender_id, aid, cur.get("date")),
                           "supplier": cur.get("supplier"), "edrpou": cur.get("edrpou"),
                           "amount": cur.get("amount"), "currency": cur.get("currency"),
                           "status": cur.get("status")})

        if cur.get("complaint_end") and (not was or not was.get("complaint_end")):
            events.append({"kind": COMPLAINT_WINDOW, "tender_id": tender_id, "award_id": aid,
                           "fp": _fp(COMPLAINT_WINDOW, tender_id, aid, cur.get("complaint_end")),
                           "window_from": _iso_to_ddmmyyyy(cur.get("complaint_start")),
                           "window_to": _iso_to_ddmmyyyy(cur.get("complaint_end")),
                           "days_left": _days_left(cur.get("complaint_end"), today),
                           "supplier": cur.get("supplier"), "status": cur.get("status")})

        if was and was.get("status") != cur.get("status"):
            events.append({"kind": AWARD_STATUS, "tender_id": tender_id, "award_id": aid,
                           "fp": _fp(AWARD_STATUS, tender_id, aid, cur.get("status")),
                           "was": was.get("status"), "now": cur.get("status"),
                           "supplier": cur.get("supplier"), "amount": cur.get("amount"),
                           "currency": cur.get("currency")})

        pe = cur.get("period_end")
        if pe:
            left = _days_left(pe, today)
            if left is not None and 0 <= left <= SOON_DAYS:
                events.append({"kind": PERIOD_SOON, "tender_id": tender_id, "award_id": aid,
                               "fp": _fp(PERIOD_SOON, tender_id, aid, _iso_to_ddmmyyyy(pe)),
                               "period_to": _iso_to_ddmmyyyy(pe), "days_left": left,
                               "status": cur.get("status")})
    order = {COMPLAINT_WINDOW: 0, NEW_AWARD: 1, AWARD_STATUS: 2, PERIOD_SOON: 3}
    events.sort(key=lambda e: order.get(e["kind"], 9))
    return events


def check(watch_list=None, fetch_awards=None, resolve_uuid=None, state=None,
          today=None, remember=True, state_path=None):
    """Один обхід Захисника.

    fetch_awards / resolve_uuid — підмінні свідомо: чек мусить перевіряти
    ПОВЕДІНКУ, а не мережу.

    -> {events, fresh, checked, problems, complete, state}
       fresh — події, яких людина ще НЕ бачила (за відбитком).
    """
    if watch_list is None:
        try:
            import tender_profile
            watch_list = tender_profile.watched()
        except Exception:
            watch_list = []
    if fetch_awards is None or resolve_uuid is None:
        import tender_source_ua as TS
        import tender_index as TI
        fetch_awards = fetch_awards or TS.awards
        resolve_uuid = resolve_uuid or (lambda tid: TI.resolve_uuid(tid))

    state = state if state is not None else load_state(state_path)
    state.setdefault("tenders", {})
    state.setdefault("sent", [])
    events, problems, checked = [], [], 0

    for w in (watch_list or []):
        tid = (w.get("tender_id") or "").strip()
        if not tid:
            continue
        uuid = (w.get("uuid") or "").strip()
        if not uuid:
            try:
                uuid = resolve_uuid(tid) or ""
            except Exception as e:
                problems.append("%s — не вдалося розвʼязати номер (%s)" % (tid, type(e).__name__))
                continue
        if not uuid:
            problems.append("%s — номер ще не знайдено в індексі" % tid)
            continue
        try:
            raw = fetch_awards(uuid)
        except Exception as e:
            problems.append("%s — джерело недоступне (%s)" % (tid, type(e).__name__))
            continue
        checked += 1
        new = snapshot(raw)
        events.extend(diff(tid, state["tenders"].get(tid), new, today))
        if remember:
            state["tenders"][tid] = new

    seen = set(state.get("sent") or [])
    fresh = [e for e in events if e["fp"] not in seen]
    return {"events": events, "fresh": fresh, "checked": checked,
            "problems": problems, "complete": not problems, "state": state}


def mark_sent(state, events):
    """Позначити події як показані — ЛИШЕ після реальної доставки."""
    seen = set(state.get("sent") or [])
    for e in (events or []):
        seen.add(e["fp"])
    state["sent"] = sorted(seen)
    return state
