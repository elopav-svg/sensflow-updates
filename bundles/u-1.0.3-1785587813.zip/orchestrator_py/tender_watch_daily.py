# -*- coding: utf-8 -*-
"""
tender_watch_daily.py — УВІМКНУТИ/ВИМКНУТИ щоденний тихий обхід сторожа.

Створює в планувальнику ТИХУ задачу (без моделі): нуль витрат на прогін.
Повторний запуск не плодить дублікатів.

Запуск: python tender_watch_daily.py [on|off|status]
"""
import sys

import scheduler

JOB = "tender_watch"
NAME = "Storozh tenderiv (shchodenno)"


def _mine():
    return [a for a in scheduler.list_automations()
            if (a.get("kind") or "") == "data_sync" and (a.get("job") or "") == JOB]


def main():
    cmd = (sys.argv[1] if len(sys.argv) > 1 else "status").lower()
    found = _mine()

    if cmd == "on":
        if found:
            for a in found:
                scheduler.set_enabled(a["id"], True)
            print("VZHE STVORENO - uvimkneno: %s" % ", ".join(a["id"] for a in found))
        else:
            rec = scheduler.create_data_sync(NAME, JOB, "щодня")
            print("STVORENO: %s | nastupnyy zapusk: %s" % (rec["id"], rec["next_run_at"]))
        print("Storozh bude khodyty sam raz na dobu. Modelʼ NE klychetsya - nul vytrat.")
        return 0

    if cmd == "off":
        if not found:
            print("NEMAYE takoyi zadachi - vymykaty nichoho.")
            return 0
        for a in found:
            scheduler.set_enabled(a["id"], False)
        print("VYMKNENO: %s" % ", ".join(a["id"] for a in found))
        return 0

    if not found:
        print("STATUS: shchodennyy obkhid NE stvoreno.")
    else:
        for a in found:
            print("STATUS: %s | uvimkneno=%s | nastupnyy zapusk: %s"
                  % (a["id"], a.get("enabled"), a.get("next_run_at")))
    return 0


if __name__ == "__main__":
    import run_log; run_log.start('tender_watch_daily')  # вивід прогону лягає у logs\ — читаю сам, без скрінів
    sys.exit(main())
