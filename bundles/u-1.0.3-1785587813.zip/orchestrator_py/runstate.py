"""
runstate.py — стан активних запусків для кооперативного переривання («Стоп»).

Користувач може зупинити роботу оркестратора. Переривання КООПЕРАТИВНЕ: рушій
перевіряє прапорець між кроками (між агентами, перед складанням) і чесно завершує
без створення файлів. Не перериває один LLM-виклик усередині — тобто реакція
настає після завершення поточного кроку (звичайно секунди).

Реєстр за токеном (client cancel_token або thread_id). Потокобезпечно.
"""

import threading

_lock = threading.Lock()
_cancelled = set()   # токени, для яких запитано зупинку


def request_cancel(token) -> bool:
    if not token:
        return False
    with _lock:
        _cancelled.add(str(token))
    return True


def is_cancelled(token) -> bool:
    if not token:
        return False
    with _lock:
        return str(token) in _cancelled


def clear(token) -> None:
    if not token:
        return
    with _lock:
        _cancelled.discard(str(token))
