# -*- coding: utf-8 -*-
"""
tender_legal_paper.py — зібрати папір «як діяти» по живому тендеру.

Запуск: Make tender action paper.bat
Мережу використовує (Прозорро + база норм). Мовну модель — НІ, тому
прогін безкоштовний.
"""
import datetime
import os
import sys

import run_log
import tender_legal_doc as doc

OUT_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "output")
DEFAULT_TENDER = "UA-2026-07-17-002005-a"


OWNER_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                          "knowledge_packs", "tender_casper", "owner.json")


def _own_edrpou():
    """ЄДРПОУ клієнта — щоб у папері було видно ЙОГО пропозицію.

    ⚠ Живий прогін 28.07.2026: без цього коду людина не бачила себе в списку
    взагалі. Просити вписувати код щоразу руками — вірний спосіб, щоб його не
    вписували ніколи. Тому він лежить у файлі поруч із профілем товару.
    """
    try:
        import json
        with open(OWNER_FILE, "r", encoding="utf-8") as fh:
            return (json.load(fh).get("edrpou") or "").strip() or None
    except Exception:
        return None


def main(argv):
    tender_id = argv[1] if len(argv) > 1 else DEFAULT_TENDER
    edrpou = argv[2] if len(argv) > 2 else _own_edrpou()
    if not edrpou:
        print("[!] ЄДРПОУ клієнта не задано (%s) — у папері не буде позначки"
              % os.path.basename(OWNER_FILE))
        print("    «ВАША пропозиція». Це не помилка, лише менше користі.")
    stamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
    out = os.path.join(OUT_DIR, "Тендер_%s_план_дій_%s.docx" % (tender_id, stamp))
    print("Тендер : %s" % tender_id)
    print("Файл   : %s" % out)
    try:
        path = doc.run(tender_id, out, our_edrpou=edrpou)
    except doc.TenderDocError as exc:
        print("")
        print("ДОКУМЕНТА НЕ БУДЕ. Причина:")
        print("  %s" % exc)
        print("")
        print("Це задумано так: краще одне питання, ніж папір із чужими строками.")
        return 2
    print("")
    print("ГОТОВО: %s" % path)
    return 0


if __name__ == "__main__":
    run_log.start("tender_legal_paper")
    sys.exit(main(sys.argv))
