"""
costs.py — оцінка вартості LLM-викликів за токенами (для показу в консолі)
та ЄДИНИЙ лічильник грошей, на якому тримаються всі стелі вартості.

Це ОЦІНКА, а не фактура: рахуємо за прайс-таблицею моделей × токени з відповідей
API (usage). Точні витрати — на сторінці білінгу провайдера. Ціни орієнтовні
(≈ 06.2026) і легко редагуються нижче.

⭐⭐⭐ 29.07.2026 (зміна 26). КОРІНЬ, ЯКИЙ ТУТ ВИЛІКУВАНО.
Раніше прогін відкривав ВИКЛИКАЧ (`engine.handle_message`), і рівно один. Тому
кожен інший вхід у платну роботу — автоматизації за розкладом, мозок підтримки,
сторож тендерів, розбір стилю — народжувався БЕЗ лічильника. А далі все мовчало:
`record()` при відсутньому прогоні просто нічого не писав, `spent_usd()` казав
«0», і мʼяка пауза в executor та аварійна межа в `llm._budget_stop()` бачили нуль
і відповідали «все гаразд». Клієнт міг створити автоматизацію й платити без межі.

ЛІКИ (три шари, кожен закриває свій клас):
  1. `run_scope()` — пара «відкрив–закрив» стала ОДНІЄЮ річчю. Забути половину
     пари більше не можна: `with costs.run_scope(...)` або є, або його немає.
  2. `ensure_run()` — сітка під усім: канал, який забули загорнути, не лишається
     без стелі. Прогін відкривається САМ, з базовою стелею, і канал НАЗИВАЄТЬСЯ
     в журналі. Безпечний стан — стан за замовчуванням, а не той, який треба
     свідомо ввімкнути [[project_run_cost_control]].
  3. ДЕННИЙ лічильник автоматизацій — стеля на прогін не рятує від 30 прогонів
     на добу. Гроші додаються в добовий рахунок ТАМ, ДЕ ВИТРАЧАЮТЬСЯ (`record`),
     а не в кінці прогону: інакше один прогін-утікач проскочив би денну межу
     цілком. Рахунок лежить у `config.STATE_DIR` і переживає перезапуск.
Рішення Андрія 29.07.2026: денна межа стосується ЛИШЕ безпілотних спрацювань за
розкладом. Питання людини в чаті (і ручний запуск на її команду) нею не
блокуються ніколи — інакше клієнт вранці впреться в стіну через нічну задачу.
"""
import json
import threading
from datetime import datetime

# Ціни $ за 1 МЛН токенів: (input, output). Орієнтир червень 2026. Редагуй за потреби.
PRICES = {
    "claude-opus-4-8": (15.0, 75.0),
    "claude-sonnet-4-6": (3.0, 15.0),
    "claude-haiku-4-5": (0.80, 4.0),
    "gpt-4.1": (2.0, 8.0),
    "gemini-2.5-pro": (1.25, 10.0),
    "gemini-2.5-flash": (0.30, 2.50),
}

_lock = threading.Lock()
_session = {"in": 0, "out": 0, "usd": 0.0, "calls": 0}
_local = threading.local()  # поточний прогін (per-request)

# Рід прогону. Від нього залежить ОДНЕ: чи йдуть гроші в добовий рахунок.
KIND_CHAT = "chat"                # людина за кермом: чат, ручний запуск на команду
KIND_AUTOMATION = "automation"    # безпілотне спрацювання за розкладом

# Прогін «без господаря» (канал, який забули загорнути в run_scope) не може жити
# вічно: інакше він накопичував би витрати в довгому потоці й зрештою заблокував
# би канал назавжди. Через цей час рахунок такого прогону починається заново.
ORPHAN_TTL_SEC = 900

_day_lock = threading.Lock()
_day = None      # {"date": "YYYY-MM-DD", "usd": float, "runs": int} — кеш добового рахунку


def _now():
    return datetime.now()


def _price(model: str):
    m = (model or "").lower()
    if m in PRICES:
        return PRICES[m]
    for k, v in PRICES.items():            # часткове співпадіння (версії/дати в назві)
        if k.lower() in m or m.startswith(k.lower()):
            return v
    return (0.0, 0.0)                        # невідома модель — не вгадуємо (0)


# ─────────────────────────── ДОБОВИЙ РАХУНОК АВТОМАТИЗАЦІЙ ───────────────────────────
# Лежить у config.STATE_DIR — тобто йде за перемикачем стану разом з усім іншим
# і НЕ смітить у бойові теки під час чеків [[project_state_isolation]].

def _day_path():
    import config
    d = config.STATE_DIR / "state"
    d.mkdir(parents=True, exist_ok=True)
    return d / "automation_day.json"


def _day_load() -> dict:
    """Прочитати добовий рахунок із диска (переживає перезапуск сервера)."""
    today = _now().strftime("%Y-%m-%d")
    try:
        rec = json.loads(_day_path().read_text(encoding="utf-8"))
        if str(rec.get("date")) == today:
            return {"date": today, "usd": float(rec.get("usd") or 0.0),
                    "runs": int(rec.get("runs") or 0)}
    except Exception:
        pass
    return {"date": today, "usd": 0.0, "runs": 0}


def _day_get() -> dict:
    """Поточний добовий рахунок. Сам перегортає добу на новій даті."""
    global _day
    today = _now().strftime("%Y-%m-%d")
    if _day is None or _day.get("date") != today:
        _day = _day_load()
        if _day.get("date") != today:
            _day = {"date": today, "usd": 0.0, "runs": 0}
    return _day


def _day_save():
    try:
        _day_path().write_text(json.dumps(_day, ensure_ascii=False), encoding="utf-8")
    except Exception:
        pass    # диск недоступний — межа лишається чинною в памʼяті цього процесу


def day_spent_usd() -> float:
    """Скільки автоматизації витратили СЬОГОДНІ, $."""
    with _day_lock:
        return float(_day_get().get("usd", 0.0) or 0.0)


def day_cap() -> float:
    """Денна стеля автоматизацій, $ (0 = межі немає, свідомо вимкнено)."""
    import config
    try:
        return float(getattr(config, "MAX_DAY_USD", 0.0) or 0.0)
    except Exception:
        return 0.0


def over_day_cap() -> bool:
    """Чи вичерпано денну межу автоматизацій. Чат людини цього не питає."""
    cap = day_cap()
    return cap > 0 and day_spent_usd() >= cap


def day_report() -> dict:
    """Для журналу й UI: скільки витрачено за добу, яка межа, скільки лишилось."""
    with _day_lock:
        cur = dict(_day_get())
    cap = day_cap()
    cur["cap"] = cap
    cur["left"] = max(0.0, cap - float(cur.get("usd", 0.0))) if cap > 0 else None
    return cur


def _day_add(usd: float):
    with _day_lock:
        cur = _day_get()
        cur["usd"] = float(cur.get("usd", 0.0)) + float(usd or 0.0)
        _day_save()


def _day_add_run():
    with _day_lock:
        cur = _day_get()
        cur["runs"] = int(cur.get("runs", 0)) + 1
        _day_save()


def day_reset():
    """Скинути добовий рахунок (для чеків і для ручного втручання)."""
    global _day
    with _day_lock:
        _day = {"date": _now().strftime("%Y-%m-%d"), "usd": 0.0, "runs": 0}
        _day_save()


def record(model: str, in_tok, out_tok):
    """Записати споживання одного виклику в сесію, поточний прогін і — якщо це
    безпілотна автоматизація — у ДОБОВИЙ рахунок.

    ⭐ Добові гроші додаються САМЕ ТУТ, а не в кінці прогону. Інакше один
    прогін-утікач витратив би денну межу цілком і лише потім про неї дізнався."""
    try:
        in_tok = int(in_tok or 0)
        out_tok = int(out_tok or 0)
    except Exception:
        return
    pi, po = _price(model)
    usd = in_tok / 1e6 * pi + out_tok / 1e6 * po
    with _lock:
        _session["in"] += in_tok
        _session["out"] += out_tok
        _session["usd"] += usd
        _session["calls"] += 1
    cur = getattr(_local, "run", None)
    if cur is not None:
        cur["in"] += in_tok
        cur["out"] += out_tok
        cur["usd"] += usd
        cur["calls"] += 1
        if cur.get("kind") == KIND_AUTOMATION:
            _day_add(usd)


def start_run(channel: str = "chat", kind: str = KIND_CHAT):
    """Почати облік нового прогону (скидає лічильник поточного запиту).

    channel — хто саме прийшов по гроші; потрапляє в журнал, коли канал забули
    загорнути. kind — KIND_CHAT (людина за кермом) або KIND_AUTOMATION
    (безпілотне спрацювання; лише його гроші йдуть у добовий рахунок)."""
    _local.run = {"in": 0, "out": 0, "usd": 0.0, "calls": 0,
                  "channel": str(channel or "?"), "kind": str(kind or KIND_CHAT),
                  "owned": True, "opened_at": _now().timestamp()}
    _local.cap = 0.0  # стелю ставить executor під конкретний прогін; стара не тягнеться
    if kind == KIND_AUTOMATION:
        _day_add_run()


def end_run() -> dict:
    """Завершити прогін і повернути його підсумок."""
    cur = getattr(_local, "run", None)
    _local.run = None
    _local.cap = 0.0
    return dict(cur) if cur else {"in": 0, "out": 0, "usd": 0.0, "calls": 0}


class run_scope:
    """⭐ ПАРА «ВІДКРИВ–ЗАКРИВ» ОДНІЄЮ РІЧЧЮ.

    Раніше це були два окремі рядки в різних кінцях функції — і саме тому в
    автоматизаціях забули перший. Тепер забути половину пари неможливо:

        with costs.run_scope("автоматизація", costs.KIND_AUTOMATION):
            ...

    Вкладення безпечне: якщо прогін уже відкритий, внутрішній `with` його НЕ
    перезаводить і НЕ закриває (інакше зовнішній лічильник обнулився б посеред
    роботи). Підсумок прогону доступний як `scope.result` після виходу."""

    def __init__(self, channel: str = "chat", kind: str = KIND_CHAT):
        self.channel = channel
        self.kind = kind
        self.result = {"in": 0, "out": 0, "usd": 0.0, "calls": 0}
        self._owner = False

    def __enter__(self):
        cur = getattr(_local, "run", None)
        # Прогін «без господаря» (його завів ensure_run) господаря отримує тут.
        if cur is None or not cur.get("owned"):
            start_run(self.channel, self.kind)
            self._owner = True
        return self

    def __exit__(self, exc_type, exc, tb):
        if self._owner:
            self.result = end_run()
        return False    # виняток не ковтаємо: обрив за вартістю мусить бути видно


def ensure_run(channel: str = "?") -> bool:
    """СІТКА ПІД УСІМ: канал, який забули загорнути в run_scope, не лишається без
    лічильника й без стелі. Повертає True, якщо прогін довелося заводити самому.

    Чому не «впасти з помилкою»: fail-closed тут зупинив би живий канал у клієнта
    через мою недодивку. Тому безпечна поведінка — завести прогін із БАЗОВОЮ
    стелею і НАЗВАТИ канал у журналі, щоб недодивка була видна одразу. Ворота, які
    ловлять це до збірки, стоять окремо (`automation_cost_test`)."""
    cur = getattr(_local, "run", None)
    if cur is not None:
        if cur.get("owned"):
            return False
        # безгосподарний прогін не живе вічно — інакше він накопичував би витрати
        # в довгому потоці й зрештою заблокував би канал назавжди
        if (_now().timestamp() - float(cur.get("opened_at") or 0)) < ORPHAN_TTL_SEC:
            return False
    _local.run = {"in": 0, "out": 0, "usd": 0.0, "calls": 0,
                  "channel": str(channel or "?"), "kind": KIND_CHAT,
                  "owned": False, "opened_at": _now().timestamp()}
    import config
    _local.cap = float(getattr(config, "MAX_RUN_USD", 0.0) or 0.0)
    # Журнал сервера — це його stdout (`run_log.start("server")` у `server.main()`),
    # тому голос тут — звичайний print: рядок сам ляже в logs\server_*.log.
    try:
        print("[costs] КАНАЛ БЕЗ ЛІЧИЛЬНИКА: %s — заведено прогін зі стелею $%.2f"
              % (channel, _local.cap), flush=True)
    except Exception:
        pass
    return True


def current_kind() -> str:
    cur = getattr(_local, "run", None)
    return str((cur or {}).get("kind") or KIND_CHAT)


def set_run_cap(usd):
    """Стеля ЦЬОГО прогону в $ (0 = вимкнено). Ставить executor на початку прогону.

    ⭐ 28.07.2026. Раніше стеля жила ЛИШЕ в executor і перевірялась МІЖ кроками —
    тому один дорогий крок (фінальна збірка на дорогому мозку) вивіз прогін на
    $2.51 при стелі $1.00, і жодна перевірка не встигла спрацювати. Стеля мусить
    бути там, де ВИТРАЧАЮТЬСЯ гроші, тобто поруч із лічильником."""
    _local.cap = float(usd or 0.0)


def run_cap() -> float:
    return float(getattr(_local, "cap", 0.0) or 0.0)


def spent_usd() -> float:
    return float(current_run().get("usd", 0.0) or 0.0)


def over_hard_cap(factor=2.0) -> bool:
    """АВАРІЙНА межа: жоден окремий виклик не має права вивезти прогін далі, ніж
    удвічі за стелю. Це не заміна мʼякій зупинці (вона зупиняє НОВІ кроки), а
    останній запобіжник проти втечі вартості всередині одного кроку."""
    cap = run_cap()
    return cap > 0 and spent_usd() >= cap * factor


def current_run() -> dict:
    """Поточний (незавершений) прогін — для бюджетного запобіжника, БЕЗ скидання."""
    cur = getattr(_local, "run", None)
    return dict(cur) if cur else {"in": 0, "out": 0, "usd": 0.0, "calls": 0}


def session() -> dict:
    with _lock:
        return dict(_session)
