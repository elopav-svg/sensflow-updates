# -*- coding: utf-8 -*-
"""
egress_guard.py — ВОРОТА ВИХОДУ НАЗОВНІ для режиму максимального збереження (Стелс).

Навіщо: у режимі повної локальної ізоляції (config.LLM_PROVIDER == "local") ЖОДЕН
вихід у мережу не має статися БЕЗ явного дозволу користувача. Цей модуль — одне
місце, що:
  1) визначає, чи запит узагалі потребує виходу назовні (поки що — юридична норма:
     точна звірка в офіційній базі «Законодавство України» ВРУ);
  2) веде НЕЗМІННИЙ append-журнал усіх подій виходу (запит / дозвіл / відмова / факт /
     блокування) — його можна показати як доказ «нічого не виходило без дозволу»;
  3) допоміжні перевірки режиму.

Сам жорсткий БЛОК виходу стоїть глибше — у спільному читачі netfetch.get_text()
(єдине вікно назовні). Тут — облік і розпізнавання наміру для UI.

Тільки стандартна бібліотека. Журнал — JSONL у runs/egress_log.jsonl.
"""

import os
import json
import datetime

import legal_source_ua  # детектор юр-норми (reuse resolve_nreg / resolve_article)

_DIR = os.path.dirname(os.path.abspath(__file__))
_LOG = os.path.join(_DIR, "runs", "egress_log.jsonl")


def _now() -> str:
    """Локальний час у форматі DD.MM.YYYY HH:MM:SS (без зовнішніх залежностей)."""
    return datetime.datetime.now().strftime("%d.%m.%Y %H:%M:%S")


def stealth_on() -> bool:
    """Чи активний режим максимального збереження (повна локальна ізоляція)."""
    try:
        import config
        return getattr(config, "LLM_PROVIDER", "") == "local"
    except Exception:
        return False


def detect(message: str, files_context: str = ""):
    """Чи потребує запит виходу назовні і якого роду.
    Повертає None (виходу не треба) або
    {"kind": "legal", "target": ..., "reason": ..., "nreg": ..., "article": ...}."""
    msg = message or ""
    # Юридична норма → ВУЗЬКА звірка в офіційній базі ВРУ (детерміновано, не залежить
    # від «розуму» слабкої локальної моделі — тому надійно спрацьовує на демо).
    try:
        nreg = legal_source_ua.resolve_nreg(msg)
    except Exception:
        nreg = None
    if nreg:
        try:
            art = legal_source_ua.resolve_article(msg)
        except Exception:
            art = None
        title = legal_source_ua.NREG_TITLE.get(nreg) or ("документ № " + nreg)
        target = "офіційна база «Законодавство України» (data.rada.gov.ua, ВРУ)"
        reason = "звірити чинний текст " + (("статті " + art + " ") if art else "") + title
        return {"kind": "legal", "target": target, "reason": reason,
                "nreg": nreg, "article": art, "title": title}
    return None


def log(event: str, info: dict = None) -> dict:
    """Дописати подію у незмінний журнал виходів.
    event: 'request' | 'allowed' | 'denied' | 'fetched' | 'failed' | 'blocked'."""
    rec = {"ts": _now(), "event": event}
    if info:
        try:
            rec.update(info)
        except Exception:
            pass
    try:
        os.makedirs(os.path.dirname(_LOG), exist_ok=True)
        with open(_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:
        pass
    return rec


def tail(n: int = 50) -> list:
    """Останні n записів журналу (найновіші — в кінці). Для показу в UI / на демо."""
    try:
        with open(_LOG, encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        return []
    out = []
    for ln in lines[-n:]:
        ln = ln.strip()
        if not ln:
            continue
        try:
            out.append(json.loads(ln))
        except Exception:
            pass
    return out
