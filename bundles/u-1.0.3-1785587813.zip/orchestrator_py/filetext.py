"""
filetext.py — витяг тексту з прикріплених файлів (для подачі агентам як вхід).

Працює з сирими байтами (файли приходять у чат як base64). Опційні бібліотеки
(python-docx, openpyxl, pypdf) визначаються під час виконання — без них формати
docx/xlsx/pdf просто позначаються як недоступні, рушій не падає.
"""

import io
import csv

MAX_CHARS = 20000  # стеля тексту на файл, щоб не роздувати контекст


def _cap(text: str) -> str:
    if text and len(text) > MAX_CHARS:
        return text[:MAX_CHARS] + f"\n\n…[обрізано, показано перші {MAX_CHARS} символів]"
    return text or ""


def _ext(name: str) -> str:
    return ("." + name.rsplit(".", 1)[-1].lower()) if "." in name else ""


def _decode(raw: bytes) -> str:
    for enc in ("utf-8-sig", "utf-8", "cp1251", "latin-1"):
        try:
            return raw.decode(enc)
        except Exception:
            continue
    return raw.decode("utf-8", errors="replace")


def _from_docx(raw: bytes) -> str:
    try:
        import docx
    except Exception:
        return "[docx не розпізнано: встановіть python-docx]"
    try:
        d = docx.Document(io.BytesIO(raw))
        parts = [p.text for p in d.paragraphs if p.text and p.text.strip()]
        for table in d.tables:
            for row in table.rows:
                cells = [c.text.strip() for c in row.cells]
                if any(cells):
                    parts.append(" | ".join(cells))
        return "\n".join(parts)
    except Exception as e:
        return f"[помилка читання docx: {e}]"


def _from_xlsx(raw: bytes) -> str:
    try:
        import openpyxl
    except Exception:
        return "[xlsx не розпізнано: встановіть openpyxl]"
    try:
        wb = openpyxl.load_workbook(io.BytesIO(raw), read_only=True, data_only=True)
        out = []
        for ws in wb.worksheets:
            out.append(f"# Аркуш: {ws.title}")
            for i, row in enumerate(ws.iter_rows(values_only=True)):
                if i > 500:
                    out.append("…[обрізано рядки]")
                    break
                vals = ["" if c is None else str(c) for c in row]
                if any(v.strip() for v in vals):
                    out.append(" | ".join(vals))
        return "\n".join(out)
    except Exception as e:
        return f"[помилка читання xlsx: {e}]"


def _from_pdf(raw: bytes) -> str:
    try:
        import pypdf
    except Exception:
        try:
            import PyPDF2 as pypdf  # запасний варіант
        except Exception:
            return "[pdf не розпізнано: встановіть pypdf]"
    try:
        reader = pypdf.PdfReader(io.BytesIO(raw))
        pages = []
        for i, page in enumerate(reader.pages):
            if i > 80:
                pages.append("…[обрізано сторінки]")
                break
            try:
                pages.append(page.extract_text() or "")
            except Exception:
                pages.append("")
        text = "\n".join(pages).strip()
        return text or "[pdf без текстового шару — можливо, скан без OCR]"
    except Exception as e:
        return f"[помилка читання pdf: {e}]"


def _from_csv(raw: bytes) -> str:
    text = _decode(raw)
    try:
        rows = list(csv.reader(io.StringIO(text)))
        return "\n".join(" | ".join(r) for r in rows[:600])
    except Exception:
        return text


def extract_text(name: str, raw: bytes) -> str:
    ext = _ext(name)
    if ext == ".docx":
        return _cap(_from_docx(raw))
    if ext in (".xlsx", ".xlsm"):
        return _cap(_from_xlsx(raw))
    if ext == ".pdf":
        return _cap(_from_pdf(raw))
    if ext in (".csv", ".tsv"):
        return _cap(_from_csv(raw))
    if ext in (".txt", ".md", ".json", ".log", ".yaml", ".yml", ".html", ".xml"):
        return _cap(_decode(raw))
    # невідомий тип: спроба як текст
    text = _decode(raw)
    printable = sum(1 for ch in text[:500] if ch.isprintable() or ch in "\n\r\t")
    if text and printable / max(1, min(len(text), 500)) > 0.85:
        return _cap(text)
    return f"[формат {ext or '?'} не підтримується для витягу тексту]"


def build_files_context(files: list) -> tuple:
    """
    files: [{'name': str, 'b64': 'data:...;base64,XXXX' або чистий base64}]
    Повертає (files_context_text, [meta]) де meta = {'name','chars'}.
    """
    import base64
    blocks = []
    meta = []
    for f in files or []:
        name = (f.get("name") or "file").strip()
        b64 = f.get("b64") or ""
        if "," in b64 and b64.strip().startswith("data:"):
            b64 = b64.split(",", 1)[1]
        try:
            raw = base64.b64decode(b64)
        except Exception:
            blocks.append(f"## Файл: {name}\n[не вдалося декодувати вміст]")
            meta.append({"name": name, "chars": 0})
            continue
        text = extract_text(name, raw)
        blocks.append(f"## Файл: {name}\n{text}")
        meta.append({"name": name, "chars": len(text)})
    return ("\n\n".join(blocks), meta)
