#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
keepawake.py — не дає Windows заснути, поки працює застосунок (важливо для демо).

Поки запущено run.bat / server.py, система й екран не йдуть у сон. Це не змінює
налаштувань живлення глобально: щойно застосунок закриється — звичайна поведінка
сну повертається сама. На не-Windows платформах — нічого не робить.
"""
import sys
import threading
import time

_ES_CONTINUOUS = 0x80000000
_ES_SYSTEM_REQUIRED = 0x00000001
_ES_DISPLAY_REQUIRED = 0x00000002


def _assert_awake():
    import ctypes
    ctypes.windll.kernel32.SetThreadExecutionState(
        _ES_CONTINUOUS | _ES_SYSTEM_REQUIRED | _ES_DISPLAY_REQUIRED
    )


def start() -> bool:
    """Вмикає режим «не засинати». Повертає True, якщо застосовано (лише Windows)."""
    if not sys.platform.startswith("win"):
        return False
    try:
        _assert_awake()

        def _loop():
            # Періодично підтверджуємо запит — на випадок, якщо ОС його скине.
            while True:
                try:
                    _assert_awake()
                except Exception:
                    return
                time.sleep(60)

        threading.Thread(target=_loop, daemon=True).start()
        return True
    except Exception:
        return False
