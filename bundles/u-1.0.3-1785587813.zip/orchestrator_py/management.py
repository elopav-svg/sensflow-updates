"""
management.py — самокерування: життєвий цикл систем оркестру.

Безпечні локальні операції над реєстром (не над зовнішнім світом):
  - smoke_test: проганяє систему на тестовій задачі і перевіряє результат;
  - activate / deactivate: змінює статус (needs_review/inactive <-> active);
  - prune_missing: прибирає з реєстру системи, чиї папки зникли;
  - status_overview: зведення систем за статусами.

Замикає цикл: виявлено -> осмислено -> виконано -> перевірено -> АКТИВОВАНО.
"""

import re

import registry
import executor
import verifier


def status_overview() -> dict:
    by = {}
    for s in registry.load_systems():
        by.setdefault(s.get("status", "?"), []).append(s.get("id"))
    return by


def _smoke_task(system: dict) -> str:
    """Бере тестову задачу з system.yaml/SMOKE_TEST.md, інакше — з осмисленої логіки."""
    root = registry.system_root(system)
    # 1) integration_smoke_test.test_task у system.yaml
    yml = root / "system.yaml"
    if yml.exists():
        try:
            txt = yml.read_text(encoding="utf-8-sig")
            m = re.search(r'test_task\s*:\s*"?([^"\n]+)"?', txt)
            if m:
                return m.group(1).strip()
        except Exception:
            pass
    # 2) SMOKE_TEST.md — перший змістовний абзац
    smk = root / "SMOKE_TEST.md"
    if smk.exists():
        try:
            for line in smk.read_text(encoding="utf-8-sig").splitlines():
                s = line.strip().lstrip("#-*").strip()
                if len(s) > 20:
                    return s[:300]
        except Exception:
            pass
    # 3) з осмисленої логіки
    try:
        import json
        p = root / ".orchestration_plan.json"
        if p.exists():
            plan = json.loads(p.read_text(encoding="utf-8")).get("plan", {})
            u = plan.get("system_understanding")
            if u:
                return f"Демонстраційний запуск системи на типовій задачі: {u}"
    except Exception:
        pass
    return f"Демонстраційний запуск системи «{system.get('name')}» на типовій для неї задачі."


def smoke_test(system_id: str) -> dict:
    """Проганяє систему і перевіряє результат. Повертає {ok, report, run_id, preview}."""
    system = registry.find_system(system_id)
    if not system:
        return {"ok": False, "report": f"Система «{system_id}» не знайдена."}
    task = _smoke_task(system)
    # allow_real_build=False: smoke-тест «Будівника систем» НЕ має створювати реальну
    # систему на тестовій задачі — лише перевіряє прохід конвеєра.
    exec_result = executor.run_system(system, task, precheck=False, allow_real_build=False)
    if exec_result.get("status") != "completed":
        return {"ok": False, "report": f"Smoke не завершився: {exec_result.get('status')}.",
                "preview": (exec_result.get("final_markdown") or "")[:300]}
    md = exec_result.get("final_markdown", "")
    gate = verifier.verify(task, md, criteria=exec_result.get("success_criteria"))
    checks = "; ".join(f"{'✓' if c['ok'] else '✗'} {c['label']}" for c in gate.get("checks", []))
    return {
        "ok": bool(gate.get("ok")),
        "report": f"Smoke {'пройдено' if gate.get('ok') else 'з зауваженнями'}: {checks}",
        "preview": md[:400],
        "agents": [t.get("agent") for t in exec_result.get("agent_trace", [])],
    }


def activate(system_id: str) -> dict:
    system = registry.find_system(system_id)
    if not system:
        return {"ok": False, "message": f"Система «{system_id}» не знайдена."}
    if system.get("status") == "missing":
        return {"ok": False, "message": "Систему позначено як зниклу (немає папки). Спершу відновіть її."}
    registry.update_system_status(system_id, "active")
    # Джерело істини — папка системи: статус має пережити наше оновлення
    # (яке затирає реєстр). Зберігаємо і живі налаштування, щоб не загубились.
    registry.write_folder_state(system, {
        "status": "active",
        "triggers": system.get("triggers", []),
        "priority": system.get("priority", 60),
        "sensitive": bool(system.get("sensitive", False)),
    })
    return {"ok": True, "message": f"Система «{system.get('name')}» активована.", "status": "active"}


def deactivate(system_id: str) -> dict:
    system = registry.find_system(system_id)
    if not system:
        return {"ok": False, "message": f"Система «{system_id}» не знайдена."}
    registry.update_system_status(system_id, "inactive")
    registry.write_folder_state(system, {"status": "inactive"})
    return {"ok": True, "message": f"Система «{system.get('name')}» деактивована.", "status": "inactive"}


def prune_missing() -> dict:
    reg = registry.load_registry()
    systems = reg.get("systems", [])
    removed = [s.get("id") for s in systems if s.get("status") == "missing"]
    if removed:
        reg["systems"] = [s for s in systems if s.get("status") != "missing"]
        registry.save_registry(reg)
    return {"ok": True, "removed": removed,
            "message": (f"Прибрано зниклих систем: {', '.join(removed)}" if removed
                        else "Зниклих систем немає.")}


def apply_action(action: str, system_id: str = None) -> dict:
    """Єдина точка для виконання дії керування (викликає engine/UI)."""
    action = (action or "").lower()
    if action == "activate":
        return activate(system_id)
    if action == "deactivate":
        return deactivate(system_id)
    if action == "smoke_test":
        return smoke_test(system_id)
    if action == "prune_missing":
        return prune_missing()
    if action in ("list_status", "status_overview"):
        return {"ok": True, "overview": status_overview()}
    return {"ok": False, "message": f"Невідома дія керування: {action}"}
