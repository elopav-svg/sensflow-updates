# База знань техпідтримки SensFlow (для бота «Клод» / TechCareSF)

_Відповідай простими словами, з конкретними кроками. Команди — одним чистим рядком, без зайвих символів._

## Запуск на Windows
1. Встановити Python 3 з python.org, при інсталяції увімкнути галочку «Add Python to PATH».
2. Розпакувати архів (наприклад, у C:\SensFlow).
3. Подвійний клік «Запустити SensFlow.bat». Перший запуск довший — ставляться залежності, це нормально.
4. У браузері відкриється консоль → на http://127.0.0.1:7799/setup вставити ключ.

## Запуск на macOS (надійний шлях — Terminal)
Виконати в Terminal по черзі (кожен рядок окремо, без хвостових символів):
- `xattr -dr com.apple.quarantine ~/Documents/SensFlow_pilot_MobilBench`
- `cd ~/Documents/SensFlow_pilot_MobilBench/orchestrator_py`
- `python3 server.py`
Перший рядок знімає блокування Apple (Gatekeeper) з усієї папки. Після `cd` запрошення в Terminal зміниться з `~` на `…orchestrator_py`. Після `python3 server.py` Terminal «висне» — це нормально, означає, що сервер працює; вікно не закривати.

## Часті помилки macOS
- **«Apple не удалось подтвердить, что файл .command не содержит вредоносного ПО»** → це Gatekeeper. Рішення: у Terminal `xattr -dr com.apple.quarantine ~/Documents/SensFlow_pilot_MobilBench`, після цього і подвійний клік по .command відкривається.
- **`can't open file '.../server.py'` або `server.pyython3`** → команда запущена не з тієї папки або зачеплено зайвий символ (напр. `\` у кінці). Рішення: спершу `cd ~/Documents/SensFlow_pilot_MobilBench/orchestrator_py`, тоді набрати вручну рівно `python3 server.py`.
- **`python3: command not found`** → не встановлено Python 3. Поставити з python.org (інсталятор для macOS).
- **`SSL: CERTIFICATE_VERIFY_FAILED ... unable to get local issuer certificate`** → Python на macOS не бачить кореневі сертифікати (типова особливість python.org-збірки, не вина SensFlow). Рішення: у Terminal виконати одну команду `open "/Applications/Python 3.14/Install Certificates.command"` (версію Python підставити свою — глянь у /Applications), дочекатись «update complete», тоді повторити запит у SensFlow. Запасний варіант: `pip3 install --upgrade certifi`.

## Часті помилки Windows
- **«python не распознаётся»** → під час інсталяції Python не була увімкнена галочка «Add Python to PATH». Перевстановити Python з галочкою.
- **Антивірус блокує** → дозволити / додати папку SensFlow у винятки.

## «Терминал у браузері?» — пояснення
Це два різних вікна. **Терминал** — чорне вікно, де вводять команди (його не закривати, там працює SensFlow). **Робоче вікно SensFlow** — звичайна веб-сторінка в браузері (http://127.0.0.1:7799), там і працюють. Аналогія: Терминал — мотор, браузер — руль.

## Куди вставити API-ключ
У браузері відкрити http://127.0.0.1:7799/setup, вставити ключ (досить одного: OpenAI / Anthropic / Google Gemini), натиснути «Перевірити і зберегти» → зелена позначка. Ключ зберігається лише локально.

## Як отримати API-ключ
- Google Gemini (безкоштовний ліміт, найпростіший старт): https://aistudio.google.com/apikey → увійти в Google → «Create API key» → скопіювати.
- Anthropic (Claude): https://console.anthropic.com → Settings → Billing (поповнити баланс, мін. ~$5) → API Keys → Create Key (ключ виду sk-ant-…, показується один раз).
- OpenAI (GPT): https://platform.openai.com/api-keys → Settings → Billing (поповнити) → Create new secret key (sk-…, показується один раз).
Порада: для проби — Gemini (безкоштовно); для якості — Claude або GPT.

## Поле моделі (локальна модель / Ollama)
У поле вводять ЛИШЕ назву моделі (напр. `llama3.2:3b`), а не команду. Не вставляти `ollama pull …` чи `ollama list` — лише назву.

## Ліцензія
Пробний/тріальний доступ активований заздалегідь; ключ ліцензії вводити НЕ потрібно. Питання продовження — до Андрія.

## Межі компетенції бота (важливо)
НЕ відповідати самостійно і ескалювати Андрію: питання ціни, оплати, ліцензійних умов, договорів, знижок, термінів, а також будь-що поза цією базою знань або коли немає впевненості. Краще чесно сказати «уточню в Андрія», ніж вигадати.
