# -*- coding: utf-8 -*-
"""
tender_message.py — ⭐ ЄДИНІ ВОРОТА ТЕНДЕРНОГО ПОВІДОМЛЕННЯ.

ЧОМУ ВОРОТА САМЕ ТУТ (дисципліна 4 питань, Статут №15):
  Тендерний факт виходить до людини ЧОТИРМА дорогами — чат системи,
  Telegram-сповіщення, файл-звіт, картка в інтерфейсі. Сторож ходить в API сам
  і шле в Telegram В ОБХІД executor. Ворота лише в executor (як у юриста)
  прикрили б 1 дорогу з 4 — і лишили б відкритою найдорожчу: дату подання
  в сповіщенні.
  Тому ворота стоять у СКЛАДАЧІ, а не у відправнику. Новий канал (пошта,
  WhatsApp, кабінет) протекти НЕ може: йому нема з чого зібрати повідомлення,
  крім результату цих воріт.

ПРАВИЛО ДЛЯ ВСІХ ВІДПРАВНИКІВ: жоден модуль не має права складати тендерний
текст сам. Єдиний дозволений вхід — build(). Це не домовленість на словах:
tender_honesty_test.py сканує вихідні файли і падає, якщо мітки повідомлення
(LABEL_*) зустрічаються поза цим модулем.

ЩО РОБИТЬ build():
  1. Бере факти ТІЛЬКИ з джерела (tender_source_ua.resolve) — не з моделі.
  2. Складає текст із цих фактів.
  3. ⭐ Проганяє ВЛАСНИЙ вихід через tender_fact_check — якщо власний текст не
     звіряється, це наша помилка, і назовні йде чесний стоп, а не крива правда.
  4. Коментар моделі (якщо є) пропускає крізь той самий звіряч; не пройшов —
     коментар знімається, і це видно людині.
  Немає жодного перевіреного тендера -> honest_stop {reason, action}.
"""
import tender_fact_check
import tender_outbound          # вартовий на виході: печатку ставить ЛИШЕ цей модуль
import tender_render            # ЄДИНА точка: як назва закупівлі показується людині

try:
    import tender_source_ua
except Exception:
    tender_source_ua = None

# Мітки повідомлення. Поза цим модулем зустрічатись НЕ можуть (див. тест).
LABEL_NUMBER = "Номер:"
LABEL_BUYER = "Замовник:"
LABEL_AMOUNT = "Очікувана вартість:"
LABEL_DEADLINE = "Подання до:"
LABEL_STATUS = "Статус:"
LABEL_LINK = "Перевірити:"
MARK_EXPIRED = "(строк подання вже минув)"
_LABELS = (LABEL_NUMBER, LABEL_BUYER, LABEL_AMOUNT, LABEL_DEADLINE,
           LABEL_STATUS, LABEL_LINK, MARK_EXPIRED)

_NO_DATA = "немає в джерелі"

# ⭐ РИСКА «НИЖЧЕ — СХОЖЕ НА ЧУЖЕ» (27.07.2026).
# Кваліфікатор сортує, але НІЧОГО не викидає: він може лише посунути вниз.
# Тому у повідомленні є друга частина, а не коротший список.
# ⚠ У розділювачі й примітці свідомо НЕМАЄ ЖОДНОЇ ЦИФРИ: будь-яке число в тексті
# зобовʼязане бути звіреним фактом тендера, інакше воно проходить повз звіряча
# як «голе число» (дірка №4 нашої ж збірки). Скільки чого — у полі report.
ASIDE_LINE = "— — — — — — — — — —"
ASIDE_NOTE = ("Нижче — те, що система вважає чужим товаром. "
              "Не викинуто навмисно: подивіться самі, вона могла помилитись.")


def _as_tuple(ddmmyyyy):
    """'05.08.2026' -> (2026, 8, 5). Не розібрали — None."""
    try:
        d, m, y = (ddmmyyyy or "").split(".")
        return (int(y), int(m), int(d))
    except (ValueError, AttributeError):
        return None


def _is_past(deadline, today):
    """Строк подання вже минув?

    ЧОМУ ЦЕ ТУТ, А НЕ В КРАСИВОМУ ТЕКСТІ: живий прогон 27.07.2026 показав тендер
    зі строком подання 26.07.2026 у статусі active.auction. Факт правдивий — але
    рядок «Подання до: 26.07.2026» без позначки читається як «ще встигаєш».
    Правдивий факт у оманливій подачі коштує клієнту так само дорого, як вигадка.
    Позначка стоїть у складачі, тому зʼявляється в УСІХ каналах одразу.
    """
    a, b = _as_tuple(deadline), _as_tuple(today)
    return bool(a and b and a < b)


def _fmt_money(amount, currency):
    if amount is None:
        return None
    whole = "%.2f" % float(amount)
    left, right = whole.split(".")
    groups = []
    while len(left) > 3:
        groups.insert(0, left[-3:])
        left = left[:-3]
    groups.insert(0, left)
    return "%s.%s %s" % (" ".join(groups), right, (currency or "UAH"))


def _render_one(n, rec, today=None):
    money = _fmt_money(rec.get("amount"), rec.get("currency"))
    deadline = rec.get("deadline") or _NO_DATA
    if _is_past(rec.get("deadline"), today):
        deadline += " " + MARK_EXPIRED
    return "\n".join([
        # ⭐ Назва — ЧЕРЕЗ tender_render, не сира. У Прозоро в полі title
        # трапляється не назва, а повна технічна умова на 2500 знаків;
        # без цього рядка вона пішла б клієнту в Telegram цілком.
        "%d. %s" % (n, tender_render.short_title(rec.get("title")) or _NO_DATA),
        "   %s %s" % (LABEL_NUMBER, rec.get("tender_id")),
        "   %s %s" % (LABEL_BUYER, rec.get("buyer") or _NO_DATA),
        "   %s %s" % (LABEL_AMOUNT, money or _NO_DATA),
        "   %s %s" % (LABEL_DEADLINE, deadline),
        "   %s %s" % (LABEL_STATUS, rec.get("status") or _NO_DATA),
        "   %s %s" % (LABEL_LINK, rec.get("url")),
    ])


def _honest_stop(reason, action):
    return {"ok": False, "text": "", "records": [], "report": "",
            "comment_dropped": False,
            "honest_stop": {"reason": reason, "action": action}}


def build(tender_ids, comment=None, today=None, resolver=None, title=None,
          set_aside=None):
    """ЄДИНИЙ дозволений спосіб зробити тендерне повідомлення.

    tender_ids — номери, які треба показати людині.
    comment    — вільний текст моделі (необовʼязково); проходить звірку.
    today      — 'DD.MM.YYYY' (дата звіту; дозволена в тексті як не-факт тендера).
    resolver   — джерело; за замовчуванням tender_source_ua.resolve.
    set_aside  — номери, які показати ПІД РИСКОЮ (схоже на чужий товар).
                 Це НЕ видалення: вони лишаються в тексті, у записах і у звіті.
                 Номер, якого немає серед tender_ids, просто ігнорується.

    -> {ok, text, records, report, comment_dropped, honest_stop}
    """
    if resolver is None:
        if tender_source_ua is None:
            return _honest_stop("Модуль джерела тендерів недоступний.",
                                "Повідомте адміністратора; повідомлення не надіслано.")
        resolver = tender_source_ua.resolve

    cache, records, problems = {}, [], []
    for tid in (tender_ids or []):
        tid = (tid or "").strip()
        if not tid or tid in cache:
            continue
        try:
            rec = resolver(tid)
        except Exception as e:
            cache[tid] = None
            problems.append("%s — джерело недоступне (%s)" % (tid, type(e).__name__))
            continue
        cache[tid] = rec
        if rec:
            records.append(rec)
        else:
            problems.append("%s — у Прозоро не знайдено" % tid)

    if not records:
        return _honest_stop(
            "Жоден тендер не вдалося звірити з Прозоро: " + ("; ".join(problems) or "немає номерів"),
            "Повідомлення НЕ надіслано. Перевірте номери або доступ до Прозоро вручну.")

    head = title or "Тендери під вашу продукцію"
    if today:
        head += " — " + today
    aside_keys = {(x or "").strip().upper() for x in (set_aside or []) if x}
    main_recs = [r for r in records
                 if (r.get("tender_id") or "").strip().upper() not in aside_keys]
    aside_recs = [r for r in records
                  if (r.get("tender_id") or "").strip().upper() in aside_keys]
    body = [head, ""]
    n = 0
    for rec in main_recs:
        n += 1
        body.append(_render_one(n, rec, today))
        body.append("")
    if aside_recs:
        # Якщо ГОЛОВНА частина порожня — риска без нічого зверху виглядала б як
        # «нічого не знайшли». Тому кажемо прямо, що все поїхало вниз.
        if not main_recs:
            body.append("Усе знайдене система вважає чужим товаром — але нічого не викинула.")
            body.append("")
        body.append(ASIDE_LINE)
        body.append(ASIDE_NOTE)
        body.append("")
        for rec in aside_recs:
            n += 1
            body.append(_render_one(n, rec, today))
            body.append("")
    facts_text = "\n".join(body).rstrip()

    # ⭐ Звірка ВЛАСНОГО виходу тим самим звірячем (кеш — без зайвих запитів).
    def _cached(tid):
        return cache.get((tid or "").strip())

    verdicts, summary = tender_fact_check.verify(facts_text, resolver=_cached, today=today)
    if not summary["ok"]:
        return _honest_stop(
            "Складене повідомлення не пройшло власну звірку з джерелом.",
            "Повідомлення НЕ надіслано. Це помилка платформи — покажіть цей звіт розробнику.\n"
            + tender_fact_check.build_report(verdicts, today or ""))

    text = facts_text
    comment_dropped = False
    if comment and comment.strip():
        clean = tender_fact_check.strip_model_seal(comment)
        c_verdicts, c_summary = tender_fact_check.verify(clean, resolver=_cached, today=today)
        if c_summary["ok"]:
            text += "\n\n" + clean.strip()
        else:
            comment_dropped = True
            text += ("\n\n⚠ Коментар помічника знято: у ньому %d невивірених фактів. "
                     "Нижче — лише те, що звірено з Прозоро." % c_summary["flagged"])
            verdicts = verdicts + c_verdicts

    if problems:
        text += "\n\n⚠ Не показано (не звірено): " + "; ".join(problems) + "."

    tender_outbound.seal(text)      # ⭐ печатка: далі вартовий на виході впізнає цей текст
    return {"ok": True, "text": text, "records": records,
            "report": tender_fact_check.build_report(verdicts, today or ""),
            "comment_dropped": comment_dropped, "honest_stop": None}


# ===========================================================================
# АНАЛІТИКА РИНКУ — ті самі ворота, друга форма повідомлення (27.07.2026)
# ===========================================================================
"""
ЧОМУ ТУТ, А НЕ В НОВОМУ МОДУЛІ. Спокуса була зробити окремий складач для
розвідника — і це відтворило б рівно ту хворобу, від якої ми лікувались:
два місця, де народжується тендерний текст, розходяться з часом.
Аналітичне повідомлення — це ДРУГА ФОРМА того самого повідомлення, тому воно
виходить із тих самих воріт і підпорядковане тому самому правилу:
жодне число не потрапляє в текст інакше, ніж порахованим із карток джерела.
"""
import tender_analytics

LABEL_ANALYTICS = "Аналітика ринку"
LABEL_BASIS = tender_fact_check.BASIS_PREFIX      # «Вибірка (N): UA-…»
LABEL_CALC = tender_fact_check.CALC_OPEN          # «[розраховано: …]»
_ANALYTICS_LABELS = (LABEL_ANALYTICS, LABEL_BASIS, LABEL_CALC)

_CALC_TAIL = "[розраховано: %s — %d із %d карток вибірки]"


def build_analytics(records, topic=None, comment=None, today=None, resolver=None, keys=None):
    """ЄДИНИЙ дозволений спосіб зробити аналітичне тендерне повідомлення.

    records — картки з джерела (вже здобуті: пошук завершених закупівель тощо).
    topic   — тема вибірки словами (без чисел: число в темі звірити нема з чим).
    comment — вільний текст моделі; проходить ту саму звірку, що й у build().

    -> {ok, text, metrics, report, comment_dropped, honest_stop}
    """
    records = [r for r in (records or []) if r and r.get("tender_id")]
    if not records:
        return dict(_honest_stop(
            "Вибірка порожня: жодної картки з джерела.",
            "Аналітику НЕ надіслано. Спершу знайдіть закупівлі, тоді рахуйте."),
            metrics=[])

    metrics = tender_analytics.compute(records, keys=keys)
    if not metrics:
        return dict(_honest_stop(
            "З наявних карток не рахується жодна метрика (немає потрібних полів).",
            "Аналітику НЕ надіслано. Це не помилка: джерело просто не дало чисел."),
            metrics=[])

    head = LABEL_ANALYTICS + ((": " + topic) if topic else "")
    if today:
        head += " — " + today
    body = [head, ""]
    for m in metrics:
        body.append("— %s: %s %s" % (m["label"], m["text"],
                                     _CALC_TAIL % (m["key"], m["used"], m["total"])))
    body.append("")
    body.append("%s (%d): %s" % (LABEL_BASIS, len(records),
                                 ", ".join(r["tender_id"] for r in records)))
    facts_text = "\n".join(body)

    # ⭐ Той самий принцип, що й у build(): власний вихід перевіряємо перерахунком.
    by_id = {r["tender_id"]: r for r in records}

    def _cached(tid):
        return by_id.get((tid or "").strip())

    verdicts, summary = tender_fact_check.verify_analytics(facts_text, resolver=_cached, today=today)
    if not summary["ok"]:
        return dict(_honest_stop(
            "Складена аналітика не пройшла власний перерахунок.",
            "Аналітику НЕ надіслано. Це помилка платформи — покажіть цей звіт розробнику.\n"
            + tender_fact_check.build_report(verdicts, today or "")),
            metrics=metrics)

    text = facts_text
    comment_dropped = False
    if comment and comment.strip():
        clean = tender_fact_check.strip_model_seal(comment)
        c_verdicts, c_summary = tender_fact_check.verify_analytics(
            clean + "\n\n" + body[-1], resolver=_cached, today=today)
        if c_summary["ok"]:
            text += "\n\n" + clean.strip()
        else:
            comment_dropped = True
            text += ("\n\n⚠ Коментар помічника знято: у ньому є числа, не підтверджені "
                     "розрахунком (%d). Вище — лише те, що порахував код." % c_summary["flagged"])
            verdicts = verdicts + c_verdicts

    tender_outbound.seal(text)      # ⭐ та сама печатка, та сама пара воріт
    return {"ok": True, "text": text, "metrics": metrics, "records": records,
            "report": tender_fact_check.build_report(verdicts, today or ""),
            "comment_dropped": comment_dropped, "honest_stop": None}
