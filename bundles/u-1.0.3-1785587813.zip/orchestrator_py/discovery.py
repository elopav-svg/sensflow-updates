"""
discovery.py — виявлення ресурсів. Оркестратор сам знаходить нові системи.

При старті (і за запитом) сканує робочий простір і generated_systems, знаходить
папки-системи, яких ще немає в реєстрі (створені білдером або користувачем за
правилами), і додає їх у реєстр зі статусом needs_review. Зниклі (папка
відсутня) позначає status=missing. Нічого не видаляє.

Без зовнішніх залежностей: system.yaml читається легким парсером потрібних полів.
"""

import re
from pathlib import Path

import config
import registry


# ---------------------------------------------------------------------------
# Розпізнавання папки-системи
# ---------------------------------------------------------------------------
def _has_agents(folder: Path) -> bool:
    adir = folder / "Agents"
    if not adir.is_dir():
        adir = folder / "agents"
    if not adir.is_dir():
        return False
    for sub in adir.iterdir():
        if sub.is_dir() and ((sub / "PROMPT.md").exists() or (sub / "CLAUDE.md").exists()):
            return True
    return False


def looks_like_system(folder: Path) -> bool:
    """
    Папка вважається системою ТІЛЬКИ за наявності system.yaml — це канонічний
    маніфест за контрактом білдера («за правилами»). Так ми не підхоплюємо
    випадкові dev/data-папки, у яких просто є CLAUDE.md+Agents.
    """
    return folder.is_dir() and (folder / "system.yaml").exists()


# ---------------------------------------------------------------------------
# Легкий парсер потрібних полів system.yaml (без PyYAML)
# ---------------------------------------------------------------------------
def _yaml_scalar(text: str, key: str):
    m = re.search(rf'^{key}\s*:\s*"?([^"\n]+?)"?\s*$', text, re.M)
    return m.group(1).strip() if m else None


def _yaml_agent_ids(text: str) -> list:
    ids = []
    for m in re.finditer(r'^\s*-\s*id\s*:\s*"?([A-Za-z0-9_]+)"?', text, re.M):
        ids.append(m.group(1))
    return ids


def _read_system_yaml(folder: Path) -> dict:
    p = folder / "system.yaml"
    if not p.exists():
        return {}
    try:
        text = p.read_text(encoding="utf-8-sig")
    except Exception:
        return {}
    return {
        "id": _yaml_scalar(text, "id"),
        "name": _yaml_scalar(text, "name"),
        "category": _yaml_scalar(text, "category"),
        "description": _yaml_scalar(text, "description"),
        "orchestration_mode": _yaml_scalar(text, "orchestration_mode"),
        "agents": _yaml_agent_ids(text),
    }


def _agents_from_folder(folder: Path) -> list:
    adir = folder / "Agents"
    if not adir.is_dir():
        adir = folder / "agents"
    if not adir.is_dir():
        return []
    return sorted([s.name for s in adir.iterdir() if s.is_dir()
                   and ((s / "PROMPT.md").exists() or (s / "CLAUDE.md").exists())])


def _first_meaningful_line(folder: Path) -> str:
    for name in ("CLAUDE.md", "PROMPT.md"):
        p = folder / name
        if p.exists():
            try:
                for line in p.read_text(encoding="utf-8-sig").splitlines():
                    s = line.strip().lstrip("#").strip()
                    if s and len(s) > 8:
                        return s[:200]
            except Exception:
                pass
    return ""


def _slug(value: str, fallback="discovered_system") -> str:
    s = re.sub(r"[^a-z0-9]+", "_", (value or "").lower())
    s = re.sub(r"_+", "_", s).strip("_")
    return s or fallback


def _norm(path_str: str) -> str:
    return (path_str or "").replace("\\", "/").strip("/").lower()


# ---------------------------------------------------------------------------
# Кандидати на сканування
# ---------------------------------------------------------------------------
def _candidate_dirs():
    out = []
    # 1) Папки верхнього рівня у робочому просторі (де живуть проєкти)
    if config.WORKSPACE_ROOT.is_dir():
        for d in config.WORKSPACE_ROOT.iterdir():
            if d.is_dir() and not d.name.startswith("."):
                rel = d.name
                out.append((d, rel))
    # 2) generated_systems всередині платформи
    gen = config.PLATFORM_ROOT / "generated_systems"
    if gen.is_dir():
        for d in gen.iterdir():
            if d.is_dir():
                # ⭐ 29.07.2026: шлях системи пишемо ВІДНОСНО КОРЕНЯ ПРОДУКТУ,
                # а не теки над ним. Інакше кожен запис мусив би називати
                # корінь — а в клієнта він зветься інакше, і документи вели
                # його в теку, якої не існує.
                rel = f"generated_systems/{d.name}"
                out.append((d, rel))
    return out


def _folder_state(folder: Path) -> dict:
    """Живий стан із .sf_state.json у папці системи ({} якщо немає).
    Це джерело істини, яке переживає наші оновлення (реєстр — лише кеш)."""
    p = folder / registry.STATE_FILE
    if not p.exists():
        return {}
    try:
        data = json.loads(p.read_text(encoding="utf-8-sig"))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _build_entry(folder: Path, rel_path: str, systems) -> dict:
    meta = _read_system_yaml(folder)
    agents = meta.get("agents") or _agents_from_folder(folder)
    name = meta.get("name") or folder.name
    sid = _slug(meta.get("id") or name, fallback=_slug(folder.name))
    # унікальність id
    existing = {s.get("id") for s in systems}
    if sid in existing:
        i = 2
        while f"{sid}_{i}" in existing:
            i += 1
        sid = f"{sid}_{i}"

    # Живий стан із папки. Якщо система вже колись була активована/налаштована —
    # відновлюємо статус, тригери, пріоритет, чутливість, а не хардкодимо
    # needs_review. Тільки СПРАВДІ нова папка (стану немає) → needs_review
    # (запобіжник контракту білдера лишається).
    st = _folder_state(folder)
    has_state = bool(st.get("status"))

    entry = {
        "id": sid,
        "name": st.get("name") or name,
        "category": meta.get("category") or "discovered",
        "status": st.get("status") or "needs_review",
        "root_path": rel_path,
        "description": meta.get("description") or _first_meaningful_line(folder),
        "orchestration_mode": meta.get("orchestration_mode") or "sequential",
        "agents": agents or ["AgentMain"],
        "priority": st.get("priority", 60),
        "sensitive": bool(st.get("sensitive", False)),
        "triggers": st.get("triggers", []),
        "discovered": not has_state,
    }
    # Паспорт здатностей ролей (контракт наміру): з папки або сіяч.
    entry["roles"] = st.get("roles") if isinstance(st.get("roles"), dict) and st.get("roles") \
        else registry.seed_roles(entry)
    return entry


# ---------------------------------------------------------------------------
# Головна синхронізація
# ---------------------------------------------------------------------------
def sync(register: bool = True) -> dict:
    """
    Повертає {added:[...], missing:[...], total:int}.
    register=False — лише звіт (dry-run), нічого не пише.
    """
    reg = registry.load_registry()
    systems = reg.get("systems", [])
    registered_paths = {_norm(s.get("root_path")) for s in systems}

    added = []
    for folder, rel in _candidate_dirs():
        if _norm(rel) in registered_paths:
            continue
        if not looks_like_system(folder):
            continue
        entry = _build_entry(folder, rel, systems + added)
        added.append(entry)

    # зниклі: registered, але папки немає
    missing = []
    for s in systems:
        root = registry.system_root(s)
        if not Path(root).exists():
            missing.append(s.get("id"))

    # Лікування + міграція для ВЖЕ ВІДОМИХ систем (папка існує):
    #   • є .sf_state.json → папка виграє: відновлюємо статус/тригери/пріоритет/
    #     чутливість у реєстрі (це рятує клієнтські системи, коли наше оновлення
    #     затерло реєстр і скинуло їх у needs_review);
    #   • стану ще немає → сіємо його з поточного запису реєстру (разова міграція),
    #     щоб система пережила НАСТУПНЕ оновлення.
    healed = []
    for s in systems:
        if s.get("id") in missing:
            continue
        folder = registry.system_root(s)
        if not Path(folder).exists():
            continue
        st = _folder_state(folder)
        if st.get("status"):
            changed = False
            for k in ("status", "triggers", "priority", "sensitive", "name", "roles"):
                if k in st and st[k] != s.get(k):
                    s[k] = st[k]
                    changed = True
            if changed:
                healed.append(s.get("id"))
        elif register:
            registry.save_state_from_entry(s)  # міграція: захистити папку на майбутнє
        # РАЗОВА МІГРАЦІЯ ПАСПОРТІВ РОЛЕЙ (контракт наміру, 10.07.2026): системі без
        # паспорта сіємо його з колишніх евристик і закріплюємо в папці+реєстрі.
        if register and not (isinstance(s.get("roles"), dict) and s.get("roles")) \
                and not (isinstance(st.get("roles"), dict) and st.get("roles")):
            s["roles"] = registry.seed_roles(s)
            registry.write_folder_state(s, {"roles": s["roles"]})
            if s.get("id") not in healed:
                healed.append(s.get("id"))

    if register and (added or missing or healed):
        for e in added:
            systems.append(e)
        for s in systems:
            if s.get("id") in missing and s.get("status") != "missing":
                s["_prev_status"] = s.get("status")
                s["status"] = "missing"
        reg["systems"] = systems
        registry.save_registry(reg)
        # Нові знайдені системи, що вже мали збережений стан у папці, теж
        # закріплюємо у папці (щоб їхній відновлений статус пережив наступне оновлення).
        for e in added:
            if not e.get("discovered"):
                registry.save_state_from_entry(e)

    return {"added": [e["id"] for e in added], "missing": missing, "healed": healed,
            "total": len(systems) + (len(added) if not register else 0)}
