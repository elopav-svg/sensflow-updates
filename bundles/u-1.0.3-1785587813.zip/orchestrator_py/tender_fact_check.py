# -*- coding: utf-8 -*-
"""
tender_fact_check.py — ДЕТЕРМІНОВАНИЙ ЗВІРЯЧ ТЕНДЕРНИХ ФАКТІВ.

Брат-близнюк legal_citation_check.py — той самий клас гарантії: код НЕ вірить
самозаяві моделі («за даними Прозоро», «перевірено»), знімає її печатку, сам іде
до джерела і ставить свою. Невивірено або розбіжність -> «ПЕРЕВІРТЕ» (fail-closed).

ЩО ЗВІРЯЄМО (факти, на яких клієнт втрачає гроші):
  * номер тендера — чи існує взагалі в Прозоро
  * сума          — до копійки
  * дата          — до дня (подання / оголошення / кінець запитань)
  * статус        — точним рядком
  * посилання     — чи веде саме на ТОЙ тендер

⭐ СИРІТСЬКИЙ ФАКТ. Найнебезпечніше — сума або дата подання, які не належать
ЖОДНОМУ номеру тендера («подати до 05.08» без номера). Звірити нема з чим,
отже такий текст НЕ проходить. Саме тут ловиться найдорожча помилка.

Джерело — виключно tender_source_ua.resolve() (одні двері). Свого мережевого
коду тут немає свідомо. resolver можна підмінити — для офлайн-тестів.
"""
import re

try:
    import tender_source_ua
except Exception:            # тест може працювати без мережевого модуля
    tender_source_ua = None

# UA-2026-07-17-007287-a
_TENDER_ID_RE = re.compile(r"\bUA-\d{4}-\d{2}-\d{2}-\d{4,8}-[a-zA-Z]\b")
_DATE_RE = re.compile(r"\b(\d{2}\.\d{2}\.\d{4})\b")
_MONEY_RE = re.compile(
    r"(\d[\d\s  ]*(?:[.,]\d{1,2})?)\s*(?:грн\b|гривень|гривні|UAH\b|₴)",
    re.IGNORECASE)
_VAGUE_MONEY_RE = re.compile(r"\d[\d\s.,]*\s*(?:млн|млрд|тис)\.?", re.IGNORECASE)
_STATUS_RE = re.compile(r"\b(active\.[a-z-]+|complete|unsuccessful|cancelled)\b")
_URL_RE = re.compile(r"prozorro\.gov\.ua/tender/([A-Za-z0-9\-]+)", re.IGNORECASE)
_MONEY_EPS = 0.01


class _NoSource(Exception):
    pass


# ---------------------------------------------------------------------------
# Розбір
# ---------------------------------------------------------------------------
def parse_amount(raw):
    """'1 234 567,89' -> 1234567.89. Не розібрали — None."""
    s = re.sub(r"[\s  ]", "", raw or "")
    if "," in s and "." in s:
        s = s.replace(",", "")
    else:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return None


def split_blocks(text):
    """Текст -> [(tender_id|None, шматок)]. Перший шматок без номера — «сирітська
    зона»: усе, що в ній сказано про гроші й терміни, звірити НЕМА З ЧИМ."""
    text = text or ""
    marks = list(_TENDER_ID_RE.finditer(text))
    if not marks:
        return [(None, text)]
    blocks = []
    if text[:marks[0].start()].strip():
        blocks.append((None, text[:marks[0].start()]))
    for i, m in enumerate(marks):
        end = marks[i + 1].start() if i + 1 < len(marks) else len(text)
        blocks.append((m.group(0), text[m.start():end]))
    return blocks


def _dates_in(chunk):
    return _DATE_RE.findall(chunk)


# ---------------------------------------------------------------------------
# Звірка
# ---------------------------------------------------------------------------
def _check_block(tid, chunk, rec, today):
    """Один тендер: усі його факти проти запису з джерела."""
    out = []
    known_dates = {d for d in (rec.get("announced"), rec.get("deadline"),
                               rec.get("enquiry_until")) if d}
    if today:
        known_dates.add(today)

    for raw in _dates_in(chunk):
        if raw in known_dates:
            out.append({"tender_id": tid, "kind": "date", "claimed": raw, "status": "match"})
        else:
            out.append({"tender_id": tid, "kind": "date", "claimed": raw,
                        "status": "mismatch", "source": rec.get("deadline")})

    for m in _MONEY_RE.finditer(chunk):
        got = parse_amount(m.group(1))
        real = rec.get("amount")
        if real is None:
            out.append({"tender_id": tid, "kind": "amount", "claimed": m.group(1).strip(),
                        "status": "unverifiable"})
        elif got is not None and abs(got - float(real)) <= _MONEY_EPS:
            out.append({"tender_id": tid, "kind": "amount", "claimed": m.group(1).strip(),
                        "status": "match"})
        else:
            out.append({"tender_id": tid, "kind": "amount", "claimed": m.group(1).strip(),
                        "status": "mismatch", "source": real})

    for m in _VAGUE_MONEY_RE.finditer(chunk):
        out.append({"tender_id": tid, "kind": "amount", "claimed": m.group(0).strip(),
                    "status": "vague"})

    for m in _STATUS_RE.finditer(chunk):
        if m.group(1) == (rec.get("status") or ""):
            out.append({"tender_id": tid, "kind": "status", "claimed": m.group(1),
                        "status": "match"})
        else:
            out.append({"tender_id": tid, "kind": "status", "claimed": m.group(1),
                        "status": "mismatch", "source": rec.get("status")})

    for m in _URL_RE.finditer(chunk):
        if m.group(1).upper() == (tid or "").upper():
            out.append({"tender_id": tid, "kind": "url", "claimed": m.group(1),
                        "status": "match"})
        else:
            out.append({"tender_id": tid, "kind": "url", "claimed": m.group(1),
                        "status": "mismatch", "source": tid})
    return out


def _check_orphans(chunk, today):
    """Факти без номера тендера — звірити нема з чим, отже не проходять.

    Строго за задумом: БУДЬ-ЯКА дата (крім дати самого звіту) і БУДЬ-ЯКА сума
    поза номером тендера — сирота. Спершу тут стояв мʼякший варіант — ловити
    дату лише за словом-маркером («подання», «дедлайн»). Тест показав дірку:
    «Не забудьте — 09.09.2026» маркера не має і пройшло б до людини.
    Ціна суворості — знятий коментар. Ціна мʼякості — клієнт їде на тендер
    у вигаданий день. Обираємо суворість."""
    out = []
    for raw in _dates_in(chunk):
        if raw != today:
            out.append({"tender_id": None, "kind": "date", "claimed": raw, "status": "orphan"})
    for m in _MONEY_RE.finditer(chunk):
        out.append({"tender_id": None, "kind": "amount", "claimed": m.group(1).strip(),
                    "status": "orphan"})
    for m in _VAGUE_MONEY_RE.finditer(chunk):
        out.append({"tender_id": None, "kind": "amount", "claimed": m.group(0).strip(),
                    "status": "orphan"})
    return out


_GOOD = ("match",)


def verify(text, resolver=None, today=None):
    """Звіряє тендерні факти в тексті. -> (verdicts, summary).

    summary['ok'] == True означає: КОЖЕН знайдений факт звірено з джерелом і він
    збігся. Текст без тендерних фактів теж ok (нема чому брехати).
    """
    if resolver is None:
        if tender_source_ua is None:
            raise _NoSource("tender_source_ua недоступний")
        resolver = tender_source_ua.resolve

    verdicts, cache = [], {}
    for tid, chunk in split_blocks(text):
        if tid is None:
            verdicts.extend(_check_orphans(chunk, today))
            continue
        if tid not in cache:
            try:
                cache[tid] = resolver(tid)
            except Exception:
                cache[tid] = "__ERROR__"
        rec = cache[tid]
        if rec == "__ERROR__":
            verdicts.append({"tender_id": tid, "kind": "tender", "claimed": tid,
                             "status": "no_source"})
            continue
        if not rec:
            verdicts.append({"tender_id": tid, "kind": "tender", "claimed": tid,
                             "status": "not_found"})
            continue
        verdicts.append({"tender_id": tid, "kind": "tender", "claimed": tid,
                         "status": "match", "source": rec.get("title")})
        verdicts.extend(_check_block(tid, chunk, rec, today))

    bad = [v for v in verdicts if v["status"] not in _GOOD]
    return verdicts, {"ok": not bad, "checked": len(verdicts), "flagged": len(bad)}


# ---------------------------------------------------------------------------
# Печатка моделі — знімається завжди
# ---------------------------------------------------------------------------
_MODEL_SEAL_RE = re.compile(
    r"[✅✔☑]?\s*(?<!не )(?:звірено|перевірено|актуально|дані)\s+"
    r"(?:з|за|у|в|на)?\s*(?:даними\s+)?(?:Прозор+о|Prozorro)[^.\n]*\.?",
    re.IGNORECASE)


def strip_model_seal(text):
    """Модель не має права ставити печатку «перевірено з Прозоро» — лише код."""
    return _MODEL_SEAL_RE.sub("", text or "")


# ---------------------------------------------------------------------------
# Звіт для людини
# ---------------------------------------------------------------------------
_KIND_UA = {"tender": "номер", "amount": "сума", "date": "дата",
            "status": "статус", "url": "посилання",
            "aggregate": "розрахунок", "basis": "вибірка", "number": "число"}


def build_report(verdicts, date_str):
    lines = ["## Звірка тендерних фактів із Прозоро (автоматична)"]
    need = []
    for v in verdicts:
        kind = _KIND_UA.get(v["kind"], v["kind"])
        loc = ("%s, %s" % (v["tender_id"], kind)) if v.get("tender_id") else ("БЕЗ НОМЕРА, %s" % kind)
        st = v["status"]
        if st == "match":
            lines.append("- ✅ %s — «%s» звірено з джерелом (%s)." % (loc, v["claimed"], date_str))
        elif st == "mismatch":
            lines.append("- ⚠ %s — РОЗБІЖНІСТЬ: у тексті «%s», у джерелі «%s». ПЕРЕВІРТЕ."
                         % (loc, v["claimed"], v.get("source")))
            need.append(loc)
        elif st == "not_found":
            lines.append("- ⚠ %s — такого тендера в Прозоро НЕ знайдено. ПЕРЕВІРТЕ." % loc)
            need.append(loc)
        elif st == "no_source":
            lines.append("- ⚠ %s — джерело недоступне, не звірено. ПЕРЕВІРТЕ вручну." % loc)
            need.append(loc)
        elif st == "unverifiable":
            lines.append("- ⚠ %s — «%s»: джерело суми не дає, звірити нема з чим. ПЕРЕВІРТЕ."
                         % (loc, v["claimed"]))
            need.append(loc)
        elif st == "vague":
            lines.append("- ⚠ %s — «%s»: округлення замість точної суми — звірити неможливо."
                         % (loc, v["claimed"]))
            need.append(loc)
        elif st == "orphan":
            lines.append("- ⛔ %s — «%s» НЕ прив'язано до жодного тендера: звірити нема з чим."
                         % (loc, v["claimed"]))
            need.append(loc)
    if need:
        lines.append("")
        lines.append("**Факти, що потребують звірки перед використанням:** " + "; ".join(need) + ".")
    return "\n".join(lines)


# ===========================================================================
# АНАЛІТИЧНІ АГРЕГАТИ — ⭐ ЗВІРКА ПЕРЕРАХУНКОМ (додано 27.07.2026)
# ===========================================================================
"""
ЧОМУ ОКРЕМА ГІЛКА. Звірка вище перевіряє факт проти ОДНІЄЇ картки тендера.
У «середньої ціни» картки немає — звіряти нема з чим, і старе правило сироти
просто заборонило б будь-яку аналітику. Але мовчазна заборона теж погана:
клієнт лишиться без найціннішого — розуміння, за скільки виграють у його ніші.

РІШЕННЯ ТОГО САМОГО КЛАСУ, що й у решті платформи: код не вірить нікому —
ні моделі, ні власному складачу. Він бере вибірку, названу в тексті, сам іде
до джерела за кожним номером, САМ ПЕРЕРАХОВУЄ метрику і порівнює з написаним.
Збіглося — проходить. Ні — «ПЕРЕВІРТЕ» (fail-closed), як і скрізь.

⚠ ДРУГА ДІРКА, яку закриває ця гілка: старі правила ловили суми (за «грн/UAH»)
і дати, але НЕ ловили голих чисел — «12 закупівель», «у середньому 4 учасники»,
«ціна впала на 8 %». В аналітичному тексті це найпростіший спосіб збрехати.
Тому тут будь-яке число поза печаткою розрахунку — сирота.
"""
import re as _re

try:
    import tender_analytics as _analytics
except Exception:
    _analytics = None

# Рядок вибірки: з ЯКИХ саме карток рахували. Одна вибірка на повідомлення.
BASIS_PREFIX = "Вибірка"
_BASIS_RE = _re.compile(r"^%s\s*\((\d+)\):\s*(.+)$" % BASIS_PREFIX, _re.M)

# Рядок метрики з печаткою розрахунку.
CALC_OPEN = "[розраховано:"
_AGG_LINE_RE = _re.compile(
    r"^[\-—\s]*(?P<label>[^:\n]+):\s*(?P<value>[^\[\n]+?)\s*"
    r"\[розраховано:\s*(?P<key>[a-z_]+)\s*—\s*(?P<used>\d+)\s+із\s+(?P<total>\d+)\s+карток вибірки\]\s*$",
    _re.M)

# Голе число в аналітичному тексті. СУВОРО: будь-яка цифра поза печаткою
# розрахунку — сирота. Мʼякший варіант («ловимо лише 2+ цифри або відсоток»)
# впав на першому ж тесті: «зазвичай 4 учасники» має одну цифру і пройшло б.
# Ціна суворості — знятий коментар. Ціна мʼякості — вигадана цифра в рішенні
# на мільйони. Обираємо суворість, як і в правилі сироти вище.
_BARE_NUM_RE = _re.compile(r"\d[\d\s  ]*(?:[.,]\d+)?\s*%?")

_AGG_EPS = 0.01


def _blank(text, span):
    """Замінює шматок пробілами тієї ж довжини — щоб інші правила його не бачили,
    але позиції решти тексту не зсувалися."""
    a, b = span
    return text[:a] + (" " * (b - a)) + text[b:]


def _num_of(s):
    """Число з тексту значення метрики ('2 600 000.00 UAH' -> 2600000.0)."""
    s = _re.sub(r"[^\d\s.,-]", "", s or "")
    return parse_amount(s.strip())


def _basis_ids(text):
    """(кількість, [номери]) з рядка вибірки. Немає рядка — (None, [])."""
    m = _BASIS_RE.search(text or "")
    if not m:
        return None, []
    ids = _TENDER_ID_RE.findall(m.group(2))
    return int(m.group(1)), ids


def verify_analytics(text, resolver=None, today=None):
    """Звіряє АНАЛІТИЧНИЙ текст. -> (verdicts, summary), як і verify().

    Проходить лише те, що: (а) є метрикою з печаткою розрахунку, перерахованою
    з реальних карток і збіглою до копійки; (б) не містить жодного іншого числа.
    """
    text = text or ""
    if resolver is None:
        if tender_source_ua is None:
            raise _NoSource("tender_source_ua недоступний")
        resolver = tender_source_ua.resolve

    verdicts = []
    declared_n, ids = _basis_ids(text)

    # 1. Сама вибірка: кожен номер має існувати в джерелі.
    records, missing = [], []
    for tid in ids:
        try:
            rec = resolver(tid)
        except Exception:
            rec = "__ERROR__"
        if rec == "__ERROR__":
            verdicts.append({"tender_id": tid, "kind": "tender", "claimed": tid, "status": "no_source"})
            missing.append(tid)
        elif not rec:
            verdicts.append({"tender_id": tid, "kind": "tender", "claimed": tid, "status": "not_found"})
            missing.append(tid)
        else:
            records.append(rec)
            verdicts.append({"tender_id": tid, "kind": "tender", "claimed": tid,
                             "status": "match", "source": rec.get("title")})
    if declared_n is not None and declared_n != len(ids):
        verdicts.append({"tender_id": None, "kind": "basis", "claimed": str(declared_n),
                         "status": "mismatch", "source": len(ids)})

    # 2. Метрики — ПЕРЕРАХУНОК із тих самих карток.
    rest = text
    found_agg = 0
    for m in _AGG_LINE_RE.finditer(text):
        found_agg += 1
        rest = _blank(rest, m.span())
        key, claimed = m.group("key"), m.group("value").strip()
        loc = m.group("label").strip()
        if not ids or missing or _analytics is None:
            verdicts.append({"tender_id": None, "kind": "aggregate", "claimed": "%s: %s" % (loc, claimed),
                             "status": "no_source"})
            continue
        real = _analytics.value_of(records, key)
        if real is None:
            verdicts.append({"tender_id": None, "kind": "aggregate", "claimed": "%s: %s" % (loc, claimed),
                             "status": "not_found", "source": key})
            continue
        got, exp = _num_of(claimed), float(real["value"])
        same_basis = (int(m.group("used")) == real["used"] and int(m.group("total")) == real["total"])
        if got is not None and abs(got - exp) <= _AGG_EPS and same_basis:
            verdicts.append({"tender_id": None, "kind": "aggregate", "claimed": "%s: %s" % (loc, claimed),
                             "status": "match", "source": real["text"]})
        else:
            verdicts.append({"tender_id": None, "kind": "aggregate", "claimed": "%s: %s" % (loc, claimed),
                             "status": "mismatch",
                             "source": "%s (%d із %d)" % (real["text"], real["used"], real["total"])})

    # 3. Решта тексту: прибираємо вибірку, номери, посилання й дату звіту —
    #    усе, що лишилось із цифрами, звірити нема з чим.
    mb = _BASIS_RE.search(rest)
    if mb:
        rest = _blank(rest, mb.span())
    for rx in (_TENDER_ID_RE, _URL_RE):
        while True:
            mm = rx.search(rest)
            if not mm:
                break
            rest = _blank(rest, mm.span())
    if today:
        rest = rest.replace(today, " " * len(today))

    for mm in _BARE_NUM_RE.finditer(rest):
        verdicts.append({"tender_id": None, "kind": "number", "claimed": mm.group(0).strip(),
                         "status": "orphan"})

    bad = [v for v in verdicts if v["status"] not in _GOOD]
    return verdicts, {"ok": not bad, "checked": len(verdicts),
                      "flagged": len(bad), "aggregates": found_agg}
