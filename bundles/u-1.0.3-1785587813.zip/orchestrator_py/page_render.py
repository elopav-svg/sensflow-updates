"""
page_render.py — локальний рендер JS-сторінок (Шар 2, гібрид-драбина).

Навіщо: сучасні сайти (React/Vue/Next тощо) віддають майже порожню HTML-оболонку,
а текст «домальовує» браузер уже на боці користувача. Наш сирий парсер (urllib,
без JS) бачить пусто → флагман чесно каже «не зміг». Цей модуль проганяє сторінку
через СПРАВЖНІЙ браузерний двигун (Playwright/Chromium) ЛОКАЛЬНО і НАПРЯМУ
(жодного стороннього сервісу — приватність ціла) і повертає вже готовий HTML.

Філософія деградації: якщо Playwright не встановлено або рендер не вдався —
повертаємо None + людську причину. Виклик НІКОЛИ не кидає виняток, щоб не ронити
флагман; драбина просто лишається на сирому парсері (як було досі).

Playwright імпортується ЛІНИВО (усередині функції), тож цей модуль безпечно
імпортувати навіть там, де браузер не встановлено (напр. у клієнтській збірці
без рушія рендеру) — і verify_and_heal_engine перекомпілює його без залежностей.
"""

import re

# Ознаки «порожньої оболонки» SPA (сторінка рендериться браузером, не сервером).
_APP_SHELL_MARKERS = (
    'id="root"', "id='root'", 'id="app"', "id='app'", "__next_data__",
    "ng-version", "data-reactroot", "data-server-rendered", "window.__nuxt__",
    "/_next/", "reactdom", "__vue__", "vite", "webpack", "hydrate",
)

# Пороги (консервативні: рендеримо ЛИШЕ коли сторінка справді порожня, щоб не
# ганяти важкий браузер на нормальних серверних сайтах).
_THIN_TEXT = 600   # менше видимого тексту, ніж це, — «тонка» сторінка
_VERY_THIN = 200   # зовсім порожньо — рендеримо навіть без маркерів SPA


def _visible_len(src_html: str) -> int:
    """Груба довжина ВИДИМОГО тексту сторінки (без script/style/тегів)."""
    src = src_html or ""
    no_sc = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", src, flags=re.S | re.I)
    txt = re.sub(r"<[^>]+>", " ", no_sc)
    txt = re.sub(r"\s+", " ", txt).strip()
    return len(txt)


def looks_like_garbage(text: str) -> bool:
    """True, якщо текст — «цифрова каша» (нерозпакований gzip/br, бінарщина):
    висока частка биттх символів (заміна � або C0-контроль). Мовно-нейтрально:
    коректно декодований текст БУДЬ-ЯКОЮ мовою (укр/рос/іврит/казах) має майже
    нуль таких символів, а стиснена бінарщина — багато."""
    sample = (text or "")[:4000]
    if not sample.strip():
        return False
    bad = sum(1 for c in sample
              if c == "�" or (ord(c) < 32 and c not in "\t\n\r"))
    return bad / max(1, len(sample)) > 0.15


def looks_js_empty_raw(src_html: str) -> bool:
    """True, якщо сиру сторінку варто дорендерити локальним браузером:
    (а) майже порожня JS-оболонка, АБО (б) це нечитабельна каша (стиснене/бінарне
    тіло, яке простий читач не розпакував). Судимо ТІЛЬКИ по сирому коду. Консервативно."""
    if not src_html:
        return False
    # Каша (стиснення/бінарщина, яку сирий читач не розпакував) → у браузер.
    if looks_like_garbage(src_html):
        return True
    low = src_html.lower()
    vlen = _visible_len(src_html)
    has_shell = any(m in low for m in _APP_SHELL_MARKERS)
    # рендеримо, якщо: (а) зовсім порожньо, або (б) тонко І видно каркас SPA
    return vlen < _VERY_THIN or (vlen < _THIN_TEXT and has_shell)


def render_html(url: str, timeout_s: int = 30) -> tuple:
    """Прогнати URL через локальний headless-браузер і повернути (html, note).

    html=None означає «рендер недоступний/не вдався» — тоді драбина лишається
    на сирому парсері. Функція НІКОЛИ не кидає виняток."""
    if not (url or "").lower().startswith(("http://", "https://")):
        return None, "дозволені лише http/https URL"
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return None, ("локальний браузер не встановлено — запусти один раз "
                      "«Install browser engine.bat» у теці рушія")
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            try:
                page = browser.new_page(
                    user_agent="Mozilla/5.0 (compatible; AI-Orchestrator/1.0; SEO render)")
                page.goto(url, timeout=timeout_s * 1000, wait_until="domcontentloaded")
                # networkidle робить сторінку «дочекатись» динаміки; не критично.
                try:
                    page.wait_for_load_state("networkidle", timeout=8000)
                except Exception:
                    pass
                html = page.content()
            finally:
                browser.close()
    except Exception as e:
        return None, f"рендер не вдався: {str(e)[:200]}"
    if html and len(html) > 200:
        return html, "прочитано через локальний браузер (JS виконано)"
    return None, "рендер повернув порожньо"


def available() -> bool:
    """Чи встановлено локальний браузер (для UI/діагностики). Без запуску."""
    try:
        import importlib.util
        return importlib.util.find_spec("playwright") is not None
    except Exception:
        return False
