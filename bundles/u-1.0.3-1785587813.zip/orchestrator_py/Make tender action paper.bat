@echo off
cd /d "%~dp0"
python tender_legal_paper.py %1 %2
pause
