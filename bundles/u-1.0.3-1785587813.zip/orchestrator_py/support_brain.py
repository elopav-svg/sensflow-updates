"""
support_brain.py — мозок техпідтримки «Клод» для Telegram-бота SensFlow (TechCareSF).

Відповідає на питання клієнтів НА ОСНОВІ бази знань (support_kb.md) + загальновідомих
фактів про встановлення. Якщо не впевнений або питання поза межами (ціни, ліцензії,
договори, нове) — ставить escalate=true, і бот передає це власнику (Андрію).

Публічний метод: answer(question, history=None, images=None) -> dict
  {"reply": <текст клієнту>, "escalate": bool, "owner_note": <текст власнику>}

NB: не плутати з support.py (журнал годин підтримки за ліцензією) — це різні модулі.
"""

import os
from pathlib import Path

import config
import llm

_KB_CACHE = {"path": None, "mtime": None, "text": ""}

_ESCALATE_REPLY = ("Дякую за питання! Хочу уточнити деталі в Андрія, щоб відповісти точно — "
                   "передаю йому, він відповість найближчим часом. 🙏")


def _load_kb() -> str:
    p = config.SUPPORT_KB_PATH
    try:
        m = os.path.getmtime(p)
        if _KB_CACHE["path"] == p and _KB_CACHE["mtime"] == m:
            return _KB_CACHE["text"]
        t = Path(p).read_text(encoding="utf-8")
        _KB_CACHE.update({"path": p, "mtime": m, "text": t})
        return t
    except Exception:
        return ""


def _system_prompt() -> str:
    name = config.SUPPORT_BOT_NAME
    kb = _load_kb()
    return (
        f"Ти — {name}, технічна підтримка SensFlow і партнер Андрія. "
        "Пиши тепло, просто, без жаргону. Відповідай ТІЄЮ мовою, якою пише клієнт "
        "(російською або українською). Коротко й по суті, конкретними кроками. "
        "Команди для копіпасту давай ОДНИМ чистим рядком, без зайвих символів і без зворотного слеша в кінці.\n\n"
        "Відповідай ТІЛЬКИ на основі бази знань нижче і загальновідомих фактів про встановлення "
        "(Python, Telegram, macOS/Windows, отримання API-ключів). Якщо питання поза базою знань, "
        "стосується цін/оплати/ліцензій/договорів, або ти не впевнений — НЕ вигадуй: став confident=false.\n\n"
        "Поверни СУВОРО JSON без тексту навколо: "
        "{\"confident\": true|false, \"answer\": \"<відповідь клієнту>\", "
        "\"reason\": \"<чому не впевнений, якщо confident=false>\"}.\n\n"
        "=== БАЗА ЗНАНЬ ПІДТРИМКИ ===\n" + (kb or "(база знань порожня — будь обережний, частіше ескалюй)")
    )


def answer(question: str, history=None, images=None) -> dict:
    sysp = _system_prompt()
    q = (question or "").strip()
    user = q or "(клієнт надіслав зображення без тексту — проаналізуй скріншот)"
    if history:
        tail = history[-6:]
        ctx = "\n".join(f"{m.get('role')}: {str(m.get('content',''))[:400]}" for m in tail)
        user = f"[Контекст попередніх повідомлень]\n{ctx}\n\n[Нове повідомлення клієнта]\n{user}"

    try:
        if images:
            raw = llm.complete_vision(sysp, user, images, temperature=0.2)
        else:
            raw = llm.complete(sysp, user, temperature=0.2)
    except Exception as e:
        return {"reply": _ESCALATE_REPLY, "escalate": True,
                "owner_note": (f"⚠️ Технічний збій підтримки: {e}\n"
                               f"Питання клієнта: {q or '(зображення)'}")}

    try:
        data = llm.extract_json(raw)
    except Exception:
        txt = (raw or "").strip()
        if txt:
            return {"reply": txt, "escalate": False, "owner_note": ""}
        return {"reply": _ESCALATE_REPLY, "escalate": True,
                "owner_note": f"Порожня/нерозбірлива відповідь моделі. Питання: {q}"}

    confident = bool(data.get("confident"))
    ans = (data.get("answer") or "").strip()
    if confident and ans:
        return {"reply": ans, "escalate": False, "owner_note": ""}

    reason = (data.get("reason") or "").strip()
    owner_note = (f"Питання клієнта: {q or '(зображення без тексту)'}\n"
                  + ("Є скріншот. " if images else "")
                  + f"Бот не впевнений: {reason or 'поза базою знань'}.")
    return {"reply": _ESCALATE_REPLY, "escalate": True, "owner_note": owner_note}
