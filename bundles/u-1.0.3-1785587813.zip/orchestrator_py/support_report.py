# -*- coding: utf-8 -*-
"""
support_report.py — ОДИН ПИСАР звіту «Допомога з технічних питань».

ЧОМУ ЦЕЙ МОДУЛЬ ІСНУЄ (Статут №15, 29.07.2026, замовлення Андрія).

  КЛАС ПРОБЛЕМИ: «зіпсутий телефон». Клієнт ловить збій → описує його словами
  Андрію → Андрій переказує мені. Кожен переказ втрачає факти: версію збірки,
  який саме прогін упав, чи була пауза за вартістю, що стоїть у трасуванні.
  Продукт знає це все про себе — і мовчить.

  ТОЧКА РІШЕННЯ: одна — тут. НЕ «сервер збирає для вікна, а потім вікно збирає
  для файлу»: це два писарі однієї правди, і рано чи пізно у файл поїде те,
  чого клієнт не бачив. Тут будується ОДИН обʼєкт звіту: вікно показує ЙОГО,
  файл пишеться З НЬОГО.

  ВСІ КАНАЛИ: сьогодні — кнопка в консолі. Завтра HTTPS-приймач, Telegram чи
  update.py кличуть ТОГО САМОГО писаря, а не збирають своє.

  ЧИ ПРОТЕЧЕ МАЙБУТНІЙ КАНАЛ: склад звіту — БІЛИЙ список розділів (нижче
  BUILDERS). Нове поле не зʼявиться у файлі, поки автор не покладе його в
  розділ, який клієнт БАЧИТЬ. Ворота — support_report_test.py.

ГОЛОВНА ВИМОГА (аргумент продажу «0 ваших файлів у нас»): клієнт БАЧИТЬ ОЧИМА
кожен рядок, який піде разом із його повідомленням, і може прибрати будь-який
розділ. Тексти його задач за замовчуванням НЕ їдуть — це окрема галочка,
яку вмикає САМ клієнт (рішення Андрія, 29.07.2026).
"""

import json
import os
import platform
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import config

FOLDER_NAME = "Звіти для підтримки"
MAX_LINE = 300          # довші рядки ріжемо: у звіт не має влізти простирадло
MAX_JOURNAL_LINES = 60  # хвіст журналу — стільки рядків, не більше
ACTIVITY_LIMIT = 15


# ───────────────────────────── службове ─────────────────────────────────────

def reports_dir() -> Path:
    """Тека, куди лягає готовий звіт. У корені пакета — поруч із
    «Запустити SensFlow.bat», щоб клієнт знайшов її очима.
    Коли рушій у пісочниці (SENSFLOW_STATE_DIR) — звіти йдуть туди ж, і наші
    власні чеки не смітять у бойову теку [[project_state_isolation]]."""
    root = config.STATE_DIR if config.STATE_SANDBOXED else config.PLATFORM_ROOT
    return Path(root) / FOLDER_NAME


def _secret_values() -> list:
    """ТОЧНІ значення секретів цієї збірки. Не «схоже на ключ», а саме те, що
    лежить у .env.local: заміна за точним збігом не має хибних спрацювань."""
    names = ("OPENAI_API_KEY", "ANTHROPIC_API_KEY", "GEMINI_API_KEY",
             "KIMI_API_KEY", "PAGESPEED_API_KEY", "LOCAL_API_KEY",
             "LICENSE_SIGNING_SECRET", "LICENSE_KEY", "TELEGRAM_BOT_TOKEN")
    out = []
    for n in names:
        v = (config.ENV.get(n) or "").strip()
        if len(v) >= 8:
            out.append(v)
    return out


# ⚠ ЧОРНИЙ список — і я називаю його чорним. Він працює ЛИШЕ на вільному
# тексті (хвіст журналу), де білого списку не буває. Усе структуроване в цьому
# файлі збирається білим списком полів, а не фільтром.
_SECRET_PAT = re.compile(r"(sk-[A-Za-z0-9_\-]{12,}|\d{8,10}:AA[A-Za-z0-9_\-]{20,}|AIza[A-Za-z0-9_\-]{20,})")


def _mask(text: str) -> str:
    t = str(text or "")
    for v in _secret_values():
        t = t.replace(v, "[приховано]")
    t = _SECRET_PAT.sub("[приховано]", t)
    return t


def _line(text) -> str:
    t = _mask(text).replace("\r", "").replace("\n", " ").strip()
    return t[:MAX_LINE] + ("…" if len(t) > MAX_LINE else "")


def _dt(ts) -> str:
    """Дата у форматі Андрія: DD.MM.YYYY HH:MM."""
    try:
        if isinstance(ts, (int, float)):
            d = datetime.fromtimestamp(ts)
        else:
            d = datetime.fromisoformat(str(ts))
        return d.strftime("%d.%m.%Y %H:%M")
    except Exception:
        return str(ts or "")


def _count(path: Path, pattern="*") -> int:
    try:
        return len([p for p in Path(path).glob(pattern) if not p.name.startswith("_")])
    except Exception:
        return 0


# ─────────────────────── розділи звіту (БІЛИЙ список) ───────────────────────

def _passport(opt) -> list:
    out = []
    brain = {}
    try:
        brain = config.provider_status()
    except Exception:
        pass
    out.append("Версія SensFlow: %s" % getattr(config, "APP_VERSION", "?"))
    out.append("Система: %s %s, Python %s" % (platform.system(), platform.release(),
                                              sys.version.split()[0]))
    out.append("Порт консолі: %s" % getattr(config, "PORT", "?"))
    out.append("Мозок: %s (%s)" % (brain.get("brain_model", "?"), brain.get("brain_provider", "?")))
    out.append("Виконавець: %s (%s)" % (brain.get("worker_model", "?"), brain.get("worker_provider", "?")))
    out.append("Ключ провайдера: %s" % ("є" if brain.get("ready") else "НЕМАЄ"))
    out.append("Веб-пошук: %s" % ("увімкнено" if brain.get("web_search") else "вимкнено"))
    out.append("Стеля вартості одного запиту: $%s" % getattr(config, "MAX_RUN_USD", "?"))
    try:
        import license as _lic
        ent = _lic.entitlement()
        out.append("Ліцензія: %s — %s" % (ent.get("mode", "?"), _line(ent.get("message", ""))))
    except Exception:
        out.append("Ліцензія: прочитати не вдалося")
    return out


def _health(opt) -> list:
    out = []
    try:
        import registry
        out.append("Систем в оркестрі: %d" % len(registry.load_systems()))
    except Exception as ex:
        out.append("Реєстр систем: ПОМИЛКА — %s" % _line(ex))
    try:
        import artifacts
        caps = artifacts.capabilities()
        have = [k for k, v in caps.items() if v]
        out.append("Формати файлів: %s" % (", ".join(sorted(have)) or "лише md/html"))
    except Exception:
        pass
    try:
        import scheduler
        autos = scheduler.list_automations()
        on = len([a for a in autos if a.get("enabled")])
        out.append("Автоматизацій: %d (увімкнено %d)" % (len(autos), on))
    except Exception:
        pass
    idx = Path(config.PLATFORM_ROOT) / "tender_index" / "index.sqlite"
    out.append("Тендерний міст: %s" % ("на місці, %.1f МБ" % (idx.stat().st_size / 1e6)
                                       if idx.exists() else "НЕМАЄ"))
    out.append("Прогонів у теці runs: %d" % _count(config.RUNS_DIR, "run-*"))
    out.append("Чатів: %d" % _count(Path(config.STATE_DIR) / "threads", "*.json"))
    return out


def _activity(opt) -> list:
    """Останні прогони — МЕТАДАНІ. Текст задач сюди не потрапляє ніколи:
    для нього є окремий розділ, який вмикає сам клієнт."""
    out = []
    try:
        import audit
        recs = audit.tail(ACTIVITY_LIMIT)
    except Exception as ex:
        return ["Журнал прогонів прочитати не вдалося: %s" % _line(ex)]
    if not recs:
        return ["Записів про прогони ще немає."]
    for r in recs:
        out.append("%s · %s · %s%s" % (
            _dt(r.get("ts")), r.get("system_id", "?"), r.get("status", "?"),
            " · перевірено" if r.get("verified") else ""))
    return out


def _pauses(opt) -> list:
    out = []
    d = Path(config.STATE_DIR) / "runs_paused"
    try:
        files = sorted(d.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)[:5]
    except Exception:
        files = []
    if not files:
        return ["Пауз за вартістю немає."]
    for p in files:
        try:
            body = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        out.append("%s · %s · витрачено $%s зі стелі $%s" % (
            _dt(body.get("saved_at")), body.get("system_id", "?"),
            round(float(body.get("spent") or 0), 2), body.get("cap", "?")))
    return out or ["Пауз за вартістю немає."]


def _journal(opt) -> list:
    """Хвіст журналу самого продукту — рядки з ознакою помилки. Клієнт бачить
    їх усі до одного й може прибрати весь розділ."""
    try:
        import run_log
        path = run_log.latest("server")
    except Exception:
        path = None
    if not path:
        return ["Журнал сервера не знайдено (продукт запускали до появи журналу)."]
    try:
        lines = Path(path).read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception as ex:
        return ["Журнал прочитати не вдалося: %s" % _line(ex)]
    marks = ("traceback", "error", "помилка", "exception", "не вдалося",
             "failed", "аварія", "warning", "увага")
    bad = [ln for ln in lines if any(m in ln.lower() for m in marks)]
    tail = bad[-MAX_JOURNAL_LINES:] if bad else []
    if not tail:
        return ["У журналі останнього запуску повідомлень про помилки немає."]
    return [_line(ln) for ln in tail]


def _task_texts(opt) -> list:
    """ВИМКНЕНО за замовчуванням. Це слова самого клієнта — вмикає лише він."""
    try:
        import audit
        recs = audit.tail(ACTIVITY_LIMIT)
    except Exception:
        return ["Прочитати не вдалося."]
    return ["%s · %s: %s" % (_dt(r.get("ts")), r.get("system_id", "?"),
                             _line(r.get("task_preview", ""))) for r in recs] or ["Записів немає."]


# key, заголовок, пояснення клієнту, увімкнено за замовчуванням, будівник
BUILDERS = [
    ("passport", "Паспорт збірки",
     "Версія, модель, ліцензія. Ваших даних тут немає.", True, _passport),
    ("health", "Стан платформи",
     "Скільки систем, які формати файлів, чи на місці тендерна база.", True, _health),
    ("activity", "Останні прогони",
     "Коли, яка система, чим завершився. БЕЗ тексту ваших запитів.", True, _activity),
    ("pauses", "Зупинки за вартістю",
     "Коли платформа ставала на паузу через стелю витрат.", True, _pauses),
    ("journal", "Повідомлення про помилки",
     "Рядки з журналу останнього запуску. Прочитайте — і приберіть розділ, "
     "якщо там є щось зайве.", True, _journal),
    ("task_texts", "Теми моїх запитів",
     "Початок тексту задач (160 символів). Вимкнено: вмикайте, лише якщо "
     "проблема саме в конкретному запиті.", False, _task_texts),
]


def build(options=None) -> dict:
    """ОДИН обʼєкт звіту. Усе, що піде у файл, є ТУТ і показується клієнту."""
    opt = dict(options or {})
    sections = []
    for key, title, note, default_on, fn in BUILDERS:
        on = bool(opt.get(key, default_on))
        # ⭐ Вимкнений розділ НЕ ЗБИРАЄТЬСЯ ВЗАГАЛІ. Інакше його вміст жив би в
        # обʼєкті звіту — і поїхав би з першим же каналом, який серіалізує
        # обʼєкт цілком. «Вимкнено» має означати «цього немає», а не «є, але
        # ми домовились не показувати».
        if not on:
            sections.append({"key": key, "title": title, "note": note,
                             "on": False, "lines": []})
            continue
        try:
            lines = [_line(x) for x in (fn(opt) or [])]
        except Exception as ex:
            lines = ["Зібрати цей розділ не вдалося: %s" % _line(ex)]
        sections.append({"key": key, "title": title, "note": note,
                         "on": True, "lines": lines})
    return {"generated_at": datetime.now().strftime("%d.%m.%Y %H:%M"),
            "app": "SensFlow", "sections": sections}


def render(report: dict, message: str = "", keys=None) -> str:
    """Текст файлу. Джерело — ВИКЛЮЧНО report['sections']: рядка, якого клієнт
    не бачив у вікні, тут узятися нізвідки."""
    allsec = report.get("sections") or []
    if keys is None:
        chosen = [s for s in allsec if s.get("on")]
    else:
        chosen = [s for s in allsec if s.get("key") in set(keys)]
    # Порожній розділ у файл не пишемо: його вміст просто не збирали.
    chosen = [s for s in chosen if s.get("lines")]
    out = ["# SensFlow — звіт для розробника",
           "", "Дата: %s" % report.get("generated_at", ""), ""]
    out += ["## Що каже клієнт", "", _mask(message).strip() or "(без опису)", ""]
    for s in chosen:
        out.append("## %s" % s["title"])
        out.append("")
        for ln in s["lines"]:
            out.append("- %s" % ln)
        out.append("")
    machine = {"generated_at": report.get("generated_at", ""),
               "message": _mask(message).strip(),
               "sections": [{"key": s["key"], "lines": s["lines"]} for s in chosen]}
    out += ["---", "", "<!-- Машинний блок для розробника -->", "```json",
            json.dumps(machine, ensure_ascii=False, indent=1), "```", ""]
    return "\n".join(out)


def save(message: str = "", keys=None, options=None) -> dict:
    """Пише файл і повертає, куди саме. Нічого нікуди не надсилає."""
    report = build(options)
    text = render(report, message, keys)
    folder = reports_dir()
    folder.mkdir(parents=True, exist_ok=True)
    name = "Звіт SensFlow %s.md" % datetime.now().strftime("%d-%m-%Y %H-%M")
    path = folder / name
    path.write_text(text, encoding="utf-8")
    return {"ok": True, "path": str(path), "folder": str(folder), "name": name,
            "bytes": len(text.encode("utf-8"))}


def open_folder(path=None) -> bool:
    """Відкрити теку зі звітом у провіднику. Не вийшло — не біда: шлях клієнт
    уже бачить у вікні."""
    target = Path(path) if path else reports_dir()
    try:
        if platform.system() == "Windows":
            if target.is_file():
                subprocess.Popen(["explorer", "/select,", str(target)])
            else:
                os.startfile(str(target))  # noqa
        elif platform.system() == "Darwin":
            subprocess.Popen(["open", "-R" if target.is_file() else "", str(target)])
        else:
            subprocess.Popen(["xdg-open", str(target.parent if target.is_file() else target)])
        return True
    except Exception:
        return False
