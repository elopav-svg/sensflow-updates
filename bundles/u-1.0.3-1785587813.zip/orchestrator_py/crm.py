"""
crm.py — local-first CRM / сервіс-центр SensFlow (Фаза 3 дизайну
DESIGN_Оновлення_та_Сервіс-центр.md).

ПРИЗНАЧЕННЯ: тримає картки клієнтів — джерело правди для публікації оновлень
(per-client секрет, ліцензія, версія, застосовані оновлення, історія взаємодії).

БЕЗПЕКА — критично:
  • Файл `crm/clients.json` містить СЕКРЕТИ всіх клієнтів і живе ЛИШЕ в адмінській
    збірці. Він НІКОЛИ не входить у клієнтські пакети: лежить у корені платформи
    (поза orchestrator_py), тож make_client_build його не копіює.
  • Майстер-секрет (LICENSE_SIGNING_SECRET адміна) у клієнтські збірки більше не
    потрапляє — кожен клієнт має власний секрет, згенерований тут.

Лише stdlib. Запис атомарний (через .tmp + replace).
"""

import json
import re
import hashlib
import secrets as _secrets
from datetime import datetime, date, timedelta
from pathlib import Path

import config

# Сховище живе в КОРЕНІ платформи (поза рушієм) — щоб не потрапити в клієнтську збірку.
CRM_DIR = config.PLATFORM_ROOT / "crm"
CLIENTS_JSON = CRM_DIR / "clients.json"

# ── Воронка (канбан) ─────────────────────────────────────────────────────────
# Стадії руху клієнта. Частина переходів автоматична (де є реальний сигнал),
# решта — вручну (продажні стадії, рішення за власником).
STAGES = [
    "Новий клієнт", "Перемовини", "Пілотне випробування", "Укладення угоди",
    "Чекаємо оплати", "Активні клієнти", "Неактивні клієнти", "Архів",
]
DEFAULT_STAGE = "Новий клієнт"
STAGE_ARCHIVE = "Архів"
STAGE_ACTIVE = "Активні клієнти"
STAGE_PILOT = "Пілотне випробування"

# Імовірність закриття угоди за стадією (для прогнозу виручки).
STAGE_PROB = {
    "Новий клієнт": 0.10, "Перемовини": 0.30, "Пілотне випробування": 0.50,
    "Укладення угоди": 0.70, "Чекаємо оплати": 0.90, "Активні клієнти": 1.00,
    "Неактивні клієнти": 0.0, "Архів": 0.0,
}
EXPIRY_SOON_DAYS = 7  # за скільки днів до кінця ліцензії бити на сполох


def _num(s) -> float:
    """Дістає число з рядка суми ('150 000', '30000₴' → 150000.0). Порожнє → 0."""
    digits = re.sub(r"[^\d.]", "", str(s or "").replace(",", ""))
    try:
        return float(digits) if digits else 0.0
    except Exception:
        return 0.0


def _is_overdue(date_str: str) -> bool:
    """True, якщо дата (YYYY-MM-DD) у минулому відносно сьогодні."""
    try:
        return bool(date_str) and date.fromisoformat(str(date_str)[:10]) < date.today()
    except Exception:
        return False


def _expiry_soon(expiry: str) -> bool:
    """True, якщо термін (YYYY-MM-DD) спливає протягом EXPIRY_SOON_DAYS або вже минув."""
    try:
        if not expiry:
            return False
        return date.fromisoformat(str(expiry)[:10]) <= (date.today() + timedelta(days=EXPIRY_SOON_DAYS))
    except Exception:
        return False


def _due_reason(c: dict) -> str:
    """Чому картка потребує уваги (порожньо = не потребує). Лише для активних (не архів)."""
    if c.get("archived"):
        return ""
    na = c.get("next_action") or {}
    if _is_overdue(na.get("date")):
        return "Протермінована дія: " + (na.get("text") or "")
    if c.get("license_key") and _expiry_soon(c.get("expiry")):
        return "Ліцензія спливає: " + str(c.get("expiry") or "")
    return ""


def cust_hash(name: str) -> str:
    """Хеш імені клієнта (16 hex) — той самий, що в URL маніфесту publish_update.py."""
    return hashlib.sha256((name or "anon").encode("utf-8")).hexdigest()[:16]


def new_secret() -> str:
    """Випадковий per-client секрет підпису (URL-safe, ~256 біт)."""
    return _secrets.token_urlsafe(32)


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _norm(customer: str) -> str:
    return (customer or "").strip()


# ── Низькорівневе сховище ────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = json.loads(CLIENTS_JSON.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("clients", {})
    return d


def _save(d: dict) -> None:
    CRM_DIR.mkdir(parents=True, exist_ok=True)
    tmp = CLIENTS_JSON.with_name(CLIENTS_JSON.name + ".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(CLIENTS_JSON)


def _blank_card(customer: str) -> dict:
    return {
        "customer": customer,
        # Латинське (ASCII) імʼя для терміналу/збирача й чистих імен файлів.
        # Порожнє = використовуємо повне імʼя (стара поведінка).
        "name_en": "",
        "secret": new_secret(),
        "license_key": "",
        "edition": "",
        "expiry": "",
        "role": "admin",
        "version": "",
        "applied": [],
        "history": [],
        "notes": "",
        "dossier": "",
        "profile": {"org": "", "region": "", "industry": "", "website": "",
                    "phone": "", "email": "", "address": "", "about": ""},
        "contacts": [],
        "deal": {"one_time": "", "mrr": "", "currency": "₴"},
        "next_action": {"text": "", "date": ""},
        # Канали звʼязку для зіставлення вхідних повідомлень із карткою (Фаза 4).
        # email береться з profile/contacts; тут тримаємо Telegram-привʼязку.
        "channels": {"telegram_id": "", "telegram_user": "", "email": ""},
        "last_inbound": "",
        "stage": DEFAULT_STAGE,
        "attention": 0,
        "archived": False,
        "created": _now(),
        "updated": _now(),
    }


# Поля профілю організації (для UI-форми).
PROFILE_FIELDS = ["org", "region", "industry", "website", "phone", "email", "address", "about"]


# ── Публічне API ─────────────────────────────────────────────────────────────
def get_client(customer: str) -> dict:
    """Повна картка клієнта (із секретом) або None."""
    return _load()["clients"].get(_norm(customer))


def get_secret(customer: str) -> str:
    """Per-client секрет підпису. Порожньо, якщо картки немає."""
    return (get_client(customer) or {}).get("secret", "")


def resolve(handle: str) -> str:
    """Повертає КЛЮЧ (повне імʼя) картки за повним іменем АБО за латинським
    `name_en` — без урахування регістру. Дає змогу запускати збірку коротким
    ASCII-іменем (напр. «Smolyar») і потрапляти в ту саму картку без дублів.
    Порожньо, якщо нічого не знайдено."""
    h = _norm(handle)
    if not h:
        return ""
    clients = _load()["clients"]
    if h in clients:                      # точний збіг за повним іменем
        return h
    hl = h.lower()
    for name, c in clients.items():       # збіг за латинським іменем
        ne = str(c.get("name_en") or "").strip().lower()
        if ne and ne == hl:
            return name
    for name in clients:                  # запасний: повне імʼя без регістру
        if name.lower() == hl:
            return name
    return ""


def list_clients(archived: bool = False) -> list:
    """Короткий список карток для UI — БЕЗ секретів. archived=False → активні,
    True → архів (угоди, що не відбулися/неактивні клієнти)."""
    d = _load()
    out = []
    for name, c in sorted(d["clients"].items(), key=lambda kv: kv[0].lower()):
        if bool(c.get("archived")) != bool(archived):
            continue
        out.append({
            "customer": name,
            "edition": c.get("edition", ""),
            "expiry": c.get("expiry", ""),
            "version": c.get("version", ""),
            "applied": len(c.get("applied", []) or []),
            "history": len(c.get("history", []) or []),
            "notes": c.get("notes", ""),
            "stage": c.get("stage", DEFAULT_STAGE),
            "attention": int(c.get("attention", 0) or 0),
            "archived": bool(c.get("archived")),
            "updated": c.get("updated", ""),
            "has_secret": bool(c.get("secret")),
        })
    return out


def counts() -> dict:
    """Кількість активних та архівних карток (для заголовків UI)."""
    d = _load()
    act = sum(1 for c in d["clients"].values() if not c.get("archived"))
    arch = sum(1 for c in d["clients"].values() if c.get("archived"))
    return {"active": act, "archived": arch, "total": act + arch}


def set_archived(customer: str, flag: bool = True) -> dict:
    """Переносить картку в архів (угода не відбулася / неактивний) або повертає з нього.
    Тримає `stage` синхронним: архів → стадія «Архів»; відновлення → «Активні клієнти»."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    c["archived"] = bool(flag)
    c["stage"] = STAGE_ARCHIVE if flag else STAGE_ACTIVE
    c.setdefault("history", []).append(
        {"date": _now(), "type": "archive" if flag else "restore",
         "note": "Перенесено в архів" if flag else "Відновлено з архіву"})
    c["updated"] = _now()
    _save(d)
    return c


def set_stage(customer: str, stage: str) -> dict:
    """Переміщує картку на стадію воронки. `archived` тримається синхронним
    (стадія «Архів» ⇔ archived=True). Невідома стадія — ігнорується (повертає None)."""
    stage = (stage or "").strip()
    if stage not in STAGES:
        return None
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    prev = c.get("stage", DEFAULT_STAGE)
    c["stage"] = stage
    c["archived"] = (stage == STAGE_ARCHIVE)
    if prev != stage:
        c.setdefault("history", []).append(
            {"date": _now(), "type": "stage", "note": f"{prev} → {stage}"})
    c["updated"] = _now()
    _save(d)
    return c


def set_attention(customer: str, value=None, inc: int = 0) -> dict:
    """Позначка «потребує уваги» (лічильник на картці/стадії). value — точне число;
    inc — змінити на дельту. 0 прибирає позначку."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    cur = int(c.get("attention", 0) or 0)
    cur = int(value) if value is not None else (cur + int(inc))
    c["attention"] = max(0, cur)
    c["updated"] = _now()
    _save(d)
    return c


def board() -> dict:
    """Канбан-зріз: стадії в порядку + картки кожної стадії + лічильники.
    {stages:[...], by_stage:{stage:[cards]}, counts:{stage:n}, attention:{stage:n}}."""
    by_stage = {s: [] for s in STAGES}
    counts = {s: 0 for s in STAGES}
    attention = {s: 0 for s in STAGES}
    d = _load()
    for name, c in sorted(d["clients"].items(), key=lambda kv: kv[0].lower()):
        st = c.get("stage", DEFAULT_STAGE)
        if st not in by_stage:
            st = DEFAULT_STAGE
        _deal = c.get("deal") or {}
        _na = c.get("next_action") or {}
        by_stage[st].append({
            "customer": name, "edition": c.get("edition", ""),
            "expiry": c.get("expiry", ""), "version": c.get("version", ""),
            "applied": len(c.get("applied", []) or []),
            "mrr": _deal.get("mrr", ""), "one_time": _deal.get("one_time", ""),
            "currency": _deal.get("currency", "₴"),
            "next_action": _na.get("text", ""), "next_date": _na.get("date", ""),
            "attention": int(c.get("attention", 0) or 0), "stage": st,
            "due": bool(_due_reason(c)),
        })
        counts[st] += 1
        attention[st] += int(c.get("attention", 0) or 0)
    return {"stages": STAGES, "by_stage": by_stage, "counts": counts, "attention": attention}


def pipeline() -> dict:
    """Зведення воронки для дашборда: суми угод, прогноз за стадіями, що потребує уваги.
    Рахуємо лише по АКТИВНИХ (не архів). Прогноз = сума * імовірність стадії."""
    d = _load()
    active = [c for c in d["clients"].values() if not c.get("archived")]
    sum_one = sum(_num((c.get("deal") or {}).get("one_time")) for c in active)
    sum_mrr = sum(_num((c.get("deal") or {}).get("mrr")) for c in active)
    w_one = sum(_num((c.get("deal") or {}).get("one_time")) * STAGE_PROB.get(c.get("stage"), 0) for c in active)
    w_mrr = sum(_num((c.get("deal") or {}).get("mrr")) * STAGE_PROB.get(c.get("stage"), 0) for c in active)
    by_stage_val = {s: {"count": 0, "one_time": 0.0, "mrr": 0.0} for s in STAGES}
    for c in active:
        s = c.get("stage", DEFAULT_STAGE)
        if s not in by_stage_val:
            s = DEFAULT_STAGE
        dl = c.get("deal") or {}
        by_stage_val[s]["count"] += 1
        by_stage_val[s]["one_time"] += _num(dl.get("one_time"))
        by_stage_val[s]["mrr"] += _num(dl.get("mrr"))
    # Картки, що потребують уваги (протерміновані дії / кінець ліцензії / ручний бейдж).
    due = []
    for name, c in sorted(d["clients"].items(), key=lambda kv: kv[0].lower()):
        if c.get("archived"):
            continue
        reason = _due_reason(c)
        att = int(c.get("attention", 0) or 0)
        if reason or att:
            due.append({"customer": name, "stage": c.get("stage", DEFAULT_STAGE),
                        "reason": reason or "Позначено вручну", "attention": att})
    cur = "₴"
    for c in active:
        cur = (c.get("deal") or {}).get("currency") or cur
        break
    return {
        "clients": len(active),
        "currency": cur,
        "sum_one_time": round(sum_one), "sum_mrr": round(sum_mrr),
        "forecast_one_time": round(w_one), "forecast_mrr": round(w_mrr),
        "by_stage_value": by_stage_val,
        "due": due, "due_count": len(due),
        "stages": STAGES,
    }


def card_public(customer: str) -> dict:
    """Картка для UI без секрету (секрет ніколи не віддаємо у фронтенд).
    Бекфіл профілю/контактів для старих карток, щоб UI завжди мав структуру."""
    c = get_client(customer)
    if not c:
        return None
    pub = {k: v for k, v in c.items() if k != "secret"}
    pub["has_secret"] = bool(c.get("secret"))
    pub["name_en"] = pub.get("name_en") or ""  # бекфіл для старих карток
    prof = dict(pub.get("profile") or {})
    for f in PROFILE_FIELDS:
        prof.setdefault(f, "")
    pub["profile"] = prof
    pub["contacts"] = pub.get("contacts") or []
    deal = dict(pub.get("deal") or {})
    deal.setdefault("one_time", ""); deal.setdefault("mrr", ""); deal.setdefault("currency", "₴")
    pub["deal"] = deal
    na = dict(pub.get("next_action") or {})
    na.setdefault("text", ""); na.setdefault("date", "")
    pub["next_action"] = na
    pub["dossier"] = pub.get("dossier") or ""
    ch = dict(pub.get("channels") or {})
    ch.setdefault("telegram_id", ""); ch.setdefault("telegram_user", ""); ch.setdefault("email", "")
    pub["channels"] = ch
    pub["last_inbound"] = pub.get("last_inbound") or ""
    return pub


def set_dossier(customer: str, text: str) -> dict:
    """Замінює «Додаткову інформацію про клієнта» (ручне редагування)."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    c["dossier"] = text or ""
    c["updated"] = _now()
    _save(d)
    return c


def append_dossier(customer: str, text: str) -> dict:
    """Дописує блок у «Додаткову інформацію» з міткою дати (для авто-доповнення)."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    block = "[" + _now() + "] " + (text or "").strip()
    cur = (c.get("dossier") or "").rstrip()
    c["dossier"] = (cur + "\n\n" + block) if cur else block
    c["updated"] = _now()
    _save(d)
    return c


def set_deal(customer: str, deal: dict) -> dict:
    """Оновлює вартість угоди (one_time, mrr, currency)."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    cur = dict(c.get("deal") or {})
    for k in ("one_time", "mrr", "currency"):
        if k in (deal or {}) and deal[k] is not None:
            cur[k] = str(deal[k])
    c["deal"] = cur
    c["updated"] = _now()
    _save(d)
    return c


def set_next_action(customer: str, text: str, date: str = "") -> dict:
    """Задає наступну дію (та дедлайн) — щоб угода не зависла мовчки."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    c["next_action"] = {"text": (text or "").strip(), "date": (date or "").strip()}
    c["updated"] = _now()
    _save(d)
    return c


def mark_action_done(customer: str) -> dict:
    """«Дію виконано»: записує в історію факт виконання поточної наступної дії,
    гасить позначку «потребує уваги» (attention=0) і очищає саму дію. Один
    очевидний крок замість розрізнених «зберегти / очистити / комунікація»."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    na = c.get("next_action") or {}
    txt = (na.get("text") or "").strip()
    note = ("Дію виконано: " + txt) if txt else "Дію виконано"
    c.setdefault("history", []).append({"date": _now(), "type": "action_done", "note": note})
    c["next_action"] = {"text": "", "date": ""}
    c["attention"] = 0
    c["updated"] = _now()
    _save(d)
    return c


def set_profile(customer: str, profile: dict) -> dict:
    """Оновлює профіль організації (лише відомі поля)."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    cur = dict(c.get("profile") or {})
    for f in PROFILE_FIELDS:
        if f in (profile or {}) and profile[f] is not None:
            cur[f] = str(profile[f])
    c["profile"] = cur
    c["updated"] = _now()
    _save(d)
    return c


def add_contact(customer: str, contact: dict) -> dict:
    """Додає пов'язану особу (ім'я/роль/телефон/пошта/нотатка)."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    person = {k: str((contact or {}).get(k, "") or "")
              for k in ("name", "role", "phone", "email", "note")}
    if not person["name"]:
        return c
    c.setdefault("contacts", []).append(person)
    c.setdefault("history", []).append(
        {"date": _now(), "type": "contact", "note": f"Додано особу: {person['name']}"})
    c["updated"] = _now()
    _save(d)
    return c


def remove_contact(customer: str, index: int) -> dict:
    """Видаляє пов'язану особу за індексом."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    lst = c.get("contacts", []) or []
    try:
        i = int(index)
    except Exception:
        return c
    if 0 <= i < len(lst):
        lst.pop(i)
        c["contacts"] = lst
        c["updated"] = _now()
        _save(d)
    return c


def ensure_client(customer: str, **fields) -> dict:
    """Створює картку (з новим секретом) або оновлює наявну заданими полями.
    Секрет НІКОЛИ не перезаписується наявний. Повертає повну картку."""
    customer = _norm(customer)
    if not customer:
        raise ValueError("порожнє ім'я клієнта")
    d = _load()
    c = d["clients"].get(customer)
    if not c:
        c = _blank_card(customer)
        d["clients"][customer] = c
    allowed = {"name_en", "license_key", "edition", "expiry", "role", "version", "notes",
               "stage", "attention", "profile", "contacts", "deal", "next_action", "dossier",
               "channels", "last_inbound"}
    for k, v in fields.items():
        if k in allowed and v is not None:
            c[k] = v
    if not c.get("secret"):
        c["secret"] = new_secret()
    c["updated"] = _now()
    _save(d)
    return c


def add_history(customer: str, kind: str, note: str = "") -> dict:
    """Додає запис в історію взаємодії клієнта."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    c.setdefault("history", []).append({"date": _now(), "type": kind, "note": note})
    c["updated"] = _now()
    _save(d)
    return c


def record_update(customer: str, version: str, update_id: str) -> dict:
    """Фіксує направлене клієнту оновлення (версія + id + запис в історію)."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    if update_id and update_id not in (c.get("applied") or []):
        c.setdefault("applied", []).append(update_id)
    if version:
        c["version"] = version
    c.setdefault("history", []).append(
        {"date": _now(), "type": "update", "note": f"{version} ({update_id})"})
    c["updated"] = _now()
    _save(d)
    return c


def set_notes(customer: str, notes: str) -> dict:
    """Оновлює нотатки картки (створює картку, якщо немає)."""
    return ensure_client(customer, notes=notes or "")


def delete_client(customer: str) -> bool:
    d = _load()
    if _norm(customer) in d["clients"]:
        del d["clients"][_norm(customer)]
        _save(d)
        return True
    return False


# ── Фаза 4: інбаунд-сигнал (зіставлення вхідних повідомлень із карткою) ───────
# Коли клієнт пише в Telegram або на пошту — знаходимо його картку за каналом
# і піднімаємо позначку «потребує уваги». Якщо картки немає — вхідне не губиться
# (для пошти створюється «Новий клієнт», для Telegram — лягає в чергу inbox).

def _emails_of(c: dict) -> set:
    """Усі відомі адреси картки (профіль + контакти + явний канал), у нижньому регістрі."""
    out = set()
    e = ((c.get("profile") or {}).get("email") or "").strip().lower()
    if e:
        out.add(e)
    for ct in (c.get("contacts") or []):
        e = (ct.get("email") or "").strip().lower()
        if e:
            out.add(e)
    e = ((c.get("channels") or {}).get("email") or "").strip().lower()
    if e:
        out.add(e)
    return out


def find_by_email(email: str) -> str:
    """Імʼя клієнта за адресою пошти (профіль/контакти/канал) або порожньо."""
    email = (email or "").strip().lower()
    if not email:
        return ""
    for name, c in _load()["clients"].items():
        if email in _emails_of(c):
            return name
    return ""


def find_by_telegram(chat_id) -> str:
    """Імʼя клієнта за привʼязаним Telegram chat_id або порожньо."""
    cid = str(chat_id or "").strip()
    if not cid:
        return ""
    for name, c in _load()["clients"].items():
        if str((c.get("channels") or {}).get("telegram_id") or "").strip() == cid:
            return name
    return ""


def find_by_telegram_user(username: str) -> str:
    """Імʼя клієнта за Telegram-юзернеймом (@user) або порожньо."""
    u = (username or "").strip().lstrip("@").lower()
    if not u:
        return ""
    for name, c in _load()["clients"].items():
        cu = str((c.get("channels") or {}).get("telegram_user") or "").strip().lstrip("@").lower()
        if cu and cu == u:
            return name
    return ""


def link_telegram(customer: str, chat_id=None, username: str = "") -> dict:
    """Привʼязує Telegram chat_id/юзернейм до картки (щоб майбутні вхідні зіставлялись)."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    ch = dict(c.get("channels") or {})
    if chat_id is not None and str(chat_id).strip():
        ch["telegram_id"] = str(chat_id).strip()
    if username:
        ch["telegram_user"] = username.strip()
    c["channels"] = ch
    c["updated"] = _now()
    _save(d)
    return c


def link_email(customer: str, email: str) -> dict:
    """Зберігає явну адресу пошти в каналі картки (на додачу до профілю)."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    ch = dict(c.get("channels") or {})
    ch["email"] = (email or "").strip()
    c["channels"] = ch
    c["updated"] = _now()
    _save(d)
    return c


_CHANNEL_LABEL = {"telegram": "Telegram", "email": "Пошта"}


def note_inbound(customer: str, channel: str, preview: str = "") -> dict:
    """Реєструє вхідне повідомлення від клієнта: +1 до позначки «уваги», запис в історію,
    оновлення часу останнього вхідного. Це і є сигнал, що спалахує бейдж на канбані."""
    d = _load()
    c = d["clients"].get(_norm(customer))
    if not c:
        return None
    c["attention"] = int(c.get("attention", 0) or 0) + 1
    c["last_inbound"] = _now()
    label = _CHANNEL_LABEL.get(channel, channel or "канал")
    snippet = " ".join((preview or "").split())[:160]
    note = f"Вхідне ({label})" + (f": {snippet}" if snippet else "")
    c.setdefault("history", []).append({"date": _now(), "type": "inbound", "note": note})
    c["updated"] = _now()
    _save(d)
    return c


# ── Черга незіставлених вхідних (немає картки) ───────────────────────────────
INBOX_JSON = CRM_DIR / "_inbound_inbox.json"


def _inbox_load() -> list:
    try:
        v = json.loads(INBOX_JSON.read_text(encoding="utf-8"))
        return v if isinstance(v, list) else []
    except Exception:
        return []


def _inbox_save(items: list) -> None:
    CRM_DIR.mkdir(parents=True, exist_ok=True)
    tmp = INBOX_JSON.with_name(INBOX_JSON.name + ".tmp")
    tmp.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(INBOX_JSON)


def record_unmatched(channel: str, identity: str, name: str = "", preview: str = "") -> dict:
    """Вхідне від невідомого (немає картки) — щоб не загубилось. Власник у консолі
    може створити/привʼязати картку. Дублікати за (channel, identity) обʼєднуються."""
    items = _inbox_load()
    ident = str(identity or "").strip()
    snippet = " ".join((preview or "").split())[:200]
    for it in items:
        if it.get("channel") == channel and str(it.get("identity")) == ident:
            it["count"] = int(it.get("count", 1)) + 1
            it["last_seen"] = _now()
            if name:
                it["name"] = name
            if snippet:
                it["preview"] = snippet
            _inbox_save(items)
            return it
    rec = {"channel": channel, "identity": ident, "name": (name or "").strip(),
           "preview": snippet, "count": 1, "first_seen": _now(), "last_seen": _now()}
    items.append(rec)
    _inbox_save(items)
    return rec


def inbox() -> list:
    """Незіставлені вхідні (для UI: вхідні без картки)."""
    return _inbox_load()


def clear_inbox(channel: str, identity: str) -> bool:
    """Прибирає елемент черги (після привʼязки/створення картки)."""
    items = _inbox_load()
    ident = str(identity or "").strip()
    kept = [it for it in items if not (it.get("channel") == channel and str(it.get("identity")) == ident)]
    if len(kept) != len(items):
        _inbox_save(kept)
        return True
    return False
