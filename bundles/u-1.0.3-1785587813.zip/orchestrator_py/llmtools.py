"""
llmtools.py — провайдер-агностичний tool-calling (OpenAI + Anthropic).

Дає ОДНУ функцію tool_turn(): надсилає модель повідомлення + набір інструментів і
повертає нормалізований результат — або текст (фінальна відповідь), або список
викликів інструментів. Уся різниця між провайдерами схована тут.

Нейтральні формати (єдині для обох провайдерів):
  Повідомлення:
    {"role":"user","content": str}
    {"role":"assistant","content": str, "tool_calls":[{"id","name","args":dict}]}
    {"role":"tool","tool_call_id": str, "name": str, "content": str}
  Інструмент (схема):
    {"name": str, "description": str, "parameters": {<json schema для args>}}
"""

import json

import config
import llm  # використовуємо llm._http_post (лог + таймаут) та винятки


# ---------------------------------------------------------------------------
# Конвертери: нейтральне -> формат провайдера
# ---------------------------------------------------------------------------
def to_openai_tools(tools: list) -> list:
    return [{"type": "function",
             "function": {"name": t["name"], "description": t.get("description", ""),
                          "parameters": t.get("parameters", {"type": "object", "properties": {}})}}
            for t in tools]


def to_openai_messages(system: str, messages: list) -> list:
    out = [{"role": "system", "content": system}]
    for m in messages:
        role = m.get("role")
        if role == "user":
            out.append({"role": "user", "content": m.get("content", "")})
        elif role == "assistant":
            a = {"role": "assistant", "content": m.get("content") or None}
            if m.get("tool_calls"):
                a["tool_calls"] = [{"id": tc["id"], "type": "function",
                                    "function": {"name": tc["name"],
                                                 "arguments": json.dumps(tc.get("args", {}), ensure_ascii=False)}}
                                   for tc in m["tool_calls"]]
            out.append(a)
        elif role == "tool":
            out.append({"role": "tool", "tool_call_id": m.get("tool_call_id"),
                        "content": m.get("content", "")})
    return out


def to_anthropic_tools(tools: list) -> list:
    return [{"name": t["name"], "description": t.get("description", ""),
             "input_schema": t.get("parameters", {"type": "object", "properties": {}})}
            for t in tools]


def to_anthropic_messages(messages: list) -> list:
    """Нейтральні -> Anthropic. Tool-результати збираються в один user-блок."""
    out = []
    pending_results = []

    def flush_results():
        if pending_results:
            out.append({"role": "user", "content": list(pending_results)})
            pending_results.clear()

    for m in messages:
        role = m.get("role")
        if role == "tool":
            pending_results.append({"type": "tool_result", "tool_use_id": m.get("tool_call_id"),
                                    "content": m.get("content", "")})
            continue
        flush_results()
        if role == "user":
            out.append({"role": "user", "content": [{"type": "text", "text": m.get("content", "")}]})
        elif role == "assistant":
            blocks = []
            if m.get("content"):
                blocks.append({"type": "text", "text": m["content"]})
            for tc in m.get("tool_calls", []) or []:
                blocks.append({"type": "tool_use", "id": tc["id"], "name": tc["name"],
                               "input": tc.get("args", {})})
            out.append({"role": "assistant", "content": blocks or [{"type": "text", "text": ""}]})
    flush_results()
    return out


# ---------------------------------------------------------------------------
# Парсери відповіді -> нейтральне
# ---------------------------------------------------------------------------
def _parse_openai(data: dict) -> dict:
    try:
        msg = data["choices"][0]["message"]
    except (KeyError, IndexError):
        raise llm.LLMError(f"OpenAI tool: неочікувана відповідь: {json.dumps(data)[:300]}")
    text = msg.get("content")
    calls = []
    for tc in msg.get("tool_calls", []) or []:
        fn = tc.get("function", {})
        try:
            args = json.loads(fn.get("arguments") or "{}")
        except Exception:
            args = {}
        calls.append({"id": tc.get("id"), "name": fn.get("name"), "args": args})
    fr = (data.get("choices") or [{}])[0].get("finish_reason")
    if not calls and not (text or "").strip():
        # Порожній хід (типово Gemini: MALFORMED_FUNCTION_CALL / MAX_TOKENS) —
        # залишаємо слід причини в консолі для діагностики.
        llm._log(f"[llmtools] порожній tool-хід: finish_reason={fr}")
    # Нормалізуємо причину обриву в спільний код "max_tokens", щоб виклики (мозок і
    # калькулятор виконавця) однаково розпізнавали обрізаний хід.
    stop = "max_tokens" if fr in ("length", "max_tokens", "MAX_TOKENS") else fr
    return {"text": text, "tool_calls": calls, "stop_reason": stop}


def _parse_anthropic(data: dict) -> dict:
    text_parts, calls = [], []
    for b in data.get("content", []) or []:
        if b.get("type") == "text":
            text_parts.append(b.get("text", ""))
        elif b.get("type") == "tool_use":
            calls.append({"id": b.get("id"), "name": b.get("name"), "args": b.get("input", {})})
    # stop_reason=="max_tokens" → хід обрізано (напр. задовгий код калькулятору).
    return {"text": ("\n".join(text_parts).strip() or None), "tool_calls": calls,
            "stop_reason": data.get("stop_reason")}


# ---------------------------------------------------------------------------
# Головна функція
# ---------------------------------------------------------------------------
def tool_turn(system: str, messages: list, tools: list, model: str = None,
              max_tokens: int = None) -> dict:
    """Один хід моделі з інструментами. Повертає {"text": str|None, "tool_calls":[...]}"""
    # Мозок теж мусить знати реальну дату (інакше «оркестратор думає, що зараз 2024»).
    # Це той самий єдиний нотатник дати, що й у llm.complete/search_complete.
    system = llm.today_note() + (system or "")
    max_tokens = max_tokens or config.MAX_OUTPUT_TOKENS
    mdl = model or config.brain_model()
    prov = config.provider_for_model(mdl)  # маршрут за моделлю -> змішування ролей
    if prov == "anthropic":
        if not config.ANTHROPIC_API_KEY:
            raise llm.LLMNotConfigured("ANTHROPIC_API_KEY не заданий")
        _hdr = {"Content-Type": "application/json", "x-api-key": config.ANTHROPIC_API_KEY,
                "anthropic-version": "2023-06-01"}
        a_tools = to_anthropic_tools(tools)
        a_msgs = to_anthropic_messages(messages)

        def _payload(use_cache):
            # Prompt caching: системний промпт + інструменти мозку великі й повторюються
            # щоходу. Кешування робить повторні читання ≈ на 90% дешевшими. Маркер на
            # system кешує весь префікс (tools + system) — за порядком Anthropic.
            sys_field = system
            if use_cache and system and len(system) > 2000:
                sys_field = [{"type": "text", "text": system,
                              "cache_control": {"type": "ephemeral"}}]
            return {"model": mdl, "max_tokens": max_tokens, "system": sys_field,
                    "messages": a_msgs, "tools": a_tools}

        try:
            data = llm._http_post("https://api.anthropic.com/v1/messages", _hdr, _payload(True))
        except llm.LLMError as e:
            # Якщо провайдер не прийняв cache_control (HTTP 400) — повтор без кешу.
            if "HTTP 400" in str(e):
                llm._log("[llmtools] anthropic: повтор без prompt-caching")
                data = llm._http_post("https://api.anthropic.com/v1/messages", _hdr, _payload(False))
            else:
                raise
        return _parse_anthropic(data)
    # OpenAI-сумісні (OpenAI або Gemini через OpenAI-ендпоінт)
    base, key = config.openai_compat(prov)
    if not key:
        raise llm.LLMNotConfigured(f"Немає API-ключа провайдера {prov}")
    payload = {
        "model": mdl,
        "messages": to_openai_messages(system, messages),
        "tools": to_openai_tools(tools),
        "tool_choice": "auto",
        "max_tokens": max_tokens,
    }
    data = llm._http_post(
        f"{base}/chat/completions",
        {"Content-Type": "application/json", "Authorization": f"Bearer {key}"},
        payload,
    )
    return _parse_openai(data)
