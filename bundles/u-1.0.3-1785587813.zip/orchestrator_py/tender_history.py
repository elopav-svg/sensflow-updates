# -*- coding: utf-8 -*-
"""
tender_history.py — АРХІВ ТОРГІВ: що вже ВІДБУЛОСЬ (або не відбулось).

НАВІЩО (живий запит клієнта, 01.08.2026). Клієнт попросив «усі тендери в нашій
ніші з початку 2025 року по сьогодні, де фігурують назви …; таблиця з номером,
посиланням, відбувся чи ні, причиною, сумою тендера, сумою перемоги, вартістю
виробу, замовником, переможцем і назвою предмета». Платформа мала рівно один
тендерний ресурс — «активні торги за профілем». Він показує ЛИШЕ те, у чому ще
можна взяти участь, і чесно сказав, що архів поза його межами.

⭐⭐⭐ УРОК: РЕСУРС, ЯКИЙ ВМІЄ ЛИШЕ «ЗАРАЗ», НЕ ВМІЄ ВІДПОВІСТИ НА «ЗА ПЕРІОД».
Це не збій сторожа і не привід послаблювати його: сторож робить свою роботу
правильно. Бракувало ДРУГОЇ роботи — погляду назад.

ДЕ ТУТ ПРАВДА, А ДЕ МЕЖА (усе видно в самому звіті, не в коментарях):
  * фільтр дат на сервері пошуку НЕ працює — період відрізаємо самі, за датою
    в номері `UA-РРРР-ММ-ДД-…` (доведено розвідкою 27.07.2026);
  * сортування пошуку — за релевантністю, тому кількість чесна лише на ПОВНОМУ
    обході; неповний обхід позначається словами, а не мовчанням;
  * переможець і сума перемоги живуть НЕ в пошуку, а в картці й нагородах
    (awards) — це окремий, дорожчий за часом крок. Він має стелю (`deep_limit`),
    і скільки рядків лишилось без глибини — написано в звіті. Мовчазних
    обрізань тут немає.

Мережа — виключно через `tender_source_ua` (спільні ворота виходу netfetch).
Прогін БЕЗКОШТОВНИЙ: модель не питається жодного разу.
"""

import time

import tender_source_ua as SRC
import tender_profile as TP

_DEEP_DEFAULT = 60          # скільки рядків поглиблюємо за замовчуванням
_DEEP_HARD = 400            # запобіжник: більше за один прогін не ходимо
_PAUSE = 0.2                # пауза між зверненнями — проти ліміту частоти
_INDEX_PAGES = 80           # стеля сторінок ДОБОРУ мосту номерів (0 — не добирати)

# Статус джерела -> слова людини. Невідомий статус віддаємо ЯК Є: вигадувати
# переклад означало б підмінити факт джерела власним припущенням.
_STATUS_HUMAN = {
    "complete": "відбувся",
    "cancelled": "не відбувся (скасовано)",
    "unsuccessful": "не відбувся (без результату)",
    "active.tendering": "триває (приймають пропозиції)",
    "active.enquiries": "триває (період запитань)",
    "active.auction": "триває (аукціон)",
    "active.qualification": "триває (кваліфікація)",
    "active.pre-qualification": "триває (перед-кваліфікація)",
    "active.awarded": "триває (визначено переможця)",
    "draft": "чернетка",
}


def human_status(status):
    return _STATUS_HUMAN.get((status or "").strip(), (status or "").strip() or "—")


def _money_text(amount, currency):
    if amount is None:
        return ""
    try:
        s = "{:,.2f}".format(float(amount)).replace(",", " ").replace(".", ",")
    except (TypeError, ValueError):
        return ""
    return (s + " " + (currency or "")).strip()


def _date_tuple(ddmmyyyy):
    try:
        d, m, y = (ddmmyyyy or "").split(".")
        return (int(y), int(m), int(d))
    except (ValueError, AttributeError):
        return None


def _in_period(announced, date_from, date_to):
    """Межі включні. Немає дати оголошення — рядок ЛИШАЄМО і позначаємо:
    викидати те, чого не зміг розібрати, — це тихе звуження відповіді."""
    a = _date_tuple(announced)
    if a is None:
        return True
    if date_from and a < (_date_tuple(date_from) or a):
        return False
    if date_to and a > (_date_tuple(date_to) or a):
        return False
    return True


def norm_words(words):
    """Слова пошуку: рядок через кому/крапку з комою або список. Порожньо —
    беремо ПІДТВЕРДЖЕНІ ВИРОБНИКОМ слова профілю (те саме джерело, що й у
    сторожа): питати в клієнта те, що вже лежить у платформі, — зайве."""
    if isinstance(words, (list, tuple)):
        out = [str(w).strip() for w in words if str(w).strip()]
    else:
        raw = str(words or "")
        for sep in (";", "\n", ","):
            raw = raw.replace(sep, "|")
        out = [w.strip() for w in raw.split("|") if w.strip()]
    if out:
        return out, "слова із запиту"
    try:
        prof = [w for w in (TP.queries() or []) if w]
    except Exception:
        prof = []
    return prof, "підтверджені виробником слова профілю"


def _uuid_for(tender_id, index_pages):
    """Номер -> внутрішній код тендера. ОДИН ПИСАР — міст `tender_index`.

    ⭐⭐⭐ 01.08.2026, живий прогін у Андрія. Спершу я вигадав другі двері —
    «картку прямо за номером» у CDB. Вони НЕ ВІДЧИНЯЮТЬСЯ (`TenderSourceError`
    на всіх чотирьох тендерах), і я їх прибрав: двері, які не відчиняються, —
    це обіцянка, за яку платить клієнт.

    Правильний механізм у продукті вже був. Міст відповідає ТРЬОМА станами:
      found   — ось код;
      absent  — відрізок обійдено повністю, номера немає (це певність);
      unknown — туди ще не ходили. Саме сюди потрапили свіжі тендери: міст
                покривав період до 25.07.2026, а рядки були від 28–31.07.
    На `unknown` міст уміє ДОБРАТИ покриття від дати оголошення (`autofill`).
    Добір платить ЧАСОМ один раз: він спільний, тож наступні рядки резолвяться
    безкоштовно. `index_pages=0` вимикає добір — тоді рядок чесно лишається
    без глибини і КАЖЕ причину.
    """
    try:
        import tender_index as TI
    except Exception as e:
        return "", "міст номерів недоступний (%s)" % type(e).__name__
    try:
        if int(index_pages or 0) > 0:
            res = TI.resolve_uuid(tender_id, autofill=True, max_pages=int(index_pages))
        else:
            res = TI.lookup(tender_id)
    except Exception as e:
        return "", "міст номерів не відповів (%s)" % type(e).__name__
    st = (res or {}).get("status")
    if st == "found":
        return (res.get("uuid") or ""), ""
    if st == "absent":
        return "", "джерело не має цього номера у стрічці"
    return "", (res.get("why") or "міст номерів ще не покриває цей період")


def _deep_facts(tender_id, uuid=""):
    """Переможець, сума перемоги, причина невдачі, предмет і ціна за одиницю.

    Дві звірки на тендер: картка + нагороди. Переможцем вважаємо ЛИШЕ нагороду
    в статусі `active` — «розглядається» переможцем не є. Ціна за одиницю —
    ПОХІДНЕ значення, і рахуємо його лише коли предмет ОДИН і кількість відома;
    інакше порожньо. Похідне число, подане як факт джерела, — початок другої правди.
    """
    out = {"deep": False, "why": "", "winner": "", "win_amount": None, "win_currency": "",
           "reason": "", "subject": "", "unit_price": None, "qty": None, "unit": "",
           "deep_via": ""}
    if not uuid:
        out["why"] = "внутрішній код тендера невідомий"
        return out
    try:
        card = SRC.fetch_card(uuid)
        out["deep_via"] = "міст номерів"
    except Exception as e:
        out["why"] = "картка недоступна (%s)" % type(e).__name__
        return out
    uuid = (card.get("id") or uuid or "").strip()
    items = card.get("items") if isinstance(card.get("items"), list) else []
    if items:
        first = items[0] or {}
        out["subject"] = (first.get("description") or "").strip()
        if len(items) == 1:
            try:
                out["qty"] = float(first.get("quantity")) if first.get("quantity") is not None else None
            except (TypeError, ValueError):
                out["qty"] = None
            out["unit"] = ((first.get("unit") or {}).get("name") or "").strip()
    # причина, чому не відбувся — беремо ТІЛЬКИ з джерела
    reasons = []
    for c in (card.get("cancellations") or []):
        if isinstance(c, dict) and (c.get("status") == "active" or not c.get("status")):
            r = (c.get("reason") or "").strip()
            if r:
                reasons.append(r)
    ur = card.get("unsuccessfulReason")
    if isinstance(ur, list):
        reasons.extend([str(x).strip() for x in ur if str(x).strip()])
    elif isinstance(ur, str) and ur.strip():
        reasons.append(ur.strip())
    out["reason"] = "; ".join(reasons)[:400]
    try:
        aws = SRC.awards(uuid) or []
    except Exception as e:
        out["deep"] = True
        out["why"] = "нагороди недоступні (%s)" % type(e).__name__
        return out
    for a in aws:
        if not isinstance(a, dict) or a.get("status") != "active":
            continue
        sup = (a.get("suppliers") or [{}])[0] or {}
        out["winner"] = (sup.get("name") or (sup.get("identifier") or {}).get("legalName") or "").strip()
        amt, cur = SRC._money(a.get("value"))
        out["win_amount"], out["win_currency"] = amt, cur
        break
    if out["win_amount"] is not None and out["qty"]:
        try:
            out["unit_price"] = round(float(out["win_amount"]) / float(out["qty"]), 2)
        except (TypeError, ValueError, ZeroDivisionError):
            out["unit_price"] = None
    out["deep"] = True
    return out


def build(words=None, date_from=None, date_to=None, statuses=None,
          deep_limit=None, max_pages=None, index_pages=_INDEX_PAGES, progress=None):
    """-> {ok, rows, markdown, stats, reason}. Мережа може впасти: тоді ok=False
    і причина словами — тиха порожнеча заборонена."""
    wl, wsrc = norm_words(words)
    if not wl:
        return {"ok": False, "rows": [], "markdown": "", "stats": {},
                "reason": ("немає слів для пошуку: у запиті їх не було, і профіль продукції "
                           "порожній — назвіть слова або підтвердіть профіль")}
    try:
        deep_limit = int(deep_limit) if deep_limit not in (None, "") else _DEEP_DEFAULT
    except (TypeError, ValueError):
        deep_limit = _DEEP_DEFAULT
    deep_limit = max(0, min(deep_limit, _DEEP_HARD))
    st = None
    if statuses:
        st = ([s.strip() for s in str(statuses).replace(";", ",").split(",") if s.strip()]
              if not isinstance(statuses, (list, tuple)) else list(statuses))

    found, partial_words = {}, []
    for w in wl:
        if callable(progress):
            try:
                progress("search", w, 0, 0)
            except Exception:
                pass
        try:
            res = (SRC.search_all(w, statuses=st, max_pages=int(max_pages))
                   if max_pages else SRC.search_all(w, statuses=st))
        except Exception as e:
            return {"ok": False, "rows": [], "markdown": "", "stats": {},
                    "reason": "джерело не віддало дані на слові «%s» (%s: %s)"
                              % (w, type(e).__name__, e)}
        if not res.get("complete"):
            partial_words.append(w)
        for it in (res.get("items") or []):
            rec = SRC.brief(it)
            tid = rec.get("tender_id")
            if not tid or tid in found:
                continue
            rec["uuid"] = (it.get("id") or "")   # пошук віддає uuid разом із номером
            rec["match"] = w
            found[tid] = rec
        time.sleep(_PAUSE)

    rows = [r for r in found.values() if _in_period(r.get("announced"), date_from, date_to)]
    rows.sort(key=lambda r: (_date_tuple(r.get("announced")) or (0, 0, 0)), reverse=True)
    dropped = len(found) - len(rows)

    deepened, deep_failed = 0, []
    for r in rows:
        if deepened >= deep_limit:
            r["deep_note"] = "поза стелею глибини"
            continue
        uid, _uwhy = _uuid_for(r.get("tender_id"), index_pages)
        if not uid:
            r["deep_note"] = _uwhy
            deep_failed.append("%s (%s)" % (r.get("tender_id"), _uwhy))
            continue
        f = _deep_facts(r.get("tender_id"), uid)
        r.update(f)
        r["deep_note"] = f.get("why") or ""
        # ⭐⭐⭐ 01.08.2026. ЛІЧИЛЬНИК, ЯКИЙ РАХУЄ НЕВДАЧІ ЯК УСПІХ, — ЦЕ ДРУГА ПРАВДА.
        # Перша версія писала «поглиблено 5» навіть тоді, коли жодна картка не
        # відкрилась: клієнт бачив би порожні колонки й вирішив, що переможців
        # НЕ БУЛО. Тепер невдачі рахуються окремо і НАЗИВАЮТЬСЯ у звіті.
        if not f.get("deep"):
            deep_failed.append("%s (%s)" % (r.get("tender_id"), f.get("why") or "причина невідома"))
            continue
        deepened += 1
        if callable(progress):
            try:
                progress("deep", r.get("tender_id"), deepened, min(deep_limit, len(rows)))
            except Exception:
                pass
        time.sleep(_PAUSE)

    stats = {"words": wl, "words_source": wsrc, "found": len(found), "in_period": len(rows),
             "dropped_by_period": dropped, "deepened": deepened,
             "shallow": max(0, len(rows) - deepened), "partial_words": partial_words,
             "deep_limit": deep_limit, "deep_failed": deep_failed,
             "index_pages": index_pages}
    return {"ok": True, "rows": rows, "markdown": render(rows, stats, date_from, date_to),
            "stats": stats, "reason": ""}


def _cell(v):
    s = ("" if v is None else str(v)).replace("|", "/").replace("\n", " ").strip()
    return s or "—"


def render(rows, stats, date_from=None, date_to=None):
    """Звіт для людини. Таблиця стає .xlsx силами матеріалізатора артефактів —
    другого складача Excel у продукті свідомо немає."""
    per = ""
    if date_from or date_to:
        per = " за період %s — %s" % (date_from or "початок", date_to or "сьогодні")
    out = ["# Архів торгів Прозорро%s" % per, ""]
    out.append("Слова пошуку (%s): %s" % (stats.get("words_source", ""),
                                          ", ".join("«%s»" % w for w in stats.get("words") or [])))
    out.append("")
    out.append("| № | Номер | Відбувся | Причина | Сума тендера | Сума перемоги | "
               "Ціна за одиницю | Замовник | Переможець | Предмет | Оголошено | Посилання |")
    out.append("|---|---|---|---|---|---|---|---|---|---|---|---|")
    for i, r in enumerate(rows, 1):
        unit = ""
        if r.get("unit_price") is not None:
            unit = "%s%s" % (_money_text(r.get("unit_price"), r.get("win_currency")),
                             (" / " + r["unit"]) if r.get("unit") else "")
        out.append("| %d | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s | %s |" % (
            i, _cell(r.get("tender_id")), _cell(human_status(r.get("status"))),
            _cell(r.get("reason")), _cell(_money_text(r.get("amount"), r.get("currency"))),
            _cell(_money_text(r.get("win_amount"), r.get("win_currency"))), _cell(unit),
            _cell(r.get("buyer")), _cell(r.get("winner")),
            _cell(r.get("subject") or r.get("title")), _cell(r.get("announced")),
            _cell(r.get("url"))))
    out.append("")
    out.append("## Межі цієї вибірки")
    out.append("")
    out.append("- Знайдено за словами: **%d**; у заданому періоді: **%d**"
               % (stats.get("found", 0), stats.get("in_period", 0)))
    if stats.get("dropped_by_period"):
        out.append("- Поза періодом відкинуто: **%d**" % stats["dropped_by_period"])
    out.append("- Поглиблено (переможець, сума перемоги, причина): **%d** із %d; "
               "без глибини лишилось: **%d** (стеля глибини на прогін — %d)"
               % (stats.get("deepened", 0), stats.get("in_period", 0),
                  stats.get("shallow", 0), stats.get("deep_limit", 0)))
    if stats.get("shallow"):
        out.append("  Рядки без глибини мають заповнені номер, суму тендера, замовника й "
                   "статус, але порожні «переможець» і «сума перемоги» — це НЕ означає, "
                   "що переможця не було. Щоб добрати їх, повторіть із більшою стелею глибини.")
    if stats.get("deep_failed") and not stats.get("index_pages"):
        out.append("- Добір мосту номерів вимкнено (`index_pages=0`), тому для свіжих "
                   "тендерів переможець недоступний. Увімкніть добір — і глибина "
                   "зʼявиться.")
    if stats.get("deep_failed"):
        out.append("- ⚠ Глибину НЕ вдалося взяти для %d тендер(ів): %s. У цих рядках "
                   "переможець і сума перемоги порожні ТОМУ, ЩО ДЖЕРЕЛО НЕ ВІДПОВІЛО, "
                   "а не тому, що переможця не було."
                   % (len(stats["deep_failed"]), "; ".join(stats["deep_failed"][:5])
                      + (" …" if len(stats["deep_failed"]) > 5 else "")))
    if stats.get("partial_words"):
        out.append("- ⚠ Обхід джерела був НЕПОВНИЙ за словами: %s. Кількість по них "
                   "занижена — це стеля видачі пошуку, а не наш підрахунок."
                   % ", ".join("«%s»" % w for w in stats["partial_words"]))
    out.append("- Порожня клітинка означає «джерело цього не дало», а не нуль.")
    return "\n".join(out)


def history_job(**kwargs) -> dict:
    """Вхід реєстру робіт. Без моделі, прогін $0."""
    r = build(words=kwargs.get("words"), date_from=kwargs.get("date_from"),
              date_to=kwargs.get("date_to"), statuses=kwargs.get("statuses"),
              deep_limit=kwargs.get("deep_limit"), max_pages=kwargs.get("max_pages"),
              index_pages=kwargs.get("index_pages", _INDEX_PAGES))
    if not r.get("ok"):
        return {"status": "failed", "summary": r.get("reason") or "джерело не віддало дані"}
    if not r.get("rows"):
        return {"status": "completed",
                "summary": ("# Архів торгів Прозорро\n\nЗа заданими словами й періодом "
                            "жодного тендера не знайдено. Це відповідь джерела, а не збій.")}
    return {"status": "completed", "summary": r["markdown"]}


def ready():
    """Чи є з чим іти. Слова можуть прийти в запиті, тому відсутній профіль —
    не привід оголошувати роботу неготовою."""
    return True, ""
