"""client_catalog.py — каталог систем для клієнта, зібраний З РЕЄСТРУ ПАКЕТА.

⭐⭐⭐ 29.07.2026 (зміна 28). Каталог писали рукою: він обіцяв «20 систем», у пакет
їхало 18, а трьох систем, які клієнт РЕАЛЬНО отримує, у ньому не було взагалі.
Той самий клас, що й назва кореня: **факт про пакет, записаний у текст рукою,
рано чи пізно розійдеться з пакетом.**

Тому тут розділено дві речі:
  • ПРОЗА (призначення, приклад задачі) — дані, лежать у CATALOG_TEXTS;
  • ПЕРЕЛІК І КІЛЬКІСТЬ — рахуються з `registry/systems.json` САМОГО ПАКЕТА
    у мить збірки. Система без прози бере опис із реєстру — і все одно
    потрапляє в каталог, а не зникає мовчки.

Модуль НЕ їде клієнту: його імпортує лише збирач.
"""

from pathlib import Path
import json

TITLE_COLOR = "0E7C86"
FONT = "Arial"

GROUP_ORDER = ['Стратегія та бізнес', 'Право та документи', 'Контент і маркетинг', 'HR і люди', 'Розробка', 'Дашборди і звіти', 'Фінанси та Excel', 'Документи й операції', 'Пошук і перевірка', 'Спеціалізовані', 'Інші системи']

# Категорія реєстру → група каталогу (для систем без власної прози).
CATEGORY_GROUP = {
    "marketing": "Контент і маркетинг", "content": "Контент і маркетинг",
    "legal": "Право та документи", "documents": "Документи й операції",
    "hr": "HR і люди", "development": "Розробка", "dashboards": "Дашборди і звіти",
    "finance": "Фінанси та Excel", "operations": "Пошук і перевірка",
    "strategy": "Стратегія та бізнес",
}

HOWTO = 'SensFlow містить набір готових систем агентів. Вам не потрібно обирати систему вручну — оркестратор сам розпізнає задачу за змістом і запускає відповідну. Цей каталог потрібен радше для розуміння можливостей продукту.'

NOTE = 'Колонка «Чутливі дані»\n«Так» означає, що система типово працює з персональними, фінансовими або іншими чутливими даними. Для таких доменів оркестратор додатково перевіряє факти та джерела перед видачею результату.'

CATALOG_TEXTS = {
    "Бізнес-аналітика та стратегія запуску": {
        "group": "Стратегія та бізнес",
        "purpose": "Комплексна аналітика й стратегія запуску: оцінка ринку та конкурентів (живий веб-пошук), діагностика (SWOT/TOWS, бізнес-модель, ризики), стратегія і фінпрогноз (roadmap 30/90/365, ціни, KPI), план запуску, синтез радою директорів.",
        "example": "«Розроби стратегію запуску кав'ярні в Полтаві: ринок, конкуренти, фінмодель, план на 90 днів».",
        "sensitive": "Ні"
    },
    "Юрист-асистент": {
        "group": "Право та документи",
        "purpose": "Юридичний, нормативний і регуляторний аналіз документів, вимог, стандартів і правових ризиків. Жива звірка статей із законодавством під час прогону.",
        "example": "«Перевір цей договір на ризики для орендаря і запропонуй правки».",
        "sensitive": "Так"
    },
    "Копірайтерська система": {
        "group": "Контент і маркетинг",
        "purpose": "Дослідження, написання, адаптація і критика нерегуляторного контенту.",
        "example": "«Напиши пост у LinkedIn про наш запуск, впевнений тон, до 1200 знаків».",
        "sensitive": "Ні"
    },
    "Маркетинговий конвеєр": {
        "group": "Контент і маркетинг",
        "purpose": "Ринкове дослідження, контент-план, тексти і зображення під кампанію.",
        "example": "«Зроби контент-план на місяць для нашого Instagram із темами і текстами».",
        "sensitive": "Ні"
    },
    "Рекрутингова система": {
        "group": "HR і люди",
        "purpose": "Вакансії, пошук кандидатів, скоринг резюме і підготовка інтерв'ю.",
        "example": "«Склади вакансію менеджера з продажу й список питань для співбесіди».",
        "sensitive": "Так"
    },
    "Розробка програмного забезпечення": {
        "group": "Розробка",
        "purpose": "Конвеєр розробки ПЗ: від карти програми до збірки (інтерфейс, backend, frontend).",
        "example": "«Спроєктуй простий вебзастосунок обліку заявок: екрани і структура».",
        "sensitive": "Ні"
    },
    "Будівник мультиагентських систем": {
        "group": "Розробка",
        "purpose": "Створення нових систем агентів: аналіз задачі, промпти, структура папок, system.yaml і реєстрація в платформі.",
        "example": "«Створи нову систему агентів для обробки скарг клієнтів».",
        "sensitive": "Ні"
    },
    "Дашборд для власника": {
        "group": "Дашборди і звіти",
        "purpose": "Опитувальник, структурований звіт і керівний дашборд для власника бізнесу.",
        "example": "«Збери управлінський дашборд по ключових показниках за квартал».",
        "sensitive": "Так"
    },
    "Маркетинговий дашборд": {
        "group": "Дашборди і звіти",
        "purpose": "HTML/XLSX дашборди маркетингу: план-факт, підрозділи, товари, щомісячні звіти.",
        "example": "«Зроби маркетинговий дашборд план-факт за травень до наради».",
        "sensitive": "Так"
    },
    "HR Dashboard Analytics": {
        "group": "Дашборди і звіти",
        "purpose": "HTML/DOCX HR-аналітика по співробітниках, показниках і дашбордах персоналу.",
        "example": "«Підготуй аналітику персоналу: плинність, навантаження, ключові показники».",
        "sensitive": "Так"
    },
    "Excel і фінансове моделювання": {
        "group": "Фінанси та Excel",
        "purpose": "Аналіз і модифікація XLSX-моделей, бюджетів, балансів.",
        "example": "«Онови фінмодель: додай сценарій із +20% витрат на оренду».",
        "sensitive": "Так"
    },
    "Агро виробнича модель": {
        "group": "Фінанси та Excel",
        "purpose": "Excel-моделі виробництва агронапрямку, версії фінансово-виробничих розрахунків.",
        "example": "«Перерахуй виробничу модель агро під нову врожайність».",
        "sensitive": "Так"
    },
    "DIY операційні Excel-процеси": {
        "group": "Фінанси та Excel",
        "purpose": "Зведення продажів, табелі, зарплатні й мотиваційні Excel-процеси DIY-напрямку.",
        "example": "«Збери табель і розрахунок мотивації за місяць по точках».",
        "sensitive": "Так"
    },
    "Генератор промптів та інструкцій": {
        "group": "Документи й операції",
        "purpose": "Підготовка промптів, інструкцій і шаблонів завдань для операційних процесів.",
        "example": "«Зроби інструкцію-промпт для оператора обробки замовлень».",
        "sensitive": "Ні"
    },
    "Інструкції, профілі та функціональні обов'язки": {
        "group": "Документи й операції",
        "purpose": "Підготовка посадових інструкцій, профілів ролей, матриць відповідальності та процесних документів.",
        "example": "«Склади посадову інструкцію для менеджера з закупівель і матрицю відповідальності у відділі».",
        "sensitive": "Так"
    },
    "Логістика / Модернізація процесів": {
        "group": "Документи й операції",
        "purpose": "Матеріали для аудиту, модернізації та автоматизації логістичних процесів.",
        "example": "«Проведи аудит логістики складу й запропонуй модернізацію».",
        "sensitive": "Так"
    },
    "Пошук товарів та людей": {
        "group": "Пошук і перевірка",
        "purpose": "Source-first пошук товарів, продавців, постачальників, фізосіб, ФОП і публічних реєстрових згадок із перевіркою джерел і звітом.",
        "example": "«Знайди постачальників цього товару й порівняй ціни з джерелами».",
        "sensitive": "Так"
    },
    "Пошук об'єктів на маршруті": {
        "group": "Пошук і перевірка",
        "purpose": "Планування конкретної поїздки автомобілем або потягом: маршрут, об'єкти вздовж нього (де зупинитись, заночувати, що подивитись) і орієнтовні витрати. Живий веб-пошук: кожна рекомендація приходить із посиланням на джерело. П'ять агентів — уточнення запиту, побудова маршруту, пошук об'єктів, розрахунок витрат, перевірка якості.",
        "example": "«Сплануй поїздку Дніпро–Львів автомобілем на 3 дні: маршрут, де ночувати, що подивитись дорогою, скільки це коштуватиме».",
        "sensitive": "Ні"
    },
    "Garmin Health Analytics": {
        "group": "Спеціалізовані",
        "purpose": "Обробка Garmin-даних, health-аналітика і HTML-звіти (сон, HRV, пульс, навантаження).",
        "example": "«Проаналізуй мої дані Garmin за тиждень і зроби звіт».",
        "sensitive": "Так"
    },
    "Конкурентний heartbeat-моніторинг і звітність": {
        "group": "Спеціалізовані",
        "purpose": "Щотижневий збір новин конкурентів, моніторинг змін у продуктах, оцінка ризиків і executive summary.",
        "example": "«Щотижневий огляд змін у конкурентів із коротким executive summary».",
        "sensitive": "Ні"
    },
    "SEO/GEO-стратег": {
        "group": "Контент і маркетинг",
        "purpose": "Стратегія пошукового просування будь-якої сторінки або адреси, яку ви дали: ключі й наміри, правки на самій сторінці, а також цитованість у відповідях ШІ-пошуковиків. Ланцюг «розвідник → стратег → критик» видає пріоритетний план по сторінці; система нічого не публікує і не міряє трафік.",
        "example": "«Ось адреса сторінки послуги — дай план просування: ключі, правки на сторінці, що зробити першим».",
        "sensitive": "Ні"
    },
    "Пошук об'єктів і людей": {
        "group": "Пошук і перевірка",
        "purpose": "Пошук товарів, продавців, постачальників, фізичних осіб та ФОП із перевіркою джерел: спершу джерело, потім висновок. На виході — звіт із посиланнями.",
        "example": "«Знайди постачальників цього обладнання в Україні з цінами і джерелами».",
        "sensitive": "Так"
    }
}


def package_systems(build_root: Path) -> dict:
    """ЄДИНИЙ лічильник «скільки систем у пакеті» — і для каталогу, і для воріт.

    ⭐⭐⭐ Два лічильники однієї правди — головний убивця: ворота рахували ТЕКИ,
    каталог рахував РЕЄСТР, і на розбіжності сварилися одне на одного замість
    того, щоб назвати справжню проблему. Тут правда одна: реєстр пакета. Якщо
    теки з ним розійшлись — це САМО ПО СОБІ дефект, і ми його називаємо."""
    build_root = Path(build_root)
    p = build_root / "registry" / "systems.json"
    names = []
    if p.exists():
        data = json.loads(p.read_text(encoding="utf-8-sig"))
        names = [(s.get("id") or "") for s in data.get("systems", [])]
    gen = build_root / "generated_systems"
    folders = sorted(d.name for d in gen.iterdir() if d.is_dir()) if gen.is_dir() else []
    only_reg = sorted(set(names) - set(folders))
    only_dir = sorted(set(folders) - set(names))
    return {"count": len(names), "names": names, "folders": folders,
            "only_in_registry": only_reg, "only_in_folders": only_dir}


def _sys_entries(build_root: Path):
    """Перелік систем — З ПАКЕТА, а не з памʼяті автора."""
    p = Path(build_root) / "registry" / "systems.json"
    data = json.loads(p.read_text(encoding="utf-8-sig"))
    out = []
    for s in data.get("systems", []):
        name = s.get("name") or s.get("id")
        t = dict(CATALOG_TEXTS.get(name) or {})
        group = t.get("group") or CATEGORY_GROUP.get(s.get("category") or "", "Інші системи")
        out.append({
            "name": name,
            "group": group,
            "purpose": t.get("purpose") or (s.get("description") or "").strip(),
            "example": t.get("example") or "",
            "sensitive": "Так" if s.get("sensitive") else "Ні",
            # ⭐ Готовність БЕРЕТЬСЯ З РЕЄСТРУ. У старому каталозі про неї
            # писали рукою — і напис протух так само, як і кількість систем.
            # (Дослівну мітку тут не пишемо: її стереже tender_honesty_test.)
            "status": (s.get("status") or "active"),
        })
    return out


def _p(doc, text, size=11, bold=False, color=None, space_after=6):
    par = doc.add_paragraph()
    run = par.add_run(text)
    run.font.name = FONT
    run.bold = bold
    from docx.shared import Pt, RGBColor
    run.font.size = Pt(size)
    if color:
        run.font.color.rgb = RGBColor.from_string(color)
    par.paragraph_format.space_after = Pt(space_after)
    return par


HEAD_COLOR = {1: TITLE_COLOR, 2: TITLE_COLOR, 3: "23424A"}


def _h(doc, text, level):
    from docx.shared import RGBColor
    par = doc.add_heading(level=level)
    run = par.add_run(text)
    run.font.name = FONT
    run.font.color.rgb = RGBColor.from_string(HEAD_COLOR.get(level, TITLE_COLOR))
    return par


def build_catalog(build_root: Path, out_path: Path = None) -> dict:
    """Збирає каталог систем із реєстру пакета. Повертає {'systems': N, 'path': ...}."""
    import docx
    from docx.shared import Pt

    build_root = Path(build_root)
    entries = _sys_entries(build_root)
    n = len(entries)
    out_path = Path(out_path or (build_root / "Документація" /
                                 "03_SensFlow_Каталог_систем.docx"))
    out_path.parent.mkdir(parents=True, exist_ok=True)

    doc = docx.Document()
    _p(doc, "SensFlow", size=28, bold=True, color=TITLE_COLOR, space_after=0)
    _p(doc, "Локальний оркестратор ШІ-агентів", size=12, space_after=18)
    _p(doc, "Каталог систем", size=20, bold=True, color=TITLE_COLOR, space_after=2)
    _p(doc, "%d систем агентів SensFlow — призначення та приклади" % n, size=12,
       space_after=12)
    _p(doc, "Продукт:  SensFlow — локальний оркестратор ШІ-агентів", size=10, space_after=2)
    _p(doc, "Систем у складі:  %d" % n, size=10, space_after=2)
    _p(doc, "Каталог зібрано зі складу цього пакета.", size=10, space_after=18)

    _h(doc, "Як це працює", 1)
    _p(doc, HOWTO)

    _h(doc, "Огляд (усі %d систем)" % n, 1)
    note = doc.add_table(rows=1, cols=1)
    note.style = "Table Grid"
    cell = note.rows[0].cells[0]
    cell.text = ""
    for i, line in enumerate(NOTE.split("\n")):
        par = cell.paragraphs[0] if i == 0 else cell.add_paragraph()
        r = par.add_run(line)
        r.font.name = FONT
        r.font.size = Pt(9)
        r.bold = (i == 0)

    t = doc.add_table(rows=1, cols=3)
    t.style = "Table Grid"
    hdr = t.rows[0].cells
    for i, title in enumerate(("Система", "Група", "Чутливі дані")):
        hdr[i].text = ""
        r = hdr[i].paragraphs[0].add_run(title)
        r.bold = True
        r.font.name = FONT
        r.font.size = Pt(10)
    for e in entries:
        c = t.add_row().cells
        for i, val in enumerate((e["name"], e["group"], e["sensitive"])):
            c[i].text = ""
            r = c[i].paragraphs[0].add_run(val)
            r.font.name = FONT
            r.font.size = Pt(10)
    # ⭐ Рядки таблиці не рвемо між сторінками (правило Андрія).
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    for row in t.rows:
        trPr = row._tr.get_or_add_trPr()
        el = OxmlElement("w:cantSplit")
        trPr.append(el)

    doc.add_paragraph()
    _h(doc, "Детальні описи", 1)
    groups = sorted({e["group"] for e in entries},
                    key=lambda g: (GROUP_ORDER.index(g) if g in GROUP_ORDER else 99, g))
    for g in groups:
        _h(doc, g, 2)
        for e in [x for x in entries if x["group"] == g]:
            _h(doc, e["name"], 3)
            if e["purpose"]:
                _p(doc, "Призначення. " + e["purpose"])
            if e["example"]:
                _p(doc, "Приклад задачі. " + e["example"])
            _p(doc, "Чутливі дані: " + e["sensitive"], size=10)
            if e.get("status") and e["status"] != "active":
                _p(doc, "Готовність: система ще дозріває — увімкнеться після "
                        "перевірки.", size=10)

    doc.save(str(out_path))
    return {"systems": n, "path": str(out_path)}
