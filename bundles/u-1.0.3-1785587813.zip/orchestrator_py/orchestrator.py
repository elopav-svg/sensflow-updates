"""
orchestrator.py — МОЗОК. Жива модель приймає рішення, а не if/else.

Системний промпт = ваш docs/GLOBAL_ORCHESTRATOR_PROMPT.md + актуальний знімок
реєстру і конекторів. Модель повертає структуроване рішення (JSON), описане
у вашому ж промпті. Рушій лише виконує це рішення.
"""

import json

import config
import llm
import registry
import capabilities


def _orchestrator_system_prompt() -> str:
    base = ""
    if config.ORCHESTRATOR_PROMPT.exists():
        base = config.ORCHESTRATOR_PROMPT.read_text(encoding="utf-8-sig")
    else:
        base = "Ти — Global Orchestrator. Аналізуй запит семантично і повертай рішення у JSON."

    web = "доступний" if config.web_search_ready() else "наразі недоступний (немає ключа/вимкнено)"
    guard = (
        "\n\n## " + config.PLATFORM_ARTIFACT_NOTE + "\n"
        f"\n## ВЕБ-ПОШУК\nУ платформи Є інструмент живого веб-пошуку ({web}). Системи, "
        "яким потрібні актуальні дані, отримують його автоматично. Тому НЕ кажи, що ти "
        "не маєш доступу до інтернету чи поточних даних. Якщо для ПРЯМОЇ відповіді "
        "(answer_directly) потрібні актуальні зовнішні факти (погода, новини, ціни, "
        "поточні події, хто обіймає посаду тощо) — додай у рішення поле "
        '"needs_web_search": true, і платформа виконає пошук замість відповіді з памʼяті.\n'
        "\n## САМОКЕРУВАННЯ СИСТЕМАМИ\n"
        "Ти можеш керувати власним оркестром. Якщо користувач просить активувати, "
        "деактивувати, перевірити (smoke), прибрати зниклі системи або показати їхні "
        "статуси — поверни status: \"manage_system\" і додай поля:\n"
        '  "management_action": "activate|deactivate|smoke_test|prune_missing|list_status",\n'
        '  "target_system_id": "id системи або null (для prune_missing/list_status)".\n'
        "Звіряй id з переліком систем у самомоделі. Це безпечні дії над реєстром.\n"
        "\n## ПАМʼЯТЬ СТИЛІВ\n"
        "Платформа вміє вивчати авторський стиль зі зразка і застосовувати його.\n"
        "• Якщо користувач просить ПРОАНАЛІЗУВАТИ текст і ЗАПАМʼЯТАТИ/ЗБЕРЕГТИ стиль "
        "(напр. «збережи цей стиль як Х») — поверни status: \"save_style\" і поле "
        "\"style_name\" (назва стилю). Текст береться з прикріпленого файлу/посилання.\n"
        "• Якщо користувач просить написати щось У СТИЛІ збереженого пресета — обери "
        "відповідну систему (route_selected) і додай поле \"style_name\" з назвою стилю "
        "зі списку самомоделі.\n"
        "\n## ТЕХНІЧНА ВИМОГА ВІДПОВІДІ\n"
        "Поверни РІВНО ОДИН JSON-обʼєкт за схемою з розділу «ФОРМАТ РІШЕННЯ» "
        '(можеш додати булеве поле "needs_web_search"). '
        "Без тексту до або після JSON, без markdown-огортки. "
        "Заповнюй усі поля МОВОЮ ПОТОЧНОГО ПОВІДОМЛЕННЯ КОРИСТУВАЧА (російськомовне "
        "повідомлення → російською, україномовне → українською; російську й українську "
        "НЕ підміняй одну одною й НЕ став за локаллю збірки — тільки за мовою повідомлення); "
        "не переходь на англійську лише тому, що ці інструкції англійською. "
        "Якщо поле не застосовується — став null або [].\n"
        "## ЛАКОНІЧНІСТЬ (критично для швидкості!)\n"
        "Повертай МІНІМАЛЬНИЙ JSON — лише поля, потрібні для обраного status: завжди "
        "status, understood_intent, selected_system_id, confidence, rationale; за потреби "
        "direct_answer / questions / required_connector / needs_web_search / "
        "management_action+target_system_id. rationale — максимум 1–2 короткі речення. "
        "НЕ заповнюй semantic_analysis, alternatives, expected_result. proposed_system "
        "заповнюй ЛИШЕ для status=propose_system_build; automation — ЛИШЕ для "
        "propose_automation; інакше став їх null. НЕ переписуй вміст самомоделі.\n"
        "Якщо користувач просить певний формат файлу (docx/word/excel/pdf), це НЕ "
        "привід для needs_input: обери відповідну систему і виконай — формат дасть платформа.\n"
    )
    return base + guard


def _context_block(self_model_text, history, task, files_context="") -> str:
    convo = ""
    for turn in (history or [])[-8:]:
        role = "Користувач" if turn.get("role") == "user" else "Оркестратор"
        convo += f"{role}: {turn.get('content','')}\n"

    files_block = ""
    if files_context:
        files_block = ("\n\n## ПРИКРІПЛЕНІ ФАЙЛИ (витяг для розуміння домену)\n"
                       + files_context[:2500]
                       + ("\n…[далі обрізано]" if len(files_context) > 2500 else ""))

    return (
        self_model_text
        + files_block
        + "\n\n## ІСТОРІЯ ДІАЛОГУ\n"
        + (convo or "(порожня)\n")
        + "\n## ПОТОЧНИЙ ЗАПИТ КОРИСТУВАЧА\n"
        + task
    )


def decide(task: str, history=None, files_context: str = "") -> dict:
    """
    Повертає dict-рішення оркестратора. Поля (мінімум):
      status, understood_intent, expected_result, selected_system_id,
      confidence, rationale, next_action, questions, direct_answer,
      required_connector, proposed_system, automation, semantic_analysis
    """
    if not config.provider_ready():
        # Чесна деградація: не імітуємо мислення без ключа.
        return {
            "status": "needs_user_direction",
            "understood_intent": "LLM-мозок не налаштований",
            "expected_result": None,
            "selected_system_id": None,
            "confidence": "low",
            "rationale": (
                f"Активний провайдер «{config.LLM_PROVIDER}» не має API-ключа. "
                "Додайте ключ у orchestrator_py/.env.local "
                "(OPENAI_API_KEY або ANTHROPIC_API_KEY) і перезапустіть сервер. "
                "Я не вигадую відповіді без робочого мозку."
            ),
            "next_action": "ask_clarification",
            "questions": [],
            "direct_answer": None,
            "required_connector": None,
            "proposed_system": None,
            "automation": None,
            "_runtime_error": "llm_not_configured",
        }

    user_block = _context_block(capabilities.self_model_prompt(), history, task, files_context)

    try:
        decision = llm.judge_json(
            _orchestrator_system_prompt(), user_block, temperature=0.15,
            model=config.brain_model(), max_tokens=1100,
            purpose="рішення оркестратора"
        )
    except llm.LLMNotConfigured as e:
        return _runtime_problem(str(e))
    except llm.LLMError as e:
        return _runtime_problem(str(e))

    return _normalize_decision(decision)


def _runtime_problem(message: str) -> dict:
    return {
        "status": "needs_user_direction",
        "understood_intent": "Технічна проблема runtime",
        "selected_system_id": None,
        "confidence": "low",
        "rationale": f"Не вдалося отримати рішення від мозку: {message}",
        "next_action": "ask_clarification",
        "questions": [],
        "direct_answer": None,
        "_runtime_error": "llm_call_failed",
    }


def _normalize_decision(d: dict) -> dict:
    """Гарантує наявність ключових полів і коректний статус."""
    if not isinstance(d, dict):
        return _runtime_problem("Мозок повернув не-обʼєкт")
    valid = {
        "route_selected",
        "answer_directly",
        "needs_user_direction",
        "needs_input",
        "needs_external_connector",
        "propose_system_build",
        "propose_automation",
        "manage_system",
        "save_style",
    }
    if d.get("status") not in valid:
        # спробуємо вгадати за наявними полями
        if d.get("selected_system_id"):
            d["status"] = "route_selected"
        elif d.get("direct_answer"):
            d["status"] = "answer_directly"
        else:
            d["status"] = "needs_user_direction"
    d.setdefault("questions", [])
    d.setdefault("selected_system_id", None)
    d.setdefault("confidence", "medium")
    d.setdefault("rationale", "")
    d.setdefault("understood_intent", "")
    d.setdefault("direct_answer", None)
    d.setdefault("proposed_system", None)
    d.setdefault("automation", None)
    # Валідація обраної системи
    if d["status"] == "route_selected":
        if not registry.find_system(d.get("selected_system_id")):
            d["status"] = "needs_user_direction"
            d["rationale"] = (
                "Обрана система відсутня в реєстрі. " + (d.get("rationale") or "")
            )
            d["selected_system_id"] = None
    return d
