# Codex Control Plane Architecture

## Strategic Decision

AI Orchestrator Platform is not a separate LLM.

The platform is a control plane around Codex:

- the console receives tasks, files and events;
- Codex is the real Global Orchestrator;
- registered systems are playbooks/contracts for Codex;
- connectors and skills are used by Codex where available;
- the console stores registry, state, logs, runs and artifacts.

This prevents the platform from becoming a fragile imitation of reasoning.

The console has no conversational authority of its own. It must not answer instead of Codex, route by hidden local judgment, or expose implementation detail as user-facing content unless the user explicitly asks for diagnostics. Its normal job is only receive -> transfer -> render returned answer -> show dashboard state.

## Runtime Model

```text
User / Telegram / API
        |
        v
AI Orchestrator Console
        |
        v
codex_control_plane/queue/<run_id>/
        |
        v
Codex Global Orchestrator
        |
        v
System playbook / direct Codex execution / clarification / system build
        |
        v
output/runs/<run_id>/
        |
        v
Console dashboard, chat archive, result panel
```

## Task Package

Every inbound request creates:

```text
codex_control_plane/queue/<run_id>/
  TASK_FOR_CODEX.md
  task_package.json
  input_files/
```

The package contains:

- original user task;
- source channel;
- uploaded files;
- systems registry snapshot;
- connector status snapshot;
- paths to Global Orchestrator contract and prompt;
- required output directory.

## Completion Contract

A task is not complete when the console creates a package.

It is complete only when Codex writes:

```text
output/runs/<run_id>/
  final_result.md
  codex_result.json
```

Optional artifacts may include HTML, DOCX, XLSX, PPTX, CSV, JSON or PDF.

## Codex Pickup Flow

To inspect the next queued task without claiming it:

```powershell
AI_Orchestrator_Platform\scripts\codex-next-task.ps1
```

To claim the next queued task for a Codex worker:

```powershell
AI_Orchestrator_Platform\scripts\codex-claim-task.ps1 -WorkerId desktop_codex
```

While working, update heartbeat:

```powershell
AI_Orchestrator_Platform\scripts\codex-heartbeat-task.ps1 `
  -RunId run-YYYY-MM-DDTHH-MM-SS `
  -WorkerId desktop_codex `
  -Status running `
  -Note "Reading files and selecting system"
```

Codex reads the returned `TASK_FOR_CODEX.md`, executes the task with available skills/connectors/tools, writes `final_result.md`, and completes the run through:

```powershell
AI_Orchestrator_Platform\scripts\codex-complete-task.ps1 `
  -RunId run-YYYY-MM-DDTHH-MM-SS `
  -MarkdownPath AI_Orchestrator_Platform\output\runs\run-YYYY-MM-DDTHH-MM-SS\final_result.md `
  -SelectedSystemId optional_system_id `
  -Summary "Short result summary"
```

Equivalent API endpoints:

```text
GET  /api/codex/next
POST /api/codex/claim
POST /api/codex/heartbeat
GET  /api/codex/result?runId=<run_id>
POST /api/codex/complete
```

## Verified Smoke Flow

The bridge protocol was smoke-tested end to end:

- console creates a queued task package;
- Codex worker claims it;
- worker heartbeat marks it as running;
- completion writes `final_result.md`, `codex_result.json` and `execution_trace.json`;
- `/api/runs` shows the run as completed with `runtime_adapter = codex_control_plane`;
- `/api/codex/next` does not offer claimed or completed packages again.

## System Role

Registered systems are not isolated fake brains.

They are structured operating contracts:

- `system.yaml`;
- `PROMPT.md`;
- agent prompts;
- result contract;
- verification rules;
- smoke tests;
- safety constraints.

Codex reads and uses them as playbooks.

## Telegram Integration

Telegram should not call any system directly.

Telegram sends a message to the same control-plane endpoint:

```text
POST /api/codex/submit
```

The console creates the same task package and stores the same run history.

## Safety Rule

Safety-critical domains must stop for missing inputs:

- legal;
- finance;
- medical/health;
- routes and evacuation;
- military-time movement;
- high-value business decisions.

No adapter or UI component may present an unverified placeholder as a final result.
