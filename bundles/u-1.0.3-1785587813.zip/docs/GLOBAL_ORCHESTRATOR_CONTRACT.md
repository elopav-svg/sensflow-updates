# Global Orchestrator Contract

## Principle

Global Orchestrator is Codex.

The platform UI is not the real intelligence layer. Codex reads the registry, understands the user request semantically, decides whether to execute directly or route to a registered system, supervises execution, verifies the result, and places the verified result in the chat and result workspace.

## Control Plane Architecture

The console is a control plane, not a replacement LLM.

Responsibilities of the console:

- accept input from UI, Telegram, API or another channel;
- store the user task, files and source channel;
- expose the systems registry, connector status, run history and artifacts;
- create a Codex task package under `codex_control_plane/queue/<run_id>/`;
- show queued/running/completed/needs_input/failed states;
- display verified artifacts returned by Codex.

Hard boundary for the console:

- the console is a non-reasoning transport and display surface;
- the console must not answer user intent from its own local rules;
- the console must not explain architecture in ordinary task/chat flow unless the user asks about architecture;
- the console must not present internal package paths, contracts or orchestration mechanics as the main answer;
- the console may only receive, transfer, show state/dashboard, and render Codex's returned answer/artifacts.

Responsibilities of Codex:

- act as the real reasoning layer;
- read `TASK_FOR_CODEX.md` and `task_package.json`;
- use available Codex skills, connectors, local files, tools and memory;
- decide whether to answer directly, route to a system, ask for clarification, propose a new system or propose automation;
- execute or supervise the selected playbook;
- verify quality;
- write final result files to `output/runs/<run_id>/`.

The console must not pretend that a queued task is completed. A task becomes complete only after Codex writes `codex_result.json` and the final artifacts, or explicitly returns `needs_input`.

## Input Channels

All input channels must create the same task package shape:

- console chat;
- Telegram bot;
- local API;
- future scheduled heartbeat jobs.

No channel may bypass the Global Orchestrator contract and call a system directly.

## Request Algorithm

1. Receive the user task in the task chat.
2. Create or read the Codex task package.
3. Read the systems registry and available manifests.
4. Understand intent semantically:
   - task type;
   - required domain;
   - required files/data;
   - risk/sensitivity;
   - expected final artifact.
5. Decide execution path:
   - **Direct Codex execution** when the task is simple, general, or no specialized system is required.
   - **System route** when a registered system clearly matches the domain.
   - **Clarification** when the task cannot be safely understood.
6. Ask for user confirmation before sensitive/high-impact execution.
7. Execute through Codex using the selected system as a playbook/contract when appropriate:
   - preserve the agent sequence declared in the system manifest or runtime blueprint;
   - use Codex skills/connectors/tools instead of reimplementing them inside the console;
   - use local adapters only as deterministic utility services, not as simulated reasoning.
8. Verify result:
   - result is not empty;
   - result answers the user task;
   - result declares source;
   - agent sequence was followed or a failure was reported;
   - downloadable artifacts were created when execution completed;
   - result is visible in the chat;
   - result is visible in the result workspace.
9. If required inputs are missing, return `needs_input` with concrete questions for the user.
10. If verification fails, do not mark the task complete. Show diagnostics and required next action.

## New System Integration Algorithm

When a new system is added:

1. User enters the system name and chooses the system folder.
2. Codex checks whether `system.yaml` exists.
3. If manifest exists, Codex reads it and extracts:
   - `id`;
   - `name`;
   - `description`;
   - `triggers.keywords`;
   - `triggers.examples`;
   - `execution.adapter_id`;
   - `execution.result_contract`;
   - `execution.pipeline`;
   - `execution.clarification_policy`;
   - `execution.result_contract.artifacts`;
   - `execution.verification_rules`.
4. If manifest does not exist, Codex creates one from `templates/system_template/system.yaml`.
5. Codex registers the system with a default adapter:
   - `${system_id}_adapter`;
   - `local_mvp_adapter`;
   - `final_result_required`.
6. Codex runs an integration smoke test:
   - create a realistic test task from `triggers.examples` or system name;
   - route to the new system;
   - ask for confirmation;
   - execute through adapter;
   - verify result appears in chat and result workspace;
   - verify downloadable artifacts exist when execution is complete;
   - verify `needs_input` is returned instead of a fake result when required data is missing.
7. If the smoke test fails, the system remains `draft` or `needs_review`.

## New System Build Algorithm

When the user asks to build a new multiagent system, or when Codex proposes a new system and the user confirms:

1. Use `docs/SYSTEM_BUILDER_CONTRACT.md` as mandatory build policy.
2. Create a separate project folder under the workspace root, for example:
   `C:\Users\AVP\Desktop\Проект ИИ\Проект <System Name>`.
3. Treat uploaded prompts, documents and notes as source material, not final prompts.
4. Transform source material into:
   - agent roles;
   - execution algorithm;
   - handoff rules;
   - constraints;
   - quality gates;
   - user clarification policy;
   - result formats.
5. Never paste the raw source pack into `PROMPT.md`, `system.yaml`, triggers or agent prompts.
6. Register the new system with `status: needs_review`.
7. Run or prepare a smoke test. The system can become `active` only after the smoke test passes.

## Required Manifest Fields

Every system manifest must define:

```yaml
global_orchestrator:
  id: codex
  semantic_routing: true
  allow_direct_codex_execution: true

execution:
  adapter_id: example_adapter
  adapter_type: local_mvp_adapter
  production_adapter_status: not_connected
  pipeline:
    preserve_agent_sequence: true
    agents_order:
      - Agent001
    stop_on_agent_failure: true
  result_contract:
    final_result_required: true
    result_must_be_user_visible: true
    artifacts:
      downloadable_required: true
      allowed_formats:
        - md
        - html
        - docx
        - pptx
        - xlsx
        - csv
        - json
        - pdf
    allowed_sources:
      - system_adapter
      - local_mvp_adapter
  clarification_policy:
    response_status: needs_input
    ask_user_when:
      - "Required input file is missing."
      - "Task intent is ambiguous."
      - "Agent cannot continue without domain-specific data."
  verification_rules:
    - "Result is not empty."
    - "Result answers the user task directly."
    - "Result source is declared."
    - "Agent sequence is preserved."
    - "Downloadable artifacts are reachable."
    - "Result is placed in chat and result workspace."

fallback:
  local_mvp_adapter:
    enabled: true
    label: "local_mvp_adapter"
```

## Honest Result Rule

Never present a placeholder as a production agent result.

Allowed labels:

- `system_adapter` - production MCP/backend adapter result.
- `local_file_adapter` - browser/local file adapter result.
- `local_mvp_adapter` - bounded local MVP result.

If no adapter can produce a meaningful result, show diagnostics instead of a fake success.

## Artifact Rule

Every completed run must create at least one downloadable artifact under:

```text
output/runs/<run_id>/
```

The UI may display an HTML preview, but the preview is not the source of truth. The source of truth is the run result returned by the Global Orchestrator API plus the files saved in the run output folder.

## Clarification Rule

When a system cannot honestly continue, the orchestrator returns:

```json
{
  "status": "needs_input",
  "questions": ["Concrete question for the user"]
}
```

The UI must show those questions in the chat and must not mark the run as complete.
