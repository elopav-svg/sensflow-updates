# Codex Desktop Bridge Contract

## Purpose

The desktop bridge is the contract between AI Orchestrator Platform and a real Codex Desktop worker.

The platform remains the control plane:

- accepts tasks and files;
- creates task packages;
- stores run state, traces and artifacts;
- shows queue, worker and result state.

Codex Desktop remains the reasoning and execution worker:

- claims one task package at a time;
- reads `TASK_FOR_CODEX.md` and `task_package.json`;
- uses local tools, connectors and repository context;
- writes `final_result.md` and any artifacts into the run output folder;
- completes the package through `/api/codex/complete`.

No layer may present a queued package as a completed answer.

## Lifecycle

```text
console submit
  -> codex_control_plane/queue/<run_id>/
  -> desktop bridge take
  -> worker_state.json = running
  -> Codex Desktop executes
  -> final_result.md + optional artifacts
  -> desktop bridge finish
  -> codex_result.json + execution_trace.json
  -> console shows completed run
```

## Worker Identity

Default worker id:

```text
desktop_codex
```

A worker should claim only one package at a time. If a package is already claimed or running, the bridge reports the current worker instead of overwriting ownership.

## Required Files

Input package:

```text
codex_control_plane/queue/<run_id>/
  TASK_FOR_CODEX.md
  task_package.json
  worker_state.json
  input_files/
```

Output package:

```text
output/runs/<run_id>/
  final_result.md
  codex_result.json
  execution_trace.json
  optional artifacts
```

## Bridge Script

Use the bridge script from the platform root:

```powershell
.\scripts\codex-desktop-bridge.ps1 -Action Status
.\scripts\codex-desktop-bridge.ps1 -Action Take -WorkerId desktop_codex
.\scripts\codex-desktop-bridge.ps1 -Action Heartbeat -RunId run-YYYY-MM-DDTHH-MM-SS -Note "Working"
.\scripts\codex-desktop-bridge.ps1 -Action Finish -RunId run-YYYY-MM-DDTHH-MM-SS -MarkdownPath .\output\runs\run-YYYY-MM-DDTHH-MM-SS\final_result.md -Summary "Done"
```

`Take` writes `desktop_bridge_context.json` into the run output folder so the current Codex Desktop thread has a small machine-readable context file in addition to `TASK_FOR_CODEX.md`.

## API Surface

```text
GET  /api/codex/desktop-bridge
GET  /api/codex/next
POST /api/codex/claim
POST /api/codex/heartbeat
POST /api/codex/complete
GET  /api/codex/result?runId=<run_id>
```

## Safety Rules

- Sensitive tasks must return `needs_input` when required facts are missing.
- A worker must not complete a package without a visible `final_result.md` unless status is `needs_input` or `failed`.
- The platform may show queued/running state, but never a fake final result.
- The bridge should prefer explicit status and artifacts over chat-only summaries.
