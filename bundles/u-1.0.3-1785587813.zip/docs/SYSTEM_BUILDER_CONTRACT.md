# System Builder Contract

## Principle

System Builder must create a real multiagent system, not a folder-shaped summary.

If the user provides prompts, notes, documents or process descriptions, they are source material. They must be analyzed and transformed into an operating system contract. They must not be pasted into `PROMPT.md`, `system.yaml`, triggers, examples or agent prompts as raw text.

## Creation Target

Every newly built system must be created as a separate project folder in the workspace root:

```text
<workspace root>\Проект <System Name>\
```

The AI Orchestrator Platform stores registry entries, run history and control-plane packages. It must not hide production systems inside `generated_systems` for normal creation flows.

## Required Build Flow

1. Understand the user goal, end user, inputs, outputs, risk level and repeated workflow.
2. If any of those are unclear, ask concise questions through the Global Orchestrator.
3. Read all supplied materials.
4. Extract reusable capabilities, roles, decision points, constraints and quality gates.
5. Design an agent sequence with clear handoffs.
6. Write a root `PROMPT.md` for the system orchestrator.
7. Write one `Agents/<AgentName>/PROMPT.md` per agent.
8. Create `system.yaml`, `SYSTEM_CONTRACT.md`, `RUNBOOK.md`, `SMOKE_TEST.md`, `adapter_stub.json`, `Memory/MEMORY.md` and `Memory/HEARTBEAT.md`.
9. Add the system to `registry/systems.json` with status `needs_review`.
10. Run or prepare a smoke test. Only after a successful quality gate may the system move to `active`.

## Prompt Contract

Every root and agent prompt must contain:

- `РОЛЬ`
- `КОНТЕКСТ`
- `ЗАПИТ`
- `ОБМЕЖЕННЯ`
- `ФОРМАТ ВІДПОВІДІ`

Agent prompts must also state:

- place in the pipeline;
- required inputs;
- expected outputs;
- when to stop and ask the user;
- handoff format for the next agent;
- quality checks.

## Raw Material Rule

Forbidden:

- copying a whole prompt pack into `PROMPT.md`;
- copying a whole prompt pack into `system.yaml`;
- using the original user document as trigger examples;
- treating generic ChatGPT prompts as final agent instructions;
- marking a system complete because files exist.

Allowed:

- short source summary in `SYSTEM_CONTRACT.md`;
- normalized use cases;
- transformed roles and algorithms;
- references to source files in run artifacts.

## Registry Rule

The registry entry must contain:

- stable `id`;
- clear `name`;
- `category`;
- `status: needs_review`;
- root path to the separate project folder;
- short semantic description;
- agent ids;
- orchestration mode;
- concise triggers derived from capabilities, not raw source text.

## Quality Gate

A build fails if:

- any required file is missing;
- any agent prompt lacks the prompt-contract sections;
- `system.yaml`, root `PROMPT.md`, `SYSTEM_CONTRACT.md` or agent prompts contain raw copied source material;
- the system is stored only as an internal platform artifact instead of a project folder;
- no smoke test exists;
- no result contract or verification rules exist.

The honest status for a failed or incomplete build is `needs_review`, not `completed` and not `active`.

## User Interaction

If the system being built will later ask users questions, those questions must pass through the Global Orchestrator. Agents must not bypass the orchestrator and must not silently guess missing business, legal, financial, route, safety or source data.
