# -*- coding: utf-8 -*-
"""deals.py — УГОДА СТАЄ СУТНІСТЮ CRM (крок C1, 15.08.2026).

⭐⭐⭐ КОРІНЬ. До сьогодні угода не була сутністю: вона була НАЗВОЮ КАРТКИ в
`crm/clients.json`. У тій самій картці одночасно жили три різні речі — ліцензія й
канал оновлень, продаж, і бейдж уваги. Наслідки бачив кожен:

  1. На угоду НЕМА ЧИМ ВКАЗАТИ: `entity` не знав виду `deal`, тому ні задача, ні
     протокол, ні майбутня заявка не могли сказати «це про цю угоду».
  2. КЛЮЧ — РЯДОК НАЗВИ: перейменував клієнта — отримав другу угоду. На диску вже
     лежав доказ: «Борис Мамлін» і «Boris Mamlin» — дві картки на один `p0004`.
  3. ОДНА УГОДА НА ВСЕ ЖИТТЯ КЛІЄНТА: повторному продажу, продовженню, апсейлу
     не було де жити.
  4. ВОРОНКА МІРЯЛА НЕ ТЕ: у ній лежали 23 картки, з них 11 — тестувальники
     чужого продукту.
  5. ЛІЦЕНЗІЯ Й ПРОДАЖ ЗВʼЯЗАНІ НАЗВОЮ — тому ТЕХНІЧНА дія (збірка пакета)
     мовчки рухала ГРОШІ у воронці.

⛒ ЗАКОН ШАРУ (продовження B1): ХТО ЦЕЙ КОНТРАГЕНТ — знає `parties`; ЩО МИ ЙОМУ
ПРОДАЄМО — знає ЦЕЙ ФАЙЛ; ЯКУ ЛІЦЕНЗІЮ ЙОМУ ВИДАНО І ЯКИМ КАНАЛОМ ЇДУТЬ
ОНОВЛЕННЯ — лишається в `crm/clients.json`, і воно НЕ ЧІПАЄТЬСЯ (рішення Р3
проєкту C1). Ліцензія — це техніка, а не гроші у воронці.

⛔ ЧОГО ЦЕЙ ФАЙЛ НЕ РОБИТЬ. Він не знає, хто такий контрагент (питає `entity` /
`parties`), не веде історію спілкування (вона на контакті, B1) і не має власного
реєстру звʼязків: «угода з компанією» і «контактна особа угоди» лежать у
`links.py` — тому картка контакту показує свої угоди ПОХІДНО, без другого сховища.

Файл: `crm/deals.json`. Шлях лежить у змінній модуля — чек підміняє її й не сміє
писати в бойову теку (той самий прийом, що з `audit._PATH`, `parties.PARTIES_JSON`,
`links.LINKS_JSON`, `protocol._PATH`).
"""

import json
import one_writer
import re

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import entity                     # спільне імʼя сутності на всю платформу
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій (хребет)

# 🩸🩸🩸 ЗНАЙДЕНО ОКОМ 15.08.2026, ЩОЙНО ПЕРЕЇЗД ЛІГ НА ДИСК: у бойовому реєстрі
# опинилось ПʼЯТЬ угод із чужих чеків («Проба Фірма», «ФОП Стрейнджер»). Причина
# не в самих чеках: `contact_layer_test` і `parties_test` чесно відводять убік
# CRM, довідник, звʼязки й протокол — але про НОВИЙ реєстр вони не знали й знати
# не могли. Це рівно той клас, від якого нас лікував `state_isolation`: писар,
# який не слухається вимикача ізоляції, рано чи пізно напише в актив Андрія.
# ⛒ ТОМУ ВИМИКАЧ СЛУХАЄ САМ РЕЄСТР, а не той, хто його викликає: у чек-режимі
# (`config.STATE_SANDBOXED`) угоди лягають у пісочницю. У бою шлях не міняється
# ні на байт.
DIR = config.CRM_DIR
DEALS_JSON = DIR / "deals.json"

# ── ВОРОНКА: ОДИН ПИСАР СТАДІЙ НА ВСЮ ПЛАТФОРМУ ──────────────────────────────
# ⛒ Стадії переїхали СЮДИ з `crm.py` разом із самим продажем (з 738 — у даних, `deal_stages`). `crm.STAGES`
# лишається тим самим імʼям, але тепер це ПОСИЛАННЯ на цей перелік: два переліки
# стадій розійшлись би на першій же правці, і воронка почала б губити картки.
# ⛒⛒⛒ 738 (10.10.2026). СТАДІЇ — ДАНІ КЛІЄНТА, ПРАВИЛА — ЗА ЗНАЧЕННЯМ СТАДІЇ (`deal_stages`).
# Угода тримає постійний номер стадії (`stage_id`); назва (`stage`) — підпис, який реєстр
# переписує з воронки при кожному читанні. Імовірність прогнозу, ворота суми й паперу, «не в
# роботі», облік абонплати, виручка — судять ЗНАЧЕННЯ стадії (`deal_stages.KINDS`).
import deal_stages as DS                       # noqa: E402


def stages() -> list:
    """Стадії воронки (у порядку): [{id, name, kind, prob}]."""
    return DS.stages_of(_load())


def stage_names(include_closed: bool = True) -> list:
    return [x["name"] for x in stages() if include_closed or x["kind"] not in DS.ARCHIVE]


def _kind(row, sts=None) -> str:
    return DS.kind_of(sts if sts is not None else stages(), _s((row or {}).get("stage_id")))


def default_stage() -> str:
    """Назва стадії нової угоди (перша звичайна у воронці клієнта)."""
    sts = stages()
    return DS.name_of(sts, DS.default_id(sts))


def requires(stage) -> tuple:
    """Що потрібно угоді, щоб стати на цю стадію (за її значенням): ("amount", "paper")…"""
    sts = stages()
    return tuple(DS.REQUIRES.get(DS.kind_of(sts, DS.resolve(sts, stage))) or ())


def stage_of_kind(kind: str) -> str:
    """Назва першої стадії з цим значенням у воронці клієнта; "" — такої немає (правило не діє)."""
    sts = stages()
    return DS.name_of(sts, DS.first_of_kind(sts, kind))


def is_not_in_work(row) -> bool:
    """Угода вже не в роботі (програна чи в архіві) — борг і «у роботі» її не рахують."""
    return _kind(row) in DS.NOT_IN_WORK


def stage_setup() -> dict:
    """Воронка для екрана налаштування: стадії з кількістю угод, значення, версія, чи є до чого відкотитись."""
    d = _load()
    sts = DS.stages_of(d)
    used = {}
    for row in d["deals"].values():
        if isinstance(row, dict):
            used[_s(row.get("stage_id"))] = used.get(_s(row.get("stage_id")), 0) + 1
    pl = d["settings"].get("pipeline") or {}
    return {"stages": [dict(x, deals=used.get(x["id"], 0)) for x in sts],
            "kinds": [{"kind": k, "name": DS.KIND_NAMES[k]} for k in DS.KINDS],
            "version": int(pl.get("version") or 0), "at": _s(pl.get("at")), "by": _s(pl.get("by")),
            "can_restore": bool(d["settings"].get("pipeline_history"))}


def save_stages(new_stages, by: str = "") -> dict:
    """⛒ 738: нова воронка — лише через суддю (`deal_stages.check`); попередня версія — в історію."""
    d = _load()
    sts = DS.stages_of(d)
    used = {}
    for row in d["deals"].values():
        if isinstance(row, dict):
            used[_s(row.get("stage_id"))] = used.get(_s(row.get("stage_id")), 0) + 1
    try:
        known = {x.get("id") for v in (d["settings"].get("pipeline_history") or [])
                 for x in (v.get("stages") or []) if isinstance(x, dict)}
        fresh = DS.check(new_stages, sts, used, known)
    except DS.StageError as ex:
        raise DealError(str(ex))
    DS.save(d, fresh, clock.now(), _s(by))
    _save(d)
    _to_protocol(protocol.A_DEAL_CHANGED, "", "воронку змінено: %s"
                 % " → ".join(x["name"] for x in fresh), source="settings")
    return stage_setup()


def restore_stages(by: str = "") -> dict:
    """Повернути попередню версію воронки — тим самим суддею (угоди стадій, яких там немає, —
    відмова словами)."""
    d = _load()
    hist = list(d["settings"].get("pipeline_history") or [])
    if not hist:
        raise DealError("Попередньої версії воронки немає.")
    prev = hist[-1]
    out = save_stages(prev.get("stages") or [], by=by)
    d = _load()
    d["settings"]["pipeline_history"] = list(d["settings"].get("pipeline_history") or [])[:-2]
    _save(d)
    return out

# Валюта за замовчуванням — та сама, що лежала в картках до переїзду.
CURRENCY = "₴"

# ── ОБОВʼЯЗКОВЕ ПОЛЕ НА СТАДІЇ (крок після C1, 15.08.2026) ───────────────────
# ⭐⭐⭐ ЯКІСТЬ ДАНИХ ТРИМАЄТЬСЯ НА СТАДІЇ, А НЕ НА СУМЛІННОСТІ. Угода без суми в
# «Укладенні угоди» робить весь прогноз воронки порожнім числом: дашборд покаже
# нуль там, де насправді гроші. Це не «валідація форми» — це ворота: у стадію,
# яка щось ОБІЦЯЄ бізнесу, не пускаємо без того, на чому обіцянка тримається.
# ⛒ Словник ЗАКРИТИЙ і живе тут: правило, яке живе в екрані, обходиться першим же
# другим входом (телеграм, імпорт, автоматика) — урок «промпт — не ворота».
# ⭐⭐⭐ 585 (16.09.2026). ДРУГА ВИМОГА — ДОГОВІР. Слово Андрія 13.09.2026:
# «Жодна угода без договору, який причеплений до цієї угоди, не може вважатися
# успішно завершеною.» Це правило ЗАКРИТТЯ угоди, а не поле в картці, — тому
# воно лягає сюди, у ті самі ворота стадії, а не в екран і не в окремий сторож.
#
# 🩸 ЧОМУ ТРИ СТАДІЇ, А НЕ ОДНА. «Успішно завершена» в цій воронці — це не одна
# поділка, а три: угоду уклали, чекаємо оплати, клієнт активний. Поставити
# ворота лише на першу означало б лишити дірку завширшки з два кліки: стадію
# можна задати будь-яку, і угода перестрибнула б ворота, не торкнувшись їх.
# ⛒ 738: вимоги — за значенням стадії (`deal_stages.REQUIRES`).
# ⭐⭐⭐ 651 (28.09.2026). ПАПІР ЗАКРИТТЯ — ЗА ФОРМОЮ ОПЛАТИ. Слово Андрія
# 28.09.2026 узагальнило правило 585: угода закривається лише зі СВОЇМ папером,
# а який він — каже форма оплати (запит Каспера: рахунок, договір, накладений
# платіж, передплата). Угода БЕЗ форми живе за старим правилом — потрібен договір.
# ⛒ «З ЯКОЇ СТАДІЇ» — ЧАСТИНА ФОРМИ, а не смак екрана. Рахунок виставляють, коли
# вже чекають оплату; ТТН зʼявляється, коли товар поїхав; «сплачено» — коли
# гроші прийшли. Вимагати ТТН на «Укладенні угоди» означало б змусити людину
# брехати формою, щоб просто рухати угоду.
# ⛒ 738: «з якої стадії» — ЗНАЧЕННЯ стадії (`deal_stages.PAPER_KINDS` у порядку руху угоди).
PAPER_PAID = "paid"               # «папір» передплати — позначка «сплачено»
PAY_FORMS = {
    "invoice":  {"name": "Згідно рахунку", "paper": "invoice",
                 "from": "await_pay", "need": "причепіть до угоди рахунок"},
    "contract": {"name": "Згідно договору", "paper": "contract",
                 "from": "contract", "need": "причепіть до угоди договір"},
    "cod":      {"name": "Накладений платіж", "paper": "ttn",
                 "from": "await_pay", "need": "причепіть до угоди ТТН"},
    "prepay":   {"name": "Передплата", "paper": PAPER_PAID,
                 "from": "won", "need": "позначте, що угоду сплачено"},
}
PAY_ORDER = ("invoice", "contract", "cod", "prepay")
STALE_DAYS_DEFAULT = 7
# ⛒ ВІДМОВА КАЖЕ, ЩО ЗРОБИТИ, А НЕ ЯК ЗВЕТЬСЯ ПОЛЕ. Суму ВКАЗУЮТЬ, договір
# ПРИЧІПЛЯЮТЬ — це різні дії, і людині треба почути свою. Один перелік із
# спільним дієсловом «вкажіть» зробив би з половини вимог нісенітницю.
FIELD_NAMES = {"amount": "вкажіть суму угоди (разову або щомісячну)",
               "contract": "причепіть до угоди договір"}
_UNSET = object()

MAX_NAME = 200        # довша «назва» — це вже текст, а не назва угоди
MAX_NOTE = 2000


class DealError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def num(s) -> float:
    """Число з рядка суми ('150 000', '30000₴' → 150000.0). Порожнє → 0.

    ⚠ ОДИН ПИСАР АРИФМЕТИКИ СУМИ. Раніше це жило в `crm._num`; там воно лишається
    тонким викликом сюди — інакше дашборд і воронка рахували б гроші по-різному."""
    digits = re.sub(r"[^\d.]", "", str(s or "").replace(",", ""))
    try:
        return float(digits) if digits else 0.0
    except Exception:
        return 0.0


# ── Сховище ──────────────────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(DEALS_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("seq", 0)
    if not isinstance(d.get("deals"), dict):
        d["deals"] = {}
    if not isinstance(d.get("settings"), dict):
        d["settings"] = {}
    # ⛒ 738: реєстр без воронки — стартова модель і номери стадій угодам, ОДИН раз і з копією.
    # ⛒ Переведений реєстр записується ЛИШЕ після копії: копія не вдалась — на диску лишається
    # старий реєстр, перехід повториться наступного читання (у памʼяті — уже з номерами).
    if DS.ensure(d, clock.now(), ever_won=_ever_won_legacy) and _backup_before_stages():
        _save(d)
    sts = DS.stages_of(d)
    for row in d["deals"].values():
        if isinstance(row, dict) and _s(row.get("stage_id")):
            row["stage"] = DS.name_of(sts, row["stage_id"]) or _s(row.get("stage"))
    return d


def _ever_won_legacy(row: dict) -> bool:
    """Угода до 738 колись заходила на «Активні клієнти» (для поділу старого «Архіву»)."""
    return bool(_s((row.get("stage_at") or {}).get("Активні клієнти")))


def _backup_before_stages() -> bool:
    """Копія реєстру до переведення на номери стадій — поруч, не перезаписує попередню.
    True — копія є (або реєстру на диску ще не було). ⛒ Читає й пише ті самі двері до стану
    (`one_writer`), що й сам реєстр: зайнятий файл не віддається як порожній."""
    try:
        if not DEALS_JSON.exists():
            return True
        dst = DEALS_JSON.with_name("deals.before_stages_738.json")
        n = 2
        while dst.exists():
            dst = DEALS_JSON.with_name("deals.before_stages_738_%d.json" % n)
            n += 1
        one_writer.write_text(dst, one_writer.read_text(DEALS_JSON))
        return True
    except Exception:                                   # noqa: BLE001
        return False


def _save(d: dict) -> None:
    """Атомарний запис: або старий файл цілий, або новий цілий. Половини не буває."""
    DEALS_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(DEALS_JSON, d)


def _new_id(d: dict) -> str:
    seq = int(d.get("seq") or 0) + 1
    while ("d%04d" % seq) in d["deals"]:
        seq += 1
    d["seq"] = seq
    return "d%04d" % seq


# ── Словники ─────────────────────────────────────────────────────────────────
def has_amount(row: dict) -> bool:
    """Чи названо в угоді хоч якісь гроші."""
    a = (row or {}).get("amount") or {}
    return bool(_s(a.get("one_time")) or _s(a.get("mrr")))


def _has_contract(row: dict) -> bool:
    """⛒ ВІДПОВІДЬ ПРО ДОГОВІР ДАЄ ТОЙ, ХТО ЙОГО ЗБЕРІГАЄ (`deal_documents`),
    а не цей файл. Імпорт ЛОКАЛЬНИЙ свідомо: документи знають про угоди, і
    зустрічний імпорт зверху замкнув би коло на завантаженні модулів.

    ⚠ FAIL-CLOSED: якщо сховище документів чомусь не відповідає, ворота
    вважають, що договору немає. «Не знаю» на замку означає «ні»."""
    did = _s((row or {}).get("id"))
    if not did:
        return False
    try:
        import deal_documents as _dd585
        return bool(_dd585.has_contract(did))
    except Exception:
        return False


def _has_paper(row: dict, kind: str, skip_doc: str = "") -> bool:
    """Чи є в угоді папір цього типу. ⚠ FAIL-CLOSED, як і `_has_contract`."""
    did = _s((row or {}).get("id"))
    if not did:
        return False
    try:
        import deal_documents as _dd651
        return bool(_dd651.has_kind(did, kind, skip=skip_doc))
    except Exception:
        return False


def paper_missing(row: dict, stage: str, skip_doc: str = "") -> str:
    """⭐⭐⭐ 651. ЧОГО З ПАПЕРУ БРАКУЄ угоді на цій стадії — словами; "" — нічого.

    Одна відповідь на три входи: перехід стадії, зміна форми оплати й
    відчеплення документа (`skip_doc` — документ, якого вже «немає»)."""
    sts = stages()
    kind = DS.kind_of(sts, DS.resolve(sts, stage))
    if kind not in DS.PAPER_KINDS:
        return ""
    form = _s((row or {}).get("payment_form"))
    if not form:
        # Угода без форми — правило 585 як було: договір.
        if skip_doc:
            ok = _has_paper(row, "contract", skip_doc)
        else:
            ok = _has_contract(row)
        return "" if ok else FIELD_NAMES["contract"]
    spec = PAY_FORMS.get(form)
    if not spec:
        return "оберіть відому форму оплати"
    if DS.PAPER_KINDS.index(kind) < DS.PAPER_KINDS.index(spec["from"]):
        return ""
    if spec["paper"] == PAPER_PAID:
        return "" if (row or {}).get("paid") else spec["need"]
    return "" if _has_paper(row, spec["paper"], skip_doc) else spec["need"]


def paper_state(row: dict) -> dict:
    """⭐ 651. ЯКИЙ папір закриває цю угоду і чи він уже є — для екрана.
    Вкладка «Документи» і блок «Форма оплати» читають ЦЕ, а не свої здогадки."""
    form = _s((row or {}).get("payment_form"))
    if form and form in PAY_FORMS:
        spec = dict(PAY_FORMS[form])
    else:
        form = ""
        spec = {"name": "не обрано", "paper": "contract", "from": DS.PAPER_KINDS[0],
                "need": FIELD_NAMES["contract"]}
    if spec["paper"] == PAPER_PAID:
        ok, pname = bool((row or {}).get("paid")), "позначка «сплачено»"
    else:
        ok = _has_paper(row, spec["paper"]) if form else _has_contract(row)
        try:
            import deal_documents as _dd651n
            pname = _dd651n.KIND_NAMES.get(spec["paper"], spec["paper"])
        except Exception:
            pname = spec["paper"]
    # ⛒ 738: «з якої стадії» — назва першої стадії з цим значенням у воронці клієнта.
    sts = stages()
    from_name = DS.name_of(sts, DS.first_of_kind(sts, spec["from"])) or DS.KIND_NAMES[spec["from"]]
    return {"form": form, "form_name": spec["name"], "paper": spec["paper"],
            "paper_name": pname, "from": from_name, "from_kind": spec["from"], "ok": bool(ok),
            "need": spec["need"]}


def check_stage_ready(row: dict, stage: str, skip_doc: str = "") -> None:
    """Ворота стадії: чого бракує, щоб туди перейти. Відмова — СЛОВАМИ.

    ⚠ Судимо не «чи заповнена форма», а сам ЗАПИС угоди: у неї є кілька входів
    (екран, збірка, майбутній імпорт), і кожен мусить упертись в одні ворота."""
    sts = stages()
    sid = DS.resolve(sts, stage)
    need = DS.REQUIRES.get(DS.kind_of(sts, sid)) or ()
    missing = []
    for field in need:
        if field == "amount" and not has_amount(row):
            missing.append(FIELD_NAMES["amount"])
        if field == "paper":
            lack = paper_missing(row, stage, skip_doc)
            if lack:
                missing.append(lack)
    if missing:
        raise DealError(
            "Щоб перевести угоду на стадію «%s», спершу %s. Угода без свого "
            "паперу (договір, рахунок, ТТН або позначка оплати — за формою оплати) "
            "не вважається успішно завершеною, а воронка без суми рахує "
            "обіцянку порожнім числом." % (DS.name_of(sts, sid) or _s(stage), ", ".join(missing)))


def check_stage(stage) -> str:
    """Номер стадії воронки клієнта (за номером чи назвою) — або відмова словами.

    ⚠ До переїзду `crm.set_stage` на невідомій стадії мовчки повертав `None`:
    людина натискала, нічого не відбувалось, і ніхто не казав чому. Тиха відмова —
    це вимкнені ворота. ⛒ 738: порожнє — стадія нової угоди."""
    sts = stages()
    if not _s(stage):
        return DS.default_id(sts)
    sid = DS.resolve(sts, stage)
    if not sid:
        raise DealError("Невідома стадія «%s». Воронка знає лише: %s."
                        % (_s(stage), ", ".join(x["name"] for x in sts)))
    return sid


def check_name(name) -> str:
    nm = _s(name)
    if not nm:
        raise DealError("Угода без назви не заводиться: назва — це те, що менеджер "
                        "бачить у воронці.")
    if len(nm) > MAX_NAME:
        raise DealError("Назва угоди задовга: %d знаків, а можна щонайбільше %d."
                        % (len(nm), MAX_NAME))
    return nm


def check_amount(amount) -> dict:
    """Суми угоди у сталій формі. Чужі ключі — відмова, а не тиха втрата."""
    src = dict(amount or {})
    out = {"one_time": "", "mrr": "", "currency": CURRENCY}
    for k, v in src.items():
        k = _s(k)
        if k not in out:
            raise DealError("Невідоме поле суми «%s». Угода знає: разова сума "
                            "(one_time), щомісячна (mrr), валюта (currency)." % k)
        out[k] = _s(v)
    out["currency"] = out["currency"] or CURRENCY
    return out


def check_next_action(text, date_str="") -> dict:
    """Наступна дія: текст + строк. Строк зберігаємо ЗАВЖДИ у вигляді РРРР-ММ-ДД.

    🩸 ЗНАЙДЕНО ЖИВИМИ ДАНИМИ (проба переїзду, 15.08.2026): у картці на диску
    лежить строк «11.08.2026» — Андрій писав його руками у ЛЮДСЬКОМУ вигляді.
    Стара перевірка протермінування (`date.fromisoformat`) таку дату НЕ читала
    ніколи — тобто протермінована дія мовчки не спалахувала. Це рівно той клас,
    що й «дата запису не читається» у стрічці подій (B3).
    ⛒ Тому ЛЮДСЬКУ форму приймаємо і ПЕРЕКЛАДАЄМО, а не відкидаємо; будь-яку
    іншу — відмова словами. Мовчки покласти нечитабельний строк не можна: він
    виглядав би як «строку немає»."""
    na = {"text": _s(text), "date": _s(date_str)}
    if not na["date"]:
        return na
    m = re.match(r"^(\d{2})\.(\d{2})\.(\d{4})$", na["date"])
    if m:
        na["date"] = "%s-%s-%s" % (m.group(3), m.group(2), m.group(1))
    if not re.match(r"^\d{4}-\d{2}-\d{2}$", na["date"]):
        raise DealError("Строк наступної дії має бути у вигляді РРРР-ММ-ДД "
                        "(або ДД.ММ.РРРР), а не «%s»." % _s(date_str))
    from datetime import date as _d
    try:
        _d.fromisoformat(na["date"])
    except Exception:
        raise DealError("Такої дати не існує: «%s»." % _s(date_str))
    return na


# ── ПОСИЛАННЯ Й НАЗВА ────────────────────────────────────────────────────────
def ref(did) -> str:
    """Посилання на угоду для загального протоколу платформи."""
    d = _s(did)
    return entity.ref(entity.KIND_DEAL, d) if d else ""


def title(did) -> str:
    d = get(did)
    return _s(d.get("name")) or _s(did)


# ── Читання ──────────────────────────────────────────────────────────────────
def get(did) -> dict:
    return dict(_load()["deals"].get(_s(did)) or {})


def exists(did) -> bool:
    return _s(did) in _load()["deals"]


def _row(d: dict) -> dict:
    """Повна форма рядка — щоб екран не мусив знати, коли завели угоду."""
    row = dict(d or {})
    row.setdefault("id", "")
    row.setdefault("name", "")
    row["stage"] = _s(row.get("stage"))
    row["stage_id"] = _s(row.get("stage_id"))
    row["amount"] = check_amount(row.get("amount"))
    na = dict(row.get("next_action") or {})
    row["next_action"] = {"text": _s(na.get("text")), "date": _s(na.get("date"))}
    row["attention"] = int(row.get("attention") or 0)
    row["archived"] = bool(row.get("archived"))
    row.setdefault("note", "")
    row.setdefault("created", "")
    row.setdefault("updated", "")
    row.setdefault("source", "")
    # ⭐ 651: форма оплати, позначка «сплачено», очікувана дата оплати і коли
    # угода заходила на кожну стадію (для виручки місяця й циклу угоди).
    row["payment_form"] = _s(row.get("payment_form"))
    row["paid"] = bool(row.get("paid"))
    row["pay_date"] = _s(row.get("pay_date"))
    row["stage_at"] = dict(row.get("stage_at") or {})
    return row


# ═══════════ ФІЛЬТР ВОРОНКИ ЗА ПОЛЕМ КАРТКИ (зміна 594, 16.09.2026) ════════
# ⛒ ЛІКУЄМО КЛАС, А НЕ «НАПРЯМ УГОДИ». 593 навчила картку питати напрям
# (продаж/закупівля) і категорію, але воронка про це не знала: поле
# заповнюється, а подивитись «лише закупівлі» неможливо. Фільтр зроблено по
# БУДЬ-ЯКОМУ оголошеному полю-списку картки угоди — завтрашній «регіон» або
# «тип техніки» фільтруватиметься без жодного рядка коду.
# ⛒ ПЕРЕЛІК ФІЛЬТРІВ РАХУЄ СЕРВЕР, а не екран: зашитий на екрані перемикач
# «продаж/закупівля» не побачив би поля, заведеного вчора.
def filters() -> list:
    """Поля, за якими воронку можна звузити, з їхніми значеннями."""
    try:
        import card_fields as _cf
        out = []
        for f in _cf.layout(entity.KIND_DEAL):
            if _s(f.get("type")) != _cf.T_LIST:
                continue
            ch = list(f.get("choices") or [])
            if _s(f.get(_cf.F_PARENT)):
                # ⛒ У залежного списку власного переліку немає: збираємо всі
                # значення, які він узагалі вміє приймати, — інакше за
                # категорією фільтрувати було б нічим.
                seen = []
                for vals in (f.get(_cf.F_CHOICES_BY) or {}).values():
                    for v in (vals or []):
                        if v not in seen:
                            seen.append(v)
                ch = seen
            out.append({"id": _s(f.get("id")), "name": _s(f.get("name")),
                        "choices": ch})
        return out
    except Exception:
        return []


def check_filter(field, value) -> tuple:
    """(поле, значення) або ВІДМОВА СЛОВАМИ.

    ⛒ Порожня воронка замість відмови — найгірша з відповідей: людина читає її
    як «угод немає», а насправді помилка в самому питанні."""
    fid, val = _s(field), _s(value)
    if not fid and not val:
        return "", ""
    import card_fields as _cf
    if not fid:
        raise DealError("Сказано, ЩО шукати, але не сказано, у якому полі.")
    f = _cf.get(fid)
    if not f:
        raise DealError("Поля %s немає в будові карток." % fid)
    if _s(f.get("card")) != entity.KIND_DEAL:
        raise DealError("«%s» лежить у картці «%s», а не в картці угоди."
                        % (_s(f.get("name")),
                           entity.KIND_NAMES.get(_s(f.get("card")), "?")))
    if _s(f.get("type")) != _cf.T_LIST:
        raise DealError("Воронку звужують за полем-списком, а «%s» — це «%s»."
                        % (_s(f.get("name")),
                           _cf.TYPE_NAMES.get(_s(f.get("type")), "?")))
    if not val:
        return fid, ""
    allowed = []
    for row in filters():
        if row["id"] == fid:
            allowed = row["choices"]
            break
    if val not in allowed:
        raise DealError("Поле «%s» не має значення «%s». Є: %s."
                        % (_s(f.get("name")), val,
                           ", ".join(allowed) or "(перелік порожній)"))
    return fid, val


def _field_values(fid) -> dict:
    """{номер угоди: значення поля} — за одне читання реєстру значень."""
    out = {}
    try:
        import card_values as _cv
        for ref_, val in _cv.values_of_field(fid).items():
            if entity.kind_of(ref_) == entity.KIND_DEAL:
                out[entity.ident_of(ref_)] = val
    except Exception:
        return {}
    return out


def all_deals(archived=None, party: str = "", sift: bool = True,
              field: str = "", value: str = "") -> list:
    """Усі угоди. `archived=None` — усі, True/False — лише архівні/живі.
    `party` — лише угоди цього контрагента. Свіжіші згори."""
    pid = _s(party)
    keep = set(deal_ids_of_party(pid)) if pid else None
    out = []
    for did, d in _load()["deals"].items():
        row = _row(d)
        row["id"] = row["id"] or did
        if archived is not None and bool(row["archived"]) != bool(archived):
            continue
        if keep is not None and did not in keep:
            continue
        out.append(row)
    out.sort(key=lambda x: _s(x.get("created")), reverse=True)
    # ⭐⭐⭐ 589: СИТО ВИДИМОСТІ — у читача переліку. Через нього йдуть канбан,
    # воронка, плитки в картці контрагента і та сама дошка, яку ЗАПИС повертає
    # у відповідь. Угода судиться господарем свого контрагента.
    # ⭐ 594: звуження за полем картки — ДО сита видимості: фільтр лише
    # звужує і не має права показати те, чого людині не видно.
    fid, val = _s(field), _s(value)
    if fid:
        got = _field_values(fid)
        keep = []
        for row in out:
            have = got.get(_s(row.get("id")))
            have = have if isinstance(have, list) else ([have] if have else [])
            if val and val in [_s(x) for x in have]:
                keep.append(row)
            elif not val and have:
                keep.append(row)
        out = keep
    # ⭐ 590: `sift=False` просить ПОВНИЙ перелік — його бере лише той, хто
    # сам притемнить чужі рядки (картка контрагента). Ховати там не можна:
    # перелік угод клієнта — це факт стосунків компанії з ним.
    if not sift:
        return out
    try:
        import entity_scope as _vs589
        return _vs589.sift(_vs589.KIND_DEAL, out)
    except Exception:
        return out


def count() -> dict:
    d = _load()["deals"]
    live = sum(1 for x in d.values() if not x.get("archived"))
    return {"all": len(d), "live": live, "archived": len(d) - live}


# ── КЛІЄНТ УГОДИ Й ЇЇ ЛЮДИ — ЧЕРЕЗ РЕЄСТР ЗВʼЯЗКІВ ───────────────────────────
# ⭐⭐⭐ ДРУГОГО СХОВИЩА НЕ ЗʼЯВЛЯЄТЬСЯ. «Угода з компанією» і «контактна особа
# угоди» — це факти про ДВІ сутності, а не властивість жодної з них (закон B2).
# Тому вони лежать у реєстрі звʼязків, а картка контакту показує свої угоди
# ПОХІДНО — рівно як «Контактні особи» в B5.
# ⚠ Реєстр імпортуємо ВСЕРЕДИНІ функцій: `links` питає `entity`, `entity` питає
# `deals`, і верхній імпорт закільцював би трійку.
def _links():
    import links
    return links


def client_of(did) -> str:
    """Номер контрагента-клієнта цієї угоди («» — звʼязку немає)."""
    me = ref(did)
    if not me:
        return ""
    try:
        L = _links()
        for row in L.outgoing(me):
            if _s(row.get("rel")) == L.REL_DEAL_WITH:
                return entity.ident_of(row.get("ref"))
    except Exception:
        pass
    return ""


# ─────────────────── ХТО ВЕДЕ ЦЮ УГОДУ (зміна 590, 16.09.2026) ─────────────
# ⭐⭐⭐ ВИПАДОК АНДРІЯ. Контрагента завів і веде Петренко. Той самий клієнт
# купує товар іншого напряму — і ту угоду веде Хоменко. Досі відповідального в
# угоди не було ЗОВСІМ, і видимість 589 судила угоду господарем компанії: Хоменко
# не міг ні завести угоду, ні відкрити її, а в базі зʼявився б ДУБЛЬ компанії.
#
# ⛒ ДРУГЕ ПОЛЕ — НЕ ДУБЛЬ ПЕРШОГО. «Хто веде компанію» і «хто веде цю угоду» —
# два різні питання: компанія живе роками й має одного господаря, угода живе
# тижнями й належить своєму напряму. Той самий клієнт буває і покупцем, і
# постачальником, і закупівельні угоди веде третя людина.
#
# ⛒ СХОВИЩЕ ТЕ САМЕ. Відповідальний живе в реєстрі звʼязків (`managed_by`), як і
# в контрагента: другого місця для однієї й тієї ж відповіді не заводимо.
def manager_ref(did) -> str:
    """Посилання на людину, яка веде цю угоду (або "").

    ⚠ Загорнуто: зламаний реєстр не сміє повалити картку угоди."""
    try:
        L = _links()
        me = ref(did)
        if not me:
            return ""
        for row in L.outgoing(me):
            if _s(row.get("rel")) == L.REL_MANAGED_BY:
                return _s(row.get("ref"))
    except Exception:
        return ""
    return ""


def manager_of(did) -> str:
    """Номер працівника, який веде угоду («» — власного відповідального немає).

    ⛒ ПОРОЖНЬО — ЦЕ НЕ «НІЧИЯ». Угоди, заведені до 590, власного відповідального
    не мають і матимуть його лише тоді, коли поставлять руками; доти вони
    судяться відповідальним СВОГО КОНТРАГЕНТА (`entity_scope`). Інакше жива база
    клієнта одного ранку стала б нічиєю."""
    row = manager_ref(did)
    return entity.ident_of(row) if row else ""


def set_manager(did, emp_id, by: str = "") -> dict:
    """Призначити відповідального за угоду або зняти його (порожньо = зняти).

    ⛒ РІВНО ОДИН: старий звʼязок ПРИБИРАЄМО, а не додаємо другий."""
    key = _s(did)
    if not exists(key):
        raise DealError("Угоди %s немає в реєстрі." % (key or "«»"))
    L = _links()
    me = ref(key)
    old = manager_of(key)
    new = _s(emp_id)
    if new:
        import taskdesk_people as _people
        rec = _people.employee(new)
        if not rec:
            raise DealError("Працівника %s немає в оргструктурі." % new)
        if rec.get("dismissed"):
            raise DealError(
                "%s звільнений — угоду йому не віддають. Виберіть чинного "
                "працівника." % (_s(rec.get("full_name")) or new))
    if old == new:
        return {"deal": key, "manager": new}
    if old:
        try:
            L.remove(me, L.REL_MANAGED_BY, entity.ref(entity.KIND_PERSON, old),
                     by=_s(by))
        except Exception:
            pass
    if new:
        L.add(me, L.REL_MANAGED_BY, entity.ref(entity.KIND_PERSON, new),
              by=_s(by))
    _to_protocol(protocol.A_DEAL_CHANGED, key,
                 "відповідальний: %s" % (entity.title(
                     entity.ref(entity.KIND_PERSON, new)) if new else "(знято)"))
    return {"deal": key, "manager": new}


def manager_name(did) -> str:
    """Імʼя того, хто веде угоду, — словами й одним писарем."""
    row = manager_ref(did)
    return entity.title(row) if row else ""


def people_of(did) -> list:
    """Контактні особи угоди: [{party_id, note}] (їх буває скільки треба)."""
    me = ref(did)
    if not me:
        return []
    out = []
    try:
        L = _links()
        for row in L.outgoing(me):
            if _s(row.get("rel")) == L.REL_DEAL_PERSON:
                out.append({"party_id": entity.ident_of(row.get("ref")),
                            "ref": _s(row.get("ref")),
                            "note": _s(row.get("note"))})
    except Exception:
        return []
    return out


def deal_ids_of_party(pid) -> list:
    """Номери угод цього контрагента (він — КЛІЄНТ угоди)."""
    p = _s(pid)
    if not p:
        return []
    out = []
    try:
        L = _links()
        me = entity.ref(entity.KIND_PARTY, p)
        for row in L.incoming(me):
            if _s(row.get("rel")) == L.REL_DEAL_WITH:
                out.append(entity.ident_of(row.get("ref")))
    except Exception:
        return []
    return out


def deals_of_party(pid, archived=None, sift: bool = True) -> list:
    """Угоди контрагента у повній формі рядка."""
    return all_deals(archived=archived, party=pid, sift=sift)


def live_deals_of_party(pid) -> list:
    """⭐ ГОЛОВНЕ ПИТАННЯ Р5: чи є в цього контакта РІВНО ОДНА жива угода.

    Технічна дія (збірка пакета) сміє рухати гроші у воронці лише тоді, коли
    іншого адресата не існує. При нулі або кількох — не вгадуємо."""
    return all_deals(archived=False, party=pid)


# ── ЗАГАЛЬНИЙ ПРОТОКОЛ ───────────────────────────────────────────────────────
# ЗАКОН (успадкований від `parties`, зміна 171): ХТО ЗБЕРІГАЄ — ТОЙ І ЗВІТУЄ.
# Рядок пише не кожна письмова функція окремо (одну неминуче забудуть), а ТРИ
# точки, через які вони всі й так проходять: `create`, `_mutate`, `delete`.
# ⚠ ЩО САМЕ ЗМІНИЛОСЬ, називає ВИКЛИКАЧ (`what`) — дефолту немає свідомо:
# мовчазне «щось змінилось» дало б журнал, який нічого не пояснює.
def _to_protocol(action: str, did: str, what: str, source: str = "") -> None:
    """Дописати рядок у загальний журнал платформи.

    ⭐ КЛІЄНТ УГОДИ ЙДЕ В `about` — саме цим «покажи все про Каспера» починає
    бачити рух його угод, не читаючи двох журналів.
    ⚠ Ніколи не валить роботу: реєстр угод — актив компанії, журнал — його тінь."""
    try:
        me = ref(did)
        about = []
        pid = client_of(did)
        if pid:
            about.append(entity.ref(entity.KIND_PARTY, pid))
        protocol.write(action, me, about=about, note=what, source=source)
    except Exception:
        pass


# ── Запис ────────────────────────────────────────────────────────────────────
@one_writer.guard("DEALS_JSON")
def create(name, party, stage: str = "", amount=None,
           next_action=None, note: str = "", source: str = "manual",
           by: str = "") -> dict:
    """Завести угоду. КЛІЄНТ ОБОВʼЯЗКОВИЙ.

    ⛒ «Угода без клієнта — не угода» (рішення Р2 проєкту C1). Тому клієнт не
    «поле, яке можна дозаповнити потім», а умова народження. Порядок такий:
    спершу перевіряємо ВСЕ (включно з тим, чи можна завести звʼязок), і лише
    потім пишемо. Угода-сирота без клієнта не зʼявляється навіть на мить.

    ⚠ ЯКЩО ЗВʼЯЗОК УСЕ Ж НЕ ЛІГ — угода прибирається, а відмова летить далі.
    Половини не буває: саме на «щось записалось, а щось ні» ми й горіли."""
    nm = check_name(name)
    st = check_stage(stage)
    amt = check_amount(amount)
    na = check_next_action((next_action or {}).get("text") if isinstance(next_action, dict) else "",
                           (next_action or {}).get("date") if isinstance(next_action, dict) else "")
    pid = _s(party)
    if not pid:
        raise DealError("Угода заводиться лише з клієнтом: скажіть, з ким вона.")
    party_ref = entity.ref(entity.KIND_PARTY, pid)
    if not entity.exists(party_ref):
        raise DealError("Контрагента %s немає в довіднику — угода вела б у порожнечу."
                        % pid)
    if len(_s(note)) > MAX_NOTE:
        raise DealError("Нотатка угоди задовга: %d знаків, межа %d."
                        % (len(_s(note)), MAX_NOTE))

    # Ворота стадії діють і на народженні: інакше «Укладення угоди» без суми
    # заводилось би в обхід — тим самим другим входом, від якого ми лікуємось.
    check_stage_ready({"amount": amt}, st)
    d = _load()
    did = _new_id(d)
    now = clock.now()
    sts = DS.stages_of(d)
    d["deals"][did] = {
        "id": did,
        "name": nm,
        "stage_id": st,
        "stage": DS.name_of(sts, st),
        "amount": amt,
        "next_action": na,
        "attention": 0,
        "archived": DS.kind_of(sts, st) in DS.ARCHIVE,
        "note": _s(note),
        "source": _s(source) or "manual",
        "created": now,
        "updated": now,
        "stage_at": {st: now},
    }
    _save(d)

    try:
        L = _links()
        L.add(ref(did), L.REL_DEAL_WITH, party_ref, by=by)
    except Exception as ex:
        # Відкіт: угода без клієнта не має права лишитись на диску.
        back = _load()
        back["deals"].pop(did, None)
        _save(back)
        raise DealError("Угоду не заведено: %s" % ex)

    _to_protocol(protocol.A_DEAL_CREATED, did,
                 "«%s» · %s · клієнт: %s · джерело: %s"
                 % (nm, st, entity.title(party_ref), _s(source) or "manual"))
    return _row(d["deals"][did])


@one_writer.guard("DEALS_JSON")
def _mutate(did, patch_fn, what: str, action: str = "", source: str = "") -> dict:
    """ОДНА точка запису на весь реєстр угод: хто зберігає — той і звітує."""
    key = _s(did)
    d = _load()
    row = d["deals"].get(key)
    if not row:
        raise DealError("Угоди %s немає в реєстрі." % (key or "«»"))
    patch_fn(row)
    row["updated"] = clock.now()
    d["deals"][key] = row
    _save(d)
    _to_protocol(_s(action) or protocol.A_DEAL_CHANGED, key, what, source=source)
    return _row(row)


def set_name(did, name) -> dict:
    """⭐ Назва міняється — НОМЕР НІ. Саме заради цього угода й стала сутністю:
    після перейменування канал оновлень пілота цього навіть не помітить."""
    nm = check_name(name)
    old = title(did)
    return _mutate(did, lambda r: r.__setitem__("name", nm),
                   "назву змінено: «%s» → «%s»" % (old or "?", nm))


def set_stage(did, stage, source: str = "") -> dict:
    """Перевести угоду на стадію воронки. Архів і стадія тримаються синхронно."""
    st = check_stage(stage)
    cur = get(did)
    if not cur:
        raise DealError("Угоди %s немає в реєстрі." % (_s(did) or "«»"))
    check_stage_ready(_row(cur), st)
    sts = stages()
    prev = _s(cur.get("stage")) or "?"
    name = DS.name_of(sts, st)

    def _p(r):
        r["stage_id"] = st
        r["stage"] = name
        r["archived"] = DS.kind_of(sts, st) in DS.ARCHIVE
        # ⭐ 651: КОЛИ угода зайшла на стадію — останній захід. Саме він каже,
        # у якому місяці угода закрилась (виручка) і скільки вона йшла (цикл).
        sa = dict(r.get("stage_at") or {})
        sa[st] = clock.now()
        r["stage_at"] = sa

    return _mutate(did, _p, "%s → %s" % (prev, name),
                   action=protocol.A_DEAL_STAGE, source=source)


def set_payment(did, form=_UNSET, paid=_UNSET, pay_date=_UNSET) -> dict:
    """⭐⭐⭐ 651. Форма оплати, позначка «сплачено» й очікувана дата оплати.

    ⛒ ТІ САМІ ВОРОТА, ЩО Й ПЕРЕХІД СТАДІЇ: змінити форму чи зняти «сплачено» так,
    щоб угода опинилась на стадії, якої вона без свого паперу не варта, не можна.
    Інакше правило обходилось би за два кроки: закрив із договором — перемкнув
    форму на «накладений платіж» без ТТН."""
    cur = get(did)
    if not cur:
        raise DealError("Угоди %s немає в реєстрі." % (_s(did) or "«»"))
    row = _row(cur)
    said = []
    if form is not _UNSET:
        f = _s(form)
        if f and f not in PAY_FORMS:
            raise DealError("Невідома форма оплати «%s». Платформа знає: %s."
                            % (f, ", ".join(PAY_FORMS[k]["name"] for k in PAY_ORDER)))
        row["payment_form"] = f
        said.append("форма оплати: %s" % (PAY_FORMS[f]["name"] if f else "не обрано"))
    if paid is not _UNSET:
        row["paid"] = bool(paid)
        said.append("сплачено" if paid else "позначку «сплачено» знято")
    if pay_date is not _UNSET:
        pd = _s(pay_date)
        if pd:
            try:
                from datetime import date as _d651
                _d651.fromisoformat(pd[:10])
                if len(pd) != 10:
                    raise ValueError(pd)
            except Exception:
                raise DealError("Дата оплати «%s» не читається. Вкажіть її у вигляді "
                                "календарної дати." % pd)
        row["pay_date"] = pd
        said.append("очікувана оплата: %s" % (pd or "не вказано"))
    if not said:
        return row
    try:
        check_stage_ready(row, row["stage_id"] or row["stage"])
    except DealError as ex:
        raise DealError("Так не можна: угода стоїть на стадії «%s». %s Спершу "
                        "поверніть угоду на попередню стадію або причепіть папір."
                        % (row["stage"], ex))

    def _p(r):
        r["payment_form"] = row["payment_form"]
        r["paid"] = row["paid"]
        r["pay_date"] = row["pay_date"]

    return _mutate(did, _p, "; ".join(said))


def set_amount(did, amount) -> dict:
    """Оновити суми (те, що приходить, — те й міняється; решта лишається)."""
    cur = check_amount(get(did).get("amount"))
    src = dict(amount or {})
    # ⚠ СПЕРШУ СУДИМО ВХІД, а вже потім міняємо. Перебирати лише ВІДОМІ ключі
    # означало б мовчки проковтнути чуже поле: людина вписала «комісію», нічого
    # не сталось, і ніхто не сказав чому (спіймано власним чеком 15.08).
    check_amount({k: v for k, v in src.items() if v is not None})
    for k in ("one_time", "mrr", "currency"):
        if k in src and src[k] is not None:
            cur[k] = _s(src[k])
    cur = check_amount(cur)
    return _mutate(did, lambda r: r.__setitem__("amount", cur),
                   "суми: разова %s · щомісяця %s %s"
                   % (cur["one_time"] or "—", cur["mrr"] or "—", cur["currency"]))


def set_next_action(did, text, date_str: str = "") -> dict:
    na = check_next_action(text, date_str)
    return _mutate(did, lambda r: r.__setitem__("next_action", na),
                   "наступна дія: %s%s" % (na["text"] or "— знято —",
                                           (" · до " + na["date"]) if na["date"] else ""))


def mark_action_done(did) -> dict:
    """«Дію виконано»: гасить бейдж уваги і чистить саму дію одним кроком."""
    cur = get(did)
    txt = _s((cur.get("next_action") or {}).get("text"))

    def _p(r):
        r["next_action"] = {"text": "", "date": ""}
        r["attention"] = 0

    return _mutate(did, _p, "дію виконано: %s" % (txt or "без опису"))


def set_attention(did, value=None, inc: int = 0) -> dict:
    """Бейдж «потребує уваги». ⭐ Він лишається на УГОДІ (заміна Р4 за словом
    Андрія 15.08): увага — про роботу продавця по ЦІЙ угоді."""
    cur = int(get(did).get("attention") or 0)
    new = int(value) if value is not None else (cur + int(inc))
    new = max(0, new)

    def _p(r):
        r["attention"] = new

    return _mutate(did, _p, "увага: %d" % new)


def set_archived(did, flag: bool = True) -> dict:
    """В архів (угода не відбулась / завершена) або назад у роботу.
    ⛒ 738: архів — «Успіх», якщо угода колись заходила на виграну стадію, інакше «Провал»;
    назад — на виграну (немає такої в воронці — на стадію нової угоди)."""
    sts = stages()
    won = set(DS.ids_of_kind(sts, "won"))

    def _p(r):
        if flag:
            ever = any(_s(k) in won for k in (r.get("stage_at") or {})) or _ever_won_legacy(r)
            sid = DS.first_of_kind(sts, "archive_won" if ever else "archive_lost")
        else:
            sid = DS.first_of_kind(sts, "won") or DS.default_id(sts)
        r["archived"] = bool(flag)
        r["stage_id"] = sid
        r["stage"] = DS.name_of(sts, sid)
        sa = dict(r.get("stage_at") or {})
        sa[sid] = clock.now()
        r["stage_at"] = sa

    return _mutate(did, _p, "перенесено в архів" if flag else "повернуто з архіву",
                   action=protocol.A_DEAL_STAGE)


def set_note(did, note) -> dict:
    text = _s(note)
    if len(text) > MAX_NOTE:
        raise DealError("Нотатка угоди задовга: %d знаків, межа %d."
                        % (len(text), MAX_NOTE))
    return _mutate(did, lambda r: r.__setitem__("note", text), "нотатку змінено")


def set_client(did, pid, by: str = "") -> dict:
    """Змінити компанію-клієнта угоди. Рівно одна — тому старий звʼязок ПРИБИРАЄМО,
    а не додаємо другий (інакше «угода з двома клієнтами» = дві угоди)."""
    key = _s(did)
    if not exists(key):
        raise DealError("Угоди %s немає в реєстрі." % (key or "«»"))
    new_pid = _s(pid)
    party_ref = entity.ref(entity.KIND_PARTY, new_pid)
    if not entity.exists(party_ref):
        raise DealError("Контрагента %s немає в довіднику." % (new_pid or "«»"))
    old = client_of(key)
    if old == new_pid:
        return _row(get(key))
    L = _links()
    me = ref(key)
    if old:
        L.remove(me, L.REL_DEAL_WITH, entity.ref(entity.KIND_PARTY, old), by=by)
    L.add(me, L.REL_DEAL_WITH, party_ref, by=by)
    return _mutate(key, lambda r: None,
                   "клієнта змінено: %s → %s"
                   % (entity.title(entity.ref(entity.KIND_PARTY, old)) if old else "—",
                      entity.title(party_ref)))


def add_person(did, pid, note: str = "", by: str = "") -> dict:
    """Додати контактну особу угоди (їх буває скільки треба — правка C3 v2)."""
    key = _s(did)
    if not exists(key):
        raise DealError("Угоди %s немає в реєстрі." % (key or "«»"))
    L = _links()
    L.add(ref(key), L.REL_DEAL_PERSON, entity.ref(entity.KIND_PARTY, _s(pid)),
          by=by, note=note)
    return _row(get(key))


def remove_person(did, pid, by: str = "") -> dict:
    key = _s(did)
    L = _links()
    L.remove(ref(key), L.REL_DEAL_PERSON, entity.ref(entity.KIND_PARTY, _s(pid)), by=by)
    return _row(get(key))


@one_writer.guard("DEALS_JSON")
def delete(did, by: str = "") -> bool:
    """Прибрати угоду. Видалення НЕ вгадує форму — тільки за номером."""
    key = _s(did)
    d = _load()
    if key not in d["deals"]:
        return False
    gone = _s((d["deals"].get(key) or {}).get("name"))
    # Клієнта питаємо ДО видалення — після нього про нього нема кого спитати.
    _to_protocol(protocol.A_DEAL_DELETED, key, "«%s»" % (gone or "без назви"))
    d["deals"].pop(key)
    _save(d)
    # ⭐⭐⭐ ВИДАЛЕНА СУТНІСТЬ НЕ ЛИШАЄ ЖИВИХ ЗВʼЯЗКІВ (закон B2). Дані від цього
    # не зникають: кожне прибирання лягає в протокол окремим рядком.
    me = entity.ref(entity.KIND_DEAL, key)
    try:
        _links().forget(me, by=by)
    except Exception as ex:
        protocol.write(protocol.A_LINK_REMOVED, me,
                       outcome="%s: %s" % (protocol.OUT_FAILED, ex),
                       note="звʼязки прибраної угоди лишились у реєстрі")
    return True


# ═══════════ АБОНПЛАТА АКТИВНОГО КЛІЄНТА (зміна 676, 01.10.2026) ════════════
# ⭐⭐⭐ ДОРОБКА АНДРІЯ 01.10.2026: угода на стадії «Активні клієнти» нагадує про
# рахунок на абонплату й стежить, чи прийшли гроші. Супровід — регулярні гроші
# (Каспер, ОТУ), і пропущений рахунок не помічає ніхто, доки грошей просто немає.
# ⛒ ГРАФІК ЖИВЕ В УГОДІ, а не в окремій задачі чи календарі: угода — єдиний писар
# грошей клієнта. Задача «виставити рахунок» була б другим писарем того самого
# факту й розійшлась би з угодою на першій же зміні суми чи дня.
# ⛒ СТАН МІСЯЦЯ РАХУЄ ОДИН ЧИТАЧ — `billing_state`. Картка, канбан, «потребує
# уваги», дашборд і головна сторінка питають його, а не рахують самі.
# ⛒ СУМА МІСЯЦЯ — ЗНІМОК на день рахунку: зміна щомісячної суми потім не
# переписує минулих рахунків (інакше борг за вересень «змінився б» у листопаді).
BILLING_TERM_DEFAULT = 5     # днів на оплату після рахунку
BILLING_LEAD_DEFAULT = 3     # за скільки днів до рахунку нагадати
BILLING_DAY_MAX = 28         # 29–31 бувають не в кожному місяці
BILLING_PAST_PAID = 6        # скільки місяців сплаченої історії показує картка
MONTHS_UA = ("січень", "лютий", "березень", "квітень", "травень", "червень",
             "липень", "серпень", "вересень", "жовтень", "листопад", "грудень")
# Родовий відмінок — для «з жовтня 2026»: «з жовтень» людина читає як помилку.
MONTHS_UA_GEN = ("січня", "лютого", "березня", "квітня", "травня", "червня",
                 "липня", "серпня", "вересня", "жовтня", "листопада", "грудня")
BILLING_MARKS = {"invoiced": "рахунок виставлено", "paid": "оплату отримано"}
B_UPCOMING, B_SOON, B_NOW, B_LATE = "upcoming", "invoice_soon", "invoice_now", "invoice_late"
B_WAITING, B_OVERDUE, B_PAID = "waiting", "overdue", "paid"
BILLING_STATE_NAMES = {
    B_UPCOMING: "попереду", B_SOON: "скоро рахунок", B_NOW: "сьогодні рахунок",
    B_LATE: "рахунок не виставлено", B_WAITING: "чекаємо оплату",
    B_OVERDUE: "оплата протермінована", B_PAID: "сплачено",
}
# Порядок гостроти: протермінована оплата — найгостріше, далі невиставлений рахунок.
_B_RANK = {B_OVERDUE: 0, B_LATE: 1, B_NOW: 2, B_SOON: 3}
_B_LEVEL = {B_OVERDUE: "bad", B_LATE: "bad", B_NOW: "warn", B_SOON: "warn"}


def _today() -> str:
    return clock.now()[:10]


def _dmy(iso) -> str:
    s = _s(iso)
    return "%s.%s.%s" % (s[8:10], s[5:7], s[:4]) if len(s) >= 10 else s


def month_name(m, gen: bool = False) -> str:
    """«2026-10» → «жовтень 2026» (gen=True → «жовтня 2026», для «з …»)."""
    s = _s(m)
    try:
        return "%s %s" % ((MONTHS_UA_GEN if gen else MONTHS_UA)[int(s[5:7]) - 1], s[:4])
    except Exception:
        return s


def _add_months(m: str, k: int) -> str:
    t = int(m[:4]) * 12 + int(m[5:7]) - 1 + int(k)
    return "%04d-%02d" % (t // 12, t % 12 + 1)


def _plus_days(iso: str, n: int) -> str:
    from datetime import date as _d676, timedelta as _td676
    return (_d676.fromisoformat(iso[:10]) + _td676(days=int(n))).isoformat()


def _days_between(a: str, b: str) -> int:
    from datetime import date as _d676b
    return (_d676b.fromisoformat(b[:10]) - _d676b.fromisoformat(a[:10])).days


def _check_month(m) -> str:
    s = _s(m)
    if not re.match(r"^\d{4}-(0[1-9]|1[0-2])$", s):
        raise DealError("Місяць абонплати «%s» не читається. Вкажіть його у вигляді "
                        "РРРР-ММ (наприклад, 2026-10)." % s)
    return s


def _check_iso_day(v, what: str) -> str:
    """Дата у вигляді РРРР-ММ-ДД або ДД.ММ.РРРР → РРРР-ММ-ДД; інакше відмова."""
    s = _s(v)
    m = re.match(r"^(\d{2})\.(\d{2})\.(\d{4})$", s)
    if m:
        s = "%s-%s-%s" % (m.group(3), m.group(2), m.group(1))
    try:
        from datetime import date as _d676c
        _d676c.fromisoformat(s)
        if len(s) != 10:
            raise ValueError(s)
    except Exception:
        raise DealError("%s «%s» не читається. Вкажіть календарну дату "
                        "(ДД.ММ.РРРР)." % (what, _s(v)))
    return s


def _int_in(v, lo: int, hi: int, what: str) -> int:
    if isinstance(v, bool):
        raise DealError("%s — це число від %d до %d." % (what, lo, hi))
    try:
        n = int(_s(v))
    except Exception:
        raise DealError("%s «%s» — не ціле число. Вкажіть від %d до %d."
                        % (what, _s(v), lo, hi))
    if not lo <= n <= hi:
        raise DealError("%s має бути від %d до %d, а не %d." % (what, lo, hi, n))
    return n


def _billing(row) -> dict:
    """Графік абонплати угоди у сталій формі (сховищна форма — `row["billing"]`)."""
    b = dict((row or {}).get("billing") or {})

    def _n(k, dflt):
        v = b.get(k)
        return v if isinstance(v, int) and not isinstance(v, bool) else dflt
    return {"on": bool(b.get("on")), "day": _n("day", 0),
            "term": _n("term", BILLING_TERM_DEFAULT), "lead": _n("lead", BILLING_LEAD_DEFAULT),
            "start": _s(b.get("start")),
            "months": {_s(k): dict(v or {}) for k, v in dict(b.get("months") or {}).items()}}


def _billing_last(b: dict, today: str) -> str:
    """Останній місяць графіка, про який уже можна говорити: місяць дати «сьогодні +
    нагадування заздалегідь», але не раніше першого місяця графіка."""
    return max(_plus_days(today, b["lead"])[:7], b["start"])


def billing_state(row, mrr=None) -> dict:
    """⭐⭐⭐ 676. ОДИН ЧИТАЧ АБОНПЛАТИ: графік, стан кожного місяця, нагадування.

    `mrr` — щомісячна сума, якою рахувати ще не виставлені місяці (типово — сума
    угоди). Нагадування — лише для живої угоди на стадії «Активні клієнти» з
    увімкненим графіком: інша стадія людину не смикає."""
    row = row or {}
    b = _billing(row)
    today = _today()
    cur_mrr = _s(((row.get("amount") or {}).get("mrr")) if mrr is None else mrr)
    live = (_kind(row) == "won" and not row.get("archived"))
    out = {"on": b["on"], "day": b["day"], "term": b["term"], "lead": b["lead"],
           "start": b["start"], "mrr": cur_mrr,
           "start_from": ("з " + month_name(b["start"], gen=True)) if b["start"] else "",
           "currency": _s((row.get("amount") or {}).get("currency")) or CURRENCY,
           "active": live, "months": [], "alerts": [], "alert": "", "level": "",
           "debt": 0.0, "states": dict(BILLING_STATE_NAMES)}
    if not b["start"] or not b["day"]:
        return out
    m, last = b["start"], _billing_last(b, today)
    while m <= last:
        rec = b["months"].get(m) or {}
        inv_on = "%s-%02d" % (m, b["day"])
        amount = _s(rec.get("amount")) or cur_mrr
        inv, paid = _s(rec.get("invoiced")), _s(rec.get("paid"))
        pay_by = _plus_days(inv or inv_on, b["term"])
        if paid:
            st = B_PAID
        elif inv:
            st = B_OVERDUE if today > pay_by else B_WAITING
        elif today > inv_on:
            st = B_LATE
        elif today == inv_on:
            st = B_NOW
        elif today >= _plus_days(inv_on, -b["lead"]):
            st = B_SOON
        else:
            st = B_UPCOMING
        x = {"month": m, "name": month_name(m), "invoice_on": inv_on, "pay_by": pay_by,
             "invoiced": inv, "paid": paid, "amount": amount, "state": st,
             "state_name": BILLING_STATE_NAMES[st]}
        out["months"].append(x)
        if st == B_OVERDUE:
            out["debt"] += num(amount)
        if b["on"] and live and st in _B_RANK:
            nm = x["name"]
            if st == B_OVERDUE:
                txt = ("Абонплата за %s: оплата протермінована на %d дн. (рахунок %s, "
                       "сплатити до %s)" % (nm, _days_between(pay_by, today), _dmy(inv), _dmy(pay_by)))
            elif st == B_LATE:
                txt = ("Абонплата за %s: рахунок не виставлено — за графіком %s "
                       "(%d дн. тому)" % (nm, _dmy(inv_on), _days_between(inv_on, today)))
            elif st == B_NOW:
                txt = "Абонплата за %s: сьогодні виставити рахунок (%s)" % (nm, _dmy(inv_on))
            else:
                txt = ("Абонплата за %s: %s — виставити рахунок (через %d дн.)"
                       % (nm, _dmy(inv_on), _days_between(today, inv_on)))
            out["alerts"].append({"month": m, "state": st, "level": _B_LEVEL[st],
                                  "rank": _B_RANK[st], "text": txt})
        m = _add_months(m, 1)
    out["alerts"].sort(key=lambda a: (a["rank"], a["month"]))
    if out["alerts"]:
        out["alert"], out["level"] = out["alerts"][0]["text"], out["alerts"][0]["level"]
    return out


def _money_hidden(did) -> bool:
    """Чи сховані гроші цієї угоди від того, хто зараз читає. Суддя — ТОЙ САМИЙ
    `entity_scope.hide_money`, що ховає суму угоди: другий суддя грошей розійшовся
    б із першим, і абонплата назвала б суму, сховану в картці."""
    try:
        import entity_scope as _vs676
        return _vs676.hide_money([{"m": "1"}], ("m",), did=_s(did))[0].get("m") == ""
    except Exception:
        return False


def _billing_without_money(state: dict) -> dict:
    s = dict(state)
    s["mrr"], s["debt"] = "", ""
    s["months"] = [dict(x, amount="") for x in (state.get("months") or [])]
    return s


def set_billing(did, on=_UNSET, day=_UNSET, term=_UNSET, lead=_UNSET, start=_UNSET) -> dict:
    """⭐⭐⭐ 676. Графік абонплати: увімкнено, день рахунку, строк оплати,
    за скільки днів нагадати, з якого місяця. Міняється лише те, що прийшло.

    ⛒ СПЕРШУ СУДИМО ВСЕ, ПОТІМ ПИШЕМО: невдала спроба не лишає пів графіка."""
    cur = get(did)
    if not cur:
        raise DealError("Угоди %s немає в реєстрі." % (_s(did) or "«»"))
    row = _row(cur)
    b = _billing(cur)
    said = []
    if day is not _UNSET:
        b["day"] = _int_in(day, 1, BILLING_DAY_MAX, "День рахунку")
        said.append("рахунок %d-го числа" % b["day"])
    if term is not _UNSET:
        b["term"] = _int_in(term, 0, 60, "Строк оплати (днів після рахунку)")
        said.append("строк оплати %d дн." % b["term"])
    if lead is not _UNSET:
        b["lead"] = _int_in(lead, 0, 15, "Нагадування заздалегідь (днів)")
        said.append("нагадати за %d дн." % b["lead"])
    if start is not _UNSET:
        b["start"] = _check_month(start)
        said.append("з %s" % month_name(b["start"], gen=True))
    if on is not _UNSET:
        b["on"] = bool(on)
        said.append("графік увімкнено" if b["on"] else "графік вимкнено")
    if not said:
        return row
    if b["on"]:
        if num(row["amount"].get("mrr")) <= 0:
            raise DealError("Абонплата рахується від щомісячної суми угоди, а її немає. "
                            "Спершу вкажіть суму «Щомісяця» у блоці «Вартість угоди».")
        if not b["day"]:
            raise DealError("Скажіть, якого числа щомісяця виставляється рахунок "
                            "(від 1 до %d)." % BILLING_DAY_MAX)
        if not b["start"]:
            b["start"] = _today()[:7]
    store = {"on": b["on"], "day": b["day"], "term": b["term"], "lead": b["lead"],
             "start": b["start"], "months": b["months"]}
    return _mutate(did, lambda r: r.__setitem__("billing", store),
                   "абонплата: " + "; ".join(said))


def mark_billing(did, month, what, value=True, date: str = "") -> dict:
    """⭐⭐⭐ 676. Позначити місяць абонплати: рахунок виставлено / оплату отримано
    (або зняти позначку). Дата — коли саме; типово сьогодні."""
    w = _s(what)
    if w not in BILLING_MARKS:
        raise DealError("Невідома позначка абонплати «%s». Платформа знає: рахунок "
                        "виставлено (invoiced), оплату отримано (paid)." % w)
    m = _check_month(month)
    cur = get(did)
    if not cur:
        raise DealError("Угоди %s немає в реєстрі." % (_s(did) or "«»"))
    b = _billing(cur)
    if not b["start"] or not b["day"]:
        raise DealError("В угоди немає графіка абонплати — спершу задайте день рахунку.")
    last = _billing_last(b, _today())
    if m < b["start"]:
        raise DealError("Графік абонплати починається з %s — %s у нього не входить."
                        % (month_name(b["start"], gen=True), month_name(m)))
    if m > last:
        raise DealError("%s ще попереду: позначати можна місяці до %s включно."
                        % (month_name(m).capitalize(), month_name(last)))
    rec = dict(b["months"].get(m) or {})
    if value:
        d = _check_iso_day(date, "Дата") if _s(date) else _today()
        rec[w] = d
        if not _s(rec.get("amount")):
            rec["amount"] = _s(_row(cur)["amount"].get("mrr"))
        said = "%s за %s — %s" % (BILLING_MARKS[w], month_name(m), _dmy(d))
    else:
        rec.pop(w, None)
        if not rec.get("invoiced") and not rec.get("paid"):
            rec.pop("amount", None)
        said = "позначку «%s» за %s знято" % (BILLING_MARKS[w], month_name(m))
    months = dict(b["months"])
    if rec:
        months[m] = rec
    else:
        months.pop(m, None)

    def _p(r):
        bb = dict(r.get("billing") or {})
        bb["months"] = months
        r["billing"] = bb

    return _mutate(did, _p, "абонплата: " + said)


def billing_alerts() -> list:
    """Усі нагадування абонплати, які бачить цей читач, — найгостріші згори.
    Для головної сторінки («Чекає на вас») і дашборда."""
    out = []
    for r in all_deals(archived=False):
        if not (r.get("billing") or {}).get("on"):
            continue
        st = billing_state(r)
        if not st["alerts"]:
            continue
        did = _s(r.get("id"))
        pid = client_of(did)
        for a in st["alerts"]:
            out.append(dict(a, deal=did, name=_s(r.get("name")),
                            href=entity.screen(ref(did)),
                            client=entity.title(entity.ref(entity.KIND_PARTY, pid)) if pid else ""))
    out.sort(key=lambda a: (a["rank"], a["month"], a["name"].lower()))
    return out


# ── ЩО ПОТРЕБУЄ УВАГИ ────────────────────────────────────────────────────────
def _is_overdue(date_str) -> bool:
    from datetime import date as _date
    try:
        return bool(date_str) and _date.fromisoformat(_s(date_str)[:10]) < _date.today()
    except Exception:
        return False


def due_reason(row: dict) -> str:
    """Чому угода потребує уваги (порожньо = не потребує). Лише живі.

    ⚠ ЛІЦЕНЗІЯ ТУТ НЕ ПИТАЄТЬСЯ. Її строк — факт КАРТКИ КЛІЄНТА (техніка), і
    підмішувати його в продажну воронку означало б повернути рівно те злиття,
    яке C1 і розділяє. Хто хоче бачити ліцензію — дивиться картку клієнта."""
    if row.get("archived"):
        return ""
    why = []
    na = row.get("next_action") or {}
    if _is_overdue(na.get("date")):
        why.append("Протермінована дія: " + _s(na.get("text")))
    # ⭐ 676: рахунок абонплати й оплата — та сама «увага», що й протермінована дія.
    if (row.get("billing") or {}).get("on"):
        try:
            a = billing_state(row).get("alert")
        except Exception:
            a = ""
        if a:
            why.append(a)
    return "; ".join(why)


# ── ВОРОНКА, ДАШБОРД, ПЛИТКА — ПО УГОДАХ ─────────────────────────────────────
# ⭐⭐⭐ Рішення Р8 проєкту C1: воронка рахує УГОДИ, а не картки. Різниця не
# косметична: до переїзду у воронці лежали 23 картки, з них 11 — тестувальники
# чужого продукту, які нічого не купували. `crm.board()` / `crm.pipeline()`
# лишаються тими самими іменами, але стають тонкими викликами сюди.
def managers(dids=()) -> dict:
    """Хто веде кожну з угод — за ОДНЕ читання реєстру звʼязків (590).

    ⛒ Поіменне питання про кожну угоду перетворило б відкриття воронки на
    сотню читань файла. Той самий прийом, що й `parties.managers`."""
    want = set(_s(x) for x in (dids or ()))
    out = {}
    try:
        L = _links()
        rows = L.all_links()
    except Exception:
        return out
    for row in rows or ():
        if _s(row.get("rel")) != L.REL_MANAGED_BY:
            continue
        frm = _s(row.get("from"))
        if entity.kind_of(frm) != entity.KIND_DEAL:
            continue
        did = entity.ident_of(frm)
        if want and did not in want:
            continue
        out[did] = _s(row.get("to") or row.get("ref"))
    return out


def _list_fields_of(did) -> dict:
    """Значення полів-списків цієї угоди: {номер поля: значення}."""
    out = {}
    try:
        import card_fields as _cf
        import card_values as _cv
        me = ref(did)
        for f in _cf.layout(entity.KIND_DEAL):
            if _s(f.get("type")) != _cf.T_LIST:
                continue
            got = _cv.value(me, f["id"])
            if got:
                out[_s(f["id"])] = got
    except Exception:
        return {}
    return out


def _tile(row: dict, mgr_ref: str = None, fields: dict = None) -> dict:
    """Плитка угоди для екрана. ⭐ Ключ плитки — НОМЕР УГОДИ, а не назва клієнта.

    ⭐ 590: плитка КАЖЕ, ХТО ВЕДЕ УГОДУ. Керівник мусить бачити це в переліку, а
    не відкриваючи кожну картку; і саме цей підпис відрізняє «мою» угоду від
    угоди колеги з тим самим клієнтом."""
    pid = client_of(row.get("id"))
    mref = manager_ref(row.get("id")) if mgr_ref is None else _s(mgr_ref)
    amt = row.get("amount") or {}
    na = row.get("next_action") or {}
    tile = {
        "id": _s(row.get("id")),
        "ref": ref(row.get("id")),
        "href": entity.screen(ref(row.get("id"))),
        "name": _s(row.get("name")),
        "stage": _s(row.get("stage")),
        "stage_id": _s(row.get("stage_id")),
        "party_id": pid,
        "client": entity.title(entity.ref(entity.KIND_PARTY, pid)) if pid else "",
        "client_href": entity.screen(entity.ref(entity.KIND_PARTY, pid)) if pid else "",
        "one_time": _s(amt.get("one_time")),
        "mrr": _s(amt.get("mrr")),
        "currency": _s(amt.get("currency")) or CURRENCY,
        "next_action": _s(na.get("text")),
        "next_date": _s(na.get("date")),
        "attention": int(row.get("attention") or 0),
        "archived": bool(row.get("archived")),
        "due": bool(due_reason(row)),
        "updated": _s(row.get("updated")),
        "manager": entity.ident_of(mref) if mref else "",
        "manager_name": entity.title(mref) if mref else "",
        # ⭐ 594: ПЛИТКА КАЖЕ, ЧОГО ВОНА. Напрям угоди видно, не відкриваючи
        # картку, — інакше відфільтрований канбан і повний виглядали б однаково.
        "fields": (_list_fields_of(row.get("id")) if fields is None
                   else dict(fields or {})),
    }
    # ⭐⭐⭐ 592: ГРОШІ — ОКРЕМА ВІСЬ, ВУЖЧА ЗА ВИДИМІСТЬ. Колега по підрозділу
    # мусить бачити, що угода Є (щоб не лізти до того самого клієнта наосліп), і
    # не мусить бачити, СКІЛЬКИ в ній. Ховаємо тут, бо це один писар форми
    # плитки: і канбан, і картка, і плитки в картці контрагента йдуть через нього.
    try:
        import entity_scope as _vs592
        return _vs592.hide_money([tile], ("one_time", "mrr"),
                                 did=_s(row.get("id")))[0]
    except Exception:
        return tile


def tiles_of_party(pid) -> list:
    """⭐ ОДИН ПИСАР ПЕРЕЛІКУ УГОД КОНТРАГЕНТА для будь-якого екрана.

    🩸 Знайдено читанням коду 15.08.2026: картка контакта брала цей перелік із
    КАРТКИ КЛІЄНТА (`crm/clients.json`). Контакт без картки-ліцензії — а це кожна
    контактна особа після B5 — показував би «угод немає», МАЮЧИ їх. Порожній
    перелік замість правди читається людиною як факт."""
    rows = deals_of_party(pid, sift=False)
    mgrs = managers([r.get("id") for r in rows])
    tiles = [_tile(r, mgrs.get(_s(r.get("id")), "")) for r in rows]
    # ⭐⭐⭐ 590: ПЕРЕЛІК ПОВНИЙ, ЧУЖІ РЯДКИ ПРИТЕМНЕНІ. Ховати чужу угоду тут
    # означало б брехати про стосунки з клієнтом: менеджер не знав би, що з
    # цією компанією вже працює колега по іншому напряму, і поліз би туди
    # наосліп. Видно назву, стадію й ХТО ВЕДЕ; грошей і наступної дії — ні.
    try:
        import entity_scope as _vs590
        return _vs590.redact(_vs590.KIND_DEAL, tiles, keep=(
            "ref", "href", "name", "stage", "party_id", "client", "client_href",
            "manager", "manager_name", "archived", "updated"))
    except Exception:
        return tiles


def _money_lines(acc: dict) -> list:
    """{валюта: [разово, щомісяця]} → рядки для екрана. Валюта без грошей не
    стає рядком «0 ₴»: порожня колонка каже «сум немає», а не нуль."""
    return [{"currency": c, "one_time": round(v[0]), "mrr": round(v[1])}
            for c, v in sorted(acc.items()) if v[0] or v[1]]


def board(field: str = "", value: str = "", include_closed: bool = False) -> dict:
    """Канбан-зріз по угодах: стадії + угоди кожної стадії + лічильники.

    ⭐⭐ 732 (побажання Каспера): колонка каже не лише СКІЛЬКИ угод, а й НА СКІЛЬКИ.
    Суму рахує той самий прохід, що кладе плитки, — тож сума колонки не може
    розійтися з її плитками. Рахуємо з ПЛИТКИ, тобто ПІСЛЯ приховування грошей
    (592): чужа сума не просочиться через суму колонки. Колонка каже, скільки
    сум їй не показано (`hidden`), — інакше часткова сума читалась би як повна.
    Валюти не складаються (431): по кожній — окремий рядок.
    ⛒ 738: колонки — стадії воронки клієнта; архівні («Успіх», «Провал») — лише на вимогу
    (`include_closed`)."""
    sts = [x for x in stages() if include_closed or x["kind"] not in DS.ARCHIVE]
    names = [x["name"] for x in sts]
    id2name = {x["id"]: x["name"] for x in sts}
    by_stage = {s: [] for s in names}
    counts = {s: 0 for s in names}
    attention = {s: 0 for s in names}
    acc = {s: {} for s in names}
    hidden = {s: 0 for s in names}
    rows = all_deals(field=field, value=value)
    rows.sort(key=lambda r: _s(r.get("name")).lower())
    mgrs = managers([r.get("id") for r in rows])
    for row in rows:
        st = id2name.get(_s(row.get("stage_id")))
        if not st:
            continue                      # архівна стадія, схована з дошки
        tile = _tile(row, mgrs.get(_s(row.get("id")), ""))
        tile["stage"] = st
        by_stage[st].append(tile)
        counts[st] += 1
        attention[st] += int(row.get("attention") or 0)
        amt = row.get("amount") or {}
        had = num(amt.get("one_time")) or num(amt.get("mrr"))
        one, mrr = num(tile.get("one_time")), num(tile.get("mrr"))
        if had and not (one or mrr):
            hidden[st] += 1
        slot = acc[st].setdefault(_s(tile.get("currency")) or CURRENCY, [0.0, 0.0])
        slot[0] += one
        slot[1] += mrr
    sums = {s: {"money": _money_lines(acc[s]), "hidden": hidden[s]} for s in names}
    return {"stages": names, "by_stage": by_stage, "counts": counts,
            "attention": attention, "sums": sums,
            "kinds": {x["name"]: x["kind"] for x in sts}, "include_closed": bool(include_closed),
            "closed": [x["name"] for x in stages() if x["kind"] in DS.ARCHIVE]}


def count_filtered(field: str = "", value: str = "") -> dict:
    """Лічильники того самого зрізу, що й дошка: одне питання — одна відповідь.

    ⛒ Окремий лічильник, який рахує ВСЮ базу, поруч із відфільтрованою дошкою
    брехав би людині просто в очі: «угод 40», а видно чотири."""
    rows = all_deals(field=field, value=value)
    live = sum(1 for r in rows if not r.get("archived"))
    return {"all": len(rows), "live": live, "archived": len(rows) - live}


def pipeline(field: str = "", value: str = "") -> dict:
    """Зведення воронки для дашборда. Рахуємо лише ЖИВІ угоди (не архів).
    Прогноз = сума × імовірність стадії."""
    live = all_deals(archived=False, field=field, value=value)
    # ⛒ 592: ВОРОНКА — ЦЕ ТЕЖ ГРОШІ. Сховати суму в картці й лишити її в
    # прогнозі означало б не сховати нічого: різниця двох прогнонів назвала б
    # чужу суму з точністю до гривні.
    try:
        import entity_scope as _vs592p
        live = _vs592p.hide_money(live, ("amount",))
    except Exception:
        pass
    amt = lambda r, k: num((r.get("amount") or {}).get(k))
    sts = stages()
    prob = lambda r: DS.prob_of(sts, r.get("stage_id"))
    # ⭐⭐⭐ 732: «СУМА УГОД У РОБОТІ» — ГОЛОВНЕ ЧИСЛО ДАШБОРДА (побажання Каспера).
    # Прогнози множать на імовірність або беруть лише угоди з датою оплати —
    # клієнтам незрозуміло, що це за гроші. Тут — просто всі живі угоди, крім
    # тих, що вже не в роботі, БЕЗ імовірностей. Гроші — після приховування
    # (592), і число каже, скільки сум йому не показано.
    work = [r for r in live if _kind(r, sts) not in DS.NOT_IN_WORK]
    w_cur = {}
    for r in work:
        c = _s((r.get("amount") or {}).get("currency")) or CURRENCY
        slot = w_cur.setdefault(c, [0.0, 0.0])
        slot[0] += amt(r, "one_time")
        slot[1] += amt(r, "mrr")
    w_lines = _money_lines(w_cur)
    w_mixed = len(w_lines) > 1
    in_work = {
        "deals": len(work),
        "hidden": len([r for r in work if r.get("amount") == ""]),
        "mixed": w_mixed,
        "currency": "" if w_mixed else (w_lines[0]["currency"] if w_lines else CURRENCY),
        "one_time": None if w_mixed else (w_lines[0]["one_time"] if w_lines else 0),
        "mrr": None if w_mixed else (w_lines[0]["mrr"] if w_lines else 0),
        "by_currency": {x["currency"]: {"one_time": x["one_time"], "mrr": x["mrr"]}
                        for x in w_lines},
    }
    sum_one = sum(amt(r, "one_time") for r in live)
    sum_mrr = sum(amt(r, "mrr") for r in live)
    w_one = sum(amt(r, "one_time") * prob(r) for r in live)
    w_mrr = sum(amt(r, "mrr") * prob(r) for r in live)
    by_stage_val = {x["name"]: {"count": 0, "one_time": 0.0, "mrr": 0.0} for x in sts}
    for r in live:
        s = DS.name_of(sts, r.get("stage_id"))
        if s not in by_stage_val:
            continue
        by_stage_val[s]["count"] += 1
        by_stage_val[s]["one_time"] += amt(r, "one_time")
        by_stage_val[s]["mrr"] += amt(r, "mrr")
    due = []
    for r in sorted(live, key=lambda x: _s(x.get("name")).lower()):
        reason = due_reason(r)
        att = int(r.get("attention") or 0)
        if reason or att:
            pid = client_of(r.get("id"))
            due.append({
                "deal": _s(r.get("id")),
                "name": _s(r.get("name")),
                "href": entity.screen(ref(r.get("id"))),
                # ⛒ 442: ТЕ САМЕ, ЩО У ВОРОНЦІ, ЗВЕТЬСЯ ТАК САМО. Тут лежить
                # назва КОНТРАГЕНТА -- це товар. Слово `customer` лишається
                # за НАШОЮ ліцензійною карткою, інакше суддя кухонних полів
                # зріже клієнтові потрібне разом із чужим.
                "client": entity.title(entity.ref(entity.KIND_PARTY, pid)) if pid else "",
                "stage": _s(r.get("stage")),
                "reason": reason or "Позначено вручну",
                "attention": att,
            })
    # ⭐⭐⭐ 431: ЧИСЛО, ЯКЕ НЕ МОЖЕ БУТИ ПРАВИЛЬНИМ, НЕ ВИДАЄТЬСЯ.
    #
    # 🩸 Доти зведення складало гривні з доларами в ОДНЕ число й підписувало
    # його валютою ПЕРШОЇ-ЛІПШОЇ живої угоди. Поки сум немає — не видно;
    # щойно в базі стають дві угоди в різних валютах, плитка починає брехати,
    # і саме тією брехнею, яку людина не має шансу помітити.
    #
    # Тому: рахуємо ПО КОЖНІЙ валюті окремо, і якщо грошові валюти не одна —
    # спільну суму не віддаємо ЗОВСІМ (None), а не показуємо «майже правду».
    by_cur = {}
    for r in live:
        c = _s((r.get("amount") or {}).get("currency")) or CURRENCY
        slot = by_cur.setdefault(c, {"one_time": 0.0, "mrr": 0.0, "deals": 0})
        slot["one_time"] += amt(r, "one_time")
        slot["mrr"] += amt(r, "mrr")
        slot["deals"] += 1
    with_money = sorted(c for c, v in by_cur.items() if v["one_time"] or v["mrr"])
    mixed = len(with_money) > 1
    by_currency = {c: {"one_time": round(v["one_time"]), "mrr": round(v["mrr"]),
                       "deals": v["deals"]}
                   for c, v in sorted(by_cur.items())}
    # Коли грошей немає ЗОВСІМ, валюту не «вгадуємо» з першої-ліпшої угоди:
    # беремо валюту платформи. Інакше підпис «0 $» стояв би над базою,
    # де майже всі угоди в гривні, — дрібна, але щоденна неправда.
    cur = with_money[0] if with_money else CURRENCY
    return {
        "deals": len(live),
        "clients": len({client_of(r.get("id")) for r in live if client_of(r.get("id"))}),
        "currency": "" if mixed else cur,
        "sum_one_time": None if mixed else round(sum_one),
        "sum_mrr": None if mixed else round(sum_mrr),
        "forecast_one_time": None if mixed else round(w_one),
        "forecast_mrr": None if mixed else round(w_mrr),
        "by_currency": by_currency,
        "mixed_currency": mixed,
        "by_stage_value": by_stage_val,
        "in_work": in_work,
        "due": due, "due_count": len(due),
        "stages": [x["name"] for x in sts],
    }


# ═══════════ ДАШБОРД КЕРІВНИКА (зміна 651, 28.09.2026) ═════════════════════
# ⭐⭐⭐ ЗАПИТ КАСПЕРА: виручка закритих угод за місяць, прогноз надходжень до
# кінця місяця з урахуванням імовірності, середній цикл угоди, «зависші» угоди
# без дій понад N днів (N задає компанія).
# ⛒ ЧИТАЧ ОДИН — ЦЕЙ. Екран нічого не рахує: він малює те, що сказано тут. Два
# місця, які рахують «виручку», за тиждень покажуть два різні числа.
# ⛒ «ЗАКРИТА» = ЗАЙШЛА НА «Активні клієнти» (імовірність 1,0): саме туди угода
# переходить після оплати, і саме ці ворота стережуть папір форми оплати.
def stale_days() -> int:
    """Скільки днів тиші робить угоду «зависшою». Задає компанія."""
    try:
        n = int((_load().get("settings") or {}).get("stale_days") or 0)
    except Exception:
        n = 0
    return n if 1 <= n <= 365 else STALE_DAYS_DEFAULT


@one_writer.guard("DEALS_JSON")
def set_stale_days(n) -> int:
    try:
        v = int(_s(n))
    except Exception:
        raise DealError("Кількість днів «%s» не число. Вкажіть ціле число від 1 до 365."
                        % _s(n))
    if not 1 <= v <= 365:
        raise DealError("Кількість днів має бути від 1 до 365, а не %d." % v)
    d = _load()
    d["settings"]["stale_days"] = v
    _save(d)
    try:
        protocol.write(protocol.A_DEAL_CHANGED, "deal:settings",
                       note="«зависла» угода — після %d днів без дій" % v)
    except Exception:
        pass
    return v


def _protocol_rows() -> list:
    try:
        return protocol.read(0)
    except Exception:
        return []


def _entered_from_protocol(rows: list) -> dict:
    """Для угод, заведених до 651 (без `stage_at`): коли вони заходили на
    стадії — з журналу. Пише цей рядок `set_stage` сам («X → Y»), тому форма
    його відома; чужого тексту тут не розбираємо."""
    out = {}
    for r in rows:
        if _s(r.get("action")) != protocol.A_DEAL_STAGE:
            continue
        subj = _s(r.get("subject"))
        if not subj.startswith("deal:"):
            continue
        note = _s(r.get("note"))
        if " → " not in note:
            continue
        st = note.split(" → ", 1)[1].strip()
        out.setdefault(subj.split(":", 1)[1], {})[st] = _s(r.get("at"))
    return out


def _last_activity(rows: list) -> dict:
    """Коли з угодою щось робили востаннє — будь-яка дія, що лягла в журнал про неї
    (стадія, документ, лист, позиція, КП). Номер угоди → час."""
    out = {}
    for r in rows:
        at = _s(r.get("at"))
        refs = [_s(r.get("subject"))] + [_s(x) for x in (r.get("about") or [])]
        for x in refs:
            if x.startswith("deal:"):
                k = x.split(":", 1)[1]
                if at > out.get(k, ""):
                    out[k] = at
    return out


def _days(a: str, b: str) -> float:
    from datetime import datetime as _dt
    try:
        return (_dt.fromisoformat(b[:19]) - _dt.fromisoformat(a[:19])).total_seconds() / 86400.0
    except Exception:
        return 0.0


def _month_end(now: str) -> str:
    import calendar
    y, m = int(now[:4]), int(now[5:7])
    return "%04d-%02d-%02d" % (y, m, calendar.monthrange(y, m)[1])


# ⭐⭐⭐ 677 (01.10.2026). ДОВІЛЬНИЙ ПЕРІОД «ВІД–ДО». Доробка Андрія 01.10.2026:
# виручки «за цей місяць» замало — керівник хоче «з ДД.ММ.РРРР по ДД.ММ.РРРР».
# ⛒ ПЕРІОД МАЄ ОДНОГО СУДДЮ (`check_period`): хибний період — відмова словами,
# порожній — з 1-го числа місяця до сьогодні.
PERIOD_MAX_DAYS = 366


def check_period(date_from: str = "", date_to: str = "") -> tuple:
    """(від, до) у вигляді РРРР-ММ-ДД, включно з обома кінцями."""
    today = _today()
    f, t = _s(date_from), _s(date_to)
    if not f and not t:
        return today[:8] + "01", today
    if not f:
        raise DealError("Скажіть, з якого дня рахувати: дата «по» без дати «з» не має "
                        "початку.")
    d1 = _check_iso_day(f, "Дата «з»")
    d2 = _check_iso_day(t, "Дата «по»") if t else today
    if d1 > d2:
        raise DealError("Дата «з» (%s) пізніша за дату «по» (%s) — поміняйте їх місцями."
                        % (_dmy(d1), _dmy(d2)))
    if d2 > today:
        raise DealError("День %s ще не настав: дашборд рахує те, що вже відбулося."
                        % _dmy(d2))
    if _days_between(d1, d2) + 1 > PERIOD_MAX_DAYS:
        raise DealError("Період задовгий: %d днів, а можна щонайбільше %d (рік)."
                        % (_days_between(d1, d2) + 1, PERIOD_MAX_DAYS))
    return d1, d2


def dashboard(field: str = "", value: str = "", date_from: str = "",
              date_to: str = "") -> dict:
    """Воронка (`pipeline`) + чотири відповіді керівникові. Усе — одним читанням."""
    p_from, p_to = check_period(date_from, date_to)   # ⛒ 677: хибний період — до роботи
    base = pipeline(field, value)
    now = clock.now()
    month, mend = now[:7], _month_end(now)
    rows = all_deals(archived=None, field=field, value=value)
    try:
        import entity_scope as _vs651
        rows = _vs651.hide_money(rows, ("amount",))
    except Exception:
        pass
    plog = _protocol_rows()
    old_entries = _entered_from_protocol(plog)
    touched = _last_activity(plog)
    amt = lambda r, k: num((r.get("amount") or {}).get(k))
    many = bool(base.get("mixed_currency"))

    sts = stages()
    won_st = [x for x in sts if x["kind"] == "won"]

    def entered(r, kind="won"):
        """⛒ 738: коли угода ВОСТАННЄ заходила на стадію з цим значенням (номери стадій; для
        угод до 651 — з журналу, за давньою назвою стадії)."""
        at = []
        for x in (won_st if kind == "won" else [y for y in sts if y["kind"] == kind]):
            at.append(_s((r.get("stage_at") or {}).get(x["id"])))
            for nm in {x.get("legacy"), x["name"]} - {None, ""}:
                at.append(_s((old_entries.get(_s(r.get("id"))) or {}).get(nm)))
        return max(at) if at else ""

    # 1. Виручка закритих угод за місяць
    won = [r for r in rows if entered(r)[:7] == month]
    rev = {"one_time": None if many else round(sum(amt(r, "one_time") for r in won)),
           "mrr": None if many else round(sum(amt(r, "mrr") for r in won)),
           "deals": len(won),
           "list": [{"deal": _s(r.get("id")), "name": _s(r.get("name")),
                     "href": entity.screen(ref(r.get("id"))),
                     "at": entered(r)[:10]} for r in won]}

    # 2. Прогноз до кінця місяця: факт + очікуване × імовірність стадії
    live = [r for r in rows if not r.get("archived")
            and _kind(r, sts) not in ("won",) + DS.NOT_IN_WORK]
    exp = [r for r in live if _s(r.get("pay_date")) and _s(r.get("pay_date")) <= mend]
    prob = lambda r: DS.prob_of(sts, r.get("stage_id"))
    nod = [r for r in live if not _s(r.get("pay_date")) and prob(r) > 0]
    w_exp = sum(amt(r, "one_time") * prob(r) for r in exp)
    fc = {"one_time": None if many else round((rev["one_time"] or 0) + w_exp),
          "fact": rev["one_time"],
          "expected": None if many else round(w_exp),
          "deals": len(exp),
          "month_end": mend,
          "no_date": {"deals": len(nod),
                      "one_time": None if many else round(sum(amt(r, "one_time") for r in nod))}}

    # 3. Середній цикл угоди: від заведення до оплати, закриті за 90 днів
    cyc_rows = []
    for r in rows:
        a = entered(r)
        if a and _days(a, now) <= 90 and _s(r.get("created")):
            cyc_rows.append(_days(_s(r.get("created")), a))
    cyc = {"days": round(sum(cyc_rows) / len(cyc_rows), 1) if cyc_rows else None,
           "deals": len(cyc_rows), "window_days": 90}

    # 4. Зависші угоди: живі, у роботі, без жодної дії понад N днів
    n = stale_days()
    st_list = []
    for r in live:
        did = _s(r.get("id"))
        last = max(_s(r.get("updated")), _s(r.get("created")), touched.get(did, ""))
        idle = _days(last, now) if last else 0
        if idle >= n:
            pid = client_of(did)
            st_list.append({
                "deal": did, "name": _s(r.get("name")),
                "href": entity.screen(ref(did)),
                "client": entity.title(entity.ref(entity.KIND_PARTY, pid)) if pid else "",
                "stage": _s(r.get("stage")),
                "idle_days": int(idle), "last": last[:10]})
    st_list.sort(key=lambda x: -x["idle_days"])

    # 5. ⭐ 676: абонплата цього місяця — очікується, виставлено, отримано; борг —
    # протерміновані оплати всіх місяців. Лише «Активні клієнти» з графіком.
    bsum = {"expected": 0.0, "invoiced": 0.0, "paid": 0.0, "debt": 0.0}
    b_deals, b_alerts = 0, []
    for r in rows:
        if (r.get("archived") or _kind(r, sts) != "won"
                or not (r.get("billing") or {}).get("on")):
            continue
        did = _s(r.get("id"))
        bst = billing_state(r)
        b_deals += 1
        for a in bst["alerts"]:
            b_alerts.append(dict(a, deal=did, name=_s(r.get("name")),
                                 href=entity.screen(ref(did))))
        if _money_hidden(did):
            continue
        for x in bst["months"]:
            v = num(x.get("amount"))
            if x["month"] == month:
                bsum["expected"] += v
                if x.get("invoiced"):
                    bsum["invoiced"] += v
                if x.get("paid"):
                    bsum["paid"] += v
            if x["state"] == B_OVERDUE:
                bsum["debt"] += v
    b_alerts.sort(key=lambda a: (a["rank"], a["month"], a["name"].lower()))
    billing = {k: (None if many else round(v)) for k, v in bsum.items()}
    billing.update({"month": month, "month_name": month_name(month),
                    "deals": b_deals, "alerts": b_alerts})

    # 6. ⭐ 677: ЗА ПЕРІОД «від–до» — виручка закритих у періоді угод, цикл,
    # заведені угоди, отримана абонплата. Ті самі правила, що й у місяці.
    def _in(day):
        return bool(day) and p_from <= day[:10] <= p_to
    p_won = [r for r in rows if _in(entered(r))]
    p_cyc = [_days(_s(r.get("created")), entered(r))
             for r in p_won if _s(r.get("created"))]
    p_paid = 0.0
    for r in rows:
        if not (r.get("billing") or {}).get("months") or _money_hidden(_s(r.get("id"))):
            continue
        for mrec in ((r.get("billing") or {}).get("months") or {}).values():
            if _in(_s((mrec or {}).get("paid"))):
                p_paid += num((mrec or {}).get("amount"))
    period = {
        "from": p_from, "to": p_to, "days": _days_between(p_from, p_to) + 1,
        "revenue": {"one_time": None if many else round(sum(amt(r, "one_time") for r in p_won)),
                    "mrr": None if many else round(sum(amt(r, "mrr") for r in p_won)),
                    "deals": len(p_won),
                    "list": [{"deal": _s(r.get("id")), "name": _s(r.get("name")),
                              "href": entity.screen(ref(r.get("id"))),
                              "at": entered(r)[:10]} for r in p_won]},
        "cycle": {"days": round(sum(p_cyc) / len(p_cyc), 1) if p_cyc else None,
                  "deals": len(p_cyc)},
        "created": sum(1 for r in rows if _in(_s(r.get("created")))),
        "billing_paid": None if many else round(p_paid),
    }
    base.update({
        "period": period,
        "billing": billing,
        "month": month,
        "revenue_month": rev,
        "forecast_month": fc,
        "cycle": cyc,
        "stale": {"days": n, "deals": st_list, "count": len(st_list)},
    })
    return base


# ── КАРТКА УГОДИ ДЛЯ ЕКРАНА ──────────────────────────────────────────────────
def card(did) -> dict:
    """Усе, що екран показує в картці угоди, — ОДНИМ читанням.

    ⭐ ЛІЦЕНЗІЯ ПРИЇЖДЖАЄ ЧИТАЧЕМ, А НЕ ДРУГИМ СХОВИЩЕМ (рішення Р9): блок
    «Ліцензія та оновлення» бере факти з `crm/clients.json` за номером
    контрагента. Угода ліцензію НЕ зберігає і НЕ править."""
    key = _s(did)
    row = get(key)
    if not row:
        return None
    out = _row(row)
    out["id"] = out["id"] or key
    out["ref"] = ref(key)
    # ⛒ Причину «потребує дії» рахуємо ДО зведення форми: вона читає СХОВИЩНУ
    # форму `next_action` (словник), якої після зведення в картці вже не буде.
    _reason = due_reason(out)
    # ⭐ 676: абонплата — тим самим читачем; гроші ховає той самий суддя, що й суму.
    _bill = billing_state(out)
    if _money_hidden(key):
        _bill = _billing_without_money(_bill)
    keep_from = _add_months(_today()[:7], -BILLING_PAST_PAID)
    _bill["months"] = [x for x in _bill["months"]
                       if x["state"] != B_PAID or x["month"] >= keep_from]
    pid = client_of(key)
    people = []
    for p in people_of(key):
        pr = entity.ref(entity.KIND_PARTY, p["party_id"])
        people.append({"party_id": p["party_id"], "ref": pr,
                       "name": entity.title(pr), "href": entity.screen(pr),
                       "note": p["note"]})
    # ⭐ C2: адресу угоди в листуванні знає ОДИН писар — `deal_mail`. Імпорт
    # локальний: на рівні модуля вийшло б коло (deal_mail читає deals).
    import deal_mail as _dm

    # ⭐⭐⭐ 429: КАРТКА — ЦЕ ТА САМА ПЛИТКА, ЩО Й У ВОРОНЦІ, ПЛЮС ДЕТАЛІ.
    #
    # 🩸 ЧОМУ ЦЕ КОРІНЬ, А НЕ ОДРУКІВКА. Досі та сама угода приїжджала на
    # екран у ДВОХ формах: у воронку — розкладена `_tile()`, у картку — зі
    # вкладеними `amount:{...}`, `next_action:{...}` і `client:{...}`. Екран,
    # написаний під першу форму, на другій малював людині «[object Object]»
    # замість клієнта й наступної дії, а рядки «Сума» і «Строк» просто
    # зникали — і жоден із 170 чеків цього не бачив, бо чек екрана читав
    # розмітку як текст. Два писарі однієї правди розійшлись.
    #
    # Тепер писар форми ОДИН — `_tile`. Картка бере його зведення й додає
    # рівно те, чого у воронці немає. Сховищну форму `amount` картка більше
    # НЕ віддає: друга проєкція тих самих грошей — це той самий другий писар.
    out.update(_tile(out))
    out.pop("amount", None)
    out["due_reason"] = _reason
    out["people"] = people
    out["license"] = license_of_party(pid)
    out["mail_token"] = _dm.token(key)
    out["stages"] = stage_names()
    out["paper_state"] = paper_state(out)
    out["billing"] = _bill
    # ⭐ 651: перелік форм оплати їде зі словника платформи — екран не має свого.
    out["pay_forms"] = [{"id": k, "name": PAY_FORMS[k]["name"],
                         "paper": PAY_FORMS[k]["paper"], "from": PAY_FORMS[k]["from"]}
                        for k in PAY_ORDER]
    return out


def license_of_party(pid) -> dict:
    """Ліцензія й канал оновлень контрагента — ЧИТАЧЕМ картки клієнта.

    ⛒ Це і є межа C1: продаж переїхав в угоду, ЛІЦЕНЗІЯ ЛИШИЛАСЬ ТАМ, ДЕ БУЛА
    (`publish_update.canon_customer` читає ту саму назву картки). Тут ми лише
    ДИВИМОСЬ на неї — жодного запису."""
    out = {"customer": "", "edition": "", "expiry": "", "version": "",
           "applied": 0, "has_key": False, "href": ""}
    p = _s(pid)
    if not p:
        return out
    try:
        import crm
        name = crm.card_of_party(p)
        if not name:
            return out
        c = crm.get_client(name) or {}
        out.update({
            "customer": name,
            "edition": _s(c.get("edition")),
            "expiry": _s(c.get("expiry")),
            "version": _s(c.get("version")),
            "applied": len(c.get("applied") or []),
            "has_key": bool(c.get("license_key")),
        })
    except Exception:
        pass
    return out
