# -*- coding: utf-8 -*-
"""tender_tape.py — СТРІЧКА ВЕРДИКТІВ СУДДІ: ЗАПИС НАЖИВО, ВІДТВОРЕННЯ ОФЛАЙН ЗА $0.

⭐⭐⭐ 25.09.2026, зміна 640. УРОК 639 (слово Андрія): «Живий прогін застосовуємо
ВИКЛЮЧНО для підтвердження того, що все добре. Я не хочу платити за твої помилки.»
🩸 Прогін 639б показав вади, які залежать від СУДДІ (модель): суддя розкрив
«Форма 1» у папір, розбив «А або Б» на кілька документів. Офлайн я їх не бачив,
бо офлайн судді немає — і кожна така вада ставала відомою лише за гроші.

⛒ ЛІКУЄМО КЛАС. Кожне слово моделі на дорозі тендерного пакета (про що перелік,
які папери в рядку і хто їх виробляє, чи це той самий папір, текст довідки) іде
через ЦЮ стрічку. Наживо (`record`) вона записує вердикт ПОРЯДКОВО — ключем є
сам рядок, який бачив суддя. Офлайн (`replay`) той самий код отримує той самий
вердикт без жодного виклику моделі. Тоді збирання пакета на справжній
документації з вердиктами справжнього судді проганяється за $0 скільки завгодно
разів — і вада судді ловиться ДО живого прогону.

⚠ ПОРЯДКОВИЙ КЛЮЧ — СВІДОМО. Після ліку коду до судді може поїхати інший набір
рядків. Незмінені рядки знайдуть свій вердикт; нові стрічка чесно назве
ПРОПУСКОМ (`misses`) — «суддя цього не бачив», а не «суддя промовчав». Пропуск
не вигадується і не підмінюється: відтворення без судді = мовчання судді.

⚠ У БОЮ СТРІЧКА ВИМКНЕНА: режим задає лише змінна `SENSFLOW_TENDER_TAPE`
(`record:<шлях>` або `replay:<шлях>`) чи проба через `set_mode`. Без неї жоден
рядок цього модуля нічого не пише й нічого не підмінює.
"""
import json
import os
import threading
from pathlib import Path

VERSION = 1
_LOCK = threading.Lock()
_STATE = {"mode": "", "path": None, "data": None, "misses": {}}


class TapeMiss(Exception):
    """Відтворення: стрічка не знає відповіді на це питання (суддя цього не бачив)."""


def _empty() -> dict:
    return {"version": VERSION, "verdicts": {}, "calls": {}, "ctx": {}, "note": ""}


def _from_env():
    raw = os.environ.get("SENSFLOW_TENDER_TAPE", "").strip()
    if not raw or ":" not in raw:
        return
    m, p = raw.split(":", 1)
    m = m.strip().lower()
    if m in ("record", "replay") and p.strip():
        set_mode(m, p.strip())


def set_mode(mode: str, path=None, data=None):
    """Увімкнути стрічку. mode: "" | "record" | "replay"."""
    with _LOCK:
        _STATE["mode"] = mode if mode in ("record", "replay") else ""
        _STATE["path"] = Path(path) if path else None
        _STATE["misses"] = {}
        if data is not None:
            _STATE["data"] = data
        elif _STATE["mode"] == "replay" and _STATE["path"] and _STATE["path"].is_file():
            _STATE["data"] = json.loads(_STATE["path"].read_text(encoding="utf-8"))
        else:
            _STATE["data"] = _empty()
        for k, v in _empty().items():
            _STATE["data"].setdefault(k, v)


def mode() -> str:
    return _STATE["mode"]


def data() -> dict:
    return _STATE["data"] or _empty()


def misses() -> dict:
    return {k: list(v) for k, v in _STATE["misses"].items()}


def _save():
    p = _STATE["path"]
    if _STATE["mode"] != "record" or not p:
        return
    try:
        import one_writer                  # один писар підміни файла (терплячий на Windows)
        one_writer.write_json(p, _STATE["data"], indent=1)
    except Exception:
        pass                      # стрічка — свідок, а не учасник: її зрив роботу не валить


# ── ПОРЯДКОВІ ВЕРДИКТИ (про що перелік; папери рядка; той самий папір) ─────────
def put(kind: str, key: str, value):
    if _STATE["mode"] != "record":
        return
    with _LOCK:
        _STATE["data"]["verdicts"].setdefault(kind, {})[str(key)] = value
        _save()


def get(kind: str, key: str):
    """-> (є_запис, значення). Запису немає — це ПРОПУСК, і він рахується."""
    got = (data().get("verdicts") or {}).get(kind) or {}
    if str(key) in got:
        return True, got[str(key)]
    with _LOCK:
        _STATE["misses"].setdefault(kind, []).append(str(key))
    return False, None


# ── ВИКЛИКИ З ТЕКСТОМ (текст довідки): записуємо СИРУ відповідь моделі ──────────
def wrap_call(kind: str, key: str, fn):
    """Обгортка виклику моделі. record: кличе й пише сиру відповідь; replay:
    віддає записані відповіді в тому самому порядку, без жодного виклику."""
    m = _STATE["mode"]
    if not m:
        return fn
    if m == "record":
        def _rec(*a, **k):
            out = fn(*a, **k)
            with _LOCK:
                _STATE["data"]["calls"].setdefault(kind, {}).setdefault(str(key), []).append(out)
                _save()
            return out
        return _rec
    seq = list(((data().get("calls") or {}).get(kind) or {}).get(str(key)) or [])

    def _rep(*a, **k):
        if not seq:
            with _LOCK:
                _STATE["misses"].setdefault(kind, []).append(str(key))
            raise TapeMiss("%s: %s" % (kind, key))
        return seq.pop(0)
    return _rep


# ── КОНТЕКСТ ПРОГОНУ (матеріал, задача, переказ читача, рішення про товар…) ────
def put_ctx(name: str, value):
    if _STATE["mode"] != "record":
        return
    with _LOCK:
        _STATE["data"]["ctx"][name] = value
        _save()


def ctx(name: str, default=None):
    return (data().get("ctx") or {}).get(name, default)


def save_as(path):
    """Записати поточну стрічку в інший файл (проба кладе її у фікстури)."""
    import one_writer
    p = Path(path)
    one_writer.write_json(p, data(), indent=1)
    return p


_from_env()
