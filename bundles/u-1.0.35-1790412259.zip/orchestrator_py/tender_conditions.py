# -*- coding: utf-8 -*-
"""
tender_conditions.py — УМОВНУ ВИМОГУ ВИРІШУЮТЬ ФАКТИ УЧАСНИКА (25.09.2026, зміна 644).

🩸 КОРІНЬ. Каспер, UA-2026-09-21-015529-A, живий прогін 643 проти ручного еталона. Замовник
пише частину вимог умовою: «Довіреність (у разі якщо інтереси Учасника представляє не
керівник)», «1.5. У разі, якщо пропозиція подається об’єднанням…», «9.1. … Подається, якщо
вартість закупівлі … перевищує 20 мільйонів», «У разі якщо Учасник не є платником ПДВ або
єдиного податку … надати лист». Платформа ЗНАЛА відповідь на кожну умову — керівник у картці,
учасник один, вартість 955 000 грн, платник єдиного податку, — і все одно:
  · поклала в пакет лист «пояснення щодо податків» платника єдиного податку, витяг якого
    лежить у тому ж пакеті (лист, що суперечить сам собі);
  · вимагала «додати» довіреність, документ об'єднання, антикорупційну програму;
  · не склала того, що склав тендерист: «Довідку щодо умовних вимог» — одним аркушем
    пояснити замовнику, чому цих паперів у пропозиції немає;
  · на «4.1. Копія ліцензії … Якщо отримання ліцензії не передбачено законодавством —
    лист-роз’яснення в довільній формі» сказала «додає учасник» — а для одягу ліцензії не
    буває, і тендерист пише саме лист.

⛒ ЗАКОН 644.
  1. Умова вимоги — властивість РЕЧЕННЯ замовника (одна писарка: `tender_skeleton.condition_of`).
  2. Умову вирішує лише ФАКТ, який платформа має з джерела: картка учасника (керівник,
     податковий статус), досьє (власний статут), картка закупівлі або оголошення (вартість).
     Немає факту — умова лишається людині («Умовна вимога», як і досі). Вгадувань немає.
  3. Папір, чия умова учасника НЕ стосується, не пишеться і не «додається»: він названий
     окремим службовим розділом, а замовнику пояснено одним документом платформи —
     «Довідкою щодо умовних вимог» (текст складає КОД із тих самих фактів, $0).
  4. Папір з альтернативою «якщо … не передбачено — лист-роз’яснення в довільній формі»
     без файла в досьє — це ЛИСТ, який пише платформа; файл у досьє є — вкладається файл.
ЧОГО МОДУЛЬ НЕ РОБИТЬ: не ходить у мережу, не кличе модель, не тлумачить закон.
"""

import re

CERT_TITLE = "Довідка щодо умовних вимог"
NOT_MINE_HEAD = "УМОВНІ ВИМОГИ, ЯКІ ВАС НЕ СТОСУЮТЬСЯ"

# ── ВИДИ УМОВ, ЯКІ ВИРІШУЄ ФАКТ ─────────────────────────────────────────────────
# Вид упізнається за ФОРМОЮ речення замовника; вирішує його лише факт.
_SIGNER = re.compile(r"не\s+керівник|іншою\s+особою|не\s+директор", re.I)
_CONSORT = re.compile(r"об[’'ʼ`]?єднанн\w*\s+учасник", re.I)
_MODEL = re.compile(r"модельн\w+\s+статут", re.I)
_VALUE = re.compile(r"вартість\s+закупівлі[^.;]{0,60}?(?:дорівнює\s+чи\s+перевищує|дорівнює\s+або\s+перевищує"
                    r"|перевищує|більш\w*\s+(?:ніж|за))\s+(\d+(?:[.,]\d+)?)\s*(мільйон\w*|млн)", re.I)
_TAX = re.compile(r"не\s+є\s+платником\s+(?:податку\s+на\s+додану\s+вартість|пдв)\s+(?:або|чи)\s+єдиного\s+податку",
                  re.I)
_LETTER_ALT = re.compile(r"(?:не\s+передбачено|не\s+вимагається|відсутн\w*|не\s+потребує)[^.;]{0,200}?"
                         r"\bлист\w*|\bлист\w*[-\s]роз[’'ʼ`]?ясненн\w*|\bлист\w*[-\s]поясненн\w*", re.I)


def _money(text) -> float:
    """«955 000,00 грн» -> 955000.0; не число — 0."""
    t = re.sub(r"[\s  ]", "", str(text or "")).replace(",", ".")
    m = re.match(r"^(\d+(?:\.\d+)?)", t)
    try:
        return float(m.group(1)) if m else 0.0
    except ValueError:
        return 0.0


_VALUE_IN_DOC = re.compile(r"очікуван\w+\s+вартість[^:\n]{0,60}:\s*([\d\s  ]+(?:[.,]\d{2})?)\s*грн", re.I)


def expected_value(facts: dict, material: str = "") -> float:
    """Очікувана вартість закупівлі: картка Прозорро (`amount`), інакше оголошення замовника."""
    v = _money((facts or {}).get("amount"))
    if v > 0:
        return v
    m = _VALUE_IN_DOC.search(str(material or ""))
    return _money(m.group(1)) if m else 0.0


def _grn(v: float) -> str:
    whole = "{:,.2f}".format(v).replace(",", " ").replace(".", ",")
    return "%s грн" % whole


def kind_of(sentence: str) -> str:
    s = str(sentence or "")
    if _TAX.search(s):
        return "tax"
    if _VALUE.search(s):
        return "value"
    if _MODEL.search(s):
        return "model_statute"
    if _CONSORT.search(s):
        return "consortium"
    if _SIGNER.search(s):
        return "signer"
    return ""


def resolve(sentence: str, req: dict, facts: dict = None, dossier=None, material: str = "") -> dict:
    """Умова речення замовника -> {"kind", "applies": True/False/None, "why"}.

    `applies=None` — факту немає: умову вирішує людина. `why` — речення від імені учасника,
    складене лише з фактів, які платформа має (картка, досьє, закупівля)."""
    req, facts = req or {}, facts or {}
    k = kind_of(sentence)
    out = {"kind": k, "applies": None, "why": ""}
    if not k:
        return out
    name = _short(req)
    if k == "signer":
        director = re.sub(r"\s+", " ", str(req.get("director") or "")).strip()
        if director:
            post = str(req.get("director_post") or "директор").strip().lower()
            out.update(applies=False, why="Пропозицію та договір про закупівлю підписує керівник "
                                          "учасника — %s %s." % (post, director))
    elif k == "consortium":
        if name:
            out.update(applies=False, why="Пропозицію подає %s самостійно, а не об’єднання учасників." % name)
    elif k == "model_statute":
        own = [e for e in (dossier or []) if e.get("type") == "статут" and e.get("kind") == "постійний"]
        if own and name:
            out.update(applies=False, why="%s діє на підставі власного Статуту (у складі пропозиції — «%s»), "
                                          "а не модельного статуту." % (name, own[0].get("file")))
    elif k == "value":
        m = _VALUE.search(sentence)
        lim = _money(m.group(1)) * 1_000_000 if m else 0.0
        val = expected_value(facts, material)
        if lim and val:
            if val < lim:
                out.update(applies=False, why="Очікувана вартість закупівлі — %s, менша за %s мільйонів "
                                              "гривень." % (_grn(val), m.group(1)))
            else:
                out.update(applies=True, why="Очікувана вартість закупівлі — %s." % _grn(val))
    elif k == "tax":
        ts = str(req.get("tax_status") or "").strip()
        low = ts.lower()
        if ts:
            if "єдиного податку" in low or re.search(r"\bплатник\s+пдв\b", low):
                has = [e for e in (dossier or []) if e.get("type") == "витяг платника податку"
                       and e.get("kind") == "постійний"]
                out.update(applies=False, why="%s — %s%s." % (
                    name or "Учасник", ts,
                    ("; витяг з реєстру платників податку («%s») — у складі пропозиції" % has[0].get("file"))
                    if has else ""))
            else:
                out.update(applies=True, why="Податковий статус учасника: %s." % ts)
    return out


def _short(req) -> str:
    try:
        import tender_fill
        return tender_fill.short_legal_name((req or {}).get("name") or "")
    except Exception:
        return str((req or {}).get("name") or "")


def letter_alternative(requirement: str) -> bool:
    """Чи дає замовник замість паперу лист-роз’яснення («якщо … не передбачено — лист»)."""
    return bool(_LETTER_ALT.search(str(requirement or "")))


# ── НОМЕР ПУНКТУ — ЛИШЕ З РЯДКА ЗАМОВНИКА ───────────────────────────────────────
_LEAD_NO = re.compile(r"^\s*(\d{1,2}(?:\.\d{1,2})+)\.?\s")
_TAIL_NO = re.compile(r"(Форм[аиі]\s*№?\s*\d+)\s*,\s*п\.\s*(\d{1,2}(?:\.\d{1,2})+)", re.I)


def clause_ref(row: str) -> str:
    """«п. 1.5» / «п. 1.2 Форми 1» — лише як написано в рядку замовника; немає — ""."""
    t = str(row or "")
    m = _TAIL_NO.search(t)
    if m:
        form = re.sub(r"\s+", " ", m.group(1)).strip()
        form = re.sub(r"^Форм[аиі]", "Форми", form, flags=re.I)
        return "п. %s %s" % (m.group(2), form)
    m = _LEAD_NO.match(t)
    return ("п. %s" % m.group(1)) if m else ""


# ── РІШЕННЯ НА ВЕСЬ ПАКЕТ ────────────────────────────────────────────────────────
def decide(checklist, makers, req: dict, facts: dict = None, dossier=None, material: str = "") -> dict:
    """Один раз на пакет. Кладе в `makers` (той самий вердикт, що протягується всюди):
      makers["not_needed"] = {позиція: {"cond", "why", "kind"}}  — папір не потрібен;
      makers["cond_lines"] = [{"kind", "why", "ref", "paper"}]     — рядки Довідки;
      makers["letter_for"] = {позиція: True}                       — пише лист-роз’яснення;
      makers["maker_of"][позиція] = "система" для листа-альтернативи.
    -> {"not_needed": n, "lines": n, "letters": n}"""
    import tender_skeleton as _ts
    if not isinstance(makers, dict):
        return {"not_needed": 0, "lines": 0, "letters": 0}
    nn = makers.setdefault("not_needed", {})
    lines = makers.setdefault("cond_lines", [])
    letters = makers.setdefault("letter_for", {})
    mo = makers.setdefault("maker_of", {})
    seen = {ln["kind"] for ln in lines}
    for it in checklist or []:
        own = _ts.item_condition(it, makers)
        row = _ts.requirement_text(it, makers)
        if own:
            r = resolve(own, req, facts, dossier, material)
            if r["applies"] is False:
                nn[it] = {"cond": own, "why": r["why"], "kind": r["kind"]}
                if r["kind"] not in seen:
                    seen.add(r["kind"])
                    lines.append({"kind": r["kind"], "why": r["why"], "ref": clause_ref(row),
                                  "paper": _ts.title_of(it), "given": _ts.name_given(it, makers)})
        # умови, що живуть в ІНШИХ реченнях рядка (1.3: «У випадку, якщо … модельного статуту»)
        for s in _ts.sentences_of(row):
            c = _ts.condition_of(s)
            if not c:
                continue
            r = resolve(c, req, facts, dossier, material)
            if r["applies"] is False and r["kind"] not in seen:
                seen.add(r["kind"])
                lines.append({"kind": r["kind"], "why": r["why"], "ref": clause_ref(row), "paper": ""})
        if it not in nn and letter_alternative(row) and not _ts.dossier_files(it, dossier) \
                and not _ts.issued_by_state(it):
            letters[it] = True
            mo[it] = "система"
            _lb = letter_body(it, makers, req, facts)
            if _lb:
                makers.setdefault("letter_body", {})[it] = _lb
    if lines:
        mo[CERT_TITLE] = "система"
    return {"not_needed": len(nn), "lines": len(lines), "letters": len(letters)}


# ⭐ 644: ТЕКСТ ЛИСТА-РОЗ’ЯСНЕННЯ — КОД, СЛОВАМИ САМОГО ЗАМОВНИКА. Підставу («отримання ліцензії …
# не передбачено законодавством України») замовник уже написав у своїй вимозі; учасник лише
# підтверджує її щодо свого предмета. Закону код не тлумачить і статей не вигадує; чи справді
# ліцензія не потрібна — вирішує людина (розділ каже: є ліцензія — вкладіть її замість листа).
_REASON = re.compile(r"\b(?:якщо|у\s+разі,?\s+якщо|у\s+випадку,?\s+якщо)\s+([^,.;]*?(?:не\s+передбачен\w*|"
                     r"не\s+вимагаєтьс\w*)[^,.;]*)", re.I)


def letter_body(item, makers, req: dict, facts: dict = None) -> str:
    import tender_skeleton as _ts
    m = _REASON.search(_ts.requirement_text(item, makers))
    if not m:
        return ""
    reason = re.sub(r"\s+на\s+провадження\s+(?:певного\s+)?виду\s+(?:господарської\s+)?діяльності", "",
                    m.group(1).strip(), flags=re.I)
    facts = facts or {}
    name = str((req or {}).get("name") or "Учасник").strip()
    ed = str((req or {}).get("edrpou") or "").strip()
    tid = str(facts.get("tender_id") or "").strip()
    subj = str(facts.get("subject") or "").strip()
    return ("%s%s, учасник закупівлі%s%s, повідомляє, що не надає у складі пропозиції %s, оскільки %s%s."
            % (name, (" (код ЄДРПОУ %s)" % ed) if ed else "", (" %s" % tid) if tid else "",
               (" «%s»" % subj) if subj else "",
               _paper_words(_ts.title_of(item), _ts.name_given(item, makers),
                            clause_ref(_ts.requirement_text(item, makers))),
               ("для постачання предмета закупівлі «%s» " % subj) if subj else "", reason))


def letter_bodies(makers) -> dict:
    """{позиція: текст листа-роз’яснення}, складений `decide` (код, $0)."""
    return dict((makers or {}).get("letter_body") or {})


def not_needed(item, makers) -> dict:
    return ((makers or {}).get("not_needed") or {}).get(str(item)) or {}


def is_letter_alt(item, makers) -> bool:
    return bool(((makers or {}).get("letter_for") or {}).get(str(item)))


# ⭐⭐ 645б: НАЗВА ПАПЕРУ В ЛИСТІ ЗАМОВНИКУ — З ФАКТУ, А НЕ З ТЕКСТУ. 🩸 Без судді заголовок
# пункту — це шматок речення замовника («У разі якщо Учасник не є платником…»), і в Довідці він
# читався як «Тому документ «У разі якщо…» не надається». Перша спроба (645) судила ТЕКСТ назви
# («якщо/у разі», довжина 90) — вгадування. Тепер вирішує ФАКТ: назву дав суддя
# (`tender_skeleton.name_given`) — вона стоїть у листі; не давав — загальні слова з номером пункту.
_GENERIC_PAPER = "документ, який замовник вимагає за цією умовою"


def _paper_words(title: str, given: bool = False, ref: str = "") -> str:
    """Назву дано: «Документ про створення …» -> «документ про створення …», інша — «документ «…»».
    Назви не дано: «документ, який замовник вимагає за п. 4.1» / «… за цією умовою» (645б)."""
    t = str(title or "").strip()
    if not (t and given):
        return ("документ, який замовник вимагає за %s" % ref) if ref else _GENERIC_PAPER
    if re.match(r"^документ\b", t, re.I):
        return t[:1].lower() + t[1:]
    return "документ «%s»" % t


def certificate_body(makers, req: dict, facts: dict = None) -> str:
    """Текст «Довідки щодо умовних вимог» — КОД, лише з фактів рішень. Нема рядків — ""."""
    lines = list((makers or {}).get("cond_lines") or [])
    if not lines:
        return ""
    facts = facts or {}
    name = str((req or {}).get("name") or "Учасник").strip()
    ed = str((req or {}).get("edrpou") or "").strip()
    tid = str(facts.get("tender_id") or "").strip()
    subj = str(facts.get("subject") or "").strip()
    head = "%s%s, учасник закупівлі%s%s, повідомляє:" % (
        name, (" (код ЄДРПОУ %s)" % ed) if ed else "", (" %s" % tid) if tid else "",
        (" «%s»" % subj) if subj else "")
    out = [head, ""]
    for n, ln in enumerate(lines, 1):
        _given = bool(ln.get("given"))
        tail = ("Тому %s%s не надається" % (_paper_words(ln["paper"], _given), "" if _given else ",")) \
            if ln.get("paper") else \
            "Тому документ, який замовник вимагає за цією умовою, не надається"
        out.append("%d. %s %s%s." % (n, ln["why"], tail, (" (%s)" % ln["ref"]) if ln.get("ref") else ""))
    return "\n".join(out)
