# -*- coding: utf-8 -*-
"""tender_word.py — ТЕНДЕРНИЙ ПАКЕТ ОДНИМ ФАЙЛОМ WORD.

⭐⭐⭐ 24.09.2026, зміна 636 (клас Е). Прохання Олександри (Каспер): «увесь пакет —
ОДИН файл Word, а не десятки файлів». Платформа ж віддавала ~50 посилань: зведений
аркуш, кожен документ окремо в .md і .docx, і все — з логотипом SensFlow у шапці.

⛒ ЗАКОН ЦЬОГО МОДУЛЯ:
  1. ОДИН .docx: реєстр пакета першим → кожен документ із нової сторінки →
     документи з досьє учасника (скани) сторінками-картинками з підписом, що це.
  2. Листи — на БЛАНКУ КЛІЄНТА (картинка з його `Бланк.docx`). Бланка немає —
     нейтральна шапка з картки учасника. Логотипа SensFlow тут не буває НІКОЛИ:
     це документ клієнта, а не наш звіт.
  3. Рендер сторінок PDF потребує бібліотеки (`pypdfium2` + Pillow). Її немає —
     пакет усе одно ОДИН Word, а на місці скану чесна сторінка-замінник
     «додається файлом: 1. Статут.pdf, 13 стор., від ДД.ММ.РРРР».
  4. Окремі файли для завантаження на Прозорро — лише на прохання людини
     («розклади по файлах», `SPLIT_ASK`).
"""

import io
import os
import re
import zipfile

import origin

SPLIT_ASK = "розклади по файлах"
_SPLIT_MARKS = (SPLIT_ASK, "розклади на файли", "окремими файлами", "по окремих файлах",
                "розбий на файли", "кожен документ окремо", "кожен документ окремим")

RENDER_DPI = 110
JPEG_QUALITY = 72
BODY_WIDTH_CM = 17.0
BODY_HEIGHT_CM = 24.0          # сторінка скану + підпис уміщаються на одному аркуші A4


def wants_split(text) -> bool:
    low = str(text or "").lower()
    return any(m in low for m in _SPLIT_MARKS)


def renderer_available() -> bool:
    try:
        import pypdfium2  # noqa: F401
        from PIL import Image  # noqa: F401
        return True
    except Exception:
        return False


def blank_image(blank_path) -> bytes:
    """Картинка фірмового бланка з `Бланк.docx` клієнта (перша картинка документа)."""
    if not blank_path or not os.path.exists(str(blank_path)):
        return b""
    try:
        with zipfile.ZipFile(str(blank_path)) as z:
            names = sorted(n for n in z.namelist() if n.startswith("word/media/"))
            return z.read(names[0]) if names else b""
    except Exception:
        return b""


def _render_pages(path: str):
    """-> [jpeg bytes] по сторінці. Помилка -> [] (тоді сторінка-замінник)."""
    # ⭐ 639: документ і кожну сторінку ЗАКРИВАЄМО. 🩸 Живий прогін 638: pypdfium2
    # на виході лишав відкритими три скани — на Windows відкритий файл = замок
    # (клієнт не перейменує й не видалить скан, доки служба жива).
    pdf = None
    try:
        import pypdfium2 as pdfium
        pdf = pdfium.PdfDocument(path)
        out = []
        for i in range(len(pdf)):
            page = pdf[i]
            try:
                img = page.render(scale=RENDER_DPI / 72.0).to_pil().convert("RGB")
            finally:
                try:
                    page.close()
                except Exception:
                    pass
            buf = io.BytesIO()
            img.save(buf, "JPEG", quality=JPEG_QUALITY, optimize=True)
            out.append(buf.getvalue())
        return out
    except Exception:
        return []
    finally:
        if pdf is not None:
            try:
                pdf.close()
            except Exception:
                pass


def placeholder_text(att: dict) -> str:
    bits = [str(att.get("file") or "документ")]
    if att.get("pages"):
        bits.append("%d стор." % int(att["pages"]))
    if att.get("date"):
        bits.append("від %s" % att["date"])
    return "додається файлом: " + ", ".join(bits)


# ─────────────────────────── простий markdown -> Word ──────────────────────────
_INLINE = re.compile(r"(\*\*[^*]+\*\*|`[^`]+`)")


def _runs(par, text, bold=False, italic=False):
    for part in _INLINE.split(str(text or "")):
        if not part:
            continue
        b = bold
        if part.startswith("**") and part.endswith("**") and len(part) > 4:   # «***» замовника — текст
            part, b = part[2:-2], True
        elif part.startswith("`") and part.endswith("`"):
            part = part[1:-1]
        r = par.add_run(part)
        r.bold = b
        r.italic = italic


def _table(document, rows):
    cells = [[c.strip() for c in r.strip().strip("|").split("|")] for r in rows]
    cells = [r for r in cells if not all(set(c) <= set("-: ") for c in r)]
    if not cells:
        return
    n = max(len(r) for r in cells)
    t = document.add_table(rows=len(cells), cols=n)
    try:
        t.style = "Table Grid"
    except Exception:
        pass
    for i, r in enumerate(cells):
        for j in range(n):
            cell = t.cell(i, j)
            cell.text = ""
            # 643: клітинка бланка на кілька рядків («Постачальник:<br>назва<br>код…»)
            parts = re.split(r"<br\s*/?>", r[j] if j < len(r) else "")
            _runs(cell.paragraphs[0], parts[0], bold=(i == 0))
            for extra in parts[1:]:
                _runs(cell.add_paragraph(), extra)


def _md_block(document, md: str, skip_requisites: bool = False):
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    import artifacts as _arts                  # 645б: машинна позначка не друкується ніколи
    lines = [ln for ln in str(md or "").replace("\r\n", "\n").split("\n") if not _arts.is_machine_mark(ln)]
    if skip_requisites:
        # на бланку клієнта реквізити вже є картинкою — шапку з картки не дублюємо
        for k, ln in enumerate(lines):
            if ln.strip().startswith("Вих. №"):
                lines = lines[k:]
                break
    i = 0
    while i < len(lines):
        ln = lines[i].rstrip()
        s = ln.strip()
        if not s or s == "---":
            i += 1
            continue
        if s.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                rows.append(lines[i])
                i += 1
            _table(document, rows)
            continue
        p = _mark_new_page(document, document.add_paragraph())
        m = re.match(r"^(#{1,6})\s+(.*)$", s)
        if m:
            _runs(p, m.group(2), bold=True)
            if len(m.group(1)) >= 3:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        elif s.startswith(">"):
            _runs(p, s.lstrip("> ").strip(), italic=True)
        elif s.startswith(("- ", "• ")):
            _runs(p, "• " + s[2:])
        elif s.startswith("Відповідальній особі"):
            _runs(p, s)
            p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        else:
            _runs(p, s)
        i += 1


def _page_break(document):
    """Розрив сторінки БЕЗ порожнього рядка зверху нової сторінки: наступний абзац
    сам починає нову сторінку (інакше скан на всю висоту переповзає на другий аркуш)."""
    _NEXT_PAGE[id(document)] = True


_NEXT_PAGE = {}


def _mark_new_page(document, par):
    if _NEXT_PAGE.pop(id(document), False):
        par.paragraph_format.page_break_before = True
    return par


def _picture(document, data: bytes, max_w_cm: float, max_h_cm: float):
    """Картинка, вписана і в ширину, і у висоту сторінки."""
    from docx.shared import Cm
    w = max_w_cm
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(data))
        ratio = im.size[1] / float(im.size[0] or 1)
        if w * ratio > max_h_cm:
            w = max_h_cm / ratio
    except Exception:
        pass
    document.add_picture(io.BytesIO(data), width=Cm(w))
    return _mark_new_page(document, document.paragraphs[-1])


def build(out_path, documents, registry_md: str = "", attachments=None,
          blank_path=None, render=None) -> dict:
    """ОДИН .docx пакета. -> {"path", "documents", "inserted": [файли], "placeholders": [файли]}.

    `render`: None — сам вирішує за наявністю бібліотеки; False — лише замінники;
    True — рендерить (бібліотеки немає — замінник, і це видно в "placeholders")."""
    import docx
    from docx.shared import Cm, Pt
    document = docx.Document()
    try:
        st = document.styles["Normal"]
        st.font.name = "Times New Roman"
        st.font.size = Pt(12)
        sec = document.sections[0]
        sec.left_margin, sec.right_margin = Cm(2.5), Cm(1.5)
        sec.top_margin, sec.bottom_margin = Cm(1.5), Cm(1.5)
    except Exception:
        pass
    img = blank_image(blank_path)
    out = {"path": str(out_path), "documents": 0, "inserted": [], "placeholders": []}

    # 1) реєстр пакета — першою сторінкою
    reg = str(registry_md or "").strip()
    if reg:
        _md_block(document, reg)
    else:
        document.add_paragraph().add_run("РЕЄСТР ПАКЕТА").bold = True

    use_render = renderer_available() if render is None else bool(render)

    def _scan(att):
        """Файл із досьє: сторінки-картинки з підписом або чесна сторінка-замінник."""
        _page_break(document)
        name = str(att.get("file") or "")
        pages = _render_pages(att.get("path") or "") if (use_render and renderer_available()) else []
        if pages:
            for k, jpg in enumerate(pages, 1):
                if k > 1:
                    _page_break(document)
                _picture(document, jpg, BODY_WIDTH_CM, BODY_HEIGHT_CM)
                cap = document.add_paragraph()
                cap.add_run("%s — стор. %d з %d" % (name, k, len(pages))).italic = True
            out["inserted"].append(name)
        else:
            p = _mark_new_page(document, document.add_paragraph())
            p.add_run(placeholder_text(att)).bold = True
            out["placeholders"].append(name)

    # Файли досьє, прив'язані до документа пакета (`for` = назва документа), стають
    # НА ЙОГО МІСЦЕ — як у тендериста: статут іде сканом статуту, а не сторінкою
    # «документ є в досьє». Неприв'язані — наприкінці.
    by_doc = {}
    for att in attachments or []:
        by_doc.setdefault(str(att.get("for") or ""), []).append(att)

    # 2) кожен документ — з нової сторінки, лист — на бланку клієнта
    for d in documents or []:
        title = str((d or {}).get("title") or "").strip()
        body = str((d or {}).get("body") or "").strip()
        if not (title or body):
            continue
        mine = by_doc.pop(title, []) if title else []
        if mine:
            warn = [ln.lstrip("> ").strip() for ln in body.splitlines() if ln.lstrip("> ").startswith("⚠")]
            for i, att in enumerate(mine):
                if i == 0 and warn:
                    _page_break(document)
                    p = _mark_new_page(document, document.add_paragraph())
                    _runs(p, title, bold=True)
                    for w in warn:
                        _runs(document.add_paragraph(), w, italic=True)
                _scan(att)
            out["documents"] += 1
            continue
        _page_break(document)
        # ⭐⭐⭐ 644: ЛИСТ ЗАМОВНИКУ — лише те, що після мітки. Службове для людини («Підстава
        # вимоги», «якщо документ у вас є…») лишається в .md і в Word не друкується.
        import tender_skeleton as _tsk        # один писар мітки — tender_skeleton
        _lm = body.find(_tsk.LETTER_MARK)
        if _lm >= 0:
            body = body[_lm + len(_tsk.LETTER_MARK):].strip()
        is_letter = "Вих. №" in body
        # ⭐⭐⭐ 643: БЛАНК ЗАМОВНИКА друкується САМ — без нашої назви, підстави й приміток
        # для людини (замовник: «Учасник не повинен відступати від даної форми»). На
        # фірмовому бланку клієнта — коли цього вимагає сам бланк.
        bm = re.search(r"<!--\s*БЛАНК ЗАМОВНИКА\b([^>]*)-->", body)
        if bm:
            if img and "фірмовий бланк" in bm.group(1):
                _picture(document, img, BODY_WIDTH_CM, 6.0)
            _md_block(document, body[bm.end():])
            out["documents"] += 1
            continue
        if is_letter and img:
            _picture(document, img, BODY_WIDTH_CM, 6.0)
        if not is_letter:
            # у листа назва вже стоїть у його тілі («ДОВІДКА / щодо …»)
            p = _mark_new_page(document, document.add_paragraph())
            _runs(p, title, bold=True)
        _md_block(document, body, skip_requisites=bool(is_letter and img))
        out["documents"] += 1

    # 3) файли досьє без прив'язки до документа — наприкінці
    for key in list(by_doc):
        for att in by_doc.pop(key):
            _scan(att)

    os.makedirs(os.path.dirname(os.path.abspath(str(out_path))), exist_ok=True)
    document.save(str(out_path))
    origin.stamp(str(out_path))      # закон платформи: жоден документ повз писаря походження
    return out


def registry_of(pack_md: str) -> str:
    """Розділ «РЕЄСТР ПАКЕТА» зі зведеного пакета (його пише `tender_skeleton`)."""
    md = str(pack_md or "")
    m = re.search(r"(?ms)^##\s+РЕЄСТР ПАКЕТА\s*$(.*?)(?=^##\s|\Z|^---\s*$)", md)
    if not m:
        return ""
    # ⭐ 645б: замовнику — ЛИШЕ ТАБЛИЦЯ реєстру. Примітка під нею («⚠ Виробника визначено
    # словником… перевірте») адресована учаснику і друкувалась у Word замовнику першою сторінкою.
    rows = [ln for ln in m.group(1).strip().splitlines() if ln.strip().startswith("|")]
    return "## РЕЄСТР ПАКЕТА\n" + "\n".join(rows)
