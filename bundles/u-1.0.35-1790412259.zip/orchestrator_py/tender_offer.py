# -*- coding: utf-8 -*-
"""tender_offer.py — ЯКИЙ ТОВАР ПРОПОНУЄМО В ТЕНДЕРІ.

⭐⭐⭐ 24.09.2026, зміна 636 (клас Г). 🩸 Каспер, UA-2026-09-21-015529-A: платформа
написала документи ВІД ІМЕНІ КАСПЕРА про товар КОНКУРЕНТА (LAPA-Gear Ghilli V6),
бо той стояв у назві закупівлі, — і ніхто її не спитав. Справжній тендерист часто
пропонує СВІЙ товар (Casper Camo) як еквівалент і доводить це таблицею
відповідності; на питання «завжди?» відповів: «не завжди».

⛒ ЗАКОН: це рішення ЛЮДИНИ, і ставиться воно ДО збірки пакета, одним питанням.
Кандидати «свого» беруться ЛИШЕ з бази товарів клієнта (`goods`) — одного
верифікованого місця; товар із назви закупівлі нашим кандидатом не стає ніколи.
Відповідь «не знаю» — не стоп: пакет збирається, графи товару лишаються учасникові.
"""

import re

MODE_NAMED = "named"
MODE_OWN = "own"
MODE_UNKNOWN = "unknown"

_UNKNOWN = ("не знаю", "не впевнен", "ще не виріш", "пізніше виріш", "поки не знаю", "без товару")
_NAMED = ("той, що в тендері", "той що в тендері", "як у тендері", "як в тендері", "названий",
          "з тендеру", "з оголошення", "що в оголошенні", "товар замовника", "їхній товар")
_OWN = ("свій", "свого", "наш товар", "нашого товару", "наш аналог", "аналог", "еквівалент")


def _stems(text) -> set:
    words = re.findall(r"[a-zа-яіїєґ0-9]{4,}", str(text or "").lower())
    return {w[:6] for w in words}


def _goods():
    try:
        import goods
        return goods.all_goods(kind=goods.KIND_GOODS, archived=False)
    except Exception:
        return []


def candidates(subject: str, goods_list=None, limit: int = 3) -> list:
    """1–3 товари з бази клієнта, найближчі до предмета закупівлі. Нічого — []."""
    items = _goods() if goods_list is None else list(goods_list)
    want = _stems(subject)
    scored = []
    for g in items:
        name = str((g or {}).get("name") or "").strip()
        if not name:
            continue
        traits = (g or {}).get("traits") or {}
        hay = name + " " + " ".join(str(v) for v in traits.values()) if isinstance(traits, dict) else name
        score = len(want & _stems(hay))
        if score:
            scored.append((-score, name.casefold(), g))
    scored.sort(key=lambda x: (x[0], x[1]))
    return [g for _s, _n, g in scored[:max(1, int(limit or 3))]]


# ⭐⭐⭐ 24.09.2026, зміна 639. ЕКВІВАЛЕНТ ЗАБОРОНЕНО — ЦЕ ПЕРШЕ, ЩО БАЧИТЬ ЛЮДИНА.
# 🩸 Каспер, UA-2026-09-21-015529-A: у Додатку 2 замовник прямо пише «Замовник не
# передбачає придбання аналогів та/або еквівалентів даних товарів». Платформа
# запропонувала «свій аналог», людина погодилась — і пакет зібрано під
# пропозицію, яку відхилять. Умову торгів, що вирішує долю пропозиції, бачить
# КОД у документації й називає її в питанні дослівно; варіанта, який замовник
# заборонив, людині не пропонуємо. Обере «свій» усе одно — пакет скаже це першим
# рядком (`tender_skeleton.build`). Рішення лишається за людиною.
_BAN_RE = re.compile(
    r"не\s+передбача\w*\s+(?:придбання\s+|постачання\s+|поставк\w*\s+)?(?:аналог|еквівалент)"
    r"|(?:аналог|еквівалент)\w*[^.]{0,40}?\s+не\s+(?:допуска|передбача|прийма|розгляда)"
    r"|не\s+(?:допуска|прийма|розгляда)\w*\s+(?:\w+\s+){0,2}(?:аналог|еквівалент)", re.I)


def equivalents_banned(material) -> str:
    """Дослівне речення замовника про заборону аналогів/еквівалентів, або ""."""
    for ln in str(material or "").splitlines():
        t = re.sub(r"\s+", " ", ln).strip()
        m = _BAN_RE.search(t)
        if not m:
            continue
        a = max(t.rfind(".", 0, m.start()), t.rfind(":", 0, m.start()),
                t.rfind("!", 0, m.start())) + 1
        b = t.find(".", m.end())
        return t[a:(b + 1) if b >= 0 else len(t)].strip(" _")[:240]
    return ""


def ask(named_product: str, cands, material: str = "") -> str:
    """ОДНЕ питання людині ДО збірки пакета."""
    named = str(named_product or "").strip() or "той, що в оголошенні"
    ban = equivalents_banned(material)
    if ban:
        return "\n".join([
            "Перш ніж збирати пакет — про товар. Замовник у документації пише прямо: "
            "«%s»" % ban,
            "",
            "Тобто свій аналог тут подати не можна — таку пропозицію відхилять.",
            "",
            "1) Названий у тендері: «%s»." % named,
            "2) Не знаю — зберу пакет, а графи товару залишу вам.",
            "",
            "Відповідайте одним словом: «названий» або «не знаю»."])
    lines = ["Перш ніж збирати пакет — який товар пропонуємо?", "",
             "1) Названий у тендері: «%s»." % named]
    names = [str((c or {}).get("name") or "") for c in (cands or []) if (c or {}).get("name")]
    if names:
        lines.append("2) Свій аналог із вашої бази товарів: %s — тоді складу таблицю "
                     "відповідності «вимога замовника → наш товар»."
                     % ", ".join("«%s»" % n for n in names))
    else:
        lines.append("2) Свій аналог — у вашій базі товарів схожого не знайшлося; "
                     "назвіть його словами, і я складу таблицю відповідності.")
    lines.append("3) Не знаю — зберу пакет, а графи товару залишу вам.")
    lines += ["", "Відповідайте одним словом: «названий», «свій» (можна з назвою) або «не знаю»."]
    return "\n".join(lines)


def read_answer(text: str, cands=None) -> dict:
    """-> {"mode": named|own|unknown|"" (рішення в тексті немає), "product": dict|None}."""
    low = " " + re.sub(r"\s+", " ", str(text or "").lower()) + " "
    if any(w in low for w in _UNKNOWN):
        return {"mode": MODE_UNKNOWN, "product": None}
    if any(w in low for w in _NAMED):
        return {"mode": MODE_NAMED, "product": None}
    hit = None
    for c in cands or []:
        nm = str((c or {}).get("name") or "").lower()
        core = [w for w in re.findall(r"[a-zа-яіїєґ0-9]{4,}", nm)]
        if nm and (nm in low or (core and sum(w in low for w in core) >= max(1, len(core) // 2))):
            hit = c
            break
    if hit is not None or any(w in low for w in _OWN):
        return {"mode": MODE_OWN, "product": hit or ((cands or [None])[0])}
    return {"mode": "", "product": None}


def compliance_table(requirements, product) -> str:
    """ТАБЛИЦЯ ВІДПОВІДНОСТІ «вимога замовника → наш товар» за зразком тендериста.

    Характеристику товару платформа не вигадує: чого немає в базі — прочерк."""
    name = str((product or {}).get("name") or "").strip() or "______"
    rows = ["| № | Вимога замовника | Запропонований товар: %s |" % name, "|---|---|---|"]
    reqs = [str(r).strip() for r in (requirements or []) if str(r).strip()]
    for i, r in enumerate(reqs, 1):
        rows.append("| %d | %s | %s — відповідає: ______ |" % (i, r.replace("|", "/"), name))
    if not reqs:
        rows.append("| 1 | ______ | %s — відповідає: ______ |" % name)
    return "\n".join(rows)


# ⭐⭐⭐ 24.09.2026, зміна 639. ТАБЛИЦЯ ВІДПОВІДНОСТІ — ЛИШЕ З ВИМОГ ДО ТОВАРУ.
# 🩸 Каспер, живий прогін 638: з 19 рядків таблиці лише 5 були характеристиками
# костюма; решта — забезпечення пропозиції, крок аукціону, штрафи й пеня з
# проєкту договору. Відбір ішов за СЛОВАМИ («розмір», «гаранті», «термін») по
# всьому тексту, а «розмір забезпечення» і «розмір пені» — теж «розмір».
# ⛒ ЗАКОН: рядок таблиці — пункт переліку, що стоїть ПІД заголовком технічних
# вимог або комплектності замовника (той самий писар переліків, що й склад
# пакета — `tender_pack._list_blocks`). Таких переліків немає — таблиця порожня з
# прочерками, а не набита умовами договору.
_SPEC_HEAD = ("технічні характеристики", "технічна специфікація", "технічні вимоги",
              "технічні, якісні", "характеристики товару", "якісні характеристики",
              "комплектн", "комплетн")


def requirements_in(material: str, limit: int = 40) -> list:
    """Вимоги замовника ДО ТОВАРУ (характеристики, комплектність) для таблиці відповідності."""
    try:
        import tender_pack as _tp
        blocks = _tp._list_blocks(str(material or ""))
        fold = _tp._fold
    except Exception:
        return []
    out, seen = [], set()
    for b in blocks:
        heads = [h for h in (b.get("heads") or []) if str(h).strip()]
        head = fold(heads[-1]).strip() if heads else ""
        if not any(head.startswith(w) or (w in head and len(head) <= 60) for w in _SPEC_HEAD):
            continue
        pref = "Комплектність: " if ("комплектн" in head or "комплетн" in head) else ""
        for it in b.get("items") or []:
            s = re.sub(r"\s+", " ", str(it)).strip(" -•*|\t.;")
            k = s.lower()
            if len(s) >= 3 and k not in seen:
                seen.add(k)
                out.append(pref + s)
            if len(out) >= limit:
                return out
    return out


def decision_in(texts, cands=None) -> dict:
    """Рішення людини з її слів (задача + останні репліки). Немає — mode ""."""
    for t in texts or []:
        r = read_answer(t, cands)
        if r.get("mode"):
            return r
    return {"mode": "", "product": None}
