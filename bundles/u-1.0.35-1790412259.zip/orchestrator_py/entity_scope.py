# -*- coding: utf-8 -*-
"""entity_scope.py — ХТО ЧИЇ КАРТКИ БАЧИТЬ (зміна 589, 16.09.2026).

⛒ КЛАС, ЯКИЙ ЦЕ ЛІКУЄ — ДРУГА ВІСЬ ТОГО САМОГО КОРЕНЯ. Зміна 588 зробила
настроюваним ДОСТУП ДО РОЗДІЛУ: менеджер може мати «Клієнти» й не мати
ліцензії. Але всередині розділу видно було ВСЕ: хто дістав CRM — дістав усю
базу компанії до останнього контрагента. Для Каспера з пʼятьма менеджерами це
не теорія, а те, за чим клієнт і дзвонить.

⭐ ТРИ РІВНІ, ЯК НАЗВАВ ВЛАСНИК 15.09.2026: «лише свої» · «свої + підрозділ» ·
«усі». Рівень — не окремий світ, а СХОДИНКА, і саме тому він записаний двома
галочками в тій самій матриці «роль × дозвіл», що й усе інше. Ширша галочка
перекриває вужчу, тож суперечливого стану не буває в принципі, а керівник
налаштовує це там само, де налаштовує решту прав. Третього писаря правди про
повноваження ми не заводимо.

⛒ ЧИЄ ЦЕ — БЕРЕТЬСЯ З НАЯВНИХ ДАНИХ, А НЕ З НОВОГО РЕЄСТРУ.
  • контрагент — той, хто його ВЕДЕ (`parties.set_manager`, звʼязок
    `managed_by`); це поле живе в платформі з 15.08.2026 і має свій екран;
  • угода — успадковує господаря ВІД СВОГО КОНТРАГЕНТА. Угода без клієнта не
    заводиться взагалі, отже сироти не буває; а передача клієнта іншому
    менеджеру переносить із ним і його угоди — саме так це й відбувається в
    житті. Другого поля «власник угоди», яке одного дня розійдеться з першим,
    ми не створюємо;
  • документи й позиції угоди — це не окремі сутності доступу, а вміст картки
    угоди: їх судить ТА САМА угода, у якій вони лежать.

⛒ НІЧИЙ КОНТРАГЕНТ ВИДНИЙ УСІМ. Це рішення, а не недогляд. У живій базі
відповідального має дай боже половина карток, і сховати решту означало б
одного ранку віддати клієнтові порожню CRM. «Нічий» читається як «спільний»;
щоб картка стала чиєюсь — треба призначити відповідального, і саме цей крок
є актом, який звужує видимість.

⛒ СИТО СТОЇТЬ ТАМ, ДЕ СУТНІСТЬ НАРОДЖУЄТЬСЯ ДЛЯ ЧИТАЧА, А НЕ НА КОЖНИХ
ДВЕРЯХ. У платформі рівно два читачі переліків — `parties.all_parties` і
`deals.all_deals`; через них ідуть і список клієнтів, і пошук, і канбан, і
воронка, і плитки в картці, і навіть та дошка, яку ЗАПИС повертає у відповідь.
Поставити сито на дверях означало б переписати два десятки місць і забути
третє; поставити його в читача — означає накрити й ті двері, яких ще немає.

⛒ ХТО ЧИТАЄ — КАЖЕ СЕРВЕР, І ЛИШЕ НА ЧАС ЗВЕРНЕННЯ. Читач сам не знає, кому
він відповідає, тому сервер називає читача на вході в звернення і прибирає
імʼя у `finally` на виході. Немає імені — сита немає: розклад, телеграм-бот і
внутрішня кухня працюють так само, як працювали.

⛒ І ДРУГИЙ БІК ОПЕРАЦІЇ. Не бачити картку, але могти перейменувати її прямою
адресою — це не доступ, а його видимість. Тому сервер судить НЕ ДВЕРІ, а саме
звернення: у ньому шукаються номери сутностей (`id`, `ref`, `deal`, `party`…),
і якщо серед них є той, кого ця людина бачити не сміє, звернення відмовляється
— байдуже, читання це чи запис, і байдуже, які двері дописали вчора.
"""
import re
import threading

# ⛒ Модулі платформи імпортуються ЛИШЕ ВСЕРЕДИНІ функцій. Причина не в стилі:
# словник дозволів (`taskdesk_roles`) імпортує цей файл, і зустрічний імпорт
# угорі зациклив би завантаження.

SCOPE_OWN = 0
SCOPE_UNIT = 1
SCOPE_ALL = 2

SCOPE_NAMES = {SCOPE_OWN: "лише свої",
               SCOPE_UNIT: "свої + підрозділу",
               SCOPE_ALL: "усі"}

VIS_UNIT = "vis_unit"
VIS_ALL = "vis_all"

VIS_PERMS = [
    {"id": VIS_UNIT, "section": "Видимість карток",
     "name": "Бачить картки свого підрозділу"},
    {"id": VIS_ALL, "section": "Видимість карток",
     "name": "Бачить картки всієї компанії"},
]
VIS_PERM_IDS = tuple(p["id"] for p in VIS_PERMS)
VIS_PERM_NAMES = {p["id"]: p["name"] for p in VIS_PERMS}

KIND_PARTY = "party"
KIND_DEAL = "deal"


def _s(v) -> str:
    return "" if v is None else str(v).strip()


# ───────────────────────────── РІВЕНЬ ЛЮДИНИ ───────────────────────────────
def level_of(emp_id: str) -> int:
    """ЯКИЙ РІВЕНЬ ВИДИМОСТІ В ЦІЄЇ ЛЮДИНИ. Сходинка, а не набір.

    ⛒ Зламаний файл ролей — це НАЙВУЖЧЕ, а не найширше: «не знаю» на замку
    означає «ні», і 588 судить так само."""
    emp = _s(emp_id)
    if not emp:
        return SCOPE_OWN
    try:
        import taskdesk_roles as roles
        perms = roles.role_of(emp).get("perms") or {}
    except Exception:
        return SCOPE_OWN
    if perms.get(VIS_ALL):
        return SCOPE_ALL
    if perms.get(VIS_UNIT):
        return SCOPE_UNIT
    return SCOPE_OWN


def level_name(level: int) -> str:
    return SCOPE_NAMES.get(int(level), SCOPE_NAMES[SCOPE_OWN])


# ─────────────────────────── ЧИЄ ЦЕ (ОДНЕ ЧИТАННЯ) ─────────────────────────
class Owners(object):
    """Хто кого веде — за ОДНЕ читання реєстру звʼязків.

    ⛒ Поіменне питання про кожну з трьох тисяч карток перетворило б відкриття
    списку на три тисячі читань файла. Тому знімок робиться один раз на
    звернення і живе рівно стільки, скільки триває відповідь."""

    def __init__(self):
        self.party_manager = {}   # контрагент -> працівник, який його веде
        self.deal_manager = {}    # угода      -> ВЛАСНИЙ відповідальний (590)
        self.deal_party = {}      # угода      -> її контрагент
        self.party_deals = {}     # контрагент -> перелік його угод
        try:
            import links
            import entity
            rows = links.all_links()
        except Exception:
            return
        try:
            rel_managed = links.REL_MANAGED_BY
            rel_deal = links.REL_DEAL_WITH
        except Exception:
            return
        for row in rows or ():
            rel = _s(row.get("rel"))
            frm, to = _s(row.get("from")), _s(row.get("to") or row.get("ref"))
            if not frm or not to:
                continue
            kind = entity.kind_of(frm)
            if rel == rel_managed and kind == entity.KIND_PARTY:
                self.party_manager[entity.ident_of(frm)] = entity.ident_of(to)
            elif rel == rel_managed and kind == entity.KIND_DEAL:
                self.deal_manager[entity.ident_of(frm)] = entity.ident_of(to)
            elif rel == rel_deal and kind == entity.KIND_DEAL:
                did, pid = entity.ident_of(frm), entity.ident_of(to)
                self.deal_party[did] = pid
                self.party_deals.setdefault(pid, []).append(did)

    def deal_holder(self, did: str) -> str:
        """⭐ 590. ХТО ВЕДЕ УГОДУ. Власний відповідальний, а якщо його ще не
        ставили — відповідальний її контрагента.

        ⛒ СПАДОК, А НЕ ЗАКОН. Угоди, заведені до 590, власного відповідального
        не мають; прочитати це як «нічия» означало б одного ранку показати живу
        базу клієнта всім. Спадок і робить перехід непомітним."""
        i = _s(did)
        own = _s(self.deal_manager.get(i, ""))
        if own:
            return own
        pid = _s(self.deal_party.get(i, ""))
        return _s(self.party_manager.get(pid, "")) if pid else ""

    def holders(self, kind: str, ident: str) -> set:
        """⭐⭐⭐ 590. КОМУ НАЛЕЖИТЬ ЦЯ СУТНІСТЬ. Відповідь — МНОЖИНА, і це
        головна різниця з 589.

        🩸 У контрагента підстав бути «своїм» ДВІ: я його веду АБО я веду хоч
        одну угоду з ним. Без другої підстави Хоменко, завівши закупівельну
        угоду з клієнтом Петренка, не побачив би ні реквізитів, ні контактних
        осіб — тобто не зміг би вести власну угоду.

        ⛒ А в УГОДИ господар один: якщо в неї є свій відповідальний, то
        відповідальний контрагента до неї стосунку не має. Інакше «дві осі»
        знову злиплись би в одну."""
        k, i = _s(kind), _s(ident)
        if not i:
            return set()
        if k == KIND_DEAL:
            who = self.deal_holder(i)
            return {who} if who else set()
        if k == KIND_PARTY:
            out = set()
            who = _s(self.party_manager.get(i, ""))
            if who:
                out.add(who)
            for did in self.party_deals.get(i, ()):
                d = self.deal_holder(did)
                if d:
                    out.add(d)
            return out
        return set()

    def owner(self, kind: str, ident: str) -> str:
        """Один господар — для тих місць, де питають «чий це рядок»."""
        who = self.holders(kind, ident)
        return sorted(who)[0] if len(who) == 1 else ("" if not who else sorted(who)[0])


def owners() -> Owners:
    return Owners()


# ───────────────────────────── ДЕРЕВО ПІДРОЗДІЛІВ ──────────────────────────
def _unit_of(emp_id: str) -> str:
    try:
        import taskdesk_people as people
        return _s((people.employee(_s(emp_id)) or {}).get("unit_id"))
    except Exception:
        return ""


def subtree_units(unit_id: str) -> set:
    """Свій підрозділ І ВСЕ, ЩО ПІД НИМ.

    ⛒ Не сам лише вузол: керівник відділу, під яким два сектори, інакше не
    бачив би роботи власних секторів — а оргструктура намальована саме деревом,
    і другої ієрархії в платформі немає."""
    root = _s(unit_id)
    if not root:
        return set()
    try:
        import taskdesk_people as people
        rows = people.units(include_liquidated=True)
    except Exception:
        return {root}
    parent = {_s(u.get("id")): _s(u.get("parent_id")) for u in rows or ()}
    out = set()
    for uid in parent:
        cur, seen = uid, set()
        while cur and cur not in seen:
            seen.add(cur)
            if cur == root:
                out.add(uid)
                break
            cur = parent.get(cur, "")
    return out


# ──────────────────────────────── ОДИН СУДДЯ ───────────────────────────────
def may_see_owner(emp_id: str, who, level=None) -> bool:
    """⭐⭐⭐ 618. ЄДИНА ВІДПОВІДЬ «ЧИ БАЧИТЬ ЦЯ ЛЮДИНА РЯДОК, ЩО НАЛЕЖИТЬ ОТИМ».

    ⛒ ЧОМУ ЦЕ ВИНЕСЕНО СЮДИ. Доти суддя вмів судити лише СУТНІСТЬ (картку
    контрагента, угоду) — і кожен новий перелік, рядки якого належать ЛЮДИНІ,
    а не картці, лишався б без сита. Саме так черга «Рознести» (`deal_mail`)
    простояла третім читачем переліку без жодного сита: у компанії з пʼятьма
    менеджерами менеджер А читав теми й уривки листів менеджера Б.
    Правило тут РІВНО ТЕ САМЕ, що судило картки з 589, — просто назване один
    раз і на обидва випадки. Другого судді тієї самої правди не буде.

    ⛒ НІЧИЙ РЯДОК БАЧАТЬ УСІ — це рішення, а не недогляд, і воно те саме, що
    для нічийних карток: «нічий» читається як «спільний». Сховати нічиє
    означало б віддати клієнтові порожній екран замість роботи."""
    emp = _s(emp_id)
    if not emp:
        return True                     # імені немає — сита немає (кухня, бот)
    lvl = level_of(emp) if level is None else int(level)
    if lvl >= SCOPE_ALL:
        return True
    who = {_s(x) for x in (who or ()) if _s(x)}
    if not who:
        return True                     # нічий рядок — спільний
    if emp in who:
        return True
    if lvl >= SCOPE_UNIT:
        mine = subtree_units(_unit_of(emp))
        return bool(mine) and any(_unit_of(h) in mine for h in who)
    return False


def may_see(emp_id: str, kind: str, ident: str, own=None, level=None) -> bool:
    """ЄДИНА ВІДПОВІДЬ «чи бачить ця людина оцю картку»."""
    emp = _s(emp_id)
    if not emp:
        return True                     # імені немає — сита немає (кухня, бот)
    lvl = level_of(emp) if level is None else int(level)
    if lvl >= SCOPE_ALL:
        return True
    own = own or owners()
    return may_see_owner(emp, own.holders(kind, ident), level=lvl)


def holders(kind: str, ident: str, own=None) -> set:
    """Кому належить сутність — одним питанням, для екранів і проб."""
    return (own or owners()).holders(kind, ident)


# ═══════════════════ ГРОШІ — ТРЕТЯ ВІСЬ (зміна 592) ════════════════════════
# ⛒ ПРАВИЛО АНДРІЯ 16.09.2026: «сума угоди видима тільки відповідальному за
# угоду менеджеру та його керівнику».
# ⭐ ЦЕ ВУЖЧЕ ЗА ВИДИМІСТЬ, І САМЕ ТОМУ ОКРЕМА ВІСЬ. Рівень «свої + підрозділу»
# дає колезі побачити, що угода Є, — щоб не лізти до того самого клієнта
# наосліп. А СКІЛЬКИ в ній грошей, його не стосується.
# ⛒ КЕРІВНИК — ЦЕ ЛАНЦЮГ УГОРУ ПО ОРГСТРУКТУРІ, а не окремий список: директор
# компанії — керівник кореневого підрозділу, і правило вже дає йому все.
# Другого «режиму директора» в коді не буде.
def deal_is_mine(emp_id: str, did: str, own=None) -> bool:
    """ЧИ ЦЯ УГОДА МОЯ (або мого підлеглого).

    ⛒ ОДНЕ ПИТАННЯ НА ВСЕ ПРИВАТНЕ В УГОДІ, а не окреме правило на кожне поле.
    Приватне — це і гроші (сума, ціни позицій, суми документів, прогноз), і
    СТРІЧКА: у журналі угоди лежать ті самі числа словами («сума: 100 000»), і
    сховати поле, лишивши стрічку, означало б не сховати нічого."""
    emp = _s(emp_id)
    if not emp:
        return True                     # імені немає — сита немає (кухня, бот)
    holder = (own or owners()).deal_holder(_s(did))
    if not holder:
        return True                     # нічия угода — грошей ховати нема від кого
    if holder == emp:
        return True
    return holder in _subordinates(emp)


def _subordinates(emp_id: str) -> set:
    """Усі, хто під цією людиною по дереву. Рахується РАЗ на звернення.

    ⛒ Без памʼяті це питання ставилось би на кожен рядок воронки — тобто сотні
    обходів оргструктури на одне відкриття екрана."""
    emp = _s(emp_id)
    if not emp:
        return set()
    cache = getattr(_LOCAL, "subs", None)
    if cache is None:
        cache = {}
        _LOCAL.subs = cache
    if emp not in cache:
        try:
            import taskdesk_people as people
            cache[emp] = set(people.subordinates_of(emp) or [])
        except Exception:
            cache[emp] = set()
    return cache[emp]


# ⛒ Стара назва лишається входом для місць, де йдеться саме про гроші: там
# вона читається зрозуміліше, а суддя за нею той самий, один.
money_visible = deal_is_mine


def deal_passport(card: dict) -> dict:
    """Картка ЧУЖОЇ угоди: робота видна, приватне — ні.

    ⭐ 592. Колега по підрозділу мусить бачити, що угода з цим клієнтом уже
    йде і хто її веде, — щоб не лізти туди наосліп. Але стрічка угоди і її
    гроші належать тому, хто її веде."""
    out = dict(card or {})
    out["feed"] = {"rows": [], "total": 0, "matched": 0, "shown": 0,
                   "offset": 0, "cut": 0, "has_more": False,
                   "pinned": [], "pin_count": 0}
    out["foreign"] = True
    out["money_hidden"] = True
    out["passport_note"] = (
        "Ця угода належить іншому менеджерові: суми, ціни позицій та історію "
        "роботи з нею бачить він і його керівник.")
    return out


def hide_money(rows, fields, did_key: str = "id", did: str = None):
    """Прибрати грошові поля з тих рядків, чиї гроші цій людині не належать."""
    emp = viewer()
    if not emp or not rows:
        return rows
    own = owners()
    out = []
    for r in rows:
        r = dict(r or {})
        key = _s(did if did is not None else r.get(did_key))
        if not deal_is_mine(emp, key, own=own):
            for f in fields:
                if f in r:
                    r[f] = ""
        out.append(r)
    return out


# ──────────────────── ХТО ЧИТАЄ ЗАРАЗ (на час звернення) ───────────────────
_LOCAL = threading.local()


def set_viewer(emp_id: str) -> None:
    _LOCAL.emp = _s(emp_id)


def clear_viewer() -> None:
    _LOCAL.emp = ""
    _LOCAL.subs = None      # ⛒ памʼять про підлеглих живе рівно одне звернення


def viewer() -> str:
    return _s(getattr(_LOCAL, "emp", ""))


def sift(kind: str, rows, key: str = "id"):
    """СИТО ДЛЯ ПЕРЕЛІКУ. Немає читача або читач бачить усе — перелік цілий."""
    emp = viewer()
    if not emp or not rows:
        return rows
    lvl = level_of(emp)
    if lvl >= SCOPE_ALL:
        return rows
    own = owners()
    return [r for r in rows
            if may_see(emp, kind, _s((r or {}).get(key)), own=own, level=lvl)]


def sift_owned(rows, key: str = "owner"):
    """⭐ 618. СИТО ДЛЯ ПЕРЕЛІКУ, РЯДКИ ЯКОГО НАЛЕЖАТЬ ЛЮДИНІ, А НЕ КАРТЦІ.

    ⛒ Рядок без власника лишається: нічий = спільний (те саме правило, що в
    `sift`). Немає читача — перелік цілий: кухня, бот і розклад працюють так
    само, як працювали."""
    # ⛒ Правило «немає читача — немає сита» живе В ОДНОМУ місці — у
    # судді. Друга його копія тут була б другим писарем тієї самої
    # правди: поправивши одну, ми б забули про другу.
    if not rows:
        return rows
    emp = viewer()
    lvl = level_of(emp)
    if lvl >= SCOPE_ALL:
        return rows
    out = []
    for r in rows:
        who = (r or {}).get(key)
        who = who if isinstance(who, (list, tuple, set)) else [who]
        if may_see_owner(emp, who, level=lvl):
            out.append(r)
    return out


def redact(kind: str, rows, key: str = "id", keep=()):
    """⭐⭐⭐ 590. ДРУГЕ ДІЄСЛОВО СУДДІ: не сховати рядок, а ПРИТЕМНИТИ його.

    ⛒ ПРАВИЛО ОДНЕ НА ДВА МІСЦЯ: **існування видно, вміст — ні.**
      • пошук за назвою мусить сказати, що така компанія в базі вже є, — інакше
        менеджер заведе ДУБЛЬ, тобто зіпсує саме той актив, заради якого
        довідник і писався;
      • перелік угод у картці контрагента мусить бути повним — це факт стосунків
        компанії з клієнтом, — але в чужому рядку немає ні грошей, ні наступної
        дії.
    Що лишається видним, називає той, хто знає форму рядка (`keep`); усе інше
    зникає, а рядок позначається `foreign`, щоб екран не вдавав, ніби він живий.

    ⛒ І ЦЕ НЕ ПОСЛАБЛЕННЯ 589: доступ до ВМІСТУ дає не пошук, а заведена угода,
    яка лишає слід у журналі й видима керівникові."""
    emp = viewer()
    if not rows:
        return rows
    if not emp:
        return rows
    lvl = level_of(emp)
    if lvl >= SCOPE_ALL:
        return rows
    own = owners()
    keep = tuple(keep) + (key, "foreign")
    out = []
    for r in rows:
        r = dict(r or {})
        if may_see(emp, kind, _s(r.get(key)), own=own, level=lvl):
            r["foreign"] = False
            out.append(r)
            continue
        thin = {k: v for k, v in r.items() if k in keep}
        thin[key] = _s(r.get(key))
        thin["foreign"] = True
        out.append(thin)
    return out


# ─────────────────── НОМЕРИ СУТНОСТЕЙ У САМОМУ ЗВЕРНЕННІ ───────────────────
# ⛒ КЛЮЧІ ЯВНІ, А НЕ «ВСЕ ПІДРЯД». Скрізь у платформі сутність приходить одним
# із цих імен; шукати номери в довільному тексті означало б колись відмовити
# людині через слово в нотатці.
REF_KEYS = ("id", "ref", "deal", "party", "item", "doc",
            "party_id", "deal_id", "about", "target", "from", "to",
            "ids", "refs", "parties", "deals")
# ⛒ ІМʼЯ КЛІЄНТА — ОКРЕМИЙ ВИПАДОК. У полі `customer` їде не номер, а назва
# картки взаємин; вона веде до контрагента через `crm.party_of`, і без цього
# рядка чуже досьє й чужу історію спілкування можна було б дістати назвою.
CUSTOMER_KEYS = ("customer",)

_P = re.compile(r"^p\d{4,}$")
_D = re.compile(r"^d\d{4,}$")
_I = re.compile(r"^i\d{4,}$")
_DOC = re.compile(r"^doc\d{4,}$")


def _resolve(value) -> tuple:
    """(вид, номер) або («», «»). Номери в платформі самі кажуть свій вид."""
    v = _s(value)
    if not v:
        return "", ""
    if ":" in v:
        try:
            import entity
            kind, ident = entity.parse(v)
        except Exception:
            return "", ""
        if kind in (KIND_PARTY, KIND_DEAL):
            return kind, _s(ident)
        return "", ""
    if _P.match(v):
        return KIND_PARTY, v
    if _D.match(v):
        return KIND_DEAL, v
    if _I.match(v):                     # позиція угоди судиться своєю угодою
        try:
            import deal_items
            return KIND_DEAL, _s(deal_items.get(v).get("deal"))
        except Exception:
            return "", ""
    if _DOC.match(v):                   # документ угоди — теж своєю угодою
        try:
            import deal_documents
            row = deal_documents.get(v)
            # ⭐ 648: документ САМОГО КЛІЄНТА (статут, витяг) судиться клієнтом.
            if not _s(row.get("deal")) and _s(row.get("party")):
                return KIND_PARTY, _s(row.get("party"))
            return KIND_DEAL, _s(row.get("deal"))
        except Exception:
            return "", ""
    return "", ""


# ⭐⭐⭐ 590. ДВЕРІ, ДЕ ЧУЖЕ ІМʼЯ ДОЗВОЛЕНЕ, БО СТВОРЮЄ СВОЄ.
# 🩸 Випадок Андрія: Хоменко заводить угоду з клієнтом, якого веде Петренко.
# Сторож 589 різав це наглухо — і штовхав менеджера завести ДУБЛЬ компанії.
# Різниця, яку сторож мусить бачити: одна річ — відкрити або змінити чуже,
# інша — ПОСЛАТИСЬ на чуже, створюючи власну сутність.
# ⛒ ПЕРЕЛІК ЯВНИЙ І FAIL-CLOSED: не названі двері судяться, як і судились.
# ⛒ І це не дірка: заведена угода лишає слід у журналі контрагента, а її
# власник видимий керівникові в переліку — прозорість замість заборони, бо
# заборона тут означала б зупинити продаж.
CREATE_WITH_REF = {
    ("POST", "/api/crm/deal_new"): ("party",),
}


def free_keys(method: str, path: str) -> tuple:
    return CREATE_WITH_REF.get((str(method or "").upper(), str(path or "")), ())


# ⭐⭐⭐ 591 (16.09.2026). ТРЕТІЙ ШАР: ПАСПОРТ.
# Слово Андрія: «менеджерам доведеться дозволити бачити картку контрагента при
# заведенні нової угоди». 🩸 До 591 Хоменко знав, що компанія в базі є, але
# картку відкрити не міг — тобто мусив завести угоду НАОСЛІП, не звіривши ні
# реквізитів, ні контактної особи. Платформа вимагала спершу створити сутність,
# а вже потім подивитись, з ким.
# ⛒ ЛІНІЯ ПРОХОДИТЬ НЕ ПО КАРТЦІ, А ПО ЇЇ ВМІСТУ. Довідник компаній —
# СПІЛЬНИЙ АКТИВ компанії: назва, тип, реквізити, контактні особи, хто веде.
# Приватна — РОБОТА з клієнтом: історія спілкування, протокол, досьє, нотатки,
# гроші. Тому чужа картка не відмовляється, а віддається БЕЗ СТРІЧКИ і чесно
# позначається паспортом, щоб екран не вдавав, ніби показав усе.
# ⛒ І ЦЕ ЛИШЕ ПРО ЧИТАННЯ: запис у чужу картку лишається зачиненим.
PASSPORT_DOORS = {
    ("GET", "/api/crm/party_card"),
    ("GET", "/api/crm/entity_card"),
}

# ⛒ ПЕРЕЛІК ТОГО, ЩО ЛИШАЄТЬСЯ, А НЕ ТОГО, ЩО ЗНИКАЄ. Різниця вирішальна:
# перелік «що прибрати» старіє на першому ж новому ключі — досьє, дописане в
# картку завтра, поїхало б у паспорт мовчки. Перелік «що лишити» помиляється в
# безпечний бік: новий ключ у паспорт не потрапить, доки його не назвуть рукою.
PASSPORT_KEEP = (
    "ref", "kind", "title", "href",     # хто це
    "layout", "layout_error",           # склад картки — щоб екран не осліп
    "related",                          # контактні особи й звʼязки
    "manager",                          # хто веде компанію — до кого йти
    "handles_signal",                   # за скількома ручками впізнаємо
    "own_fields",                       # реквізити, оголошені клієнтом
    "deals",                            # перелік угод (чужі вже притемнені 590)
)


def passport_doors(method: str, path: str) -> bool:
    return (str(method or "").upper(), str(path or "")) in PASSPORT_DOORS


def passport(card: dict) -> dict:
    """Зробити з картки паспорт: вміст зникає, паспорт лишається."""
    src = dict(card or {})
    out = {k: v for k, v in src.items() if k in PASSPORT_KEEP}
    # ⛒ ФОРМУ СТРІЧКИ ПОВЕРТАЄМО, ВМІСТ — НІ. `setdefault`, а не присвоєння:
    # якщо стрічка якимось шляхом уціліла після відбору, порожня форма поверх
    # неї приховала б цей факт — і сторож дивився б на власну латку замість
    # правди. Порожню форму екран мусить дістати, інакше він вирішить, що
    # картка зламана.
    out.setdefault("feed", {"rows": [], "total": 0, "matched": 0, "shown": 0,
                            "offset": 0, "cut": 0, "has_more": False,
                            "pinned": [], "pin_count": 0})
    out["passport"] = True
    out["foreign"] = True
    out["passport_note"] = (
        "Ви бачите паспорт компанії: назву, реквізити й контактних осіб. "
        "Історія спілкування та угоди належать іншим менеджерам.")
    return out


def refs_in(*sources, **kw) -> list:
    """Усі сутності, названі у зверненні. Порядок і повтори не важливі."""
    skip = set(kw.get("skip") or ())
    out, seen = [], set()
    for src in sources:
        for key in CUSTOMER_KEYS:
            if key in skip:
                continue
            if not isinstance(src, dict) or not _s(src.get(key)):
                continue
            try:
                import crm
                pid = _s(crm.party_of(_s(src.get(key))))
            except Exception:
                pid = ""
            if pid and (KIND_PARTY, pid) not in seen:
                seen.add((KIND_PARTY, pid))
                out.append((KIND_PARTY, pid))
        for key in REF_KEYS:
            if key in skip:
                continue
            if not isinstance(src, dict) or key not in src:
                continue
            raw = src.get(key)
            values = raw if isinstance(raw, (list, tuple)) else [raw]
            for v in values:
                if isinstance(v, dict):
                    v = v.get("id") or v.get("ref")
                kind, ident = _resolve(v)
                if kind and (kind, ident) not in seen:
                    seen.add((kind, ident))
                    out.append((kind, ident))
    return out


def refusal(kind: str, emp_id: str) -> dict:
    """ВІДМОВА СЛОВАМИ. Тиха відмова = вимкнений сторож."""
    what = "угода" if _s(kind) == KIND_DEAL else "картка контрагента"
    return {"error": "operator_forbidden",
            "message": ("Ця %s належить іншому працівникові, а ваша роль бачить "
                        "лише %s. Ширшу видимість відкриває той, хто веде права "
                        "доступу." % (what, level_name(level_of(emp_id)))),
            "scope": level_name(level_of(emp_id))}
