# -*- coding: utf-8 -*-
"""tender_assemble.py — ОДНА ДОРОГА ЗБИРАННЯ ТЕНДЕРНОГО ПАКЕТА (зміна 640, 25.09.2026).

⭐⭐⭐ НАВІЩО ОКРЕМИЙ МОДУЛЬ. До 640 збирання пакета жило всередині `executor.run_system`
(420 рядків посеред прогону агентів) — і перевірити його з вердиктами справжнього
судді можна було ЛИШЕ живим прогоном за гроші. 🩸 639: $0.91 за день, і перший
прогін був розвідкою.
⛒ Тепер збирання — ОДНА функція `assemble`, якою ходить і бойовий прогін
(`executor`), і офлайн-відтворення на записаній стрічці вердиктів (`tender_tape`,
`tender_replay`). Другої дороги немає: перевірене офлайн — рівно те, що побачить
клієнт. Код перенесено ДОСЛІВНО; змінено лише одне: факти закупівлі й реквізити
учасника беруться через стрічку (наживо — записуються, офлайн — відтворюються).
"""
import llm
import tender_fill
import tender_pack
import tender_skeleton
import tender_tape


def _emit(emit, label):
    if emit:
        try:
            emit("stage", label)
        except Exception:
            pass


def _ctx_or(name, fn):
    """Контекст прогону: офлайн — зі стрічки, наживо — порахувати й записати."""
    if tender_tape.mode() == "replay":
        v = tender_tape.ctx(name)
        if v is not None:
            return v
    v = fn()
    tender_tape.put_ctx(name, v)
    return v


def assemble(files_context="", task="", accumulated="", final_markdown="",
             topics=None, topics_of=None, offer=None, adm_state=None,
             blank_questions=None, emit=None) -> dict:
    """Зібрати пакет. -> {"final_markdown", "documents", "pack_word", "pack_proof", "trace"}"""
    _topics = topics if topics is not None else {"ok": False, "verdicts": {}}
    _topics_of = topics_of
    _offer = offer or {}
    _adm_state = adm_state or {}
    _blank_questions = list(blank_questions or [])
    for _n, _v in (("files_context", files_context), ("task", task),
                   ("accumulated", accumulated), ("offer", _offer),
                   ("adm_state", _adm_state), ("blank_questions", _blank_questions),
                   ("final_markdown_in", final_markdown),
                   ("topics_of_is_material", _topics_of == ((files_context or "") + "\n\n"
                                                            + (task or "")).strip())):
        tender_tape.put_ctx(_n, _v)
    _pack_docs = []
    _pack_proof = {}
    _pack_word = {}
    _dossier = []
    _not_docs = []
    _only_reader = []
    _empty_docs = []
    _same_papers = {}
    _list_rows = 0
    _form_fields = []
    _list_forms = []
    _other_stage = []
    _chk = []
    _mk = {"ok": False, "verdicts": {}}
    _facts = {}
    _verdict = {}
    # ⭐ 10.08.2026. МАТЕРІАЛ = файли + ЗАДАЧА. Людина має право вставити вимоги
    # замовника прямо в задачу, і тоді вони — таке саме джерело, як завантажене.
    _material = ((files_context or "") + "\n\n" + (task or "")).strip()
    # ⚠ Вердикт про теми ми взяли ще до воріт витрат. Питаємо вдруге ЛИШЕ
    # тоді, коли матеріал відтоді змінився: інакше це гроші за те саме
    # питання. А мовчки судити НЕ ТОЙ матеріал не можна — вердикт не
    # знайшовся б, і ми б не відрізнили цього від «суддя промовчав».
    if _material != _topics_of:
        try:
            _topics = tender_pack.head_topics(_material)
            _topics_of = _material
            llm._log("[executor] тема переліків (матеріал змінився): названо=%d"
                     % len(_topics.get("verdicts") or {}))
        except Exception as _e:
            llm._log("[executor] тема переліків не судилась: %s" % _e)
    # ⭐ ДВА ДЖЕРЕЛА ПЕРЕЛІКУ ТРИМАЄМО ОКРЕМО, І ЦЕ НЕ ДРІБНИЦЯ: у них РІЗНА
    # ВАГА. Позицію з документів замовника підтвердив ЗАГОЛОВОК переліку;
    # позицію від агента-читача не підтвердив ніхто (зміна 157).
    # ⭐⭐⭐ 17.08.2026, зміна 194. ФАКТ ПРО НЕПРОЧИТАНЕ ЧИТАЄ КОД, А НЕ МОДЕЛЬ.
    # Мітки кладе `source_intake` (один писар), читає він же (один читач) —
    # і далі факт іде і в шапку пакета, і у ворота. Без цього ворота міряли
    # повноту пакета проти переліку, витягнутого з ПОЛОВИНИ документації.
    _mat_gaps = []
    try:
        import source_intake as _si
        _mat_gaps = _si.gaps_in(_material)
        if _mat_gaps:
            llm._log("[executor] документацію прочитано НЕ ВСЮ: %d — %s"
                     % (len(_mat_gaps), "; ".join(_mat_gaps[:3])))
    except Exception as _e:
        llm._log("[executor] мітки непрочитаного не прочитались: %s" % _e)
    _trace_chk = tender_pack.checklist_from_trace(accumulated)
    _mat_chk = tender_pack.extra_requirements_in(_material, topics=_topics)
    # ⭐ 12.08.2026. ТОЙ САМИЙ ПАПІР, НАЗВАНИЙ ІНШИМИ СЛОВАМИ, — ОДНА ПОЗИЦІЯ.
    _trace_chk, _same_papers = tender_pack.drop_same_papers(_trace_chk, _mat_chk)
    if _same_papers:
        llm._log("[executor] той самий папір іншими словами: %d — %s"
                 % (len(_same_papers), "; ".join(list(_same_papers)[:3])))
    # ⭐⭐⭐ 17.08.2026, зміна 193. ГРАФА БЛАНКА — НЕ ДОКУМЕНТ, І ВИРІШУЄ ЦЕ КОД.
    # 🩸 16.08 читач переказав поля Додатків №3 і №4 («Шапка:», «Телефон/факс:
    # [Номер]», «Чи є дочірнім підприємством?») як окремі вимоги, і платформа
    # склала на кожну довідку: 20 позицій стали 57. Прибираємо ДО злиття —
    # тоді графи не доїжджають ні до судді (це ще й гроші), ні до пакета.
    _trace_chk, _form_fields = tender_pack.drop_form_fields(_trace_chk, _mat_chk)
    if _form_fields:
        llm._log("[executor] графи бланків (не документи): %d — %s"
                 % (len(_form_fields), "; ".join(_form_fields[:3])))
    # ⭐ 639 (живий прогін): пункт переліку ПЕРЕМОЖЦЯ, переказаний читачем, — не
    # документ пропозиції. Код уже визнав той перелік іншим етапом.
    try:
        _trace_chk, _other_stage = tender_pack.stage_rejected(_trace_chk, _material, _topics)
        if _other_stage:
            llm._log("[executor] пункти іншого етапу від читача: %d — %s"
                     % (len(_other_stage), "; ".join(_other_stage[:3])))
    except Exception as _e:
        llm._log("[executor] етап позицій читача не перевірено: %s" % _e)
    _chk = tender_pack.merge_checklists(_trace_chk, _mat_chk)
    # ⭐⭐⭐ 24.09.2026, зміна 636. ОДНА ФОРМА ЗАМОВНИКА — ОДИН ДОКУМЕНТ.
    _n_before = len(_chk)
    _chk = tender_skeleton.one_form_one_document(_chk)
    if len(_chk) != _n_before:
        llm._log("[executor] графи однієї форми й дублі злито: %d -> %d"
                 % (_n_before, len(_chk)))
    # ⭐⭐⭐ 24.09.2026, зміна 639. «ФОРМА 1» — ЦЕ ПЕРЕЛІК, А НЕ ДОКУМЕНТ; ГОЛИЙ
    # «ДОДАТОК № 2» ПОРЯД ІЗ «ЗАПОВНЕНИЙ ДОДАТОК № 2» — ДУБЛЬ. Код, $0, не мовчки.
    try:
        _chk, _list_forms = tender_pack.drop_list_forms(_chk, _material, topics=_topics)
        if _list_forms:
            llm._log("[executor] посилання на форми (не документи): %d — %s"
                     % (len(_list_forms), "; ".join(_list_forms[:4])))
    except Exception as _e:
        llm._log("[executor] посилання на форми не перевірено: %s" % _e)
    # ⭐⭐⭐ 05.08.2026, ТРЕТІЙ ПРОВАЛЕНИЙ ПРОГІН. КІСТЯК ПАКЕТА БУДУЄ КОД.
    # Агенти відмовлялись складати пакет («більшість інформації відсутня» —
    # у них не було реквізитів і цін учасника), і жоден текст у промпті цього
    # не змінив: рішення ухвалює модель, а прохання в промпті — це прохання.
    # Тепер структура пакета детермінована: перелік замовника -> розділ на
    # кожен пункт + реєстр із підставами + список «заповнити перед подачею».
    # Модель не вирішує, БУТИ пакету чи ні: пакет уже є, вона його наповнює.
    # Найгірше, що можливо, — порожні графи. Це чесний папір, а не «роботи не зроблено».
    if _chk:
        try:
            # ⭐ ФАКТИ ЗАКУПІВЛІ БЕРЕМО З КАРТКИ, А НЕ ЛИШЕ НОМЕР (зміна 159):
            # інакше платформа знає предмет і замовника, а в складеній
            # довідці стоїть «предмет закупівлі: ______».
            _tid = (tender_pack.tender_id_in(task or "")
                    or tender_pack.tender_id_in(files_context or ""))
            _facts = _ctx_or("facts", lambda: tender_pack.tender_facts(_tid))
            _facts["offer"] = dict(_offer or {})     # зміна 636, клас Г
            # ⭐ 639: заборона аналогів замовником — дослівно в пакет, якщо обрано свій.
            try:
                import tender_offer as _tofb
                _facts["equivalents_banned"] = _tofb.equivalents_banned(_material)
            except Exception:
                pass
            # ⭐ 17.08.2026. СТАН ЗАКУПІВЛІ ЇДЕ В САМ ПАКЕТ. Ворота №0 могли
            # пропустити роботу за прямим словом людини («як заготовка») —
            # тоді документ мусить нести це попередження першим рядком:
            # пакет читатимуть ще й ті, хто не бачив нашої розмови.
            _adm = tender_pack.admissibility_note(_adm_state)
            if _adm:
                _facts["admissibility"] = _adm
            llm._log("[executor] факти закупівлі: номер=%s предмет=%s замовник=%s "
                     "строк=%s кількість=%s"
                     % (_facts.get("tender_id") or "—",
                        (_facts.get("subject") or "—")[:60],
                        (_facts.get("customer") or "—")[:40],
                        _facts.get("deadline") or "—",
                        _facts.get("quantity") or "—"))
            # ⭐ ХТО ВИРОБЛЯЄ ДОКУМЕНТ — теж судження про ЧУЖИЙ документ.
            # Один виклик на весь пакет, вердикт протягується в усі чотири
            # місця, де про це питали (розділ, реєстр, «зібрати самому»,
            # «бланки замовника»). Суддя мовчить -> словник + видима помітка.
            _mk = {"ok": False, "verdicts": {}}
            try:
                _mk = tender_skeleton.makers_for(_chk)
                llm._log("[executor] виробник документів: суддя=%s, названо позицій=%d"
                         % ("так" if _mk.get("ok") else "ні",
                            len(_mk.get("verdicts") or {})))
            except Exception as _e2:
                llm._log("[executor] виробника не судили: %s" % _e2)
            # ⛔ Позиції, які суддя назвав НЕ ДОКУМЕНТАМИ, у пакет не йдуть,
            # але й не зникають мовчки: код прибирає їх зі складу і НАЗИВАЄ
            # людині окремим блоком. Ворота пакета мусять звірятися з тим
            # самим переліком, інакше поскаржаться на власне ж прибирання.
            _not_docs = tender_skeleton.not_documents(_chk, _mk)
            if _not_docs:
                _chk = [i for i in _chk
                        if tender_skeleton.is_document(i, _mk)]
                llm._log("[executor] не документи (прибрано з пакета): %d — %s"
                         % (len(_not_docs), "; ".join(_not_docs[:5])))
            # ⛔ 11.08.2026, зміна 157. ПОЗИЦІЯ, ЯКУ НАЗВАВ ЛИШЕ ЧИТАЧ І ЯКУ
            # СУДДЯ НЕ ПІДТВЕРДИВ ДОКУМЕНТОМ, У ПАКЕТ НЕ ЙДЕ. Інакше дефолт
            # «система» робив довідку з власного заголовка агента-читача.
            _chk, _only_reader = tender_pack.keep_confirmed_docs(
                _chk, _trace_chk, _mat_chk, _mk)
            if _only_reader:
                llm._log("[executor] лише від читача, не підтверджено: %d — %s"
                         % (len(_only_reader), "; ".join(_only_reader[:5])))
            # ⭐⭐⭐ 17.08.2026 (зміна 197). РЯДОК ВИМОГИ -> ДОКУМЕНТИ. Замовник
            # пише вимогу умовою («Якщо пропозиція подається не керівником —
            # учасник надає ДОВІРЕНІСТЬ»), і папір ховається всередині правила.
            # Розкриваємо ОДИН раз, у ОДНОМУ місці, після того як склад пакета
            # вже звірений із переліком замовника й переказом читача: далі всі —
            # і текст довідок, і кістяк, і ворота — працюють з ДОКУМЕНТАМИ,
            # а сам рядок лишається їхньою ПІДСТАВОЮ.
            _rows_n = _list_rows = len(_chk)
            _chk = tender_skeleton.expand(_chk, _mk)
            if len(_chk) != _rows_n:
                llm._log("[executor] рядки замовника розкрито в документи: %d -> %d"
                         % (_rows_n, len(_chk)))
            # ⭐⭐⭐ 640. ФІЛЬТР ПОСИЛАНЬ НА ФОРМИ — І ПІСЛЯ РОЗКРИТТЯ. 🩸 639б: суддя
            # розкрив «надати документи згідно Форми 1 та … Додатку № 2» у папери
            # «Форма 1» і «Документи згідно Додатку № 2» — вже ПІСЛЯ фільтра рядків.
            # Той самий закон судить і рядки, і папери: одне правило, два входи.
            try:
                _chk, _lf2 = tender_pack.drop_list_forms(_chk, _material, topics=_topics)
                if _lf2:
                    _list_forms = list(_list_forms) + list(_lf2)
                    llm._log("[executor] посилання на форми серед паперів: %d — %s"
                             % (len(_lf2), "; ".join(_lf2[:4])))
            except Exception as _e:
                llm._log("[executor] посилання на форми серед паперів не перевірено: %s" % _e)
            # ⭐⭐⭐ 24.08.2026, зміна 209. КАРТКА, ЯКУ КЛІЄНТ ДАВ У ЧАТ,
            # ЇДЕ В БАЗУ ЗНАНЬ. Обіцянка клієнту звучала так: «дайте файл із
            # даними компанії — платформа візьме реквізити звідти». Досі
            # прикріплений файл був лише матеріалом одного прогону: наступного
            # разу все спочатку. Тепер прочитане ЗБЕРІГАЄТЬСЯ, і клієнт дає
            # картку ОДИН раз. Витяг детермінований (правила, не модель), тому
            # він однаковий на еталоні й у клієнта і коштує $0.
            try:
                import owner_card as _oc
                # ⛒ 24.08.2026, зміна 213. СУДИМО КОЖЕН ФАЙЛ ОКРЕМО.
                # Злиття всіх прикріплених файлів в один текст дало тендерній
                # документації замовника видати себе за картку учасника — і в
                # базу знань лягло ЄДРПОУ ЗАМОВНИКА. Файл судиться сам, зі
                # своєю назвою і своїм розміром.
                # ⭐ ЗМІНА 221: збираємо з УСІХ прикріплених файлів, а не
                # шукаємо один «правильний». Рубрика «чи це картка» більше
                # не вирішує долю даних; тендерну документацію замовника
                # відсікає сам `harvest` (уроки змін 213 і 215).
                _blocks = list(_oc.blocks(files_context or ""))
                _card, _src = _oc.harvest(_blocks)
                if _src:
                    llm._log("[executor] реквізити зібрано з файлів: %s"
                             % "; ".join("%s <- %s" % (k, v) for k, v in _src.items()))
                if not any((_card or {}).values()):
                    _card = {}
                if _card:
                    if _oc.save(_card, sources=_src):
                        llm._log("[executor] картку учасника оновлено з файла клієнта: %s"
                                 % ", ".join(k for k in _oc.FIELDS if _card.get(k)))
                        _emit(emit, "🗂 Реквізити учасника взято з вашого файла "
                                    "і збережено в базу знань — далі підставляться самі")
            except Exception as _e:
                llm._log("[executor] картка учасника не прочиталась: %s" % _e)
            _req = _ctx_or("req", tender_pack.requisites)
            # ⭐⭐⭐ 12.08.2026 (зміна 159). ТЕКСТ ДОВІДКИ ЗАМОВЛЯЄ ПЛАТФОРМА.
            # Живий прогін 12.08 віддав клієнту пʼять ПОРОЖНІХ бланків: текст
            # моделі ліпився хвостом пакета за збігом перших 32 знаків назви —
            # і у файл довідки не потрапляв ніколи. Тепер «одна довідка — один
            # запит», а код кладе відповідь УСЕРЕДИНУ свого розділу.
            # ⭐⭐⭐ 24.09.2026, зміна 636. ДОСЬЄ УЧАСНИКА ЛЯГАЄ В ПАКЕТ.
            # 🩸 Каспер: статут, витяги, наказ, протокол, договори лежали в
            # теці, а пакет писав «додає учасник». Тепер кожен файл має тип і
            # дату, і під вимогу замовника пакет бере файл із досьє.
            # ⭐ 644: читається ДО рішень про умовні вимоги (власний статут, витяг платника).
            try:
                import tender_dossier as _tdos
                _dossier = _tdos.scan()
                llm._log("[executor] досьє учасника: файлів=%d, постійних=%d, зразків=%d, "
                         "без типу=%d"
                         % (len(_dossier),
                            sum(1 for e in _dossier if e.get("kind") == _tdos.KIND_KEEP),
                            sum(1 for e in _dossier if e.get("kind") == _tdos.KIND_SAMPLE),
                            sum(1 for e in _dossier if not e.get("type"))))
            except Exception as _e4:
                _dossier = []
                llm._log("[executor] досьє учасника не прочиталось: %s" % _e4)
            _slots, _bodies, _blanks = [], {}, {}
            try:
                # ⭐⭐⭐ 639 (живий прогін): довідка «відповідно Форми N» — це ТЕКСТ
                # ФОРМИ ЗАМОВНИКА з назвою учасника, його заповнює код ($0, дослівно);
                # модель такий текст не складає (вона писала свій, без граф форми).
                _form_b = {}
                try:
                    _form_b = tender_fill.form_bodies(_chk, _mk, _material, _req)
                    if _form_b:
                        llm._log("[executor] форми замовника заповнено кодом: %d — %s"
                                 % (len(_form_b), "; ".join(list(_form_b)[:3])))
                except Exception as _ef:
                    llm._log("[executor] форми замовника не заповнено: %s" % _ef)
                # ⭐⭐⭐ 643: БЛАНК ЗАМОВНИКА ЛЯГАЄ В ПАКЕТ ЗАПОВНЕНИМ. 🩸 Каспер 25.09.2026:
                # замість Пропозиції, Додатка 2 і проєкту договору пакет писав «заповнюється
                # на бланку Замовника», хоча їхній текст платформа вже прочитала. Тепер папір,
                # для якого замовник дав свій бланк, — це цей бланк з реквізитами учасника
                # (код, $0); модель такий папір не пише, а вирок «хто складає» — «форма
                # замовника» для реєстру, паспорта й «заповнити перед подачею».
                try:
                    import tender_blank as _tbl
                    # бланк беремо лише з ДОКУМЕНТІВ замовника: слова людини (task) бланком не бувають
                    _blanks = _tbl.bodies(_chk, _mk, files_context or _material, _req, _facts,
                                          skip=_form_b)
                    if _blanks:
                        _mk = dict(_mk or {})
                        _mk["maker_of"] = dict(_mk.get("maker_of") or {})
                        for _bi in _blanks:
                            _mk["maker_of"][_bi] = "форма замовника"
                        llm._log("[executor] бланки замовника заповнено кодом: %d — %s"
                                 % (len(_blanks), "; ".join("%s <- %s" % (tender_skeleton._clean(k)[:40],
                                                                        v["label"])
                                                           for k, v in list(_blanks.items())[:4])))
                except Exception as _eb:
                    _blanks = {}
                    llm._log("[executor] бланки замовника не заповнено: %s" % _eb)
                # ⭐⭐⭐ 644: УМОВНУ ВИМОГУ ВИРІШУЮТЬ ФАКТИ УЧАСНИКА — ДО замовлення текстів.
                # 🩸 Каспер, живий прогін 643: лист «пояснення щодо податків» платника єдиного
                # податку поїхав у пакет, а довіреність і антикорупційну програму просили «додати»,
                # хоча картка, досьє й вартість закупівлі давали відповідь.
                try:
                    import tender_conditions as _tcond
                    _mk = _mk if isinstance(_mk, dict) else {}
                    _cd = _tcond.decide(_chk, _mk, _req, _facts, _dossier,
                                        (files_context or "") + "\n\n" + (_material or ""))
                    llm._log("[executor] умовні вимоги: не потрібні=%d, рядків довідки=%d, "
                             "листів-роз'яснень=%d%s"
                             % (_cd["not_needed"], _cd["lines"], _cd["letters"],
                                (" — " + "; ".join(tender_skeleton._clean(k)[:40]
                                                   for k in list((_mk.get("not_needed") or {}))[:5]))
                                if _cd["not_needed"] else ""))
                except Exception as _ec:
                    llm._log("[executor] умовні вимоги не вирішено: %s" % _ec)
                # ⭐ 644: текст листа-роз’яснення складає КОД словами вимоги замовника ($0)
                _letter_b = dict((_mk or {}).get("letter_body") or {})
                _slots = [_s for _s in tender_fill.slots(_chk, _mk)
                          if _s["item"] not in _form_b and _s["item"] not in _blanks]
                _bodies = dict(_form_b)
                _bodies.update(_letter_b)
                if _slots:
                    _fill = tender_fill.compose(_slots, _facts, _req, _material)
                    _bodies.update(_fill.get("bodies") or {})
                    _empty_docs = list(_fill.get("missing") or [])
                    llm._log("[executor] текст довідок: замовлено=%d складено=%d "
                             "без тексту=%d%s"
                             % (_fill.get("asked", 0), _fill.get("done", 0),
                                len(_empty_docs),
                                (" — " + "; ".join(_empty_docs[:3])) if _empty_docs else ""))
                    _emit(emit, "✍ Текст довідок склала платформа: %d з %d"
                          % (_fill.get("done", 0), _fill.get("asked", 0)))
            except Exception as _e3:
                # Зрив не смів би бути тихим: усі замовлені довідки лишаються
                # без тексту, і людина мусить це БАЧИТИ, а не здогадуватись.
                _empty_docs = [tender_skeleton._clean(_s.get("item"))
                               for _s in (_slots or [])]
                llm._log("[executor] текст довідок не склався: %s" % _e3)
            # (досьє прочитано вище — до рішень про умовні вимоги, зміна 644)
            # ⭐ зміна 636, клас Г: свій товар -> таблиця відповідності за зразком
            # тендериста; характеристик платформа не вигадує (прочерки).
            # 645б: це ДОКУМЕНТ пакета — його пише `tender_skeleton.build` (позначка писаря
            # і рядок у реєстрі), а не дописаний хвіст після паспорта.
            _compl = ""
            if (_offer or {}).get("mode") == "own":
                try:
                    import tender_offer as _tof2
                    _compl = _tof2.compliance_table(_tof2.requirements_in(_material),
                                                    (_offer or {}).get("product"))
                except Exception as _e7:
                    llm._log("[executor] таблиця відповідності не склалась: %s" % _e7)
            _skel = tender_skeleton.build(_chk, _req, _facts,
                                          makers=_mk, bodies=_bodies,
                                          material_gaps=_mat_gaps,
                                          list_rows=_list_rows,
                                          blanks=_blanks,
                                          dossier=_dossier,
                                          compliance=_compl)
            if _skel:
                # ⛔ Вільний пакет моделі СЮДИ БІЛЬШЕ НЕ ДОДАЄТЬСЯ: правда про
                # склад і зміст пакета одна, і її пише платформа.
                final_markdown = _skel
                if _blank_questions:
                    final_markdown += ("\n\n---\n\n### ЩО ПОТРІБНО ВІД УЧАСНИКА\n"
                                       + "\n".join("- " + q for q in _blank_questions))
                _emit(emit, "🧱 Кістяк пакета зібрано платформою — %d позицій переліку"
                            % len(_chk))
                # 🩸 Раніше цей рядок називався «текст моделі=…», а показував
                # довжину ЗІБРАНОГО пакета — і памʼять зміни 158 записала
                # «модель написала 26 034 знаки», чого ніхто не бачив.
                llm._log("[executor] кістяк пакета: позицій=%d, довідок з текстом=%d "
                         "із %d, зібраний пакет=%d знаків"
                         % (len(_chk), len(_bodies), len(_slots),
                            len(final_markdown or "")))
        except Exception as _e:
            llm._log("[executor] кістяк пакета не зібрався: %s" % _e)
    # ⭐⭐⭐ 10.08.2026. ВОРОТА ДІСТАЮТЬ САМЕ ОГОЛОШЕННЯ — щоб звіряти пакет не з
    # тим переліком, з якого його ж і зібрали (замкнене коло), а з незалежною
    # оцінкою обсягу вимог у документах замовника.
    # ⭐ 642: прибране КОДОМ як не-документ (посилання, правило, форма-перелік) теж
    # «свідомо прибране» — але лише те, що стояло в лінійці обсягу замовника.
    try:
        _vk = tender_pack.volume_keys(_material, _topics) if _material else set()
        _code_dropped = len({tender_pack._key(_x) for _x in (_list_forms or [])} & _vk)
    except Exception as _evk:
        _code_dropped = 0
        llm._log("[executor] лінійка прибраного кодом не порахувалась: %s" % _evk)
    _verdict = tender_pack.check_pack(final_markdown, _chk, _material, topics=_topics,
                                      dropped=len(_not_docs) + len(_only_reader) + _code_dropped,
                                      empty_docs=_empty_docs, material_gaps=_mat_gaps,
                                      list_rows=_list_rows)
    # 🩸 «НЕ ВИСТАЧАЄ» БЕЗ «НАДЛИШКУ» — ПОЛОВИНА ПРАВДИ (зміна 193): 16.08 цей
    # самий рядок казав «обсяг в оголошенні=20 не вистачає=0» при 57 пунктах.
    # ⭐ 198: у рядку тепер ВИДНО обидві лінійки — вимог замовника й документів.
    llm._log("[executor] ворота пакета: вимог замовника=%d документів=%d рядків=%d "
             "пропущено=%d без підстави=%d обсяг в оголошенні=%d "
             "не вистачає=%d надлишок=%d"
             % (_verdict.get("list_rows", 0), len(_chk), _verdict.get("rows", 0),
                len(_verdict.get("missing") or []),
                len(_verdict.get("no_source") or []), _verdict.get("volume", 0),
                _verdict.get("short_by", 0), _verdict.get("over_by", 0)))
    # ⭐⭐⭐ 24.09.2026, зміна 636. ВОРОТА ЛИСТІВ: спотворений номер закупівлі
    # або прочерк там, де платформа знає дані, — пакет не видається як готовий.
    try:
        _blockers = tender_skeleton.pack_blockers(final_markdown or "", _req, _facts) \
            if _chk else []
    except Exception as _e5:
        _blockers = []
        llm._log("[executor] ворота листів не спрацювали: %s" % _e5)
    if _blockers:
        _verdict = dict(_verdict or {})
        _verdict["ok"] = False
        _verdict["reason"] = ((_verdict.get("reason") or "") + " "
                              + "Пакет містить помилки в листах: " + "; ".join(_blockers)
                              + ".").strip()
        llm._log("[executor] ворота листів: %s" % "; ".join(_blockers))
    if not _verdict.get("ok"):
        # ⭐ 05.08.2026, живий прогін: моє попередження прочитав СУДДЯ ЯКОСТІ й
        # оголосив усю роботу невиконаною — людина не отримала нічого. Це вже не
        # чесність, а друга правда про «готово». Блок лишається, але прямо каже,
        # ЩО він таке: попередження учаснику перед подачею, а не вердикт про роботу.
        _lines = ["> ⚠ **ПЕРЕВІРКА ПАКЕТА ПЕРЕД ПОДАЧЕЮ.** " + (_verdict.get("reason") or "")
                  + " Це попередження учаснику, а НЕ ознака невиконаної роботи:"
                    " документи нижче складені й придатні до використання."]
        if _verdict.get("missing"):
            _lines.append("> \n> **Пункти переліку замовника, яких немає в пакеті:**")
            _lines += ["> • " + m for m in _verdict["missing"][:12]]
        if _verdict.get("empty_docs"):
            _lines.append("> \n> **Довідки, текст яких платформа не склала** "
                          "(шапка й підстава є — текст напишіть самі):")
            _lines += ["> • " + m for m in _verdict["empty_docs"][:12]]
        if _verdict.get("no_source"):
            _lines.append("> \n> **Рядки без підстави в оголошенні** (не доведено, звідки вимога):")
            _lines += ["> • " + m for m in _verdict["no_source"][:12]]
        _lines.append("> \n> Закрийте названі пункти перед подачею — решта пакета готова.")
        final_markdown = "\n".join(_lines) + "\n\n---\n\n" + (final_markdown or "")
        _emit(emit, "⛔ Ворота пакета: %s" % (_verdict.get("reason") or "неповно"))
    # ⭐⭐⭐ 10.08.2026, зміна 142. ПЕРЕЛІК, ЯКИЙ МИ НЕ ВИЗНАЛИ ВИМОГАМИ, НЕ
    # СМІЄ ЗНИКНУТИ МОВЧКИ. Тему переліку тепер судить його ЗАГОЛОВОК — і це
    # рішення ПЛАТФОРМИ, а не замовника. Тому все, що ми відклали, людина
    # БАЧИТЬ і може заперечити очима, а не дізнатись про пропуск на знятті з
    # торгів. Блок дописуємо ПІСЛЯ воріт: ворота мусять судити пакет, а не
    # власну примітку про нього.
    if _not_docs:
        final_markdown = (final_markdown or "") + (
            "\n\n---\n\n### ПОЗИЦІЇ, ЯКІ ПЛАТФОРМА НЕ ВИЗНАЛА ДОКУМЕНТАМИ\n\n"
            "Це рядки умов закупівлі (ціна, кількість, строки, розділи договору), "
            "а не папери до подачі — тому окремих документів для них не складено. "
            "Перевірте очима, якщо вважаєте інакше:\n\n"
            + "\n".join("- " + n for n in _not_docs[:12])
            + (("\n- …і ще %d" % (len(_not_docs) - 12)) if len(_not_docs) > 12 else ""))
    # 🩸 І ЦЕ ПРИБИРАННЯ ТЕЖ НЕ ТИХЕ: людина бачить, що назвав читач і чому
    # цього немає в пакеті (зміна 157).
    _empty_note = tender_fill.empty_note(_empty_docs)
    if _empty_note:
        final_markdown = (final_markdown or "") + "\n\n---\n\n" + _empty_note
    _only_note = tender_pack.unconfirmed_trace_note(_only_reader)
    if _only_note:
        final_markdown = (final_markdown or "") + "\n\n---\n\n" + _only_note
    # 🩸 17.08.2026 (зміна 193). ГРАФИ БЛАНКІВ ПРИБИРАЄ КОД — І ТЕЖ НЕ МОВЧКИ.
    _fields_note = tender_pack.form_fields_note(_form_fields)
    if _fields_note:
        final_markdown = (final_markdown or "") + "\n\n---\n\n" + _fields_note
    _st_note = tender_pack.stage_note(_other_stage)            # 639
    if _st_note:
        final_markdown = (final_markdown or "") + "\n\n---\n\n" + _st_note
    _lf_note = tender_pack.list_forms_note(_list_forms)       # 639
    if _lf_note:
        final_markdown = (final_markdown or "") + "\n\n---\n\n" + _lf_note
    _same_note = tender_pack.same_papers_note(_same_papers)
    if _same_note:
        final_markdown = (final_markdown or "") + "\n\n---\n\n" + _same_note
    # ⭐⭐⭐ 641, закон Д: ПРИМІТКИ ПЕРЕЛІКУ ЗАМОВНИКА — ДОСЛІВНО. «Примітки:» між пунктами
    # (нерезиденти; «якщо не платник ПДВ — лист»; «документи 8.1–8.4 не раніше 30 днів»)
    # — це умови до паперів, і вони не губляться між документами пакета.
    try:
        _notes = tender_pack.list_notes(_material, topics=_topics)
    except Exception as _en:
        _notes = []
        llm._log("[executor] примітки переліку не прочитались: %s" % _en)
    if _notes:
        _nl = ["### ПРИМІТКИ ЗАМОВНИКА ДО ПЕРЕЛІКУ (дослівно)", ""]
        for _h, _its in _notes:
            _nl.append("**%s**" % str(_h).strip())
            _nl += ["- " + str(x).lstrip("-–—•· ").strip() for x in _its]
            _nl.append("")
        final_markdown = (final_markdown or "") + "\n\n---\n\n" + "\n".join(_nl).rstrip()
    _unc = tender_pack.unclaimed_note(_material, topics=_topics)
    if _unc:
        final_markdown = (final_markdown or "") + "\n\n---\n\n" + _unc
    # ⭐ FAIL-OPEN НЕ СМІЄ БУТИ ТИХИМ: перелік, узятий у вимоги без
    # підтвердженої теми, людина мусить БАЧИТИ так само, як і відкладений.
    _unconf = tender_pack.topic_unconfirmed_note(_material, topics=_topics)
    if _unconf:
        final_markdown = (final_markdown or "") + "\n\n---\n\n" + _unconf
    # ⭐⭐⭐ 642. КАРТА ПУНКТІВ ЗАМОВНИКА — ПОРУЧ ІЗ ПАКЕТОМ, А НЕ В НЬОМУ. 🩸 Живий
    # прогін 640: мозок пояснив «статут сканом» пунктами «15.2 і 15.3 Форми 1», яких у
    # Формі 1 немає. Нумерацію документів замовника читає один писар (`clause_map`); з
    # карти відповідає мозок, за нею судять двері відповіді (`agent._mend_clause_refs`).
    # ⛒ У ТЕКСТ ПАКЕТА КАРТА НЕ ЛЯГАЄ: там вона — слова замовника, яких пакет не брав,
    # і кожна перевірка «чи потрапило це в пакет» бачила б їх у карті (proba tender_pack_path
    # почервоніла саме так). Карта їде окремим полем результату — як склад Word.
    try:
        import clause_map as _cmap
        _cm_sec = _cmap.section(_material)
    except Exception as _ecm:
        _cm_sec = ""
        llm._log("[executor] карта пунктів замовника не склалась: %s" % _ecm)
    # ⭐ 10.08.2026, зміна 144. ПАКЕТ ЇДЕ ОКРЕМИМИ ФАЙЛАМИ.
    # Учасник подає на майданчик кожен документ окремо, а не один зведений
    # аркуш. Склад пакета оголошує ТОЙ, ХТО ЙОГО ЗІБРАВ; файли пише один
    # писар (`artifacts.write_document_files`) на здачі.
    try:
        _pack_docs = tender_skeleton.split_documents(final_markdown or "")
    except Exception as _e:
        _pack_docs = []
        llm._log("[executor] склад пакета не розбився: %s" % _e)
    # ⭐⭐⭐ 24.08.2026, зміна 208. ДОКАЗ ПРО СКЛАД ПАКЕТА — МАШИНОЧИТНИЙ.
    # Корінь (живий зрив у Каспера 24.08): пакет був СКЛАДЕНИЙ і ПІДТВЕРДЖЕНИЙ
    # нашими ж воротами (пропущено=0, без підстави=0), а суддя приймання
    # подивився на прочерки «______» і виніс «це не результат» — код викинув
    # увесь пакет, не написав жодного файлу і звелів мозку сказати клієнту
    # «роботи не зроблено». Тепер факт про склад пакета їде ЧИСЛАМИ поруч із
    # самим пакетом, і вирок про ТЕКСТ не скасовує ДОВЕДЕНИЙ склад.
    # ⭐⭐⭐ 24.09.2026, зміна 636 (клас Е). ПАКЕТ — ОДНИМ ФАЙЛОМ WORD.
    # Прохання Олександри (Каспер): один Word замість десятків файлів. Тут
    # оголошуємо, ЩО в нього лягає (реєстр, документи, файли досьє, бланк);
    # сам файл пише `tender_word` на здачі (agent), поруч із прогоном.
    if _pack_docs:
        try:
            import tender_dossier as _tdos2
            import tender_word as _tw
            _atts, _seen_att = [], set()
            for _it in (_chk or []):
                if tender_skeleton.who_makes(_it, _mk) != "учасник":
                    continue
                for _f in tender_skeleton.dossier_files(_it, _dossier):
                    if _f.get("path") not in _seen_att:
                        _seen_att.add(_f.get("path"))
                        # скан стає НА МІСЦЕ свого документа в Word
                        _atts.append(dict(_f, **{"for": tender_skeleton._clean(_it)}))
            _pack_word = {"registry": _tw.registry_of(final_markdown or ""),
                          "attachments": _atts,
                          "blank": _tdos2.blank(_dossier),
                          "tender_id": (_facts or {}).get("tender_id", "")}
            llm._log("[executor] один Word пакета: документів=%d, файлів досьє=%d, бланк=%s"
                     % (len(_pack_docs), len(_atts), "так" if _pack_word["blank"] else "ні"))
        except Exception as _e6:
            _pack_word = {}
            llm._log("[executor] склад одного Word не оголошено: %s" % _e6)
    if _pack_docs:
        _pack_proof = {
            "documents": len(_pack_docs),
            "missing": len(_verdict.get("missing") or []),
            "no_source": len(_verdict.get("no_source") or []),
            "rows": int(_verdict.get("rows") or 0),
            "checklist": len(_chk or []),
        }
        llm._log("[executor] доказ складу пакета: документів=%d пропущено=%d "
                 "без підстави=%d рядків реєстру=%d"
                 % (_pack_proof["documents"], _pack_proof["missing"],
                    _pack_proof["no_source"], _pack_proof["rows"]))
    return {"final_markdown": final_markdown, "documents": _pack_docs,
            "pack_word": _pack_word, "pack_proof": _pack_proof, "clause_map": _cm_sec,
            "trace": {"checklist": list(_chk or []), "makers": _mk, "topics": _topics,
                      "not_docs": _not_docs, "only_reader": _only_reader,
                      "list_forms": _list_forms, "other_stage": _other_stage,
                      "form_fields": _form_fields, "same_papers": _same_papers,
                      "verdict": _verdict, "list_rows": _list_rows, "facts": _facts}}
