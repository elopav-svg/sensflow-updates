# -*- coding: utf-8 -*-
"""
tender_blank.py — БЛАНК ЗАМОВНИКА ЗАПОВНЮЄ КОД (25.09.2026, зміна 643).

🩸 КОРІНЬ. Каспер, закупівля UA-2026-09-21-015529-A. Оркестратор віддав пакет, у якому
на місці Пропозиції (Додаток 1), Додатка 2 і проєкту договору стояло «Заповнюється на
бланку Замовника … усі графи форми замовника». Текст цих бланків платформа вже
ПРОЧИТАЛА з документації — і не поклала його в пакет. Людина мусила знайти бланк у
документах замовника, переписати його й повписувати реквізити, які платформа знає.
Саша назвала пакет незадовільним; його довелось зібрати вручну.

⛒ ЗАКОН 643.
  1. Папір, для якого замовник дав СВІЙ бланк (Додаток N / Форма N / проєкт договору,
     на який вимога посилається як на ФОРМУ, а не як на місце вимог), лягає в пакет цим
     бланком — дослівно, з усіма реченнями, таблицями й примітками замовника.
  2. Графи УЧАСНИКА в ньому заповнює код з картки учасника: назва, код ЄДРПОУ, адреса,
     банк, керівник, підписант, телефон, пошта, «в особі …», «на підставі …». Графу
     впізнає ЇЇ ПІДПИС (слова поруч із прочерком), а не місце на сторінці.
  3. ІНШИЙ БІК, незмінно: цін, сум, дат, номерів договорів, країни походження і всього,
     чого платформа не знає, код НЕ ставить — прочерк лишається, і людина бачить перелік
     того, що лишилось. Графи ЗАМОВНИКА («***», його назва й підпис) не чіпаються.
  4. Межі бланка читає `clause_map.blocks` — той самий писар, що й нумерацію пунктів.

ЧОГО МОДУЛЬ НЕ РОБИТЬ. Не ходить у мережу, не кличе модель ($0), не вигадує реквізитів,
не тлумачить закон. Родовий відмінок «в особі …» складає лише за певним правилом; де
правило не певне — графа лишається порожньою (краще прочерк, ніж «Ігора»).
"""

import re

import clause_map

MARK = "<!-- БЛАНК ЗАМОВНИКА: %s -->"
MARK_RE = re.compile(r"<!--\s*БЛАНК ЗАМОВНИКА\b[^>]*-->")
SIGN_BLANK = "____________________"

# ── 1. ЧИ ЦЕЙ ПАПІР — БЛАНК ЗАМОВНИКА ────────────────────────────────────────────
# «Цінова пропозиція (Додаток № 2)», «оформлена відповідно Додатку № 3», «за формою
# згідно з додатком № 4», «у вигляді Додатку 1», «Заповнений Додаток № 2», «Підписаний
# Додаток 1» — посилання на додаток як на ФОРМУ. «…викладене в Додатку №3», «…визначені
# у додатку № 1», «…наведеним в Додатку 1» — посилання на МІСЦЕ ВИМОГ: там бланка немає.
_FREE = ("довільн", "вільній формі", "вільної форми", "власною формою")
_REF = re.compile(r"(додат\w*|форм[аиіу]?)\s*№?\s*(\d{1,2})\b", re.I)
_AS_FORM_BEFORE = re.compile(
    r"(?:відповідно|згідно|за\s+формою|у\s+вигляді|заповнен\w*|підписан\w*|оформлен\w*|"
    r"наданої\s+форми|у\s+відповідності\s+до\s+вимог)[^.;]{0,50}$", re.I)
_PLACE_BEFORE = re.compile(r"(?:викладен\w*|визначен\w*|наведен\w*|зазначен\w*|встановлен\w*)\s+"
                           r"(?:у|в)\s*$", re.I)
_OWN_PAREN = re.compile(r"^[^()]{3,160}?\(\s*(додат\w*|форм\w*)\s*№?\s*(\d{1,2})\b[^)]*\)", re.I)
_CONTRACT_PAPER = re.compile(r"^\W*(?:\d{1,2}(?:\.\d{1,2})*\.?\s*)?(?:підписан\w*\s+|заповнен\w*\s+)?"
                             r"(?:проєкт\w*|проект\w*)\s+договор", re.I)
_SIGNED = re.compile(r"підписан|заповнен|завіре", re.I)


def blank_ref(item: str, basis: str = "") -> tuple:
    """Ключ бланка замовника для паперу: ('додаток', N) / ('форма', N) / ('договір',) або ()."""
    text = re.sub(r"\s+", " ", "%s %s" % (item or "", basis or "")).strip()
    low = text.lower()
    if any(w in low for w in _FREE):
        return ()
    head = re.sub(r"\s+", " ", str(item or "")).strip()
    if _CONTRACT_PAPER.match(head) and _SIGNED.search(text):
        return ("договір",)
    import tender_skeleton as _ts
    if _ts.by_dictionary(head) == "учасник":
        return ()                               # копія/витяг «згідно з додатком» — папір учасника
    m = _OWN_PAREN.match(head)
    if m and not re.search(r"довідк|підтвердж|документ|копі", head[:m.start(1)], re.I):
        return (_kind(m.group(1)), int(m.group(2)))
    for m in _REF.finditer(text):
        before = text[max(0, m.start() - 70):m.start()]
        if _PLACE_BEFORE.search(before) and not re.search(r"форм\w*[^.;]{0,40}$", before, re.I):
            continue                             # «наведених у Додатку 1» — місце вимог, не бланк
        if _AS_FORM_BEFORE.search(before):
            return (_kind(m.group(1)), int(m.group(2)))
    return ()


def _kind(word: str) -> str:
    return "форма" if word.lower().startswith("форм") else "додаток"


def ref_label(key) -> str:
    if not key:
        return ""
    if key[0] == "договір":
        return "проєкт договору"
    return ("Форма %d" if key[0] == "форма" else "Додаток № %d") % key[1]


# ── 2. «В ОСОБІ ДИРЕКТОРА ОДИНЦОВА ІЛЛІ СЕРГІЙОВИЧА» ─────────────────────────────
_POST_GEN = {
    "директор": "директора", "генеральний директор": "генерального директора",
    "виконавчий директор": "виконавчого директора", "комерційний директор": "комерційного директора",
    "керівник": "керівника", "голова": "голови", "голова правління": "голови правління",
    "президент": "президента", "начальник": "начальника",
}
_CONS = "бвгґджзйклмнпрстфхцчшщ"
_MALE_GIVEN_EXC = {"ігор": "Ігоря", "лев": "Лева", "павло": "Павла", "петро": "Петра"}


def _cap(src: str, word: str) -> str:
    if src.isupper() and len(src) > 1:
        return word.upper()
    return word[:1].upper() + word[1:]


def _male_given(w: str) -> str:
    lw = w.lower()
    if lw in _MALE_GIVEN_EXC:
        return _cap(w, _MALE_GIVEN_EXC[lw])
    if lw.endswith("ій"):
        return w[:-1] + "я"
    if lw.endswith("й") or lw.endswith("ь"):
        return w[:-1] + "я"
    if lw.endswith("о"):
        return w[:-1] + "а"
    if lw.endswith("а"):
        return w[:-1] + "и"
    if lw.endswith("я") and len(lw) > 1 and lw[-2] in _CONS:
        return w[:-1] + "і"
    if lw[-1] in _CONS:
        return w + "а"
    return ""


def _female_given(w: str) -> str:
    lw = w.lower()
    if lw.endswith("ія"):
        return w[:-1] + "ї"
    if lw.endswith("я") and len(lw) > 1 and lw[-2] in _CONS:
        return w[:-1] + "і"
    if lw.endswith("а"):
        return w[:-1] + "и"
    if lw == "любов":
        return w + "і"
    return ""


def _male_surname(w: str) -> str:
    lw = w.lower()
    if re.search(r"(?:ськ|цьк|зьк)ий$", lw) or lw.endswith("ий"):
        return w[:-2] + "ого"
    if lw.endswith("ій"):
        return w[:-1] + "я"
    if re.search(r"(?:ов|ев|єв|ів|їв|ин|ін|їн)$", lw):
        return w + "а"
    if lw.endswith("о"):
        return w[:-1] + "а"
    if lw.endswith("а"):
        return w[:-1] + "и"
    if lw.endswith("ь") or lw.endswith("й"):
        return w[:-1] + "я"
    if lw[-1] in _CONS:
        return w + "а"
    return ""


def _female_surname(w: str) -> str:
    lw = w.lower()
    if re.search(r"(?:ськ|цьк|зьк)а$", lw):
        return w[:-1] + "ої"
    if re.search(r"(?:ов|ев|єв|ін|їн|ин)а$", lw):
        return w[:-1] + "ої"
    if lw.endswith("а"):
        return w[:-1] + "и"
    if lw[-1] in _CONS or lw.endswith("о"):
        return w
    return ""


def in_person_of(post: str, full_name: str) -> str:
    """«директор», «Одинцов Ілля Сергійович» -> «директора Одинцова Іллі Сергійовича».
    Правило не певне (посада не з переліку, немає по батькові, латиниця) -> ""."""
    p = re.sub(r"\s+", " ", str(post or "")).strip().lower()
    pg = _POST_GEN.get(p)
    parts = re.sub(r"\s+", " ", str(full_name or "")).strip().split(" ")
    if not pg or len(parts) != 3 or not all(re.fullmatch(r"[А-ЯІЇЄҐа-яіїєґʼ'\-]+", x) for x in parts):
        return ""
    sur, given, patr = parts
    lp = patr.lower()
    if re.search(r"(?:ович|евич|євич)$", lp):
        out = (_male_surname(sur), _male_given(given), patr + "а")
    elif re.search(r"(?:івна|ївна|овна)$", lp):
        out = (_female_surname(sur), _female_given(given), patr[:-1] + "и")
    else:
        return ""
    if not all(out):
        return ""
    return "%s %s" % (pg, " ".join(out))


# ── 3. ЗНАЧЕННЯ З КАРТКИ УЧАСНИКА ────────────────────────────────────────────────
def _quotes(name: str) -> str:
    t = re.sub(r"\s+", " ", str(name or "")).strip()
    m = re.match(r'^(.*?)["“”„]+(.+?)["“”]+\s*$', t)
    return ("%s«%s»" % (m.group(1), m.group(2))) if m else t


def values(req: dict, facts: dict = None) -> dict:
    import tender_fill
    import tender_skeleton as _ts
    req, facts = req or {}, facts or {}
    name = _quotes(req.get("name"))
    post = str(req.get("director_post") or "директор").strip()
    director = re.sub(r"\s+", " ", str(req.get("director") or "")).strip()
    signer = _ts.signer(req) if director else ""
    iban = str(req.get("iban") or "").strip()
    bank = str(req.get("bank") or "").strip()
    short = tender_fill.short_legal_name(name) if name else ""
    legal = ""
    m = re.match(r'^([^«"“]+?)\s*[«"“]', name)
    if m and short and short != name:
        legal = m.group(1).strip().lower()
    return {
        "name": name, "short": _quotes(short) or name,
        "edrpou": str(req.get("edrpou") or "").strip(),
        "address": str(req.get("address") or "").strip(),
        "phone": str(req.get("phone") or "").strip(),
        "email": str(req.get("email") or "").strip(),
        "iban": ("IBAN %s в %s" % (iban, bank)) if (iban and bank) else iban,
        "director": ("%s, %s" % (director, post.lower())) if director else "",
        "director_name": director,
        "post": post[:1].upper() + post[1:] if post else "",
        "signer": ("%s %s" % (post[:1].upper() + post[1:], signer)) if signer else "",
        "director_gen": in_person_of(post, director),
        "basis": "Статуту" if (legal and not short.upper().startswith("ФОП")) else "",
        "legal_form": legal,
        "tax": str(req.get("tax_status") or "").strip(),
        "buyer": str(facts.get("buyer") or "").strip(),
        "subject": str(facts.get("subject") or "").strip(),
        "sign_line": ("%s %s %s" % (post[:1].upper() + post[1:], SIGN_BLANK, signer)) if signer else "",
    }


# ── 4. ЯКА ЦЕ ГРАФА: ЇЇ ПІДПИС, А НЕ МІСЦЕ ───────────────────────────────────────
_NEVER = re.compile(
    r"підпис(?!ув)|печатк|\bм\.\s*п\.|\bдат[аиі]\b|^\W*дата|ціна|цін[иі]\b|\bсум[аиу]?\b|вартіст|\bгрн"
    r"|пдв|строк|термін|кількіст|к-ть|№\s*договор|договор\w*\s*№|податков\w*\s+номер|номер\s+свідоцтв"
    r"|свідоцтв|виробник|походженн|власник|бенефіціар|замовник|прописом|цифрами|коп\.", re.I)
_QUESTION = re.compile(r"\?\s*\W*$|^\W*(?:\d{1,2}\.\s*)?чи\b", re.I)
_EXTRA = re.compile(r"англійськ|веб-?сайт|громадянств|дата\s+утворення|спеціалізац", re.I)
_VOCAB = (
    ("buyer", re.compile(r"назв\w*\s+замовник|^\W*кому\W*$", re.I)),
    ("subject", re.compile(r"(?:назв|найменуванн)\w*\s+предмет", re.I)),
    ("director_gen", re.compile(r"(?:^|\s)в\s+особі\s*:?\s*$", re.I)),
    ("basis", re.compile(r"на\s+підставі\s*:?\s*$", re.I)),
)
_FIELDS = (
    ("edrpou", re.compile(r"єдрпоу|ідентифікаційн\w+\s+код|код\s+(?:в|у|за)\s+єдин|рнокпп", re.I)),
    ("name", re.compile(r"(?:назв|найменуванн)\w*\s+(?:\S+\s+){0,2}(?:учасник|підприємств|організац|"
                        r"суб.?єкт\w*\s+господар|постачальник)|^\W*(?:учасник|постачальник)\W*$|^\W*ми\W*$", re.I)),
    ("signer", re.compile(r"уповноважен\w+.{0,60}(?:підписув|представля)|посада,?\s*піб|піб,?\s*посада", re.I)),
    ("director", re.compile(r"керівник|прізвище,?\s+ім.я,?\s+по.батькові", re.I)),
    ("legal_form", re.compile(r"організаційно.правов", re.I)),
    ("tax", re.compile(r"систем\w+\s+оподаткув", re.I)),
    ("email", re.compile(r"e-?mail|е-?mail|електронн\w+\s+(?:адрес|пошт)", re.I)),
    ("phone", re.compile(r"телефон|\bтел\b|\bфакс", re.I)),
    ("iban", re.compile(r"iban|банківськ|розрахунков\w+\s+рахун|\bр/р|\bп/р", re.I)),
    ("address", re.compile(r"адрес|місцезнаходж", re.I)),
    ("post", re.compile(r"^\W*посада\W*$", re.I)),
)
_CONTACT = ("address", "phone", "email", "iban")


def field_of(label: str):
    """Графа за її підписом -> ['name'] / ['address', 'phone'] / [] (невідома) / None (ніколи)."""
    lab = re.sub(r"\s+", " ", str(label or "")).strip()
    if not lab:
        return []
    for f, rx in _VOCAB:
        if rx.search(lab):
            return [f]
    if re.search(r"підпис(?!ув)", lab, re.I) and re.search(r"посад|прізвищ|п\.?\s*і\.?\s*б|піб", lab, re.I):
        return ["sign"]
    if _NEVER.search(lab) or _QUESTION.search(lab):
        return None                             # ціна, дата, номер… і ПИТАННЯ: відповідь — рішення учасника
    hits = [f for f, rx in _FIELDS if rx.search(lab)]
    if "address" in hits and not re.search(r"адрес|місцезнаходж", re.sub(r"електронн\w*\s+адрес\w*", " ", lab,
                                                                           flags=re.I), re.I):
        hits.remove("address")                    # «електронна адреса» — це пошта
    if re.search(r"^\W*реквізит", lab, re.I) and "iban" not in hits:
        hits = ["address", "iban", "phone", "email"]
    if "name" in hits and "edrpou" in hits:
        return ["name", "edrpou"]               # «найменування учасника та код за ЄДРПОУ»
    contacts = [f for f in hits if f in _CONTACT]
    if len(contacts) >= 2:
        return [f for f in ("address", "phone", "email", "iban") if f in contacts]
    for f in ("edrpou", "name", "signer", "director", "legal_form", "tax", "email", "phone", "iban",
              "address", "post"):
        if f in hits:
            if f == "director" and "phone" in hits:
                return ["director", "phone"]
            return [f]
    return []


def _value(fields, v: dict, label: str = "") -> str:
    vals = [v.get(f) or "" for f in fields]
    if not fields or not all(vals):
        return ""
    if fields == ["name", "edrpou"]:
        out = "%s (код ЄДРПОУ %s)" % (vals[0], vals[1])
    elif fields == ["director", "phone"]:
        out = "%s, тел. %s" % (vals[0], vals[1])
    elif fields[0] in _CONTACT:
        pref = {"phone": "тел. ", "email": "e-mail: "}
        out = "; ".join((pref.get(f, "") + x) if len(fields) > 1 else x for f, x in zip(fields, vals))
    else:
        out = vals[0]
    if _EXTRA.search(label or ""):
        out += " " + SIGN_BLANK[:10]
    return out


# ── 5. ЗАПОВНЕННЯ ─────────────────────────────────────────────────────────────────
_RUN = re.compile(r"_{3,}")
_PAREN_AFTER = re.compile(r"^\s*\(((?:[^()]|\([^()]*\))*)\)")
_PURE_PAREN = re.compile(r"^\s*\(((?:[^()]|\([^()]*\))*)\)\s*$")
_ONLY_RUNS = re.compile(r"^[\s_.,;:|]*_{3,}[\s_.,;:|]*$")
_NAME_PH = re.compile(r"\((?:повн\w*\s+)?(?:назв\w*|найменуванн\w*)\s+(?:організації\s+)?учасник\w*[^)]{0,60}\)", re.I)
_INSTR = re.compile(r"подається\s+(?:учасником\s+)?на\s+(?:фірмовому\s+)?бланку|не\s+повинен\s+відступати\s+від",
                    re.I)
_SIGN_CAPTION = re.compile(r"^\W*(?:посада,?\s*прізвище|підпис\s+уповноважен|\(\s*підпис\s+уповноважен)", re.I)


def _tail(label: str, n: int = 90) -> str:
    t = re.sub(r"\s+", " ", str(label or "")).strip()
    return t[-n:]


def _fill_line(i, lines, v, used, left):
    """Один рядок поза таблицею. -> новий рядок (або None, якщо рядок поглинуто)."""
    line = lines[i]
    if not _RUN.search(line):
        m = _NAME_PH.search(line)
        if m and v.get("short"):
            used.add("name")
            return line[:m.start()] + v["short"] + line[m.end():]
        return line
    prev = lines[i - 1] if i > 0 else ""
    nxt = lines[i + 1] if i + 1 < len(lines) else ""
    only = bool(_ONLY_RUNS.match(line))
    if only and _SIGN_CAPTION.search(nxt or ""):
        return line                      # рядок підпису — його ставить обробник підпису
    if only and prev and _RUN.search(prev) and not _ONLY_RUNS.match(prev) and prev.rstrip().endswith("_"):
        # продовження графи попереднього рядка: графу заповнено — зайвий прочерк не лишаємо
        return None if ("__filled_%d" % (i - 1)) in used else line
    out, pos, runs = [], 0, list(_RUN.finditer(line))
    for k, r in enumerate(runs):
        before = line[(runs[k - 1].end() if k else 0):r.start()]
        after = line[r.end():(runs[k + 1].start() if k + 1 < len(runs) else len(line))]
        pa = _PAREN_AFTER.match(after)
        lab_after = pa.group(1) if pa else ""
        consumed_next = False
        if not lab_after and k == len(runs) - 1 and not after.strip(" .,;:") and _PURE_PAREN.match(nxt or ""):
            lab_after = _PURE_PAREN.match(nxt).group(1)
            consumed_next = True
        lab_before = before
        if only:
            lab_before = prev if prev and not _RUN.search(prev) else ""
        fb0 = field_of(_tail(lab_before, 40)) if lab_before else []
        if fb0 in (["director_gen"], ["basis"]):
            fields = fb0                       # «в особі ___», «на підставі ___» — вирішує зворот
        else:
            fields = field_of(lab_after) if lab_after else []
        if only and lab_before and _QUESTION.search(re.sub(r"\s+", " ", lab_before).strip()):
            fields = None                      # відповідь на питання анкети — рішення учасника
        elif fields == [] and lab_before is not None:
            fb = field_of(_tail(lab_before, 90 if only else 200))
            if fields == [] and fb is not None:
                fields = fb
            elif fb is None and not lab_after:
                fields = None
        label = lab_after or lab_before
        out.append(line[pos:r.start()])
        pos = r.end()
        if fields == ["sign"]:
            if v.get("sign_line") and "sign" not in used:
                used.add("sign")
                out.append(v["sign_line"])
                if consumed_next:
                    used.add("__drop_next__")
                continue
            out.append(r.group(0))
            continue
        val = _value(fields or [], v, label) if fields else ""
        if fields == ["name"] and re.search(r"(?:^|\s)(?:ми|щодо|про|від|для|у|в|з|із)\W*$", _tail(lab_before, 12), re.I):
            val = v.get("short") or val              # назва посеред речення — коротка форма (640)
        if val:
            used.update(fields)
            if out and out[-1] and not out[-1][-1].isspace() and out[-1][-1] not in "(«\"":
                val = " " + val
            out.append(val)
            if pa:
                pos = r.end() + pa.end()
            elif consumed_next:
                used.add("__drop_next__")
        else:
            out.append(r.group(0))
            left.append(_left_label(lab_after or lab_before))
    out.append(line[pos:])
    if runs and len(out) >= 2 and not _RUN.fullmatch(out[-2] or ""):
        used.add("__filled_%d" % i)
    return "".join(out)


_SUP_HEAD = re.compile(r"^\W*(?:постачальник|учасник|виконавець)\W*$", re.I)
_TOTAL_ROW = re.compile(r"сума|всього|усього|загальн|разом|ціна\s+товару\s+без", re.I)


def _cells(line: str) -> list:
    if line.startswith("|"):                   # Markdown «| a | b |» (так пише і сам документ)
        s = line.strip()[1:]
        if s.endswith("|"):
            s = s[:-1]
        return [c.strip() for c in s.split("|")]
    # документ замовника: « | a | b |  | » — порожня перша й остання клітинки теж клітинки
    return [c.strip() for c in line.rstrip().split("|")]


def _requisites(v: dict, with_sign: bool) -> str:
    rows = [v.get("name"), ("Код ЄДРПОУ %s" % v["edrpou"]) if v.get("edrpou") else "", v.get("address"),
            v.get("iban"), v.get("tax"), ("тел.: %s" % v["phone"]) if v.get("phone") else "",
            ("e-mail: %s" % v["email"]) if v.get("email") else ""]
    rows = [r for r in rows if r]
    if with_sign and v.get("sign_line"):
        rows += ["", v["sign_line"]]
    return "<br>".join(rows)


def _qty(facts: dict) -> tuple:
    m = re.match(r"^\s*(\d[\d\s]*)\s+(\S.*?)\s*$", str((facts or {}).get("quantity") or ""))
    return (m.group(1).replace(" ", ""), m.group(2)) if m else ("", "")


def _table(rows_lines, lead, v, facts, used, left) -> list:
    """Таблиця бланка -> рядки Markdown «| … |». lead — рядки над першим рядком, що
    належать його першій клітинці (реквізити сторони «Замовник» над «М.П. | Постачальник»)."""
    rows = [_cells(x) for x in rows_lines]
    if lead and rows:
        rows[0][0] = "<br>".join([x.strip() for x in lead] + ([rows[0][0]] if rows[0][0] else []))
    # колонка постачальника
    sup = None
    for r in rows:
        for j, c in enumerate(r):
            if _SUP_HEAD.match(c.split("<br>")[-1] if c else ""):
                sup = (rows.index(r), j)
                break
        if sup:
            break
    if sup:
        ri, j = sup
        later_sign = any(j < len(r) and _ONLY_RUNS.match(r[j] or "") for r in rows[ri + 1:])
        if v.get("name"):
            rows[ri][j] = rows[ri][j] + "<br>" + _requisites(v, with_sign=not later_sign)
            used.update(("name", "edrpou", "iban"))
        for r in rows[ri + 1:]:
            if j < len(r) and _ONLY_RUNS.match(r[j] or "") and v.get("sign_line"):
                r[j] = "%s %s" % (r[j].strip(), v["sign_line"].split(SIGN_BLANK)[-1].strip())
                used.add("sign")
    # таблиця товару: назва, одиниця, кількість — з картки закупівлі (ціни — ні)
    qty, unit = _qty(facts)
    subj = (facts or {}).get("subject") or ""
    for hi, h in enumerate(rows):
        low = [c.lower() for c in h]
        nc = next((k for k, c in enumerate(low) if re.search(r"найменуван|назва", c)), None)
        qc = next((k for k, c in enumerate(low) if re.search(r"кіль-?кість|кільк|к-ть", c)), None)
        if nc is None or qc is None or not (qty and subj):
            continue
        uc = next((k for k, c in enumerate(low) if re.search(r"од\.?\s*вим|одиниц|\bов\b", c)), None)
        data = rows[hi + 1:]
        items = [r for r in data if r and re.fullmatch(r"\d{1,2}\.?", r[0] or "")]
        if any(len(r) > nc and r[nc] for r in items):
            break                                   # товар уже вписав замовник
        if len(items) > 1:
            break
        if items:
            r = items[0]
        elif data and _TOTAL_ROW.search(" ".join(data[0])):
            r = [""] * len(h)
            r[0] = "1"
            rows.insert(hi + 1, r)
        else:
            break
        while len(r) < len(h):
            r.append("")
        r[nc] = subj
        r[qc] = qty
        if uc is not None:
            r[uc] = unit
        break
    # графи-підписи в клітинках: «Повне найменування учасника» | (значення)
    for r in rows:
        for j, c in enumerate(r):
            if not c or "<br>" in c or len(c) > 160 or _PURE_PAREN.match(c):
                continue
            nxt = r[j + 1] if j + 1 < len(r) else None
            if nxt not in (None, ""):
                continue
            f = field_of(c)
            if not f or f == ["sign"]:
                continue
            val = _value(f, v, c)
            if not val:
                continue
            used.update(f)
            if nxt is None:
                r.append(val)
            else:
                r[j + 1] = val
    # підписи під прочерками в таблиці: «____ | ____» над «(Прізвище…) | (Посада*)»
    for ri, r in enumerate(rows[:-1]):
        cap = rows[ri + 1]
        for j, c in enumerate(r):
            if not _ONLY_RUNS.match(c or "") or j >= len(cap):
                continue
            pm = _PURE_PAREN.match(cap[j] or "")
            if not pm:
                continue
            f = field_of(pm.group(1).replace("*", ""))
            if f == ["director"]:
                f = ["director_name"]
            val = _value(f, v) if f and f != ["sign"] else ""
            if val:
                used.update(f)
                r[j] = val
    out = []
    width = max(len(r) for r in rows) if rows else 0
    for k, r in enumerate(rows):
        out.append("| " + " | ".join(r) + " |")
        if k == 0:
            out.append("|" + " --- |" * max(width, 1))
    for r in rows:
        for c in r:
            if _RUN.search(c or "") and not re.search(r"ОДИНЦОВ|%s" % re.escape(v.get("sign_line", "") or "§§"), c):
                pass
    return out


_DATA_ROW = re.compile(r"^\s*\|?\s*\d{1,2}\.?\s*\|")
_HEAD_CELL = re.compile(r"№|з/п|п/п|найменуван|назва", re.I)


def _join_headers(lines: list) -> list:
    """Шапка таблиці, розірвана на кілька рядків (клітинки з переносами в документі
    замовника), збирається в ОДИН рядок — стільки клітинок, скільки в рядку товару під нею.
    Короткий рядок «№» над «з/п | …» — початок першої клітинки."""
    out = list(lines)
    k = 0
    while k < len(out):
        if not _DATA_ROW.match(out[k]):
            k += 1
            continue
        want = len(_cells(out[k]))
        done = False
        for s in range(k - 1, max(-1, k - 13), -1):
            if _DATA_ROW.match(out[s]):
                break
            if "|" not in out[s] or not _HEAD_CELL.search(_cells(out[s])[0] + " " + out[s]):
                continue
            cells = _cells(out[s])
            for ln in out[s + 1:k]:
                parts = _cells(ln) if "|" in ln else [ln.strip()]
                cells[-1] = (cells[-1] + "<br>" + parts[0]).strip("<br>") if parts[0] else cells[-1]
                cells += parts[1:]
            if len(cells) == want and k - s > 1:
                start = s
                if s > 0 and len(out[s - 1].strip()) <= 5 and "|" not in out[s - 1] and out[s - 1].strip():
                    cells[0] = out[s - 1].strip() + " " + cells[0]
                    start = s - 1
                out[start:k] = [" | ".join(cells)]
                k = start + 1
                done = True
                break
        if not done:
            k += 1
    # «№» над «з/п | …» без розриву шапки
    k = 1
    while k < len(out):
        if "|" in out[k] and re.match(r"^\s*\|?\s*(?:з/п|п/п)", out[k]) and out[k - 1].strip() in ("№", "№№"):
            out[k - 1:k + 1] = ["%s %s" % (out[k - 1].strip(), out[k].strip())]
            continue
        k += 1
    return out


def _vat_phrase(text: str, v: dict) -> str:
    t = (v.get("tax") or "").lower()
    non_vat = bool(re.search(r"без\s+пдв|не\s+є\s+платник\w*\s+пдв|неплатник", t)) or \
        ("єдин" in t and "платник пдв" not in t)
    if not non_vat:
        return ""
    m = re.search(r"не\s+є\s+платником\s+(?:податку\s+на\s+додану\s+вартість|ПДВ)[^«]{0,60}«([^»]{5,160})»",
                  text, re.I)
    return m.group(1).strip().rstrip(".") if m else ""


def fill(block_text: str, req: dict, facts: dict = None, key=()) -> dict:
    """Бланк замовника -> {"markdown", "left": [графи, що лишились], "used": {поля}}."""
    v = values(req, facts)
    raw = [ln.rstrip() for ln in str(block_text or "").splitlines()]
    lines = _join_headers([ln for ln in raw if ln.strip() and not _INSTR.search(ln)])
    phrase = _vat_phrase(block_text, v)
    used, left, out = set(), [], []
    i = 0
    while i < len(lines):
        ln = lines[i]
        if "|" in ln and len(_cells(ln)) >= 2:
            # таблиця: рядки з «|» і короткі рядки між ними (клітинка на кілька рядків)
            tab = [ln]
            j = i + 1
            while j < len(lines):
                if "|" in lines[j] and len(_cells(lines[j])) >= 2:
                    tab.append(lines[j])
                    j += 1
                    continue
                k = j
                while k < len(lines) and not ("|" in lines[k] and len(_cells(lines[k])) >= 2) and k - j < 40 \
                        and len(lines[k]) <= 120:
                    k += 1
                bound = any(clause_map._BOUND_RE.match(x.strip()) for x in lines[j:k])
                same = len(_cells(lines[k])) == len(_cells(tab[0])) if k < len(lines) else False
                wrap = (k - j == 1 and len(lines[j].strip()) <= 20)
                if k < len(lines) and k > j and "|" in lines[k] and len(_cells(lines[k])) >= 2 \
                        and not bound and (same or wrap):
                    last = _cells(tab[-1])
                    idx = max([n for n, c in enumerate(last) if c] or [len(last) - 1])
                    last[idx] = "<br>".join([last[idx]] + [x.strip() for x in lines[j:k]])
                    tab[-1] = " | ".join(last)
                    j = k
                    continue
                break
            lead = []
            cells0 = _cells(ln)
            if len(cells0) == 2 and _SUP_HEAD.match(cells0[1]) and len(cells0[0]) <= 20 \
                    and not re.search(r"замовник", cells0[0], re.I):
                b = len(out)
                while b > 0 and len(lead) < 8:
                    prev = out[b - 1]
                    if not prev.strip() or len(prev) > 80 or re.match(r"^\s*(?:\d{1,2}\.\s|[-•])", prev) \
                            or prev.startswith("|"):
                        break
                    lead.insert(0, prev)
                    b -= 1
                if lead and any(re.search(r"замовник", x, re.I) for x in lead):
                    del out[b:]
                else:
                    lead = []
            out += _table(tab, lead, v, facts, used, left)
            out.append("")
            i = j
            continue
        new = _fill_line(i, lines, v, used, left)
        if new is None:
            i += 1
            continue
        if phrase:
            new = re.sub(r"((?:у|в)\s+т\.?\s*ч\.?\s+ПДВ\*?)\s*_{3,}\s*грн\.?", r"\1 — " + phrase, new)
        if _SIGN_CAPTION.search(new) and v.get("sign_line") and "sign" not in used:
            # підпис замовник показав лише підписом графи — рядок підпису ставимо над ним
            if out and _ONLY_RUNS.match(out[-1]) and not (len(out) > 1 and re.match(r"^\s*\d{1,2}\.\s", out[-2])):
                out[-1] = v["sign_line"]
            else:
                out.append(v["sign_line"])
            used.add("sign")
            i += 1
            continue
        if _SIGN_CAPTION.search(new) and "sign" in used:
            i += 1
            continue
        out.append(new)
        if "__drop_next__" in used:
            used.discard("__drop_next__")
            i += 2
            continue
        i += 1
    if "sign" not in used and v.get("sign_line"):
        out += ["", v["sign_line"]]
    md = "\n\n".join(x for x in _paras(out))
    left += participant_marked(block_text, md)        # 644: графи «* Заповнюється Учасником»
    return {"markdown": md, "left": _uniq(left), "used": sorted(used - {"__drop_next__"})}


# ⭐⭐⭐ 644: ГРАФА, ЯКУ ПРИМІТКА БЛАНКА ВІДДАЄ УЧАСНИКУ. 🩸 Каспер, UA-2026-09-21-015529-A,
# Додаток 2: «Країна походження: *» і примітка «* Заповнюється Учасником». Прочерку немає —
# і графа не потрапила ні в «лишилось заповнити», ні в «заповнити перед подачею». Учасник
# подав би бланк із порожньою графою. ⛒ Позначку графи судить ПРИМІТКА самого бланка, а не
# форма прочерку; код такої графи НЕ заповнює (закон 643, п. 3) — лише називає.
_NOTE = re.compile(r"^\s*(\*{1,3})\s*(?:[-–—:]\s*)?(?:заповнюєтьс\w*|зазначаєтьс\w*|вказуєтьс\w*|вписуєтьс\w*"
                   r"|заповнює|зазначає|вказує)\s+(?:\w+\s+){0,2}учасник", re.I | re.M)


def participant_marked(block_text: str, md: str) -> list:
    """Назви граф, позначених зірочкою, яку примітка бланка віддає учаснику."""
    out = []
    for m in _NOTE.finditer(str(block_text or "")):
        star = re.escape(m.group(1))
        # рядок «Назва графи: *» (значення — лише позначка)
        for g in re.finditer(r"(?m)^\s*([^:|*\n]{3,60}?)\s*:\s*%s\s*$" % star, str(md or "")):
            out.append(g.group(1).strip().lower())
        # клітинка таблиці, у якій лише позначка -> назва її колонки
        head = None
        for r in str(md or "").splitlines():
            if not r.strip().startswith("|"):
                head = None                           # нова таблиця — нова шапка
                continue
            cells = [c.strip() for c in r.strip().strip("|").split("|")]
            if head is None:
                head = cells
                continue
            if set("".join(cells)) <= set("-: "):
                continue
            for k, c in enumerate(cells):
                if re.fullmatch(star, c) and k < len(head) and head[k]:
                    out.append(re.sub(r"<br>|\*", " ", head[k]).strip().lower())
    return out


def _paras(out):
    """Рядки бланка -> абзаци Markdown; таблиця лишається суцільною."""
    buf = []
    for ln in out:
        if ln.startswith("|"):
            buf.append(ln)
            continue
        if buf:
            yield "\n".join(buf)
            buf = []
        if ln.strip():
            yield ln
    if buf:
        yield "\n".join(buf)


def _left_label(label: str) -> str:
    """Що лишилось заповнити — словами людини, а не шматком речення замовника."""
    t = re.sub(r"[_*|]", " ", str(label or ""))
    if len(re.sub(r"[^A-Za-zА-Яа-яІіЇїЄєҐґ]", "", t)) < 3:
        return "дата" if re.search(r"[«»\"“”]", t) else "інші графи без підпису"
    if re.search(r"ціна|цін[иі]\b|\bсум[аиу]?\b|вартіст|\bгрн|гривен|коп|пдв|прописом|цифрами", t, re.I):
        return "ціни й суми"
    if re.search(r"\bдат[аиі]\b|«\s*_*\s*»|20\d\d\s*р", t, re.I) or not t.strip():
        return "дата" if t.strip() else "інші графи без підпису"
    if re.search(r"строк|термін", t, re.I):
        return "строки"
    if re.search(r"договор\w*\s*№|№", t, re.I):
        return "номер"
    return _tail(t, 60).strip(" ,.;:–—-(")


def _uniq(xs):
    seen, out = set(), []
    for x in xs:
        k = x.lower()
        if k not in seen:
            seen.add(k)
            out.append(x)
    return out


# ── 6. БЛАНКИ ПАКЕТА ─────────────────────────────────────────────────────────────
def bodies(checklist, makers=None, material: str = "", req: dict = None, facts: dict = None,
           skip=()) -> dict:
    """{позиція: розділ-бланк (Markdown з міткою)} для паперів, чий бланк замовник дав."""
    import tender_skeleton as _ts
    out = {}
    for it in checklist or []:
        if it in (skip or ()) or _ts.issued_by_state(it):
            continue
        basis = _ts.basis_of(it, makers)
        key = blank_ref(it, basis)
        if not key:
            continue
        b = clause_map.blank_for(material, key)
        if not b:
            continue
        r = fill(b["text"], req or {}, facts or {}, key)
        out[it] = {"key": key, "label": ref_label(b["key"] if b["key"][0] != "додаток договору" else key),
                   "markdown": r["markdown"], "left": r["left"], "used": r["used"],
                   "letterhead": bool(re.search(r"фірмовому\s+бланку|бланку\s+учасника", b["text"], re.I))}
    return out
