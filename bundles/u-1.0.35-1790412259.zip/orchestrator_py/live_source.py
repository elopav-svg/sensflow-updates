# -*- coding: utf-8 -*-
"""live_source.py — ЯКІ ФАЙЛИ НЕСУТЬ ЖИВИЙ ШЛЯХ ПРОГОНУ (зміна 640, 25.09.2026).

⭐ ОДИН ПИСАР ВІДПОВІДІ «ДЕ ЖИВЕ БОЙОВИЙ ШЛЯХ». Проби проводки (чи кличеться
ворота, чи передається досьє, у якому порядку) читали `executor.py` напряму.
Коли збирання тендерного пакета винесено в `tender_assemble.py` (640), усі
вони почервоніли б на КРАЩОМУ рішенні — або кожна вчила б нову адресу окремо.
Тепер адресу знає одне місце: винесеш ще щось — допиши сюди, і всі проби
побачать новий шлях разом.
"""
import ast
from pathlib import Path

HERE = Path(__file__).resolve().parent
# Порядок = порядок прогону: виконавець, потім збирання пакета.
LIVE_PATH = ("executor.py", "tender_assemble.py")


def text(names=LIVE_PATH) -> str:
    return "\n".join((HERE / n).read_text(encoding="utf-8") for n in names)


def tree(names=LIVE_PATH):
    return ast.parse(text(names))


# ⭐ 640: ХІД РОЗМОВИ В АГЕНТІ = обгортка `run` (вона віддає назовні підтверджене
# розуміння) + тіло ходу `_run_turn`. Проби, що шукають «що стоїть у гарячому шляху
# ходу», дивляться в ОБИДВІ — інакше перевірка стала б порожньою (обгортка чиста).
AGENT_TURN = ("run", "_run_turn")


def agent_turn_nodes():
    t = tree(("agent.py",))
    return [n for n in t.body if isinstance(n, ast.FunctionDef) and n.name in AGENT_TURN]
