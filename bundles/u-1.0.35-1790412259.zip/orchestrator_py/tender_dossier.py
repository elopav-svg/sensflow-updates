# -*- coding: utf-8 -*-
"""tender_dossier.py — ДОСЬЄ УЧАСНИКА: ЩО ЗА ФАЙЛИ ЛЕЖАТЬ У ТЕЦІ КЛІЄНТА.

⭐⭐⭐ 24.09.2026, зміна 636. КЛАС «ЗНАННЯ УЧАСНИКА Є — У ПАКЕТ НЕ ЛЯГЛО».
🩸 Каспер, пакет UA-2026-09-21-015529-A: статут, витяг з ЄДР, наказ, протокол,
витяг платника єдиного податку, п'ять аналогічних договорів і сертифікат лежали
в теці `knowledge_packs\\tender_casper\\Матеріали про товар\\` — а пакет по кожному
з них писав «додає учасник». Код брав із цих файлів лише реквізити; ЩО це за
документи і від якої вони дати, не знав ніхто.

⛒ ЗАКОН ЦЬОГО МОДУЛЯ:
  1. Кожен файл отримує ТИП і ДАТУ документа. Тип — спершу з назви (тендерист
     називає файли чітко), потім із тексту. Не видно ні там, ні там — тип
     ПОРОЖНІЙ. Скан без тексту з назвою «scan_0001» — це «не знаю», а не здогад.
  2. ПОСТІЙНИЙ документ учасника (статут, витяги, наказ, протокол, договори,
     сертифікат) вкладається в пакет під вимогу замовника. ЗРАЗОК — лист, який
     тендерист уже писав ІНШОМУ замовнику (гарантійний лист, довідка, таблиця
     відповідності, технічна специфікація), — у новий пакет НЕ вкладається
     НІКОЛИ: він адресований чужій військовій частині й має чужий номер.
  3. Свіжість: якщо замовник вимагає документ не раніше дати оголошення, а наш
     старший — пакет каже «замовте свіжий», а не вкладає мовчки. Дати не
     знаємо — теж кажемо, а не вдаємо, що все гаразд.
  4. Модуль лише ЧИТАЄ теку клієнта. Нічого в ній не пише й не переносить.
"""

import os
import re

# ⛒ 638: адреса пакета одна (config.TENDER_PACK_DIR через tender_materials).
# Тихий запасний шлях тут був другою відповіддю на те саме питання — прибрано.
import tender_materials as _tm
MATERIALS_DIR = _tm.MATERIALS_DIR

KIND_KEEP = "постійний"      # вкладається в пакет
KIND_SAMPLE = "зразок"       # лист під інший тендер — лише взірець
KIND_BLANK = "бланк"         # фірмовий бланк клієнта для листів

# ТИП -> (ознаки в НАЗВІ файла, ознаки на ПОЧАТКУ тексту). Порядок має значення:
# «Довідка щодо виконання аналогічного договору» — довідка, а не договір;
# «Гарантійний лист» — лист, а не довідка.
TYPES = (
    ("гарантійний лист", ("гарантійн",), ("гарантійний лист",)),
    ("таблиця відповідності", ("таблиця відповідн", "таблиця відповiдн"), ("таблиця відповідності",)),
    ("технічна специфікація", ("технічна специфікац", "техн. специфікац", "технічні вимоги"),
     ("технічна специфікація",)),
    ("довідка", ("довідк",), ("довідка",)),
    ("бланк", ("бланк",), ()),
    ("статут", ("статут",), ("статут",)),
    ("витяг ЄДР", ("єдр", "едр", "єдиного державного реєстру"),
     ("витяг з єдиного державного реєстру",)),
    ("витяг платника податку", ("єдиний податок", "єдиного податку", "платника податку",
                                "платника пдв", "реєстру платників"),
     ("реєстру платників єдиного податку", "платника єдиного податку",
      "реєстру платників податку на додану вартість")),
    ("наказ", ("наказ",), ("наказ",)),          # уточнюється `_order_kind` (639)
    ("протокол випробувань", ("протокол випроб", "протокол випр"), ("протокол випробувань",)),
    ("протокол", ("протокол",), ("протокол",)),
    ("аналогічний договір", ("аналогічн", "видатков"), ()),
    ("сертифікат", ("сертифікат", "висновок"), ("сертифікат",)),
    # ⭐ 644: ліцензія з досьє вкладається замість листа-роз’яснення (лист про ліцензію — не вона)
    ("ліцензія", ("ліценз", "дозвіл на"), ("ліцензія",)),
)
SAMPLE_TYPES = ("гарантійний лист", "таблиця відповідності", "технічна специфікація", "довідка")

# ⭐⭐⭐ 24.09.2026, зміна 639. ТИП ВИМОГИ — ЦЕ ПЕРШИЙ НАЗВАНИЙ У НІЙ ПАПІР, А НЕ
# БУДЬ-ЯКЕ СЛОВО В ХВОСТІ. 🩸 Каспер (живий прогін 638): «Інформація про наявність
# антикорупційної програми та НАКАЗ про призначення уповноваженого» отримала
# «3. Наказ директор.pdf» — наказ про призначення ДИРЕКТОРА; «Довідка з ЄДР» (графа
# Форми 2) і «Інформаційні довідки з Єдиного державного реєстру осіб, які вчинили
# корупційні…» впізнавались як «витяг з ЄДР» за словами «єдиного державного
# реєстру». Перелік слів «хоч де в рядку» ловив БУКВУ, а не папір.
# ⛒ ЗАКОН: (1) тип вимоги — папір, названий у рядку ПЕРШИМ; (2) якщо першим
# названо довідку чи лист — це інший папір, і скан із досьє його не підміняє;
# (3) «наказ» має ПРЕДМЕТ: наказ про призначення керівника — один документ, будь-
# який інший наказ — інший, і сам по собі в пакет не підставляється; (4) ЄДР — це
# реєстр ЮРИДИЧНИХ ОСІБ, а не будь-який «єдиний державний реєстр».
_REQ_RULES = (
    ("статут", r"\bстатут"),
    ("витяг ЄДР", r"\bєдр\b|\bедр\b|реєстр\w*\s+юридичних\s+осіб"),
    # ⚠ корінь, а не словоформа: «платника податків», «єдиного податку» (живий прогін 639)
    ("витяг платника податку", r"єдин\w*\s+подат|платник\w*\s+подат"
                               r"|платник\w*\s+пдв|реєстр\w*\s+платник"),
    ("наказ", r"\bнаказ"),
    ("протокол випробувань", r"\bпротокол\w*\s+випроб"),
    ("протокол", r"\bпротокол"),
    ("аналогічний договір", r"аналогічн"),
    ("сертифікат", r"\bсертифікат|\bвисновок"),
    ("ліцензія", r"\bліценз|дозвільн\w*\s+характер"),
)
# Перший названий папір — ІНШИЙ: довідку чи лист платформа або пише, або їх видає
# держава, але скан постійного документа з досьє їх НЕ підміняє.
_OTHER_PAPER = r"\bдовідк|\bлист\b|\bлиста\b|гарантійн"
APPOINT_ORDER = "наказ про призначення керівника"
_HEAD_OF = r"директор|керівник"


def _order_kind(text_after: str) -> str:
    """Предмет наказу: призначення керівника — або інший наказ ("")."""
    return APPOINT_ORDER if re.search(_HEAD_OF, _low(text_after)[:90]) else ""

_FRESH = ("не раніше", "станом на дату", "чинн", "актуальн", "не старш", "дійсн")
_SKIP = (".tmp", ".part", "desktop.ini", "thumbs.db")
_DATE = r"(\d{2})[._\-/](\d{2})[._\-/](\d{4})"


def _low(s) -> str:
    return str(s or "").lower().replace("’", "'").replace("ʼ", "'")


def _date(d, m, y) -> str:
    try:
        di, mi, yi = int(d), int(m), int(y)
        if 1 <= di <= 31 and 1 <= mi <= 12 and 1990 <= yi <= 2100:
            return "%02d.%02d.%04d" % (di, mi, yi)
    except Exception:
        pass
    return ""


def type_of(name: str, text: str = "") -> str:
    """Тип документа: назва, потім текст. Не знаємо — порожній рядок."""
    base = _low(os.path.splitext(os.path.basename(name or ""))[0])
    for t, name_words, _txt in TYPES:
        if t == "ліцензія" and re.search(r"\bлист", base):
            continue                              # 644: лист про ліцензію — не ліцензія
        if any(w in base for w in name_words):
            if t == "аналогічний договір" and "договір" not in base and "договор" not in base \
                    and "накладн" not in base:
                continue
            if t == "наказ":
                # 639: предмет наказу — з назви файла, потім з тексту.
                return _order_kind(base[base.find("наказ"):]) or \
                    _order_kind(_low(text)[:600]) or "наказ"
            return t
    head = _low(text)[:600]
    if head.strip():
        for t, _nw, txt_words in TYPES:
            if any(w in head for w in txt_words):
                if t == "наказ":
                    return _order_kind(head[head.find("наказ"):]) or "наказ"
                return t
    return ""


def kind_of(doc_type: str) -> str:
    if not doc_type:
        return ""
    if doc_type == "бланк":
        return KIND_BLANK
    return KIND_SAMPLE if doc_type in SAMPLE_TYPES else KIND_KEEP


def date_of(name: str, text: str = "") -> str:
    """Дата ДОКУМЕНТА, а не файла. Витяг — дата формування; лист — «від»; інакше з назви."""
    t = str(text or "")
    for pat in (r"формування\s+витягу[^0-9]{0,40}(?:\d+\s*,\s*)?" + _DATE,
                r"станом\s+на\s+" + _DATE):
        m = re.search(pat, t, re.IGNORECASE)
        if m:
            d = _date(*m.groups()[-3:])
            if d:
                return d
    m = re.search(_DATE, os.path.basename(name or ""))
    if m:
        d = _date(*m.groups())
        if d:
            return d
    m = re.search(r"\bвід\s+" + _DATE, t[:400], re.IGNORECASE)
    if m:
        return _date(*m.groups())
    return ""


def _pages(path: str) -> int:
    if not path.lower().endswith(".pdf"):
        return 0
    try:
        import pypdf
        with open(path, "rb") as fh:          # 639: файл закривається — на Windows це замок
            return len(pypdf.PdfReader(fh).pages)
    except Exception:
        return 0


def _text(path: str) -> str:
    try:
        import filetext
        with open(path, "rb") as fh:
            t = filetext.extract_text(os.path.basename(path), fh.read())
        if filetext.is_unreadable(t) or t.startswith("[pdf ") or t.startswith("[помилка"):
            return ""
        return t
    except Exception:
        return ""


def _order(name: str):
    """Природний порядок «1, 2, … 9.1, 9.2, 10» — як пронумерував тендерист."""
    return [int(x) if x.isdigit() else x for x in re.split(r"(\d+)", _low(name))]


def scan(folder: str = None) -> list:
    """Досьє теки: [{file, path, type, kind, date, pages}]. Лише читає."""
    folder = folder or MATERIALS_DIR
    out = []
    if not os.path.isdir(folder):
        return out
    for root, _dirs, names in os.walk(folder):
        for nm in names:
            low = nm.lower()
            if low.startswith("~$") or low.endswith(_SKIP):
                continue
            path = os.path.join(root, nm)
            if not os.path.isfile(path):
                continue
            text = _text(path)
            t = type_of(nm, text)
            out.append({"file": nm, "path": path, "type": t, "kind": kind_of(t),
                        "date": date_of(nm, text), "pages": _pages(path)})
    out.sort(key=lambda e: _order(e["file"]))
    return out


def blank(dossier) -> str:
    """Шлях до фірмового бланка клієнта (docx), якщо він лежить у досьє."""
    for e in dossier or []:
        if e.get("kind") == KIND_BLANK and str(e.get("file", "")).lower().endswith(".docx"):
            return e.get("path") or ""
    return ""


def type_for_requirement(requirement: str) -> str:
    """Тип постійного документа, який вимагає рядок, або "" (див. закон 639 вище)."""
    low = _low(requirement)
    first = None                                   # (позиція, -довжина, тип)
    for t, pat in _REQ_RULES + (("", _OTHER_PAPER),):
        m = re.search(pat, low)
        if m:
            cand = (m.start(), -(m.end() - m.start()), t)
            if first is None or cand < first:
                first = cand
    if first is None or not first[2]:
        return ""
    t = first[2]
    if t == "наказ":
        return _order_kind(low[first[0]:])        # інший наказ сам не підставляється
    return t


def match(requirement: str, dossier) -> list:
    """Файли з досьє під вимогу замовника. Лише ПОСТІЙНІ документи; зразок — ніколи."""
    t = type_for_requirement(requirement)
    if not t:
        return []
    return [e for e in (dossier or []) if e.get("type") == t and e.get("kind") == KIND_KEEP]


def _as_tuple(d: str):
    m = re.match(r"^(\d{2})\.(\d{2})\.(\d{4})$", str(d or "").strip())
    return (int(m.group(3)), int(m.group(2)), int(m.group(1))) if m else None


def freshness(entry: dict, requirement: str, announced: str = "", created: str = "") -> str:
    """Попередження про свіжість або "". Замовник свіжості не вимагає — мовчимо.

    ⭐ 640: НЕВІДОМА ДАТА ОГОЛОШЕННЯ — НЕ «ВСЕ ГАРАЗД». `created` — дата створення
    закупівлі з її номера (UA-2026-09-21-…): оголошують її не раніше, тож документ,
    старший за цю дату, точно старший і за оголошення. Коли не відомо ні того, ні того,
    людина чує прохання звірити, а не мовчання."""
    low = _low(requirement)
    if not any(w in low for w in _FRESH):
        return ""
    name = (entry or {}).get("file") or "документ"
    date = (entry or {}).get("date") or ""
    if not date:
        return ("⚠ Дату документа «%s» платформа не визначила, а замовник вимагає свіжий "
                "документ. Перевірте дату і за потреби замовте свіжий." % name)
    a, d, c = _as_tuple(announced), _as_tuple(date), _as_tuple(created)
    if a and d and d < a:
        return ("⚠ «%s» від %s старший за дату оголошення закупівлі %s, а замовник вимагає "
                "документ не раніше неї — замовте свіжий." % (name, date, announced))
    if not a and c and d and d < c:
        return ("⚠ «%s» від %s старший навіть за дату створення закупівлі %s (оголошено її не "
                "раніше), а замовник вимагає документ не раніше дати оголошення — замовте "
                "свіжий." % (name, date, created))
    if not a and d:
        return ("⚠ Замовник вимагає документ, свіжий на дату оголошення; дату оголошення "
                "платформа не знає — звірте: «%s» від %s." % (name, date))
    return ""


def describe(entry: dict) -> str:
    """Людський рядок про файл: «1. Статут.pdf (13 стор., від 16.06.2026)»."""
    bits = []
    if entry.get("pages"):
        bits.append("%d стор." % entry["pages"])
    if entry.get("date"):
        bits.append("від %s" % entry["date"])
    return "%s%s" % (entry.get("file", ""), (" (%s)" % ", ".join(bits)) if bits else "")
