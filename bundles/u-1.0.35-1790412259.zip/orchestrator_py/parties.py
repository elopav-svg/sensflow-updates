# -*- coding: utf-8 -*-
"""parties.py — ДОВІДНИК КОНТРАГЕНТІВ (клієнтська база).

⭐⭐⭐ КОРІНЬ 12.08.2026 (зміна 167, слово Андрія).
«Клієнтська база — окрема сутність, яка є джерелом для решти. Це фундаментальний
скарб компанії.» До сьогодні такої сутності не існувало: був файл `crm/clients.json`,
де в одному обʼєкті лежали КОНТРАГЕНТ, ЛІЦЕНЗІЯ, УГОДА і СТАДІЯ ПРОДАЖУ, а ключем
картки був РЯДОК НАЗВИ. Дві біди з цього:

  1. **Перейменування розривало історію.** ФОП став ТОВ — і всі попередні записи
     від'єднались, бо шукали за назвою (`crm.resolve`).
  2. **Рішення людини підмінював дефолт коду.** `inbound.from_email` на будь-який
     невідомий лист САМ створював картку — тобто кнопку менеджера обходили, а базу
     засмічували розсилки.

ЩО РОБИТЬ ЦЕЙ ФАЙЛ І ЧОГО НЕ РОБИТЬ:
  • тримає СТАБІЛЬНИЙ номер контрагента (`p0007`), який не міняється НІКОЛИ —
    саме він поїде в загальний протокол платформи;
  • тримає ТИП (особа / компанія) і РОЛІ (клієнт / постачальник / партнер).
    ⭐ Ролей може бути кілька: одна компанія буває водночас клієнтом і
    постачальником. Три окремі кошики змусили б заводити її двічі — і історія
    розійшлась би на дві половини (рішення Андрія 12.08);
  • тримає «ручки», за якими контрагента ВПІЗНАЮТЬ: пошта, телеграм, телефон, ЄДРПОУ;
  • ⛔ НЕ знає ні про угоди, ні про ліцензії, ні про стадії продажу — це справа
    картки CRM. Довідник живе роками, угоди приходять і йдуть.

ЗАКРИТІ СЛОВНИКИ (урок зміни 162). Тип, роль і вид «ручки» беруться лише зі списків
нижче. Невідоме слово — ВІДМОВА з причиною, а не тиха підстановка сусіднього.

ОДНА РУЧКА — ОДИН КОНТРАГЕНТ. Спроба привʼязати чужу пошту до другої картки — відмова
з номером того, кому вона вже належить. Дублікати в клієнтській базі коштують дорожче,
ніж незручність відмови.

Файл: `crm/parties.json`. Шлях лежить у змінній модуля — чек підміняє її й не сміє
писати в бойову теку (той самий прийом, що з `audit._PATH`).
"""

import json
import one_writer
import re

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import entity                     # спільне імʼя сутності на всю платформу
import protocol                   # ЗАГАЛЬНИЙ журнал усіх дій (хребет, 13.08.2026)

DIR = config.CRM_DIR
PARTIES_JSON = DIR / "parties.json"

# ── Закриті словники ─────────────────────────────────────────────────────────
KIND_PERSON = "person"
KIND_COMPANY = "company"
KIND_UNKNOWN = ""                 # ще не сказали; питає екран, а не вгадує код
KINDS = (KIND_UNKNOWN, KIND_PERSON, KIND_COMPANY)
KIND_NAMES = {KIND_UNKNOWN: "не вказано", KIND_PERSON: "фізична особа",
              KIND_COMPANY: "компанія"}

ROLE_CLIENT = "client"
ROLE_SUPPLIER = "supplier"
ROLE_PARTNER = "partner"
# ⭐ КРОК B5 (15.08.2026): контактна особа компанії — теж контрагент, але вона нам
# нічого не продає і нічого в нас не купує. Записати її «клієнтом», щоб пройти
# перевірку ролей, означало б брехню в даних: Одинцов не наш клієнт, він директор
# нашого клієнта. Тому — власна роль, і саме за нею перелік бази її ховає.
ROLE_CONTACT = "contact"
ROLES = (ROLE_CLIENT, ROLE_SUPPLIER, ROLE_PARTNER, ROLE_CONTACT)
ROLE_NAMES = {ROLE_CLIENT: "клієнт", ROLE_SUPPLIER: "постачальник",
              ROLE_PARTNER: "партнер", ROLE_CONTACT: "контактна особа"}

# ── АРХІВ КОНТРАГЕНТА (крок D3, 16.08.2026) ─────────────────────────────────
# ⭐⭐⭐ КОРІНЬ: Андрій узгодив групову дію «архівувати». Але в довіднику архіву
# НЕ БУЛО ЗОВСІМ — він був лише в угод. Кнопка, за якою нічого не стоїть, — це
# не дія, а обіцянка без покриття: людина натискає «архівувати 700 карток», і
# з базою не відбувається НІЧОГО.
#
# ⛒ ЧОМУ АРХІВ, А НЕ ВИДАЛЕННЯ. Контрагент — актив компанії: за ним стоять
# угоди, листи, рядки протоколу. Видалити його гуртом означало б обірвати
# історію, яку вже не відновити. Архів прибирає картку з ОЧЕЙ, лишаючи все
# інше на місці, — і саме тому дорога назад обовʼязкова: архів без повернення
# є тим самим видаленням, тільки під мʼякшим словом.
#
# ⚠ ЗБЕРІГАЄМО ЯК В УГОД (`deals.archived`) — щоб два різні реєстри однієї
# платформи не називали ту саму річ двома словами.
F_ARCHIVED = "archived"

H_EMAIL = "email"
H_TG_ID = "telegram_id"
H_TG_USER = "telegram_user"
H_PHONE = "phone"
H_EDRPOU = "edrpou"
HANDLE_KINDS = (H_EMAIL, H_TG_ID, H_TG_USER, H_PHONE, H_EDRPOU)
HANDLE_NAMES = {H_EMAIL: "пошта", H_TG_ID: "телеграм", H_TG_USER: "телеграм-імʼя",
                H_PHONE: "телефон", H_EDRPOU: "ЄДРПОУ"}

# ── БАЗОВИЙ ШАР: ЩО ЗНАЄ ПРО КОНТРАГЕНТА САМ КОНТАКТ (крок B1, 14.08.2026) ────
# ⭐⭐⭐ КОРІНЬ (шарова модель, слово Андрія 14.08): контакт живе РОКАМИ і
# переживає всі угоди. До сьогодні профіль, контактні особи, досьє й уся історія
# спілкування лежали в КАРТЦІ-УГОДІ (`crm/clients.json`), ключем якої був рядок
# назви. Наслідок бачив кожен: Борис Мамлін мав ДВІ картки з тим самим `p0004`,
# профіль слово в слово однаковий, а історія розділена 7 + 4 — половина розмови
# в одному місці, половина в іншому.
#
# ⛒ ЗАКОН ШАРУ: ХТО ЦЕЙ КОНТРАГЕНТ — знає КОНТАКТ; ЩО МИ ЙОМУ ПРОДАЄМО —
# знає УГОДА. Профіль, особи, ручки, досьє й історія спілкування — тут.
# Стадія, гроші, наступна дія, ліцензія, набір систем — лишаються на картці.
#
# ⚠ ПИСАР ОДИН. `crm.py` більше НЕ дописує історію й не править профіль сам —
# він кличе ці функції. Два писарі на одне поле і дали сьогоднішню біду.
PROFILE_FIELDS = ("org", "region", "industry", "website", "phone", "email",
                  "address", "about")
CONTACT_FIELDS = ("name", "role", "phone", "email", "note")

# Підпис каналу вхідного — той самий, що показувала картка до переїзду.
CHANNEL_NAMES = {"telegram": "Telegram", "email": "Пошта"}


class PartyError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


# ── Сховище ──────────────────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(PARTIES_JSON)
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("seq", 0)
    d.setdefault("parties", {})
    return d


def _save(d: dict) -> None:
    PARTIES_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(PARTIES_JSON, d)


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


# ── Ручки: нормалізація і пошук ──────────────────────────────────────────────
# ⭐⭐⭐ 648 (26.09.2026). ТОЙ САМИЙ НОМЕР — ОДНА РУЧКА, ХОЧ ЯК ЙОГО ЗАПИСАЛИ.
# 🩸 «067 123-45-67» і «+380 67 123 45 67» — один телефон, а довідник бачив ДВА:
# «+0671234567» і «+380671234567». Наслідок — дубль клієнта, якого ніхто не
# помітить, і дзвінок/лист, що не впізнає свого клієнта. Знайдено, коли бот почав
# заводити клієнтів із телефона: менеджер пише номер так, як звик.
# ⛒ ПРАВИЛО НОМЕРНОГО ПЛАНУ, А НЕ ПЕРЕЛІК ЗАПИСІВ: «00» на початку — міжнародний
# вихід (прибираємо); одна «0» на початку при національній довжині — магістральний
# префікс країни платформи (замінюємо кодом країни). Країна — налаштування
# (`SENSFLOW_PHONE_CC`, типово Україна 380; національний номер 9 цифр).
PHONE_CC = re.sub(r"\D", "", str(config.ENV.get("SENSFLOW_PHONE_CC") or "")) or "380"
PHONE_NSN = 9


def _norm_phone(value) -> str:
    digits = re.sub(r"\D", "", _s(value))
    if digits.startswith("00"):
        digits = digits[2:]
    elif digits.startswith("0") and len(digits) == PHONE_NSN + 1:
        digits = PHONE_CC + digits[1:]
    return ("+" + digits) if digits else ""


def _same(kind: str, stored, needle: str) -> bool:
    """Чи збережена ручка — та сама, що шукана. ⛒ Збережене теж нормалізуємо:
    номер, записаний до 648 як «+0671234567», мусить упізнаватись за
    «+380671234567» без жодного переписування бази."""
    try:
        return norm_handle(kind, stored) == needle
    except PartyError:
        return False


def norm_handle(kind: str, value) -> str:
    """Однакова ручка, записана по-різному, мусить збігтися. Невідомий вид — відмова."""
    kind = _s(kind)
    if kind not in HANDLE_KINDS:
        raise PartyError("Невідомий вид ручки «%s». Відомі: %s."
                         % (kind, ", ".join(HANDLE_KINDS)))
    v = _s(value)
    if not v:
        return ""
    if kind == H_EMAIL:
        return v.lower()
    if kind == H_TG_USER:
        return v.lstrip("@").lower()
    if kind == H_TG_ID:
        return v
    if kind == H_PHONE:
        return _norm_phone(v)
    if kind == H_EDRPOU:
        return re.sub(r"\D", "", v)
    return v


def _handles_of(p: dict) -> dict:
    h = dict(p.get("handles") or {})
    for k in HANDLE_KINDS:
        h.setdefault(k, [])
        if not isinstance(h[k], list):
            h[k] = [h[k]] if h[k] else []
    return h


def find(value, kind: str = "") -> str:
    """Номер контрагента за будь-якою ручкою. Порожньо — якщо такого немає."""
    v = _s(value)
    if not v:
        return ""
    kinds = (kind,) if _s(kind) else HANDLE_KINDS
    d = _load()
    for hk in kinds:
        try:
            needle = norm_handle(hk, v)
        except PartyError:
            continue
        if not needle:
            continue
        for pid, p in d["parties"].items():
            if any(_same(hk, x, needle) for x in _handles_of(p).get(hk, [])):
                return pid
    return ""


def handles_summary(pid) -> dict:
    """ЗА СКІЛЬКОМА РУЧКАМИ МИ ВПІЗНАЄМО ЦЬОГО КОНТРАГЕНТА.

    ⭐ Дубль - це не сміття, а СИГНАЛ (розбір CareerSwift, 27.08.2026). Картка,
    що зійшлась за поштою, телеграмом і ЄДРПОУ, каже не про склеювання, а про
    те, наскільки повно ми знаємо людину: вхідне від неї впізнається трьома
    різними дорогами, і жодна зміна номера телефону нас не осліпить.

    ⛒ РАХУЄМО ТИМИ САМИМИ РУЧКАМИ, ЯКИМИ ВПІЗНАЄ `find()`. Другий перелік
    (на екрані чи тут) розійшовся б із першим назавтра - саме через це екран
    роками тримав свою копію словника.

    ⛒ ПОХІДНЕ. Нічого не пишемо на диск: перерахунок щоразу з тих самих карток.

    Повертає: known - за скількома ручками впізнаємо; total - скільки їх узагалі
    буває; kinds - які саме (у порядку словника); names - словник назв для екрана.
    """
    p = get(pid) if isinstance(pid, str) else dict(pid or {})
    h = _handles_of(p)
    # ⛒ Ручка є лише тоді, коли в ній щось СТОЇТЬ. Порожній рядок у списку —
    # це дорога, якою вхідне не впізнається ніколи, і рахувати її означало б
    # сказати людині «2 з 5» там, де насправді одна.
    have = [k for k in HANDLE_KINDS
            if any(_s(v) for v in (h.get(k) or []))]
    return {"known": len(have), "total": len(HANDLE_KINDS), "kinds": list(have),
            "order": list(HANDLE_KINDS), "names": dict(HANDLE_NAMES)}


def owner_of_handle(kind: str, value) -> str:
    """Кому вже належить ця ручка (для чесної відмови при спробі дубля)."""
    needle = norm_handle(kind, value)
    if not needle:
        return ""
    for pid, p in _load()["parties"].items():
        if any(_same(kind, x, needle) for x in _handles_of(p).get(kind, [])):
            return pid
    return ""


# ── Читання ──────────────────────────────────────────────────────────────────
def get(pid: str) -> dict:
    return dict(_load()["parties"].get(_s(pid)) or {})


def exists(pid: str) -> bool:
    return _s(pid) in _load()["parties"]


def is_archived(p) -> bool:
    """Чи прибрана картка в архів.

    ⛒ ОДИН ЧИТАЧ НА ВЕСЬ ПРОДУКТ. Картки, заведені до 16.08.2026, поля не
    мають зовсім — і кожне місце, яке читало б `p["archived"]` саме, або
    падало б, або мовчки вважало відсутність «правдою». Відсутність поля
    означає РІВНО «жива картка», і це сказано в одному місці."""
    if isinstance(p, str):
        p = get(p)
    return bool((p or {}).get(F_ARCHIVED))


def all_parties(role: str = "", kind: str = "", archived=None,
                sift: bool = True) -> list:
    """Уся база; за потреби — лише одна роль, один тип або один стан.

    ⚠ `archived=None` — УСІ, як було до 16.08.2026: жоден старий виклик не
    сміє мовчки почати бачити менше, ніж бачив учора. Хто хоче лише живих —
    каже це вголос (`archived=False`)."""
    role, kind = _s(role), _s(kind)
    if role and role not in ROLES:
        raise PartyError("Невідома роль «%s». Відомі: %s." % (role, ", ".join(ROLES)))
    out = []
    for pid, p in _load()["parties"].items():
        if role and role not in (p.get("roles") or []):
            continue
        if kind and _s(p.get("kind")) != kind:
            continue
        if archived is not None and is_archived(p) != bool(archived):
            continue
        out.append(dict(p))
    out.sort(key=lambda x: _s(x.get("created")), reverse=True)
    # ⭐⭐⭐ 589: СИТО ВИДИМОСТІ СТОЇТЬ ТУТ — У ЧИТАЧА, а не на дверях. Через
    # цього читача йдуть і список клієнтів, і пошук, і вибиралки; двері,
    # дописані завтра, дістануть сито самі. Коли сервер не назвав читача
    # (розклад, телеграм, кухня) — перелік їде цілим, як і їхав.
    # ⭐ 590: `sift=False` просить ПОВНИЙ перелік — його бере лише той, хто сам
    # притемнить чужі рядки (пошук за назвою: антидубль).
    if not sift:
        return out
    try:
        import entity_scope as _vs589
        return _vs589.sift(_vs589.KIND_PARTY, out)
    except Exception:
        return out


def count(archived=None) -> dict:
    """Скільки чого в базі.

    ⚠ `all` і рахунки ролей — про ТУ САМУ громаду, яку просили (`archived`);
    а `live`/`archived` — ЗАВЖДИ загальні числа по всій базі, бо вкладка
    «Архів» мусить називати своє число ще до того, як у неї зайшли."""
    d = _load()["parties"]
    pop = {k: v for k, v in d.items()
           if archived is None or is_archived(v) == bool(archived)}
    n_arch = sum(1 for v in d.values() if is_archived(v))
    res = {"all": len(pop), "unspecified_kind": 0,
           "live": len(d) - n_arch, "archived": n_arch, "total": len(d)}
    for r in ROLES:
        res[r] = 0
    for p in pop.values():
        for r in (p.get("roles") or []):
            if r in res:
                res[r] += 1
        if not _s(p.get("kind")):
            res["unspecified_kind"] += 1
    return res


def ref(pid: str) -> str:
    """Посилання на контрагента для загального протоколу платформи."""
    return "party:" + _s(pid) if _s(pid) else ""


def title(pid: str) -> str:
    p = get(pid)
    return _s(p.get("name")) or _s(pid)


# ── Перевірки словників ──────────────────────────────────────────────────────
def _check_kind(kind: str) -> str:
    kind = _s(kind)
    if kind not in KINDS:
        raise PartyError("Невідомий тип контрагента «%s». Відомі: особа, компанія "
                         "(або порожньо, якщо ще не вказано)." % kind)
    return kind


def _check_roles(roles) -> list:
    if isinstance(roles, str):
        roles = [roles]
    out = []
    for r in (roles or []):
        r = _s(r)
        if r not in ROLES:
            raise PartyError("Невідома роль «%s». Відомі: %s."
                             % (r, ", ".join(ROLE_NAMES[x] for x in ROLES)))
        if r not in out:
            out.append(r)
    if not out:
        raise PartyError("Контрагент без жодної ролі не заводиться: скажіть, він "
                         "клієнт, постачальник чи партнер.")
    return out


def _check_handles(handles, skip_pid: str = "") -> dict:
    """Нормалізує ручки і не дає завести чужу. Одна ручка — один контрагент."""
    clean = {k: [] for k in HANDLE_KINDS}
    for hk, values in dict(handles or {}).items():
        hk = _s(hk)
        if hk not in HANDLE_KINDS:
            raise PartyError("Невідомий вид ручки «%s». Відомі: %s."
                             % (hk, ", ".join(HANDLE_NAMES[x] for x in HANDLE_KINDS)))
        if isinstance(values, (str, int)):
            values = [values]
        for v in (values or []):
            nv = norm_handle(hk, v)
            if not nv:
                continue
            owner = owner_of_handle(hk, nv)
            if owner and owner != _s(skip_pid):
                raise PartyError("%s «%s» уже належить контрагенту %s (%s). "
                                 "Дубль у клієнтській базі не заводимо."
                                 % (HANDLE_NAMES[hk], nv, owner, title(owner)))
            if nv not in clean[hk]:
                clean[hk].append(nv)
    return clean


def _new_id(d: dict) -> str:
    seq = int(d.get("seq") or 0) + 1
    while ("p%04d" % seq) in d["parties"]:
        seq += 1
    d["seq"] = seq
    return "p%04d" % seq


# ── ЗАГАЛЬНИЙ ПРОТОКОЛ ───────────────────────────────────────────────────────
# 🩸 КОРІНЬ 13.08.2026 (зміна 171, знайдено ЖИВОЮ перевіркою). Хребет 169 урізали
# в пʼять модулів РУШІЯ — прогони, гроші, картки CRM, конектори, задачі. А сам
# ДОВІДНИК, заради якого хребет і затівався, не писав у протокол ЖОДНОГО рядка:
# народження, зміна і смерть контрагента лишали журнал порожнім. Гірше: у переліку
# перед видаленням платформа обіцяє людині «рядки протоколу не зникають» — обіцянка
# без покриття, бо рядків не було взагалі.
#
# ⛒ ЛІКУЄМО КЛАС, А НЕ ВИПАДОК. Рядок пише не кожна з девʼяти письмових функцій
# окремо (одну неминуче забудуть), а ТРИ точки, через які вони всі й так проходять:
# `create`, `_mutate`, `delete`. ЗАКОН: хто зберігає — той і звітує.
#
# ⚠ ЩО САМЕ ЗМІНИЛОСЬ, називає ВИКЛИКАЧ (параметр `what`), і в нього НЕМАЄ
# ДЕФОЛТУ — свідомо. Питання без відповіді «жоден» — міна (урок 157): мовчазний
# дефолт «» дав би рядок «щось змінилось», тобто журнал, який нічого не пояснює.
# Нова мутація не компілюється, поки не назве себе словами.
def _to_protocol(action: str, pid: str, what: str, source: str = "",
                 bind: bool = False) -> None:
    """Дописати рядок у загальний журнал платформи.

    ⚠ НІКОЛИ не валить роботу з базою: довідник — актив компанії, журнал — його
    тінь. `protocol.write` і сам не кидає, але `entity.ref` на порожньому номері
    кине, а порожній номер — не привід не зберегти картку.

    ⚠ `bind` УМИСНО не типовий (14.08, крок B1). Привʼязка грошей до контрагента
    вмикається лише там, де вона й була до переїзду, — на СПІЛКУВАННІ (історія,
    вхідне, надіслане оновлення). Якби кожне перейменування чи додана ручка теж
    привʼязували гаманець, ціна прогону мовчки приписалась би останньому, кого
    ми торкнулись, — рівно той дефект, який зловили в зміні 169."""
    try:
        ref = entity.ref(entity.KIND_PARTY, pid)
        if bind:
            protocol.bind(party=ref)
        protocol.write(action, ref, note=what, source=source)
    except Exception:
        pass


# ── Запис ────────────────────────────────────────────────────────────────────
@one_writer.guard("PARTIES_JSON")
def create(name: str, kind: str = KIND_UNKNOWN, roles=(ROLE_CLIENT,),
           handles=None, source: str = "manual", note: str = "") -> dict:
    """Завести контрагента. Викликається ЛИШЕ явним рішенням людини (кнопка
    менеджера) або міграцією наявних карток. Ніякий вхідний лист сам сюди не
    потрапляє — саме це й було дефектом до 12.08."""
    name = _s(name)
    if not name:
        raise PartyError("Контрагент без назви не заводиться.")
    kind = _check_kind(kind)
    roles = _check_roles(roles)
    clean = _check_handles(handles)
    d = _load()
    pid = _new_id(d)
    now = clock.now()
    d["parties"][pid] = {
        "id": pid,
        "name": name,
        "kind": kind,
        "roles": roles,
        "handles": clean,
        "note": _s(note),
        # ⛒ Народжується ЖИВОЮ і каже це вголос: поле, якого немає, змушувало б
        # кожного читача вгадувати, що означає його відсутність.
        F_ARCHIVED: False,
        # ── базовий шар (крок B1): те, що раніше лежало в картці-угоді ──
        "profile": {f: "" for f in PROFILE_FIELDS},
        "contacts": [],
        "dossier": "",
        "history": [],
        "last_inbound": "",
        "source": _s(source) or "manual",
        "created": now,
        "updated": now,
    }
    _save(d)
    # ⚠ `source` довідника («міграція карток», «manual») і `source` протоколу
    # («звідки прийшла робота») — ДВА РІЗНІ ПИТАННЯ. Одне поле на два питання —
    # міна (урок 09.08), тому джерело картки їде в текст рядка, а звідки прийшла
    # робота протокол бере з контексту дверей, які цей крок відкрили.
    _to_protocol(protocol.A_PARTY_CREATED, pid,
                 "«%s» · %s · %s · джерело картки: %s"
                 % (name, KIND_NAMES.get(kind, kind),
                    ", ".join(ROLE_NAMES.get(r, r) for r in roles),
                    _s(source) or "manual"))
    return dict(d["parties"][pid])


def create_by_person(name: str, employee_id: str = "", by: str = "",
                     kind: str = KIND_UNKNOWN, roles=(ROLE_CLIENT,), handles=None,
                     source: str = "manual", note: str = "") -> dict:
    """⭐⭐⭐ 648: НАРОДЖЕННЯ КЛІЄНТА ЛЮДИНОЮ — ОДИН ПИСАР НА ВСІ КАНАЛИ.

    Досі це правило жило в обробнику дверей екрана: «завести» + «хто завів — той
    і веде» (589). Бот працівника мусить народжувати клієнта РІВНО так само —
    інакше клієнт із телефона був би «нічиїм» (видимий усім, ніким не ведений).
    ⛒ Дубль за телефоном/поштою відмовляє сам `create` — до запису.
    ⚠ Не вдалось призначити (людина без картки працівника, звільнений) — не привід
    валити створення: клієнт лишається нічиїм, як і було з екрана."""
    party = create(name, kind=kind, roles=roles, handles=handles,
                   source=source, note=note)
    emp = _s(employee_id)
    if emp:
        try:
            if not manager_of(party["id"]):
                set_manager(party["id"], emp, by=_s(by))
                party = get(party["id"])
        except Exception:
            pass
    return party


@one_writer.guard("PARTIES_JSON")
def _mutate(pid: str, patch_fn, what: str, action: str = "",
            source: str = "", bind: bool = False) -> dict:
    """ОДНА точка запису на весь довідник: хто зберігає — той і звітує (закон 171).

    ⚠ `action` порожній = звичайна зміна картки контрагента. Спілкування
    (історія, вхідне, оновлення) називає свою дію ВГОЛОС, бо в протоколі це
    різні події, а не «щось змінилось»."""
    pid = _s(pid)
    d = _load()
    p = d["parties"].get(pid)
    if not p:
        raise PartyError("Контрагента %s немає в базі." % (pid or "«»"))
    patch_fn(p)
    p["updated"] = clock.now()
    d["parties"][pid] = p
    _save(d)
    _to_protocol(_s(action) or protocol.A_PARTY_CHANGED, pid, what,
                 source=source, bind=bind)
    return dict(p)


def add_handle(pid: str, kind: str, value) -> dict:
    """Доприбити ручку (нову пошту, телеграм, телефон). Чужу — відмова."""
    nv = norm_handle(kind, value)
    if not nv:
        raise PartyError("Порожнє значення ручки не привʼязується.")
    owner = owner_of_handle(kind, nv)
    if owner and owner != _s(pid):
        raise PartyError("%s «%s» уже належить контрагенту %s (%s)."
                         % (HANDLE_NAMES[_s(kind)], nv, owner, title(owner)))

    def _p(p):
        h = _handles_of(p)
        if not any(_same(_s(kind), x, nv) for x in h[_s(kind)]):
            h[_s(kind)].append(nv)
        p["handles"] = h

    return _mutate(pid, _p, "привʼязано %s: %s" % (HANDLE_NAMES[_s(kind)], nv))


def remove_handle(pid: str, kind: str, value) -> dict:
    nv = norm_handle(kind, value)

    def _p(p):
        h = _handles_of(p)
        h[_s(kind)] = [x for x in h[_s(kind)] if not _same(_s(kind), x, nv)]
        p["handles"] = h
        # ⛒ 648: стара копія в профілі (до 648 профіль тримав номер сам) не сміє
        # пережити відвʼязування — інакше відвʼязаний номер «воскресне» в профілі.
        prof = p.get("profile")
        if isinstance(prof, dict):
            for f, hk in _PROFILE_FROM_HANDLES:
                if hk == _s(kind) and prof.get(f) and norm_handle(hk, prof.get(f)) == nv:
                    prof[f] = ""

    return _mutate(pid, _p, "відвʼязано %s: %s" % (HANDLE_NAMES.get(_s(kind), _s(kind)), nv))


def set_kind(pid: str, kind: str) -> dict:
    k = _check_kind(kind)
    return _mutate(pid, lambda p: p.__setitem__("kind", k),
                   "тип: %s" % KIND_NAMES.get(k, k))


def set_roles(pid: str, roles) -> dict:
    rs = _check_roles(roles)
    return _mutate(pid, lambda p: p.__setitem__("roles", rs),
                   "ролі: %s" % ", ".join(ROLE_NAMES.get(r, r) for r in rs))


def add_role(pid: str, role: str) -> dict:
    r = _check_roles([role])[0]

    def _p(p):
        rs = list(p.get("roles") or [])
        if r not in rs:
            rs.append(r)
        p["roles"] = rs

    return _mutate(pid, _p, "додано роль: %s" % ROLE_NAMES.get(r, r))


def set_name(pid: str, name: str) -> dict:
    """⭐ Назва міняється — НОМЕР НІ. Саме заради цього все й затівалось."""
    nm = _s(name)
    if not nm:
        raise PartyError("Порожня назва контрагента не зберігається.")
    # ⭐ ПЕРЕЙМЕНУВАННЯ — ГОЛОВНА ПОДІЯ ДОВІДНИКА (заради неї він і писався):
    # у журналі мусить лишитись СТАРА назва, інакше історію потім не прочитати.
    return _mutate(pid, lambda p: p.__setitem__("name", nm),
                   "назву змінено: «%s» → «%s»" % (title(pid) or "?", nm))


def set_note(pid: str, note: str) -> dict:
    return _mutate(pid, lambda p: p.__setitem__("note", _s(note)),
                   "примітку змінено")


def set_archived(pid: str, flag: bool = True) -> dict:
    """Прибрати картку в архів або повернути з нього (крок D3, 16.08.2026).

    ⛒ ЙДЕ ЧЕРЕЗ `_mutate`, як і решта змін, — отже, кожна картка лишає СВІЙ
    рядок у загальному протоколі. Це не дрібниця: групова дія над сімомастами
    картками мусить дати сімсот слідів, а не один рядок «змінено 700 карток»,
    інакше завтра неможливо відповісти «а чому Каспер в архіві?».

    ⛔ ПОВТОР — ЦЕ ВІДМОВА СЛОВАМИ, А НЕ ТИХЕ «ГАРАЗД». Мовчазна згода на
    «архівувати вже архівне» зробила б підсумок групової дії брехливим:
    людина побачила б «прибрано 700», хоча насправді змінилось 12."""
    key = _s(pid)
    if not exists(key):
        raise PartyError("Контрагента %s немає в довіднику." % (key or "«»"))
    want = bool(flag)
    if is_archived(get(key)) == want:
        raise PartyError("«%s» %s." % (title(key) or key,
                                       "вже в архіві" if want
                                       else "і так у роботі — повертати нізвідки"))
    return _mutate(key, lambda p: p.__setitem__(F_ARCHIVED, want),
                   "прибрано в архів" if want else "повернуто з архіву")


@one_writer.guard("PARTIES_JSON")
def delete(pid: str) -> bool:
    """Прибрати з бази. Використовується лише для прибирання помилкового запису
    (напр. завели розсилку). Видалення НЕ вгадує форму — тільки за номером."""
    pid = _s(pid)
    d = _load()
    if pid not in d["parties"]:
        return False
    # Імʼя беремо ДО видалення: після нього питати вже нікого.
    gone = _s((d["parties"].get(pid) or {}).get("name"))
    d["parties"].pop(pid)
    _save(d)
    # ⭐ Саме цей рядок робить правдою обіцянку екрана видалення: «рядки протоколу
    # з посиланням party:… НЕ зникають». `entity.norm` існування не вимагає —
    # посилання на прибраного контрагента лишається читабельним назавжди.
    _to_protocol(protocol.A_PARTY_DELETED, pid, "«%s»" % (gone or "без назви"))
    # ⭐⭐⭐ ВИДАЛЕНА СУТНІСТЬ НЕ ЛИШАЄ ЖИВИХ ЗВʼЯЗКІВ (крок B2, 14.08.2026).
    # Задача, яка «стосується» прибраного контрагента, показувала б людині
    # роботу, привʼязану до порожнечі. Дані від цього не зникають: кожне
    # прибирання лягає в протокол окремим рядком, а журнал append-only памʼятає
    # його назавжди. Живий звʼязок у нікуди гірший за його відсутність.
    # ⚠ Реєстр імпортуємо ТУТ, а не зверху: `links` питає `entity`, `entity` —
    # `parties`, і верхній імпорт закільцював би трійку заради одного рядка.
    # ⚠ І ЦЕ НЕ МОВЧИТЬ, ЯКЩО НЕ ВИЙШЛО. Контрагента вже немає — кидати звідси
    # означало б збрехати, що видалення не сталось. Тому невдача лягає в журнал
    # окремим рядком-відмовою: людина побачить, що звʼязки лишились сиротами.
    _ref = entity.ref(entity.KIND_PARTY, pid)
    try:
        import links
        links.forget(_ref)
    except Exception as ex:
        protocol.write(protocol.A_LINK_REMOVED, _ref,
                       outcome="%s: %s" % (protocol.OUT_FAILED, ex),
                       note="звʼязки прибраного контрагента лишились у реєстрі")
    return True

# ── БАЗОВИЙ ШАР: ЧИТАННЯ ─────────────────────────────────────────────────────
# ⭐ Читачі повертають ЗАВЖДИ повну форму (бекфіл), бо екран не має знати, коли
# саме контакт завели: до переїзду чи після. Порожній профіль і відсутній
# профіль виглядають для людини однаково — і мусять однаково читатись.
# ⭐⭐⭐ 648 (26.09.2026). ТЕЛЕФОН І ПОШТА ПРОФІЛЮ — ПОХІДНІ ВІД РУЧОК.
# 🩸 Каспер: «потрібно кілька телефонів у картці». Уміння було (ручки — список),
# але профіль тримав ДРУГУ копію тієї самої правди одинарним полем. Людина бачила
# одне поле «Телефон» і вирішувала, що телефон один; а копії розходились:
# відвʼязаний номер лишався в профілі, чужий тихо лягав у профіль, а в ручки ні.
# ⛒ ХТО ЗНАЄ ПРАВДУ — РУЧКИ. Профіль лише ЧИТАЄ з них (перший номер — головний)
# і пише в них. Старе значення, що так і не стало ручкою, показується, поки
# ручок цього виду немає, — щоб дані людини не зникли мовчки.
_PROFILE_FROM_HANDLES = (("phone", H_PHONE), ("email", H_EMAIL))


def _profile_of(p: dict) -> dict:
    prof = dict(p.get("profile") or {})
    for f in PROFILE_FIELDS:
        prof.setdefault(f, "")
    h = _handles_of(p)
    for f, hk in _PROFILE_FROM_HANDLES:
        vals = [_s(v) for v in (h.get(hk) or []) if _s(v)]
        if vals:
            prof[f] = vals[0]
    return prof


def _contacts_of(p: dict) -> list:
    """⚠ ЗАЛИШОК ПОЛЯ, а не правда про людей (крок B5, 15.08.2026).

    До 15.08 контактна особа була чотирма полями всередині картки компанії. Тепер
    вона — окремий контрагент, повʼязаний звʼязком «працює в», і правду про людей
    віддає `contacts()`. Цей читач лишився рівно для одного: показати те, що ще
    НЕ переїхало, — щоб непереїханий запис не зник з очей мовчки."""
    out = []
    for c in (p.get("contacts") or []):
        row = {k: _s((c or {}).get(k)) for k in CONTACT_FIELDS}
        row.update({"ref": "", "href": "", "party_id": "", "moved": False})
        out.append(row)
    return out


# ── КОНТАКТНІ ОСОБИ = ОКРЕМІ КОНТРАГЕНТИ (крок B5, 15.08.2026) ───────────────
# ⭐⭐⭐ КОРІНЬ (знайшов Андрій 14.08, відкривши картку): «Повʼязані особи» не
# клікабельні. Це не дефект екрана — вести НЕМА КУДИ: у поля картки немає ні
# номера, ні власної картки, ні історії. Наслідок бачили в даних: та сама людина
# у двох компаніях лежала двома різними записами.
#
# ⛒ ДРУГОГО СХОВИЩА НЕ ЗʼЯВЛЯЄТЬСЯ. Перелік «Повʼязані особи» лишається на
# екрані в ТІЙ САМІЙ формі, але тепер він ПОХІДНИЙ від реєстру звʼязків — рівно
# той самий прийом, яким у B1 канали звʼязку стали похідними від ручок. Тому
# жоден із десяти читачів цього переліку не правиться.
def _people_links(pid: str) -> list:
    """Рядки реєстру «хто працює в цьому контрагенті».

    ⚠ Загорнуто: зламаний реєстр не сміє повалити картку контакта."""
    try:
        import links
        me = entity.ref(entity.KIND_PARTY, _s(pid))
        return [l for l in links.incoming(me)
                if _s(l.get("rel")) == links.REL_WORKS_AT]
    except Exception:
        return []


def _person_row(link_row: dict) -> dict:
    """Людина в тій самій формі, у якій жила контактна особа, + адреса переходу.

    ⭐ Посада береться з ПІДПИСУ ЗВʼЯЗКУ (рішення Андрія 15.08): одна людина в
    двох компаніях має дві різні посади, і жодна з них не є властивістю людини."""
    ref = _s(link_row.get("ref"))
    pid = ref.split(":", 1)[1] if ":" in ref else ""
    p = get(pid)
    if not p:
        return None
    prof = _profile_of(p)
    h = _handles_of(p)
    first = lambda k: (h.get(k) or [""])[0] if (h.get(k) or []) else ""
    return {
        "name": _s(p.get("name")),
        "role": _s(link_row.get("note")),
        "phone": _s(prof.get("phone")) or first(H_PHONE),
        "email": _s(prof.get("email")) or first(H_EMAIL),
        "note": _s(p.get("note")) or _s(prof.get("about")),
        # ⭐ КРОК B4 ЖИВЕ Й ТУТ: адресу дає ПЛАТФОРМА (`entity.screen`), а не
        # екран. Новий шар стане клікабельним без правки жодної сторінки.
        "ref": ref,
        "href": entity.screen(ref),
        "party_id": pid,
        "moved": True,
    }


def _history_of(p: dict) -> list:
    return [dict(h) for h in (p.get("history") or []) if isinstance(h, dict)]


def profile(pid: str) -> dict:
    return _profile_of(get(pid))


def contacts(pid: str) -> list:
    """Люди цього контрагента: спершу ті, що мають власну картку, потім залишки
    старого поля. Форма рядка та сама, що й до 15.08, — плюс адреса переходу."""
    out = []
    for l in _people_links(pid):
        row = _person_row(l)
        if row:
            out.append(row)
    out.extend(_contacts_of(get(pid)))
    return out


def dossier(pid: str) -> str:
    return _s(get(pid).get("dossier"))


def history(pid: str) -> list:
    return _history_of(get(pid))


def last_inbound(pid: str) -> str:
    return _s(get(pid).get("last_inbound"))


# ── ДАТА ОСТАННЬОГО КОНТАКТУ (крок D2, 16.08.2026) ───────────────────────────
# ⭐⭐⭐ ЗАКРИТИЙ СЛОВНИК, А НЕ «УСЕ, КРІМ». Стовпець «останній контакт» читає
# менеджер, щоб побачити, хто охолов. Якби туди потрапив МАШИННИЙ запис (зібрано
# збірку, змінено стадію, надіслано оновлення), холодний клієнт виглядав би
# теплим — і загубився б тихо. Ціна помилки несиметрична, тому контактом
# вважаємо ЛИШЕ те, що названо тут.
CONTACT_TYPES = ("comm", "inbound", "outbound", "call", "email", "telegram")
# А це — записи, які пише САМА платформа, і нотатка менеджера («Нотатка» в
# картці). Розмова з клієнтом тут не ночувала.
NON_CONTACT_TYPES = ("note", "stage", "build", "update", "action_done", "contact")
CONTACT_TYPE_NAMES = {"comm": "комунікація", "inbound": "вхідне",
                      "outbound": "вихідне", "call": "дзвінок",
                      "email": "пошта", "telegram": "Telegram"}


def is_contact_type(kind) -> bool:
    """Чи цей запис історії — розмова з людиною, а не робота платформи."""
    return _s(kind) in CONTACT_TYPES


def _last_contact_of(p: dict) -> dict:
    """Найсвіжіший контакт у ГОТОВОМУ записі картки.

    ⛒ НІЧОГО НЕ РАХУЄ ЗАНОВО: читає історію й позначку останнього вхідного —
    тобто тих, хто вже володіє цим фактом. Другий писар дати розійшовся б
    із карткою назавтра."""
    best, kind = "", ""
    for h in _history_of(p):
        if not is_contact_type(h.get("type")):
            continue
        d = _s(h.get("date"))
        # ⚠ ПРИ ОДНАКОВІЙ ДАТІ ВИГРАЄ ПІЗНІШЕ ЗАПИСАНИЙ. Час у платформі йде
        # СЕКУНДАМИ, і два записи в одну секунду — не рідкість (вхідне лягає
        # поруч із коментарем). Строге «більше» лишало б у стовпці ПЕРШИЙ із
        # них, і людина читала б не той вид контакту.
        if d >= best:
            best, kind = d, _s(h.get("type"))
    li = _s(p.get("last_inbound"))
    if li > best:
        best, kind = li, "inbound"
    return {"date": best, "type": kind,
            "name": CONTACT_TYPE_NAMES.get(kind, kind)}


def last_contact(pid) -> dict:
    """Коли з цим контрагентом востаннє спілкувались («» — ще ніколи)."""
    return _last_contact_of(get(pid))


def last_contacts(pids=()) -> dict:
    """Те саме на перелік карток за ОДНЕ читання файла.

    ⚠ Три тисячі клієнтів: `last_contact` у циклі — це три тисячі читань диска.
    Обидва шляхи ведуть в ОДНОГО `_last_contact_of`, тому розійтись не можуть."""
    want = set(_s(x) for x in (pids or ()))
    out = {}
    for pid, p in _load()["parties"].items():
        if want and pid not in want:
            continue
        out[pid] = _last_contact_of(p)
    return out


def managers(pids=()) -> dict:
    """Хто веде кожного з контрагентів — за ОДНЕ читання реєстру звʼязків.

    Форма рядка та сама, що й у `manager_card`: номер, імʼя, звільнений, зник.
    ⚠ Загорнуто: зламаний реєстр не сміє повалити перелік клієнтів."""
    want = set(_s(x) for x in (pids or ()))
    out = {}
    try:
        import links
        rows = links.all_links()
    except Exception:
        return out
    names, active = {}, {}
    try:
        # 🩸🩸🩸 ДЕФЕКТ, ЗНАЙДЕНИЙ ЧЕКОМ D3 (16.08.2026), ЖИВ ІЗ САМОГО D1.
        # `employees()` за замовчуванням ХОВАЄ звільнених — тому в переліку
        # клієнтів звільнений менеджер виглядав не «звільнений», а «НЕМАЄ В
        # ОРГСТРУКТУРІ». Це не косметика: перше означає «передай клієнта
        # іншому», друге — «у платформі щось поламалось». Картка контрагента
        # казала правду (вона питає `employee()` поіменно), а СПИСОК — ні;
        # рівно той клас «два писарі однієї правди».
        for e in _people().employees(include_dismissed=True):
            eid = _s(e.get("id"))
            names[eid] = _s(e.get("full_name")) or eid
            active[eid] = bool(e.get("active"))
    except Exception:
        names, active = {}, {}
    for l in rows:
        if _s(l.get("rel")) != links.REL_MANAGED_BY:
            continue
        # 🩸 ДВІ ФОРМИ ОДНОГО РЯДКА. `links.outgoing()` віддає рядок у формі
        # картки (`ref`), а `links.all_links()` — сирий рядок реєстру
        # (`from`/`to`). Прочитати сирий рядок формою картки означає взяти
        # порожнє посилання — саме на цьому чек і спіймав мене 16.08.
        src = _s(l.get("from"))
        if entity.kind_of(src) != entity.KIND_PARTY:
            continue
        pid = entity.ident_of(src)
        if want and pid not in want:
            continue
        emp = entity.ident_of(_s(l.get("to")))
        out[pid] = {"id": emp, "ref": _s(l.get("ref")),
                    "name": names.get(emp, emp),
                    "dismissed": (emp in names) and not active.get(emp, True),
                    "gone": emp not in names}
    return out


def channels(pid: str) -> dict:
    """Канали звʼязку у формі, яку читали екрани й розсилка ДО переїзду.

    ⭐ Це ПОХІДНЕ від ручок, а не окреме сховище: `telegram_id` у картці і
    `handles.telegram_id` у довіднику були двома писарями одного факту."""
    h = _handles_of(get(pid))
    first = lambda k: (h.get(k) or [""])[0] if (h.get(k) or []) else ""
    return {"telegram_id": first(H_TG_ID), "telegram_user": first(H_TG_USER),
            "email": first(H_EMAIL)}


def emails(pid: str) -> list:
    """Усі відомі адреси контакту: ручки + профіль + люди контрагента.

    🩸 КРОК B5, МІНА, НАЗВАНА ДО РОБОТИ. Вхідний лист сьогодні піднімає картку
    УГОДИ саме через цей перелік (`crm._emails_of`). Коли контактні особи стали
    окремими картками, адреси нікуди не поділись: `contacts()` віддає їх з карток
    людей. Тобто канал впізнавання пілота лишився цілим, хоч сховище й змінилось."""
    out = []
    for e in (_handles_of(get(pid)).get(H_EMAIL) or []):
        if e and e not in out:
            out.append(e)
    prof = profile(pid)
    for e in [prof.get("email")] + [c.get("email") for c in contacts(pid)]:
        e = _s(e).lower()
        if e and e not in out:
            out.append(e)
    return out


def contact_view(pid: str) -> dict:
    """Увесь базовий шар одним читанням — саме це підмішує `crm.card_public`."""
    p = get(pid)
    if not p:
        return {"profile": {f: "" for f in PROFILE_FIELDS}, "contacts": [],
                "dossier": "", "history": [], "last_inbound": "",
                "channels": {"telegram_id": "", "telegram_user": "", "email": ""}}
    # ⛒ САМЕ ЦЕЙ РЯДОК РОБИТЬ ПЕРЕЛІК ОСІБ ПОХІДНИМ НА ВСІХ ЕКРАНАХ ОДРАЗУ:
    # картка контакту, публічна картка CRM і текст комерційної пропозиції читають
    # `contact_view`, а не поле. Правка одна, а каналів — усі.
    return {"profile": _profile_of(p), "contacts": contacts(pid),
            "dossier": _s(p.get("dossier")), "history": _history_of(p),
            "last_inbound": _s(p.get("last_inbound")), "channels": channels(pid)}


# ── БАЗОВИЙ ШАР: ЗАПИС ───────────────────────────────────────────────────────
def set_profile(pid: str, prof: dict) -> dict:
    """Профіль контакту. Приймає ЛИШЕ відомі поля — невідоме не пишеться тихо."""
    incoming = dict(prof or {})
    unknown = [k for k in incoming if _s(k) not in PROFILE_FIELDS]
    if unknown:
        raise PartyError("Невідоме поле профілю «%s». Відомі: %s."
                         % (unknown[0], ", ".join(PROFILE_FIELDS)))
    # ⭐⭐⭐ 648: телефон і пошта йдуть У РУЧКИ, а не в профіль (див. `_profile_of`).
    # Чужий номер — ВІДМОВА ДО БУДЬ-ЯКОГО ЗАПИСУ. Раніше відмову ручки ковтали, а
    # номер лягав у профіль: дві правди розходились із першого ж збереження.
    via_handles = []
    for f, hk in _PROFILE_FROM_HANDLES:
        v = _s(incoming.pop(f, None))
        if not v:
            continue                  # порожнє поле ручок не стирає
        nv = norm_handle(hk, v)
        owner = owner_of_handle(hk, nv) if nv else ""
        if owner and owner != _s(pid):
            raise PartyError("%s «%s» уже належить контрагенту %s (%s)."
                             % (HANDLE_NAMES[hk], nv, owner, title(owner)))
        if nv:
            via_handles.append((f, hk, nv))
    changed = []

    def _p(p):
        cur = dict(p.get("profile") or {})
        for f in PROFILE_FIELDS:
            cur.setdefault(f, "")
            if f in incoming and incoming[f] is not None:
                v = _s(incoming[f])
                if v != cur.get(f, ""):
                    changed.append(f)
                cur[f] = v
        h = _handles_of(p)
        for f, hk, nv in via_handles:
            # Назване в профілі стає ГОЛОВНИМ (першим) — саме його профіль і покаже.
            h[hk] = [nv] + [x for x in h[hk] if x != nv]
            cur[f] = ""               # стара копія більше не живе в профілі
            changed.append(f)
        p["handles"] = h
        p["profile"] = cur

    _mutate(pid, _p, "профіль: %s" % (", ".join(changed) if changed else "без змін"))
    return get(pid)


def add_contact(pid: str, contact: dict) -> dict:
    """Додати контактну особу — тобто ЗАВЕСТИ ЇЙ КАРТКУ і звʼязати з компанією.

    ⭐⭐⭐ КРОК B5. Раніше ця функція дописувала чотири поля в картку компанії —
    і саме тому людина нікуди не вела, а кожна нова згадка народжувала дубль.
    Точка народження особи ОДНА: якщо кнопка й міграція народжували б її
    по-різному, за тиждень у базі знову лежали б дві моделі однієї речі.

    ⚠ Якщо пошта чи телефон уже належать комусь у базі — беремо ТУ картку, а не
    робимо другу. Ручка = тотожність, це правило довідника з 12.08."""
    person = {k: _s((contact or {}).get(k)) for k in CONTACT_FIELDS}
    if not person["name"]:
        raise PartyError("Контактна особа без імені не додається.")
    if not exists(pid):
        raise PartyError("Контрагента %s немає в базі." % (pid or "«»"))

    import links

    known = ""
    for hk, val in ((H_EMAIL, person["email"]), (H_PHONE, person["phone"])):
        if not val:
            continue
        try:
            known = find(val, hk)
        except PartyError:
            known = ""
        if known:
            break

    if known:
        person_id = known
    else:
        person_id = create(person["name"], kind=KIND_PERSON,
                           roles=(ROLE_CONTACT,), source="контактна особа",
                           note=person["note"])["id"]
        prof = {}
        if person["phone"]:
            prof["phone"] = person["phone"]
        if person["email"]:
            prof["email"] = person["email"]
        if person["note"]:
            prof["about"] = person["note"]
        if prof:
            set_profile(person_id, prof)

    # ⚠ ВІДМОВА РЕЄСТРУ ПЕРЕКЛАДАЄТЬСЯ МОВОЮ ДОВІДНИКА. Той, хто натиснув кнопку
    # «додати особу», не має бачити слова «звʼязок» — він додавав людину. І тиха
    # відмова тут заборонена: повторне додавання мусить СКАЗАТИ про себе.
    try:
        links.add(entity.ref(entity.KIND_PARTY, person_id), links.REL_WORKS_AT,
                  entity.ref(entity.KIND_PARTY, pid), note=person["role"])
    except links.LinkError as ex:
        raise PartyError("Особу «%s» не додано: %s" % (person["name"], ex))
    return add_history(pid, "contact", "Додано особу: %s" % person["name"])


def remove_contact(pid: str, index) -> dict:
    """Прибрати особу з компанії за номером у переліку.

    ⛒ КАРТКА ЛЮДИНИ ПРИ ЦЬОМУ НЕ ЗНИКАЄ. Прибирається саме звʼязок «працює в»:
    людина пішла з компанії, а її історія лишається при ній. Видалити картку —
    окреме свідоме рішення на самій картці (правило «робота Андрія = актив»)."""
    try:
        i = int(index)
    except Exception:
        raise PartyError("Номер особи має бути числом.")
    lst = contacts(pid)
    if not (0 <= i < len(lst)):
        raise PartyError("Особи №%s у контакта %s немає." % (index, pid or "«»"))
    row = lst[i]
    gone = row.get("name") or "без імені"

    if row.get("moved"):
        import links
        links.remove(row["ref"], links.REL_WORKS_AT,
                     entity.ref(entity.KIND_PARTY, pid))
        return _mutate(pid, lambda p: None,
                       "особа більше не працює тут: %s (картка лишилась)" % gone)

    # Залишок старого поля: тут людина ще не має картки, прибирати нічого, крім
    # самого запису.
    legacy_at = i - sum(1 for x in lst[:i] if x.get("moved"))

    def _p(p):
        cur = list(p.get("contacts") or [])
        if 0 <= legacy_at < len(cur):
            cur.pop(legacy_at)
        p["contacts"] = cur

    return _mutate(pid, _p, "прибрано особу: %s" % gone)


# ── ХТО ВЕДЕ КЛІЄНТА (крок D1, 15.08.2026) ───────────────────────
# ⭐⭐⭐ КОРІНЬ. «Відповідальний» — ЦЕ ЗВʼЯЗОК, А НЕ ПІДПИС. Підпис рядком
# у картці означав би, що й фільтр «клієнти менеджера Х», й масове
# перезакріплення при звільненні є пошуком-заміною по імені — і перший
# тезка ламає обидва. Тому відповідальний лежить у СПІЛЬНОМУ РЕЄСТРІ
# ЗВʼЯЗКІВ (`links.REL_MANAGED_BY`), рівно як клієнт угоди й посада особи.
#
# ⛒ ДРУГОГО СХОВИЩА НЕ ЗʼЯВЛЯЄТЬСЯ: поля «менеджер» у записі контрагента
# немає й не буде. Імʼя людини питаємо в оргструктури (`taskdesk_people`) —
# єдиного писаря працівників; свого переліку людей довідник не заводить.


def _people():
    """Оргструктура — єдиний писар працівників.

    ⚠ Імпорт ТУТ, а не зверху: довідник контрагентів не має залежати від
    Task Desk на запуску — інакше вимкнений модуль валив би весь CRM."""
    import taskdesk_people as people
    return people


def manager_ref(pid) -> str:
    """Посилання на людину, яка веде цього контрагента (або "").

    ⚠ Загорнуто: зламаний реєстр не сміє повалити картку."""
    try:
        import links
        me = entity.ref(entity.KIND_PARTY, _s(pid))
        for l in links.outgoing(me):
            if _s(l.get("rel")) == links.REL_MANAGED_BY:
                return _s(l.get("ref"))
    except Exception:
        return ""
    return ""


def manager_of(pid) -> str:
    """Номер працівника, який веде контрагента (або "")."""
    row = manager_ref(pid)
    return entity.ident_of(row) if row else ""


def manager_options(include_dismissed: bool = False) -> list:
    """З кого вибирати відповідального. ОДИН ПИСАР цього переліку.

    ⛒ `include_dismissed` існує рівно заради ОДНОГО сценарію, і він же —
    головний сценарій напряму D: менеджер ЗВІЛЬНИВСЯ, і треба знайти всіх
    його клієнтів, щоб передати іншому. У переліку ПРИЗНАЧЕННЯ звільненого
    немає (віддати йому клієнта не можна), а у переліку ПОШУКУ він мусить
    бути — інакше саме тих клієнтів, заради яких усе робилось, не знайти.
    Два питання — два відповіді, але писар списку людей один."""
    try:
        # 🩸 ПИТАЄМО ВСІХ, А ВІДБИРАЄМО САМІ. `employees()` за замовчуванням
        # ХОВАЄ звільнених (рішення Андрія 06.08) — і без цього прапорця
        # звільнений не потрапив би навіть у перелік ПОШУКУ, тобто саме тих
        # клієнтів, заради яких фільтр писався, знайти було б нічим.
        rows = _people().employees(include_dismissed=True)
    except Exception:
        rows = []
    out = []
    for e in rows:
        active = bool(e.get("active"))
        if not active and not include_dismissed:
            continue
        out.append({"id": _s(e.get("id")),
                    "name": _s(e.get("full_name")) or _s(e.get("id")),
                    "dismissed": not active})
    return out


def manager_card(pid) -> dict:
    """Блок «Відповідальний» для екрана: хто веде й з кого вибирати.

    🩸 ЗВІЛЬНЕНИЙ ЧИННИЙ ВІДПОВІДАЛЬНИЙ ПОКАЗУЄТЬСЯ І НАЗИВАЄ СЕБЕ.
    Показати порожньо означало б сховати рівно той випадок, заради якого
    напрям і починався: менеджер пішов, а його клієнти лишились нічиї.
    ⚠ А ось У ПЕРЕЛІКУ ВИБОРУ його немає: призначити звільненого заново
    не можна."""
    key = _s(pid)
    emp = manager_of(key)
    try:
        people = _people()
    except Exception:
        people = None
    # ⛒ Перелік вибору бере ОДИН писар (`manager_options`) — той самий, що й
    # фільтр «клієнти менеджера X». Два списки людей розійшлися б на першому
    # ж звільненні, і саме це вже коштувало нам дефекту в зміні 188.
    options = [{"id": o["id"], "name": o["name"]}
               for o in manager_options(include_dismissed=False)]
    cur = None
    if emp:
        rec = None
        if people is not None:
            try:
                rec = people.employee(emp)
            except Exception:
                rec = None
        cur = {
            "id": emp,
            "ref": entity.ref(entity.KIND_PERSON, emp),
            "name": _s((rec or {}).get("full_name")) or emp,
            "dismissed": bool(rec) and not bool(rec.get("active")),
            "gone": rec is None,
        }
    return {"party_id": key, "manager": cur, "options": options,
            "no_people": not options}


def set_manager(pid, emp_id, by: str = "") -> dict:
    """Призначити відповідального або зняти його (порожній номер = зняти).

    ⛒ РІВНО ОДИН: старий звʼязок ПРИБИРАЄМО, а не додаємо другий.
    ⛔ ЗВІЛЬНЕНОМУ КЛІЄНТА НЕ ВІДДАЄМО — відмова СЛОВАМИ, а не тихий
    пропуск: інакше масове перезакріплення (D3) змогло б передати клієнтів
    тому самому чоловікові, який щойно звільнився."""
    key = _s(pid)
    if not exists(key):
        raise PartyError("Контрагента %s немає в довіднику." % (key or "«»"))
    import links
    me = entity.ref(entity.KIND_PARTY, key)
    old = manager_of(key)
    new = _s(emp_id)

    if new:
        try:
            rec = _people().employee(new)
        except Exception:
            rec = None
        if not rec:
            raise PartyError(
                "Працівника %s немає в оргструктурі — вести клієнта нема кому."
                % (new or "«»"))
        if not rec.get("active"):
            raise PartyError(
                "%s звільнений — вести клієнта може лише чинний працівник."
                % (_s(rec.get("full_name")) or new))
        if new == old:
            return manager_card(key)
    elif not old:
        raise PartyError(
            "Контрагента %s ніхто не веде — знімати нічого." % key)

    if old:
        links.remove(me, links.REL_MANAGED_BY,
                     entity.ref(entity.KIND_PERSON, old), by=by)
    if new:
        try:
            links.add(me, links.REL_MANAGED_BY,
                      entity.ref(entity.KIND_PERSON, new), by=by)
        except links.LinkError as ex:
            # ⚠ ВІДМОВА РЕЄСТРУ ПЕРЕКЛАДАЄТЬСЯ МОВОЮ ДОВІДНИКА: той, хто
            # призначав відповідального, не має бачити слова «звʼязок».
            raise PartyError("Відповідального не змінено: %s" % ex)
    return manager_card(key)


def set_dossier(pid: str, text: str) -> dict:
    return _mutate(pid, lambda p: p.__setitem__("dossier", _s(text)), "досьє змінено")


def append_dossier(pid: str, text: str) -> dict:
    add = _s(text)
    if not add:
        return get(pid)

    def _p(p):
        cur = _s(p.get("dossier"))
        p["dossier"] = (cur + "\n\n" + add) if cur else add

    return _mutate(pid, _p, "досьє доповнено")


def add_history(pid: str, kind: str, note: str = "", action: str = "") -> dict:
    """Запис в історію спілкування з контактом.

    ⚠ ЦЕ ЄДИНИЙ ПИСАР ІСТОРІЇ на всю платформу. До 14.08 таких місць було сім
    (архів, стадія, дія виконана, додана особа, довільний запис, надіслане
    оновлення, вхідне) — і всі сім писали в картку-угоду, тобто історія однієї
    людини розліталась по всіх її угодах."""
    rec = {"date": clock.now(), "type": _s(kind), "note": _s(note)}

    def _p(p):
        h = _history_of(p)
        h.append(rec)
        p["history"] = h

    what = ("%s: %s" % (rec["type"], rec["note"])) if rec["note"] else rec["type"]
    return _mutate(pid, _p, what, action=_s(action) or protocol.A_PARTY_HISTORY,
                   bind=True)


def note_inbound(pid: str, channel: str, preview: str = "") -> dict:
    """Вхідне повідомлення від контакта: запис в історію + час останнього вхідного.

    ⚠ Позначка «потребує уваги» лишається на КАРТЦІ-УГОДІ — вона про роботу
    продавця по конкретній угоді, а не про людину."""
    label = CHANNEL_NAMES.get(_s(channel), _s(channel) or "канал")
    snippet = " ".join((preview or "").split())[:160]
    note = "Вхідне (%s)" % label + ((": %s" % snippet) if snippet else "")
    rec = {"date": clock.now(), "type": "inbound", "note": note}

    def _p(p):
        h = _history_of(p)
        h.append(rec)
        p["history"] = h
        p["last_inbound"] = rec["date"]

    # ⭐ «Звідки береться робота» — питання №1 Андрія до протоколу: канал вхідного
    # їде в поле `source`, а не тоне в тексті примітки.
    return _mutate(pid, _p, note, action=protocol.A_PARTY_INBOUND,
                   source=_s(channel), bind=True)

