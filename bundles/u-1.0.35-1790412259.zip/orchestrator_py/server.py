"""
server.py — точка входу. Легкий HTTP-сервер на стандартній бібліотеці.

Запуск:  python server.py
Відкрити: http://127.0.0.1:7799

Жодних зовнішніх залежностей для самого сервера. Потрібен лише API-ключ LLM
у orchestrator_py/.env.local (OPENAI_API_KEY або ANTHROPIC_API_KEY).
"""

import json
import sys
import os
import time
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# Дозволяємо плоскі імпорти (import config, import llm, ...)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config
import models_live   # ⭐ 11.08.2026: перелiк моделей для екрана — вiд провайдера
import registry
import store
import engine
import scheduler
import artifacts
import filetext
import discovery
import capabilities
import threads
import understanding as _und_srv   # ⛒ один писар поправок людини (581б)
import projects
import llm
import tools


def _json_bytes(payload) -> bytes:
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")


def _persist_turn(tid, user_message, incoming_fc, reply, result_obj=None) -> bool:
    """ОДИН ПИСАР ХОДУ В ТРЕД (30.07.2026).

    НАВІЩО. Запис ходу жив ЛИШЕ на успішній гілці обох дверей чату: якщо рушій
    падав винятком, користувач бачив текст аварії, але в треді не лишалось НІ
    його питання, НІ відповіді. Після перезапуску діалогу просто не існувало —
    людина не могла ні повторити, ні показати, що саме питала.

    ⛔ ХІД, ЗАПИСАНИЙ ЛИШЕ НА УСПІШНІЙ ГІЛЦІ, ЗНИКАЄ САМЕ ТОДІ, КОЛИ ПОТРІБЕН.

    Тому писар ОДИН і викликається на ОБОХ гілках (успіх і виняток) обох дверей
    (`/api/chat` і `/api/chat/stream`). Сам він мовчазним бути не має права:
    якщо не зміг записати — каже про це в журнал, а не «пас».
    """
    if not tid:
        return False
    try:
        threads.append(tid, "user", user_message or "(прикріплені файли)",
                       files_context=incoming_fc or None)
        _r = result_obj or {}
        threads.append(tid, "assistant", reply or "",
                       extra=({"result": {
                           "final_markdown": _r.get("final_markdown", ""),
                           "artifacts": _r.get("artifacts", []),
                           "sources": _r.get("sources", []),
                           "verification": _r.get("verification"),
                           "clause_map": _r.get("clause_map") or "",   # 642: карта пунктів замовника
                           "brain_trace": [x for x in (_r.get("brain_trace") or [])
                                           if x.get("type") == "tool"],
                       }} if _r else None))
        return True
    except Exception as e:
        try:
            llm._log("[server] ХІД НЕ ЗАПИСАНО В ТРЕД %s: %s" % (tid, e))
        except Exception:
            pass
        return False


# ── RBAC-lite: роль із ліцензії (operator = обмежені права) ──────────────────
# Адмінські дії (налаштування, керування системами/ключами/Telegram) недоступні
# в режимі оператора. Запуск задач, читання й свої чати — доступні.
# ⭐⭐⭐ 524 (06.09.2026): ДВЕРІ НАШОЇ КУХНІ. Судить їх ТВОРЕЦЬ
# (`self._is_creator()` -> `crm_access.kitchen_open`), а НЕ адміністратор:
# адміністратор — це рівень, який Є І В КЛІЄНТА, а генератор ключів наш.
# 🩸 ДВЕРІ ЖИВУТЬ В ОДНОМУ ПЕРЕЛІКУ: те, що стоїть тут, з адмінського
# прибрано. Двічі названі двері — це два різні «ні» в різні дні.
# ⛒⛒⛒ 623в: `/api/telegram/users` ПОВЕРНУТО адміністраторові клієнта.
# Зміна 524 сховала ці двері під Творця — а це ЄДИНЕ джерело і стану бота, і
# заявок на доступ. Наслідок бачив клієнт 21.09.2026: сторінка «доступ до
# Telegram-бота» відкривалась, а в журналі сипались 403; ні «бот працює», ні
# кнопки «дозволити» не було нікому, крім нас. Генератор ключів лишається
# Творцевим — він про ЛІЦЕНЗІЇ, а не про робочий стан машини клієнта.
_CREATOR_GET_PATHS = {"/genkey", "/genkey.html"}
_CREATOR_POST_PATHS = {"/api/license/generate"}

_ADMIN_POST_PATHS = {# ⭐ 616: магазин — гроші компанії, тому запис
                     # (порахувати, сформувати, передати пошті) судиться
                     # розділом `sec_shop`, а не самим лише входом.
                     "/api/shop/quote", "/api/shop/order", "/api/shop/handed",
                     # ⭐⭐⭐ 628: ТРЕНАЖЕР — ЗАПИС. Кожна з цих дверей
                     # доходить до моделі, тобто до грошей клієнта. Ті самі
                     # ворота, той самий розділ.
                     "/api/trainer/new", "/api/trainer/message",
                     "/api/trainer/finish",
                     # ⛒ 628б: ЕТАЛОН, ЗА ЯКИМ СУДЯТЬ ЗНАННЯ ПРОДУКТУ.
                     # Ті самі ворота й той самий розділ; окремо судиться лише
                     # РУКА — право «бачити розбори команди».
                     "/api/trainer/case_save", "/api/trainer/case_remove",
                     "/api/automations/toggle", "/api/automations/schedule",
                     "/api/automations/run_now", "/api/automations/delete",
                     # ⛒ 624: створення регулярної роботи — те саме право,
                     # що й керування нею. Другого замка тут бути не може.
                     "/api/automations/create",
                     # ⛒⛒⛒ 626г (22.09.2026): «Надіслати ще раз» — та сама
                     # рука, що керує роботою, тому той самий замок і той
                     # самий розділ.
                     "/api/automations/resend",
                     # 506: МЕРЕЖУ ВІДКРИВАЄ ЛИШЕ АДМІНІСТРАТОР — тим самим
                     # переліком, що й решта адмінських дій, а не другим замком.
                     "/api/taskdesk/network/action",
                     # ⭐ 537: СЕРТИФІКАТ РОБИТЬ ЛИШЕ АДМІНІСТРАТОР — тим
                     # самим переліком, що й решта адмінських дій.
                     "/api/taskdesk/https/action",
                     "/api/discover", "/api/llm/config",
                     "/api/system/status",
                     "/api/setup", "/api/setup/local", "/api/llm/stealth",
                     "/api/license",
                     # ⭐ 524: `/api/license/generate` переїхав під Творця
                     # (`_CREATOR_POST_PATHS`). Тут лишилась ВСТАВКА ключа —
                     # це дія клієнтського адміністратора у своїй збірці.
                     "/api/telegram/token", "/api/telegram/tasks_token",
                     "/api/telegram/support_mode", "/api/support/log",
                     "/api/update/apply", "/api/llm/demo",
                     # ⭐ 454: БУДОВУ КАРТОК МІНЯЄ ЛИШЕ АДМІНІСТРАТОР (слово
                     # Андрія). Новий вхід іде СТАРИМИ воротами — тим самим
                     # переліком, а не другим замком поруч.
                     "/api/cards/field_new", "/api/cards/field_save",
                     "/api/cards/field_many", "/api/cards/field_choices",
                     "/api/cards/field_active", "/api/cards/field_depends",
                     "/api/crm/note", "/api/crm/history",
                     "/api/crm/profile", "/api/crm/contact", "/api/crm/contact_remove",
                     "/api/crm/systems",
                     # ⭐ 631: які МОДУЛІ купив клієнт — та сама кухня,
                     # ті самі ворота, що й набір систем.
                     "/api/crm/modules",
                     "/api/crm/comm", "/api/crm/dossier",
                     "/api/crm/inbound", "/api/crm/inbox_clear",
                     # ⭐⭐⭐ C1 (15.08.2026): ПРОДАЖ ПЕРЕЇХАВ В УГОДУ. Двері
                     # `/stage`, `/attention`, `/next_action`, `/deal`,
                     # `/action_done`, `/archive`, `/unarchive` ПРИБРАНІ разом
                     # із полями картки — двері до неіснуючого поля гірші за їх
                     # відсутність. Нижче — двері самої угоди.
                     "/api/crm/deal_manager",
                     "/api/crm/deal_new", "/api/crm/deal_name", "/api/crm/deal_stage",
                     "/api/crm/deal_amount", "/api/crm/deal_next_action",
                     "/api/crm/deal_action_done", "/api/crm/deal_attention",
                     "/api/crm/deal_archive", "/api/crm/deal_delete",
                     "/api/crm/deal_client", "/api/crm/deal_person",
                     "/api/crm/deal_person_remove", "/api/crm/deal_note",
                     "/api/crm/deal_mail", "/api/crm/deal_mail_sent",
                     "/api/crm/spread_assign", "/api/crm/spread_drop",
                     "/api/crm/spread_owner",
                     "/api/crm/promote", "/api/crm/party",
                     # ⭐ 13.08.2026: розділ «Клієнти» був вітриною без дверей —
                     # картку не відкрити, контрагента не завести й не прибрати.
                     "/api/crm/party_new", "/api/crm/party_delete",
                     # ⭐ D1 (15.08.2026): хто веде клієнта. НОВИЙ ВХІД ІДЕ
                     # СТАРИМИ ВОРОТАМИ — той самий адмінський перелік, що
                     # й решта CRM. Забути тут = зробити двері повз охорону.
                     "/api/crm/party_manager",
                     # ⭐⭐⭐ D3 (16.08.2026): ГРУПОВІ ДІЇ над клієнтською базою.
                     # НОВИЙ ВХІД ІДЕ СТАРИМИ ВОРОТАМИ — той самий адмінський
                     # перелік, що й решта CRM. Забути тут = зробити двері повз
                     # охорону, причому двері, за якими міняються СОТНІ карток.
                     "/api/crm/bulk_preview", "/api/crm/bulk_apply",
                     # ⭐ C3 (15.08.2026): закріплення події у стрічці. НОВИЙ ВХІД
                     # ІДЕ СТАРИМИ ВОРОТАМИ — той самий адмінський перелік, що й
                     # решта CRM. Забути тут = зробити двері повз охорону.
                     "/api/crm/pin",
                     "/api/crm/inbox_attach",
                     # ⭐ 532: ревізія сховища — прибрати назавжди,
                     # перерахувати від диска, відмітити ревізію.
                     "/api/files/recount", "/api/files/ack",
                     "/api/files/remove",
                     # ⭐⭐⭐ 533: БАЗА ТОВАРІВ І ПОСЛУГ. НОВИЙ ВХІД ІДЕ
                     # СТАРИМИ ВОРОТАМИ — той самий адмінський перелік, що
                     # й решта CRM. Забути тут = зробити двері повз охорону.
                     "/api/goods/new", "/api/goods/save",
                     "/api/goods/archive",
                     # ⭐⭐⭐ 536: позиції угоди. НОВИЙ ВХІД ІДЕ СТАРИМИ
                     # ВОРОТАМИ — той самий адмінський перелік, що й
                     # решта CRM.
                     "/api/crm/deal_item_add", "/api/crm/deal_item_save",
                     "/api/crm/deal_item_remove",
                     # ⭐⭐⭐ 585 (16.09.2026): ДОКУМЕНТИ УГОДИ. НОВИЙ ВХІД ІДЕ
                     # СТАРИМИ ВОРОТАМИ — той самий перелік, що й решта CRM, і
                     # той самий розділ у реєстрі `access_sections`.
                     "/api/crm/deal_doc_add", "/api/crm/deal_doc_remove",
                     # ⭐⭐⭐ 625 (21.09.2026): ЗАМІНА ПАПЕРУ —
                     # нова редакція того самого документа.
                     # Ті самі ворота, той самий розділ.
                     "/api/crm/deal_doc_restate",
                     # ⭐⭐⭐ 648 (26.09.2026): ДОКУМЕНТИ КЛІЄНТА. Ті самі ворота,
                     # той самий розділ, що й документи угоди.
                     "/api/crm/party_doc_add", "/api/crm/party_doc_remove",
                     "/api/crm/party_doc_take",
                     # ⭐⭐⭐ 648: ПОШТОВІ СКРИНЬКИ, ЩО ЛЯГАЮТЬ У CRM. Пароль — секрет
                     # компанії, тому ворота — розділ налаштувань, не CRM.
                     "/api/crm/mailbox_add", "/api/crm/mailbox_remove",
                     "/api/crm/mailbox_check",
                     # ⭐⭐⭐ 613 (19.09.2026): МІСТОК «КАРТКА → КП».
                     # НОВИЙ ВХІД ІДЕ СТАРИМИ ВОРОТАМИ — той самий
                     # перелік, що й причеплення документа до угоди.
                     # Окремого платного рівня немає: рішення власника
                     # 19.09.2026 — КП іде в клієнтську збірку без
                     # окремої оплати.
                     "/api/crm/deal_kp"}
_ADMIN_GET_PATHS = {"/setup", "/setup.html", "/telegram", "/telegram.html",
                    # ⛒ 623в: дані свого екрана Telegram — адміністраторові.
                    "/api/telegram/users",
                    # ⛒⛒⛒ 624: екран автоматизацій і перелік доступних обходів.
                    # Куплене вміння мусить вмикатись у клієнта, а не нашим
                    # батником: 21.09.2026 сторожа тендерів довелось запускати
                    # руками з нашої теки, бо в консолі його не було взагалі.
                    "/automations", "/automations.html", "/api/automations/jobs",
                    # ⭐⭐⭐ 626б (22.09.2026): ЕКРАНИ ДОСТУПІВ І РОЛЕЙ.
                    # 🩸 У ТОВ «КАСПЕР УКРАЇНА» менеджер з продажу відкривав
                    # обидва: дані відмовляли (403), а сторінка малювала
                    # «Закрити доступ з мережі», «Оновити сертифікат», форму
                    # заведення запису з галочкою «адміністратор» і матрицю
                    # прав усієї компанії. Сторінка, не названа в реєстрі, не
                    # судиться взагалі — це той самий клас, що 625б, але з
                    # боку СТОРІНОК. Розділ у них свій (`sec_access`), щоб
                    # власник міг дати це право, не роблячи людину
                    # адміністратором усієї платформи.
                    "/access", "/roles",
                    # ⛒ 626б: стан мережі й лічильник місць віддавали 200
                    # будь-кому. Це рівно те, що показує екран «Доступи».
                    "/api/taskdesk/network", "/api/taskdesk/seats",
                    "/api/license/admin",
                    # ⭐ 524: `/genkey`, `/genkey.html` і `/api/telegram/users`
                    # переїхали під Творця (`_CREATOR_GET_PATHS`).
                    # `/api/license/admin` лишається тут свідомо: воно
                    # відповідає про ЗБІРКУ, і це вже правильне питання.
                    "/api/support",
                    # ⭐ 537: файл ключа офісу віддається лише
                    # адміністраторові. Він відкритий за змістом, але роздає
                    # його той, хто відповідає за машини в офісі.
                    "/api/taskdesk/https/office_key",
                    # ⭐ 17.08.2026: безкоштовна діагностика тендера. НОВИЙ ВХІД ІДЕ
                    # СТАРИМИ ВОРОТАМИ — той самий адмінський перелік. Двері лише
                    # читають, але показують внутрішню кухню розбору, і стороннім
                    # у ній робити нічого.
                    "/api/tender/diagnose",
                    # ⭐ 455: сторінка будови карток — адмінська, як і генератор
                    # ключів. Двері `/api/cards/access` НЕ тут: вони лише кажуть
                    # «чи можна», і мовчазна відмова на них сховала б вхід від
                    # того самого адміністратора, якому він і потрібен.
                    "/cards", "/cards.html",
                    # ⭐ 532: екран сховища файлів і його читання —
                    # ревізія господаря машини, а не щоденна робота.
                    "/files", "/files.html", "/api/files/storage",
                    "/api/crm/list", "/api/crm/card", "/api/crm/board", "/api/crm/channels",
                    "/api/crm/products",
                    "/api/crm/pipeline", "/api/crm/inbox", "/api/crm/parties",
                    # ⭐ B3: розділ «Історія взаємовідносин» у картці контакту.
                    # НОВИЙ ВХІД ІДЕ СТАРИМИ ВОРОТАМИ — той самий адмінський
                    # перелік, що й решта CRM. Адреса нічого не відмикає.
                    "/api/crm/party_card",
                    # ⭐ C1: перелік угод, картка угоди і ЗАГАЛЬНИЙ читач картки
                    # будь-якої сутності (той самий `relations.card`).
                    "/api/crm/deals", "/api/crm/deal_card", "/api/crm/entity_card",
                    # ⭐ 585: перелік документів угоди — тими самими воротами.
                    "/api/crm/deal_docs",
                    # ⭐ 648: документи клієнта в його картці — тими самими воротами.
                    "/api/crm/party_docs",
                    # ⭐ 648: перелік поштових скриньок (без паролів).
                    "/api/crm/mailboxes",
                    # ⭐ D2 (16.08.2026): пошук по клієнтській базі. НОВИЙ ВХІД
                    # ІДЕ СТАРИМИ ВОРОТАМИ — той самий адмінський перелік, що й
                    # решта CRM. Забути тут = зробити двері повз охорону.
                    "/api/crm/party_search",
                    "/api/crm/spread",
                    # ⭐⭐⭐ 533: читання бази товарів — тими самими воротами,
                    # що й решта CRM: товарна база — частина клієнтського
                    # шару, а не окреме господарство зі своїм замком.
                    "/api/goods/list", "/api/goods/card",
                    # ⭐⭐⭐ 534: сам екран товару — тими самими воротами,
                    # що й його двері. Сторінка без замка показала б
                    # порожній список тому, кому базу все одно не
                    # віддадуть, а відповідь, якої не видно, — це мовчання.
                    "/goods", "/goods.html",
                    # ⭐⭐⭐ 628 (22.09.2026): ТРЕНАЖЕР ПЕРЕГОВОРІВ. Сторінка
                    # й усі її двері на читання йдуть СТАРИМИ воротами — тим
                    # самим адмінським переліком і тим самим суддею розділів
                    # (`sec_trainer`). Тренажер витрачає гроші клієнта на
                    # кожній репліці й тримає розбори навичок людей: новий
                    # вхід повз охорону тут коштував би і грошей, і чужих
                    # оцінок на чужому екрані.
                    "/trainer", "/trainer.html",
                    "/api/trainer/config", "/api/trainer/session",
                    "/api/trainer/sessions", "/api/trainer/report",
                    # ⭐⭐⭐ 616: МАГАЗИН. Сторінка й читання пропозиції йдуть
                    # СТАРИМИ воротами — тим самим адмінським переліком і тим
                    # самим суддею розділів. Новий вхід повз охорону — це
                    # рівно той клас, який 515б поставив сюди перевірку.
                    # ⛒ Екран інструкції (`/manual`) тут свідомо НЕ стоїть:
                    # довідник — для КОЖНОГО, хто працює за платформою, і
                    # замкнути його означало б, що людина не знайде, як
                    # користуватись тим, за що вже заплачено.
                    "/api/shop/offer", "/shop", "/shop.html"}


def _license_admin() -> bool:
    """Чи дозволяє САМА ЗБІРКА адмінські права. Це питання про ЛІЦЕНЗІЮ, а не
    про людину: ліцензія-оператор ріже адмінське для ВСІХ, хто сидить за цією
    машиною. Хто саме зараз діє — питають окремо (`Handler._is_admin`).

    ⛒ 515: доти ця функція звалася `_is_admin_request` і відповідала на питання
    «чи адміністратор ТОЙ, ХТО ПИТАЄ» — а знала лише про збірку. Через це
    керівник підрозділу, що увійшов під своїм паролем, отримував «admin: true»
    і бачив адмінські входи. Fail-open лишається: помилка перевірки ліцензії
    не має валити роботу."""
    # ⭐⭐⭐ 648: саме питання тепер живе в `access_sections.license_admin` — його
    # ставить і суддя дверей, і бот працівника. Тут — лише передача.
    import access_sections as _sec648l
    return _sec648l.license_admin()


def _quiet_log() -> bool:
    """Чи пише сервер у журнал КОЖНЕ звертання.

    ⛒ 516: коли платформа працює службою, вікна немає — увесь вивід іде у
    файл. Рядок на кожен запит перетворює той файл на гігабайти за місяці
    безперервної роботи. Успішна відповідь — не подія; помилка — подія.
    Змінну ставить ЛИШЕ запускач служби, тож у вікні консолі все як було."""
    try:
        return (config.ENV.get("SENSFLOW_QUIET", "0") or "0") != "0"
    except Exception:
        return False


def _closed_sections_631() -> list:
    """⭐ 631: розділи недоставлених модулів — одна відповідь для екранів.
    ⛒ Поломка судді ховає розділи ВСІХ модулів (fail-closed), але не ядро."""
    try:
        import product_scope as _ps631
        return sorted(_ps631.closed_sections())
    except Exception:
        import access_sections as _s631
        return sorted(s["id"] for s in _s631.SECTIONS if s.get("module"))


def _me_for_screen(session_actor):
    """ОДНА відповідь «хто я» для екранів — через того самого `resolve_actor()`,
    що вирішує, хто діє. Друга відповідь у другому місці розійшлася б із першою."""
    import taskdesk_identity as _tdid
    try:
        acc = _tdid.resolve_actor(session_actor)
    except Exception:
        acc = None
    if not acc or not acc.get("employee_id"):
        return None
    # ⭐⭐⭐ 588: МЕНЮ ПИТАЄ ТОГО САМОГО СУДДЮ, ЩО Й ДВЕРІ. Доти сторінка малювала
    # службові входи по одній галочці «чи адміністратор», а двері судили своє.
    # Щойн  право стало ширшим за галочку, ці дві відповіді розійшлись би:
    # людина з правом на розділ не побачила б входу, який їй уже відчинено, —
    # а схований вхід для неї те саме, що зачинений.
    secs = []
    try:
        import access_sections as _sec588
        import taskdesk_roles as _roles588
        emp = str(acc.get("employee_id") or "")
        if acc.get("is_admin"):
            secs = list(_sec588.SECTION_IDS)
        elif emp:
            secs = [x for x in _sec588.SECTION_IDS if _roles588.allows(emp, x)]
        # ⭐⭐⭐ 631: розділ НЕКУПЛЕНОГО модуля не показується нікому — рівно
        # як його двері не відчиняються нікому (`_not_delivered`).
        import product_scope as _ps631
        _off631 = _ps631.closed_sections()
        secs = [x for x in secs if x not in _off631]
    except Exception:
        secs = []                      # «не знаю» ховає вхід (fail-closed)
    return {"employee_id": acc.get("employee_id"),
            "name": acc.get("employee_name") or "",
            "is_admin": bool(acc.get("is_admin")),
            "sections": secs}


def _oauth_page(title: str, message: str, ok: bool) -> bytes:
    """Сторінка, яку бачить людина після згоди сервісу.

    ⛒ Ця вкладка відкрита ОКРЕМО від консолі, тож вона мусить сама сказати, що
    сталося і куди йти далі: «повідомлення без жодної дії — глухий кут».
    """
    import html as _html
    return ("""<!doctype html><html lang="uk"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>%s</title><style>
 body{margin:0;background:#0f1216;color:#e8edf3;font:16px/1.6 system-ui,Segoe UI,Roboto,sans-serif;
      display:flex;align-items:center;justify-content:center;min-height:100vh}
 .card{max-width:560px;padding:32px 36px;background:#171c23;border:1px solid #2a323d;border-radius:16px}
 h1{margin:0 0 12px;font-size:22px;color:%s}
 p{margin:0 0 20px;color:#c2cbd6}
 a{display:inline-block;padding:10px 18px;border-radius:10px;background:#3b82f6;
   color:#fff;text-decoration:none;font-weight:600}
</style></head><body><div class="card">
<h1>%s</h1><p>%s</p><a href="/">Повернутися в платформу</a>
</div></body></html>""" % (_html.escape(title), ("#5eead4" if ok else "#fca5a5"),
                           _html.escape(title), _html.escape(message))
            ).encode("utf-8")


# ⭐⭐⭐ 519: ПОРТ — ЦЕ ПОСВІДЧЕННЯ ЄДИНОСТІ, А НЕ ПРОСТО АДРЕСА.
# Захист «порт зайнятий -> SensFlow уже працює» був написаний правильно і
# на Linux працює. На WINDOWS він мовчки не працював: типовий сокет
# піднімається з `SO_REUSEADDR`, а Windows за цим дозволом пускає ДРУГУ
# копію на той самий порт. 05.09.2026 на машині Андрія так і сталось: дві
# платформи одночасно ганяли планувальник, сторожа строків і зведення, і
# обидві опитували телеграм-ботів (війна «409 Conflict» у журналі).
# ⛒ Тому: на Windows просимо ВИКЛЮЧНЕ володіння портом, і жодного
# `SO_REUSEADDR`. Друга копія тепер фізично не сяде — і піде тим шляхом,
# який для неї й написаний: «уже працює, це вікно можна закрити».
class _SoleServer(ThreadingHTTPServer):
    allow_reuse_address = (os.name != "nt")

    # ⭐⭐⭐ 537, 08.09.2026. ОДИН ПОРТ, ДВА СТУКИ.
    #
    # Шифрування можна було зробити двома способами, і другий здається
    # простішим: підняти шифрований сокет на іншому порту. Але тоді людина
    # зі старою закладкою `http://…:7799` не отримала б НІЧОГО — ні сторінки,
    # ні пояснення. «Відповідь, якої не видно, — це мовчання.»
    #
    # Тому порт лишається ОДИН, а з'єднання розпізнається за першим байтом:
    # шифрована розмова завжди починається з 0x16, звичайний запит — з літери
    # («GET», «POST»). Підглядання (MSG_PEEK) не забирає байт із черги, тож
    # далі і той, і той шлях працюють, ніби нічого не було.
    #
    # 🩸 Підглядаємо ВЖЕ У ПОТОЦІ З'ЄДНАННЯ: ThreadingHTTPServer кличе
    # finish_request саме там. Роби ми це в черзі прийому — одне мовчазне
    # з'єднання зупинило б усю платформу.
    _tls = None

    def finish_request(self, request, client_address):
        conn = request
        if self._tls is not None:
            try:
                import socket as _sock
                head = request.recv(1, _sock.MSG_PEEK)
            except Exception:
                head = b""
            if head[:1] == b"\x16":
                try:
                    conn = self._tls.wrap_socket(request, server_side=True)
                except Exception:
                    # Невдале рукостискання — не подія платформи. Браузер
                    # скаже про це сам; ми просто закриваємо двері тихо.
                    return
        try:
            self.RequestHandlerClass(conn, client_address, self)
        finally:
            # 🩸 Загорнутий сокет ЗАБИРАЄ собі з'єднання, і прибиральник
            # socketserver закриє вже порожню оболонку. Закриваємо самі.
            if conn is not request:
                try:
                    conn.close()
                except Exception:
                    pass

    def server_bind(self):
        if os.name == "nt":
            try:
                import socket as _sock
                self.socket.setsockopt(_sock.SOL_SOCKET,
                                       _sock.SO_EXCLUSIVEADDRUSE, 1)
            except Exception:
                pass
        ThreadingHTTPServer.server_bind(self)


def _ascii_download_name(name) -> str:
    """ЗАПАСНЕ ЛАТИНСЬКЕ ІМʼЯ ФАЙЛА (зміна 530б, 07.09.2026).

    Розпорядження про завантаження несе імʼя двічі: просте латинське
    (`filename=`) для старих програм і повне українське (`filename*`), яке
    читають усі теперішні браузери.

    🩸 ЗНАЙДЕНО ЖИВОЮ МАШИНОЮ: коли просте імʼя будували відкиданням «не тих»
    символів, «Проба 530.txt» ставала « 530.txt». **Півімені гірше за чесне
    `file`** — воно ВДАЄ, що назвало файл. Тому: імʼя й так латинське — беремо
    як є; є хоч одна не латинська літера — кажемо `file` з тим самим
    розширенням і не вдаємо нічого."""
    nm = str(name or "").strip()
    clean = "".join(ch for ch in nm if 32 <= ord(ch) < 127 and ch not in '"\\')
    clean = " ".join(clean.split()).strip(" .")
    if clean and clean == " ".join(nm.split()).strip(" ."):
        return clean
    ext = ""
    if "." in nm:
        tail = nm.rsplit(".", 1)[-1]
        if tail.isascii() and tail.isalnum() and 0 < len(tail) <= 10:
            ext = "." + tail.lower()
    return "file" + ext


class _BodyReader:
    """ЧИТАЧ ТІЛА ЗАПИТУ З ЛІЧИЛЬНИКОМ (зміна 530, 07.09.2026).

    Віддає рівно стільки, скільки обіцяв заголовок, і ні байтом більше: одне
    зʼєднання несе кілька запитів поспіль, і зайвий байт означав би, що
    наступний запит почне читати з хвоста цього файла.

    ⛒ ЧОМУ НЕ `rfile.read(length)` ОДНИМ ШМАТКОМ: сто мегабайтів у памʼяті
    сервера на кожного, хто щось завантажує. Рушій сховища вміє читати
    шматками — цей читач саме такий шматкар."""

    def __init__(self, rfile, length):
        self._f = rfile
        self.left = int(length or 0)

    def read(self, n=65536):
        if self.left <= 0:
            return b""
        want = min(int(n or 65536), self.left)
        chunk = self._f.read(want) or b""
        self.left -= len(chunk)
        return chunk

    def drain(self):
        """Дочитати рештки після відмови, щоб зʼєднання лишилось чистим."""
        while self.left > 0:
            if not self.read(262144):
                break



# ⭐⭐⭐ 648 (26.09.2026). СЛОВА ПЛАТФОРМИ ДЛЯ ЕКРАНА CRM — ОДНИМ ПИСАРЕМ.
# 🩸 Екран тримав власні копії словників: випадайку видів ручок, назви ручок і
# заголовки блоків. Копія розходиться з платформою на першій правці — людина
# бачить на екрані одне слово, а платформа знає інше (або нове не бачить зовсім).
# ⛒ Обидві двері бази CRM (перелік і пошук) віддають ці словники ОДНИМ викликом.
def _crm_words() -> dict:
    import parties as _ptw
    import card_layout as _clw
    return {"kinds": _ptw.KIND_NAMES, "roles": _ptw.ROLE_NAMES,
            "handle_names": dict(_ptw.HANDLE_NAMES),
            "handle_order": list(_ptw.HANDLE_KINDS),
            "block_names": dict(_clw.BLOCKS)}

class Handler(BaseHTTPRequestHandler):

    # ⭐⭐⭐ 589. ІМʼЯ ЧИТАЧА І ПРОЧИТАНЕ ТІЛО ЖИВУТЬ РІВНО ОДНЕ ЗВЕРНЕННЯ.
    # Сервер потоковий, а зʼєднання тримається відкритим: якби імʼя лишилось на
    # потоці, наступне звернення сусіда відфільтрувалось би чужим рівнем. Тому
    # прибирання стоїть у `finally` — воно спрацює й тоді, коли обробник упав.
    def handle_one_request(self):
        self._body_cache = None
        try:
            return BaseHTTPRequestHandler.handle_one_request(self)
        finally:
            self._body_cache = None
            try:
                import entity_scope as _vs589h
                _vs589h.clear_viewer()
            except Exception:
                pass
    server_version = "AIOrchestratorPy/1.0"

    # ---- утиліти ----------------------------------------------------------
    def _send(self, status, payload, content_type="application/json; charset=utf-8",
              headers=None):
        # ⛒⛒⛒ 432: ОДИН ВИХІД -- ОДИН СУДДЯ ПОЛІВ. Доти кухонні
        # поля різали в ОКРЕМИХ обробниках -- і той, хто забуде, ставав
        # дірою. Позначку ставлять ворота; тут вона знімається одразу,
        # бо один з’єднання несе кілька запитів поспіль.
        _crm_prod = getattr(self, "_crm_product", False)
        self._crm_product = False
        if _crm_prod and not isinstance(payload, (bytes, bytearray)):
            import crm_access as _ca_out
            payload = _ca_out.strip_kitchen(payload, self._actor())
        # ⛒⛒⛒ 626в (22.09.2026). КЛІТКА НА ВИХОДІ: ТАЄМНИЦЯ НЕ ЇДЕ В БРАУЗЕР.
        # 🩸 Відповідь `telegram_unlink` везла ВЕСЬ запис облікового запису —
        # із `salt` і `pwd_hash`, — а перелік записів віддавав хеші паролів
        # усієї компанії. Винен був не обробник: кожна дія віддає те, що
        # повернув писар, а писар повертає запис ЦІЛИМ. Тому ріжемо не в
        # обробниках (той, хто забуде, стане дірою), а ТУТ — на єдиному виході.
        if not isinstance(payload, (bytes, bytearray)):
            try:
                import secrets_gate as _so626
                payload = _so626.clean(payload)
            except Exception as _e626:
                # ⛒ 626з: КЛІТКА НЕ МАЄ ПРАВА ЗВАЛИТИ ВІДПОВІДЬ — але й мовчати
                # про власну поломку не сміє. 22.09.2026 модуль клітки не
                # поїхав у бандлі, і мовчазний `pass` зробив би з цього тишу:
                # запобіжник не працює, а на екрані все як завжди. Тепер
                # збірка без клітки зупиняється ще в нас (ворота складу), а
                # тут лишається гучний слід у журналі.
                sys.stderr.write("[srv] KLITKA NA VYKHODI NE PRATSYUYE: %r\n"
                                 % (_e626,))
        body = payload if isinstance(payload, (bytes, bytearray)) else _json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        for name, value in (headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    # ⭐⭐⭐ ВОРОТА 1 «ХТО ЦЕ» (крок 1.3 Task Desk, 06.08.2026).
    # Стоять В ОДНОМУ місці на всі ~60 обробників: інакше кожен новий обробник
    # мусив би памʼятати про перевірку — а той, хто забуде, і стане дірою.
    # Поки в компанії один обліковий запис (як у Каспера), ворота пропускають
    # усе, як і раніше: живу роботу клієнта вони не чіпають.
    def _taskdesk_gate(self):
        import taskdesk_identity as _tdid
        ok, who, why = _tdid.web_gate(self.path.split("?", 1)[0],
                                      self.headers.get("Cookie") or "")
        self.actor = who
        return ok, why

    # ⭐ ХТО ДІЄ В ЦЬОМУ ЗАПИТІ (крок 1.5). Консоль не вирішує сама: питає
    # єдиного відповідача. `self.actor` сюди кладуть ворота `_taskdesk_gate`.
    def _actor(self):
        import taskdesk_identity as _tdid
        return _tdid.resolve_actor(getattr(self, "actor", None))

    # ⭐⭐⭐ ОДИН СУДДЯ «ЧИ ЦЕ АДМІНІСТРАТОР» НА ВЕСЬ СЕРВЕР (зміна 515).
    # Питань насправді два, і плутати їх не можна:
    #   ЩО ЦЕ ЗА ЗБІРКА  — `_license_admin()`: ліцензія-оператор ріже всіх;
    #   ХТО ЦЕ ЗА ЛЮДИНА — `taskdesk_identity.is_admin()`, той самий суддя,
    #   яким уже судять Task Desk, телеграм і домашня сторінка.
    # Відповідь — ОБИДВІ умови разом. Доти сервер питав саму лише ліцензію,
    # і рядовий працівник бачив адмінські входи.
    # ⚠ Поки вхід не вимагається (одноосібний клієнт), `is_admin` каже «так»
    # господареві машини — саме тому цей замок НІКОГО не виштовхує.
    def _is_admin(self) -> bool:
        if not _license_admin():
            return False
        import taskdesk_identity as _tdid
        try:
            return bool(_tdid.is_admin(self._actor()))
        except Exception:
            return True

    def _is_creator(self) -> bool:
        """⭐⭐⭐ 524: ОДНА ВІДПОВІДЬ «ЧИ ЦЕ ТВОРЕЦЬ» — і вона вже написана.
        Обидві половини (наша збірка + сама людина) питає `kitchen_open`;
        другого судді поруч не заводимо. Поломка судді закриває кухню
        (fail-closed): «не знаю» на замку означає «ні»."""
        import crm_access as _ca
        try:
            return bool(_ca.kitchen_open(self._actor()))
        except Exception:
            return False

    # ⭐⭐⭐ 588 (16.09.2026). ОДИН СУДДЯ АДМІНСЬКИХ ДВЕРЕЙ — І ВІН ЗНАЄ ПРО
    # РОЗДІЛИ. Доти ці ворота питали рівно одне: «чи адміністратор». Право мало
    # дві поділки — «все» або «нічого», — і 15.09.2026 у Каспера менеджер не зміг
    # завести контрагента: уся CRM стоїть в адмінському переліку. Обхід того дня
    # (зробити менеджерів адміністраторами) віддав кожному з них ліцензію,
    # мережу, Telegram і будову карток.
    #
    # Тепер кожні двері мають НАЗВУ РОЗДІЛУ (`access_sections`), а розділ — це
    # дозвіл у тій самій матриці «роль × дозвіл», якою вже судять постановку
    # задач (`taskdesk_roles`). Другого замка поруч не заводимо.
    #
    # ⛒ ТРИ ЗАМКИ ЗАЛИШАЮТЬСЯ FAIL-CLOSED:
    #   ліцензія-оператор ріже адмінське для ВСІХ, хоч би які ролі стояли;
    #   двері БЕЗ розділу лишаються найсуворішими — адміністратор і край;
    #   поломка суду про роль означає «ні», а не «мабуть можна».
    def _may_admin_path(self, method: str, path: str) -> bool:
        # ⭐⭐⭐ 648: СУДДЯ ОДИН НА ВСІ КАНАЛИ (`access_sections.may`). Бот працівника
        # питає його ж — інакше в телефоні була б кнопка, якої немає на екрані.
        import access_sections as _sec588
        try:
            _act648 = self._actor()
        except Exception:
            _act648 = None
        return _sec588.may(_act648, method, path, admin=self._is_admin())

    # ⭐⭐⭐ 589 (16.09.2026). ДРУГА ВІСЬ: ЧИЇ КАРТКИ ВИДНО.
    # 588 вирішила, КУДИ людина заходить. Ця — ЧИЇ картки вона там бачить.
    # ⛒ СУДИМО ЗВЕРНЕННЯ, А НЕ ДВЕРІ. Перелік дверей завжди відстає від коду
    # на одні щойно дописані двері; натомість номер сутності приходить у
    # зверненні під одним із кількох звичних імен (`id`, `ref`, `deal`…), і
    # правило «названого чужого не чіпаємо» діє на будь-яких дверях, зокрема
    # на тих, яких ще немає.
    # ⛒ І ОДРАЗУ КАЖЕМО ЧИТАЧЕВІ ІМʼЯ: переліки судить сито в `parties` і
    # `deals`, а вони самі не знають, кому відповідають. Імʼя живе рівно
    # стільки, скільки триває звернення (`handle_one_request` прибирає його).
    def _may_see_request(self, method: str, path: str):
        import entity_scope as _vs589
        _vs589.clear_viewer()
        if self._is_admin():
            return True, {}                   # як і було: адміністратор бачить усе
        try:
            emp = str((self._actor() or {}).get("employee_id") or "")
        except Exception:
            emp = ""
        if not emp:
            return True, {}                   # одноосібний господар машини
        try:
            if _vs589.level_of(emp) >= _vs589.SCOPE_ALL:
                return True, {}
            _vs589.set_viewer(emp)
            # 🩸 ТІЛО ЧИТАЄМО ЛИШЕ ТОДІ, КОЛИ ВОНО JSON. Завантаження файла
            # їде сирим потоком (`/api/files/upload` читає `rfile` сам), і
            # сторож, який проковтнув би ті сто мегабайтів заради пошуку
            # номера, зламав би саме завантаження. Номера сутності в сирому
            # потоці немає — він приходить окремими дверима.
            _ct589 = str(self.headers.get("Content-Type") or "").lower()
            body = (self._read_json()
                    if (str(method).upper() == "POST"
                        and _ct589.startswith("application/json")) else {})
            from urllib.parse import urlparse as _up589, parse_qs as _pq589
            query = {k: v[0] for k, v in
                     _pq589(_up589(self.path).query or "").items()}
            own = _vs589.owners()
            lvl = _vs589.level_of(emp)
            # ⭐ 590: двері, які лише посилаються на чуже, створюючи власну
            # сутність (завести угоду з чужим клієнтом), названі окремо.
            _free590 = _vs589.free_keys(method, path)
            _pass591 = _vs589.passport_doors(method, path)
            for kind, ident in _vs589.refs_in(query, body, skip=_free590):
                if _vs589.may_see(emp, kind, ident, own=own, level=lvl):
                    continue
                # ⭐ 591: у картку КОНТРАГЕНТА чужого пускаємо — але обробник
                # віддасть паспорт без стрічки. Угоди це не стосується: у
                # чужій угоді паспорта не буває, там усе — вміст.
                if _pass591 and kind == _vs589.KIND_PARTY:
                    continue
                return False, _vs589.refusal(kind, emp)
        except Exception:
            # ⛒ «Не знаю» на замку означає «ні» — але лише для НАЗВАНОЇ чужої
            # картки. Тут ми не знаємо навіть цього, тож звуження робить сито:
            # людина побачить лише своє, а не чужу картку через поломку.
            return True, {}
        return True, {}

    # ⭐⭐⭐ 628 (22.09.2026). ХТО ТРЕНУЄТЬСЯ І ЧИЇ РОЗБОРИ ЙОМУ ВИДНО.
    # ⛒ ОДНА ВІДПОВІДЬ НА ОБИДВА МЕТОДИ. Тренажер має шість дверей; правило
    # «сесія належить працівнику, а розбори команди — окреме право», написане
    # шість разів, розійдеться на першій правці. Тому воно тут одне.
    # ⛒ Порожній `employee_id` — це одноосібний господар машини: у платформи
    # тоді один власник сесій, і ховати від нього його ж розбори нема від кого.
    def _trainer_who(self):
        """(employee_id, імʼя, чи бачить розбори команди)."""
        actor = self._actor() or {}
        emp = str(actor.get("employee_id") or "")
        name = ""
        try:
            import taskdesk_people as _ap
            name = str((_ap.employee(emp) or {}).get("name") or "") if emp else ""
        except Exception:
            name = ""
        if not name:
            name = str(actor.get("login") or actor.get("name") or "")
        if self._is_admin():
            return emp, name, True
        try:
            import taskdesk_roles as _ar
            team = bool(emp) and bool(_ar.allows(emp, _ar.P_TRAINER_TEAM))
        except Exception:
            team = False            # «не знаю» на замку означає «ні»
        return emp, name, team

    def _may_transfer_party(self) -> bool:
        """⭐⭐⭐ 590/618. ЧИ МОЖЕ ЦЯ ЛЮДИНА ПЕРЕДАТИ КЛІЄНТА — ОДНА ВІДПОВІДЬ.

        Правило 590 жило всередині одних дверей (`/api/crm/party_manager`).
        ⛒ 618 відчинила ДРУГІ двері до того самого акту: «чий це лист»
        ставить відповідального контрагента. Правило, написане двічі,
        розійдеться на першій правці, і черга листів стала б чорним ходом
        до бази відділу. Тому відповідь тут одна, і обоє двері питають її."""
        if self._is_admin():
            return True
        import taskdesk_roles as _r590
        try:
            _emp = str((self._actor() or {}).get("employee_id") or "")
            return bool(_emp) and bool(_r590.allows(_emp, _r590.P_TRANSFER_PARTY))
        except Exception:
            return False            # «не знаю» на замку означає «ні»

    def _not_delivered(self, method: str, path: str) -> dict:
        """⭐⭐⭐ 631. ЧИ ЗА ЦИМИ ДВЕРИМА МОДУЛЬ, ЯКОГО КЛІЄНТ НЕ КУПУВАВ.

        Порожньо — пускаємо далі, до звичайних воріт. Інакше — відмова, яка
        каже, де модуль узяти. ⛒ «Не знаю» тут означає «ні»: поламаний суддя
        зачиняє лише розділи МОДУЛІВ, а не всю платформу."""
        import access_sections as _sec631
        sec = _sec631.section_of(method, path)
        if not sec or not _sec631.module_of(sec):
            return {}
        try:
            import product_scope as _ps631
            if _ps631.section_delivered(sec):
                return {}
            return _ps631.not_delivered(sec)
        except Exception:
            return {"error": "module_not_delivered",
                    "message": "Цей модуль зараз недоступний. Напишіть нам у підтримку."}

    def _section_refusal(self, method: str, path: str, page: bool = False) -> dict:
        """ВІДМОВА СЛОВАМИ І З ПРИЧИНОЮ. Тиха відмова = вимкнений сторож:
        людина мусить розуміти, ЧОГО їй бракує і в кого це просити."""
        import access_sections as _sec588
        name = _sec588.name_of(_sec588.section_of(method, path))
        what = "Сторінка" if page else "Дія"
        if name:
            msg = ("%s належить до розділу «%s», а ваша роль його не має. "
                   "Доступ відкриває той, хто веде права доступу." % (what, name))
        else:
            msg = "%s доступна лише адміністратору (режим оператора)." % what
        return {"error": "operator_forbidden", "message": msg, "section": name}

    def _read_json(self):
        """⭐⭐⭐ 589: ТІЛО ЧИТАЄТЬСЯ З ПРОВОДУ РІВНО ОДИН РАЗ.

        Досі кожен виклик читав `rfile` наново — а потік звернення віддає байти
        лише раз. Доки тіло питав один обробник, це працювало; сторож видимості
        мусить прочитати те саме тіло ПЕРЕД ним, і другий читач дістав би
        порожнечу. Тому прочитане памʼятається на час звернення."""
        if getattr(self, "_body_cache", None) is not None:
            return self._body_cache
        length = int(self.headers.get("Content-Length", "0") or "0")
        if not length:
            self._body_cache = {}
            return self._body_cache
        raw = self.rfile.read(length)
        try:
            self._body_cache = json.loads(raw.decode("utf-8"))
        except Exception:
            self._body_cache = {}
        if not isinstance(self._body_cache, dict):
            self._body_cache = {}
        return self._body_cache

    def _send_download(self, path, human_name):
        """🩸🩸 ФАЙЛ ЗАВЖДИ ЇДЕ ЯК ЗАВАНТАЖЕННЯ (зміна 530, 07.09.2026).

        І НІКОЛИ не відкривається всередині сторінки. «Специфікація», яка
        насправді сторінка зі скриптом, інакше виконалась би в браузері іншого
        працівника ПІД ЙОГО ПРАВАМИ — це звичайний спосіб украсти чужий
        доступ, а не теорія. Тому: тип вмісту завжди двійковий, браузеру
        заборонено вгадувати (`nosniff`), розпорядження — `attachment`.

        ⛒ ІМʼЯ ЇДЕ ДВІЧІ: простим латинським (старі програми) і повним
        українським у `filename*` — інакше «Специфікація.pdf» доїжджала б
        каракулями.

        🩸 І ВІДДАЄМО ПОТОКОМ: сто мегабайтів у памʼяті сервера на кожного,
        хто натиснув «завантажити», — та сама біда, тільки повільніша."""
        import os as _os530
        import shutil as _sh530
        from urllib.parse import quote as _q530
        size = _os530.path.getsize(str(path))
        nm = str(human_name or "file")
        ascii_name = _ascii_download_name(nm)
        self.send_response(200)
        self.send_header("Content-Type", "application/octet-stream")
        self.send_header("Content-Length", str(size))
        self.send_header("Content-Disposition",
                         "attachment; filename=\"%s\"; filename*=UTF-8''%s"
                         % (ascii_name, _q530(nm, safe="")))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        with open(str(path), "rb") as _fh530:
            _sh530.copyfileobj(_fh530, self.wfile, 1024 * 1024)

    def log_message(self, fmt, *args):  # тихіший лог
        sys.stderr.write("[srv] " + (fmt % args) + "\n")

    # ⭐⭐⭐ 516: У ТИХОМУ РЕЖИМІ МОВЧИТЬ ЛИШЕ УСПІХ. Відмови (4xx) і поломки
    # (5xx) лишаються в журналі: інакше служба, яка мовчки відмовляє людям,
    # не лишала б по собі жодного сліду — а це гірше за великий файл.
    def log_request(self, code="-", size="-"):
        if _quiet_log() and str(getattr(code, "value", code))[:1] in ("2", "3"):
            return
        BaseHTTPRequestHandler.log_request(self, code, size)

    def _insecure_redirect(self) -> bool:
        """⭐⭐⭐ 537: СТАРЕ ПОСИЛАННЯ НЕ МОВЧИТЬ.

        Хтось збереже в закладках адресу без шифрування, хтось набере її
        руками. Якщо на такий стук не відповісти, людина побачить порожнечу
        і вирішить, що платформа впала. Тому звичайний стук З МЕРЕЖІ
        перекидається на шифрований — тим самим шляхом, за тією ж адресою.

        З ЦІЄЇ Ж МАШИНИ звичайний вхід лишається робочим і нічого не
        перекидає: трафік на 127.0.0.1 не виходить за межі комп'ютера,
        шифрувати в ньому нема чого. Саме цим шляхом ходять власник,
        наші проби і робот-клієнт — жоден із них не ламається.
        """
        if getattr(self.server, "_tls", None) is None:
            return False
        try:
            import ssl as _ssl
            if isinstance(self.connection, _ssl.SSLSocket):
                return False
        except Exception:
            return False
        who = (self.client_address or ("",))[0] or ""
        if who.startswith("127.") or who in ("::1", "localhost"):
            return False
        where = self.headers.get("Host") or ""
        if not where:
            return False
        try:
            self.send_response(301)
            self.send_header("Location", "https://%s%s" % (where, self.path))
            self.send_header("Content-Length", "0")
            self.end_headers()
        except Exception:
            pass
        return True

    # ---- GET --------------------------------------------------------------
    def do_GET(self):
        path = self.path.split("?", 1)[0]

        if self._insecure_redirect():
            return

        _ok, _why = self._taskdesk_gate()
        if not _ok:
            return self._send(401, {"error": "login_required", "message": _why})

        # ⭐⭐⭐ 515б: АДМІНСЬКІ ВОРОТА СТОЯТЬ ПЕРШИМИ.
        # Замок був правильний, а сторінка `/cards` усе одно відкривалася:
        # її обробник стояв ВИЩЕ за ворота. Тому ворота живуть тут — одразу
        # після воріт «хто це» і ПЕРЕД усіма обробниками. Тоді новий обробник
        # не може випередити охорону, хоч би де його дописали.
        # ⭐⭐⭐ 524: ВОРОТА ТВОРЦЯ СТОЯТЬ ПЕРЕД АДМІНСЬКИМИ. Генератор
        # ключів судився питанням «чи адміністратор» — а цей рівень у клієнта
        # Є, тож тестовий запис клієнтського адміністратора діставався сюди
        # прямою адресою. Відмову пише ЄДИНИЙ писар (`crm_access.refusal`):
        # у нашій збірці він називає причину, у клієнтській про Творця не
        # згадує жодним словом.
        if path in _CREATOR_GET_PATHS and not self._is_creator():
            import crm_access as _ca524
            return self._send(403, _ca524.refusal(path))

        # ⭐⭐⭐ 631. НЕКУПЛЕНИЙ МОДУЛЬ ЗАЧИНЕНИЙ ДЛЯ ВСІХ — і стоїть ЦЕЙ замок
        # ПЕРЕД адмінським: адміністратор клієнта проходить будь-які ролі, але
        # купівля — не роль. Питаємо розділ дверей у ТОГО САМОГО реєстру.
        _nd631 = self._not_delivered("GET", path)
        if _nd631:
            return self._send(403, _nd631)

        if path in _ADMIN_GET_PATHS and not self._may_admin_path("GET", path):
            return self._send(403, self._section_refusal("GET", path, page=True))

        _see, _no = self._may_see_request("GET", path)
        if not _see:
            return self._send(403, _no)

        # ⭐⭐⭐ 617. ЧИТАННЯ ТЕЖ МАЄ ІМʼЯ. Доти «хто почав цей запит» називав
        # лише POST (зміна 171). Поки конектор був властивістю платформи, це
        # не заважало: відповідь «підключено» була одна на всіх. Щойно
        # конектор дістав власника, БЕЗІМЕННЕ ЧИТАННЯ стало питанням без
        # відповіді — картка конектора не знала б, про кого вона говорить, а
        # кнопка «Підключити» не знала б, чию згоду записує.
        # ⛒ Писар той самий, що й на записі (`protocol.bind`), і стоїть у
        # ОДНОМУ місці на всі обробники читання — новий обробник не може про
        # нього забути.
        try:
            import protocol as _proto617
            import entity as _ent617
            _proto617.clear()
            _proto617.bind(source=_proto617.S_CONSOLE,
                           actor=_ent617.person_of_actor(self._actor()))
        except Exception:
            pass

        if path == "/api/taskdesk/whoami":
            import taskdesk_identity as _tdid
            who = getattr(self, "actor", None)
            import taskdesk_api as _tdapi0
            return self._send(200, {"enabled": _tdapi0.enabled(),
                                    "login_required": _tdid.login_required(),
                                    "light_mode": _tdid.light_mode(),
                                    "actor": ({"id": who["id"], "login": who["login"],
                                               "name": who["employee_name"],
                                               "is_admin": who["is_admin"],
                                               "layers": who["layers"],
                                               "orchestrator": who["orchestrator"]}
                                              if who else None),
                                    # ⭐ «Хто я» для екрана — це РОЗВʼЯЗАНИЙ актор
                                    # (`resolve_actor`), а не лише жива сесія: в
                                    # одноосібного клієнта сесії немає, а людина є.
                                    # Без цього кнопці «Моя картка» нема куди вести.
                                    "me": _me_for_screen(who)})

        # ── ПАЛІТРА Й ПЕРЕМИКАЧ ТЕМИ (зміна 184, 15.08.2026).
        # Один файл кольорів на весь продукт і один перемикач: доти кольори
        # жили в пʼятьох сторінках окремо, і світла тема означала б пʼять
        # правок замість однієї. Віддається ДО будь-якої перевірки прав —
        # сторінка входу мусить бути пофарбована ще до того, як стало
        # відомо, хто прийшов.
        if path in ("/theme.css", "/theme.js"):
            page = config.UI_DIR / path.lstrip("/")
            if not page.exists():
                return self._send(404, {"error": "not_found"})
            kind = ("text/css" if path.endswith(".css")
                    else "application/javascript")
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="%s; charset=utf-8" % kind)

        # ── Екрани Task Desk (крок 1.4). Поки робота вимкнена — їх немає зовсім:
        # вимкнена річ не мусить світитись у клієнта навіть сторінкою.
        # ⛒ 436: СПІЛЬНИЙ ЕКРАН CRM -- один файл на два місця підключення
        # (консоль і сторінка /crm). Віддається БЕЗ замка: консоль кличе
        # crmDate() для показу ліцензії ще до того, як CRM хтось відкрив, --
        # мовчазний 404 тут зламав би екран, який до CRM не має стосунку.
        # ⭐ 481: спільне вікно «Мозок платформи». Файл, якого сервер не
        # віддає, для сторінки не існує — тому новий шматок інтерфейсу
        # їде ТИМИ САМИМИ воротами, що й спільний екран CRM.
        # ⭐ 500: вихід додому на кожному екрані — той самий шов.
        if path in ("/brain_panel.js", "/shell_top.js"):
            page = config.UI_DIR / path.lstrip("/")
            if not page.exists():
                return self._send(500, {"error": "ui_part_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="application/javascript; charset=utf-8")

        if path == "/__never__":
            page = config.UI_DIR / "brain_panel.js"
            if not page.exists():
                return self._send(500, {"error": "brain_panel_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="application/javascript; charset=utf-8")

        if path in ("/crm_core.css", "/crm_core.js"):
            page = config.UI_DIR / path.lstrip("/")
            if not page.exists():
                return self._send(404, {"error": "not_found"})
            kind = ("text/css" if path.endswith(".css") else "application/javascript")
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="%s; charset=utf-8" % kind)

        if path in ("/taskdesk.css", "/taskdesk.js"):
            page = config.UI_DIR / path.lstrip("/")
            if not page.exists():
                return self._send(404, {"error": "not_found"})
            kind = ("text/css" if path.endswith(".css") else "application/javascript")
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="%s; charset=utf-8" % kind)

        if path == "/own_fields.js":
            # ⭐ СПІЛЬНИЙ МАЛЯР ВЛАСНИХ ПОЛІВ (зміна 527) — один на картку CRM
            # і на екран задачі. Віддається так само, як решта спільних писарів.
            page = config.UI_DIR / "own_fields.js"
            if not page.exists():
                return self._send(404, {"error": "not_found"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="application/javascript; charset=utf-8")

        # ⭐⭐⭐ ЕКРАН CRM (зміна 421, крок 3 шару CRM) — ВЛАСНА сторінка, а не
        # вікно всередині адмінської консолі. Консоль клієнту не їде, тому доти
        # показати CRM клієнту було просто нічим.
        # ⛒ Поки що під замком адміністратора, як і двері `/api/crm`: у
        # клієнтських збірках цей шар ще не куплено. Замок «куплено» приходить
        # кроком 4; тут навмисно fail-closed — півживий екран у людини, яка за
        # нього не платила, гірший за відсутній.
        # ⭐⭐⭐ ЕКРАН БУДОВИ КАРТОК (зміна 455) — лише адміністратор.
        # Сама сторінка стоїть у `_ADMIN_GET_PATHS`, тобто йде СТАРИМИ воротами.
        # ⭐⭐⭐ ЕКРАН СХОВИЩА ФАЙЛІВ (зміна 532) — лише адміністратор.
        # Сама сторінка стоїть у `_ADMIN_GET_PATHS`, тобто йде СТАРИМИ воротами.
        if path in ("/files", "/files.html"):
            page = config.UI_DIR / "files.html"
            if not page.exists():
                return self._send(500, {"error": "files_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        # ⭐⭐⭐ ЕКРАН «ТОВАРИ І ПОСЛУГИ» (зміна 534). Сама сторінка
        # стоїть у `_ADMIN_GET_PATHS`, тобто йде СТАРИМИ воротами —
        # тими самими, що й двері до бази товарів.
        if path in ("/goods", "/goods.html"):
            page = config.UI_DIR / "goods.html"
            if not page.exists():
                return self._send(500, {"error": "goods_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        # ⭐⭐⭐ ЕКРАН ТРЕНАЖЕРА ПЕРЕГОВОРІВ (628). Сама сторінка стоїть у
        # `_ADMIN_GET_PATHS`, тобто йде СТАРИМИ воротами — тими самими, що й
        # двері Тренажера, і під тим самим розділом `sec_trainer`.
        if path in ("/trainer", "/trainer.html"):
            page = config.UI_DIR / "trainer.html"
            if not page.exists():
                return self._send(500, {"error": "trainer_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        # ⭐⭐⭐ ДАНІ ТРЕНАЖЕРА (628). Замок стоїть вище, у `_ADMIN_GET_PATHS`:
        # тут ми його не повторюємо — другий замок поруч розходиться з першим.
        if path.startswith("/api/trainer/"):
            import trainer as _ac
            emp, _nm, team = self._trainer_who()
            from urllib.parse import urlparse as _upa, parse_qs as _pqa
            q = {k: v[0] for k, v in
                 _pqa(_upa(self.path).query or "").items()}
            try:
                if path == "/api/trainer/config":
                    return self._send(200, _ac.config_state())
                if path == "/api/trainer/sessions":
                    return self._send(200, {"sessions": _ac.engine().listing(
                        emp, team=team), "team": team,
                        "spend": _ac.spend_report()})
                if path == "/api/trainer/session":
                    return self._send(200, _ac.engine().get(
                        q.get("id") or "", emp, team=team))
                if path == "/api/trainer/report":
                    import trainer_report as _arep
                    s = _ac.engine().get(q.get("id") or "", emp, team=team)
                    if not s.get("report"):
                        return self._send(400, {"error": "trainer_no_report",
                                                "message": "Розбір ще не сформовано."})
                    import tempfile as _tf628
                    from pathlib import Path as _P628
                    out = _P628(_tf628.mkdtemp(prefix="sf_trainer_")) \
                        / _arep.file_name(s)
                    if not _arep.build_docx(s, out):
                        return self._send(500, {
                            "error": "trainer_docx_failed",
                            "message": "Не вдалося зібрати файл звіту."})
                    return self._send_download(out, out.name)
            except _ac.TrainerError as e:
                return self._send(403 if "чужа" in str(e) else 400,
                                  {"error": "trainer_refused", "message": str(e)})
            return self._send(404, {"error": "not_found"})

        # ⭐⭐⭐ ЕКРАН МАГАЗИНУ (зміна 616). Сама сторінка стоїть у
        # `_ADMIN_GET_PATHS`, тобто йде СТАРИМИ воротами — тими самими, що й
        # двері до пропозиції.
        if path in ("/shop", "/shop.html"):
            page = config.UI_DIR / "shop.html"
            if not page.exists():
                return self._send(500, {"error": "shop_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        # ⭐⭐⭐ ЕКРАН ІНСТРУКЦІЇ (зміна 616) — БЕЗ адмінського замка.
        # ⛒ Довідник потрібен саме тому, хто ще не знає, як тут усе влаштовано.
        # Замкнути його на адміністратора означало б лишити працівника наодинці
        # з платформою, якої йому ніхто не пояснив.
        if path in ("/manual", "/manual.html"):
            page = config.UI_DIR / "manual.html"
            if not page.exists():
                return self._send(500, {"error": "manual_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        if path in ("/cards", "/cards.html"):
            page = config.UI_DIR / "cards.html"
            if not page.exists():
                return self._send(500, {"error": "cards_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        if path == "/crm":
            # ⛒ 428: ЗАМОК ПИТАЄ «ЧИ КУПЛЕНО», а не «чи це наша збірка».
            import crm_access as _ca
            if not _ca.product_open():
                return self._send(404, {"error": "not_found"})
            page = config.UI_DIR / "crm.html"
            if not page.exists():
                return self._send(500, {"error": "crm_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        if path in ("/login", "/people", "/access", "/roles", "/employee",
                    "/tasks", "/task", "/worktypes", "/structure", "/history",
                    "/mirror"):
            import taskdesk_api as _tdapi
            if not _tdapi.enabled():
                return self._send(404, {"error": "not_found"})
            names = {"/login": "taskdesk_login.html", "/people": "taskdesk_people.html",
                     "/access": "taskdesk_access.html", "/roles": "taskdesk_roles.html",
                     "/employee": "taskdesk_employee.html",
                     "/tasks": "taskdesk_tasks.html", "/task": "taskdesk_task.html",
                     "/worktypes": "taskdesk_worktypes.html",
                     # ⭐ Схема структури компанії (зміна 312) — окремий екран,
                     # відкритий усім працівникам за словом Андрія.
                     "/structure": "taskdesk_structure.html",
                     # ⭐ Історія змін компанії (зміна 365) — окремий екран:
                     # він росте роками, і блоку внизу чужої сторінки замало.
                     "/history": "taskdesk_history.html",
                     # ⭐ Дзеркало керівника (зміна 389) — окремий екран: це
                     # інструмент керівника, а не блок унизу чужої сторінки.
                     "/mirror": "taskdesk_mirror.html"}
            page = config.UI_DIR / names[path]
            if not page.exists():
                return self._send(500, {"error": "taskdesk_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        if path in ("/api/taskdesk/people", "/api/taskdesk/structure",
                    "/api/taskdesk/accounts", "/api/taskdesk/history",
                    "/api/taskdesk/mirror",
                    "/api/taskdesk/roles", "/api/taskdesk/worktypes",
                    "/api/taskdesk/employee_card"):
            import taskdesk_api as _tdapi
            who = getattr(self, "actor", None)
            try:
                if path == "/api/taskdesk/people":
                    return self._send(200, _tdapi.people_state(who))
                if path == "/api/taskdesk/structure":
                    # Згорнуті й розгорнуті гілки їдуть в адресі: схему можна
                    # переслати колезі, і вона відкриється в нього так само.
                    from urllib.parse import urlparse as _ups, parse_qs as _pqs
                    _q = _pqs(_ups(self.path).query)
                    return self._send(200, _tdapi.structure_state(
                        who, (_q.get("fold") or [""])[0],
                        (_q.get("open") or [""])[0]))
                if path == "/api/taskdesk/history":
                    from urllib.parse import urlparse as _uph, parse_qs as _pqh
                    _h = _pqh(_uph(self.path).query)
                    return self._send(200, _tdapi.history_state(
                        who, (_h.get("q") or [""])[0],
                        (_h.get("since") or [""])[0], (_h.get("until") or [""])[0],
                        (_h.get("limit") or [""])[0], (_h.get("offset") or [""])[0]))
                if path == "/api/taskdesk/mirror":
                    from urllib.parse import urlparse as _upm, parse_qs as _pqm
                    _m = _pqm(_upm(self.path).query)
                    return self._send(200, _tdapi.mirror_state(
                        who, (_m.get("days") or [""])[0]))
                if path == "/api/taskdesk/accounts":
                    return self._send(200, _tdapi.accounts_state(who))
                if path == "/api/taskdesk/roles":
                    return self._send(200, _tdapi.roles_state(who))
                if path == "/api/taskdesk/worktypes":
                    return self._send(200, _tdapi.worktypes_state(who))
                from urllib.parse import urlparse as _up, parse_qs as _pq
                q = _pq(_up(self.path).query)
                return self._send(200, _tdapi.employee_card(who, (q.get("id") or [""])[0]))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path in ("/api/taskdesk/board", "/api/taskdesk/task"):
            import taskdesk_api as _tdapi
            from urllib.parse import urlparse as _upb, parse_qs as _pqb
            q = _pqb(_upb(self.path).query)
            # ⭐ «Хто діє» питаємо ЄДИНОГО відповідача (крок 1.5), а не сирий
            # actor сесії: інакше єдиний власник без входу перестає бути людиною.
            who = self._actor()
            try:
                if path == "/api/taskdesk/board":
                    return self._send(200, _tdapi.board_state(
                        who, (q.get("scope") or ["all"])[0],
                        (q.get("closed") or [""])[0] == "1",
                        None, (q.get("q") or [""])[0],
                        (q.get("fresh") or [""])[0] == "1",
                        (q.get("archive") or [""])[0] == "1"))
                return self._send(200, _tdapi.task_state(who, (q.get("id") or [""])[0]))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/photo":
            import taskdesk_api as _tdapi
            from urllib.parse import urlparse as _up2, parse_qs as _pq2
            q = _pq2(_up2(self.path).query)
            try:
                raw, mime = _tdapi.photo_get(getattr(self, "actor", None),
                                             (q.get("id") or [""])[0])
                return self._send(200, raw, content_type=mime)
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/light_list":
            # Легкий режим: список людей для вибору себе без пароля. Поза легким
            # режимом список нікому не показується — це не довідник для чужих.
            import taskdesk_identity as _tdid
            if not _tdid.light_mode():
                return self._send(403, {"error": "light_mode_off",
                                        "message": "Вхід без пароля вимкнений."})
            return self._send(200, {"accounts": [
                {"id": a["id"], "name": a["employee_name"], "login": a["login"]}
                for a in _tdid.accounts() if a["can_login"]]})

        # ⛒⛒⛒ 428: ДВЕРІ, ЯКІ КАЖУТЬ, ЧИ ВІДКРИТА CRM. МАЮТЬ СТОЯТИ ДО
        # воріт — інакше консоль не зможе спитати, чи показувати вхід. Віддає
        # РІВНО два біти і жодного факту про базу.
        if path == "/api/taskdesk/seats":
            # 508-509: ЛІЧИЛЬНИК МІСЦЬ. Віддає самі числа і ЖОДНОГО імені:
            # скільки людей у системі зараз, піки за день і за місяць, скільки
            # різних працівників заходило цього місяця.
            # ⛔ Нічого не обмежує: місцями ми не торгуємо (рішення 04.09.2026).
            import seats as _seats
            import taskdesk_identity as _tdseats
            return self._send(200, _seats.stats(len(_tdseats.active_accounts())))

        if path == "/api/taskdesk/network":
            # 506: стан мережевого доступу. Рівно те, що показує екран
            # «Доступи»: чи відкрито, чи є пароль, за якою адресою заходити.
            import network_access as _net
            return self._send(200, _net.state())

        if path == "/api/taskdesk/https/office_key":
            # ⭐⭐⭐ 537: ФАЙЛ, ЯКИЙ СТАВЛЯТЬ КОМПʼЮТЕРАМ ПРАЦІВНИКІВ.
            # Це ВІДКРИТА частина ключа офісу — її для того й роблять, щоб
            # роздати. 🩸 Таємної частини ці двері не знають: `https_access`
            # уміє віддати лише публічний файл, і другого способу немає.
            import https_access as _sec
            _body = _sec.ca_public_pem()
            if not _body:
                return self._send(404, {"error": "no_office_key",
                                        "message": "Ключ офісу ще не створено."})
            _raw = _body.encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/x-x509-ca-cert")
            self.send_header("Content-Length", str(len(_raw)))
            self.send_header("Content-Disposition",
                             'attachment; filename="SensFlow_office_key.crt"')
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(_raw)
            return

        if path == "/api/crm/access":
            import crm_access as _ca
            return self._send(200, {"open": _ca.product_open(),
                                    "kitchen": _ca.kitchen_open(self._actor())})

        # ⛒⛒⛒ 428: ОДИН СУДДЯ ДОСТУПУ ДО CRM. Дотепер тут стояв один
        # замок на ВСЕ `/api/crm/*` — і на наш сервіс-центр, і на товар.
        # Через це клієнтський шар не міг бути відкритим без того, щоб віддати
        # кухню. Тепер суддя один, а відповідей дві — за ВЛАСНИКОМ дверей.
        if path.startswith("/api/crm"):
            import crm_access as _ca
            if not _ca.allowed(path, self._actor()):
                return self._send(403, _ca.refusal(path))
            # ⛒ 432: позначку «це ТОВАРНІ двері» ставлять ВОРОТА --
            # одне місце на читання й запис. Ріже кухонні поля `_send`.
            self._crm_product = _ca.is_product(path)

        # ⭐⭐⭐ 470: КОРІНЬ — ЦЕ ДОМАШНЯ. Рішення Андрія 04.09.2026.
        # Домашня однакова для всіх: замки на непридбаному показує сама
        # сторінка, питаючи тих самих суддів, що вирішують долю розділів.
        if path in ("/", "/home", "/home.html"):
            return self._serve_home()

        # Чат отримав власне імʼя. Старе `/index.html` лишається робочим:
        # посилання, які вже комусь роздані, ламати не можна.
        if path in ("/chat", "/chat.html", "/index.html"):
            return self._serve_ui()

        if path == "/setup" or path == "/setup.html":
            page = config.UI_DIR / "setup.html"
            if not page.exists():
                return self._send(500, {"error": "setup_ui_missing"})
            return self._send(200, self._localized_html(page),
                              content_type="text/html; charset=utf-8")

        if path == "/automations" or path == "/automations.html":
            page = config.UI_DIR / "automations.html"
            if not page.exists():
                return self._send(500, {"error": "automations_ui_missing"})
            return self._send(200, page.read_text(encoding="utf-8").encode("utf-8"),
                              content_type="text/html; charset=utf-8")

        if path == "/telegram" or path == "/telegram.html":
            page = config.UI_DIR / "telegram.html"
            if not page.exists():
                return self._send(500, {"error": "telegram_ui_missing"})
            return self._send(200, self._localized_html(page),
                              content_type="text/html; charset=utf-8")

        if path == "/genkey" or path == "/genkey.html":
            page = config.UI_DIR / "genkey.html"
            if not page.exists():
                return self._send(500, {"error": "genkey_ui_missing"})
            body = page.read_text(encoding="utf-8").encode("utf-8")
            return self._send(200, body, content_type="text/html; charset=utf-8")

        if path == "/i18n.js":
            page = config.UI_DIR / "i18n.js"
            if not page.exists():
                return self._send(500, {"error": "i18n_missing"})
            body = page.read_text(encoding="utf-8").encode("utf-8")
            return self._send(200, body,
                              content_type="application/javascript; charset=utf-8")

        if path == "/api/telegram/users":
            import telegram_access, telegram_bot
            import config as _cfg
            snap = telegram_access.snapshot()
            snap["bot"] = telegram_bot.status()
            snap["support_mode"] = _cfg.TELEGRAM_SUPPORT_MODE
            return self._send(200, snap)

        if path == "/api/update/check":
            import update as _upd
            return self._send(200, _upd.check_for_update())

        if path == "/api/health":
            try:
                import license as _lic
                _role = _lic.role()
            except Exception:
                _role = "admin"
            try:
                import costs as _costs
                _sess = _costs.session()
            except Exception:
                _sess = {}
            return self._send(200, {
                "ok": True,
                "orchestrator": "python_global_orchestrator",
                "brain": config.provider_status(),
                "artifacts": artifacts.capabilities(),
                "role": _role,
                # ⛒ 515: ОДИН СУДДЯ. Доти тут відповідала сама ліцензія —
                # і домашня показувала службові входи будь-кому, хто увійшов.
                "is_admin": self._is_admin(),
                # ⭐⭐⭐ 631: розділи НЕКУПЛЕНИХ модулів. Домашня одноосібного
                # клієнта (без входу, `me` порожнє) інакше не знала б, що
                # плитку ховати, — і вела б людину у відмову.
                "closed_sections": _closed_sections_631(),
                "costs": {"session_usd": round(_sess.get("usd", 0.0), 4),
                          "session_calls": _sess.get("calls", 0)},
            })

        if path == "/api/support":
            import support
            return self._send(200, support.summary())

        # ── Кнопка «Допомога з технічних питань» ─────────────────────────────
        # Доступна КЛІЄНТУ (не адмінська): це його спосіб покликати підтримку.
        # Сервер нічого не надсилає — лише показує, що піде у файл.
        if path == "/api/support_report/preview":
            import support_report
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            opts = {"task_texts": (q.get("task_texts", ["0"])[0] == "1")}
            rep = support_report.build(opts)
            rep["folder"] = str(support_report.reports_dir())
            return self._send(200, rep)

        if path == "/api/automations/jobs":
            # ⛒ 624: ЩО ВЗАГАЛІ ВМІЄ ПЛАТФОРМА БЕЗ МОДЕЛІ. Паспорти лежать у
            # `data_jobs` — другого переліку тут не заводимо.
            import data_jobs as _dj
            import scheduler as _sch
            _busy = {a.get("job") for a in _sch.list_automations()
                     if a.get("kind") == "data_sync"}
            _out = []
            for _p in _dj.passports():
                # ⛒ Регулярним може бути лише обхід, який не питає параметрів:
                # «прочитати документацію тендера UA-…» за розкладом безглузде —
                # номер тендера щодня інший. Пропонуємо тільки те, що справді
                # вміє ходити саме.
                if _p.get("params"):
                    continue
                _out.append({
                    "job": _p.get("id"),
                    "name": _p.get("name") or _p.get("id"),
                    "does": _p.get("does") or "",
                    "free": bool(_p.get("free", True)),
                    "ready": bool(_p.get("ready_ok", True)),
                    "ready_why": _p.get("ready_reason") or "",
                    "already": _p.get("id") in _busy,
                })
            return self._send(200, {"jobs": _out})

        if path == "/api/automations":
            return self._send(200, {"automations": scheduler.list_automations()})

        if path == "/api/llm/config":
            st = config.provider_status()
            # ⭐ 11.08.2026: перелiк для екрана дає ОДИН писар — той, що
            # питає провайдера. Зашитий рядок лишився тiльки запасним.
            st["suggestions"] = models_live.suggestions()
            st["model_ranks"] = models_live.ranks_for(st["suggestions"])
            st["demo"] = (config.ENV.get("DEMO_MODE") == "1")
            return self._send(200, st)

        if path == "/api/capabilities":
            return self._send(200, capabilities.self_model())

        if path == "/api/styles":
            import styles
            return self._send(200, {"styles": styles.list_styles()})

        if path == "/api/threads":
            return self._send(200, {"threads": threads.list_threads()})

        if path.startswith("/api/threads/"):
            tid = path.split("/api/threads/", 1)[1]
            rec = threads.get(tid)
            if not rec:
                return self._send(404, {"error": "thread_not_found"})
            return self._send(200, rec)

        if path == "/api/projects":
            return self._send(200, {"projects": projects.list_projects()})

        if path.startswith("/api/projects/"):
            rest = path.split("/api/projects/", 1)[1]
            if rest.endswith("/documents"):
                pid = rest[:-len("/documents")]
                return self._send(200, {"documents": projects.documents(pid)})
            rec = projects.get(rest)
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/registry":
            return self._send(200, {"systems": registry.load_systems()})

        if path == "/api/connectors":
            return self._send(200, {"connectors": registry.connector_inventory()})

        # ⭐⭐⭐ ДВЕРІ ДО ЧУЖОГО СЕРВІСУ (12.08.2026, зміна 163).
        # Два кроки одного шляху: людина натискає «Підключити» → ми ведемо її
        # на екран згоди сервісу → сервіс повертає її сюди з разовим кодом →
        # ми міняємо код на ключ і кладемо його туди, куди дивляться ворота.
        # ⛒ Ендпоінти ЗАГАЛЬНІ (по `<id>`): новий конектор = новий рядок у
        # `connector_oauth.DOORS`, і цього файла чіпати не треба.
        if path.startswith("/api/connectors/") and path.endswith("/auth/start"):
            cid = path[len("/api/connectors/"):-len("/auth/start")]
            import connector_oauth
            # ⛒ Платний рівень: вимкненої речі не існує навіть як сторінки.
            if not connector_oauth.enabled():
                return self._send(404, {"error": "not_found"})
            url, err = connector_oauth.start(cid)
            if err:
                return self._send(200, _oauth_page("Підключення не почалось", err, False),
                                  content_type="text/html; charset=utf-8")
            return self._send(302, b"", content_type="text/html; charset=utf-8",
                              headers={"Location": url})

        if path.startswith("/api/connectors/") and path.endswith("/oauth/callback"):
            cid = path[len("/api/connectors/"):-len("/oauth/callback")]
            import connector_oauth
            if not connector_oauth.enabled():
                return self._send(404, {"error": "not_found"})
            from urllib.parse import urlparse as _up, parse_qs as _pq
            q = _pq(_up(self.path).query)
            ok, err = connector_oauth.finish(
                cid,
                (q.get("code", [""])[0] or ""),
                (q.get("state", [""])[0] or ""),
                (q.get("error", [""])[0] or ""))
            if not ok:
                return self._send(200, _oauth_page("Не підключено", err, False),
                                  content_type="text/html; charset=utf-8")
            caveat = connector_oauth.caveat(cid)
            return self._send(200, _oauth_page(
                "Підключено",
                ("Доступ надано. Поверніться в платформу — картка конектора вже "
                 "показує «підключено». " + caveat).strip(), True),
                content_type="text/html; charset=utf-8")

        if path == "/api/runs":
            return self._send(200, {"runs": store.list_runs()})

        if path == "/api/egress/log":
            # Журнал виходів назовні (режим максимального збереження) — доказ, що
            # жоден вихід не стався без явного дозволу. Найновіші — в кінці.
            import egress_guard
            return self._send(200, {"log": egress_guard.tail(100),
                                    "stealth": egress_guard.stealth_on()})

        if path == "/api/version":
            import update
            return self._send(200, {"version": update.current_version()})

        if path == "/api/license":
            import license as licensing
            st = licensing.status()
            st["entitlement"] = licensing.entitlement()
            return self._send(200, st)

        if path == "/api/license/admin":
            return self._send(200, {"admin": config.LICENSE_ADMIN})

        # ═══════ ДІАГНОСТИКА ТЕНДЕРА БЕЗ ГРОШЕЙ (17.08.2026, зміна 194) ═══════
        # 🩸🩸🩸 СЛОВО АНДРІЯ 17.08: «прогін ми робимо ТІЛЬКИ тоді, коли всі засоби
        # використані». Я двічі за день платив за живий прогін лише для того, щоб
        # подивитись, ЩО платформа прочитала з документації і ЯКИЙ перелік із
        # цього вийшов. Обидві відповіді дає КОД, а не модель, — але дістатись до
        # них можна було лише через платний конвеєр із чотирма агентами.
        # ⛒ ЦІ ДВЕРІ — ТОЙ САМИЙ КОД БЕЗ ЖОДНОГО ВИКЛИКУ МОДЕЛІ. Вони читають
        # документацію з Прозорро (безкоштовне джерело) і показують рівно те, що
        # побачить складач пакета: які файли прочитано, чого не прочитано, чи не
        # обрізано, який обсяг вимог видно, який перелік дає код і що з нього
        # прибрало правило «графа бланка — не документ». Ціна виклику — НУЛЬ.
        # ⚠ Двері адмінські й лише ЧИТАЮТЬ: свого стану не пишуть, нічого не
        # надсилають, у пакет не втручаються.
        if path == "/api/tender/diagnose":
            from urllib.parse import urlparse as _upd, parse_qs as _pqd
            tid = (_pqd(_upd(self.path).query).get("id") or [""])[0].strip()
            if not tid:
                return self._send(400, {"error": "потрібен номер: ?id=UA-…"})
            try:
                import filetext as _ft
                import tender_docs as _td
                import tender_pack as _tp
                res = _td.read_docs(tid, max_files=_td.MAX_FILES_DEFAULT)
                if not res.get("ok"):
                    return self._send(200, {"ok": False, "tender_id": tid,
                                            "reason": res.get("reason") or ""})
                files = res.get("files") or []
                material, cut_notes = _td.material_blocks(files)
                gaps = ["%s — %s" % (s.get("title") or "документ",
                                     s.get("why") or "причина невідома")
                        for s in (res.get("skipped") or [])] + list(cut_notes)
                items = _tp.extra_requirements_in(material)
                fields = [i for i in items if _tp.is_form_field(i)]
                state = _tp.tender_state(tid)
                return self._send(200, {
                    "ok": True, "tender_id": tid,
                    "stan": {"strok": state.get("deadline"),
                             "dniv_lyshylos": state.get("days_left"),
                             "vidmina": state.get("cancelled"),
                             "zakryta": state.get("closed"),
                             "chomu": state.get("why")},
                    "fayly": [{"nazva": f.get("title"), "znakiv": f.get("chars"),
                               "obrizano": _ft.was_capped(f.get("text") or "")}
                              for f in files],
                    "ne_prochytano": gaps,
                    "use_prochytano": bool(res.get("complete")) and not cut_notes,
                    "znakiv_materialu": len(material),
                    "obsyah_vymoh": _tp.requirements_volume(material),
                    "perelik_z_materialu": items,
                    "hrafy_blankiv": fields,
                    "ne_vyznani_vymohamy": [b.get("heading")
                                            for b in _tp.unclaimed_lists(material)][:12],
                })
            except Exception as e:
                return self._send(500, {"ok": False, "tender_id": tid,
                                        "error": "%s: %s" % (type(e).__name__, e)})

        if path == "/api/update/check":
            import update
            return self._send(200, update.check_for_update())

        if path == "/api/crm/list":
            import crm
            return self._send(200, {"active": crm.list_clients(False),
                                    "archived": crm.list_clients(True),
                                    "counts": crm.counts()})

        if path == "/api/crm/products":
            # ⭐ ЕТАП 4: що взагалі можна купити. Перелік — з ОДНОГО місця
            # (`make_client_build.PRODUCT_SYSTEMS`), назви — з реєстру.
            import product_scope as _mcb   # ⛒ 561в: суддя складу, а не складальник
            import registry as _reg
            _names = {x.get("id"): (x.get("name") or x.get("id"))
                      for x in _reg.load_systems()}
            return self._send(200, {"systems": [
                {"id": _sid, "name": _names.get(_sid, _sid)}
                for _sid in sorted(_mcb.PRODUCT_SYSTEMS,
                                   key=lambda i: (_names.get(i, i) or "").lower())],
                # ⭐ 631: модулі, що продаються окремо, — з того самого судді.
                "modules": [{"id": _m, "name": _n}
                            for _m, _n in sorted(_mcb.PRODUCT_MODULES.items())]})

        # ⭐⭐⭐ 533: ДВЕРІ ДО БАЗИ ТОВАРІВ І ПОСЛУГ. Рушій `goods.py` стоїть
        # із 04.09.2026, але дверей до нього не було ЖОДНИХ: база жила лише
        # всередині, і жоден екран не міг її ні показати, ні поповнити.
        # ⛒ Слово «products» тут уже зайняте: `/api/crm/products` — це НАШІ
        # системи, які клієнт купує в нас. Товар КЛІЄНТА зветься `goods`, як і
        # рушій: півімені гірше за чесну назву (урок 530б).
        if path in ("/api/goods/list", "/api/goods/card"):
            import goods as _gd
            from urllib.parse import urlparse, parse_qs
            _q = parse_qs(urlparse(self.path).query)
            # ⭐ ПЕРЕЛІК КОЛОНОК ЇДЕ З ОДНОГО МІСЦЯ (`goods.COLUMNS`): двері
            # своїх назв не вигадують, інакше екран і шаблон імпорту почали б
            # звати те саме поле двома словами.
            _cols = _gd.template_columns()
            if path == "/api/goods/card":
                _gid = (_q.get("id", [""])[0] or "").strip()
                _row = _gd.get(_gid)
                if not _row:
                    return self._send(404, {"error": "Товару %s немає в базі."
                                            % (_gid or "«»")})
                return self._send(200, {"good": _row, "columns": _cols,
                                        "traits": list(_gd.TRAITS),
                                        "kinds": _gd.KIND_NAMES})
            _kind = (_q.get("kind", [""])[0] or "").strip()
            _arch = (_q.get("archived", [""])[0] or "").strip()
            _want = None if _arch == "" else (_arch not in ("0", "false", "no"))
            try:
                _rows = _gd.all_goods(_kind, _want)
            except _gd.GoodsError as ex:
                return self._send(400, {"error": str(ex)})
            # ⭐ Пошук — і за назвою, І ЗА АРТИКУЛОМ: на складі шукають кодом,
            # у розмові з клієнтом — словом.
            _needle = (_q.get("q", [""])[0] or "").strip().casefold()
            if _needle:
                _rows = [r for r in _rows
                         if _needle in str(r.get("name", "")).casefold()
                         or _needle in str(r.get("sku", "")).casefold()]
            return self._send(200, {"goods": _rows, "counts": _gd.count(),
                                    "columns": _cols, "traits": list(_gd.TRAITS),
                                    "kinds": _gd.KIND_NAMES})

        if path == "/api/crm/card":
            import crm
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            cust = (q.get("customer", [""])[0] or "").strip()
            card = crm.card_public(cust)
            if not card:
                return self._send(404, {"error": "client_not_found"})
            return self._send(200, card)

        if path == "/api/crm/board":
            # ⭐ 594: ті самі двері, якими ходить екран канбану, теж звужуються
            # за полем картки. Фільтр, що працює лише на сусідніх дверях, для
            # людини не існує.
            import deals as _dl594b
            from urllib.parse import urlparse as _up594b, parse_qs as _pq594b
            _q594b = {k: v[0] for k, v in
                      _pq594b(_up594b(self.path).query or "").items()}
            try:
                _f594b, _v594b = _dl594b.check_filter(_q594b.get("field", ""),
                                                      _q594b.get("value", ""))
            except _dl594b.DealError as _ex594b:
                return self._send(400, {"error": str(_ex594b)})
            out594b = _dl594b.board(_f594b, _v594b)
            out594b["filters"] = _dl594b.filters()
            out594b["filter"] = {"field": _f594b, "value": _v594b}
            out594b["counts_all"] = _dl594b.count_filtered(_f594b, _v594b)
            return self._send(200, out594b)

        if path == "/api/crm/pipeline":
            import deals as _dl594p
            from urllib.parse import urlparse as _up594p, parse_qs as _pq594p
            _q594p = {k: v[0] for k, v in
                      _pq594p(_up594p(self.path).query or "").items()}
            try:
                _f594p, _v594p = _dl594p.check_filter(_q594p.get("field", ""),
                                                      _q594p.get("value", ""))
            except _dl594p.DealError as _ex594p:
                return self._send(400, {"error": str(_ex594p)})
            out594 = _dl594p.pipeline(_f594p, _v594p)
            out594["filters"] = _dl594p.filters()
            out594["filter"] = {"field": _f594p, "value": _v594p}
            return self._send(200, out594)

        if path == "/api/crm/inbox":
            import crm
            return self._send(200, {"inbox": crm.inbox()})

        if path in ("/api/crm/party_card", "/api/crm/entity_card"):
            # ⭐⭐⭐ ІСТОРІЯ ВЗАЄМОВІДНОСИН (крок B3, 14.08.2026). Дві частини —
            # «що існує» (реєстр звʼязків) і «що сталось» (протокол + спілкування) —
            # рахує ОДИН читач `relations`. Сервер їх не змішує і не складає
            # власних формулювань: другий писар правди розійшовся б із першим.
            import relations as _rel
            import entity as _ent
            from urllib.parse import urlparse as _up4, parse_qs as _pq4
            q4 = {k: v[0] for k, v in _pq4(_up4(self.path).query or "").items()}
            # ⭐ C1: та сама відповідь про БУДЬ-ЯКУ сутність. `relations.card`
            # від першого дня написаний про будь-який вид — другого читача
            # (окремо «картка угоди») ми не заводимо.
            raw_ref = (q4.get("ref") or "").strip()
            pid = (q4.get("id") or "").strip()
            if not raw_ref and not pid:
                return self._send(400, {"error": "no_party"})
            try:
                ref = _ent.norm(raw_ref) if raw_ref else _ent.ref(_ent.KIND_PARTY, pid)
                limit = int(q4.get("limit") or _rel.FEED_PAGE)
            except Exception as ex:
                return self._send(400, {"error": str(ex)})
            # ⭐ C3: фільтр і сторінка ЇДУТЬ У ЧИТАЧА, а не робляться на екрані.
            # Порахувати «показано N із M» у браузері означало б завести другого
            # писаря тієї самої арифметики — і телеграм показав би своє число.
            try:
                _card = _rel.card(
                    ref, limit,
                    offset=int(q4.get("offset") or 0),
                    source=(q4.get("source") or "").strip(),
                    kind=(q4.get("kind") or "").strip(),
                    about=(q4.get("about") or "").strip(),
                    since=(q4.get("since") or "").strip(),
                    until=(q4.get("until") or "").strip())
                # ⭐ C1: картка КОНТРАГЕНТА несе перелік його угод — і бере його
                # в того самого писаря, що й решта екранів. Інакше контакт без
                # картки-ліцензії показував би «угод немає», маючи їх.
                if _ent.kind_of(ref) == _ent.KIND_PARTY:
                    import deals as _dl2
                    _card["deals"] = _dl2.tiles_of_party(_ent.ident_of(ref))
                    # ⭐ D1: хто веде цього клієнта й з кого вибирати. Дані
                    # складає ПИСАР ДОВІДНИКА (`parties.manager_card`): екран не
                    # питає оргструктуру сам, інакше писарів «хто веде» стало б двоє.
                    import parties as _pt3
                    _card["manager"] = _pt3.manager_card(_ent.ident_of(ref))
                    # ⭐ 247: ЗА СКІЛЬКОМА РУЧКАМИ ВПІЗНАЄМО + словник назв.
                    # Екран не рахує це сам і не тримає свого переліку ручок:
                    # зашитий на екрані словник не показав би нову ручку взагалі.
                    _card["handles_signal"] = _pt3.handles_summary(_ent.ident_of(ref))
                    # ⭐⭐⭐ 648: ДОКУМЕНТИ КЛІЄНТА ЇДУТЬ РАЗОМ ІЗ КАРТКОЮ (власні +
                    # усіх його угод) — з того самого писаря, що й картка угоди.
                    import deal_documents as _dd648
                    _card["party_docs"] = _dd648.documents_of_party(_ent.ident_of(ref))
                    _card["party_doc_kinds"] = [
                        {"id": _k, "name": _dd648.KIND_NAMES[_k]} for _k in _dd648.PARTY_KINDS]
                # ⭐⭐⭐ 526: ВЛАСНІ ПОЛЯ ЇДУТЬ РАЗОМ ІЗ КАРТКОЮ. Окремий похід
                # екрана за ними означав би другого писаря складу картки:
                # склад приїхав би з одного запиту, а вміст — з іншого, і на
                # повільній машині людина побачила б картку без своїх полів.
                # ⛒ Вид, який розширювати не можна (прогін, конектор), — це не
                # помилка: у нього власних полів просто не буває.
                import card_values as _cv3
                try:
                    _card["own_fields"] = _cv3.card(ref)
                except _cv3.CardValueError:
                    _card["own_fields"] = []
                # ⭐⭐⭐ 536: ПОЗИЦІЇ ЇДУТЬ РАЗОМ ІЗ КАРТКОЮ — з тієї
                # самої причини, що й власні поля: окремий похід
                # екрана за ними завів би другого писаря складу
                # картки. ⛒ Читаємо ЗНІМКИ, а не базу товарів.
                if _ent.kind_of(ref) == _ent.KIND_DEAL:
                    import deal_items as _di
                    _card["deal_items"] = _di.items_of(_ent.ident_of(ref))
                    # ⭐ 585: документи їдуть тим самим возом. Другий похід
                    # екрана за ними завів би другого писаря складу картки.
                    import deal_documents as _dd585c
                    _did585c = _ent.ident_of(ref)
                    _card["deal_docs"] = _dd585c.documents_of(_did585c)
                    _card["deal_doc_kinds"] = [
                        {"id": k, "name": _dd585c.KIND_NAMES[k]}
                        for k in _dd585c.KINDS]
                    _card["deal_has_contract"] = _dd585c.has_contract(_did585c)
                    # ⭐ 615: дата підписання їде тим самим возом і від ТОГО
                    # САМОГО писаря — окремого поля з тією самою датою немає.
                    _card["deal_signed_at"] = _dd585c.signed_at(_did585c)
                # ⭐⭐⭐ 591: ЧУЖА КАРТКА КОНТРАГЕНТА ЇДЕ ПАСПОРТОМ, а не
                # відмовою. Судить той самий суддя, що й двері, — другого
                # рішення про те саме поруч не заводимо.
                try:
                    import entity_scope as _vs591
                    _emp591 = str((self._actor() or {}).get("employee_id") or "")
                    if (_emp591 and not self._is_admin()
                            and _ent.kind_of(ref) == _ent.KIND_PARTY
                            and not _vs591.may_see(_emp591, _vs591.KIND_PARTY,
                                                   _ent.ident_of(ref))):
                        _card = _vs591.passport(_card)
                    # ⭐ 592: чужа УГОДА теж їде без стрічки — у журналі угоди
                    # ті самі суми лежать словами.
                    if (_emp591 and not self._is_admin()
                            and _ent.kind_of(ref) == _ent.KIND_DEAL
                            and not _vs591.deal_is_mine(_emp591,
                                                        _ent.ident_of(ref))):
                        _card = _vs591.deal_passport(_card)
                except Exception:
                    pass
                return self._send(200, _card)
            except Exception as ex:
                # Невідомий вид у фільтрі «про кого» — відмова СЛОВАМИ, а не 500.
                return self._send(400, {"error": str(ex)})

        if path == "/api/crm/spread":
            # ⭐ C2: черга «Рознести» — сестра черги «Не оброблені». Тут лежать
            # листи від ВІДОМИХ контактів, у яких немає адреси угоди. Кожен
            # рядок каже, ЧОМУ платформа не рознесла його сама.
            import deal_mail as _dm
            from urllib.parse import urlparse as _up6, parse_qs as _pq6
            q6 = {k: v[0] for k, v in _pq6(_up6(self.path).query or "").items()}
            rows = _dm.pending((q6.get("party") or "").strip())
            # ⭐ 618: екран мусить знати, ХТО ЗАРАЗ ДИВИТЬСЯ, щоб кнопка
            # «це мій лист» була одним кліком, а не вибором із переліку
            # всієї компанії. Ім’я каже СЕРВЕР — екран його не вгадує.
            try:
                _me6 = str((self._actor() or {}).get("employee_id") or "")
            except Exception:
                _me6 = ""
            return self._send(200, {"items": rows, "count": len(rows),
                                    "me": _me6})

        if path == "/api/crm/deals":
            # ⭐ C1: воронка й плитка тепер про УГОДИ. Форма відповіді та сама,
            # що й у `board()`, — екран канбану не переписується.
            # ⭐ 594: і звуження за полем картки (напрям угоди, категорія…).
            import deals as _dl
            from urllib.parse import urlparse as _up594, parse_qs as _pq594
            _q594 = {k: v[0] for k, v in
                     _pq594(_up594(self.path).query or "").items()}
            try:
                _f594, _v594 = _dl.check_filter(_q594.get("field", ""),
                                                _q594.get("value", ""))
            except _dl.DealError as _ex594:
                return self._send(400, {"error": str(_ex594)})
            return self._send(200, {"board": _dl.board(_f594, _v594),
                                    "counts": _dl.count_filtered(_f594, _v594),
                                    "filters": _dl.filters(),
                                    "filter": {"field": _f594, "value": _v594},
                                    "stages": _dl.STAGES})

        if path == "/api/crm/deal_card":
            import deals as _dl
            from urllib.parse import urlparse as _up5, parse_qs as _pq5
            q5 = {k: v[0] for k, v in _pq5(_up5(self.path).query or "").items()}
            did = (q5.get("id") or "").strip()
            if not did:
                return self._send(400, {"error": "no_deal"})
            card = _dl.card(did)
            if card is None:
                return self._send(404, {"error": "Угоди %s немає в реєстрі." % did})
            return self._send(200, card)

        # ⭐⭐⭐ БУДОВА КАРТОК (зміна 454). Читання -- НЕ адмінське: екран мусить
        # намалювати поля кожному, хто відкрив картку. Міняти будову має право
        # лише адміністратор, і це стоїть на ЗАПИСІ (`_ADMIN_POST_PATHS`).
        # ⛒ 455: ДВЕРІ, ЯКІ КАЖУТЬ ЛИШЕ «ЧИ МОЖНА». Вхід у консолі їде
        # ЗАВЖДИ і схований; показує його живий суддя, а не збірка — бо в
        # клієнта теж є свій адміністратор, і будова карток потрібна саме йому.
        # ⭐ 588: суддя тут ТОЙ САМИЙ, що на дверях самої сторінки будови карток
        # (`/cards` -> розділ «Будова карток»). Доти він питав лише «чи
        # адміністратор» — і людина з правом на розділ не бачила б входу, який
        # їй уже відчинено.
        # ⭐⭐⭐ 585: ДОКУМЕНТИ УГОДИ. Реєстр номерів їде разом зі списком —
        # людині треба бачити не лише «що причеплено», а й «який номер платформа
        # видасть наступним», інакше вона знову набере його руками.
        if path == "/api/crm/mailboxes":
            # ⭐⭐⭐ 648: ПОШТА В CRM. Паролів тут немає за побудовою (`boxes()`).
            import mail_intake as _mi648
            _own648 = []
            try:
                import taskdesk_people as _pp648
                _own648 = [{"id": e.get("id"), "name": e.get("full_name")}
                           for e in (_pp648.employees() or []) if e.get("active")]
            except Exception:
                _own648 = []
            return self._send(200, {"boxes": _mi648.boxes(), "owners": _own648,
                                    "tick_min": _mi648.TICK_MIN})

        if path == "/api/crm/party_docs":
            import deal_documents as _dd648g
            from urllib.parse import urlparse as _up648, parse_qs as _pq648
            _pid648 = ((_pq648(_up648(self.path).query).get("party", [""])[0]) or "").strip()
            return self._send(200, _dd648g.documents_of_party(_pid648))

        if path == "/api/crm/deal_docs":
            import deal_documents as _dd585
            import doc_numbers as _dn585
            from urllib.parse import urlparse as _up585, parse_qs as _pq585
            _q585 = _pq585(_up585(self.path).query)
            _did585 = (_q585.get("deal", [""])[0] or "").strip()
            return self._send(200, {"deal": _did585,
                                    "docs": _dd585.documents_of(_did585),
                                    "kinds": [{"id": k, "name": _dd585.KIND_NAMES[k]}
                                              for k in _dd585.KINDS],
                                    "has_contract": _dd585.has_contract(_did585),
                                    "next_number": _dn585.today()})

        if path == "/api/cards/access":
            return self._send(200,
                              {"admin": bool(self._may_admin_path("GET", "/cards"))})

        if path == "/api/cards/fields":
            import card_fields as _cf
            from urllib.parse import urlparse as _upc, parse_qs as _pqc
            qc = {k: v[0] for k, v in _pqc(_upc(self.path).query or "").items()}
            card = (qc.get("card") or "").strip()
            try:
                fields = _cf.layout(card) if card else _cf.all_fields(active=True)
            except _cf.FieldError as ex:
                return self._send(400, {"error": str(ex)})
            import entity as _entc
            # ⛒ 456: ВИВЕДЕНІ З РОБОТИ ПОЛЯ ТЕЖ МАЮТЬ БУТИ ВИДНІ — інакше
            # «вивести з роботи» означало б «знищити», а екран обіцяє
            # людині зворотний шлях. Віддаємо їх ОКРЕМИМ переліком і лише
            # адміністраторові: заповнювачу картки вони ні до чого, він і
            # так бачить тільки чинні поля.
            off = (_cf.all_fields(card, active=False)
                   if card and self._is_admin() else [])
            return self._send(200, {
                "card": card,
                "fields": fields,
                "off": off,
                # ⛒ Екран не вгадує ані переліку карток, ані переліку типів:
                # обидва приходять від того самого писаря, що їх і судить.
                "cards": [{"id": c, "name": _entc.KIND_NAMES[c]} for c in _cf.CARDS],
                "types": [{"id": t, "name": _cf.TYPE_NAMES[t]} for t in _cf.TYPES]})

        # ⭐⭐⭐ 530: ЗАБРАТИ ФАЙЛ. Двері щоденні (не адмінські): хто бачить
        # картку — той бачить і прикріплене до неї. Окремого права на файл
        # немає, це випливає з ухваленого в 527.
        # 🩸 Файла немає на диску — кажемо СЛОВАМИ і кодом 404, а не мовчимо:
        # адміністратор міг прибрати його руками, і платформа не має вдавати.
        # ⭐⭐⭐ 532: СХОВИЩЕ ОЧИМА АДМІНІСТРАТОРА. Ревізія без інструмента —
        # це дзвінок без інструмента: щоб СВІДОМО вирішувати про глибину
        # зберігання, треба бачити, що займає місце і що вже нікуди не
        # прикріплене. Замок стоїть у `_ADMIN_GET_PATHS`.
        # ⭐⭐⭐ 616: ПРОПОЗИЦІЯ МАГАЗИНУ. Сервер не рахує тут нічого сам —
        # усе рахує ОДИН писар пропозиції (`shop.py`).
        if path == "/api/shop/offer":
            import shop as _shop616
            try:
                return self._send(200, _shop616.offer())
            except _shop616.ShopError as ex:
                return self._send(400, {"error": "refused", "message": str(ex)})

        # ⭐⭐⭐ 616: ДОВІДНИК. Той самий шов: читає `manual.py`, сервер лише везе.
        if path == "/api/manual":
            import manual as _man616
            try:
                return self._send(200, _man616.screen())
            except _man616.ManualScreenError as ex:
                return self._send(400, {"error": "refused", "message": str(ex)})

        if path == "/api/manual/search":
            import manual as _man616s
            from urllib.parse import urlparse as _up616, parse_qs as _pq616
            _q616 = {k: v[0] for k, v in
                     _pq616(_up616(self.path).query or "").items()}
            try:
                return self._send(200, {"hits": _man616s.search(_q616.get("q"))})
            except _man616s.ManualScreenError as ex:
                return self._send(400, {"error": "refused", "message": str(ex)})

        if path == "/api/files/storage":
            import card_values as _cv532
            import file_store as _fs532
            _use532 = _cv532.file_usage()
            _rows532 = []
            for _r532 in _fs532.all_files():
                _r532 = dict(_r532)
                _r532["attached"] = _use532.get(_r532["id"], [])
                _r532["orphan"] = not _r532["attached"]
                _rows532.append(_r532)
            return self._send(200, {"usage": _fs532.usage(), "files": _rows532})

        if path == "/api/files/get":
            import file_store as _fs530g
            from urllib.parse import urlparse as _up530, parse_qs as _pq530
            _q530g = {k: v[0] for k, v in _pq530(_up530(self.path).query or "").items()}
            _fid530 = (_q530g.get("id") or "").strip()
            try:
                _p530 = _fs530g.path_of(_fid530)
            except _fs530g.FileStoreError as ex:
                return self._send(404, {"error": str(ex)})
            _info530 = _fs530g.info(_fid530) or {}
            return self._send_download(_p530, _info530.get("name") or "file")

        if path == "/api/cards/card":
            import card_values as _cv
            from urllib.parse import urlparse as _upv, parse_qs as _pqv
            qv = {k: v[0] for k, v in _pqv(_upv(self.path).query or "").items()}
            try:
                rows = _cv.card((qv.get("ref") or "").strip())
            except _cv.CardValueError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ref": (qv.get("ref") or "").strip(),
                                    "fields": rows})

        if path == "/api/crm/parties":
            # ⭐ КЛІЄНТСЬКА БАЗА (довідник контрагентів). Тип і роль — необовʼязкові
            # фільтри; картку угоди тут не показуємо — це різні сутності.
            import crm as _crm
            import parties as _pt
            from urllib.parse import urlparse as _up3, parse_qs as _pq3
            q = {k: v[0] for k, v in _pq3(_up3(self.path).query or "").items()}
            try:
                items = _pt.all_parties(role=q.get("role", ""), kind=q.get("kind", ""))
            except _pt.PartyError as ex:
                return self._send(400, {"error": str(ex)})
            for it in items:
                it["customer"] = _crm.card_of_party(it.get("id", ""))
            _res = {"parties": items, "counts": _pt.count()}
            _res.update(_crm_words())
            return self._send(200, _res)

        if path == "/api/crm/party_search":
            # ⭐⭐⭐ D2 (16.08.2026): ЗНАЙТИ клієнта, коли їх три тисячі.
            # ⛒ Сервер нічого не шукає сам і нічого не фільтрує: і пошук, і
            # словник фільтрів, і сторінки — в ОДНОГО писаря `party_search`.
            # Другий пошук (у розмітці чи тут) розійшовся б із ним назавтра.
            import parties as _pt5
            import party_search as _ps
            from urllib.parse import urlparse as _up6, parse_qs as _pq6
            q6 = {k: v[0] for k, v in _pq6(_up6(self.path).query or "").items()}
            try:
                res = _ps.search(query=q6.get("q", ""),
                                 filter=q6.get("filter", ""),
                                 page=q6.get("page", ""),
                                 per=q6.get("per", ""),
                                 sort=q6.get("sort", ""),
                                 dir=q6.get("dir", ""),
                                 # ⭐ D3: стан (у роботі / архів) і фільтр
                                 # «клієнти менеджера X» — слова їдуть у того
                                 # самого писаря, а не розбираються тут.
                                 state=q6.get("state", ""),
                                 manager=q6.get("manager", ""))
            except _ps.SearchError as ex:
                return self._send(400, {"error": str(ex)})
            res.update(_crm_words())
            return self._send(200, res)

        if path == "/api/crm/channels":
            import config as _cfg
            return self._send(200, {
                "email": {"available": True, "mode": "mailto",
                          "hint": "Лист відкривається у вашій поштовій програмі; пряму відправку (SMTP) можна підключити пізніше."},
                "telegram": {"available": bool(getattr(_cfg, "TELEGRAM_BOT_TOKEN", "") or _cfg.ENV.get("TELEGRAM_BOT_TOKEN")),
                             "connect": "/telegram",
                             "hint": "Підключіть бота у розділі Telegram, щоб писати клієнту з картки."},
                "call": {"available": True, "mode": "log",
                         "hint": "Дзвоніть через месенджер/телефон, а тут фіксуйте результат у історію."},
            })

        if path.startswith("/artifacts/"):
            return self._serve_artifact(path)

        return self._send(404, {"error": "not_found", "path": path})

    # ---- POST -------------------------------------------------------------
    def do_POST(self):
        path = self.path.split("?", 1)[0]

        if self._insecure_redirect():
            return

        _ok, _why = self._taskdesk_gate()
        if not _ok:
            return self._send(401, {"error": "login_required", "message": _why})

        # ⭐⭐⭐ 515б: АДМІНСЬКІ ВОРОТА СТОЯТЬ ПЕРШИМИ.
        # Замок був правильний, а сторінка `/cards` усе одно відкривалася:
        # її обробник стояв ВИЩЕ за ворота. Тому ворота живуть тут — одразу
        # після воріт «хто це» і ПЕРЕД усіма обробниками. Тоді новий обробник
        # не може випередити охорону, хоч би де його дописали.
        # ⭐⭐⭐ 524: ВОРОТА ТВОРЦЯ СТОЯТЬ ПЕРЕД АДМІНСЬКИМИ. На записі це
        # важить більше, ніж на читанні: за цими дверима не сторінка, а САМА
        # ВИДАЧА ключа. Власна перевірка всередині дверей лишається другим
        # замком, але вона питає лише збірку — людину питають ці ворота.
        if path in _CREATOR_POST_PATHS and not self._is_creator():
            import crm_access as _ca524p
            return self._send(403, _ca524p.refusal(path))

        _nd631 = self._not_delivered("POST", path)      # ⭐ 631: той самий замок
        if _nd631:
            return self._send(403, _nd631)

        if path in _ADMIN_POST_PATHS and not self._may_admin_path("POST", path):
            return self._send(403, self._section_refusal("POST", path))

        _see, _no = self._may_see_request("POST", path)
        if not _see:
            return self._send(403, _no)

        # ⭐ ДВЕРІ НАЗИВАЮТЬ СЕБЕ (зміна 171, 13.08.2026). «Хто натиснув і звідки»
        # відоме лише ТУТ, на вході; писарі протоколу цього не знають і знати не
        # мусять. Без цього рядка звіт протоколу чесно казав: «джерело не назвав
        # ЖОДЕН рядок — це прогалина». Крок роботи ВІДКРИВАЄ той, хто його починає
        # (той самий закон, що й `costs.start_run` у зміні 169).
        # ⚠ `clear()` перед `bind()`: сервер потоковий (потік на запит), але якби
        # потік колись перевикористали, контекст сусіднього запиту мовчки приписав
        # би роботу не тому клієнту.
        try:
            import protocol as _proto
            import entity as _ent
            _proto.clear()
            # 🩸 ХТО ДІЄ — ПИТАЄМО ЄДИНОГО ВІДПОВІДАЧА (`self._actor`), А НЕ ПОЛЕ.
            # Перший захід 171 читав сиру `self.actor` — сесію. Сесії в консолі
            # немає (Task Desk вимкнений), і журнал писав «діяч: (немає)», хоча
            # платформа чудово знає, що діє ВЛАСНИК. Поле зі схожою назвою — не
            # відповідь; відповідає `taskdesk_identity.resolve_actor`.
            _proto.bind(source=_proto.S_CONSOLE,
                        actor=_ent.person_of_actor(self._actor()))
        except Exception:
            pass

        # ⭐⭐⭐ ТРЕНАЖЕР — ЗАПИС (628). Замок стоїть вище, у
        # `_ADMIN_POST_PATHS` і під розділом `sec_trainer`.
        if path.startswith("/api/trainer/"):
            import trainer as _ac
            emp, name, team = self._trainer_who()
            body = self._read_json() or {}
            try:
                if path == "/api/trainer/new":
                    return self._send(200, _ac.engine().create(emp, name))
                if path == "/api/trainer/message":
                    return self._send(200, _ac.engine().message(
                        body.get("id") or "", body.get("text"),
                        body.get("request_id"), emp))
                if path == "/api/trainer/finish":
                    return self._send(200, _ac.engine().finish(
                        body.get("id") or "", emp))
                if path in ("/api/trainer/case_save", "/api/trainer/case_remove"):
                    if not team:
                        return self._send(403, {
                            "error": "trainer_refused",
                            "message": "Навчальні сценарії веде той, кому "
                                       "відкрито «бачити розбори команди»: "
                                       "паспорт сценарію — це еталон, за яким "
                                       "оцінюють знання продукту."})
                    if path.endswith("case_save"):
                        return self._send(200, {"case": _ac.save_case(body),
                                                "products": _ac.cases()})
                    _ac.remove_case(body.get("id") or "")
                    return self._send(200, {"products": _ac.cases()})
            except _ac.ModelUnavailable as e:
                # ⛒ Межа грошей і мовчання моделі — НЕ поломка сервера.
                # Людина мусить прочитати причину й побачити, що робити далі.
                return self._send(200, {"error": "trainer_model",
                                        "message": str(e)})
            except _ac.TrainerError as e:
                return self._send(403 if "чужа" in str(e) else 400,
                                  {"error": "trainer_refused", "message": str(e)})
            return self._send(404, {"error": "not_found"})

        if path == "/api/taskdesk/login":
            import taskdesk_identity as _tdid
            data = self._read_json()
            try:
                if data.get("account_id"):
                    token = _tdid.login_light(data.get("account_id"))
                else:
                    token = _tdid.login(data.get("login") or "", data.get("password") or "")
            except _tdid.IdentityError as e:
                return self._send(401, {"error": "login_failed", "message": str(e)})
            return self._send(200, {"ok": True},
                              headers={"Set-Cookie": _tdid.cookie_header(token)})

        if path == "/api/taskdesk/photo":
            import taskdesk_api as _tdapi
            data = self._read_json()
            try:
                return self._send(200, _tdapi.photo_set(getattr(self, "actor", None),
                                                        data.get("id") or "",
                                                        data.get("data") or ""))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/tasks/action":
            import taskdesk_api as _tdapi
            try:
                return self._send(200, _tdapi.run_task_action(
                    self._actor(), self._read_json()))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        # Вигляд списку, фільтр, збережені набори і вивантаження в Excel. Ворота
        # тут ті самі, що в задачах: веде сама людина, не адміністратор.
        if path == "/api/taskdesk/prefs/action":
            import taskdesk_api as _tdapi
            try:
                return self._send(200, _tdapi.run_prefs_action(
                    self._actor(), self._read_json()))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path in ("/api/taskdesk/people/action", "/api/taskdesk/access/action",
                    "/api/taskdesk/roles/action", "/api/taskdesk/worktypes/action"):
            import taskdesk_api as _tdapi
            table = ("people" if path.endswith("/people/action")
                     else "roles" if path.endswith("/roles/action")
                     else "worktypes" if path.endswith("/worktypes/action")
                     else "access")
            try:
                return self._send(200, _tdapi.run_action(getattr(self, "actor", None),
                                                         table, self._read_json()))
            except _tdapi.ApiError as e:
                return self._send(e.status, {"error": e.code, "message": str(e)})

        if path == "/api/taskdesk/logout":
            import taskdesk_identity as _tdid
            _tdid.logout(_tdid.token_from_cookies(self.headers.get("Cookie") or ""))
            return self._send(200, {"ok": True},
                              headers={"Set-Cookie": _tdid.clear_cookie_header()})

        # ⛒⛒⛒ 428: той самий суддя, що й на читанні. Друга редакція правила
        # розійшлась би з першою — і запис виявився б відкритішим за читання.
        if path.startswith("/api/crm"):
            import crm_access as _ca
            if not _ca.allowed(path, self._actor()):
                return self._send(403, _ca.refusal(path))
            # ⛒ 432: позначку «це ТОВАРНІ двері» ставлять ВОРОТА --
            # одне місце на читання й запис. Ріже кухонні поля `_send`.
            self._crm_product = _ca.is_product(path)

        if path == "/api/taskdesk/network/action":
            # 506: стоїть ПІСЛЯ адмінських воріт свідомо — сама дія в
            # переліку `_ADMIN_POST_PATHS`, тож оператор сюди не дійде.
            import network_access as _net
            _d = self._read_json()
            return self._send(200, _net.set_open(bool(_d.get("open"))))

        if path == "/api/taskdesk/https/action":
            # ⭐⭐⭐ 537: створити або перевипустити сертифікат сервера.
            # Ключ офісу створюється ОДИН раз і далі перевикористовується —
            # інакше після кожного оновлення довелось би знову обходити всі
            # компʼютери працівників. Віддаємо ПОВНИЙ стан мережі, щоб екран
            # не збирав правду з двох різних відповідей.
            import https_access as _sec
            import network_access as _netsec
            _made = _sec.make()
            _out = _netsec.state()
            _out["made"] = _made
            return self._send(200, _out)

        if path == "/api/support_report/save":
            import support_report
            data = self._read_json()
            keys = data.get("keys")
            opts = {"task_texts": bool(data.get("task_texts"))}
            res = support_report.save(message=(data.get("message") or ""),
                                      keys=(list(keys) if isinstance(keys, list) else None),
                                      options=opts)
            if data.get("open_folder", True):
                res["opened"] = support_report.open_folder(res.get("path"))
            return self._send(200, res)

        if path == "/api/support_report/open":
            import support_report
            data = self._read_json()
            return self._send(200, {"ok": support_report.open_folder(data.get("path"))})

        if path == "/api/chat/stream":
            import runstate
            data = self._read_json()
            message = (data.get("message") or "").strip()
            files = data.get("files") or []
            cancel_token = data.get("cancel_token") or ""
            runstate.clear(cancel_token)
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream; charset=utf-8")
            self.send_header("Cache-Control", "no-cache")
            self.send_header("Connection", "close")
            self.send_header("X-Accel-Buffering", "no")
            self.end_headers()
            self.close_connection = True  # закрити сокет після стріму

            def emit(etype, payload):
                try:
                    self.wfile.write(("data: " + json.dumps({"type": etype, "data": payload},
                                                             ensure_ascii=False) + "\n\n").encode("utf-8"))
                    self.wfile.flush()
                except Exception:
                    pass

            # Тред заводимо ДО спроби виконати: інакше на винятку немає куди
            # записати хід — і питання людини зникає разом з аварією.
            tid, incoming_fc = "", ""
            try:
                tid = data.get("thread_id") or threads.create()["id"]
            except Exception:
                pass
            try:
                # Новий чат, створений у проєкті: спершу зробити його членом проєкту,
                # ЩОБ контекст проєкту дійшов до мозку вже в ПЕРШОМУ повідомленні.
                _pid = data.get("project_id")
                if _pid:
                    try:
                        projects.add_thread(_pid, tid)
                    except Exception:
                        pass
                incoming_fc, _m = filetext.build_files_context(files) if files else ("", [])
                if not incoming_fc:
                    incoming_fc = data.get("files_context") or ""
                # Успадкувати документ із попередніх ходів, якщо зараз нічого не прикріплено.
                files_context = incoming_fc or threads.latest_files_context(tid)
                _url_ctx = tools.fetch_urls_in_text(message)
                if _url_ctx:
                    files_context = (files_context + "\n\n" + _url_ctx).strip()
                # ⭐ КАРТКА РОЗУМІННЯ (зміна 152): поправка людини живе ВЕСЬ ЧАТ,
                # тому лягає у файл чату, а не в памʼять вкладки.
                _und_cl = threads.understanding_of(tid)
                # ⛒ 581б. СЕРВЕР НЕ ЗНАЄ ІМЕН ПОЛІВ. Що в підтвердженні є
                # поправкою, а що керуванням, каже ОДИН писар — інакше кожен
                # новий рядок картки треба було б дописувати ще й сюди, і рядок
                # 581 (клас машини) саме тому мовчки з'їдався б.
                _fix = _und_srv.client_fields(data.get("confirm"))
                if _fix:
                    _und_cl = threads.set_understanding(tid, _fix) or _und_cl
                result = engine.handle_message(
                    self._actor(),
                    message=message or "(див. прикріплені файли)",
                    history=threads.history_for_brain(tid),
                    files_context=files_context,
                    pending=data.get("pending"),
                    confirm=data.get("confirm"),
                    understanding_client=_und_cl,
                    can_ask=True,
                    # ⛒ МОВА КОРИСТУВАЧА ЇДЕ В КОЖНОМУ ЗАПИТІ (зміна 255): доти
                    # сервер про неї не знав, і службові написи приходили не тією
                    # мовою, якою людина працює.
                    lang=data.get("lang"),
                    emit=emit,
                    should_cancel=(lambda: runstate.is_cancelled(cancel_token)) if cancel_token else None,
                    project_context=projects.context_for_thread(tid),
                    egress_allowed=bool(data.get("egress_allowed")),
                )
                _persist_turn(tid, message, incoming_fc,
                              result.get("reply", ""), result.get("result"))
                # ⭐ 640: «Запускай» на картці розуміння живе ВЕСЬ ЧАТ, а не один хід.
                threads.remember_turn_understanding(tid, result)
                result["thread_id"] = tid
                emit("final", result)
            except Exception as e:
                import traceback
                traceback.print_exc()
                # Аварія — теж хід розмови: питання людини й чесна відповідь
                # лягають у тред ТИМ САМИМ писарем, що й успішна відповідь.
                import failure
                _reply = failure.client_text(e, "server/chat_stream")
                _persist_turn(tid, message, incoming_fc, _reply)
                emit("final", {"reply": _reply, "thread_id": tid,
                               "decision": {"status": "error"}, "result": None, "pending": None})
            finally:
                runstate.clear(cancel_token)
            return

        if path == "/api/chat":
            data = self._read_json()
            message = (data.get("message") or "").strip()
            files = data.get("files") or []
            if not message and not data.get("pending") and not files:
                return self._send(400, {"error": "empty_message"})
            # Тред заводимо ДО спроби виконати (див. _persist_turn): хід мусить
            # мати куди лягти й тоді, коли рушій упав.
            tid, incoming_fc = "", ""
            try:
                tid = data.get("thread_id") or threads.create()["id"]
            except Exception:
                pass
            try:
                # Новий чат, створений у проєкті: спершу зробити його членом проєкту,
                # ЩОБ контекст проєкту дійшов до мозку вже в ПЕРШОМУ повідомленні.
                _pid = data.get("project_id")
                if _pid:
                    try:
                        projects.add_thread(_pid, tid)
                    except Exception:
                        pass
                incoming_fc, _meta = filetext.build_files_context(files) if files else ("", [])
                if not incoming_fc:
                    incoming_fc = data.get("files_context") or ""
                # Успадкувати документ із попередніх ходів, якщо зараз нічого не прикріплено.
                files_context = incoming_fc or threads.latest_files_context(tid)
                _url_ctx = tools.fetch_urls_in_text(message)
                if _url_ctx:
                    files_context = (files_context + "\n\n" + _url_ctx).strip()
                _und_cl = threads.understanding_of(tid)
                # ⛒ 581б. СЕРВЕР НЕ ЗНАЄ ІМЕН ПОЛІВ. Що в підтвердженні є
                # поправкою, а що керуванням, каже ОДИН писар — інакше кожен
                # новий рядок картки треба було б дописувати ще й сюди, і рядок
                # 581 (клас машини) саме тому мовчки з'їдався б.
                _fix = _und_srv.client_fields(data.get("confirm"))
                if _fix:
                    _und_cl = threads.set_understanding(tid, _fix) or _und_cl
                result = engine.handle_message(
                    self._actor(),
                    message=message or "(див. прикріплені файли)",
                    history=threads.history_for_brain(tid),
                    files_context=files_context,
                    pending=data.get("pending"),
                    confirm=data.get("confirm"),
                    understanding_client=_und_cl,
                    can_ask=True,
                    # ⛒ МОВА КОРИСТУВАЧА ЇДЕ В КОЖНОМУ ЗАПИТІ (зміна 255): доти
                    # сервер про неї не знав, і службові написи приходили не тією
                    # мовою, якою людина працює.
                    lang=data.get("lang"),
                    project_context=projects.context_for_thread(tid),
                    egress_allowed=bool(data.get("egress_allowed")),
                )
                # Збереження у архів чатів — ОДИН писар (див. _persist_turn)
                _persist_turn(tid, message, incoming_fc,
                              result.get("reply", ""), result.get("result"))
                # ⭐ 640: «Запускай» на картці розуміння живе ВЕСЬ ЧАТ, а не один хід.
                threads.remember_turn_understanding(tid, result)
                result["thread_id"] = tid
                return self._send(200, result)
            except Exception as e:  # ніколи не падаємо мовчки
                import traceback
                traceback.print_exc()
                import failure
                _reply = failure.client_text(e, "server/chat")
                _persist_turn(tid, message, incoming_fc, _reply)
                return self._send(500, {
                    "reply": _reply, "thread_id": tid,
                    "decision": {"status": "error"}, "result": None, "pending": None,
                })

        if path == "/api/automations/create":
            # ⛒ 624: створення регулярної роботи руками КЛІЄНТА. Fail-closed:
            # невідомий обхід сюди не пройде — суддя один, у `data_jobs`.
            import scheduler as _sch
            _d = self._read_json() or {}
            _job = str(_d.get("job") or "").strip()
            _name = str(_d.get("name") or "").strip()
            _cad = str(_d.get("cadence") or "щодня").strip() or "щодня"
            try:
                _rec = _sch.create_data_sync(_name or _job, _job, _cad)
            except Exception as _e:
                return self._send(400, {"error": "create_failed", "message": str(_e)})
            return self._send(200, {"ok": True, "automation": _rec})

        if path == "/api/automations/toggle":
            data = self._read_json()
            ok = scheduler.set_enabled(data.get("id"), bool(data.get("enabled")))
            return self._send(200, {"ok": ok})

        # ⭐ 28.07.2026: розклад можна не лише вмикати, а й НАЛАШТОВУВАТИ —
        # періодичність і час наступного запуску. Раніше був самий вимикач.
        if path == "/api/automations/schedule":
            data = self._read_json()
            res = scheduler.set_schedule(data.get("id"),
                                         cadence=data.get("cadence"),
                                         next_run_at=data.get("next_run_at"))
            return self._send(200 if res.get("ok") else 400, res)

        # ⭐ 30.07.2026 (Зміна B). Двері НІЧОГО не виконують і нічого не стирають:
        # вони лише переказують прохання дошці. «Запустити зараз» пересуває час і
        # віддає задачу тому самому єдиному виконавцеві; «видалити» переносить
        # теку в архів. Обидві відповідають словами людини, а не кодом помилки.
        if path == "/api/automations/run_now":
            data = self._read_json()
            res = scheduler.request_run_now(data.get("id"))
            return self._send(200 if res.get("ok") else 400, res)

        # ⛒⛒⛒ 626г (22.09.2026). НАДІСЛАТИ ЩЕ РАЗ. Двері нічого не шлють самі:
        # вони просять роботу забути позначку «надіслано» з останньої розсилки
        # і віддають задачу тому самому єдиному виконавцеві. Другого шляху
        # виконання не зʼявляється — це та сама Зміна B, що й «Запустити зараз».
        if path == "/api/automations/resend":
            import data_jobs as _dj626
            _d = self._read_json() or {}
            _rec = scheduler.get_automation(_d.get("id"))
            if not _rec:
                return self._send(400, {"ok": False,
                                        "message": "Задачу не знайдено."})
            if _rec.get("kind") != "data_sync" or not _rec.get("job"):
                return self._send(400, {"ok": False,
                                        "message": "Ця задача нічого не розсилає, "
                                                   "тому надіслати ще раз їй нічого."})
            _r = _dj626.resend(_rec["job"])
            if not _r.get("ok"):
                return self._send(400, {"ok": False,
                                        "message": _r.get("message") or
                                        "Надіслати ще раз не вийшло."})
            _go = scheduler.request_run_now(_rec["id"])
            return self._send(200, {
                "ok": True, "forgot": _r.get("forgot") or [],
                "message": "%s %s" % (_r.get("message") or "",
                                      _go.get("message") or "")})

        if path == "/api/automations/delete":
            data = self._read_json()
            res = scheduler.delete(data.get("id"))
            return self._send(200 if res.get("ok") else 400, res)

        if path == "/api/discover":
            result = discovery.sync(register=True)
            return self._send(200, result)

        if path == "/api/system/status":
            # Активація/деактивація системи однією кнопкою в UI (лише адмін — див.
            # _ADMIN_POST_PATHS). Активація також пише статус у папку системи
            # (management → registry.write_folder_state), щоб пережити оновлення.
            import management
            data = self._read_json()
            sid = (data.get("system_id") or "").strip()
            status = (data.get("status") or "").strip().lower()
            if status not in ("active", "inactive"):
                return self._send(400, {"ok": False, "message": "status має бути active або inactive."})
            action = "activate" if status == "active" else "deactivate"
            res = management.apply_action(self._actor(), action, sid)
            return self._send(200 if res.get("ok") else 400, res)

        if path == "/api/llm/config":
            data = self._read_json()
            st = config.set_llm(
                provider=(data.get("provider") or "").strip().lower() or None,
                brain=(data.get("brain") or "").strip() or None,
                worker=(data.get("worker") or "").strip() or None,
            )
            # Самомодель залежить від активної моделі — скинути кеш, щоб мозок знав про зміну.
            try:
                capabilities.invalidate()
            except Exception:
                pass
            # ⭐ 11.08.2026: перелiк для екрана дає ОДИН писар — той, що
            # питає провайдера. Зашитий рядок лишився тiльки запасним.
            st["suggestions"] = models_live.suggestions()
            st["model_ranks"] = models_live.ranks_for(st["suggestions"])
            return self._send(200, st)

        if path == "/api/llm/demo":
            data = self._read_json()
            on = bool(data.get("on"))
            ks = config.keys_status()
            if on:
                # ⭐⭐⭐ 10.08.2026, зміни 146 і 148. ДЕМО-РЕЖИМ — ЦЕ ПЕРШИЙ
                # ДОТИК НОВОГО КЛІЄНТА, а зашиті тут назви моделей робили його
                # першим враженням помилку 404 (Google зняв модель для нових
                # ключів). Тепер жодного імені: беремо ЖИВІ моделі провайдера
                # за РОЛЛЮ — дешевий виконавець і сильніший мозок.
                _prov = ""
                for _p in ("gemini", "openai", "anthropic"):
                    if ks.get(_p):
                        _prov = _p
                        break
                if _prov:
                    b = config.live_default_model(_prov, "brain")
                    w = config.live_default_model(_prov, "worker")
                else:
                    return self._send(200, {"error": "no_keys", "demo": False,
                                            "message": "Немає ключа жодного хмарного провайдера."})
                if config.ENV.get("DEMO_MODE") != "1":
                    prev = {"DEMO_PREV_BRAIN": config.brain_model(),
                            "DEMO_PREV_WORKER": config.worker_model()}
                    config.update_env_local(prev)
                    config.ENV.update(prev)
                st = config.set_llm(brain=b, worker=w)
                config.update_env_local({"DEMO_MODE": "1"}); config.ENV["DEMO_MODE"] = "1"
                st["demo"] = True
            else:
                pb = (config.ENV.get("DEMO_PREV_BRAIN") or "").strip()
                pw = (config.ENV.get("DEMO_PREV_WORKER") or "").strip()
                st = config.set_llm(brain=pb or None, worker=pw or None)
                config.update_env_local({"DEMO_MODE": "0"}); config.ENV["DEMO_MODE"] = "0"
                st["demo"] = False
            try:
                capabilities.invalidate()
            except Exception:
                pass
            # ⭐ 11.08.2026: перелiк для екрана дає ОДИН писар — той, що
            # питає провайдера. Зашитий рядок лишився тiльки запасним.
            st["suggestions"] = models_live.suggestions()
            st["model_ranks"] = models_live.ranks_for(st["suggestions"])
            return self._send(200, st)

        if path == "/api/setup":
            # Майстер налаштування: зберегти ключі (локально в .env.local) і перевірити звʼязок.
            data = self._read_json()
            st = config.set_keys({
                "openai": data.get("openai"),
                "anthropic": data.get("anthropic"),
                "gemini": data.get("gemini"),
            })
            ping_ok, ping_msg = (False, "немає ключа")
            if st.get("ready"):
                try:
                    ping_ok, ping_msg = llm.ping()
                except Exception as e:
                    ping_ok, ping_msg = False, str(e)
            st["ping"] = {"ok": ping_ok, "message": ping_msg}
            st["keys"] = config.keys_status()
            return self._send(200, st)

        if path == "/api/setup/local":
            # Локальна / on-prem модель: зберегти base_url+модель і зробити активною,
            # потім перевірити зв'язок із локальним сервером (Ollama/vLLM/LM Studio).
            data = self._read_json()
            st = config.set_local(
                base_url=(data.get("base_url") or "").strip() or None,
                model=(data.get("model") or "").strip() or None,
                worker=(data.get("worker") or "").strip() or None,
            )
            try:
                capabilities.invalidate()
            except Exception:
                pass
            ping_ok, ping_msg = (False, "не задано base_url/модель")
            if st.get("local") and config.LOCAL_MODEL:
                try:
                    ping_ok, ping_msg = llm.ping()
                except Exception as e:
                    ping_ok, ping_msg = False, str(e)
            st["ping"] = {"ok": ping_ok, "message": ping_msg}
            st["keys"] = config.keys_status()
            return self._send(200, st)

        if path == "/api/llm/stealth":
            # Режим Стелс: повна локальна ізоляція. on=true вмикає локальну модель
            # (за потреби з переданими base_url+model), on=false повертає хмару.
            data = self._read_json()
            st = config.set_stealth(
                bool(data.get("on")),
                base_url=(data.get("base_url") or "").strip() or None,
                model=(data.get("model") or "").strip() or None,
                worker=(data.get("worker") or "").strip() or None,
            )
            try:
                capabilities.invalidate()
            except Exception:
                pass
            ping_ok, ping_msg = (True, "")
            if st.get("stealth"):
                try:
                    ping_ok, ping_msg = llm.ping()
                except Exception as e:
                    ping_ok, ping_msg = False, str(e)
            st["ping"] = {"ok": ping_ok, "message": ping_msg}
            # ⭐ 11.08.2026: перелiк для екрана дає ОДИН писар — той, що
            # питає провайдера. Зашитий рядок лишився тiльки запасним.
            st["suggestions"] = models_live.suggestions()
            st["model_ranks"] = models_live.ranks_for(st["suggestions"])
            return self._send(200, st)

        if path == "/api/cancel":
            import runstate
            data = self._read_json()
            ok = runstate.request_cancel(data.get("cancel_token") or "")
            return self._send(200, {"ok": ok})

        if path == "/api/license":
            import license as licensing
            data = self._read_json()
            config.set_license(data.get("key") or "")
            st = licensing.status()
            st["entitlement"] = licensing.entitlement()
            return self._send(200, st)

        if path == "/api/license/generate":
            if not config.LICENSE_ADMIN:
                return self._send(403, {"error": "admin_disabled",
                                        "message": "Генерація вимкнена. Увімкніть LICENSE_ADMIN=1 у .env.local."})
            import license as licensing
            data = self._read_json()
            try:
                days = int(data.get("days") or 365)
            except Exception:
                days = 365
            key = licensing.generate((data.get("customer") or "").strip(),
                                     (data.get("edition") or "pilot").strip(), days)
            return self._send(200, {"key": key, "info": licensing.parse(key)})

        if path == "/api/telegram/token":
            import telegram_bot
            data = self._read_json()
            return self._send(200, telegram_bot.set_token(data.get("token") or ""))

        if path == "/api/telegram/tasks_token":
            import telegram_bot
            data = self._read_json()
            return self._send(200, telegram_bot.set_tasks_token(data.get("token") or ""))

        if path == "/api/telegram/support_mode":
            import config as _cfg
            data = self._read_json()
            return self._send(200, _cfg.set_support_mode(bool(data.get("on"))))

        if path == "/api/update/apply":
            import update as _upd
            data = self._read_json()
            ids = data.get("ids")
            return self._send(200, _upd.apply_updates(ids=ids or None))

        if path in ("/api/telegram/allow", "/api/telegram/revoke", "/api/telegram/dismiss"):
            import telegram_access
            data = self._read_json()
            cid = data.get("id")
            try:
                cid = int(cid)
            except Exception:
                return self._send(400, {"error": "bad_chat_id"})
            if path.endswith("/allow"):
                snap = telegram_access.allow(cid, (data.get("label") or "").strip())
            elif path.endswith("/revoke"):
                snap = telegram_access.revoke(cid)
            else:
                snap = telegram_access.dismiss_pending(cid)
            return self._send(200, snap)

        if path == "/api/threads/new":
            return self._send(200, threads.create())

        if path == "/api/threads/delete":
            data = self._read_json()
            return self._send(200, {"ok": threads.delete(data.get("id"))})

        if path == "/api/projects/new":
            data = self._read_json()
            return self._send(200, projects.create(data.get("name")))

        if path == "/api/projects/update":
            data = self._read_json()
            rec = projects.update(data.get("id"), name=data.get("name"),
                                  context=data.get("context"))
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/projects/delete":
            data = self._read_json()
            return self._send(200, {"ok": projects.delete(data.get("id"))})

        if path == "/api/projects/add-thread":
            data = self._read_json()
            rec = projects.add_thread(data.get("id"), data.get("thread_id"))
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/projects/remove-thread":
            data = self._read_json()
            rec = projects.remove_thread(data.get("id"), data.get("thread_id"))
            if not rec:
                return self._send(404, {"error": "project_not_found"})
            return self._send(200, rec)

        if path == "/api/support/log":
            import support
            data = self._read_json()
            e = support.log(data.get("hours"), data.get("note", ""))
            return self._send(200, {"ok": bool(e), "entry": e, "summary": support.summary()})

        if path == "/api/crm/inbound":
            # Зовнішній інбаунд-сигнал (ранкова автоперевірка пошти). Зіставляє
            # відправника з карткою й піднімає «увагу». ⛔ 12.08.2026: НОВОГО ЛІДА
            # БІЛЬШЕ НЕ СТВОРЮЄ САМ — невпізнане йде в чергу «Не оброблені», а в базу
            # його кладе людина кнопкою (/api/crm/promote).
            import inbound
            data = self._read_json()
            channel = (data.get("channel") or "email").strip()
            if channel == "telegram":
                res = inbound.from_telegram(data.get("chat_id"),
                                            username=data.get("username", ""),
                                            name=data.get("name", ""),
                                            text=data.get("preview", ""))
            else:
                email = (data.get("email") or "").strip()
                if not email:
                    return self._send(400, {"error": "no_email"})
                # ⭐ 618: «КОМУ» І «КОПІЯ» ІДУТЬ ДАЛІ. У корпоративній скриньці
                # саме адреса й каже, ЧИЙ це лист; доти вона гинула на порозі.
                res = inbound.from_email(email, name=data.get("name", ""),
                                         subject=data.get("subject", ""),
                                         preview=data.get("preview", ""),
                                         org=data.get("org", ""),
                                         to=data.get("to", ""),
                                         cc=data.get("cc", ""))
            import crm
            return self._send(200, {"ok": True, "result": res, "counts": crm.counts()})

        # ⭐⭐⭐ 533: ЗМІНА БАЗИ ТОВАРІВ — завести, виправити, прибрати з
        # обігу. Замок стоїть вище, у `_ADMIN_POST_PATHS`: тут ми його не
        # повторюємо, бо другий писар правила розійшовся б із першим.
        # ⭐⭐⭐ 536: ПОЗИЦІЇ УГОДИ. Замок стоїть вище, у `_ADMIN_POST_PATHS`.
        # ⛒ Відповідь ЗАВЖДИ везе свіжий перелік позицій цієї угоди: інакше
        # екран мусив би ходити за ним другим запитом і показав би застаріле.
        if path.startswith("/api/crm/deal_item_"):
            import deal_items as _di
            data = self._read_json()
            _iid = (data.get("id") or "").strip()
            _did = (data.get("deal") or "").strip()
            # ⭐ ХТО ДІЄ — питаємо в того самого місця, що й решта дверей.
            try:
                _by536 = (self._actor() or {}).get("login") or ""
            except Exception:
                _by536 = ""
            try:
                if path == "/api/crm/deal_item_add":
                    _row = _di.add(_did, (data.get("good") or "").strip(),
                                   qty=data.get("qty", ""),
                                   price=data.get("price", ""),
                                   by=_by536)
                    _did = _row["deal"]
                elif not _iid:
                    return self._send(400, {"error": "Не сказано, про яку позицію йдеться."})
                elif path == "/api/crm/deal_item_save":
                    _row = _di.get(_iid)
                    if "qty" in data:
                        _row = _di.set_qty(_iid, data.get("qty", ""))
                    if "price" in data:
                        _row = _di.set_price(_iid, data.get("price", ""))
                    _did = _row.get("deal") or _did
                elif path == "/api/crm/deal_item_remove":
                    _row = _di.get(_iid)
                    _did = _row.get("deal") or _did
                    _di.remove(_iid, by=_by536)
                else:
                    return self._send(404, {"error": "not_found", "path": path})
            except _di.DealItemError as ex:
                # ⛒ ВІДМОВА СЛОВАМИ, а не 500.
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "deal": _did,
                                    "items": _di.items_of(_did)})

        if path.startswith("/api/goods/"):
            import goods as _gd
            data = self._read_json()
            _gid = (data.get("id") or "").strip()
            try:
                if path == "/api/goods/new":
                    _row = _gd.create(data.get("name", ""),
                                      (data.get("kind") or _gd.KIND_GOODS).strip(),
                                      sku=data.get("sku", ""),
                                      unit=data.get("unit", ""),
                                      price=data.get("price", ""),
                                      currency=data.get("currency", ""),
                                      traits=data.get("traits") or {})
                    _gid = _row["id"]
                elif not _gid:
                    return self._send(400, {"error": "Не сказано, про який товар ідеться."})
                elif path == "/api/goods/save":
                    _base = {k: data[k] for k, _t in _gd.BASE_COLUMNS if k in data}
                    if _base:
                        _gd.set_fields(_gid, **_base)
                    if "traits" in data:
                        _gd.set_traits(_gid, data.get("traits") or {})
                elif path == "/api/goods/archive":
                    # ⛔ ТОВАР НЕ ВИДАЛЯЄТЬСЯ, а стає недіючим: на ньому висять
                    # угоди, і зникнення позиції зробило б їх нечитними.
                    _gd.set_archived(_gid, bool(data.get("on", True)))
                else:
                    return self._send(404, {"error": "not_found", "path": path})
            except _gd.GoodsError as ex:
                # ⛒ ВІДМОВА СЛОВАМИ, а не 500: людина мусить прочитати причину.
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "good": _gd.get(_gid) or {},
                                    "counts": _gd.count()})

        # ⭐⭐⭐ БУДОВА КАРТОК: ЗМІНА (зміна 454) — лише адміністратор.
        # Сам замок стоїть вище, у `_ADMIN_POST_PATHS`: тут ми його не
        # повторюємо, бо другий писар правила розійшовся б із першим.
        if path.startswith("/api/cards/field"):
            import card_fields as _cf
            data = self._read_json()
            # ⭐ 593: ці двері називають поле ключем `field` (а не `id`), бо
            # в тілі поруч стоїть ще й `parent` — два різні поля в одному
            # зверненні, і плутати їх під одним іменем не можна.
            fid = ((data.get("id") or data.get("field")) or "").strip()
            try:
                if path == "/api/cards/field_depends":
                    _cf.set_depends(fid, (data.get("parent") or "").strip(),
                                    data.get("choices_by") or {})
                elif path == "/api/cards/field_new":
                    row = _cf.create((data.get("card") or "").strip(),
                                     data.get("name", ""),
                                     (data.get("type") or _cf.T_TEXT).strip(),
                                     many=bool(data.get("many")),
                                     choices=data.get("choices") or [],
                                     hint=data.get("hint", ""),
                                     order=data.get("order") or 0)
                    fid = row["id"]
                elif not fid:
                    return self._send(400, {"error": "Не сказано, про яке поле йдеться."})
                elif path == "/api/cards/field_save":
                    if "name" in data:
                        _cf.set_name(fid, data.get("name", ""))
                    if "hint" in data:
                        _cf.set_hint(fid, data.get("hint", ""))
                    if "order" in data:
                        _cf.set_order(fid, data.get("order") or 0)
                elif path == "/api/cards/field_many":
                    _cf.set_many(fid, True)
                elif path == "/api/cards/field_choices":
                    _cf.set_choices(fid, data.get("choices") or [])
                elif path == "/api/cards/field_active":
                    _cf.set_active(fid, bool(data.get("on", True)))
                else:
                    return self._send(404, {"error": "not_found", "path": path})
            except _cf.FieldError as ex:
                # ⛒ ВІДМОВА СЛОВАМИ, а не 500: людина мусить прочитати причину.
                return self._send(400, {"error": str(ex)})
            row = _cf.get(fid) or {}
            return self._send(200, {"ok": True, "field": row,
                                    "fields": _cf.all_fields(row.get("card") or "")})

        # ⭐⭐⭐ 530: ПОКЛАСТИ ФАЙЛ У СХОВИЩЕ. Двері ЩОДЕННІ, не адмінські:
        # прикріпити специфікацію до угоди — та сама робота менеджера, що й
        # заповнити поле (право заповнювати = право правити, ухвалено в 527).
        # ⛒ Тіло запиту — САМІ БАЙТИ файла, людське імʼя — у заголовку
        # `X-File-Name`. Свого розбору багатоскладових форм не заводимо: це
        # окремий писар, який уміє помилятись, а користі від нього тут нуль.
        # ⭐⭐⭐ 532: РЕВІЗІЯ СХОВИЩА. Перерахувати від диска · відмітити, що
        # ревізію проведено · прибрати файл НАЗАВЖДИ. Усе троє адмінське
        # (`_ADMIN_POST_PATHS`): це рішення господаря машини про глибину
        # зберігання, а не щоденна робота менеджера.
        # 🩸 Прибрати можна й прикріплений файл — саме це й означає «скоротити
        # глибину зберігання». Картка після цього чесно скаже, що файла немає;
        # екран попереджає про це ДО натискання.
        if path in ("/api/files/recount", "/api/files/ack", "/api/files/remove"):
            import file_store as _fs532p
            _d532 = self._read_json()
            try:
                if path.endswith("recount"):
                    _res532 = _fs532p.recount()
                elif path.endswith("ack"):
                    _res532 = _fs532p.ack_threshold()
                else:
                    _res532 = _fs532p.remove((_d532.get("id") or "").strip())
            except _fs532p.FileStoreError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "result": _res532,
                                    "usage": _fs532p.usage()})

        if path == "/api/files/upload":
            import file_store as _fs530
            from urllib.parse import unquote as _unq530
            _name530 = _unq530(self.headers.get("X-File-Name") or "")
            try:
                _len530 = int(self.headers.get("Content-Length", "0") or "0")
            except Exception:
                _len530 = 0
            if _len530 <= 0:
                return self._send(400, {"error": "Порожній файл не зберігається."})
            if _len530 > _fs530.MAX_FILE_BYTES:
                # 🩸 НЕ ЧИТАЄМО СТО МЕГАБАЙТІВ, ЩОБ ЇХ ВИКИНУТИ. Тіло лишається
                # непрочитаним, тому зʼєднання закриваємо: інакше наступний
                # запит почав би з хвоста цього файла.
                self.close_connection = True
                return self._send(400, {"error":
                    "Файл «%s» більший за 100 МБ — це стеля на один файл. "
                    "Розділіть його або покладіть стисненим."
                    % (_name530 or "без імені")})
            _who530 = ""
            try:
                _who530 = (self._actor() or {}).get("login") or ""
            except Exception:
                _who530 = ""
            _rd530 = _BodyReader(self.rfile, _len530)
            try:
                _info530p = _fs530.put(_rd530, _name530, by=_who530)
            except _fs530.FileStoreError as ex:
                _rd530.drain()
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "file": _info530p,
                                    "usage": _fs530.usage()})

        # ⭐ ЗАПОВНЕННЯ ПОЛІВ — не адмінське: це щоденна робота менеджера.
        if path in ("/api/cards/value_set", "/api/cards/value_clear"):
            import card_values as _cv
            data = self._read_json()
            ref = (data.get("ref") or "").strip()
            fid = (data.get("field") or "").strip()
            try:
                if path.endswith("value_set"):
                    _cv.set_value(ref, fid, data.get("value"))
                else:
                    _cv.clear(ref, fid)
            except _cv.CardValueError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "ref": ref,
                                    "fields": _cv.card(ref)})

        # ⭐⭐⭐ 585: ПРИЧЕПИТИ / ВІДЧЕПИТИ ДОКУМЕНТ УГОДИ. Файл сюди не
        # їде: його кладе ОДИН завантажувач платформи (`/api/files/upload`), а
        # сюди приходить уже готовий `file_id`. Два шляхи для тих самих байтів
        # розійшлись би на першій же правці стелі розміру.
        # ⭐⭐⭐ 648: ПОШТОВІ СКРИНЬКИ — підключити (з перевіркою входу), прибрати,
        # перевірити зараз. Відмова — словами людині, пароль назад не їде ніколи.
        if path in ("/api/crm/mailbox_add", "/api/crm/mailbox_remove",
                    "/api/crm/mailbox_check"):
            import mail_intake as _mi648p
            data = self._read_json()
            try:
                _by648 = (self._actor() or {}).get("login") or ""
            except Exception:
                _by648 = ""
            _res648m = {}
            try:
                if path.endswith("mailbox_add"):
                    _res648m = _mi648p.add((data.get("address") or ""),
                                           (data.get("password") or ""),
                                           owner=(data.get("owner") or ""),
                                           host=(data.get("host") or ""), by=_by648)
                elif path.endswith("mailbox_remove"):
                    _mi648p.remove((data.get("id") or ""), by=_by648)
                else:
                    _res648m = _mi648p.check((data.get("id") or ""))
            except _mi648p.MailboxError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "result": _res648m,
                                    "boxes": _mi648p.boxes()})

        # ⭐⭐⭐ 648: ДОКУМЕНТИ КЛІЄНТА — покласти, прибрати, взяти в угоду. Файл сюди
        # не їде: його кладе ОДИН завантажувач (`/api/files/upload`), тут — `file_id`.
        if path in ("/api/crm/party_doc_add", "/api/crm/party_doc_remove",
                    "/api/crm/party_doc_take"):
            import deal_documents as _dd648p
            data = self._read_json()
            try:
                _who648 = (self._actor() or {}).get("login") or ""
            except Exception:
                _who648 = ""
            try:
                if path.endswith("party_doc_add"):
                    _pid648p = (data.get("party") or "").strip()
                    _res648 = _dd648p.add_for_party(
                        _pid648p, (data.get("kind") or "").strip(),
                        file_id=(data.get("file_id") or "").strip(),
                        number=(data.get("number") or "").strip(),
                        date=(data.get("date") or "").strip(), by=_who648)
                elif path.endswith("party_doc_take"):
                    _src648 = _dd648p.get((data.get("id") or "").strip())
                    _pid648p = str(_src648.get("party") or "")
                    _res648 = _dd648p.take_into_deal((data.get("id") or "").strip(),
                                                     (data.get("deal") or "").strip(),
                                                     by=_who648)
                else:
                    _src648 = _dd648p.get((data.get("id") or "").strip())
                    _pid648p = str(_src648.get("party") or "")
                    if str(_src648.get("deal") or ""):
                        return self._send(400, {"error": "Це документ угоди — прибирається в картці угоди."})
                    _res648 = _dd648p.remove((data.get("id") or "").strip(), by=_who648)
            except _dd648p.DealDocError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "result": _res648,
                                    "docs": _dd648p.documents_of_party(_pid648p)})

        if path in ("/api/crm/deal_doc_add", "/api/crm/deal_doc_remove",
                    "/api/crm/deal_doc_restate"):
            import deal_documents as _dd585p
            data = self._read_json()
            _who585 = ""
            try:
                _who585 = (self._actor() or {}).get("login") or ""
            except Exception:
                _who585 = ""
            try:
                if path.endswith("doc_restate"):
                    # ⭐⭐⭐ 625: НОВА РЕДАКЦІЯ ТОГО САМОГО ДОКУМЕНТА.
                    # ⛒ Порожню суму й порожню дату НЕ видаємо за «стерти»:
                    # чого екран не назвав, того писар не чіпає.
                    _doc625 = _dd585p.get((data.get("id") or "").strip())
                    _did585p = str(_doc625.get("deal") or "")
                    _amt625 = data.get("amount")
                    _dat625 = data.get("date")
                    _res585 = _dd585p.restate(
                        (data.get("id") or "").strip(),
                        file_id=(data.get("file_id") or "").strip(),
                        amount=(None if _amt625 in (None, "") else str(_amt625)),
                        date=(None if _dat625 in (None, "") else str(_dat625)),
                        by=_who585)
                elif path.endswith("doc_add"):
                    _res585 = _dd585p.add(
                        (data.get("deal") or "").strip(),
                        (data.get("kind") or "").strip(),
                        file_id=(data.get("file_id") or "").strip(),
                        number=(data.get("number") or "").strip(),
                        date=(data.get("date") or "").strip(),
                        amount=(data.get("amount") or "").strip(),
                        by=_who585)
                    _did585p = (data.get("deal") or "").strip()
                else:
                    _doc585 = _dd585p.get((data.get("id") or "").strip())
                    _did585p = str(_doc585.get("deal") or "")
                    _res585 = _dd585p.remove((data.get("id") or "").strip(),
                                             by=_who585)
            except Exception as ex:
                # ⛒ ВІДМОВА СЛОВАМИ І КОДОМ 400, а не 500: людина мусить
                # прочитати, чого бракує, а не «щось пішло не так».
                import doc_numbers as _dn585p
                if isinstance(ex, (_dd585p.DealDocError, _dn585p.NumberError)):
                    return self._send(400, {"error": "refused",
                                            "message": str(ex)})
                raise
            return self._send(200, {"ok": True, "result": _res585,
                                    "docs": _dd585p.documents_of(_did585p),
                                    "has_contract": _dd585p.has_contract(_did585p)})

        # ⭐⭐⭐ 613. МЕНЕДЖЕР ПРОСИТЬ КП ПРЯМО З КАРТКИ УГОДИ.
        # ⛒ Уся робота — в містку (`deal_kp`): двері лише передають слова.
        # Відмова приходить кодом 400 і ТЕКСТОМ, який людина прочитає: вирок
        # судді результату (612) мусить бути видний, а не з'їдений тишею.
        # ⭐⭐⭐ 616: МАГАЗИН — ПОРАХУВАТИ, СФОРМУВАТИ, ПЕРЕДАТИ ПОШТІ.
        # ⛒ Підсумок рахує сервер, а не екран: другий калькулятор грошей —
        # це дві правди про гроші, і розійдуться вони в документі клієнта.
        if path in ("/api/shop/quote", "/api/shop/order", "/api/shop/handed"):
            import shop as _shop616p
            data = self._read_json()
            _who616 = ""
            try:
                _who616 = (self._actor() or {}).get("login") or ""
            except Exception:
                _who616 = ""
            try:
                if path == "/api/shop/quote":
                    q = _shop616p.quote(data.get("picks") or [])
                    q["total_said"] = _shop616p.say_money(q["total"])
                    return self._send(200, q)
                if path == "/api/shop/order":
                    row = _shop616p.order(data.get("picks") or [],
                                          by=_who616, note=data.get("note") or "")
                    row["total_said"] = _shop616p.say_money(row["total"])
                    letter = None
                    try:
                        letter = _shop616p.letter(row["id"])
                    except _shop616p.ShopError:
                        letter = None          # кому надсилати — не названо
                    return self._send(200, {"ok": True, "order": row,
                                            "letter": letter})
                row = _shop616p.note_handed(data.get("order"), by=_who616)
                return self._send(200, {"ok": True, "state": row.get("state")})
            except _shop616p.ShopError as ex:
                return self._send(400, {"error": "refused", "message": str(ex)})

        # ⭐⭐⭐ 616: ВІЛЬНЕ ПИТАННЯ ДО КОНСУЛЬТАНТА ПЛАТФОРМИ.
        if path == "/api/manual/ask":
            import manual as _man616a
            data = self._read_json()
            try:
                return self._send(200, _man616a.ask(data.get("question") or ""))
            except _man616a.ManualScreenError as ex:
                return self._send(400, {"error": "refused", "message": str(ex)})

        if path == "/api/crm/deal_kp":
            import deal_kp as _dkp613
            import deal_documents as _dd613
            data = self._read_json()
            _did613 = (data.get("deal") or "").strip()
            _who613 = ""
            try:
                _who613 = (self._actor() or {}).get("login") or ""
            except Exception:
                _who613 = ""
            try:
                _res613 = _dkp613.prepare(_did613, by=_who613)
            except _dkp613.KpBridgeError as ex:
                return self._send(400, {"error": "refused", "message": str(ex)})
            return self._send(200, {"ok": True, "result": _res613,
                                    "docs": _dd613.documents_of(_did613),
                                    "has_contract": _dd613.has_contract(_did613)})

        if path == "/api/crm/promote":
            # ⭐ КНОПКА МЕНЕДЖЕРА: невпізнане вхідне → контрагент у базі «Клієнти».
            # Мінімум — сама ручка (пошта/телеграм) і назва; тип і ролі можна
            # уточнити пізніше на стадіях «Збір даних» і «Кваліфікація».
            import inbound as _inb
            import parties as _pt
            import crm as _crm
            import crm_access as _ca_promote
            data = self._read_json()
            roles = data.get("roles") or [_pt.ROLE_CLIENT]
            if isinstance(roles, str):
                roles = [roles]
            try:
                res = _inb.promote((data.get("channel") or "").strip(),
                                   (data.get("identity") or "").strip(),
                                   name=data.get("name", ""),
                                   kind=data.get("kind", _pt.KIND_UNKNOWN),
                                   roles=roles,
                                   # ⛒⛒⛒ 450: ЧИ ЗАВОДИТИ НАШУ ЛІЦЕНЗІЙНУ
                                   # КАРТКУ -- вирішує ЗАМОК, а не екран.
                                   # У клієнта картка не створюється НІКОЛИ,
                                   # що б у запиті не просили.
                                   create_card=(bool(data.get("create_card", True))
                                                and _ca_promote.kitchen_open(self._actor())),
                                   note=data.get("note", ""))
            except _pt.PartyError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "result": res,
                                    "inbox": _crm.inbox(), "counts": _pt.count()})

        if path == "/api/crm/party_manager":
            # ⭐⭐⭐ 590. ПЕРЕДАЧА КЛІЄНТА — ПЕРЕДАЧА АКТИВУ, А НЕ ЩОДЕННА
            # РОБОТА. Слово Андрія 16.09.2026: відповідального за контрагента
            # міняє керівник торгового підрозділу. Без цих воріт перший-ліпший
            # менеджер переписав би на себе базу відділу, і керівник дізнався б
            # про це з журналу. ⛒ Відповідального за УГОДУ це не стосується —
            # там своє правило, і воно нижче.
            # ⛒ 618: право судить ОДИН писар — до того самого акту
            # ведуть уже двоє дверей.
            if not self._may_transfer_party():
                return self._send(403, {
                    "error": "operator_forbidden",
                    "message": "Передати клієнта іншому менеджеру може "
                               "керівник підрозділу. Вашій ролі це право "
                               "не надано."})

            # ⭐ D1 (15.08.2026): призначити або зняти відповідального за клієнта.
            # ⛒ Сервер нічого не вирішує й нічого не вгадує: «чи можна» судить
            # писар довідника, а відмова їде СЛОВАМИ, а не кодом 500.
            import entity as _ent5
            import parties as _pt4
            data = self._read_json()
            pid = (data.get("id") or "").strip()
            try:
                card = _pt4.set_manager(pid, (data.get("employee") or "").strip(),
                                        by=_ent5.person_of_actor(self._actor()))
            except Exception as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "manager": card})

        if path == "/api/crm/deal_manager":
            # ⭐⭐⭐ 590. ХТО ВЕДЕ ЦЮ УГОДУ. Окремо від відповідального за
            # контрагента: один клієнт — кілька напрямів, і кожен веде свій
            # менеджер. ⛒ Права тут окремого немає свідомо: до цих дверей
            # доходить лише той, хто цю угоду БАЧИТЬ, а видимість уже судить
            # сторож вище. Передати свою угоду колезі — щоденна робота.
            import deals as _dl590
            import entity as _ent590
            data = self._read_json()
            try:
                res = _dl590.set_manager(
                    (data.get("id") or "").strip(),
                    (data.get("employee") or "").strip(),
                    by=_ent590.person_of_actor(self._actor()))
            except Exception as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "deal": res["deal"],
                                    "manager": res["manager"],
                                    "manager_name": _dl590.manager_name(res["deal"])})

        if path == "/api/crm/party":
            # Правка запису клієнтської бази: назва, тип, ролі, примітка, ручки.
            # ⭐ Номер контрагента не міняється НІКОЛИ — на ньому тримається історія.
            import parties as _pt
            data = self._read_json()
            pid = (data.get("id") or "").strip()
            try:
                if not _pt.exists(pid):
                    return self._send(404, {"error": "Контрагента %s немає в довіднику." % (pid or "«»")})
                if "name" in data:
                    _pt.set_name(pid, data.get("name", ""))
                if "kind" in data:
                    _pt.set_kind(pid, data.get("kind", ""))
                if "roles" in data:
                    _pt.set_roles(pid, data.get("roles") or [])
                if "note" in data:
                    _pt.set_note(pid, data.get("note", ""))
                if data.get("add_handle"):
                    h = data["add_handle"]
                    _pt.add_handle(pid, h.get("kind", ""), h.get("value", ""))
                if data.get("remove_handle"):
                    h = data["remove_handle"]
                    _pt.remove_handle(pid, h.get("kind", ""), h.get("value", ""))
            except _pt.PartyError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "party": _pt.get(pid)})

        if path == "/api/crm/pin":
            # ⭐⭐ ЗАКРІПЛЕННЯ ПОДІЇ (C3, 15.08.2026). Реєстр окремий, бо журнал
            # append-only переписувати не можна; ключ події рахує ОДИН писар
            # (`relations.event_key`), а сервер його лише передає.
            # ⛒ ВІДМОВА ПРО МЕЖУ ЇДЕ СЛОВАМИ (їх людина й побачить), а не кодом.
            import pins as _pins
            data = self._read_json()
            ref = (data.get("ref") or "").strip()
            key = (data.get("key") or "").strip()
            on = bool(data.get("on"))
            try:
                res = _pins.pin(ref, key) if on else _pins.unpin(ref, key)
            except Exception as ex:
                return self._send(400, {"error": str(ex)})
            res["ok"] = True
            return self._send(200, res)

        if path in ("/api/crm/bulk_preview", "/api/crm/bulk_apply"):
            # ⭐⭐⭐ D3 (16.08.2026): ЗРОБИТИ ЩОСЬ ІЗ ВІДІБРАНИМ, не перебираючи
            # по одному. ⛒ Сервер тут — лише двері: ані відбору, ані дії, ані
            # переліку він не рахує сам. Усе — в ОДНОГО писаря `party_bulk`,
            # інакше «вибрано 743» на екрані і «змінено 743» в базі були б
            # двома різними числами.
            import entity as _ent6
            import party_bulk as _pb
            import party_search as _ps2
            data = self._read_json()
            raw = dict(data.get("criteria") or {})
            try:
                # ⛒ Умови відбору ПЕРЕВІРЯЄ той самий писар, що й пошук: сміття
                # в стані чи невідомий працівник — відмова СЛОВАМИ ще до того,
                # як хоч одна картка змінилась.
                crit = _ps2.criteria(query=raw.get("query", ""),
                                     filter=raw.get("filter", ""),
                                     sort=raw.get("sort", ""),
                                     dir=raw.get("dir", ""),
                                     state=raw.get("state", ""),
                                     manager=raw.get("manager", ""))
                args = dict(action=data.get("action", ""),
                            scope=data.get("scope", ""),
                            ids=data.get("ids") or [],
                            crit=crit,
                            employee=(data.get("employee") or ""))
                if path.endswith("preview"):
                    res = _pb.preview(**args)
                else:
                    # 🩸🩸🩸 `by` — ЦЕ ПОСИЛАННЯ НА ЛЮДИНУ, А НЕ ПІДПИС СЛОВАМИ
                    # (спіймано ЖИВИМ прогоном 16.08.2026). Я поставив сюди
                    # текст «менеджер (консоль)» — реєстр звʼязків його прийняв,
                    # і картки p0016/p0017 перестали ВІДКРИВАТИСЬ узагалі.
                    # ⛒ Беремо ТОЙ САМИЙ писар, що й одинарні двері D1
                    # (`/api/crm/party_manager`): два способи назвати діяча —
                    # це два писарі однієї правди.
                    res = _pb.apply(by=_ent6.person_of_actor(self._actor()), **args)
            except (_pb.BulkError, _ps2.SearchError) as ex:
                return self._send(400, {"error": str(ex)})
            res["ok"] = True
            return self._send(200, res)

        if path == "/api/crm/party_new":
            # ⭐ ЗАВЕСТИ КОНТРАГЕНТА РУКАМИ (13.08.2026). Досі в базу вів РІВНО ОДИН
            # шлях — кнопка «У базу» з черги вхідних. Але клієнт народжується і на
            # зустрічі, і в телефонній розмові: контакт, який не має як потрапити в
            # базу, живе в чиїйсь голові, а не в активі компанії.
            import parties as _pt
            import entity as _ent589
            data = self._read_json()
            # ⭐⭐⭐ 589 → 648: «ХТО ЗАВІВ — ТОЙ І ВЕДЕ» ЖИВЕ В ОДНОМУ ПИСАРІ
            # (`parties.create_by_person`). Раніше правило стояло тут, у дверях, — і
            # бот працівника народжував би клієнта «нічиїм». Тепер обидва канали
            # ідуть одним писарем, і правило не можна забути в новому каналі.
            _act589 = {}
            try:
                _act589 = self._actor() or {}
            except Exception:
                _act589 = {}
            try:
                party = _pt.create_by_person(
                    name=(data.get("name") or "").strip(),
                    employee_id=str(_act589.get("employee_id") or ""),
                    by=_ent589.person_of_actor(_act589) if _act589 else "",
                    kind=(data.get("kind") or ""),
                    roles=data.get("roles") or [_pt.ROLE_CLIENT],
                    handles=data.get("handles") or {},
                    source="manual",
                    note=(data.get("note") or ""))
            except _pt.PartyError as ex:
                return self._send(400, {"error": str(ex)})
            return self._send(200, {"ok": True, "party": party})

        if path == "/api/crm/party_delete":
            # ⭐ ВИДАЛЕННЯ НЕ ВГАДУЄ ФОРМУ (рішення Андрія 10.08, підтверджене 13.08).
            # Спершу віддаємо ПЕРЕЛІК: що саме зникне і що ЗАЛИШИТЬСЯ. Видаляємо лише
            # другим викликом, із `confirm`. Картку угоди не чіпаємо НІКОЛИ: історія
            # взаємин і ліцензія — окрема цінність, і зносити її заразом ніхто не просив.
            import crm as _crm
            import parties as _pt
            data = self._read_json()
            pid = (data.get("id") or "").strip()
            if not _pt.exists(pid):
                return self._send(404, {"error": "Контрагента %s немає в довіднику." % (pid or "«»")})
            party = _pt.get(pid)
            card = _crm.card_of_party(pid)
            handles = []
            for hk, vals in (party.get("handles") or {}).items():
                for v in (vals or []):
                    handles.append("%s: %s" % (_pt.HANDLE_NAMES.get(hk, hk), v))
            plan = {
                "party": party,
                "goes": ["контрагент %s «%s»" % (pid, party.get("name") or "")] + handles,
                "stays": ([("картка угоди «%s» з усією історією, ліцензією та "
                            "нотатками — вона лишиться, але без звʼязку з довідником") % card]
                          if card else ["картки угоди в Сервіс-центрі немає"]),
                "protocol": ("Рядки протоколу з посиланням party:%s НЕ зникають: журнал "
                             "дописується в кінець і не переписується назад." % pid),
            }
            if not data.get("confirm"):
                return self._send(200, {"ok": False, "plan": plan})
            if card:
                try:
                    _crm.set_party(card, "")
                except Exception:
                    pass
            ok = _pt.delete(pid)
            return self._send(200, {"ok": bool(ok), "deleted": pid, "plan": plan})

        if path == "/api/crm/inbox_attach":
            # ⭐ ПРИВʼЯЗАТИ ДО НАЯВНОГО (борг із 12.08). У черзі стояв телеграм
            # «Boris Mamlin», а в базі вже був p0004 «Борис Мамлін»: єдина кнопка
            # «У базу» завела б ДУБЛЬ руками — тобто зіпсувала б саме той актив,
            # заради якого писався довідник.
            import crm as _crm
            import parties as _pt
            data = self._read_json()
            pid = (data.get("party_id") or "").strip()
            channel = (data.get("channel") or "").strip()
            identity = (data.get("identity") or "").strip()
            name = (data.get("name") or "").strip()
            if not _pt.exists(pid):
                return self._send(404, {"error": "Контрагента %s немає в довіднику." % (pid or "«»")})
            hk = _pt.H_EMAIL if channel == "email" else _pt.H_TG_ID
            try:
                _pt.add_handle(pid, hk, identity)
                if name and channel != "email":
                    user = name.split("(@")[-1].rstrip(")") if "(@" in name else ""
                    if user:
                        try:
                            _pt.add_handle(pid, _pt.H_TG_USER, user)
                        except _pt.PartyError:
                            pass
            except _pt.PartyError as ex:
                return self._send(400, {"error": str(ex)})
            _crm.clear_inbox(channel, identity)
            return self._send(200, {"ok": True, "party": _pt.get(pid),
                                    "inbox": _crm.inbox()})

        if path == "/api/crm/inbox_clear":
            import crm
            data = self._read_json()
            ok = crm.clear_inbox((data.get("channel") or "").strip(),
                                 (data.get("identity") or "").strip())
            return self._send(200, {"ok": bool(ok), "inbox": crm.inbox()})

        # ⭐⭐⭐ ДВЕРІ УГОДИ (крок C1, 15.08.2026). Кожна дія називає себе окремо:
        # одні двері «зміни щось в угоді» приймали б будь-що і мовчки губили
        # незнайоме поле — рівно те, на чому нас спіймав власний чек.
        # ⭐⭐⭐ КРОК C2 (15.08.2026) — ЛИСТУВАННЯ З АДРЕСОЮ УГОДИ.
        # ⚠ Стоїть ПЕРЕД загальним `deal_*`, інакше цей самий префікс проковтне
        # маршрут і віддасть «not_found» — тиха відмова на рівному місці.
        if path in ("/api/crm/deal_mail", "/api/crm/deal_mail_sent",
                    "/api/crm/spread_assign", "/api/crm/spread_drop",
                    "/api/crm/spread_owner"):
            import deal_mail as _dm
            data = self._read_json()
            try:
                if path.endswith("/deal_mail"):
                    # Заготовка листа. Нічого ще не сталось — сліду не пишемо.
                    return self._send(200, _dm.compose(
                        (data.get("id") or "").strip(),
                        subject=data.get("subject", ""),
                        to=data.get("to", "")))
                if path.endswith("/deal_mail_sent"):
                    # ⛒ «Сформовано», а не «надіслано»: шле поштова програма людини.
                    return self._send(200, _dm.note_sent(
                        (data.get("id") or "").strip(),
                        subject=data.get("subject", ""),
                        to=data.get("to", "")))
                if path.endswith("/spread_owner"):
                    # ⭐⭐⭐ 618: «ЧИЙ ЦЕ ЛИСТ» — один клік людини. Він не
                    # прилипає до рядка, а НАВЧАЄ зв’язок на майбутнє.
                    import entity as _ent618
                    import parties as _pt618
                    # ⛒ ТОЙ САМИЙ АКТ, ЩО Й У 590, — ОТЖЕ Й ПРАВИЛО ТЕ САМЕ.
                    # Єдиний виняток названо вголос: взяти НІЧИЙОГО
                    # контрагента СОБІ — це не передача активу, а звичайне
                    # «беру в роботу»; віддати комусь іншому або перезакріпити
                    # чужого — вже передача.
                    _item618 = (data.get("item") or "").strip()
                    _who618 = (data.get("owner") or "").strip()
                    _row618 = _dm.get_pending(_item618)
                    _pid618 = str((_row618 or {}).get("party") or "")
                    try:
                        _me618 = str((self._actor() or {}).get("employee_id") or "")
                    except Exception:
                        _me618 = ""
                    _had618 = _pt618.manager_of(_pid618) if _pid618 else ""
                    _take618 = (not _had618) and bool(_who618) and _who618 == _me618
                    if not _take618 and not self._may_transfer_party():
                        return self._send(403, {
                            "error": "operator_forbidden",
                            "message": "Узяти нічийого клієнта собі ви можете; "
                                       "віддати листа іншому менеджеру або "
                                       "перезакріпити чужого клієнта може "
                                       "керівник підрозділу."})
                    _dm.set_owner(_item618, _who618,
                                  by=_ent618.person_of_actor(self._actor()))
                    return self._send(200, {"ok": True, "spread": _dm.pending()})
                if path.endswith("/spread_assign"):
                    res = _dm.assign((data.get("item") or "").strip(),
                                     (data.get("deal") or "").strip())
                    import deals as _dl3
                    return self._send(200, {"ok": True, "deal": _dl3.card(res["deal"]),
                                            "spread": _dm.pending()})
                _dm.drop((data.get("item") or "").strip(), data.get("why", ""))
                return self._send(200, {"ok": True, "spread": _dm.pending()})
            except Exception as ex:
                # ⛒ ВІДМОВА СЛОВАМИ, а не 500.
                return self._send(400, {"error": str(ex)})

        if path.startswith("/api/crm/deal_"):
            import deals as _dl
            data = self._read_json()
            did = (data.get("id") or "").strip()
            try:
                if path.endswith("/deal_new"):
                    row = _dl.create((data.get("name") or "").strip(),
                                     (data.get("party") or "").strip(),
                                     stage=(data.get("stage") or _dl.DEFAULT_STAGE),
                                     amount=data.get("amount") or {},
                                     note=(data.get("note") or ""))
                    did = row["id"]
                    # ⭐⭐⭐ 590: ХТО ЗАВІВ УГОДУ — ТОЙ ЇЇ Й ВЕДЕ. Саме це
                    # дозволяє Хоменку працювати з клієнтом Петренка, не
                    # відбираючи в Петренка самого клієнта.
                    try:
                        import entity as _ent590d
                        _act590 = self._actor() or {}
                        _emp590d = str(_act590.get("employee_id") or "")
                        if _emp590d:
                            _dl.set_manager(did, _emp590d,
                                            by=_ent590d.person_of_actor(_act590))
                    except Exception:
                        pass
                elif not did:
                    return self._send(400, {"error": "Не сказано, про яку угоду йдеться."})
                elif path.endswith("/deal_name"):
                    _dl.set_name(did, data.get("name", ""))
                elif path.endswith("/deal_stage"):
                    _dl.set_stage(did, data.get("stage", ""))
                elif path.endswith("/deal_amount"):
                    _dl.set_amount(did, data.get("amount") or {})
                elif path.endswith("/deal_next_action"):
                    _dl.set_next_action(did, data.get("text", ""), data.get("date", ""))
                elif path.endswith("/deal_action_done"):
                    _dl.mark_action_done(did)
                elif path.endswith("/deal_attention"):
                    _dl.set_attention(did, value=data.get("value"),
                                      inc=int(data.get("inc") or 0))
                elif path.endswith("/deal_archive"):
                    _dl.set_archived(did, bool(data.get("on", True)))
                elif path.endswith("/deal_note"):
                    _dl.set_note(did, data.get("note", ""))
                elif path.endswith("/deal_client"):
                    _dl.set_client(did, (data.get("party") or "").strip())
                elif path.endswith("/deal_person_remove"):
                    _dl.remove_person(did, (data.get("party") or "").strip())
                elif path.endswith("/deal_person"):
                    _dl.add_person(did, (data.get("party") or "").strip(),
                                   note=(data.get("note") or ""))
                elif path.endswith("/deal_delete"):
                    # ⛒ Видалення НЕ ВГАДУЄ ФОРМУ: прибираємо рівно за номером.
                    if not _dl.delete(did):
                        return self._send(404, {"error": "Угоди %s немає в реєстрі." % did})
                    return self._send(200, {"ok": True, "deleted": did,
                                            "board": _dl.board()})
                else:
                    return self._send(404, {"error": "not_found", "path": path})
            except Exception as ex:
                # ⛒ ВІДМОВА СЛОВАМИ, а не 500: людина мусить прочитати причину.
                return self._send(400, {"error": str(ex)})
            # ⛒ 429: відповідь на ЗАПИС несе ту саму картку — отже й та сама
            # межа: кухонні поля не виходять із товарних дверей.
            return self._send(200, {"ok": True,
                                    "deal": _dl.card(did),
                                    "board": _dl.board()})

        if path in ("/api/crm/note", "/api/crm/history",
                    "/api/crm/profile", "/api/crm/contact", "/api/crm/contact_remove",
                    "/api/crm/comm", "/api/crm/dossier",
                    "/api/crm/systems", "/api/crm/modules"):
            import crm
            data = self._read_json()
            cust = (data.get("customer") or "").strip()
            if not cust:
                return self._send(400, {"error": "no_customer"})
            if path.endswith("/note"):
                crm.set_notes(cust, data.get("notes", ""))
            elif path.endswith("/profile"):
                # ⛒ 648: чужий телефон/пошта — відмова СЛОВАМИ людині, а не збій дверей.
                import parties as _pt648
                try:
                    crm.set_profile(cust, data.get("profile") or {})
                except _pt648.PartyError as _e648:
                    return self._send(400, {"error": str(_e648)})
                if "name_en" in data:
                    crm.ensure_client(cust, name_en=(data.get("name_en") or "").strip())
            elif path.endswith("/contact_remove"):
                crm.remove_contact(cust, data.get("index"))
            elif path.endswith("/contact"):
                crm.add_contact(cust, data.get("contact") or {})
            elif path.endswith("/comm"):
                ch = (data.get("channel") or "note").strip()
                crm.add_history(cust, ch, data.get("note", ""))
            elif path.endswith("/systems"):
                # ⭐⭐⭐ ЕТАП 4. Набір судить ОДИН суддя — той самий, що й збірка.
                # Помилку показуємо людині ТУТ, а не в мовчазній збірці потім.
                _raw = data.get("systems")
                if _raw is not None:
                    import product_scope as _mcb   # ⛒ 561в: суддя складу, а не складальник
                    try:
                        _mcb.client_systems(cust, card={"systems": _raw})
                    except _mcb.EntitlementError as _e:
                        return self._send(400, {"error": "bad_systems", "message": str(_e)})
                crm.set_systems(cust, _raw)
            elif path.endswith("/modules"):
                # ⭐⭐⭐ 631. Модулі судить ТОЙ САМИЙ суддя, що й доставка.
                _rawm = data.get("modules")
                if _rawm is not None:
                    import product_scope as _ps631
                    try:
                        _ps631.client_modules(cust, card={"modules": _rawm})
                    except _ps631.EntitlementError as _e:
                        return self._send(400, {"error": "bad_modules", "message": str(_e)})
                crm.set_modules(cust, _rawm)
            elif path.endswith("/dossier"):
                crm.set_dossier(cust, data.get("text", ""))
            else:
                crm.add_history(cust, (data.get("type") or "note"), data.get("note", ""))
            return self._send(200, {"ok": True, "card": crm.card_public(cust),
                                    "counts": crm.counts()})

        return self._send(404, {"error": "not_found", "path": path})

    # ---- статика ----------------------------------------------------------
    def _localized_html(self, page):
        """Читає HTML-сторінку UI й підставляє дефолтну мову зі збірки.
        Вибір користувача в localStorage має пріоритет (логіка в ui/i18n.js).
        Спільний шлях для index/setup/telegram → один шов на всі сторінки."""
        lang = (getattr(config, "UI_DEFAULT_LANG", "uk") or "uk").lower()
        if lang not in ("uk", "ru", "en"):
            lang = "uk"
        html = page.read_text(encoding="utf-8").replace("__UI_DEFAULT_LANG__", lang)
        return html.encode("utf-8")

    def _serve_ui(self):
        index = config.UI_DIR / "index.html"
        if not index.exists():
            return self._send(500, {"error": "ui_missing"})
        return self._send(200, self._localized_html(index),
                          content_type="text/html; charset=utf-8")

    def _serve_home(self):
        """ДОМАШНЯ СТОРІНКА ПЛАТФОРМИ (зміна 470).

        Іде ТИМ САМИМ швом, що й консоль, — `_localized_html`: мова збірки
        підставляється в одному місці на всі сторінки, а не окремо на кожній.
        """
        page = config.UI_DIR / "home.html"
        if not page.exists():
            return self._send(500, {"error": "home_ui_missing"})
        return self._send(200, self._localized_html(page),
                          content_type="text/html; charset=utf-8")

    def _serve_artifact(self, path):
        parts = path.split("/")
        # /artifacts/<run_id>/<filename>
        if len(parts) < 4:
            return self._send(404, {"error": "bad_artifact_path"})
        run_id, filename = parts[2], "/".join(parts[3:])
        fpath = store.artifact_path(run_id, filename)
        if not fpath.exists():
            return self._send(404, {"error": "artifact_not_found"})
        data = fpath.read_bytes()
        ctypes = {
            ".md": "text/markdown; charset=utf-8",
            ".html": "text/html; charset=utf-8",
            ".json": "application/json; charset=utf-8",
            ".csv": "text/csv; charset=utf-8",
            ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        }
        ext = "." + filename.rsplit(".", 1)[-1] if "." in filename else ""
        return self._send(200, data, content_type=ctypes.get(ext, "application/octet-stream"))


def _scheduler_loop():
    # Фоновий потік: перевіряє автоматизації, що настали.
    while True:
        try:
            executed = scheduler.run_due(engine.automation_runner)
            for e in executed:
                print(f"[auto] виконано: {e['name']} -> {e['entry'].get('status')}")
        except Exception as ex:
            sys.stderr.write(f"[auto] помилка планувальника: {ex}\n")
        time.sleep(60)


def main():
    # ⭐ 29.07.2026. Консоль продукту існувала ЛИШЕ на екрані: коли в клієнта
    # щось падало, від збою не лишалось нічого, крім слів. Тепер той самий
    # вивід іде і у файл logs\\server_*.log — його бере звіт підтримки
    # (support_report). Один прийом, що вже працює в наших пробах.
    try:
        import run_log
        run_log.start("server")
        run_log.prune("server", 20)
    except Exception as ex:
        sys.stderr.write("[log] журнал сервера не увімкнувся: %s\n" % ex)
    # ⭐⭐⭐ 519: ПОРТ БЕРЕМО ПЕРШИМ — ДО ВСЬОГО, ЩО ДІЄ НАЗОВНІ.
    # Доти сокет піднімався в самому кінці: друга копія встигала запустити
    # ботів, планувальник, сторожа строків і розвідку систем — і лише потім
    # дізнавалась, що вона зайва. Порт — єдина відповідь на питання «чи я
    # тут один», тому питаємо його ПЕРШИМ і мовчки виходимо, якщо ні.
    _url = "http://127.0.0.1:%d" % config.PORT
    try:
        import network_access as _net_bind
        httpd = _SoleServer((_net_bind.effective_host(), config.PORT), Handler)
    except OSError as ex:
        import errno
        if (ex.errno in (errno.EADDRINUSE, 48, 98, 10048)
                or getattr(ex, "winerror", 0) in (10048, 10013)):
            print("=" * 64)
            print(" SensFlow уже працює на %s." % _url)
            print(" Друга копія не потрібна — це вікно можна закрити.")
            print("=" * 64)
            # ⛒ Під службою вікна немає і відкривати браузер нікому:
            # питаємо той самий вимикач, що й нижче.
            if (config.ENV.get("AUTO_OPEN_BROWSER", "1") or "1") != "0":
                try:
                    webbrowser.open(_url)
                except Exception:
                    pass
            return
        raise
    # ⭐⭐⭐ 537, 08.09.2026. ШИФРУВАННЯ БЕРЕТЬСЯ ОДИН РАЗ — ТУТ.
    # Не в кожному з'єднанні: інакше «чи ми зашифровані» стало б питанням, на
    # яке відповідають тисячу разів і щоразу трохи інакше. Немає придатного
    # сертифіката — контекст порожній, і платформа працює як працювала; у
    # мережу вона при цьому не вийде, бо цього не дасть замок (network_access).
    try:
        import https_access as _sec
        httpd._tls = _sec.context()
    except Exception as _ex:
        httpd._tls = None
        sys.stderr.write("[https] шифрування не піднялось: %s\n" % _ex)
    # ⭐⭐⭐ 537ж, 08.09.2026. ДРУГИЙ ПОВЕРХ: СЕРВЕР ПЕРЕВІРЯЄ САМ.
    # Замок мережі вже питав про шифрування — але сервер вірив йому на слово.
    # 🩸 Живий крок показав, чого це варте: сертифікат може бути бездоганним на
    # вигляд і непридатним насправді. Якщо адреса відкрита, а шифрування не
    # піднялось — платформа стає на 127.0.0.1 і каже чому. Відкритий порт без
    # шифрування — це рівно та біда, від якої ставився замок.
    if httpd._tls is None:
        try:
            import network_access as _net_guard
            if httpd.server_address[0] == _net_guard.OPEN_HOST:
                httpd.server_close()
                httpd = _SoleServer((_net_guard.LOCAL_HOST, config.PORT), Handler)
                httpd._tls = None
                print("=" * 64)
                print(" УВАГА: мережу було відкрито, але шифрування не піднялось.")
                print(" Платформа стала на 127.0.0.1 — відкритий порт без")
                print(" шифрування ми не піднімаємо НІКОЛИ.")
                print(" Створіть сертифікат заново на екрані Доступи.")
                print("=" * 64)
        except Exception as _ex2:
            sys.stderr.write("[https] другий поверх не спрацював: %s\n" % _ex2)
    # ⭐ 30.07.2026. Клієнт міг відредагувати .env.local руками або отримати
    # збірку із запіненою моделлю чужого провайдера — тоді продукт казав
    # «немає API-ключа», хоча ключі є. Канал «правка файлу» повз set_keys не
    # проходить, тому звіряємо досяжність ролей ще й на старті — і НАЗИВАЄМО
    # зміну в журналі, а не підмінюємо вибір клієнта мовчки.
    try:
        _rt = config.ensure_reachable_models()
        if _rt.get("changed"):
            for _role in ("brain", "worker"):
                _r = _rt.get(_role)
                if _r:
                    print("[llm] %s: модель %s недосяжна (немає ключа) -> %s (%s)"
                          % (_role, _r["was"], _r["now"], _r["provider"]))
    except Exception as _ex:
        sys.stderr.write("[llm] звірка досяжності моделей не виконалась: %s\n" % _ex)
    brain = config.provider_status()
    print("=" * 64)
    print(" AI Orchestrator Platform — Python engine")
    print("=" * 64)
    print(f" Робочий простір : {config.WORKSPACE_ROOT}")
    print(f" Реєстр систем   : {config.REGISTRY_JSON}")
    print(f" Провайдер       : {brain['provider']} [{'готовий' if brain['ready'] else 'НЕМАЄ КЛЮЧА'}]")
    print(f" Мозок (думання) : {brain.get('brain_model')}")
    print(f" Виконавець      : {brain.get('worker_model')}")
    if brain["ready"]:
        ok, msg = llm.ping()
        print(f" Перевірка мозку : {'✓ OK' if ok else '✗ ПОМИЛКА'} — {msg}")
    if not brain["ready"]:
        print("  УВАГА: додайте OPENAI_API_KEY або ANTHROPIC_API_KEY у orchestrator_py/.env.local")
    print(f" Консоль         : http://127.0.0.1:{config.PORT}")
    # 506: людина не має гадати, кому платформа відкрита. Один модуль
    # відповідає і серверу, і екрану, і цьому рядку.
    import network_access as _net_say
    for _ln in _net_say.console_lines():
        print(_ln)
    # 537: і про шифрування — тими самими словами, що й на екрані.
    try:
        import https_access as _sec_say
        for _ln in _sec_say.console_lines():
            print(_ln)
    except Exception:
        pass
    try:
        import keepawake
        if keepawake.start():
            print(" Енергозбереження : сон ПК вимкнено, поки працює застосунок")
    except Exception:
        pass
    caps = artifacts.capabilities()
    fmts = "md, html" + (", docx" if caps["docx"] else "") + (", xlsx" if caps["xlsx"] else "") + (", pptx" if caps.get("pptx") else "")
    missing = ([] + (["python-docx"] if not caps["docx"] else []) + (["openpyxl"] if not caps["xlsx"] else []) + (["python-pptx"] if not caps.get("pptx") else []))
    print(f" Артефакти       : {fmts}"
          + (f"   [для повного набору: pip install {' '.join(missing)}]" if missing else "   (повний набір доступний)"))
    print(f" Планувальник    : активний (фонова перевірка щохвилини)")
    # Виявлення ресурсів: знайти нові системи у проєктах і додати в оркестр
    try:
        disc = discovery.sync(register=True)
        if disc.get("added"):
            print(f" Виявлено нових систем: {len(disc['added'])} -> {', '.join(disc['added'])}")
        if disc.get("missing"):
            print(f" Позначено зниклими: {', '.join(disc['missing'])}")
        if disc.get("healed"):
            print(f" Відновлено статус із папки: {', '.join(disc['healed'])}")
        print(f" Систем в оркестрі: {len(registry.load_systems())}")
    except Exception as ex:
        sys.stderr.write(f"[discovery] помилка: {ex}\n")
    print("=" * 64)

    url = f"http://127.0.0.1:{config.PORT}"
    threading.Thread(target=_scheduler_loop, daemon=True).start()
    # ⭐ СТОРОЖ СТРОКІВ (зміна 172): протермінування стає ФАКТОМ у протоколі, а не
    # лише картинкою на екрані. ОКРЕМИЙ потік навмисно: довгий прогін автоматизації
    # не сміє відкладати факт, а поломка сторожа — зупиняти автоматизації.
    try:
        import taskdesk_overdue as _overdue
        threading.Thread(target=_overdue.loop, daemon=True).start()
        print(" Сторож строків  : активний (перевірка щохвилини)"
              if _overdue.on() else
              " Сторож строків  : мовчить (Task Desk вимкнений)")
    except Exception as ex:
        sys.stderr.write("[строки] сторож не запустився: %s\n" % ex)
    # ⭐ ЗВЕДЕННЯ (зміна 241): один лист замість пʼятнадцяти тим, від кого дії
    # не чекають. ОКРЕМИЙ потік: поломка зведення не сміє зупинити ні
    # автоматизації, ні сторожа строків.
    try:
        import taskdesk_digest as _digest
        threading.Thread(target=_digest.loop, daemon=True).start()
        print(" Зведення        : щодня о %02d:00 тим, хто лише спостерігає"
              % _digest.HOUR)
    except Exception as ex:
        sys.stderr.write("[зведення] не запустилось: %s\n" % ex)
    # Telegram-вхід (опційно): активується, якщо в .env.local є TELEGRAM_BOT_TOKEN
    try:
        import telegram_bot
        if telegram_bot.start_in_background():
            print(" Telegram-бот     : активний (long-polling)")
            print(f" Доступ до бота    : керування на http://127.0.0.1:{config.PORT}/telegram")
        else:
            print(" Telegram-бот     : вимкнено (немає TELEGRAM_BOT_TOKEN у .env.local)")
    except Exception as ex:
        sys.stderr.write(f"[telegram] не вдалося запустити: {ex}\n")
    # ⭐⭐⭐ 648: ПОШТА В CRM. Окремий потік: лежачий поштовий сервер клієнта не
    # сміє зупинити ні автоматизації, ні телеграм. Немає скриньок — потік мовчить.
    try:
        import mail_intake as _mail648
        _mail648.start_in_background()
        print(" Пошта в CRM      : скриньки перевіряються кожні %d хв"
              % _mail648.TICK_MIN)
    except Exception as ex:
        sys.stderr.write("[пошта] приймальник не запустився: %s\n" % ex)
    # РОТ TASK DESK: доставка подій нерва в телеграм. Окремий потік, окремий
    # курсор. Немає бота задач — рота просто немає, і це нормальний стан
    # (закритий контур): нерв від цього не страждає.
    try:
        import taskdesk_telegram as _mouth
        if _mouth.start_in_background():
            print(" Задачі в телеграм : доставка активна")
        else:
            print(" Задачі в телеграм : вимкнено (немає TELEGRAM_TASKS_BOT_TOKEN)")
    except Exception as ex:
        sys.stderr.write(f"[рот] не вдалося запустити доставку: {ex}\n")
    # ⛒ 519: сокет уже піднято НА ПОЧАТКУ main() — саме там вирішується,
    # чи ми тут одні. Нижче лишається тільки почати обслуговування.
    try:
        # Автоматично відкрити консоль у браузері (можна вимкнути: AUTO_OPEN_BROWSER=0)
        if (config.ENV.get("AUTO_OPEN_BROWSER", "1") or "1") != "0":
            threading.Timer(1.2, lambda: webbrowser.open(url)).start()
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nЗупинено.")
        httpd.server_close()


if __name__ == "__main__":
    main()
