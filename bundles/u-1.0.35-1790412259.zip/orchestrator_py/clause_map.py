# -*- coding: utf-8 -*-
"""clause_map.py — НОМЕР ПУНКТУ ЗАМОВНИКА БЕРЕТЬСЯ ЛИШЕ З ДОКУМЕНТА ЗАМОВНИКА (зміна 642).

🩸 Живий прогін 640 (25.09.2026). На «чому статут сканом?» мозок відповів: «це
прямо вимагає замовник: п.15.2 і 15.3 „Форми 1“». У Формі 1 пунктів 15.x немає —
правило стоїть в ОГОЛОШЕННІ, розділ 15, підпункти 2–3. Зміст відповіді правильний,
а номер вигаданий. Тендерист, який шукатиме «п.15.2 Форми 1», не знайде нічого, і
людина перестане вірити всім номерам, які їй показує платформа.

КОРІНЬ. Нумерацію пунктів замовника не знав ніхто. Мозок бачив паспорт і шматок
пакета без номерів — тож номери він складав сам.

⛒ ЗАКОН 642. Нумерацію документів замовника читає ОДИН писар — цей модуль:
  • `index(material)` — карта: документ замовника (оголошення, Форма N, Додаток N,
    договір) → номер пункту → перше речення пункту. Номер читається з тексту
    дослівно; підпункти, що починають лік наново («15. Вимоги…» → «1.», «2.»),
    стають «15.1», «15.2» саме цього документа.
  • `section(material)` — та сама карта у пакеті: людина бачить, звідки номер,
    а мозок відповідає з неї.
  • `mend(reply, index)` — ДВЕРІ відповіді. Кожне посилання «п. N» на документ
    замовника мусить бути в карті. Помилкова назва документа виправляється на ту,
    де цей номер справді є; номер, якого немає ніде, знімається або замінюється
    номером пункту, текст якого відповідь переказує. Посилання на закони
    («п. 1 ч. 13 ст. 14 Закону») — не наша карта, їх двері не чіпають.
"""

import re

HEAD = "КАРТА ПУНКТІВ ЗАМОВНИКА"
BRAIN_RULE = ("Номер пункту документа замовника називай ЛИШЕ з цієї карти — разом із назвою документа, "
              "де він стоїть («п. 1.3 Форми 1», «п. 15.2 оголошення»). Пункту немає в карті — назви "
              "документ і процитуй його слова, без номера.")
_LINE_CUT = 90

_DOC_RE = re.compile(r"^\s*===\s*ДОКУМЕНТ:\s*(.+?)\s*(?:\(\d+\s*символ\w*\))?\s*===\s*$", re.I)
_BOUND_RE = re.compile(r"^\s*(форма|додаток)\s*№?\s*(\d{1,2})\s*(до\s+[^.;|–—]{0,160})?[.:]?\s*$", re.I)
_DOT_RE = re.compile(r"^\s*(\d{1,2}(?:\.\d{1,2}){0,3})\.?\s*[.)]?\s+(?=\S)(.*)$")
_PAREN_RE = re.compile(r"^\s*(\d{1,2})\)\s+(.*)$")
_GAP = 3


def _fold(t) -> str:
    return re.sub(r"\s+", " ", str(t or "")).strip()


def _num(s) -> tuple:
    return tuple(int(x) for x in str(s).split(".") if x != "")


def _dotted(t) -> str:
    return ".".join(str(x) for x in t)


# ── документ замовника ──────────────────────────────────────────────────────

def _keys_of_name(name: str) -> tuple:
    """Ключі документа за його назвою: ('main',) / ('форма', N) / ('додаток', N) / ('договір',)."""
    low = str(name or "").lower().replace("_", " ")
    keys = []
    m = re.search(r"(додат\w*|dod)\s*№?\s*(\d{1,2})", low)
    if m:
        keys.append(("додаток", int(m.group(2))))
    m = re.search(r"форм\w*\s*№?\s*(\d{1,2})", low)
    if m:
        keys.append(("форма", int(m.group(1))))
    if re.search(r"договір|договор|dogovir|contract", low):
        keys.append(("договір",))
    if re.search(r"документац", low) and not keys:
        keys.append(("main", "td"))
    elif re.search(r"оголошен|ogoloshen", low) and not keys:
        keys.append(("main",))
    return tuple(keys)


def _label_of(keys, name="") -> str:
    for k in keys:
        if k == ("main", "td"):
            return "Тендерна документація"
        if k[0] == "main":
            return "Оголошення"
        if k[0] == "форма":
            return "Форма %d" % k[1]
        if k[0] == "додаток":
            return "Додаток № %d" % k[1]
    for k in keys:
        if k[0] == "договір":
            return "Проєкт договору"
    return _fold(name)[:60] or "Документ замовника"


def _genitive(label: str) -> str:
    """Назва документа в родовому відмінку — для «п. 1.3 Форми 1»."""
    low = label.lower()
    if low == "оголошення":
        return "оголошення"
    if low == "тендерна документація":
        return "тендерної документації"
    m = re.match(r"форма\s+(\d+)", low)
    if m:
        return "Форми %s" % m.group(1)
    m = re.match(r"додаток\s*№?\s*(\d+)", low)
    if m:
        return "Додатка № %s" % m.group(1)
    if low.startswith("проєкт договору"):
        return "проєкту договору"
    return "«%s»" % label


# ── карта ───────────────────────────────────────────────────────────────────

def _continues(t, last) -> bool:
    """t продовжує лік, на якому стоїть last: наступний пункт будь-якого рівня (1.4 → 2.1,
    коли заголовок «2.» замовника загубився при читанні docx) або перший підпункт."""
    if not last:
        return False
    if len(t) > len(last) and t[:len(last)] == last:
        return len(t) - len(last) <= 2 and all(x in (1, 2) for x in t[len(last):])
    for i in range(min(len(t), len(last))):
        if t[i] != last[i]:
            return 0 < t[i] - last[i] <= _GAP and all(x == 1 for x in t[i + 1:])
    return False


def _title_case(text) -> bool:
    """Заголовок розділу великими літерами: «1. ПРЕДМЕТ ДОГОВОРУ»."""
    letters = [c for c in str(text or "") if c.isalpha()]
    return 4 <= len(letters) <= 80 and sum(c.isupper() for c in letters) >= 0.7 * len(letters)


def index(material: str) -> list:
    """[{doc, label, keys, path, cite, text}] — усі нумеровані пункти документів замовника."""
    out = []
    lines = str(material or "").splitlines()
    doc_keys, doc_label, doc_name = ("main",), "Оголошення", ""
    cont = {"keys": doc_keys, "label": doc_label}
    frames, paren = [], {"base": None, "last": 0}
    st = {"loose": False}

    def _reset(keys, label):
        cont["keys"], cont["label"] = keys, label
        del frames[:]
        paren["base"], paren["last"] = None, 0
        st["loose"] = False

    def _emit(path, text, paren_leaf=False):
        text = _fold(text)
        if not text:
            return
        if not paren_leaf:
            cite = "п. %s" % _dotted(path)
        elif len(path) > 1:
            cite = "п. %s, пп. %d)" % (_dotted(path[:-1]), path[-1])
        else:
            cite = "пп. %d)" % path[-1]
        out.append({"doc": doc_name, "label": cont["label"], "keys": cont["keys"],
                    "path": tuple(path), "paren": paren_leaf, "cite": cite, "text": text})

    def _dot(t, text):
        """Пункт із номером. Продовжує лік відкритого переліку — стає в нього (найглибший
        перелік має першість). Новий лік «1.» під пунктом документа («15. Вимоги до
        Учасника:» → «1.», «2.») — підпункти цього пункту: 15.1, 15.2 … Лік, що почався
        наново вже всередині підпунктів (таблиці форм, бланки без межі), — не пункт
        документа: назвати його номер не можна, тож у карту він не йде, доки лік
        документа не продовжиться."""
        for i in range(len(frames) - 1, -1, -1):
            f = frames[i]
            if _continues(t, f["last"]):
                del frames[i + 1:]
                f["last"], f["text"] = t, text
                st["loose"] = False
                _emit(f["prefix"] + t, text)
                paren["base"], paren["last"] = f["prefix"] + t, 0
                return
        if st["loose"]:
            if not (t == (1,) and _title_case(text)):
                return
            del frames[:]                 # «1. ПРЕДМЕТ ДОГОВОРУ» — документ почав лік наново
            st["loose"] = False
        if frames and len(t) == 1 and t[-1] == 1:
            top = frames[-1]
            if not top["prefix"]:
                base = top["prefix"] + top["last"]
                frames.append({"prefix": base, "last": t, "text": text})
                _emit(base + t, text)
                paren["base"], paren["last"] = base + t, 0
                return
            st["loose"] = True
            paren["base"] = None
            return
        if frames:
            st["loose"] = True
            paren["base"] = None
            return
        frames.append({"prefix": (), "last": t, "text": text})
        _emit(t, text)
        paren["base"], paren["last"] = t, 0

    for i_ln, raw in enumerate(lines):
        ln = raw.strip()
        if not ln:
            continue
        m = _DOC_RE.match(ln)
        if m:
            doc_name = m.group(1)
            keys = _keys_of_name(doc_name)
            if doc_name.lower().startswith("audit_"):
                keys = (("service",),)
            if ("main", "td") in keys:
                keys = tuple(keys) + (("main",),)
            _reset(keys or (("doc", doc_name),), _label_of(keys, doc_name))
            continue
        if cont["keys"] and cont["keys"][0] == ("service",):
            continue
        _solo = [c.strip() for c in ln.strip("|").split("|") if c.strip()] if "|" in ln else [ln]
        if len(_solo) == 1:
            b = _BOUND_RE.match(_solo[0])
            if b and annex_of_contract(lines, i_ln, b.group(3)):
                # ⭐ 643: «Додаток № 1 / до Договору» — додаток ДОГОВОРУ, а не документа
                # закупівлі: документ лишається тим самим (договором), лік — наново.
                keys = tuple(cont["keys"])
                if ("договір",) not in keys:
                    keys += (("договір",),)
                _reset(keys, cont["label"])
                continue
            if b:
                kind = "форма" if b.group(1).lower().startswith("форм") else "додаток"
                k = (kind, int(b.group(2)))
                keys = (k,)
                if not any(e["doc"] == doc_name for e in out):
                    # межа — перший рядок файла («Додаток №3 до документації» у файлі
                    # «Договір…»): документ має обидва імені
                    keys += tuple(x for x in _keys_of_name(doc_name) if x[0] not in ("main", k[0]))
                _reset(keys, _label_of((k,)))
                continue
            if cont["label"].startswith("Додаток") and re.match(r"^(проєкт\s+)?договір\b", _solo[0].lower()):
                if ("договір",) not in cont["keys"]:
                    cont["keys"] = tuple(cont["keys"]) + (("договір",),)
        cells = [c.strip() for c in ln.strip("|").split("|")] if "|" in ln else [ln]
        cells = [c for c in cells if c] or [""]
        if len(cells) >= 3:
            continue                      # рядок таблиці даних (товар | од. | к-сть), не пункт
        first = cells[0]
        if len(cells) > 1 and re.fullmatch(r"\d{1,2}(?:\.\d{1,2}){0,3}[.)]?", first):
            t = _num(first.rstrip(".)"))
            rest = " | ".join(cells[1:])
            m2 = _DOT_RE.match(cells[1])
            if m2 and _num(m2.group(1))[:len(t)] == t and len(_num(m2.group(1))) > len(t):
                _dot(t, rest)
                _dot(_num(m2.group(1)), m2.group(2))
            else:
                _dot(t, rest)
            continue
        m = re.match(r"^\s*(\d{1,2}(?:\.\d{1,2}){0,3})(\.|\.?(?=\s))\s*(.*)$", first)
        if m and (m.group(2) == "." or "." in m.group(1)) and len(m.group(3)) >= 3 \
                and not re.match(r"^\d", m.group(3)):
            _dot(_num(m.group(1)), m.group(3))
            continue
        m = _PAREN_RE.match(first)
        if m and st["loose"]:
            continue
        if m and paren["base"] is None and int(m.group(1)) == 1:
            paren["base"], paren["last"] = (), 0
        if m and paren["base"] is not None:
            n = int(m.group(1))
            if n == 1 or 0 < n - paren["last"] <= _GAP:
                paren["last"] = n
                _emit(tuple(paren["base"]) + (n,), m.group(2), paren_leaf=True)
    return out


# ── бланки замовника: межі (зміна 643) ────────────────────────────────────
# 🩸 25.09.2026, Каспер. Пакет писав «заповнюється на бланку Замовника» замість самого
# бланка, хоча текст Пропозиції, Додатка 2 і проєкту договору платформа вже прочитала.
# ⛒ Межі документів замовника (Форма N, Додаток N, договір) читає ТОЙ САМИЙ писар, що й
# нумерацію пунктів: одна правда про те, де починається і де кінчається документ.
# 🩸 «Додаток № 1» з рядком «до Договору» — додаток ДОГОВОРУ (специфікація), а не
# Додаток 1 оголошення (Пропозиція). Без цього правила специфікація договору ставала
# «Пропозицією», а договір втрачав свої додатки.
_CONTRACT_OF = re.compile(r"^до\s+(?:цього\s+|даного\s+)?договор", re.I)
_CHANGES_DOC = re.compile(r"перелік\s+змін|порівняльн\w+\s+таблиц|протокол\s+змін", re.I)
_CONTRACT_HEAD = re.compile(r"^(?:проєкт|проект)?\s*договір\b|^(?:проєкт|проект)\s+договору\b", re.I)


def annex_of_contract(lines, i, tail="") -> bool:
    """Межа в рядку i — додаток ДОГОВОРУ («до Договору» в тому ж рядку або в наступному)."""
    if tail and _CONTRACT_OF.match(_fold(tail)):
        return True
    for nxt in lines[i + 1:i + 4]:
        t = _fold(nxt)
        if t:
            return bool(_CONTRACT_OF.match(t))
    return False


def blocks(material: str) -> list:
    """[{key, keys, doc, start, end, text, changes}] — Форми, Додатки й договори замовника.

    Документ без рядка-межі («Додаток 3.docx», «Договір….docx») сам є блоком за своєю
    назвою. Додатки договору («до Договору») лишаються всередині договору. Текст поза
    основною структурою («[ДОДАТКОВО ЗНАЙДЕНО…]») — не частина жодного бланка."""
    lines = str(material or "").splitlines()
    out, st = [], {"cur": None, "doc": "", "skip": False}

    def _close(end):
        cur = st["cur"]
        if cur:
            cur["end"] = end
            cur["text"] = "\n".join(lines[cur["start"]:end]).strip()
            head = [_fold(x) for x in lines[cur["start"]:end] if _fold(x)][:6]
            if any(_CONTRACT_HEAD.match(h) for h in head) and ("договір",) not in cur["keys"]:
                cur["keys"] = tuple(cur["keys"]) + (("договір",),)
            if cur["text"]:
                out.append(cur)
        st["cur"] = None

    def _open(start, keys):
        st["cur"] = {"key": keys[0], "keys": tuple(keys), "doc": st["doc"], "start": start,
                     "changes": bool(_CHANGES_DOC.search(st["doc"]))}

    for i, raw in enumerate(lines):
        s = raw.strip()
        m = _DOC_RE.match(s)
        if m:
            _close(i)
            st["doc"], st["skip"] = m.group(1), m.group(1).lower().startswith("audit_")
            keys = [k for k in _keys_of_name(st["doc"]) if k[0] in ("додаток", "форма", "договір")]
            if keys and not st["skip"]:
                _open(i + 1, keys)
            continue
        if st["skip"]:
            continue
        if s.startswith("[ДОДАТКОВО"):
            _close(i)
            st["skip"] = True
            continue
        solo = [c.strip() for c in s.strip("|").split("|") if c.strip()] if "|" in s else [s]
        if len(solo) != 1:
            continue
        b = _BOUND_RE.match(solo[0])
        if not b:
            continue
        kind = "форма" if b.group(1).lower().startswith("форм") else "додаток"
        if annex_of_contract(lines, i, b.group(3)):
            if st["cur"] is not None:
                if ("договір",) not in st["cur"]["keys"]:
                    st["cur"]["keys"] = tuple(st["cur"]["keys"]) + (("договір",),)
                continue
            _open(i, [("додаток договору", int(b.group(2))), ("договір",)])
            continue
        _close(i)
        _open(i, [(kind, int(b.group(2)))])
    _close(len(lines))
    return out


def blank_for(material: str, key) -> dict:
    """Бланк замовника за ключем (('додаток', 1) / ('форма', 2) / ('договір',)) або {}.
    Кілька редакцій — остання (документ зі змінами йде після первісного); перелік змін
    («було/стало») бланком не буває."""
    found = [b for b in blocks(material) if key in b["keys"] and not b["changes"]]
    if key == ("договір",):
        # договір, названий додатком оголошення, — сильніший за окремий файл «Договір»
        named = [b for b in found if b["key"][0] in ("додаток", "форма")]
        found = named or found
    return found[-1] if found else {}


# ── карта в пакеті і назад ──────────────────────────────────────────────────

def _first_sentence(text: str, width: int = _LINE_CUT) -> str:
    t = _fold(text)
    m = re.search(r"(?<=[^\d\s.][.!?])\s", t)
    if m and m.start() <= width:
        t = t[:m.start()]
    return (t[:width].rstrip() + "…") if len(t) > width else t


def section(material: str) -> str:
    """Карта пунктів у пакеті (### — під паспортом). Порожньо, якщо нумерації немає."""
    idx = index(material)
    if not idx:
        return ""
    lines = ["### %s (номери — дослівно з документів замовника)" % HEAD, "",
             "Кожен номер пункту, який платформа називає, є тут. Шукайте пункт у документі, "
             "назва якого стоїть першою. Підпункти, які замовник нумерує наново під пунктом "
             "(«15. Вимоги до Учасника:» → «1.», «2.»), записано як 15.1, 15.2.", ""]
    seen = set()
    for e in idx:
        ln = "- %s, %s — %s" % (e["label"], e["cite"], _first_sentence(e["text"]))
        if ln not in seen:                 # дві редакції одного документа — один рядок
            seen.add(ln)
            lines.append(ln)
    return "\n".join(lines)


_MAP_LINE = re.compile(r"^-\s+(?P<label>.+?),\s+(?:п\.\s+(?P<num>\d{1,2}(?:\.\d{1,2}){0,3})"
                       r"(?:,\s+пп\.\s+(?P<par>\d{1,2})\))?|пп\.\s+(?P<rpar>\d{1,2})\))\s+—\s+(?P<text>.*)$")


def section_of(markdown: str) -> str:
    """Розділ карти з готового пакета (до наступного розділу), або ""."""
    t = str(markdown or "")
    a = t.find("### " + HEAD)
    if a < 0:
        return ""
    ends = [x for x in (t.find("\n## ", a + 3), t.find("\n### ", a + 3), t.find("\n---", a + 3)) if x > 0]
    return t[a:min(ends) if ends else len(t)].strip()


def index_from_markdown(markdown: str) -> list:
    """Карту, покладену в пакет, прочитати назад (двері відповіді бачать саме її)."""
    out = []
    for ln in section_of(markdown).splitlines():
        m = _MAP_LINE.match(ln.strip())
        if not m:
            continue
        label = m.group("label").strip()
        if m.group("rpar"):
            path, par = (int(m.group("rpar")),), True
        else:
            path = _num(m.group("num"))
            par = bool(m.group("par"))
            if par:
                path = path + (int(m.group("par")),)
        out.append({"label": label, "keys": _keys_of_label(label), "path": path, "paren": par,
                    "cite": "", "text": m.group("text")})
    return out


def _keys_of_label(label: str) -> tuple:
    low = label.lower()
    if low == "оголошення":
        return (("main",),)
    if low == "тендерна документація":
        return (("main", "td"), ("main",))
    m = re.match(r"форма\s+(\d+)", low)
    if m:
        return (("форма", int(m.group(1))),)
    m = re.match(r"додаток\s*№?\s*(\d+)", low)
    if m:
        return (("додаток", int(m.group(1))),)
    if low.startswith("проєкт договору"):
        return (("договір",),)
    return (("doc", label),)


# ── двері відповіді ─────────────────────────────────────────────────────────

_NUM = r"\d{1,2}(?:\.\d{1,2}){0,3}"
_KW = r"(?:п\.\s*п\.|пп\.|п\.|пункт[а-яіїє]*|підпункт[а-яіїє]*)"
_SEP = r"\s*(?:,|і|й|та|–|—|-|до)\s*(?:" + _KW + r"\s*)?"
_REF = re.compile(r"(?<![\w.])(?P<kw>" + _KW + r")\s*(?P<nums>" + _NUM + r"(?:" + _SEP + _NUM + r")*)"
                  r"(?![\d)])", re.I)
_CONT_AFTER = re.compile(r"^\s*(?:(?:у|в)\s+)?[«\"“]?\s*(?:(?:цього|даного)\s+)?"
                         r"(?P<c>(?P<f>форм\w*)\s*№?\s*(?P<fn>\d{1,2})|(?P<d>додат\w*)\s*№?\s*(?P<dn>\d{1,2})"
                         r"|(?P<o>оголошенн\w*)|(?P<td>тендерн\w+\s+документац\w*)|(?P<g>договор\w*|проєкт\w*\s+договор\w*))"
                         r"(?:\s*[»\"”])?", re.I)
_CONT_BEFORE = re.compile(r"(?:(?:у|в)\s+)?(?P<c>(?P<f>форм\w*)\s*№?\s*(?P<fn>\d{1,2})|(?P<d>додат\w*)\s*№?\s*(?P<dn>\d{1,2}))"
                          r"\s*[»\"”]?\s*,?\s*$", re.I)
_LAW = re.compile(r"^[^.;\n]{0,70}?(?:\bч\.\s*\d|\bчастин|\bст\.\s*\d|\bстатт|закон|кодекс|особливост|постанов|"
                  r"\bпорядк|положенн|інструкц|\bкму\b|розпорядженн)", re.I)
_TAIL_DUP = re.compile(r"^\s*(?:цього|даного)\s+оголошенн\w*", re.I)


def _cont_key(m):
    if not m:
        return None
    if m.group("f"):
        return ("форма", int(m.group("fn")))
    if m.group("d"):
        return ("додаток", int(m.group("dn")))
    g = m.groupdict()
    if g.get("o") or g.get("td"):
        return ("main",)
    if g.get("g"):
        return ("договір",)
    return None


def _nums_of(s: str) -> list:
    return [_num(x) for x in re.findall(_NUM, s)]


def _has(idx, key, t) -> bool:
    for e in idx:
        if key is not None and key not in e["keys"]:
            continue
        if e["path"] == t:
            return True
    return False


def _docs_with_all(idx, nums) -> list:
    keys = []
    for e in idx:
        for k in e["keys"]:
            if k not in keys:
                keys.append(k)
    return [k for k in keys if all(_has(idx, k, t) for t in nums)]


def _label_for_key(idx, key) -> str:
    for e in idx:
        if key in e["keys"]:
            return e["label"]
    return ""


def _stems(text) -> set:
    return {w[:5] for w in re.findall(r"[a-zа-яіїєґ']{5,}", str(text or "").lower())}


def refs(reply: str, idx) -> list:
    """Усі посилання на пункти замовника у відповіді: [{span, nums, key, ok}]."""
    out = []
    t = str(reply or "")
    for m in _REF.finditer(t):
        after = t[m.end():m.end() + 90]
        if _LAW.match(after):
            continue
        nums = _nums_of(m.group("nums"))
        ca = _CONT_AFTER.match(after)
        key, span = None, [m.start(), m.end()]
        if ca and _cont_key(ca):
            key = _cont_key(ca)
            span[1] = m.end() + ca.end()
            d = _TAIL_DUP.match(t[span[1]:])
            if d and key == ("main",):
                span[1] += d.end()
        else:
            cb = _CONT_BEFORE.search(t[max(0, m.start() - 30):m.start()])
            if cb and _cont_key(cb):
                key = _cont_key(cb)
                span[0] = max(0, m.start() - 30) + cb.start()
        if key == ("договір",) and not any(("договір",) in e["keys"] for e in idx):
            key = None
        ok = all(_has(idx, key, n) for n in nums)
        out.append({"span": tuple(span), "text": t[span[0]:span[1]], "nums": nums, "key": key,
                    "kw": m.group("kw"), "ok": ok})
    return out


def _cite_text(kw, nums_src, label) -> str:
    return "%s %s %s" % ("п." if kw.lower().startswith("п") else kw, nums_src.strip(), _genitive(label))


def mend(reply: str, idx) -> tuple:
    """-> (відповідь, [що виправлено]). Без карти відповідь не змінюється."""
    if not idx or not reply:
        return reply, []
    t = str(reply)
    fixes = []
    for r in reversed(refs(t, idx)):
        if r["ok"]:
            continue
        a, b = r["span"]
        m = _REF.search(t, a)
        nums_src = m.group("nums") if m else _dotted(r["nums"][0])
        new = None
        homes = _docs_with_all(idx, r["nums"])
        if homes:
            key = ("main",) if ("main",) in homes else homes[0]
            if len(homes) == 1 or ("main",) in homes:
                new = _cite_text(r["kw"], nums_src, _label_for_key(idx, key))
        if new is None:
            win = t[max(0, a - 220):min(len(t), b + 220)]
            ws = _stems(win)
            scored = sorted(((len(ws & _stems(e["text"])), i) for i, e in enumerate(idx)), reverse=True)
            if scored and scored[0][0] >= 3 and (len(scored) == 1 or scored[0][0] >= scored[1][0] + 2):
                e = idx[scored[0][1]]
                new = "п. %s %s" % (_dotted(e["path"]), _genitive(e["label"]))
        if new is None:
            new = ""
        if new.endswith(("оголошення", "документації")):
            d = _TAIL_DUP.match(t[b:]) or re.match(r"^\s*(?:цієї|даної)\s+(?:тендерної\s+)?документац\w*", t[b:], re.I)
            if d:
                b += d.end()
        fixes.append((r["text"], new))
        t = t[:a] + new + t[b:]
    if fixes:
        t = re.sub(r"[ \t]{2,}", " ", t)
        t = re.sub(r"\s+([,.;:])", r"\1", t)
        t = re.sub(r"\(\s*\)|«\s*»", "", t)
    return t, list(reversed(fixes))
