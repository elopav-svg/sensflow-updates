"""
threads.py — архів чатів (серверне збереження діалогів).

Кожен чат — JSON-файл у orchestrator_py/threads/<id>.json:
  {id, title, created_at, updated_at, messages:[{role, content, at}]}
Назва автоматично береться з першого повідомлення користувача.
"""

import json
import uuid
from datetime import datetime
from pathlib import Path

import config

# ⭐⭐⭐ 01.09.2026. ПИСАР ІДЕ ЗА ПЕРЕМИКАЧЕМ СТАНУ, А НЕ ЗА ТЕКОЮ РУШІЯ.
# У бою `STATE_DIR == ENGINE_DIR`, тож шлях не змінюється ні на байт.
# Під чеком стан відведено вбік — і ми більше не пишемо в бойову теку.
THREADS_DIR = config.STATE_DIR / "threads"
THREADS_DIR.mkdir(parents=True, exist_ok=True)


def _path(tid: str) -> Path:
    safe = "".join(ch for ch in (tid or "") if ch.isalnum() or ch in "-_")
    return THREADS_DIR / f"{safe}.json"


def _save(rec: dict):
    _path(rec["id"]).write_text(json.dumps(rec, ensure_ascii=False, indent=2), encoding="utf-8")


def create(title: str = None) -> dict:
    tid = "thr-" + uuid.uuid4().hex[:8]
    now = datetime.now().isoformat()
    rec = {"id": tid, "title": title or "Новий чат", "created_at": now, "updated_at": now, "messages": []}
    _save(rec)
    return rec


def get(tid: str):
    p = _path(tid)
    if not p.exists():
        return None
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None


def append(tid: str, role: str, content: str, files_context: str = None, extra: dict = None) -> dict:
    rec = get(tid)
    if rec is None:
        now = datetime.now().isoformat()
        rec = {"id": tid, "title": "Новий чат", "created_at": now, "updated_at": now, "messages": []}
    msg = {"role": role, "content": content, "at": datetime.now().isoformat()}
    # Зберігаємо вміст прикріплених файлів разом із ходом — щоб документ
    # лишався доступним на наступних ходах діалогу (як у звичайному чаті з LLM).
    if files_context:
        msg["files_context"] = files_context
    # Зберігаємо результат (тіло + файли + перевірка), щоб при повторному відкритті
    # чату користувач бачив результат і кнопки завантаження, а не лише коротку репліку.
    if extra:
        msg.update(extra)
    rec["messages"].append(msg)
    if role == "user" and rec.get("title") in (None, "", "Новий чат") and (content or "").strip():
        rec["title"] = content.strip()[:48]
    rec["updated_at"] = datetime.now().isoformat()
    _save(rec)
    return rec


def understanding_of(tid: str):
    """⭐ ПОПРАВКА ЛЮДИНИ ПРО РОЗУМІННЯ ЗАДАЧІ — ЖИВЕ ВЕСЬ ЧАТ (зміна 152).

    Рішення 8 задуму: людина виправила галузь один раз — і далі в цьому чаті
    вона діє, доки людина не змінить. Тому правда лежить у ЧАТІ на диску, а не в
    памʼяті вкладки: сторінку перезавантажують, вкладку закривають, сервер
    перезапускають — а поправка мусить пережити все це. Інакше клієнт виправляв
    би те саме по колу."""
    rec = get(tid) or {}
    u = rec.get("understanding")
    return u if isinstance(u, dict) and u else None


# ⭐⭐⭐ 640. ПІДТВЕРДЖЕНЕ РОЗУМІННЯ ЖИВЕ ВЕСЬ ЧАТ. 🩸 Каспер, 639б: «Запускай» на
# картці, відповідь про товар — і та сама картка знову: факт підтвердження жив один
# хід. Тепер відбиток підтвердженого розуміння лягає в ЧАТ на диску (поряд із
# поправкою людини) і їде в агент тим самим `understanding_of`. Інше розуміння —
# інший відбиток: картка питає знову. Інший чат — свій запис.
CONFIRMED_KEY = "_confirmed"
_CONFIRMED_CAP = 20


def remember_turn_understanding(tid: str, turn_result) -> bool:
    """Записати в чат відбиток розуміння, яке людина підтвердила в цьому ході."""
    fp = (turn_result or {}).get("understanding_confirmed") if isinstance(turn_result, dict) else None
    if not fp or not tid:
        return False
    rec = get(tid)
    if not rec:
        return False
    cur = dict(rec.get("understanding") or {})
    seen = [x for x in (cur.get(CONFIRMED_KEY) or []) if x != fp] + [str(fp)]
    cur[CONFIRMED_KEY] = seen[-_CONFIRMED_CAP:]
    rec["understanding"] = cur
    rec["updated_at"] = datetime.now().isoformat()
    _save(rec)
    return True


def set_understanding(tid: str, patch: dict):
    """Накласти поправку (лише відомі ключі) і повернути ПОВНИЙ стан чату."""
    rec = get(tid)
    if not rec:
        return None
    cur = dict(rec.get("understanding") or {})
    for k in ("domain", "jurisdiction"):
        v = (patch or {}).get(k)
        if v:
            cur[k] = str(v)
    rec["understanding"] = cur
    rec["updated_at"] = datetime.now().isoformat()
    _save(rec)
    return cur or None


def latest_files_context(tid: str) -> str:
    """Найсвіжіший вміст прикріплених файлів у цьому діалозі (для успадкування
    документа на наступних ходах, коли користувач уже нічого не прикріпив)."""
    rec = get(tid)
    if not rec:
        return ""
    for m in reversed(rec.get("messages", [])):
        if m.get("files_context"):
            return m["files_context"]
    return ""


def _first_heading(md: str) -> str:
    import re
    for line in (md or "").splitlines():
        m = re.match(r"^\s{0,3}#{1,3}\s+(.+?)\s*#*\s*$", line)
        if m:
            return m.group(1).strip()
    return ""


PASSPORT_HEAD = "ПАСПОРТ РЕЗУЛЬТАТУ"      # той самий знак, що в tender_skeleton (639)


def _passport_of(md: str, cap: int = 4000) -> str:
    """Розділ «## ПАСПОРТ РЕЗУЛЬТАТУ…» до наступного «## » (або кінця), або ""."""
    t = str(md or "")
    a = t.find("## " + PASSPORT_HEAD)
    if a < 0:
        return ""
    ends = [x for x in (t.find("\n## ", a + 3), t.find("\n---", a + 3)) if x > 0]
    return t[a:min(ends) if ends else len(t)].strip()[:cap]


def history_for_brain(tid: str, max_turns: int = 10, body_chars: int = 4000) -> list:
    """Авторитетна історія для мозку — з СЕРВЕРНОГО треда, а не з лосслесної історії
    браузера. Зданий результат подається з реальним змістом і явною міткою, щоб мозок
    відповідав на уточнення по суті й НЕ зрікався власної роботи. Повне тіло звіту даємо
    лише для ОСТАННЬОГО зданого результату (економія токенів); старіші — лише мітка."""
    rec = get(tid)
    if not rec:
        return []
    msgs = rec.get("messages", [])
    last_res = -1
    for i, m in enumerate(msgs):
        if m.get("role") == "assistant" and ((m.get("result") or {}).get("final_markdown") or "").strip():
            last_res = i
    out = []
    for i, m in enumerate(msgs):
        role = "assistant" if m.get("role") == "assistant" else "user"
        content = m.get("content", "") or ""
        res = m.get("result") or {}
        fm = (res.get("final_markdown") or "").strip()
        if role == "assistant" and fm:
            arts = [a.get("filename") for a in (res.get("artifacts") or [])
                    if isinstance(a, dict) and a.get("filename")]
            title = _first_heading(fm) or "результат"
            head = ("[ЗДАНИЙ РЕЗУЛЬТАТ — вже створено й передано користувачу]\n"
                    f"Назва: {title}\n"
                    + (f"Файли: {', '.join(arts)}\n" if arts else ""))
            if i == last_res:
                # ⭐ 639: ПАСПОРТ РЕЗУЛЬТАТУ — мозку ЦІЛИМ. 🩸 На «чому статут сканом?»
                # мозок бачив перші 4000 знаків 66-тисячного пакета і «пояснив», що
                # статуту в досьє немає. Паспорт — короткий перелік рішень самої
                # системи (склад і доля файлів); він іде першим, звіт — за ним.
                pp = _passport_of(fm)
                room = body_chars if not pp else max(1200, body_chars - len(pp) // 2)
                body = fm if len(fm) <= room else fm[:room] + "\n…[звіт скорочено; повний — у файлах]"
                content = head + (("Паспорт результату (рішення системи — спирайся на нього):\n%s\n\n"
                                   % pp) if pp else "") + "Зміст (для відповідей на уточнення):\n" + body
                # ⭐⭐⭐ 642: КАРТА ПУНКТІВ ЗАМОВНИКА — мозку ЦІЛОЮ. 🩸 Прогін 640: без неї мозок
                # склав номер «п.15.2 Форми 1», якого немає. Карта їде поруч із пакетом
                # (поле результату `clause_map`), за нею ж двері (`agent._mend_clause_refs`).
                try:
                    import clause_map as _cmap
                    _cm = _cmap.section_of(res.get("clause_map") or "")
                except Exception:
                    _cm = ""
                if _cm:
                    content += ("\n\n" + _cmap.BRAIN_RULE + "\n" + _cm)
            else:
                content = head + "(зміст не дублюємо — це не останній результат)"
        out.append({"role": role, "content": content})
    return out[-max_turns:]


def list_threads(limit: int = 60) -> list:
    out = []
    if not THREADS_DIR.exists():
        return out
    files = sorted(THREADS_DIR.glob("*.json"), key=lambda x: x.stat().st_mtime, reverse=True)
    for p in files:
        try:
            r = json.loads(p.read_text(encoding="utf-8"))
            msgs = r.get("messages", [])
            if not msgs:
                continue  # порожні чати не показуємо
            out.append({"id": r["id"], "title": r.get("title") or "Без назви",
                        "updated_at": r.get("updated_at"), "count": len(msgs)})
        except Exception:
            continue
        if len(out) >= limit:
            break
    return out


def delete(tid: str) -> bool:
    p = _path(tid)
    if p.exists():
        try:
            p.unlink()
            return True
        except Exception:
            return False
    return False


def set_project(tid: str, pid):
    """Стампить (або знімає, якщо pid=None) мітку проєкту на треді — для O(1)
    пошуку контексту проєкту в гарячому шляху чату. Членство веде projects.py."""
    rec = get(tid)
    if rec is None:
        return False
    if pid:
        rec["project_id"] = pid
    else:
        rec.pop("project_id", None)
    rec["updated_at"] = datetime.now().isoformat()
    _save(rec)
    return True


def project_of(tid: str):
    """Id проєкту, якому належить цей чат, або None."""
    rec = get(tid)
    if not rec:
        return None
    return rec.get("project_id")
