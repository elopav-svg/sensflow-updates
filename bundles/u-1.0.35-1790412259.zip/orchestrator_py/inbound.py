# -*- coding: utf-8 -*-
"""inbound.py — ВХІДНИЙ СИГНАЛ: зіставити з контрагентом або покласти в чергу.

⭐⭐⭐ ЗМІНА 12.08.2026 (167), слово Андрія: «Лист від невідомого абонента потрапляє
у CRM на стадію "Не оброблені". Менеджер (або ШІ в ролі менеджера) читає лист і
ОДНІЄЮ КНОПКОЮ кладе абонента в базу "Клієнти".»

ЩО БУЛО НЕ ТАК (знайдено читанням коду, а не прогоном). `from_email` мав
`create_if_missing=True` і на БУДЬ-ЯКИЙ невідомий лист САМ створював картку
«Новий клієнт». Тобто:
  • кнопку менеджера обходив код — рішення людини підмінював дефолт;
  • у клієнтську базу — фундаментальний актив компанії — сипались розсилки,
    автовідповідачі й випадкові адресати;
  • черга «Не оброблені» (`crm.inbox`) існувала, але працювала ЛИШЕ для Telegram:
    пошта проходила повз неї.
Це той самий клас, що й «дефолт, який робить документ із будь-якого рядка» (157):
питання без відповіді «жоден» — міна.

ЯК ТЕПЕР:
  • ВПІЗНАЛИ (за ручкою контрагента в довіднику `parties.py`) → позначка «потребує
    уваги» на картці, як і раніше;
  • НЕ ВПІЗНАЛИ → вхідне лягає в чергу «Не оброблені» — і пошта, і Telegram
    однаково. Нічого не створюється;
  • контрагент зʼявляється в базі ЛИШЕ через `promote()` — це і є та сама кнопка.

Лише stdlib + `crm` + `parties`. Нічого не надсилає назовні.
"""

import crm
import parties


def from_telegram(chat_id, username: str = "", name: str = "", text: str = "") -> dict:
    """Вхідне з Telegram. Повертає {matched, customer}."""
    cust = crm.find_by_telegram(chat_id)
    if not cust and username:
        cust = crm.find_by_telegram_user(username)
    if cust:
        crm.note_inbound(cust, "telegram", text)
        # Доприбʼємо chat_id, якщо картку знайшли лише за юзернеймом.
        # ⭐ КРОК B1: канали питаємо в КОНТАКТА під карткою, а не в самій картці.
        if not crm.channels_of(cust).get("telegram_id"):
            crm.link_telegram(cust, chat_id, username)
        return {"matched": True, "customer": cust}
    crm.record_unmatched("telegram", str(chat_id), name or username, text)
    return {"matched": False, "customer": ""}


def from_email(email: str, name: str = "", subject: str = "", preview: str = "",
               org: str = "", to: str = "", cc: str = "", box_owner: str = "") -> dict:
    """Вхідне з пошти. Повертає {matched, customer}.

    ⛔ Картку НЕ створює. Невідомий відправник іде в чергу «Не оброблені».

    ⭐⭐⭐ 618: «КОМУ» ЇДЕ ОКРЕМИМ ПОЛЕМ І БІЛЬШЕ НЕ ГИНЕ НА ПОРОЗІ. Доти двері
    брали відправника, тему й уривок — а саме в «кому» корпоративна скринька
    й каже, ЧИЙ це лист (`sales+ivan@`). Найточніше джерело правди про
    власника платформа викидала, не прочитавши."""
    email = (email or "").strip()
    cust = crm.find_by_email(email)
    if cust:
        # ⭐ C2: ТЕМА їде окремим полем. Адреса угоди живе саме в темі, і якщо
        # склеїти її з уривком, токен `[SF-D0014]` загубиться серед тексту.
        # ⭐ 648: з чиєї ОСОБИСТОЇ скриньки прочитано лист — їде до судді «чий лист».
        crm.note_inbound(cust, "email", subject or preview, subject=subject,
                         to=to, cc=cc, box_owner=box_owner)
        return {"matched": True, "customer": cust}
    # ⭐ 648: у черзі видно і тему, і початок тексту — менеджер вирішує «у базу»
    # з першого погляду, не відкриваючи пошту.
    crm.record_unmatched("email", email, name or org,
                         " — ".join(x for x in (subject, preview) if (x or "").strip()))
    return {"matched": False, "customer": ""}


# ── КНОПКА МЕНЕДЖЕРА: з черги — у клієнтську базу ────────────────────────────
_CHANNEL_HANDLE = {"email": parties.H_EMAIL, "telegram": parties.H_TG_ID}


def promote(channel: str, identity: str, name: str = "", kind: str = parties.KIND_UNKNOWN,
            roles=(parties.ROLE_CLIENT,), create_card: bool = True,
            stage: str = "Збір даних", note: str = "") -> dict:
    """Одна кнопка: невпізнане вхідне стає контрагентом у базі «Клієнти».

    ⭐ Мінімум, який потрібен, — сама ручка (пошта або телеграм) і назва. Решта
    даних наповнюється потім, на стадіях «Збір даних» і «Кваліфікація».
    ⛔ Вгадування тут заборонене: якщо в черзі такого елемента немає — відмова
    з причиною, а не «створимо про всяк випадок»."""
    channel = (channel or "").strip()
    identity = (identity or "").strip()
    hk = _CHANNEL_HANDLE.get(channel)
    if not hk:
        raise parties.PartyError("Невідомий канал «%s». Відомі: пошта, телеграм." % channel)
    if not identity:
        raise parties.PartyError("Порожній відправник — нема чого класти в базу.")

    item = None
    for it in crm.inbox():
        if it.get("channel") == channel and str(it.get("identity")) == identity:
            item = it
            break
    if item is None:
        raise parties.PartyError("У черзі «Не оброблені» немає такого вхідного (%s: %s)."
                                 % (channel, identity))

    title = (name or item.get("name") or identity).strip()
    known = parties.find(identity, hk)
    if known:
        party = parties.get(known)
    else:
        party = parties.create(title, kind=kind, roles=roles,
                               handles={hk: [identity]},
                               source="черга «Не оброблені»: " + channel, note=note)

    customer = crm.card_of_party(party["id"])
    if not customer and create_card:
        customer = title
        crm.ensure_client(customer)
        card = crm.get_client(customer)
        if str(card.get("party_id") or "").strip() != party["id"]:
            crm.set_party(customer, party["id"])
        if channel == "email":
            crm.link_email(customer, identity)
        else:
            crm.link_telegram(customer, identity, item.get("name") or "")
        crm.note_inbound(customer, channel, item.get("preview") or "")

    # ⭐⭐⭐ КРОК C1 (15.08.2026): новий лід заходить У ВОРОНКУ через УГОДУ, а не
    # через стадію на картці — стадії на картці більше немає. Без цього рядка
    # кнопка «завести в базу» тихо викидала б лід із воронки: продаж почався, а
    # у воронці порожньо.
    # ⛒ Угоду заводимо ЛИШЕ разом із карткою (`create_card`) і лише тоді, коли
    # в цього контрагента ще немає жодної живої — другу вгадувати не наша справа.
    if create_card:
        try:
            import deals
            if not deals.live_deals_of_party(party["id"]):
                deals.create(title, party["id"], stage=stage,
                             source="черга «Не оброблені»: " + channel)
        except Exception as ex:
            # Мовчати не можна: лід у базі є, а у воронці його немає.
            import protocol as _pr
            _pr.write(_pr.A_DEAL_CREATED, parties.ref(party["id"]),
                      outcome="%s: %s" % (_pr.OUT_FAILED, ex),
                      note="угоду для нового ліда не заведено")

    crm.clear_inbox(channel, identity)
    return {"party": parties.get(party["id"]), "customer": customer}
