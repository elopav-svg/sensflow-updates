# -*- coding: utf-8 -*-
"""
taskdesk_telegram.py — РОТ TASK DESK: доносить події нерва в телеграм.

КОРІНЬ, ЯКИЙ ЦЕ ЛІКУЄ (08.08.2026). Нерв (`taskdesk_events`) уже знає, ЩО
сталося і КОГО це стосується, але не знає, як про це СКАЗАТИ. Людина за межами
офісу не дізнається нічого: платформа стоїть на `127.0.0.1`, і телефон її не
дістане ні додатком, ні сторінкою.

⭐⭐⭐ ТЕЛЕГРАМ — ЄДИНИЙ КАНАЛ, ЩО ОБХОДИТЬ СТІНУ БЕЗ ДІРИ В ПЕРИМЕТРІ КЛІЄНТА:
бот сам дзвонить НАЗОВНІ (long polling), місцем зустрічі стають сервери
телеграма. Жодного вхідного порту в клієнта відкривати не треба.

МЕЖІ, ПРИЙНЯТІ СВІДОМО:
  • бот живе, лише поки живий сервер клієнта (те саме, що зупинило бота
    лідогенерації 20.07.2026) — прокинувся, дочитав чергу з диска;
  • телеграм = вихід даних за периметр, тож для ЗАКРИТОГО КОНТУРУ рот просто
    не вмикається: немає токена — немає рота, нерв працює як працював.

ЦЕЙ ФАЙЛ — ОДИН ПИСАР ТЕКСТУ В ЧАТ. Слід у задачі малює
`taskdesk_tasks._reason()`, а повідомлення людині — `text_for()` тут. Це не два
писарі однієї правди: правда одна (вид події + деталі), а читачі різні —
журнал задачі й людина в телефоні.

⚠ ЖОДНОГО ВЛАСНОГО ДРОТУ НАЗОВНІ. Відправка йде через `telegram_bot.send_as()`,
той — через `netfetch`, тобто під тими самими воротами виходу, що й усе інше.
"""

import sys
import threading
import time

import taskdesk_events as events
import taskdesk_identity as identity
import taskdesk_people as people
import taskdesk_tasks as tasks

# Імʼя рота в черзі. Кожен рот веде СВІЙ курсор — пошта чи дзвіночок колись
# стануть поруч і не заберуть одне в одного події.
SINK = "telegram"

ROLE = "tasks"                 # роль бота в `telegram_bot`
TICK_SEC = 15                  # як часто рот заглядає в чергу
BATCH = 100                    # скільки подій за один захід
MAX_ATTEMPTS = 5               # скільки разів пробувати одну й ту саму подію

# Значок виду події. Людина в телефоні читає РЯДОК, а не абзац: значок і перше
# слово мають сказати все ще до того, як вона відкриє повідомлення.
MARK = {
    events.KIND_CREATED: "🆕",
    events.KIND_COMMENT: "💬",
    events.KIND_RESULT: "✅",
    events.KIND_VERIFIED: "🔎",
    events.KIND_STAGE: "🔄",
    events.KIND_DELEGATED: "👤",
    events.KIND_REFUSED: "⛔",
    events.KIND_UPDATED: "✏️",
    events.KIND_PROPOSAL: "🤖",
    events.KIND_PROPOSAL_DONE: "🤖",
    events.KIND_CHECKLIST: "☑️",
    events.KIND_LINKED: "🔗",
    events.KIND_UNLINKED: "🔗",
    events.KIND_OVERDUE: "⏰",
}


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def enabled() -> bool:
    """Рот увімкнений, якщо в клієнта заведений бот задач. Немає токена —
    немає рота, і це нормальний стан (закритий контур)."""
    try:
        import config
        return bool(_s(config.ENV.get("TELEGRAM_TASKS_BOT_TOKEN")))
    except Exception:
        return False


def bot_username() -> str:
    """Імʼя бота задач (@…). Людині треба знати, КОМУ надсилати код — інакше
    кнопка «Підключити телеграм» веде в нікуди. Імʼя питаємо в телеграма один
    раз, коли зберігають токен, і тримаємо поруч із ним."""
    try:
        import config
        return _s(config.ENV.get("TELEGRAM_TASKS_BOT_USERNAME"))
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# АДРЕСА: працівник → чат. Другого способу впізнати людину в боті немає.
# ---------------------------------------------------------------------------
def chat_of(emp_id: str) -> str:
    """Чат працівника або порожньо. Порожньо — це НЕ помилка: людина просто ще
    не підключила телеграм, і рот про неї мовчить."""
    acc = identity.account_of_employee(_s(emp_id))
    if not acc or not acc.get("can_login"):
        return ""
    return _s(acc.get("telegram_chat_id"))


def admin_of(emp_id: str) -> bool:
    """Чи цей працівник — адміністратор. Питаємо ТОГО САМОГО писаря, що й екран
    (`identity.is_admin`): відколи адміністратор може все, розбіжність означала б
    кнопку, яка є на екрані й зникла в телефоні."""
    return identity.is_admin(identity.account_of_employee(_s(emp_id)))


def _name(emp_id: str) -> str:
    eid = _s(emp_id)
    if not eid:
        return ""
    if eid == tasks.AI_ACTOR:
        return "SensFlow"
    emp = people.employee(eid)
    return _s(emp.get("full_name")) if emp else eid


def _human_date(iso: str) -> str:
    """Дата очима людини — DD.MM.YYYY (правило Андрія)."""
    v = _s(iso)
    if len(v) < 10:
        return v
    out = "%s.%s.%s" % (v[8:10], v[5:7], v[0:4])
    return (out + " " + v[11:16]) if len(v) >= 16 else out


def _link_phrase(det) -> str:
    """Звʼязок словами. ОДИН писар формулювань — `taskdesk_links.phrase`: інакше
    картка на екрані й повідомлення в чаті назвали б те саме різними словами."""
    det = det or {}
    try:
        import taskdesk_links as tlinks
        return tlinks.phrase(det.get("rel"), det.get("ref"))
    except Exception:
        return _s(det.get("ref"))


def _cut(text: str, n: int = 200) -> str:
    t = " ".join(_s(text).split())
    return t if len(t) <= n else (t[:n - 1] + "…")


# ---------------------------------------------------------------------------
# ОДИН ПИСАР ТЕКСТУ В ЧАТ
# ---------------------------------------------------------------------------
def _line(kind: str, det: dict, who: str, count: int) -> str:
    """Що саме сталося — одним рядком. Кількість — це склеювання: пʼять
    коментарів за хвилину людина має отримати ОДНИМ повідомленням, інакше бота
    вимкнуть, і нерв стане марним."""
    det = det or {}
    if kind == events.KIND_CREATED:
        return "%s поставив(ла) вам задачу" % who if who else "Нова задача"
    if kind == events.KIND_COMMENT:
        if count > 1:
            return "%s — %d нові коментарі" % (who, count)
        return "%s залишив(ла) коментар" % who
    if kind == events.KIND_RESULT:
        return "%s позначив(ла) результат" % who
    if kind == events.KIND_VERIFIED:
        return "%s перевірив(ла) результат: годиться" % who
    if kind == events.KIND_STAGE:
        st = _s(det.get("stage"))
        return "%s: стадія → %s" % (who, tasks.STAGE_NAMES.get(st, st))
    if kind == events.KIND_DELEGATED:
        return "%s передав(ла) задачу: виконавець — %s" % (
            who, _name(det.get("new_assignee_id")))
    if kind == events.KIND_REFUSED:
        return "%s відмовився(лась). Причина: %s" % (who, _cut(det.get("reason"), 150))
    if kind == events.KIND_UPDATED:
        said = [x for x in (det.get("said") or []) if _s(x)]
        return "%s змінив(ла) задачу: %s" % (who, _cut(" · ".join(said), 150))
    if kind == events.KIND_PROPOSAL:
        if _s(det.get("kind_of")) == "acceptance":
            return "Пропозиція: за чим приймемо результат — %s" % _cut(det.get("text"), 120)
        return "Пропозиція: посунути термін до %s" % _human_date(det.get("date"))
    if kind == events.KIND_PROPOSAL_DONE:
        return "Пропозицію %s" % ("прийнято" if det.get("accepted") else "відхилено")
    if kind == events.KIND_CHECKLIST:
        if count > 1:
            return "%s — %d пункти плану" % (who, count)
        return "%s %s пункт плану" % (who, "виконав(ла)" if det.get("done")
                                      else "зняв(ла) галочку з")
    if kind == events.KIND_LINKED:
        return "%s звʼязав(ла) задачу — %s" % (who, _link_phrase(det))
    if kind == events.KIND_UNLINKED:
        return "%s прибрав(ла) звʼязок — %s" % (who, _link_phrase(det))
    if kind == events.KIND_OVERDUE:
        # ⚠ ДІЯЧА ТУТ НЕМАЄ НАВМИСНО: строк минув сам собою, і писати «Платформа
        # протермінувала вашу задачу» було б неправдою про того, хто діяв.
        return "Строк минув: %s. Задача досі в роботі." % _human_date(det.get("due"))
    return events.KIND_NAMES.get(kind, kind)


def text_for(group: list) -> str:
    """Повідомлення в чат із групи подій. Порожня група — порожній текст, а не
    виняток: рот не сміє впасти через дивну чергу.

    ⚠ Посилання на задачу тут НЕМАЄ навмисно. Платформа стоїть на `127.0.0.1`,
    і посилання з телефона нікуди не веде. Обіцянка, не покрита фактом, гірша
    за її відсутність — адреса буде окремою роботою."""
    group = [g for g in (group or []) if isinstance(g, dict)]
    if not group:
        return ""
    first = group[0]
    kind = _s(first.get("kind"))
    det = first.get("details") or {}
    who = _name(first.get("actor_id"))
    head = "%s %s" % (MARK.get(kind, "•"), _line(kind, det, who, len(group)))
    title = _cut(first.get("task_title"), 120) or "(без назви)"
    out = [head, "«%s» · %s" % (title, _s(first.get("task_id")))]
    # Текст коментаря — саме те, заради чого людина відкриває телефон.
    if kind in (events.KIND_COMMENT, events.KIND_RESULT) and len(group) == 1:
        body = _cut(det.get("text"), 300)
        if body:
            out.append("— " + body)
    return "\n".join(out)


# ---------------------------------------------------------------------------
# ⭐⭐⭐ КНОПКИ ПІД ПОВІДОМЛЕННЯМ — ОДИН РЕЄСТР НА ВЕСЬ КАНАЛ
#
# КОРІНЬ (живий тест 09.08.2026). Людина, отримавши задачу, природно
# відповідає в чат. Бот відсилав її «на екран задач» — а екран на
# `127.0.0.1`, і з телефона туди шляху НЕМАЄ. ПОВІДОМЛЕННЯ БЕЗ ЖОДНОЇ
# ДІЇ ПЕРЕТВОРЮЄ ТЕЛЕФОН НА ГЛУХИЙ КУТ.
#
# ⭐⭐⭐ ЦЕ ТОЙ САМИЙ ЗАКОН, ЩО Й НА ЕКРАНІ: ДІЯ БЕЗ КНОПКИ НЕ ІСНУЄ.
# Телеграм — другий екран продукту, і правила в нього ті самі.
#
# ⭐ ПРАВ ТУТ НЕ ОГОЛОШУЮТЬ. Кожна кнопка називає ДІЇ з `tasks.ACTION_ROLES`,
# і показується лише тоді, коли ВСІ вони дозволені. Другої таблиці
# прав немає й не буде [[project_taskdesk_rights_table]].
#
# ⭐ `when` — ЦЕ НЕ ПРАВА, А ДОРЕЧНІСТЬ. Право взяти в роботу в людини
# є завжди, але в задачі, яка ВЖЕ в роботі, така кнопка — пастка:
# натиснувши її, людина розішле всім порожнє сповіщення. Звідси ж
# безкоштовно виходить закон «повторне натискання не народжує події».
# ---------------------------------------------------------------------------
BTN_WORK = "work"        # взяти в роботу
BTN_DONE = "done"        # здати роботу (результат + на перевірку)
BTN_ACCEPT = "accept"    # прийняти (постановник)
BTN_BACK = "back"        # повернути в роботу
BTN_NOTE = "note"        # коментар
BTN_DUE = "due"          # прошу інший термін

CB_PREFIX = "td"
CB_LIMIT = 64            # межа телеграма на callback_data, у БАЙТАХ


def _live(t) -> bool:
    return _s(t.get("stage")) not in tasks.STAGES_CLOSED


def _when_take(t, emp, adm=False) -> bool:
    return _s(t.get("stage")) in (tasks.STAGE_NEW, tasks.STAGE_HOLD)


def _when_hand_over(t, emp, adm=False) -> bool:
    return _s(t.get("stage")) in (tasks.STAGE_NEW, tasks.STAGE_WORK)


def _when_review(t, emp, adm=False) -> bool:
    return _s(t.get("stage")) == tasks.STAGE_REVIEW


def _when_live(t, emp, adm=False) -> bool:
    return _live(t)


def _when_ask_due(t, emp, adm=False) -> bool:
    """Просить інший термін ТОЙ, ХТО ЙОГО ВИКОНУЄ.

    ⭐ Двоє відпадають з РІЗНИХ причин, і плутати їх не можна: постановник
    рухає термін сам (у себе не просять), а спостерігачеві чужий термін не
    болить — кнопка в нього була б шумом."""
    if not _live(t) or tasks.may(t, emp, tasks.ACT_EDIT, adm):
        return False
    return any(r in (tasks.ROLE_ASSIGNEE, tasks.ROLE_CO)
               for r in tasks.roles_of(t, emp))


BUTTONS = (
    {"code": BTN_WORK, "label": "▶️ Взяти в роботу",
     "acts": (tasks.stage_action(tasks.STAGE_WORK),), "when": _when_take},
    {"code": BTN_DONE, "label": "✅ Готово — здаю",
     "acts": (tasks.ACT_RESULT, tasks.stage_action(tasks.STAGE_REVIEW)),
     "when": _when_hand_over},
    {"code": BTN_ACCEPT, "label": "👍 Прийняти",
     "acts": (tasks.stage_action(tasks.STAGE_DONE),), "when": _when_review},
    {"code": BTN_BACK, "label": "↩️ Повернути в роботу",
     "acts": (tasks.stage_action(tasks.STAGE_WORK),), "when": _when_review},
    {"code": BTN_NOTE, "label": "💬 Коментар",
     "acts": (tasks.ACT_COMMENT,), "when": _when_live},
    {"code": BTN_DUE, "label": "📅 Прошу інший термін",
     "acts": (tasks.ACT_COMMENT,), "when": _when_ask_due},
)


def button(code):
    for b in BUTTONS:
        if b["code"] == _s(code):
            return b
    return None


def press_data(code, arg) -> str:
    """Що поїде в телеграм під кнопкою.

    ЗІРКА. Тут немає і не буде імені людини. Хто діє — вирішує ЧАТ, а не вміст
    кнопки: інакше переслане повідомлення стало б чужими руками.

    УВАГА. Другий знак — це НЕ завжди номер задачі: у переходів там номер
    працівника, слово терміну або номер сторінки. Тому він і зветься arg.
    """
    return "%s:%s:%s" % (CB_PREFIX, _s(code), _s(arg))


def parse_press(data) -> tuple:
    """Пара (код кнопки, аргумент) або дві порожні — без винятків: телеграм
    може принести що завгодно, а бот від чужого рядка падати не сміє."""
    parts = _s(data).split(":")
    if len(parts) != 3 or parts[0] != CB_PREFIX:
        return "", ""
    if not known(parts[1]) or not _s(parts[2]):
        return "", ""
    return parts[1], _s(parts[2])


# ---------------------------------------------------------------------------
# ВЛАСНИЙ ВХІД У БОТА (09.08.2026, питання Андрія після живого прогону)
#
# КОРІНЬ. Бот умів лише ВІДПОВІДАТИ на власні повідомлення. Поки задача одна,
# це терпимо: свіже повідомлення про неї несе пульт. Але щойно задач стає
# кілька, єдиний шлях до потрібної — ГОРТАТИ ЧАТ. А поставити задачу з телефона
# було неможливо взагалі.
#
# ЗАКОН: ЗДАТНІСТЬ, ДО ЯКОЇ НЕ ВЕДЕ ЖОДЕН ВХІД, ДЛЯ ЛЮДИНИ НЕ ІСНУЄ — той
# самий, що «екран без кнопки до нього» і «дія без кнопки».
#
# ДВА РЕЄСТРИ, І ЦЕ НАВМИСНО:
#   BUTTONS — ДІЇ над задачею. У кожної є дія з ACTION_ROLES, ворота — права.
#   NAV     — ПЕРЕХОДИ (відкрити задачу, обрати людину, обрати термін). Вони
#             нічого не змінюють, тож місця в ACTION_ROLES не мають і мати не
#             можуть. Але без воріт не лишаються: перехід до задачі питає
#             visible_ids().
# Змішати їх означало б або вигадати фальшиві «права на перехід», або пустити
# кнопку повз реєстр дій. Обидва шляхи ведуть до тихої діри.
# ---------------------------------------------------------------------------
MENU_MY = "Мої задачі"
MENU_NEW = "Поставити задачу"
# ⭐⭐⭐ 648 (26.09.2026): КЛІЄНТ ІЗ ТЕЛЕФОНА. Каспер: «заповнювати картки клієнтів
# через Telegram-бота». Пункт має ДВЕРІ — ті самі, якими клієнта заводить екран:
# кому ці двері зачинені на екрані, тому пункт і не показується (суддя один —
# `access_sections.may`).
MENU_CLIENT = "Новий клієнт"

MENU = (
    {"code": "my", "label": MENU_MY},
    {"code": "new", "label": MENU_NEW},
    {"code": "client", "label": MENU_CLIENT, "door": ("POST", "/api/crm/party_new")},
)

NAV_OPEN = "open"        # відкрити задачу зі списку
NAV_PICK = "pick"        # обрати виконавця у формі
NAV_WHEN = "when"        # обрати термін у формі
NAV_PAGE = "page"        # ще люди
NAV_DROP = "drop"        # скасувати форму
NAV_SKIP = "skip"        # ⭐ 648: пропустити необовʼязковий крок форми клієнта

NAV = (
    {"code": NAV_OPEN}, {"code": NAV_PICK}, {"code": NAV_WHEN},
    {"code": NAV_PAGE}, {"code": NAV_DROP}, {"code": NAV_SKIP},
)

LIST_MAX = 8             # скільки задач показуємо в списку за раз
PEOPLE_PAGE = 8          # скільки людей на сторінці вибору


def nav(code):
    for n in NAV:
        if n["code"] == _s(code):
            return n
    return None


def known(code) -> bool:
    """Чи ця кнопка взагалі наша — дія або перехід."""
    return bool(button(code) or nav(code))


def menu_code(text) -> str:
    """Текст кнопки меню -> код, або порожньо. Меню шле ЗВИЧАЙНИЙ текст, тож
    впізнавати його треба тут, а не «якщо» у трьох місцях."""
    t = _s(text)
    for m in MENU:
        if t == m["label"]:
            return m["code"]
    return ""


def menu_allowed(item, acc) -> bool:
    """Чи бачить ця людина цей пункт меню. Пункт без дверей — для всіх
    привʼязаних; пункт із дверима — рівно тоді, коли ці двері відчинені їй на
    ЕКРАНІ. Суддя той самий (`access_sections.may`), другого немає."""
    door = (item or {}).get("door")
    if not door:
        return True
    try:
        import access_sections as _sec648
        return bool(_sec648.may(acc, door[0], door[1]))
    except Exception:
        return False                      # «не знаю» на замку означає «ні»


def menu_markup(acc=None) -> dict:
    """Постійні кнопки під полем вводу. Це і є власний вхід: людина відкриває
    чат і бачить, ЩО тут можна, не гортаючи історію.
    ⭐ 648: меню малюється ПІД ЛЮДИНУ — пункт, до дверей якого їй зачинено,
    не показується."""
    return {"keyboard": [[{"text": m["label"]}] for m in MENU if menu_allowed(m, acc)],
            "resize_keyboard": True, "is_persistent": True}


def skip_markup(step) -> dict:
    """Кнопка «Пропустити» під необовʼязковим кроком форми клієнта."""
    return {"inline_keyboard": [[
        {"text": "Пропустити", "callback_data": press_data(NAV_SKIP, step)},
        {"text": "Скасувати", "callback_data": press_data(NAV_DROP, "x")}]]}


def _stage_line(t) -> str:
    st = _s(t.get("stage"))
    out = tasks.STAGE_NAMES.get(st, st)
    due = _s(t.get("due_effective")) or _s(t.get("due_at"))
    if due:
        out += " · до %s" % _human_date(due)
    if t.get("overdue"):
        out += " · ПРОСТРОЧЕНО"
    return out


def my_tasks(emp_id, limit: int = LIST_MAX) -> dict:
    """Живі задачі людини: текст списку плюс кнопки-переходи.

    ЗІРКА. ОБРІЗАННЯ НАЗИВАЄМО ВГОЛОС. Мовчазне «показали перші вісім»
    читається як «оце всі твої задачі» — і людина спокійно проґавить девʼяту.
    """
    emp_id = _s(emp_id)
    live = list(tasks.visible_tasks(emp_id, include_closed=False))
    live.sort(key=lambda t: (not t.get("overdue"),
                             _s(t.get("due_effective")) or "9999",
                             _s(t.get("id"))))
    limit = max(1, int(limit))
    shown = live[:limit]
    if not live:
        return {"text": "У вас немає живих задач.", "markup": None,
                "total": 0, "shown": 0}
    lines = ["Ваші задачі (%d):" % len(live)]
    rows, row = [], []
    for i, t in enumerate(shown, 1):
        lines.append("%d. «%s» · %s" % (i, _cut(t.get("title"), 60), _s(t.get("id"))))
        lines.append("    %s" % _stage_line(t))
        row.append({"text": "%d" % i,
                    "callback_data": press_data(NAV_OPEN, _s(t.get("id")))})
        if len(row) == 4:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    if len(live) > len(shown):
        lines.append("")
        lines.append("Показано %d із %d — решту видно на екрані задач."
                     % (len(shown), len(live)))
    lines.append("")
    lines.append("Натисніть номер, щоб відкрити задачу.")
    return {"text": "\n".join(lines), "markup": {"inline_keyboard": rows},
            "total": len(live), "shown": len(shown)}


def card_text(t, emp_id) -> str:
    """Картка задачі словами — те саме, що людина побачила б на екрані."""
    if not t:
        return ""
    out = ["«%s» · %s" % (_cut(t.get("title"), 120), _s(t.get("id"))),
           _stage_line(t),
           "Постановник: %s" % _name(t.get("author_id")),
           "Виконавець: %s" % _name(t.get("assignee_id"))]
    body = _cut(t.get("description"), 300)
    if body:
        out.append("")
        out.append(body)
    feed = [c for c in (t.get("feed") or []) if c.get("kind") == "comment"]
    if feed:
        last = feed[-1]
        out.append("")
        out.append("Останнє: %s — %s"
                   % (_name(last.get("author_id")), _cut(last.get("text"), 200)))
    role = tasks.role_of(t, _s(emp_id))
    if role:
        out.append("")
        out.append("Ви тут — %s." % tasks.ROLE_NAMES.get(role, role))
    return "\n".join(out)


def people_page(page: int = 0) -> dict:
    """Кнопки з іменами для вибору виконавця.

    ЗІРКА. ЧОМУ КНОПКИ, А НЕ ПОШУК ЗА ЛІТЕРАМИ. Правило звуження (збіг із
    ПОЧАТКОМ слова, підрядок — друга лінія) живе в ui/taskdesk.js. Написати
    його ще й тут означало б ДВА ПИСАРІ ОДНІЄЇ ПРАВДИ: варто їм розійтись — і
    той самий набір літер дає різних людей на екрані й у телефоні.
    """
    who = [e for e in people.employees() if people.can_receive_tasks(e["id"])]
    who.sort(key=lambda e: _s(e.get("full_name")))
    page = max(0, int(page))
    start = page * PEOPLE_PAGE
    chunk = who[start:start + PEOPLE_PAGE]
    rows, row = [], []
    for e in chunk:
        row.append({"text": _cut(e.get("full_name"), 30),
                    "callback_data": press_data(NAV_PICK, e["id"])})
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    tail = []
    if page > 0:
        tail.append({"text": "Назад", "callback_data": press_data(NAV_PAGE, page - 1)})
    if start + PEOPLE_PAGE < len(who):
        tail.append({"text": "Ще", "callback_data": press_data(NAV_PAGE, page + 1)})
    if tail:
        rows.append(tail)
    rows.append([{"text": "Скасувати", "callback_data": press_data(NAV_DROP, "new")}])
    return {"markup": {"inline_keyboard": rows},
            "total": len(who), "shown": len(chunk), "page": page}


def when_markup() -> dict:
    """Термін у два дотики. Дату руками теж приймаємо — окремим писарем."""
    return {"inline_keyboard": [
        [{"text": "Сьогодні", "callback_data": press_data(NAV_WHEN, "today")},
         {"text": "Завтра", "callback_data": press_data(NAV_WHEN, "tomorrow")}],
        [{"text": "Через тиждень", "callback_data": press_data(NAV_WHEN, "week")},
         {"text": "Без терміну", "callback_data": press_data(NAV_WHEN, "none")}],
        [{"text": "Скасувати", "callback_data": press_data(NAV_DROP, "new")}],
    ]}


def buttons_for(t, emp_id, is_admin: bool = False) -> list:
    """ЄДИНА відповідь «які кнопки бачить ЦЯ людина під ЦІЄЮ задачею».

    ⭐⭐⭐ Це й ворота: її питають ДВІЧІ — коли кнопку МАЛЮЮТЬ і коли на
    неї НАТИСНУЛИ. Тому кнопка зі старого повідомлення не може зробити
    того, чого людині вже не можна."""
    emp_id = _s(emp_id)
    if not t or not emp_id:
        return []
    out = []
    for b in BUTTONS:
        if not all(tasks.may(t, emp_id, a, is_admin) for a in b["acts"]):
            continue
        if not b["when"](t, emp_id, is_admin):
            continue
        out.append(b)
    return out


def markup_for_task(t, emp_id, is_admin: bool = False):
    """Кнопки, можливі ЗАРАЗ, або None.

    ⭐⭐⭐ ОДИН БУДІВНИЧИЙ РОЗМІТКИ НА ВЕСЬ КАНАЛ. Її будують ДВІЧІ: коли
    повідомлення надсилають і коли його ПЕРЕМАЛЬОВУЮТЬ після натискання.
    Якби це були два місця, старе повідомлення показувало б інше, ніж нове."""
    if not t:
        return None
    tid = _s(t.get("id"))
    btns = buttons_for(t, emp_id, is_admin) if tid else []
    if not btns:
        return None
    rows, row = [], []
    for b in btns:
        row.append({"text": b["label"], "callback_data": press_data(b["code"], tid)})
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    return {"inline_keyboard": rows}


def markup_for(group, emp_id, is_admin: bool = False):
    """Кнопки під повідомленням про подію або None.

    ⭐⭐⭐ КНОПКИ ПЕРСОНАЛЬНІ, ХОЧ ТЕКСТ СПІЛЬНИЙ. Одна й та сама подія
    йде кільком людям, але постановник бачить «Прийняти», а виконавець —
    «Готово». Саме тому розмітка рахується НА КОЖНОГО АДРЕСАТА, а не
    одного разу на групу подій."""
    group = [g for g in (group or []) if isinstance(g, dict)]
    if not group:
        return None
    tid = _s(group[0].get("task_id"))
    if not tid:
        return None
    try:
        t = tasks.task(tid)
    except Exception:
        return None          # задачі вже немає — текст йде, кнопки ні
    return markup_for_task(t, emp_id, is_admin)


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ХТО ПРО ЦЕ ДІЗНАЄТЬСЯ — І ХТО НІ, З ПРИЧИНОЮ
#
# КОРІНЬ (живий випадок 09.08.2026). Андрій поставив задачу САМ СОБІ й чекав
# повідомлення в телеграм. Не прийшло нічого — бо платформа собі не пише. Закон
# правильний: людина щойно натиснула «Поставити» й дивиться на екран. АЛЕ ЕКРАН
# ПРО ЦЕ НЕ СКАЗАВ ЖОДНОГО СЛОВА, і розумна дія обернулась тишею, яку неможливо
# відрізнити від поламаного бота.
#
# ⭐⭐⭐ ЦЕ КЛАС, А НЕ ВИПАДОК. Платформа мовчить із ТРЬОХ різних причин, і про
# жодну не казала: (1) це ви самі; (2) людина не підключила телеграм; (3) бота
# задач у клієнта немає взагалі (закритий контур). Друга — найдорожча: ставиш
# задачу людині без телеграма і ЩИРО думаєш, що вона її отримала.
#
# ⭐ ОДИН ПИСАР ЦІЄЇ ВІДПОВІДІ. Її питають екран створення й картка задачі —
# і жоден із них не рахує сам, інакше на двох екранах стояла б різна правда.
# ---------------------------------------------------------------------------
SILENT_SELF = "self"
SILENT_NO_CHAT = "no_chat"
SILENT_NO_MOUTH = "no_mouth"

SILENT_WHY = {
    SILENT_SELF: "про власні дії платформа не пише",
    SILENT_NO_CHAT: "не підключив телеграм",
    SILENT_NO_MOUTH: "бот задач не заведений",
}


def reach(t, actor_id, kind: str = None) -> dict:
    """Хто дізнається про зміни в ЦІЙ задачі, а хто ні і ЧОМУ.

    ⚠ Людину, якій ця роль про такі зміни й не належить чути (спостерігач і
    коментарі), сюди НЕ пишемо: це не тиша, а межа ролі — про неї бреше вже
    сама згадка."""
    kind = _s(kind) or events.KIND_CREATED
    actor_id = _s(actor_id)
    on = enabled()
    allowed = tasks.KIND_ROLES.get(kind, ())
    hear, silent = [], []
    for emp in tasks.participants(t or {}):
        who = {"id": emp, "name": _name(emp)}
        if emp == actor_id:
            silent.append(dict(who, why=SILENT_SELF))
            continue
        if not any(r in allowed for r in tasks.roles_of(t, emp)):
            continue
        if not on:
            silent.append(dict(who, why=SILENT_NO_MOUTH))
        elif not chat_of(emp):
            silent.append(dict(who, why=SILENT_NO_CHAT))
        else:
            hear.append(who)
    return {"mouth": on, "hear": hear, "silent": silent,
            "note": _reach_note(on, hear, silent)}


def _reach_note(on, hear, silent) -> str:
    """Той самий факт — людськими словами. Один рядок, який читає людина одразу
    після «Поставити»: саме там її і спіткала тиша."""
    mute = [x for x in silent if x["why"] != SILENT_SELF]
    me = [x for x in silent if x["why"] == SILENT_SELF]
    if not on:
        out = "Бот задач не заведений, тож у телеграм не піде нікому."
        return out + " Люди побачать задачу лише на екрані."
    parts = []
    if hear:
        parts.append("У телеграм отримають: %s."
                     % ", ".join(x["name"] for x in hear))
    elif me and not mute:
        return ("У телеграм не піде нікому: у задачі лише ви, а про власні дії "
                "платформа не пише.")
    else:
        parts.append("У телеграм не піде нікому.")
    if mute:
        parts.append("НЕ отримають: %s."
                     % ", ".join("%s (%s)" % (x["name"], SILENT_WHY[x["why"]])
                                 for x in mute))
    if me:
        parts.append("Собі платформа не пише.")
    return " ".join(parts)


# ---------------------------------------------------------------------------
# ДОСТАВКА
# ---------------------------------------------------------------------------
def _send(chat_id, text, markup=None) -> bool:
    import telegram_bot
    return bool(telegram_bot.send_as(ROLE, chat_id, text, markup))


_attempts = {}          # id події -> скільки разів уже пробували (лише в памʼяті)


def deliver(send=None, limit: int = BATCH) -> dict:
    """Донести те, чого рот ще не доніс.

    ⭐ КУРСОР РУХАЄТЬСЯ ЛИШЕ ПІСЛЯ УСПІШНОЇ ДОСТАВКИ І ЛИШЕ ВПЕРЕД. Якщо
    доставка впала — курсор лишається, і наступний захід почне з того самого
    місця. Дубль людині краще за втрату: втрачене повідомлення нічим не видно.

    ⭐ АЛЕ ОДИН ЗАБЛОКОВАНИЙ ЧАТ НЕ СМІЄ ЗУПИНИТИ ВСЮ КОМПАНІЮ. Після
    MAX_ATTEMPTS невдалих спроб подія лишає СЛІД («events_lost.log») і курсор
    іде далі — мовчазної втрати не буває, буває названа."""
    send = send or _send
    events.register(SINK)                 # новий рот не отримує всю історію
    evs = events.pending(SINK, limit)
    stat = {"events": len(evs), "sent": 0, "no_chat": 0, "failed": 0,
            "dropped": 0, "groups": 0, "stopped": ""}
    if not evs:
        return stat
    for g in events.coalesce(evs):
        stat["groups"] += 1
        last_id = max(int(e["id"]) for e in g)
        to = []
        for e in g:
            for emp in (e.get("to") or []):
                if emp not in to:
                    to.append(emp)
        text = text_for(g)
        failed = False
        for emp in to:
            chat = chat_of(emp)
            if not chat:
                stat["no_chat"] += 1
                continue
            try:
                ok = send(chat, text, markup_for(g, emp, admin_of(emp)))
            except Exception as ex:
                ok = False
                sys.stderr.write("[рот] %s: %s\n" % (emp, ex))
            if ok:
                stat["sent"] += 1
            else:
                failed = True
                stat["failed"] += 1
        if not failed:
            _attempts.pop(last_id, None)
            events.ack(SINK, last_id)
            continue
        n = _attempts.get(last_id, 0) + 1
        _attempts[last_id] = n
        if n >= MAX_ATTEMPTS:
            events.lost({"sink": SINK, "event_ids": [int(e["id"]) for e in g],
                         "task_id": _s(g[0].get("task_id")), "to": to},
                        "рот не доніс за %d спроб — подію пропущено" % n)
            _attempts.pop(last_id, None)
            events.ack(SINK, last_id)
            stat["dropped"] += len(g)
            continue
        stat["stopped"] = ("доставка спинилась на події %d (спроба %d з %d)"
                           % (last_id, n, MAX_ATTEMPTS))
        break
    return stat


def snapshot() -> dict:
    """Стан рота одним поглядом — для консолі й для чеків."""
    try:
        pend = len(events.pending(SINK, 10_000))
    except Exception:
        pend = -1
    return {"enabled": enabled(), "sink": SINK, "cursor": events.cursor(SINK),
            "pending": pend, "tick_sec": TICK_SEC}


# ---------------------------------------------------------------------------
# ФОНОВИЙ ЦИКЛ
# ---------------------------------------------------------------------------
_thread = None


def _loop():
    sys.stderr.write("[рот] доставку задач у телеграм запущено (кожні %d с)\n" % TICK_SEC)
    while True:
        try:
            if enabled():
                deliver()
        except Exception as ex:
            # Рот не сміє впасти назовсім: черга лишається на диску, наступний
            # захід спробує знову. Але мовчати теж не сміє.
            sys.stderr.write("[рот] захід не вдався: %s\n" % ex)
        time.sleep(TICK_SEC)


def is_running() -> bool:
    return _thread is not None and _thread.is_alive()


def start_in_background() -> bool:
    """Запускає доставку окремим потоком (ідемпотентно). False — рот вимкнений."""
    global _thread
    if not enabled():
        return False
    if is_running():
        return True
    _thread = threading.Thread(target=_loop, daemon=True, name="taskdesk-telegram")
    _thread.start()
    return True
