# -*- coding: utf-8 -*-
"""mail_intake.py — ПОШТА ЛЯГАЄ В CRM САМА, З БУДЬ-ЯКОЇ СКРИНЬКИ (зміна 648, 26.09.2026).

🩸 ЗАПИТ КАСПЕРА (23.09.2026): «привʼязати пошту до CRM». Розбір коду показав
корінь, глибший за «немає конектора»: у клієнтській платформі вхідна пошта НЕ
ЧИТАЛАСЬ ВЗАГАЛІ. Двері `/api/crm/inbound` уміли розкласти лист (картка, угода за
міткою [SF-D…], черга «Не оброблені», «чий лист»), але живила їх лише ранкова
задача на машині розробника. Єдиний конектор — Gmail через згоду Google у режимі
«Testing», яка вмирає щотижня, а скринька Каспера info@casper.in.ua живе на
хостингу сайту (Fornex), не в Google.

⛒ ХТО ЗНАЄ ПРАВДУ — СКРИНЬКА НА ПОШТОВОМУ СЕРВЕРІ КЛІЄНТА. Мова, якою говорить
будь-який поштовий сервер, — IMAP (RFC 3501): хостинг, Gmail, ukr.net, власний
сервер. Тому платформа сама читає скриньку за розкладом і віддає кожен лист у ТІ
САМІ двері розкладання (`inbound.from_email`) — другого розкладача не заводимо.

⛒ ЗАКОНИ ЦЬОГО МОДУЛЯ:
  1. СКРИНЬКУ КЛІЄНТА НЕ ЗМІНЮЄМО. Лише читання: `SELECT … readonly`, `BODY.PEEK`
     — лист лишається непрочитаним у поштовій програмі людини.
  2. ЛИСТ ЛЯГАЄ РІВНО РАЗ. Водяний знак за номером листа (UID) + памʼять
     Message-ID: і повтор тіку, і перенумерація скриньки сервером (UIDVALIDITY)
     не народжують дубля.
  3. СТАРЕ НЕ ТЯГНЕМО. Від моменту підключення — лише нове (той самий закон, що й
     у `deal_mail`: розбір старого листування заднім числом не робимо).
  4. НЕ КЛІЄНТСЬКЕ НЕ ЛЯГАЄ. Лист від свого працівника, масова розсилка
     (List-Id / List-Unsubscribe, RFC 2369; Precedence: bulk) і автовідповідь
     (Auto-Submitted, RFC 3834) — не звернення клієнта. Це правила самих заголовків
     пошти, а не перелік слів.
  5. ПАРОЛЬ — СЕКРЕТ. Лежить у теці конекторів (вона не їде ні в збірку, ні в
     оновлення, ні в архів даних), ніколи не повертається на екран і не пишеться
     в журнал.
  6. ОДНА СКРИНЬКА НЕ ВАЛИТЬ ІНШІ. Збій сервера, мережі чи пароля — це стан
     скриньки словами на екрані, а не виняток у потоці.
  7. ДОВІРУ ДО СЕРТИФІКАТА ЗНАЄ ОДИН ПИСАР (`netfetch.ssl_context`, урок 623).

Лише stdlib + `config`, `inbound`, `mail_owner`, `netfetch`, `one_writer`.
"""
import email
import email.policy
import email.utils
import imaplib
import re
import socket
import sys
import threading
import time
from datetime import datetime

import config
import one_writer

BOXES_JSON = config.CONNECTORS_DIR / "mailboxes.json"
TICK_MIN = 5                   # як часто платформа заглядає в скриньки
TIMEOUT_S = 25
MAX_PER_TICK = 200             # скільки листів за один захід (перший прихід не душить)
BIG_BYTES = 1_500_000          # лист більший — читаємо заголовки без тіла
PREVIEW_MAX = 600
SEEN_MAX = 3000                # скільки Message-ID памʼятає скринька
FOLDER = "INBOX"

SEC_SSL, SEC_STARTTLS, SEC_PLAIN = "ssl", "starttls", "plain"
_LOCAL_HOSTS = ("127.0.0.1", "localhost", "::1")


class MailboxError(Exception):
    """Відмова словами: що не так і що зробити людині."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def _now() -> str:
    try:
        import clock
        return clock.now()
    except Exception:
        return datetime.now().isoformat(timespec="seconds")


# ── СХОВИЩЕ (ОДИН ПИСАР) ─────────────────────────────────────────────────────
def _load() -> dict:
    try:
        d = one_writer.read_json(BOXES_JSON)
    except PermissionError:
        raise
    except Exception:
        d = {}
    if not isinstance(d, dict):
        d = {}
    d.setdefault("boxes", {})
    d.setdefault("seq", 0)
    return d


def _save(d: dict) -> None:
    BOXES_JSON.parent.mkdir(parents=True, exist_ok=True)
    one_writer.write_json(BOXES_JSON, d)


_PUBLIC = ("id", "address", "owner", "owner_name", "host", "port", "security",
           "enabled", "added", "added_by", "last_ok", "last_error", "last_new",
           "total")


def _public(box: dict) -> dict:
    """Скринька для екрана — БЕЗ пароля й без службових лічильників."""
    out = {k: box.get(k) for k in _PUBLIC}
    out["owner_name"] = _owner_name(_s(box.get("owner")))
    return out


def _owner_name(emp_id: str) -> str:
    if not emp_id:
        return "компанія (спільна)"
    try:
        import taskdesk_people as people
        return _s((people.employee(emp_id) or {}).get("full_name")) or emp_id
    except Exception:
        return emp_id


def boxes() -> list:
    return [_public(b) for b in sorted(_load()["boxes"].values(), key=lambda x: _s(x.get("id")))]


# ── ЗʼЄДНАННЯ ────────────────────────────────────────────────────────────────
def _ssl():
    import netfetch
    return netfetch.ssl_context()


def candidates(address: str, host: str = "", port=None, security: str = "") -> list:
    """Куди стукати. Названий сервер — лише він. Не названий — ПРАВИЛО домену
    (`imap.<домен>`, `mail.<домен>`, сам домен; 993 з шифруванням, потім 143 з
    STARTTLS), а не перелік провайдерів: так знаходяться і Gmail, і ukr.net, і
    хостинг сайту клієнта."""
    if _s(host):
        sec = _s(security) or SEC_SSL
        p = int(port or (993 if sec == SEC_SSL else 143))
        return [(_s(host), p, sec)]
    dom = _s(address).rpartition("@")[2].lower()
    if not dom or "." not in dom:
        raise MailboxError("Адреса «%s» не схожа на пошту." % _s(address))
    hosts = ["imap." + dom, "mail." + dom, dom]
    return ([(h, 993, SEC_SSL) for h in hosts] + [(h, 143, SEC_STARTTLS) for h in hosts[:2]])


def _open(host: str, port: int, security: str):
    if security == SEC_SSL:
        return imaplib.IMAP4_SSL(host, port, ssl_context=_ssl(), timeout=TIMEOUT_S)
    if security == SEC_STARTTLS:
        c = imaplib.IMAP4(host, port, timeout=TIMEOUT_S)
        c.starttls(ssl_context=_ssl())
        return c
    if security == SEC_PLAIN:
        # ⛔ Пароль відкритим текстом — лише до своєї машини (місцевий поштовий
        # перекладач або проба). До чужого сервера — ніколи.
        if host not in _LOCAL_HOSTS:
            raise MailboxError("Без шифрування підключаємось лише до цієї ж машини.")
        return imaplib.IMAP4(host, port, timeout=TIMEOUT_S)
    raise MailboxError("Невідомий спосіб зʼєднання «%s»." % security)


def _human(ex, host: str) -> str:
    """Відмова людською мовою: ЩО сталося і ЩО зробити."""
    t = _s(ex)
    low = t.lower()
    if isinstance(ex, imaplib.IMAP4.error) and ("auth" in low or "login" in low
                                                or "credentials" in low or "invalid" in low
                                                or "password" in low):
        return ("Сервер %s не прийняв пароль. Перевірте пароль скриньки. Для Gmail потрібен "
                "окремий «пароль застосунку» (Google → Безпека → Паролі застосунків)." % host)
    if isinstance(ex, (socket.timeout, TimeoutError)):
        return "Сервер %s не відповів за %d с." % (host, TIMEOUT_S)
    if isinstance(ex, (socket.gaierror,)):
        return "Сервера %s не знайдено в мережі." % host
    try:
        import netfetch
        why = netfetch.explain_ssl_error(ex)
        if why:
            return why
    except Exception:
        pass
    if isinstance(ex, (ConnectionRefusedError, OSError)):
        return "Сервер %s не приймає зʼєднання: %s" % (host, t[:120])
    return "Пошта %s: %s" % (host, t[:160])


def _login(address: str, password: str, host="", port=None, security=""):
    """-> (клієнт, host, port, security). Пробує кандидатів по черзі; пароль,
    який сервер ВІДКИНУВ, далі не носимо по інших серверах."""
    last = ""
    for h, p, sec in candidates(address, host, port, security):
        try:
            c = _open(h, p, sec)
        except MailboxError:
            raise
        except Exception as ex:
            last = _human(ex, h)
            continue
        try:
            c.login(_s(address), password)
            return c, h, p, sec
        except imaplib.IMAP4.error as ex:
            try:
                c.logout()
            except Exception:
                pass
            raise MailboxError(_human(ex, h))
        except Exception as ex:
            last = _human(ex, h)
    raise MailboxError(last or "Поштового сервера для «%s» не знайдено." % address)


def _select(c):
    """Відкрити «Вхідні» ЛИШЕ ДЛЯ ЧИТАННЯ -> (uidvalidity, uidnext)."""
    typ, _ = c.select(FOLDER, readonly=True)
    if typ != "OK":
        raise MailboxError("Сервер не відкрив «Вхідні».")
    vals = c.untagged_responses.get("UIDVALIDITY") or []
    validity = vals[0].decode("ascii", "replace").strip() if vals else ""
    nxt = c.untagged_responses.get("UIDNEXT") or []
    try:
        uidnext = int(nxt[0]) if nxt else 0
    except Exception:
        uidnext = 0
    if not uidnext:
        typ, data = c.uid("SEARCH", None, "ALL")
        ids = [int(x) for x in (data[0] or b"").split()] if typ == "OK" else []
        uidnext = (max(ids) + 1) if ids else 1
    return validity, uidnext


# ── РОЗБІР ЛИСТА ─────────────────────────────────────────────────────────────
def _text_of(msg) -> str:
    part = None
    try:
        part = msg.get_body(preferencelist=("plain", "html"))
    except Exception:
        part = None
    if part is None:
        return ""
    try:
        txt = part.get_content()
    except Exception:
        try:
            txt = (part.get_payload(decode=True) or b"").decode("utf-8", "replace")
        except Exception:
            txt = ""
    if part.get_content_type() == "text/html":
        txt = re.sub(r"(?is)<(script|style).*?</\1>", " ", txt)
        txt = re.sub(r"(?s)<[^>]+>", " ", txt)
    return " ".join(_s(txt).split())[:PREVIEW_MAX]


def not_client_mail(msg) -> str:
    """Причина, чому лист — НЕ звернення клієнта, або порожньо.
    ⛒ Правила самих заголовків пошти (RFC 2369, RFC 3834), а не перелік слів."""
    if msg.get("List-Id") or msg.get("List-Unsubscribe"):
        return "розсилка"
    if _s(msg.get("Precedence")).lower() in ("bulk", "list", "junk"):
        return "масовий лист"
    auto = _s(msg.get("Auto-Submitted")).lower()
    if auto and auto != "no":
        return "автовідповідь"
    return ""


def parse(raw: bytes) -> dict:
    msg = email.message_from_bytes(raw, policy=email.policy.default)
    frm = email.utils.getaddresses([_s(msg.get("From"))])
    name, addr = (frm[0] if frm else ("", ""))
    return {
        "message_id": _s(msg.get("Message-ID")),
        "from": _s(addr).lower(),
        "name": _s(name),
        "to": _s(msg.get("To")),
        "cc": _s(msg.get("Cc")),
        "subject": _s(msg.get("Subject")),
        "preview": _text_of(msg),
        "skip": not_client_mail(msg),
    }


def _staff_address(addr: str) -> bool:
    try:
        import mail_owner
        return bool(mail_owner.employees_at(addr))
    except Exception:
        return False


# ── ПРИЙОМ ───────────────────────────────────────────────────────────────────
def deliver(box: dict, item: dict) -> str:
    """Один лист — у ті самі двері розкладання. -> що з ним сталось (для журналу)."""
    if item.get("skip"):
        return "пропущено: " + item["skip"]
    frm = _s(item.get("from"))
    if not frm:
        return "пропущено: без відправника"
    if frm == _s(box.get("address")).lower() or _staff_address(frm):
        return "пропущено: лист свого працівника"
    # ⛒ ЧИЙ ЛИСТ: особиста скринька працівника — певне джерело (`mail_owner`
    # HOW_BOX), і воно їде до судді окремим полем. Спільна скринька (info@)
    # нічийого не каже — тоді судять «кому», мітка угоди й відповідальний.
    import inbound
    res = inbound.from_email(frm, name=_s(item.get("name")), subject=_s(item.get("subject")),
                             preview=_s(item.get("preview")), to=_s(item.get("to")),
                             cc=_s(item.get("cc")), box_owner=_s(box.get("owner")))
    return "впізнано" if res.get("matched") else "у «Не оброблені»"


_MONTHS = ("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec")


def _imap_day(stamp: str) -> str:
    """ISO-мітка -> день у форматі IMAP («26-Sep-2026»), на день раніше (запас)."""
    from datetime import timedelta
    try:
        d = datetime.fromisoformat(_s(stamp)[:19]) - timedelta(days=1)
    except Exception:
        d = datetime.now() - timedelta(days=2)
    return "%02d-%s-%04d" % (d.day, _MONTHS[d.month - 1], d.year)


def _fetch_new(c, box: dict, resync: bool = False) -> list:
    """Нові листи -> [(uid, item)].
    Звичайно — після водяного знака за номером (UID). Після перенумерації скриньки
    (`resync`) номери нічого не важать: беремо листи від дня останнього заходу, а
    дубль відсікає памʼять Message-ID. Так не губиться лист, що прийшов між
    останнім заходом і перенумерацією."""
    if resync:
        typ, data = c.uid("SEARCH", None, "SINCE", _imap_day(box.get("last_ok")))
        start = 1
    else:
        start = int(box.get("next_uid") or 1)
        typ, data = c.uid("SEARCH", None, "UID", "%d:*" % start)
    if typ != "OK":
        raise MailboxError("Сервер не віддав перелік листів.")
    uids = sorted(int(x) for x in (data[0] or b"").split() if int(x) >= start)
    out = []
    for uid in uids[:MAX_PER_TICK]:
        typ, d = c.uid("FETCH", str(uid), "(RFC822.SIZE INTERNALDATE BODY.PEEK[HEADER])")
        if typ != "OK" or not d or not isinstance(d[0], tuple):
            continue
        size_m = re.search(rb"RFC822\.SIZE (\d+)", d[0][0] or b"")
        raw = d[0][1]
        got_at = 0.0                  # момент приходу на сервер, секунди епохи (UTC)
        try:
            tt = imaplib.Internaldate2tuple(d[0][0])
            if tt:
                got_at = float(time.mktime(tt))
        except Exception:
            got_at = 0.0
        if not size_m or int(size_m.group(1)) <= BIG_BYTES:
            typ2, d2 = c.uid("FETCH", str(uid), "(BODY.PEEK[])")
            if typ2 == "OK" and d2 and isinstance(d2[0], tuple):
                raw = d2[0][1]
        item = parse(raw)
        item["received"] = got_at
        out.append((uid, item))
    return out


@one_writer.guard("MAILBOXES_JSON")
def _store_box(box: dict) -> None:
    d = _load()
    if _s(box.get("id")) in d["boxes"]:
        d["boxes"][_s(box["id"])] = box
        _save(d)


def check(box_id: str, connect=None) -> dict:
    """Один захід у скриньку. -> {"new": n, "done": [..], "error": ""}.
    ⛒ Помилка — стан скриньки СЛОВАМИ, а не виняток: одна скринька не валить інші."""
    d = _load()
    box = dict(d["boxes"].get(_s(box_id)) or {})
    if not box:
        raise MailboxError("Скриньки %s немає." % (_s(box_id) or "«»"))
    out = {"id": box["id"], "new": 0, "done": [], "error": ""}
    c = None
    try:
        if connect:
            c = connect(box)
        else:
            c = _open(_s(box.get("host")), int(box.get("port") or 993), _s(box.get("security")))
            try:
                c.login(_s(box.get("address")), _s(box.get("password")))
            except imaplib.IMAP4.error as ex:
                raise MailboxError(_human(ex, _s(box.get("host"))))
        validity, uidnext = _select(c)
        resync = bool(_s(box.get("uidvalidity")) and validity != _s(box.get("uidvalidity")))
        if resync:
            # Сервер перенумерував листи: старий знак нічого не важить.
            box["next_uid"] = 1
        box["uidvalidity"] = validity
        seen = list(box.get("seen") or [])
        seen_set = set(seen)
        got = _fetch_new(c, box, resync=resync)
        for uid, item in got:
            mid = _s(item.get("message_id")) or ("uid:%s:%s" % (validity, uid))
            if mid in seen_set:
                box["next_uid"] = max(int(box.get("next_uid") or 1), uid + 1)
                continue
            # ⛒ ЗАКОН 3 ДІЄ ЗАВЖДИ, не лише на першому заході: лист, що ПРИЙШОВ
            # НА СЕРВЕР до підключення скриньки, не тягнемо (час приходу —
            # INTERNALDATE сервера, а не дата, яку написав відправник).
            # ⛒ Порівнюємо МОМЕНТИ (секунди епохи), а не рядки часу: сервер пише
            # свій пояс, машина клієнта — свій.
            if item.get("received") and box.get("added_at") and \
                    float(item["received"]) < int(float(box["added_at"])):   # сервер лічить секундами
                seen.append(mid)
                seen_set.add(mid)
                box["next_uid"] = max(int(box.get("next_uid") or 1), uid + 1)
                continue
            try:
                what = deliver(box, item)
            except Exception as ex:
                # ⛒ Лист, який не ліг, НЕ позначаємо прийнятим: наступний захід
                # спробує знову. Знак зупиняється перед ним.
                out["error"] = "Лист від %s не розкладено: %s" % (_s(item.get("from")), _s(ex)[:160])
                break
            seen.append(mid)
            seen_set.add(mid)
            box["next_uid"] = max(int(box.get("next_uid") or 1), uid + 1)
            out["done"].append({"from": item.get("from"), "subject": item.get("subject"), "as": what})
            if not what.startswith("пропущено"):
                out["new"] += 1
        box["seen"] = seen[-SEEN_MAX:]
        box["last_ok"] = _now()
        box["last_error"] = out["error"]
        box["last_new"] = out["new"]
        box["total"] = int(box.get("total") or 0) + out["new"]
    except MailboxError as ex:
        out["error"] = _s(ex)
        box["last_error"] = out["error"]
    except Exception as ex:
        out["error"] = _human(ex, _s(box.get("host")))
        box["last_error"] = out["error"]
    finally:
        if c is not None:
            try:
                c.logout()
            except Exception:
                pass
    _store_box(box)
    return out


# ── ПІДКЛЮЧИТИ / ПРИБРАТИ ────────────────────────────────────────────────────
@one_writer.guard("MAILBOXES_JSON")
def _put_new(box: dict) -> dict:
    d = _load()
    for b in d["boxes"].values():
        if _s(b.get("address")).lower() == _s(box["address"]).lower():
            raise MailboxError("Скринька %s уже підключена." % box["address"])
    d["seq"] = int(d.get("seq") or 0) + 1
    box["id"] = "mb%03d" % d["seq"]
    d["boxes"][box["id"]] = box
    _save(d)
    return box


def add(address: str, password: str, owner: str = "", host: str = "", port=None,
        security: str = "", by: str = "", connect=None) -> dict:
    """Підключити скриньку. Спершу ПЕРЕВІРЯЄМО вхід, потім зберігаємо: скринька,
    що не відкривається, у переліку — це обіцянка, яку ніхто не виконає.
    Водяний знак ставиться на «зараз» — старе листування не тягнемо (закон 3)."""
    address, password = _s(address).lower(), _s(password)
    if "@" not in address:
        raise MailboxError("Впишіть адресу скриньки повністю, наприклад info@firma.ua.")
    if not password:
        raise MailboxError("Потрібен пароль скриньки.")
    if _s(owner):
        try:
            import taskdesk_people as people
            if not people.employee(_s(owner)):
                raise MailboxError("Працівника %s немає." % _s(owner))
        except MailboxError:
            raise
        except Exception:
            pass
    if connect:                       # проба підставляє свій сервер
        c = connect({"address": address, "password": password})
        h, p, sec = _s(host), int(port or 0), _s(security)
    else:
        c, h, p, sec = _login(address, password, host, port, security)
    try:
        validity, uidnext = _select(c)
    finally:
        try:
            c.logout()
        except Exception:
            pass
    box = {"address": address, "password": password, "owner": _s(owner),
           "host": h, "port": p, "security": sec, "enabled": True,
           "uidvalidity": validity, "next_uid": uidnext, "seen": [],
           "added": _now(), "added_at": time.time(), "added_by": _s(by),
           "last_ok": _now(), "last_error": "",
           "last_new": 0, "total": 0}
    box = _put_new(box)
    _trace("підключено скриньку %s (%s)" % (address, _owner_name(_s(owner))))
    return _public(box)


@one_writer.guard("MAILBOXES_JSON")
def remove(box_id: str, by: str = "") -> bool:
    d = _load()
    box = d["boxes"].pop(_s(box_id), None)
    if not box:
        raise MailboxError("Скриньки %s немає." % (_s(box_id) or "«»"))
    _save(d)
    _trace("відключено скриньку %s" % _s(box.get("address")))
    return True


def tick(connect=None) -> list:
    out = []
    for bid, b in sorted(_load()["boxes"].items()):
        if not b.get("enabled"):
            continue
        try:
            out.append(check(bid, connect=connect))
        except Exception as ex:
            out.append({"id": bid, "new": 0, "done": [], "error": _s(ex)})
    return out


def _trace(note: str) -> None:
    """Слід у загальному журналі — без пароля за побудовою (його тут немає)."""
    try:
        sys.stderr.write("[пошта] %s\n" % note)
    except Exception:
        pass


# ── ПОТІК ────────────────────────────────────────────────────────────────────
_RUN = {"on": False}


def loop() -> None:
    if _RUN["on"]:
        return
    _RUN["on"] = True
    time.sleep(20)
    while True:
        try:
            for r in tick():
                if r.get("new") or r.get("error"):
                    _trace("%s: нових %d%s" % (r.get("id"), r.get("new") or 0,
                                              ("; " + r["error"]) if r.get("error") else ""))
        except Exception as ex:
            _trace("захід не вдався: %s" % ex)
        time.sleep(TICK_MIN * 60)


def start_in_background() -> bool:
    t = threading.Thread(target=loop, name="mail_intake", daemon=True)
    t.start()
    return True
