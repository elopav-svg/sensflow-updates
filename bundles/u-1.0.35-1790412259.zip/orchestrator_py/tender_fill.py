# -*- coding: utf-8 -*-
"""
tender_fill.py — ТЕКСТ ДОВІДКИ ЗАМОВЛЯЄ ПЛАТФОРМА (12.08.2026, зміна 159).

КОРІНЬ, ЯКИЙ ТУТ ЗАКРИТО. Живий прогін 12.08 віддав клієнту чистий склад пакета —
19 позицій, усі документи — і ПОРОЖНІ бланки замість довідок: шапка, «Цим
підтверджуємо: ______» і обіцянка «текст довідки — нижче», під якою нічого немає.

Було так: кістяк пакета складав КОД, а окремо від нього агент-складач писав СВІЙ
власний пакет своїми заголовками. Далі `tender_skeleton.merge_model_text`
намагався одружити два незалежні документи, шукаючи розділ моделі за ПЕРШИМИ 32
ЗНАКАМИ назви пункту замовника, і чіпляв знайдене хвостом. Проба (зміна 159)
показала два факти:
  1) модель називає свої розділи СВОЇМИ словами — доїхало 0 з 5;
  2) навіть при ДОСЛІВНОМУ збігу назв текст падав у хвостовий розділ, а всі 5
     файлів довідок клієнта лишались порожніми. Тобто злиття за назвою не було
     «недопрацьованим» — воно НЕ МОЖЕ наповнити довідку.

РІШЕННЯ АРХІТЕКТУРНЕ. Ніякого вгадування: платформа сама ЗАМОВЛЯЄ текст кожної
довідки окремим запитом («одна довідка — один запит») і сама кладе відповідь
УСЕРЕДИНУ свого розділу. Ключ звірки — не буква назви, а той самий рядок
переліку, за яким будувався розділ. Модель більше не вирішує, куди подіти текст.

ЧОГО ЦЕЙ МОДУЛЬ НЕ РОБИТЬ. Не вигадує фактів (лише те, що є в матеріалах
замовника й у реквізитах клієнта; чого немає — порожня графа `______`), не
тлумачить закон, не ходить у мережу, не малює шапку й підпис — їх пише
`tender_skeleton`. І не мовчить: чого не склали — названо викликачеві.
"""

import re

import config
import llm
import tender_skeleton as _ts

# Скільки знаків уважаємо ТЕКСТОМ, а не відлунням шапки. Коротша відповідь —
# це «модель не написала», і людина мусить це БАЧИТИ, а не здогадуватись.
MIN_BODY = 120
# Скільки знаків матеріалу замовника даємо на одну довідку. Стеля — щоб не
# платити за весь пакет документів у кожному з N запитів.
CTX_CHARS = 1600
MAX_TOKENS = 2000

# 🩸 ЦЕЙ ТЕКСТ ЇДЕ В ТЕНДЕР КЛІЄНТА. Слово Андрія 12.08.2026: «економія на
# тендерній системі може вистрелити втратами під час торгів». Тому довідки пише
# сильна модель (мозок), а не дешевий виконавець. Одна точка рішення — тут.
def _model_first() -> str:
    return config.brain_model()


def _model_retry() -> str:
    """Друга спроба — надійною моделлю, якщо вона інша."""
    try:
        rel = config.reliable_model()
    except Exception:
        rel = ""
    return rel or _model_first()


SYSTEM = (
    "Ти складаєш ТЕКСТ ОДНІЄЇ довідки для тендерної пропозиції учасника в Україні.\n"
    "ВІДДАЙ ЛИШЕ ТЕКСТ ДОВІДКИ — без шапки з реквізитами, без слова «ДОВІДКА» "
    "заголовком, без підпису директора: їх додає платформа сама.\n"
    "ПРАВИЛА:\n"
    "- Пиши від імені учасника, офіційно, по суті вимоги замовника.\n"
    "- Назви номер закупівлі і предмет — за ними замовник упізнає папір.\n"
    "- Жодних вигаданих фактів: числа, дати, назви договорів, суми, адреси бери "
    "ЛИШЕ з наданих матеріалів. Чого немає — постав порожню графу ______ .\n"
    "- Не пиши «текст буде нижче», «зразок», «шаблон», «заповніть самі».\n"
    "- Тільки українська мова, тільки кирилиця.\n"
    "- Жодних заголовків Markdown (#, ##, ###) і жодних таблиць — це тіло документа.\n"
    "- Вихідний номер і дату листа, адресата, реквізити учасника і підпис НЕ пиши: "
    "їх ставить платформа.\n"
    "- Номер закупівлі пиши ЛИШЕ такий, як дано нижче, символ у символ.\n"
    "- Коротко, як досвідчений тендерист: суть у 3-5 реченнях. Якщо вимога передбачає "
    "перелік — звичайні пункти через дефіс."
)


def slots(checklist, makers=None) -> list:
    """Позиції пакета, текст яких складає ПЛАТФОРМА (виробник — «система»).

    Порядок і сам рядок переліку зберігаємо БЕЗ ЗМІН: саме цей рядок буде ключем,
    за яким код покладе текст у свій розділ."""
    out = []
    for it in (checklist or []):
        if not str(it).strip():
            continue
        if _ts.not_needed_of(it, makers):
            continue                           # 644: умова учасника не стосується — не пишемо
        if ((makers or {}).get("letter_body") or {}).get(it):
            continue                           # 644: лист-роз’яснення вже склав код ($0)
        if _ts.who_makes(it, makers) == "система":
            _nm = _ts._clean(it)
            if _ts._is_letter_alt(it, makers):  # 644: замість паперу — лист-роз’яснення
                _nm = "Лист-роз’яснення про підстави ненадання документа «%s»" % _nm
            out.append({"item": it, "name": _nm,
                        "basis": _ts.requirement_text(it, makers)})   # 641: дослівно
    return out


def _context_for(name: str, material: str) -> str:
    """Витяг із матеріалів замовника ПРО ЦЮ вимогу. Стеля — щоб не платити за
    весь пакет у кожному запиті. Не знайшли — краще нічого, ніж випадковий зріз."""
    mat = str(material or "")
    if not mat.strip():
        return ""
    low = mat.lower()
    key = (name or "").lower()[:24].strip()
    pos = low.find(key) if len(key) >= 8 else -1
    if pos < 0:
        words = sorted([w for w in re.findall(r"[а-яіїєґА-ЯІЇЄҐ]{7,}", name or "")],
                       key=len, reverse=True)
        for w in words[:3]:
            pos = low.find(w.lower())
            if pos >= 0:
                break
    if pos < 0:
        return ""
    half = CTX_CHARS // 2
    return mat[max(0, pos - half):pos + half].strip()


def _sanitize(text: str) -> str:
    """Текст моделі — це ТІЛО документа, а не другий пакет.

    Заголовок Markdown усередині тіла розрізав би пакет на файли по чужій межі
    (`tender_skeleton.split_documents` ріже по «## »), тому будь-який заголовок
    робимо звичайним жирним рядком. Так само прибираємо службові обгортки."""
    t = str(text or "").replace("\r\n", "\n").strip()
    t = re.sub(r"^```[a-zA-Z]*\s*|\s*```$", "", t).strip()
    lines = []
    for ln in t.split("\n"):
        m = re.match(r"^\s{0,3}#{1,6}\s+(.+?)\s*$", ln)
        if m:
            body = m.group(1).strip()
            lines.append("**%s**" % body if body else "")
            continue
        lines.append(ln)
    t = "\n".join(lines).strip()
    # Модель іноді все ж домальовує підпис — його пише платформа, двох не буває.
    t = re.sub(r"\n+\s*(Директор|Керівник)\b[^\n]*_{5,}[^\n]*$", "", t).strip()
    return _drop_code_owned(t)


# ⭐⭐⭐ 24.09.2026, зміна 636 (клас Б). РЕКВІЗИТИ ЛИСТА — ЗА КОДОМ, НЕ ЗА МОДЕЛЛЮ.
# 🩸 Каспер: модель писала свій «Вих. №», свого адресата, свій підпис і прочерки
# на місці директора — поверх того, що код уже знав. Номер, дату, адресата,
# реквізити й підпис ставить `tender_skeleton`; з тексту моделі вони вирізаються,
# хоч би як модель їх написала. Лишається СУТЬ.
_OWNED_HEAD = re.compile(r"^\s*(?:\*\*)?\s*(?:вих\.?\s*№|вих\.\s*номер|відповідальній\s+особі"
                         r"|код\s+єдрпоу|єдрпоу\b|адреса\s*:|тел\.?\s*:|e-?mail\s*:)", re.I)
_OWNED_SIGN = re.compile(r"^\s*(?:\*\*)?\s*(?:генеральний\s+директор|директор|керівник"
                         r"|уповноважена\s+особа|з\s+повагою|м\.\s*п\.)\b", re.I)


def _drop_code_owned(text: str) -> str:
    rows = str(text or "").split("\n")
    out, skip_next = [], False
    for ln in rows:
        s = ln.strip()
        if skip_next:
            skip_next = False
            if s and s[:1].islower():
                continue                      # продовження адресата: «військової частини …»
        if _OWNED_HEAD.match(s):
            skip_next = s.lower().startswith("відповідальній особі")
            continue
        out.append(ln)
    while out and (not out[-1].strip() or _OWNED_SIGN.match(out[-1].strip())):
        out.pop()
    return "\n".join(out).strip()


def _offer_line(facts: dict) -> str:
    """Товар у листах — за рішенням людини (зміна 636, клас Г), а не з назви закупівлі."""
    off = (facts or {}).get("offer") or {}
    mode = off.get("mode") or ""
    if mode == "own":
        name = str((off.get("product") or {}).get("name") or "").strip()
        return ("%s — власний товар учасника, еквівалент товару з оголошення" % name) if name \
            else "власний товар учасника (назва — ______)"
    if mode == "named":
        return "товар, названий в оголошенні: %s" % ((facts or {}).get("subject") or "______")
    return "______ (учасник вкаже сам; НЕ називай товар з оголошення як товар учасника)"


# ⭐⭐⭐ 24.09.2026, зміна 639. НАЗВА ЗАКУПІВЛІ НЕ СТАЄ НАЗВОЮ НАШОГО ТОВАРУ.
# 🩸 Каспер, живий прогін 638: людина відповіла «свій аналог», назви не дала — а
# модель написала «гарантує, що товар – маскувальний костюм LAPA-Gear Ghilli V6 …
# є власного виробництва учасника». Прохання в рядку про товар («НЕ називай товар
# з оголошення») модель прочитала поряд із рядком «ПРЕДМЕТ ЗАКУПІВЛІ: …LAPA…» — і
# взяла назву звідти. Прохання — не ворота.
# ⛒ ЗАКОН: коли людина НЕ обрала «названий у тендері», модель назви предмета НЕ
# БАЧИТЬ — ні в рядку предмета, ні у фрагменті документації: замість неї стоїть
# позначка. Назву вставляє КОД, і лише там, де йдеться про предмет закупівлі
# («на предмет закупівлі «…»»). Позначка в ролі товару учасника — не текст:
# повтор надійнішою моделлю, потім код ставить на це місце товар учасника
# (його назву або прочерк). Назва конкурента в ролі «нашого» не проходить ніколи.
SUBJ_MARK = "[ПРЕДМЕТ ЗАКУПІВЛІ]"
_MARK_RE = re.compile(r"«?" + re.escape(SUBJ_MARK) + r"»?")
_SUBJ_CTX = re.compile(r"(?:предмет\w*|закупівл\w*|оголошен\w*)(?:(?!товар|продукц|виріб)[^.;,\n]){0,30}$",
                       re.I)


def _masked_subject(facts: dict) -> bool:
    """Маскуємо, коли людина НЕ обрала «названий» і в назві Є марка чи модель.
    Родова назва («Антитепловізорні пончо») — це вид товару, а не чужа марка:
    її модель бачить, як і раніше (без неї в довідці стояло «предмет: ______»)."""
    return ((facts or {}).get("offer") or {}).get("mode") != "named" \
        and bool(_brand_tokens((facts or {}).get("subject") or ""))


def _brand_tokens(subject: str) -> list:
    """Слова назви, які впізнають ЧУЖИЙ товар: латиниця, цифри («LAPA-Gear», «V6»)."""
    return [w for w in re.findall(r"[\w\-]+", str(subject or ""))
            if re.search(r"[A-Za-z0-9]", w) and len(w) >= 2]


def _mask(text: str, subject: str) -> str:
    t = str(text or "")
    if subject:
        t = re.sub(re.escape(subject), SUBJ_MARK, t, flags=re.I)
        for w in sorted(_brand_tokens(subject), key=len, reverse=True):
            t = re.sub(r"(?<![\w\-])" + re.escape(w) + r"(?![\w\-])", SUBJ_MARK, t, flags=re.I)
    return t


def _misused_marks(body: str, subject: str) -> list:
    """Позначки й слова чужої назви, які стоять НЕ в ролі предмета закупівлі."""
    bad = []
    for m in _MARK_RE.finditer(body):
        if not _SUBJ_CTX.search(body[max(0, m.start() - 60):m.start()]):
            bad.append(m)
    low = body.replace(SUBJ_MARK, "")
    for w in _brand_tokens(subject):
        if re.search(r"(?<![\w\-])" + re.escape(w) + r"(?![\w\-])", low, re.I):
            bad.append(w)
    return bad


def _unmask(body: str, facts: dict) -> str:
    """Позначка -> «назва закупівлі» там, де вона предмет; товар учасника — там, де ні."""
    subject = str((facts or {}).get("subject") or "").strip()
    off = (facts or {}).get("offer") or {}
    ours = str((off.get("product") or {}).get("name") or "").strip() or "______"
    t = str(body or "")
    # 1) чужа назва, яку модель знала сама (не з позначки), — на місце нашого товару
    for w in sorted(_brand_tokens(subject), key=len, reverse=True):
        t = re.sub(r"(?<![\w\-])" + re.escape(w) + r"(?![\w\-])", ours, t, flags=re.I)
    # 2) позначка: предмет закупівлі — у лапках; у ролі товару — наш товар
    out, pos = [], 0
    for m in _MARK_RE.finditer(t):
        out.append(t[pos:m.start()])
        out.append(("«%s»" % subject) if _SUBJ_CTX.search(t[max(0, m.start() - 60):m.start()])
                   else ours)
        pos = m.end()
    out.append(t[pos:])
    return "".join(out)


def _one(slot: dict, facts: dict, req: dict, material: str, complete=None) -> dict:
    """Одна довідка — один запит. Порожня або надто коротка відповідь — не текст:
    один повтор надійнішою моделлю, і лише тоді чесне «не склали»."""
    _c = complete or llm.complete
    # ⭐ 640: сира відповідь моделі — на стрічку (наживо) / зі стрічки (офлайн).
    import tender_tape as _tt
    _c = _tt.wrap_call("body", slot.get("name") or "", _c)
    tender = (facts or {}).get("tender_id") or ""
    subject = (facts or {}).get("subject") or ""
    name = (req or {}).get("name") or ""
    edrpou = (req or {}).get("edrpou") or ""
    ctx = _context_for(slot.get("name") or "", material)
    _mask_on = _masked_subject(facts)
    if _mask_on:                                     # 639: назви предмета модель не бачить
        ctx = _mask(ctx, subject)
    user = "\n".join([
        "ВИМОГА ЗАМОВНИКА (назва документа): %s" % (slot.get("name") or ""),
        "ПІДСТАВА ВИМОГИ: %s" % (slot.get("basis") or "перелік оголошення"),
        "НОМЕР ЗАКУПІВЛІ: %s" % (tender or "______"),
        "ПРЕДМЕТ ЗАКУПІВЛІ: %s" % ((SUBJ_MARK if _mask_on else subject) or "______"),
        ("(позначку %s пиши лише там, де йдеться про предмет закупівлі — «на предмет "
         "закупівлі %s»; назву вставить платформа. Це НЕ назва товару учасника.)"
         % (SUBJ_MARK, SUBJ_MARK)) if _mask_on else "",
        "УЧАСНИК: %s" % (name or "______"),
        "КОД ЄДРПОУ УЧАСНИКА: %s" % (edrpou or "______"),
        "ПІДПИСАНТ: %s %s" % ((req or {}).get("director_post") or "",
                               (req or {}).get("director") or "______"),
        "АДРЕСА УЧАСНИКА: %s" % ((req or {}).get("address") or "______"),
        "ПОДАТКОВИЙ СТАТУС: %s" % ((req or {}).get("tax_status") or "______"),
        "ТОВАР, ЯКИЙ ПРОПОНУЄ УЧАСНИК: %s" % _offer_line(facts),
        "",
        ("ФРАГМЕНТ ДОКУМЕНТІВ ЗАМОВНИКА ПРО ЦЮ ВИМОГУ:\n" + ctx) if ctx else
        "ФРАГМЕНТ ДОКУМЕНТІВ ЗАМОВНИКА: не знайдено — пиши строго за назвою вимоги.",
        "",
        "Віддай лише текст довідки.",
    ])
    tries = []
    _last_bad = ""
    for mdl in (_model_first(), _model_retry()):
        try:
            got = _sanitize(_c(SYSTEM, user, temperature=0.2, max_tokens=MAX_TOKENS,
                               model=mdl))
        except Exception as e:
            tries.append("%s: %s" % (mdl, e))
            continue
        # ⭐ зміна 636: чужий номер закупівлі в тексті — не текст цього пакета
        # (🩸 Каспер: UA-2022-… замість UA-2026-…). Повтор, потім чесне «не склали».
        _alien = [m for m in re.findall(r"UA-\d{4}-\d{2}-\d{2}-\d{6}-[A-Za-zА-Яа-я]", got)
                  if tender and m.upper() != str(tender).upper()]   # регістр літери — не спотворення
        if _alien:
            tries.append("%s: чужий номер закупівлі %s" % (mdl, _alien[0]))
            continue
        if _mask_on and _misused_marks(got, subject):
            tries.append("%s: назву закупівлі подано як товар учасника" % mdl)
            _last_bad = got
            continue
        if len(got) >= MIN_BODY:
            return {"body": _unmask(got, facts) if _mask_on else got, "model": mdl, "why": ""}
        tries.append("%s: коротка відповідь (%d знаків)" % (mdl, len(got)))
    if _last_bad and len(_last_bad) >= MIN_BODY:
        # Обидві спроби поставили назву закупівлі на місце нашого товару: код ставить
        # туди товар учасника (назву або прочерк), а предмет лишає предметом.
        return {"body": _unmask(_last_bad, facts), "model": "код", "why": ""}
    return {"body": "", "model": "", "why": "; ".join(tries)[:300]}


def compose(slots_list, facts: dict = None, req: dict = None, material: str = "",
            complete=None) -> dict:
    """ТЕКСТ УСІХ ДОВІДОК ПАКЕТА.

    -> {"bodies": {рядок переліку: текст}, "asked": n, "done": n,
        "missing": [назви], "why": {назва: причина}}
    Ключ `bodies` — САМ РЯДОК ПЕРЕЛІКУ, а не його перші знаки: код кладе текст
    туди, звідки взяв назву, і вгадувати нічого не треба."""
    out = {"bodies": {}, "asked": 0, "done": 0, "missing": [], "why": {}}
    for slot in (slots_list or []):
        out["asked"] += 1
        r = _one(slot, facts or {}, req or {}, material, complete=complete)
        if r["body"]:
            out["bodies"][slot["item"]] = r["body"]
            out["done"] += 1
        else:
            out["missing"].append(slot["name"])
            out["why"][slot["name"]] = r["why"] or "модель не віддала тексту"
    return out


# ⭐⭐⭐ 639: ДОВІДКА «ЗА ФОРМОЮ N» ЗАМОВНИКА — ЦЕ ЙОГО ТЕКСТ З НАШОЮ НАЗВОЮ, А НЕ ТВІР
# МОДЕЛІ (див. `tender_pack.customer_form_text`). Код, $0, дослівно.
_FORM_REF = re.compile(r"(?:відповідн\w*|згідно|за)\s+(?:з\s+|із\s+)?форм\w*\s*№?\s*(\d{1,2})", re.I)
_NAME_BLANK = re.compile(r"_{3,}\s*\(\s*(?:повн\w+\s+)?(?:назв\w*|найменуванн\w*)\s+учасника\s*\)", re.I)


# ⭐ 640: НАЗВА УЧАСНИКА В ГРАФАХ ФОРМИ — КОРОТКА. 🩸 639б, Форма 2 Каспера: «у
# ТОВАРИСТВО З ОБМЕЖЕНОЮ ВІДПОВІДАЛЬНІСТЮ…», «щодо ТОВАРИСТВО…» — повна назва після
# прийменника не відмінюється, і довідка читається як помилка. Графи замовника
# ставлять назву після «у», «щодо», «про»; скорочена організаційно-правова форма
# (ТОВ, ПП, ФОП…) не відмінюється за правописом — речення граматичне без жодного
# вгадування відмінків. Шапка бланка лишається з ПОВНОЮ назвою.
_LEGAL_SHORT = (
    (r"товариство\s+з\s+обмеженою\s+відповідальністю", "ТОВ"),
    (r"товариство\s+з\s+додатковою\s+відповідальністю", "ТДВ"),
    (r"приватне\s+акціонерне\s+товариство", "ПрАТ"),
    (r"публічне\s+акціонерне\s+товариство", "ПАТ"),
    (r"акціонерне\s+товариство", "АТ"),
    (r"приватне\s+підприємство", "ПП"),
    (r"комунальне\s+підприємство", "КП"),
    (r"державне\s+підприємство", "ДП"),
    (r"фізична\s+особа\s*[-–—]\s*підприємець", "ФОП"),
)


def short_legal_name(name: str) -> str:
    """«ТОВАРИСТВО З ОБМЕЖЕНОЮ ВІДПОВІДАЛЬНІСТЮ "КАСПЕР УКРАЇНА"» -> «ТОВ «КАСПЕР УКРАЇНА»».
    Форми, якої немає в переліку, не скорочуємо — назва лишається як є."""
    t = re.sub(r"\s+", " ", str(name or "")).strip()
    for pat, short in _LEGAL_SHORT:
        m = re.match(r"^%s\b\s*(.*)$" % pat, t, re.I)
        if m:
            rest = m.group(1).strip()
            q = re.match(r'^["“”„«]+(.*?)["“”»]+$', rest)
            if q:
                rest = "«%s»" % q.group(1).strip()
            return ("%s %s" % (short, rest)).strip()
    return t


def fill_customer_form(text: str, participant: str) -> str:
    rows = [r.strip() for r in str(text or "").splitlines() if r.strip()]
    if rows and "_" not in rows[0] and len(rows[0]) <= 80:
        rows = rows[1:]                                  # заголовок форми ставить платформа
    rows = [r for r in rows if not re.fullmatch(r"_+", r)
            and not r.lower().startswith(("посада, прізвище", "підпис уповноваженої"))]
    out = []
    for r in rows:
        if out and not re.match(r"^\d{1,2}\)", r) and not out[-1].endswith((";", ":", ".")):
            out[-1] = out[-1] + " " + r                   # перенос рядка всередині графи
        else:
            out.append(r)
    name = short_legal_name(participant) or "______"
    return "\n".join(_NAME_BLANK.sub(name, r) for r in out).strip()


def form_bodies(checklist, makers=None, material: str = "", req: dict = None) -> dict:
    """{позиція: текст форми замовника з назвою учасника} для довідок «за формою N»."""
    try:
        import tender_pack as _tp
    except Exception:
        return {}
    out = {}
    for it in checklist or []:
        if _ts.who_makes(it, makers) != "система":
            continue
        m = _FORM_REF.search("%s %s" % (it, _ts.basis_of(it, makers)))
        if not m:
            continue
        ft = _tp.customer_form_text(material, m.group(1))
        if ft and _NAME_BLANK.search(ft):
            body = fill_customer_form(ft, (req or {}).get("name"))
            if len(body) >= MIN_BODY:
                out[it] = body
    return out


def empty_note(missing) -> str:
    """ЧОГО НЕ СКЛАЛИ — ТЕ НАЗВАНО. Порожній бланк без цього блоку читається як
    готова довідка, і людина везе його замовникові."""
    names = [str(n) for n in (missing or []) if str(n).strip()]
    if not names:
        return ""
    return ("### ДОВІДКИ, ТЕКСТ ЯКИХ ПЛАТФОРМА НЕ СКЛАЛА\n\n"
            "У цих документах є шапка, підстава й місце для підпису, але ТЕКСТУ "
            "немає — його треба написати перед подачею. Решта пакета готова:\n\n"
            + "\n".join("- " + n for n in names[:12])
            + (("\n- …і ще %d" % (len(names) - 12)) if len(names) > 12 else ""))
