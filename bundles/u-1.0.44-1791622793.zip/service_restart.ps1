﻿# ============================================================================
#  SensFlow — ПЕРЕЗАПУСТИТИ ПЛАТФОРМУ (зміни 518-520, 05.09.2026).
#
#  ⛒ ОДНА КНОПКА НА ДВА СВІТИ. Платформа живе двома способами: службою (без
#  вікна) і вікном консолі. Кнопка СПЕРШУ питає, як саме, і йде тим шляхом.
#
#  ⭐⭐⭐ 520: ПИТАННЯ СТАВИМО З ТИМИ ПРАВАМИ, ЗА ЯКИХ ВІДПОВІДЬ ВЗАГАЛІ ВИДНО.
#  Windows не показує завдання, що працює від SYSTEM, тому, хто не має прав
#  адміністратора. 05.09.2026 кнопка через це вирішила, що служби немає, і
#  підняла друге вікно поруч зі службою. Тому права просимо ПЕРШИМ ділом —
#  до того, як щось вирішувати. Одне вікно згоди коштує дешевше за платформу,
#  що працює у двох примірниках.
#
#  ⛒ 519в: кожен крок лягає рядком у service_action.log — інакше, коли кнопка
#  спрацює не так, розбиратися немає по чому: вікно бачить лише людина.
# ============================================================================
. (Join-Path (Split-Path -Parent $PSCommandPath) "service_common.ps1")

Sf-Head "SensFlow: перезапуск платформи"
Sf-Trace "----- перезапуск: почали"

# ⭐ 697: лежимо не там — словами і нічого не робимо (ні прав, ні перезапуску).
if (-not (Sf-RequireEngine)) { exit 2 }

if (-not (Sf-NeedAdmin -ScriptPath $PSCommandPath)) {
    Sf-Trace "вийшли: пішли по права адміністратора"
    exit
}
Sf-Trace "права адміністратора: є"

$port = Sf-Port
$task = Sf-Task
Sf-Trace ("завдання: " + $(if ($task) { "знайдено" } else { "НЕ знайдено" }) +
          " (" + $SfTaskWhy + ")")

if ($task) {
    Sf-Line "Платформа працює СЛУЖБОЮ — перезапускаю службу."
    Sf-Trace (Sf-TaskStop)

    Sf-Line "Зупинив. Чекаю, поки звільниться порт $port..."
    $till = (Get-Date).AddSeconds(20)
    while ((Sf-Alive -Port $port -Seconds 1) -and ((Get-Date) -lt $till)) {
        Start-Sleep -Seconds 1
    }
    # Хвіст, який не відпустив порт, знімаємо силою: інакше служба підніметься,
    # побачить зайнятий порт і чесно вийде — а людина думатиме, що працює.
    try {
        $held = @(Get-NetTCPConnection -LocalPort ([int]$port) -State Listen -ErrorAction Stop)
        Sf-Trace ("порт тримають процесів: " + $held.Count)
        $held | ForEach-Object {
            Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue
        }
    } catch {
        Sf-Trace "порт вільний"
    }
    Start-Sleep -Seconds 2

    Sf-Trace (Sf-TaskStart)
    Sf-Line "Запустив. Чекаю відповіді..."
    if (Sf-Alive -Port $port -Seconds 60) {
        Sf-Trace "платформа відповіла — перезапуск СЛУЖБОЮ вдався"
        Sf-Head "ГОТОВО. Платформа перезапущена"
        Sf-Line "Адреса : http://127.0.0.1:$port"
        Sf-Line "Вікна немає — вона працює у фоні, як і має."
    } else {
        Sf-Trace "платформа НЕ відповіла за 60 с (гілка служби)"
        Sf-Head "ПЛАТФОРМА НЕ ВІДПОВІЛА"
        Sf-Line "Причина — в журналі: $SfLog"
        Sf-Line "Покажи мені його, розберемось."
    }
} else {
    Sf-Line "Автозапуску немає — перезапускаю вікном консолі, як раніше."
    Sf-Trace "гілка БЕЗ служби: піднімаю вікно консолі"
    & taskkill /f /t /fi "WINDOWTITLE eq SensFlow Orchestrator" 2>$null | Out-Null
    try {
        Get-NetTCPConnection -LocalPort ([int]$port) -State Listen -ErrorAction Stop |
            ForEach-Object { Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue }
    } catch {}
    Start-Sleep -Seconds 3
    # ⛒ 724: чим підняти — каже `Sf-ConsoleLauncher` (наша машина чи пакет клієнта).
    $launcher = Sf-ConsoleLauncher
    if (-not $launcher) {
        Sf-Trace "гілка БЕЗ служби: запускача поруч немає"
        Sf-Head "НЕ ЗНАЙШОВ ЗАПУСКАЧА ПЛАТФОРМИ"
        Sf-Line "Поруч із кнопкою немає «Запустити SensFlow.bat». Запустіть платформу ним вручну."
        Read-Host "Натисни Enter, щоб закрити"
        exit 1
    }
    Start-Process -FilePath $launcher -WorkingDirectory $SfRoot -WindowStyle Minimized
    Sf-Line "Підняв вікно. Чекаю відповіді..."
    if (Sf-Alive -Port $port -Seconds 60) {
        Sf-Trace "платформа відповіла — перезапуск ВІКНОМ вдався"
        Sf-Head "ГОТОВО. Платформа перезапущена"
        Sf-Line "Адреса : http://127.0.0.1:$port"
    } else {
        Sf-Trace "платформа НЕ відповіла за 60 с (гілка вікна)"
        Sf-Head "ПЛАТФОРМА НЕ ВІДПОВІЛА"
        Sf-Line "Подивись у вікно консолі — воно згорнуте на панелі задач."
    }
}
Sf-Trace "----- перезапуск: завершили"
Sf-Line ""
Read-Host "Натисни Enter, щоб закрити"
