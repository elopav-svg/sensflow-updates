﻿# ============================================================================
#  SensFlow — спільні речі для трьох скриптів служби (зміна 517, 05.09.2026).
#  Один писар на відповіді «де корінь», «який порт», «чи жива платформа»:
#  три копії тієї самої правди розійшлися б за тиждень.
# ============================================================================
$ErrorActionPreference = "Stop"
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $OutputEncoding = [System.Text.Encoding]::UTF8
} catch {}

$SfRoot   = Split-Path -Parent $PSCommandPath          # ...\AI_Orchestrator_Platform
$SfEngine = Join-Path $SfRoot "orchestrator_py"
$SfRunner = Join-Path $SfRoot "_run_service.bat"
$SfLog    = Join-Path $SfRoot "service.log"
$SfTask   = "SensFlow Orchestrator"

# ⭐⭐⭐ 519в: КНОПКА МУСИТЬ ЛИШАТИ СЛІД НА ДИСКУ.
# Скрипти служби говорять у вікно, яке бачить лише Андрій, — і коли кнопка
# спрацювала не так, розбиратися немає по чому. Тепер кожен важливий крок
# лягає рядком у service_action.log поруч: я читаю його сам, не питаючи.
$SfTrace = Join-Path $SfRoot "service_action.log"
function Sf-Trace {
    param([string]$t)
    try {
        Add-Content -Path $SfTrace -Encoding UTF8 -Value (
            "{0}  {1}" -f (Get-Date -Format "yyyy-MM-dd HH:mm:ss"), $t)
    } catch {}
}

function Sf-Line { param([string]$t = "") Write-Host $t }

# ⭐⭐⭐ 697 (05.10.2026): ПЛАТФОРМА ПОРУЧ — ДО БУДЬ-ЯКОЇ ДІЇ.
# 🩸 На розгортанні ОТУ кнопки служби поклали в підтеку: служба заводилась і
# шукала server.py не там — платформа мовчки не піднімалась. Тепер кнопка, що
# лежить не там, каже це словами і НІЧОГО не робить: ні прав не просить, ні
# завдання не заводить.
function Sf-RequireEngine {
    if (Test-Path (Join-Path $SfEngine "server.py")) { return $true }
    Sf-Line ""
    Sf-Line "СТОП: поруч із цією кнопкою немає платформи."
    Sf-Line ("Шукав: " + (Join-Path $SfEngine "server.py"))
    Sf-Line "Кнопки служби мусять лежати в КОРЕНІ теки платформи — там, де тека"
    Sf-Line "orchestrator_py і «Запустити SensFlow.bat». Перекладіть їх туди і натисніть знову."
    Sf-Line "Нічого не змінено."
    Sf-Trace "СТОП: поруч немає orchestrator_py\server.py — нічого не робили"
    try { Read-Host "Натисни Enter" | Out-Null } catch {}
    return $false
}

# ⛒⛒⛒ 724 (08.10.2026, Р-0004). ЯКИЙ PYTHON БЕРЕ СЛУЖБА — ОДИН ПИСАР.
# 🩸 723 дала пакету свій Python (тека python\), а установник служби шукав лише в PATH, реєстрі
# й `py` — вбудованого там немає: на машині без Python кнопка служби сказала б «НЕ ЗНАЙШОВ».
# Python пакета — ПЕРШИЙ (і для нього гасимо чужі PYTHONHOME/PYTHONPATH — з ними він стартує, але
# НЕ БАЧИТЬ своїх бібліотек: перевірено 08.10.2026, `No module named 'docx'`);
# інакше — як досі. Служба працює від SYSTEM з іншим PATH, тому відповідь — ПОВНИЙ шлях.
function Sf-OwnPython { return (Join-Path $SfRoot "python\python.exe") }
function Sf-FindPython {
    $own = Sf-OwnPython
    if (Test-Path $own) {
        # 735: змінні процесу гасимо присвоєнням — команди видалення в спільному файлі служби
        # не буває зовсім (legacy_autostart_test): служба нічого не видаляє.
        $env:PYTHONHOME = $null
        $env:PYTHONPATH = $null
        $env:PYTHONNOUSERSITE = "1"
        $v = ""
        try { $v = (& $own -c "import sys;print(sys.version_info[0])" 2>$null | Out-String).Trim() } catch {}
        if ($v -eq "3") { return $own }
    }
    $cands = New-Object System.Collections.Generic.List[string]
    foreach ($c in (Get-Command python.exe -All -ErrorAction SilentlyContinue)) {
        if ($c.Source) { $cands.Add($c.Source) }
    }
    foreach ($hive in @("HKLM:\SOFTWARE\Python\PythonCore",
                        "HKLM:\SOFTWARE\WOW6432Node\Python\PythonCore",
                        "HKCU:\SOFTWARE\Python\PythonCore")) {
        if (Test-Path $hive) {
            foreach ($k in (Get-ChildItem $hive -ErrorAction SilentlyContinue)) {
                $ip = Join-Path $k.PSPath "InstallPath"
                if (Test-Path $ip) {
                    $pr = Get-ItemProperty $ip -ErrorAction SilentlyContinue
                    $exe = $null
                    if ($pr.ExecutablePath) { $exe = $pr.ExecutablePath }
                    elseif ($pr.'(default)') { $exe = Join-Path $pr.'(default)' "python.exe" }
                    if ($exe) { $cands.Add($exe) }
                }
            }
        }
    }
    try {
        & py -0p 2>$null | ForEach-Object {
            if ($_ -match "([A-Za-z]:\\[^\r\n]*python\.exe)") { $cands.Add($Matches[1]) }
        }
    } catch {}
    foreach ($c in $cands) {
        if (-not $c) { continue }
        # Заглушка з Microsoft Store виглядає як python.exe, а відкриває магазин.
        if ($c -like "*\WindowsApps\*") { continue }
        if (-not (Test-Path $c)) { continue }
        try {
            $v = (& $c -c "import sys;print(sys.version_info[0])" 2>$null | Out-String).Trim()
            if ($v -eq "3") { return $c }
        } catch {}
    }
    return $null
}

# ⛒⛒ 724. ЯКИМ ВІКНОМ ПІДНЯТИ ПЛАТФОРМУ БЕЗ СЛУЖБИ — ОДИН ПИСАР.
# 🩸 Кнопка перезапуску (697) піднімала наш `_run_server.bat` — у пакеті клієнта його немає, і
# кнопка без служби падала. На нашій машині — він; у пакеті — запускач пакета. Нічого — порожньо.
function Sf-ConsoleLauncher {
    foreach ($n in @("_run_server.bat", "Запустити SensFlow.bat")) {
        $p = Join-Path $SfRoot $n
        if (Test-Path $p) { return $p }
    }
    return ""
}
function Sf-Head {
    param([string]$t)
    Write-Host ""
    Write-Host ("=" * 66)
    Write-Host ("  " + $t)
    Write-Host ("=" * 66)
}

# ⭐⭐⭐ 523 (06.09.2026): НОВА РІЧ МУСИТЬ ПРИБРАТИ ТЕ, ЩО ВОНА ЗАМІНЯЄ.
# 🩸 Жива біда: після вмикання машини на робочому столі лишалось вікно
# «SensFlow уже працює». У теці автозавантаження Windows лежав ярлик із часів
# ДО служби: служба вже підняла платформу, а ярлик піднімав другу копію.
# ⛔ НІЧОГО НЕ ВИДАЛЯЄМО. Ярлики переносимо в теку поруч, записи реєстру
# спершу пишемо у файл і лише тоді знімаємо. ⛔ ЧУЖОГО НЕ ЧІПАЄМО ВЗАГАЛІ:
# беремо ЛИШЕ те, що показує В ТЕКУ ПЛАТФОРМИ.
function Sf-LegacyStore {
    $d = Join-Path $SfRoot "_старий автозапуск"
    if (-not (Test-Path $d)) {
        New-Item -ItemType Directory -Path $d -Force | Out-Null
        $readme = Join-Path $d "ЩО ТУТ ЛЕЖИТЬ.txt"
        Set-Content -Path $readme -Encoding UTF8 -Value @(
            "Сюди перенесено СТАРИЙ автозапуск платформи.",
            "",
            "Навіщо: платформа тепер піднімається службою Windows. Старий ярлик",
            "піднімав ДРУГУ копію, і вона лишала зайве вікно на робочому столі.",
            "",
            "Нічого не видалено. Щоб повернути як було: зніміть автозапуск",
            "кнопкою «Служба - зняти автозапуск.bat», а тоді покладіть ярлик",
            "звідси назад у теку автозавантаження Windows.",
            "Записи реєстру, якщо вони були, виписані у registry_backup.txt.")
    }
    return $d
}

function Sf-RemoveLegacyAutostart {
    param([string]$Scope = "User")
    $found = 0
    if ($Scope -eq "User") {
        $folder = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
        $keys = @("HKCU:\Software\Microsoft\Windows\CurrentVersion\Run")
    } else {
        $folder = Join-Path $env:ProgramData "Microsoft\Windows\Start Menu\Programs\Startup"
        $keys = @("HKLM:\Software\Microsoft\Windows\CurrentVersion\Run",
                  "HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Run")
    }
    if (Test-Path $folder) {
        $sh = New-Object -ComObject WScript.Shell
        foreach ($i in (Get-ChildItem $folder -Filter *.lnk -ErrorAction SilentlyContinue)) {
            $target = ""
            try { $target = ("" + ($sh.CreateShortcut($i.FullName)).TargetPath) } catch {}
            if (-not $target) { continue }
            if (-not $target.StartsWith($SfRoot, [System.StringComparison]::OrdinalIgnoreCase)) { continue }
            try {
                Move-Item -LiteralPath $i.FullName -Destination (Join-Path (Sf-LegacyStore) $i.Name) -Force
                $found = $found + 1
                Sf-Line ("Прибрано старий ярлик автозапуску: " + $i.Name)
                Sf-Trace ("старий автозапуск прибрано: " + $i.FullName)
            } catch {
                Sf-Line ("НЕ ЗМІГ прибрати " + $i.Name + ": " + $_.Exception.Message)
                Sf-Trace ("старий автозапуск НЕ прибрано: " + $i.FullName)
            }
        }
    }
    foreach ($k in $keys) {
        if (-not (Test-Path $k)) { continue }
        $props = Get-ItemProperty $k -ErrorAction SilentlyContinue
        foreach ($n in $props.PSObject.Properties) {
            if ($n.Name -like "PS*") { continue }
            $v = "" + $n.Value
            if ($v.IndexOf($SfRoot, [System.StringComparison]::OrdinalIgnoreCase) -lt 0) { continue }
            # ⛒ СПЕРШУ СЛІД НА ДИСКУ, І ЛИШЕ ТОДІ ЗНІМАЄМО.
            Add-Content -Path (Join-Path (Sf-LegacyStore) "registry_backup.txt") -Encoding UTF8 -Value (
                ("{0} | {1} | {2}" -f $k, $n.Name, $v))
            try {
                Remove-ItemProperty -Path $k -Name $n.Name -Force
                $found = $found + 1
                Sf-Line ("Прибрано старий запис автозапуску: " + $n.Name)
                Sf-Trace ("запис автозапуску прибрано: " + $k + " -> " + $n.Name)
            } catch {
                Sf-Line ("НЕ ЗМІГ прибрати запис " + $n.Name + " (бракує прав)")
                Sf-Trace ("запис автозапуску НЕ прибрано: " + $k + " -> " + $n.Name)
            }
        }
    }
    return $found
}

function Sf-IsAdmin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    return (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole(
        [Security.Principal.WindowsBuiltInRole]::Administrator)
}

# Права адміністратора потрібні, щоб завести завдання від імені SYSTEM.
# Просимо їх САМІ, а не вимагаємо від людини памʼятати про «запуск від імені».
function Sf-NeedAdmin {
    param([string]$ScriptPath)
    if (Sf-IsAdmin) { return $true }
    Sf-Line "Потрібні права адміністратора — відкриваю вікно з запитом..."
    try {
        Start-Process -FilePath "powershell.exe" -Verb RunAs -ArgumentList @(
            "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$ScriptPath`"")
    } catch {
        Sf-Line ""
        Sf-Line "Запит скасовано. Без прав адміністратора завдання не заводиться."
        Sf-Line "Спробуй ще раз і погодься у вікні Windows."
        Read-Host "Натисни Enter"
    }
    return $false
}

# Порт беремо ЗВІДТИ, звідки його бере сама платформа, а не з голови.
function Sf-Port {
    $port = "7799"
    foreach ($f in @((Join-Path $SfRoot ".env.local"),
                     (Join-Path $SfEngine ".env.local"),
                     (Join-Path (Split-Path -Parent $SfRoot) ".env.local"))) {
        if (Test-Path $f) {
            foreach ($line in (Get-Content $f -Encoding UTF8 -ErrorAction SilentlyContinue)) {
                if ($line -match '^\s*PORT\s*=\s*(\d+)\s*$') { $port = $Matches[1] }
            }
        }
    }
    return $port
}

function Sf-Alive {
    param([string]$Port, [int]$Seconds = 1)
    $till = (Get-Date).AddSeconds($Seconds)
    do {
        try {
            $r = Invoke-WebRequest -Uri ("http://127.0.0.1:$Port/api/health") `
                 -UseBasicParsing -TimeoutSec 3
            if ($r.StatusCode -eq 200) { return $true }
        } catch {}
        if ((Get-Date) -lt $till) { Start-Sleep -Seconds 2 }
    } while ((Get-Date) -lt $till)
    return $false
}

# ⭐⭐⭐ 520: «ЗАВДАННЯ НЕ ЗНАЙДЕНО» І «Я НЕ МАЮ ПРАВА ЙОГО БАЧИТИ» — ЦЕ
# РІЗНІ ВІДПОВІДІ, І ПЛУТАТИ ЇХ НЕ МОЖНА. Windows не показує завдання, що
# працює від SYSTEM, тому, хто не має прав адміністратора. 05.09.2026 кнопка
# перезапуску через це вирішила, що служби немає, і підняла друге вікно.
# Тепер: питаємо рідним способом, а якщо він мовчить — перепитуємо через
# schtasks.exe (він є на кожній Windows і не потребує модуля), і В КОЖНОМУ
# разі лишаємо в сліді, ЧОМУ відповідь саме така.
$SfTaskWhy = ""

function Sf-Task {
    $script:SfTaskWhy = ""
    try {
        $t = Get-ScheduledTask -TaskName $SfTask -ErrorAction Stop
        if ($t) {
            $script:SfTaskWhy = "Get-ScheduledTask: знайдено"
            return $t
        }
        $script:SfTaskWhy = "Get-ScheduledTask: порожньо"
    } catch {
        $script:SfTaskWhy = "Get-ScheduledTask: " + $_.Exception.Message
    }
    try {
        $out = & schtasks.exe /Query /TN $SfTask 2>&1
        if ($LASTEXITCODE -eq 0) {
            $script:SfTaskWhy += " | schtasks: знайдено"
            return ([pscustomobject]@{ TaskName = $SfTask; State = "знайдено через schtasks" })
        }
        $script:SfTaskWhy += " | schtasks: " + (($out | Out-String).Trim())
    } catch {
        $script:SfTaskWhy += " | schtasks: " + $_.Exception.Message
    }
    return $null
}

# Зупинка й запуск теж мають запасний шлях: якщо модуля немає, працює schtasks.
function Sf-TaskStop {
    try {
        Stop-ScheduledTask -TaskName $SfTask -ErrorAction Stop
        return "Stop-ScheduledTask: виконано"
    } catch {
        $o = & schtasks.exe /End /TN $SfTask 2>&1
        return "schtasks /End: " + (($o | Out-String).Trim())
    }
}

function Sf-TaskStart {
    try {
        Start-ScheduledTask -TaskName $SfTask -ErrorAction Stop
        return "Start-ScheduledTask: виконано"
    } catch {
        $o = & schtasks.exe /Run /TN $SfTask 2>&1
        return "schtasks /Run: " + (($o | Out-String).Trim())
    }
}
