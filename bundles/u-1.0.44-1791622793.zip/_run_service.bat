@echo off
rem ============================================================
rem  SensFlow: sluzhba (zapuskach). Zminu 516 dyv. u zhurnali.
rem  Zapuskaie Planuvalnyk zavdan vid imeni SYSTEM pry starti
rem  mashyny. Vikna nemaie, tomu vsi povidomlennia idut u fayl
rem  service.log poruch. Poperedniy zapusk zberihaietsia v
rem  service.prev.log - shchob fayl ne ris bez mezh.
rem  ASCII only: tsey fayl chytaie konsol Windows.
rem ============================================================
setlocal
cd /d "%~dp0orchestrator_py"

rem Povnyy shliakh do python znayshov vstanovliuvach sluzhby.
if exist "%~dp0_service_python.cmd" call "%~dp0_service_python.cmd"
rem 724: Python paketa (teka python, zmina 723) - pershym; chuzhi PYTHONHOME/PYTHONPATH
rem mashyny hasymo - z nymy vin ne bachyt svoyikh bibliotek.
if exist "%~dp0python\python.exe" (
  set "SF_PY=%~dp0python\python.exe"
  set "PYTHONHOME="
  set "PYTHONPATH="
  set "PYTHONNOUSERSITE=1"
)
if not defined SF_PY set "SF_PY=python"

set "SF_LOG=%~dp0service.log"
if exist "%SF_LOG%" move /y "%SF_LOG%" "%~dp0service.prev.log" >nul 2>&1

rem Brauzer u sluzhbi vidkryvaty nikomu - vikna nemaie.
set "AUTO_OPEN_BROWSER=0"
rem Uspishni zvertannia v zhurnal ne pyshemo (zmina 516).
set "SENSFLOW_QUIET=1"

"%SF_PY%" -X utf8 server.py >> "%SF_LOG%" 2>&1
