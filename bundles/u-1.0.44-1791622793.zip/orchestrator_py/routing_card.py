# -*- coding: utf-8 -*-
"""routing_card.py — ПАСПОРТ ПРИЗНАЧЕННЯ СИСТЕМИ: за чим мозок обирає маршрут.

⭐⭐⭐ КОРІНЬ 04.08.2026 (живий випадок у клієнта, двічі за день).
Запит «проаналізуй сайт як досвідчений маркетолог» + адреса двічі пішов у
«Бізнес-аналітику»: спершу вона написала звіт із памʼяті моделі (аудит сайту
американського бренду матраців Casper), потім — чесно, але шістьма етапами
консалтингу за ~$3 замість маркетингового аудиту сторінки.

ЧОМУ МОЗОК ОБИРАВ ТАК. Каталог, який він читає перед вибором, розповідав, ЯК
система влаштована всередині: «послідовний шестиетапний конвеєр», «4 агенти
передають артефакти через файлову систему», «цикл критик→стратег до вердикту».
Це технічний переказ пайплайну. Ніде не було сказано ДЛЯ ЧОГО систему брати,
ЩО подають на вхід, ЩО вийде і ЧОГО вона НЕ робить (поле «межі» — порожнє в усіх
22 системах). Виграє завжди той опис, який звучить найширше, — а не той, що
підходить. Спроба полагодити це позначкою в каталозі й наказом у промпті
провалилась наживо: правило, яке живе в промпті, — це прохання, а не ворота.

РІШЕННЯ (Андрій, 04.08.2026: «мені не потрібна релейна шафа, яка спрацьовує по
тригерах»). Заборон за ключовими ознаками не ставимо — вони лікують один запит,
а не клас. Натомість мозок отримує СТРУКТУРОВАНИЙ ПАСПОРТ кожної системи з
чотирьох полів і обирає, зіставляючи задачу зі ВХОДОМ і ВИХОДОМ:
    ДЛЯ ЯКИХ ЗАДАЧ · ЩО НА ВХОДІ · ЩО НА ВИХОДІ · ЧОГО НЕ РОБИТЬ

ОДИН ПИСАР. Паспорт складається з власного мозку системи (кореневий промпт +
паспорт ролей), лежить у теці системи (`.routing_card.json`, поруч із
`.orchestration_plan.json`) і має ВІДБИТОК джерела. Похідне значення на диску без
відбитка = друга правда; тут її немає.

⛒⛒⛒ 729 (09.10.2026). ПАСПОРТ — ОГОЛОШЕННЯ ВИХОДУ СИСТЕМИ; КАТАЛОГ СУДИТЬ ОГОЛОШЕНЕ.
🩸 Каталог щоразу рахував відбиток із ТЕКСТУ ПРОМПТА кожної системи — тож кожна перевірка,
що будує каталог, читала промпти всіх систем, і правка промпта однієї системи будила 32–43
перевірки, хоч жодна з них не судить, що в промпті написано. Тепер відбитків два:
  * `fingerprint` — ОГОЛОШЕНЕ, видне з реєстру: назва, опис, оголошені вміння ролей.
    Розійшовся — паспорт у каталог НЕ йде (`load`), як і досі;
  * `brain` — мозок системи, з якого паспорт складено. Його судить ОДИН суддя — `fresh`:
    проба живого стану перед публікацією і складальник паспортів (`refresh_all`).
Клієнтові промпти міняє лише оновлення, а воно везе паспорти з еталона, де свіжість доведено
до публікації. Ціна: паспорт, складений за старим мозком, у каталозі еталона живе до воріт
публікації (там — СТОП із назвою дії), а не зникає мовчки, як до 729.

ГРОШІ. Складання паспорта — окрема обслуговна дія (`build_routing_cards.py`),
найдешевшою моделлю драбини, ОДИН раз на систему. У гарячому шляху чату паспорт
НІКОЛИ не будується: немає паспорта — каталог чесно каже про це, а не мовчить.
"""

import hashlib
import json

import config
import llm
import registry

CARD_FILE = ".routing_card.json"
FIELDS = ("for_tasks", "input", "output", "not_for")


def _brain_text(system: dict) -> str:
    """Кореневий промпт системи (той самий, що читає виконавець)."""
    try:
        root = registry.system_root(system)
        for name in ("CLAUDE.md", "PROMPT.md"):
            p = root / name
            if p.exists():
                return p.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        pass
    return ""


# ⭐⭐⭐ КОРІНЬ 09.09.2026 (промах маршруту, знятий під камеру). Чек-лист вхідного
# контролю пішов у Копірайтерську систему. Вада була не в мозку: у каталог, який
# він читає ПЕРЕД вибором, 19 систем із 25 приїжджали БЕЗ паспорта — з написом
# «паспорт не складено, суди обережно». Файли паспортів лежали на диску цілі; їх
# відкидав ВІДБИТОК, бо рахувався з УСІХ умінь ролі. А платформа дораховує роль
# сама: `registry.enforce_role_invariants` додає `page_read` кожному, хто має
# `web` (правило від 09.08.2026). Тобто одна платформна зміна МОВЧКИ знецінила
# паспорти всіх систем, де `page_read` не був оголошений явно.
#
# ⛒ ЛІКУЄМО КЛАС, А НЕ ВИПАДОК: паспорт — про ПРИЗНАЧЕННЯ системи, а дане
# платформою ПРАВО призначення не міняє. Тому відбиток судить ОГОЛОШЕНЕ:
# оголосили `page_read` явно — він рахується; дорахувала платформа (мітка
# `registry.PAGE_READ_IMPLIED`) — ні. Наступне таке правило вже не обнулить
# каталог, а `routing_card_fingerprint_test.py` не дасть цьому зогнити мовчки.
def _declared_tools(role) -> list:
    """Уміння ролі, ЯКІ ОГОЛОШЕНІ в самій системі — без дорахованих прав."""
    tools = ((role or {}).get("tools") or {})
    if not isinstance(tools, dict):
        return []
    return [k for k, v in tools.items()
            if not (k == "page_read" and v == registry.PAGE_READ_IMPLIED)]


BRAIN_SEEN = 6000      # стільки мозку бачить модель, що складає паспорт (`build`)


def _declared_parts(system: dict) -> list:
    roles = registry.get_roles(system) or {}
    return [
        str((system or {}).get("name") or ""),
        str((system or {}).get("description") or ""),
        json.dumps({k: sorted(_declared_tools(v))
                    for k, v in sorted(roles.items())}, ensure_ascii=False, sort_keys=True),
    ]


def fingerprint(system: dict) -> str:
    """⛒ 729: відбиток ОГОЛОШЕНОГО — імʼя, опис, оголошені вміння ролей (усе з реєстру).
    Змінилось будь-що з цього — паспорт у каталог не йде. Мозку тут немає: його судить `fresh`."""
    return hashlib.md5("\n<>\n".join(_declared_parts(system)).encode("utf-8")).hexdigest()[:16]


def brain_fingerprint(system: dict) -> str:
    """⛒ 729: відбиток мозку — рівно того тексту, який бачила модель, що складала паспорт."""
    return hashlib.md5(_brain_text(system)[:BRAIN_SEEN].encode("utf-8")).hexdigest()[:16]


def _legacy_fingerprint(system: dict) -> str:
    """Відбиток паспорта ДО 729 (оголошене + мозок одним числом) — лише щоб судити паспорт
    старого формату: він лежить у клієнта, доки оновлення не привезе новий."""
    parts = _declared_parts(system) + [_brain_text(system)[:8000]]
    return hashlib.md5("\n<>\n".join(parts).encode("utf-8")).hexdigest()[:16]


def _path(system: dict):
    return registry.system_root(system) / CARD_FILE


def _read(system: dict):
    try:
        p = _path(system)
        if not p.exists():
            return None
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def _complete(card) -> bool:
    return isinstance(card, dict) and all(card.get(f) for f in FIELDS)


def load(system: dict) -> dict:
    """Дійсний паспорт або {} — якщо його немає чи змінилось ОГОЛОШЕНЕ (назва, опис, вміння).
    ⛒ 729: мозку системи не читає (паспорт старого формату — виняток, див. `_legacy_fingerprint`).
    НІКОЛИ не будує сам: гарячий шлях чату не витрачає гроші користувача."""
    data = _read(system)
    if data is None:
        return {}
    if "brain" in data:
        if data.get("fingerprint") != fingerprint(system):
            return {}      # оголошене змінилось — паспорт застарів, у каталог не йде
    elif data.get("fingerprint") != _legacy_fingerprint(system):
        return {}          # старий формат: судить старий відбиток, як до 729
    card = data.get("card") or {}
    if not isinstance(card, dict) or not card.get("input") or not card.get("output"):
        return {}
    return card


def fresh(system: dict):
    """⛒ 729. ЄДИНИЙ СУДДЯ СВІЖОСТІ ПАСПОРТА: (True, "") або (False, чому — з назвою дії).
    Свіжий = є, повний, нового формату, оголошене і мозок ті самі, що при складанні."""
    sid = str((system or {}).get("id") or "?")
    act = "python build_routing_cards.py --only %s" % sid
    data = _read(system)
    if data is None:
        return False, "паспорта немає або він не читається: %s" % act
    if not _complete(data.get("card")):
        return False, "паспорт неповний: %s" % act
    if "brain" not in data:
        return False, "паспорт старого формату (до 729): python build_routing_cards.py переведе без моделі"
    if data.get("fingerprint") != fingerprint(system):
        return False, "змінились назва, опис чи вміння системи: %s" % act
    if data.get("brain") != brain_fingerprint(system):
        return False, "мозок системи змінився після складання паспорта: %s" % act
    return True, ""


def upgrade(system: dict) -> bool:
    """⛒ 729. Перевести паспорт старого формату в новий БЕЗ МОДЕЛІ — лише якщо старий відбиток
    збігається (паспорт складено саме з цього мозку й оголошеного). Інакше — нічого не пише."""
    data = _read(system)
    if data is None or "brain" in data or not _complete(data.get("card")):
        return False
    if data.get("fingerprint") != _legacy_fingerprint(system):
        return False
    _write(system, data["card"])
    return True


def _write(system: dict, card: dict):
    p = _path(system)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"fingerprint": fingerprint(system), "brain": brain_fingerprint(system),
                             "card": card}, ensure_ascii=False, indent=2), encoding="utf-8")


_SYS = (
    "Ти складаєш ПАСПОРТ ПРИЗНАЧЕННЯ мультиагентської системи для каталогу, за яким "
    "оркестратор обирає, кому віддати задачу користувача. Тебе цікавить НЕ будова "
    "системи (скільки агентів, як передають файли, чи є критик) — це в каталозі "
    "непотрібне. Тебе цікавить ЛИШЕ: для яких задач її брати, що подають на вхід, що "
    "вона віддає на виході і чого вона НЕ робить.\n"
    "Пиши простою мовою замовника, без маркетингу й без загальних слів на кшталт "
    "«комплексний аналіз» чи «повний цикл». Кожен рядок має допомагати ВІДРІЗНИТИ цю "
    "систему від сусідньої в каталозі.\n"
    "Поле not_for — це справжні межі: назви задачі, схожі на цю, які цій системі "
    "віддавати НЕ можна. Порожнім його лишати не можна.\n"
    'Поверни РІВНО ОДИН JSON: {"for_tasks":["",""],"input":"","output":"","not_for":["",""]}. '
    "for_tasks — 2-4 короткі типові задачі. input — що саме подають (напр. «адреса "
    "сторінки і мета», «сира ідея бізнесу», «вже наявні внутрішні дані»). output — що "
    "виходить на руки. not_for — 2-4 пункти."
)


def build(system: dict, model: str = None) -> dict:
    """Складає паспорт мозком системи і кладе поруч із нею. Повертає паспорт.
    Кидає виняток, якщо судження не вдалося — мовчазної порожнечі тут немає."""
    roles = registry.get_roles(system) or {}
    tools_by_role = {k: sorted(((v or {}).get("tools") or {}).keys()) for k, v in roles.items()}
    user = (
        f"НАЗВА: {system.get('name')}\n"
        f"ID: {system.get('id')}\n"
        f"ОПИС З РЕЄСТРУ: {system.get('description') or '—'}\n"
        f"РОЛІ ТА ЇХНІ ІНСТРУМЕНТИ: {json.dumps(tools_by_role, ensure_ascii=False)}\n"
        f"(page_read = вміє відкрити й розібрати сторінку за адресою; "
        f"web = живий пошук в інтернеті; calculator = рахує калькулятором)\n\n"
        f"КОРЕНЕВИЙ ПРОМПТ СИСТЕМИ (її власний мозок):\n{_brain_text(system)[:BRAIN_SEEN]}"
    )
    data = llm.judge_json(_SYS, user, model=model or config.worker_model(),
                          purpose="routing_card/%s" % system.get("id"))
    card = {
        "for_tasks": [str(x).strip() for x in (data.get("for_tasks") or []) if str(x).strip()][:4],
        "input": str(data.get("input") or "").strip(),
        "output": str(data.get("output") or "").strip(),
        "not_for": [str(x).strip() for x in (data.get("not_for") or []) if str(x).strip()][:4],
    }
    if not (card["input"] and card["output"] and card["for_tasks"] and card["not_for"]):
        raise ValueError("паспорт неповний: %s" % json.dumps(card, ensure_ascii=False))
    _write(system, card)
    return card


def refresh_all(systems, force=False, emit=print) -> dict:
    """⛒ 729. ОДИН ПИСАР ПАСПОРТІВ (кнопка `build_routing_cards.py`): свіжий — не чіпає;
    старий формат, що збігається, — переводить без моделі; решту — складає (`build`, платно,
    найдешевшою моделлю). Повертає лічильники {made, upgraded, skipped, failed}."""
    n = {"made": 0, "upgraded": 0, "skipped": 0, "failed": 0}
    for s in systems:
        sid = s.get("id")
        if not force:
            ok, why = fresh(s)
            if ok:
                emit("  =  %-52s паспорт свіжий" % sid)
                n["skipped"] += 1
                continue
            if upgrade(s):
                emit("  ~  %-52s переведено в новий формат (без моделі)" % sid)
                n["upgraded"] += 1
                continue
            emit("  .  %-52s %s" % (sid, why.split(":")[0]))
        try:
            card = build(s)
            emit("  +  %-52s складено" % sid)
            emit("       для задач: " + "; ".join(card["for_tasks"])[:150])
            emit("       на вхід  : " + card["input"][:150])
            emit("       на вихід : " + card["output"][:150])
            emit("       НЕ для   : " + "; ".join(card["not_for"])[:150])
            n["made"] += 1
        except Exception as e:                       # noqa: BLE001
            emit("  !  %-52s НЕ СКЛАДЕНО: %s" % (sid, str(e)[:120]))
            n["failed"] += 1
    return n


def render_lines(card: dict) -> list:
    """Паспорт у рядки каталогу мозку. Порожній паспорт → порожній список."""
    if not card:
        return []
    out = ["    для задач: " + "; ".join(card.get("for_tasks") or []),
           "    на вхід: " + str(card.get("input") or ""),
           "    на вихід: " + str(card.get("output") or "")]
    if card.get("not_for"):
        out.append("    НЕ для: " + "; ".join(card["not_for"]))
    return out
