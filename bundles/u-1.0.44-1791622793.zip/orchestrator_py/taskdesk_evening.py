# -*- coding: utf-8 -*-
"""taskdesk_evening.py — ⭐⭐⭐ ВЕЧІРНІЙ КОНТРОЛЬ: ПРОТЕРМІНОВАНЕ КОМАНДИ ЗА ВИКОНАВЦЯМИ (зміна 739, 10.10.2026).

ЗВІДКИ. Розмови Андрія з клієнтами (09.10.2026, план на 10.10): керівник (у Каспера — Подервінскас)
увечері з телефона дивиться, що в команди протерміновано, і реагує — відкриває задачу, пише
коментар. А щоб не треба було памʼятати, бот увечері сам каже «протерміновано N — відкрити список».

ЩО ТУТ ВИРІШЕНО
1. ТЕ САМЕ, ЩО ЛЮДИНА БАЧИТЬ. Перелік — не новий збирач: `tasks.board(scope="overdue")`, ті самі
   ворота видимості, що й на екрані задач. Вечірній контроль не може показати чужого.
2. ЧУЖЕ, А НЕ СВОЄ. Повідомлення — про протерміноване ІНШИХ людей, яке людина бачить (як керівник,
   постановник чи спостерігач). Своє протерміноване людина й так бачить на головній.
3. РАЗ НА ДЕНЬ, ПІСЛЯ ВІДПРАВКИ. Позначка «сьогодні надіслано» — на людину, лише після успішної
   відправки: перезапуск сервера не шле вдруге, збій — спробуємо в наступний обхід цього ж вечора.
4. НЕМАЄ ПРОТЕРМІНОВАНОГО — НЕМАЄ ПОВІДОМЛЕННЯ. Порожній звіт — шум, від якого вимикають бота.
5. КАНАЛ — ТОЙ САМИЙ СУДДЯ, що й у зведення: телеграм, інакше пошта (686), інакше — названо в журналі.
6. НІКОЛИ НЕ КИДАЄ НАГОРУ: фоновий потік не сміє зупинити платформу.
"""
import sys

import clock
import config
import one_writer

DESK_DIR = config.STATE_DIR / "taskdesk"
config.refuse_live_state_for_checks(__name__)

MARK = DESK_DIR / "evening_marks.json"
PAGE = "/evening"

# Названа година: увечері, наприкінці робочого дня.
HOUR = 18
SLEEP_SEC = 300


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def overdue_of_others(emp_id: str) -> list:
    """Протерміновані задачі ІНШИХ виконавців, які ця людина бачить (ворота екрана задач)."""
    import taskdesk_tasks as tasks
    try:
        data = tasks.board(emp_id, scope="overdue", show_closed=False)
    except Exception:
        return []
    out = []
    for col in data.get("columns") or []:
        for t in col.get("tasks") or []:
            if _s(t.get("assignee_id")) and _s(t.get("assignee_id")) != _s(emp_id):   # протерміноване — судить відбір дошки
                out.append(t)
    return out


def page_url() -> str:
    """Посилання на екран вечірнього контролю — за адресою, якою люди справді заходять (699)."""
    try:
        import access_letter
        base = _s(access_letter.public_url()).rstrip("/")
    except Exception:
        base = ""
    return (base + PAGE) if base else ""


def text_for(rows: list, url: str = "") -> str:
    people = sorted({_s(t.get("assignee_name")) or "без імені" for t in rows})
    head = "Вечірній контроль: протерміновано задач — %d (виконавців: %d)." % (len(rows), len(people))
    who = "Хто: " + ", ".join(people[:8]) + (" і ще %d" % (len(people) - 8) if len(people) > 8 else "") + "."
    tail = ("Відкрити список: " + url) if url else "Список — у Task Desk: «Вечірній контроль»."
    return "\n".join([head, who, tail])


def _marks() -> dict:
    try:
        m = one_writer.read_json(MARK)
        return m if isinstance(m, dict) else {}
    except PermissionError:
        raise
    except Exception:
        return {}


def due_now(now: str = "") -> bool:
    now = now or clock.now()
    try:
        return int(str(now)[11:13]) >= HOUR
    except Exception:
        return False


def sweep(send=None, mail=None, now: str = "") -> dict:
    """Розіслати вечірній контроль тим, у кого в полі зору протерміноване інших. Що сталося — словами."""
    import taskdesk_people as people
    import taskdesk_telegram as mouth
    send = send or mouth._send
    now = now or clock.now()
    today = now[:10]
    marks = _marks()
    url = page_url()
    stat = {"people": 0, "sent": 0, "no_channel": 0, "failed": 0, "empty": 0, "already": 0}
    changed = False
    for emp in people.employees(True):
        eid = emp["id"]
        if marks.get(eid) == today:
            stat["already"] += 1
            continue
        rows = overdue_of_others(eid)
        if not rows:
            stat["empty"] += 1
            continue
        stat["people"] += 1
        chat = mouth.chat_of(eid)
        address = ""
        if not chat:
            try:
                import taskdesk_email as _letters
                kind, addr, _why = _letters.channel_of(eid)
                address = addr if kind == _letters.CH_EMAIL else ""
            except Exception:
                address = ""
        if not chat and not address:
            stat["no_channel"] += 1
            sys.stderr.write("[вечірній контроль] %s: ні телеграма, ні пошти — повідомлення нікуди не йде\n"
                             % (emp.get("full_name") or eid))
            continue
        try:
            if chat:
                ok = send(chat, text_for(rows, url))
            else:
                if mail is None:
                    import notify_mail as _nm
                    mail = _nm.send
                ok = mail(address, "SensFlow: вечірній контроль — протерміновані задачі", text_for(rows, url))
        except Exception as ex:
            ok = False
            sys.stderr.write("[вечірній контроль] %s: не надіслано (%s)\n" % (eid, ex))
        if not ok:
            stat["failed"] += 1
            continue
        marks[eid] = today
        changed = True
        stat["sent"] += 1
    if changed:
        DESK_DIR.mkdir(parents=True, exist_ok=True)
        one_writer.write_json(MARK, marks)
    return stat


def loop(sleep_sec: int = SLEEP_SEC):
    """Фоновий потік. Окремий від зведення: поломка одного не зупиняє іншого."""
    import time
    while True:
        try:
            if due_now():
                st = sweep()
                if st["sent"]:
                    print("[вечірній контроль] надіслано: %d" % st["sent"])
        except Exception as ex:
            sys.stderr.write("[вечірній контроль] спіткнулось: %s\n" % ex)
        time.sleep(sleep_sec)
