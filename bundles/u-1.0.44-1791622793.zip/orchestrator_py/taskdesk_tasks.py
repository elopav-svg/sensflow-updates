# -*- coding: utf-8 -*-
"""
taskdesk_tasks.py — САМА ЗАДАЧА: склад, стадії, стрічка, терміни, видимість.

Етап 2 Task Desk. Рішення, за якими це збудовано, — у памʼяті проєкту
(`project_taskdesk_domain`, `project_taskdesk_design`), узгоджені з Андрієм
02-06.08.2026. Уклад файла той самий, що в `taskdesk_people.py` і `scheduler.py`:
ОДИН НОРМАЛІЗАТОР · ОДИН ЧИТАЧ · ОДИН ПИСАР + слід у `audit[]`.

⭐⭐⭐ ЧОТИРИ РІШЕННЯ, ЯКІ ТУТ ВТІЛЕНІ ЯК ВОРОТА, А НЕ ЯК ПРОХАННЯ:

1. **ОДНА ФУНКЦІЯ ВИДИМОСТІ — `visible_ids()`.** Список, дошка, фільтр, пошук,
   картка і майбутні звіти питають ЇЇ. Видимість, розсипана по екранах, — той
   самий клас, що ворота лише на першому вході.

2. **ТЕРМІН МАЄ ОДНОГО ПИСАРЯ.** На диску лежить лише той термін, який ввела
   ЛЮДИНА. Порожній — ОБЧИСЛЮЄТЬСЯ з пунктів чек-листа при читанні
   (`due_effective`). Пункт із терміном за межею задачі — відмова з причиною.

3. **ЗАВЕРШИТИ БЕЗ РЕЗУЛЬТАТУ НЕ МОЖНА.** Результат — це ВКАЗІВНИК на коментар
   у стрічці (`result_comment_id`), а не копія його тексту: копія була б другим
   писарем однієї правди.

4. **ПРОТЕРМІНУВАННЯ — ОЗНАКА ПОВЕРХ СТАДІЇ, А НЕ СТАДІЯ.** Задача лишається
   там, де вона є, і горить червоним. Обчислюється при читанні, на диск не лягає.

⚠ МОЗОК (LLM) СЮДИ НЕ ХОДИТЬ. Стадії, права, терміни, звʼязки й закриття —
логічні скрипти. Єдиний майбутній міст до мозку — окремий `taskdesk_ai.py`
(рішення 21). Цей файл не імпортує ні `llm`, ні `agent`, ні `executor` — це
перевіряє чек деревом коду.
"""

import json
import re
from pathlib import Path

import clock                      # ОДИН ПИСАР ЧАСУ на весь продукт
import config
import taskdesk_events as events   # НЕРВ: журнал подій і черга ротів
import taskdesk_people as people
import taskdesk_worktypes as worktypes
import taskdesk_templates as templates   # ⭐ 707: шаблони пояснень і запитів (один суддя полів)
import projects                    # ⭐ ПРОЄКТИ — теки робочих напрямів (оркестратор, 30.06.2026)
import taskdesk_projects as tprj   # ⭐ 705: ОДИН суддя проєкту в Task Desk (видимість, стан)
import entity                      # спільне імʼя сутності на всю платформу
import protocol                    # ЗАГАЛЬНИЙ журнал усіх дій (хребет, 13.08.2026)
import links                       # ⭐ РЕЄСТР ЗВʼЯЗКІВ — один на всі шари (крок B2)
import taskdesk_links as tlinks    # СЛОВА, якими звʼязок читається людині (172 → B2)
import one_writer

# ⭐ ОДИН ПИСАР ШЛЯХУ: теку стану Task Desk оголошує нерв, тут лише беремо.
DESK_DIR = events.DESK_DIR

# ⛒ ДРУГИЙ ЗАМОК (27.08.2026): чек, завантажений не через файл, не сміє
# працювати по бойовому стану — тут лежать живі люди, ролі й задачі.
config.refuse_live_state_for_checks(__name__)
TASKS_DIR = DESK_DIR / "tasks"
# ⛒ АРХІВ (зміна 279, 29.08.2026). Закрита задача коштувала стільки ж, скільки
# жива, і коштувала ВІЧНО: щоденний екран читає кожен файл. Тому закриті
# задачі, яким більше ARCHIVE_AFTER_DAYS днів, переїжджають сюди й зникають із
# повсякденного читання. ЗАКОН: задача існує РІВНО В ОДНОМУ МІСЦІ.
ARCHIVE_DIR = DESK_DIR / "archive"
ARCHIVE_AFTER_DAYS = 30

AUDIT_KEEP = 200

# ---------------------------------------------------------------------------
# СТАДІЇ. Основна лінія + дві збоку. Протермінування стадією НЕ Є.
# ---------------------------------------------------------------------------
STAGE_NEW = "new"
STAGE_WORK = "in_work"
STAGE_REVIEW = "review"
STAGE_DONE = "done"
STAGE_HOLD = "postponed"
STAGE_CANCEL = "cancelled"
# ⭐⭐⭐ 706 (проєкт розробки ОТУ, 3.4). «НЕ ПРОЙШЛА ПЕРЕВІРКУ» — СТАДІЯ, А НЕ ПОЗНАЧКА.
# Доти повернення на доопрацювання було стадією «У роботі» і коментарем: через тиждень
# не видно, що задача провалювала перевірку, і повернути можна було без жодного слова.
# ⛒ Це окремий стан зі своїми переходами: увійти — ЛИШЕ «Не прийняти» з причиною
# (`reject`), вийти в роботу — ЛИШЕ поясненням виконавця (`explain`); постановник може
# відкласти чи скасувати. Прямої дороги через `set_stage` немає ні в той бік, ні в інший:
# інакше та сама дія мала б двоє дверей, і одні з них не лишали б сліду провалу.
# ⚠ ОСНОВНА ЛІНІЯ ЛИШАЄТЬСЯ З ЧОТИРЬОХ стадій (3.3: колонки власника належать до них);
# ця стадія — повернення з перевірки, у правах і строках вона жива, як «У роботі».
STAGE_FAILED = "failed"

STAGES_MAIN = (STAGE_NEW, STAGE_WORK, STAGE_REVIEW, STAGE_DONE)
STAGES_RETURN = (STAGE_FAILED,)
STAGES_SIDE = (STAGE_HOLD, STAGE_CANCEL)
# Порядок — той, у якому людина читає дошку: здали → не прийняли → завершили.
STAGES_ALL = (STAGE_NEW, STAGE_WORK, STAGE_REVIEW, STAGE_FAILED, STAGE_DONE) + STAGES_SIDE
STAGES_CLOSED = (STAGE_DONE, STAGE_CANCEL)

STAGE_NAMES = {
    STAGE_NEW: "Нова",
    STAGE_WORK: "У роботі",
    STAGE_REVIEW: "На перевірці",
    STAGE_FAILED: "Не пройшла перевірку",
    STAGE_DONE: "Завершена",
    STAGE_HOLD: "Відкладена",
    STAGE_CANCEL: "Скасована",
}

# ⭐⭐ 733 «СТРОК» (побажання Каспера): закритий словник у порядку часу. Значення рахує
# `_due_when`; підписи — тут, і їх бере реєстр полів (фільтр, колонка, Excel).
DUE_OVERDUE, DUE_THIS_WEEK, DUE_NEXT_WEEK = "overdue", "this_week", "next_week"
DUE_WHEN = (DUE_OVERDUE, DUE_THIS_WEEK, DUE_NEXT_WEEK)
DUE_WHEN_NAMES = {DUE_OVERDUE: "Протерміновані", DUE_THIS_WEEK: "На цьому тижні",
                  DUE_NEXT_WEEK: "На наступному тижні"}

# ⭐⭐ 734 ПРІОРИТЕТ (побажання Каспера): закритий словник у порядку Андрія. На диску —
# код; назва рахується (`priority_name`). Старий запис без поля — «Стандартний».
PRIORITY_IMPORTANT, PRIORITY_URGENT, PRIORITY_STANDARD = "important", "urgent", "standard"
PRIORITIES = (PRIORITY_IMPORTANT, PRIORITY_URGENT, PRIORITY_STANDARD)
PRIORITY_NAMES = {PRIORITY_IMPORTANT: "Важлива", PRIORITY_URGENT: "Термінова",
                  PRIORITY_STANDARD: "Стандартний"}

# ⭐⭐⭐ 706 (3.6). «Я ЗРОЗУМІВ ЗАДАЧУ». Підтвердження — запис `ack` у файлі задачі:
# для КОГО він (`for`), у якому стані (`pending` · `clarify` · `understood`), відколи
# чекає (`since`), скільки разів просили уточнення (`asked`) і чи сторож уже сказав
# постановнику про незрозумілу задачу (`unclear_at`).
# ⭐ «Для кого» — та сама рівність, що й у перевірки: змінився виконавець — старе
# підтвердження не про нього, і воно перестає діяти саме. Новий запис на нового
# виконавця пише ОДИН писар — `save()`, хоч би якими дверима виконавця змінили.
# ⚠ Порожнє поле = сьогоднішня поведінка: старі задачі (до 706) і задачі собі
# підтвердження не просять.
ACK_PENDING = "pending"
ACK_CLARIFY = "clarify"
ACK_UNDERSTOOD = "understood"
ACK_ANSWERED = "answered"      # лише похідне: постановник відповів на питання
ACK_UNCLEAR_HOURS = 24         # стільки без підтвердження — «незрозуміла задача»

# Ролі людини в задачі. Порядок важливий: сильніша роль перемагає слабшу.
ROLE_AUTHOR = "author"          # постановник
ROLE_ASSIGNEE = "assignee"      # виконавець — ОДИН, уся відповідальність на ньому
ROLE_CO = "coassignee"          # співвиконавець — РЕСУРС, доданий постановником
ROLE_VERIFIER = "verifier"      # перевіряючий — НЕОБОВʼЯЗКОВА ланка, див. нижче
ROLE_WATCHER = "watcher"        # спостерігач — перегляд і коментарі, і все

ROLE_NAMES = {
    ROLE_AUTHOR: "постановник",
    ROLE_ASSIGNEE: "виконавець",
    ROLE_CO: "співвиконавець",
    ROLE_VERIFIER: "перевіряючий",
    ROLE_WATCHER: "спостерігач",
}

# ---------------------------------------------------------------------------
# ⭐⭐⭐ ПЕРЕВІРКА РЕЗУЛЬТАТУ — НЕОБОВʼЯЗКОВА ЛАНКА (зміна 207, 24.08.2026).
#
# ⛒ ГОЛОВНЕ ПРАВИЛО, ЯКЕ НЕ ОБГОВОРЮЄТЬСЯ: **порожнє поле = сьогоднішня
# поведінка**. Немає перевіряючого — приймання рівно таке, як було: виконавець
# позначив результат, постановник прийняв. Слова Андрія 24.08: платформа
# економить робочий час, а не робить із себе священну корову з довгими
# ланцюгами узгоджень. Тому ланка вмикається ТОЧКОВО, там, де вона потрібна
# (партія виробу — ОТК, договір — юрист), а не «для всієї компанії».
#
# ⭐ ПЕРЕВІРКА ЗАСВІДЧУЄ КОНКРЕТНИЙ РЕЗУЛЬТАТ, А НЕ ЗАДАЧУ ВЗАГАЛІ. Тому на
# диску лежить `verified_result_id` — ЯКИЙ саме результат перевірено, — а не
# прапорець «перевірено». Виконавець позначив НОВИЙ результат — стара перевірка
# більше не збігається з ним і перестає діяти САМА, без жодного коду зняття.
# Прапорець довелось би знімати руками в кожному місці, де зʼявляється новий
# результат, і перше ж забуте місце видало б чужу перевірку за свіжу.
#
# ⛒ SoD (розподіл обовʼязків): перевіряючим не може бути ні виконавець, ні
# співвиконавець — інакше людина перевіряє сама себе, і перевірка нічого не
# варта. Це правило ДАНИХ (кого можна записати в поле), а не прав: запасні
# двері адміністратора нікуди не зникають — він міняє перевіряючого і йде далі.
# ---------------------------------------------------------------------------

# ⭐ Рішення 25, вузький варіант: якщо підлеглий у задачі ЛИШЕ спостерігач,
# керівникові вона не показується — інакше через одного спостерігача керівникові
# заїдуть задачі чужих підрозділів. Одна константа = одне місце, де це
# перемикається, якщо Андрій вирішить інакше.
MANAGER_SEES_WATCHER_ONLY = False

# ⭐ ПРОПОЗИЦІЯ МОЗКУ — це ПРОХАННЯ, а не дія. Стан у неї свій, щоб та сама
# порада не спливала щоразу, коли її вже відхилили.
PROPOSAL_DUE = "due"                 # «посунути термін до …»
PROPOSAL_ACCEPT = "acceptance"       # «за чим приймемо результат»
PROPOSAL_KINDS = (PROPOSAL_DUE, PROPOSAL_ACCEPT)
PROPOSAL_OPEN = "open"
PROPOSAL_ACCEPTED = "accepted"
PROPOSAL_DECLINED = "declined"
AI_ACTOR = "ai"                      # автор запису, який зробив мозок

# Похідні поля: ОБЧИСЛЮЮТЬСЯ при читанні й НІКОЛИ не лежать на диску.
DERIVED = ("broken", "broken_reason", "due_effective", "due_source", "overdue", "due_when",
           "priority_name",
           "stage_name", "author_name", "assignee_name", "participant_ids",
           "checklist_done", "checklist_total", "result_text", "days_left",
           "open_proposals", "has_proposal", "links", "links_in",
           # ⭐ «перевірено» НЕ ЗБЕРІГАЄТЬСЯ, а РАХУЄТЬСЯ: перевірка чинна лише
           # доти, доки результат той самий, який перевіряли.
           "verified", "awaiting_verify", "verifier_name",
           # ⭐ «Сира» РАХУЄТЬСЯ, а не зберігається: дописали критерій —
           # ознака зникла сама. Прапорець на диску довелося б гасити руками,
           # і він жив би своїм життям.
           "unready", "unready_why", "for_other",
           # ⭐ Числа стандарту готовності РАХУЮТЬСЯ, назва типу — теж: на диску
           # лежать самі пункти зі знімка й номер типу. Зберігати назву означало
           # б, що перейменування типу лишає в задачі вчорашнє слово.
           "dod_total", "dod_done", "dod_left", "worktype_name",
           # ⭐ «Звірка свіжа» РАХУЄТЬСЯ, а не зберігається: вона чинна доти,
           # доки результат той самий, який звіряли. Прапорець довелося б
           # гасити руками в кожному місці, де зʼявляється новий результат.
           "match_fresh",
           # ⭐ «archived» РАХУЄТЬСЯ з того, у якій теці лежить файл, а не
           # зберігається в ньому. Прапорець на диску розійшовся б із місцем
           # файла в першу ж мить, коли задачу повернули з архіву (зміна 280).
           "archived",
           # ⭐ ЗАТОРИ. «Скільки стоїть» і «чи стоїть» РАХУЮТЬСЯ: обидва цілком
           # виводяться з дати останнього руху, і зберігати їх означало б
           # завести поле, яке треба щодня оновлювати руками або будильником.
           "idle_days", "stuck",
           # ⭐ ЗАЛЕЖНОСТІ (зміна 242). «Чого чекаю», «кого тримаю» і «чи це
           # вже павутина» РАХУЮТЬСЯ з реєстру звʼязків і стадій тих задач.
           # Зберігати їх означало б, що закриття однієї задачі мусить піти й
           # переписати файли всіх, хто на неї чекав, — і перший же пропущений
           # прохід лишив би на екрані вчорашню перепону.
           "waiting", "waiting_for", "holding", "hard_links", "link_web",
           # ⭐ «Перевіряє керівник» — теж похідне: оргструктура міняється, і
           # збережений прапорець назавтра казав би неправду.
           "verifier_boss",
           # ⭐ 706. Лічильник провалів — довжина переліку провалів, а не окреме
           # число: два писарі одного факту розійшлися б. «Чи можна не прийняти»,
           # стан підтвердження і «незрозуміла» — з поточної стадії, виконавця й годинника.
           "failed_count", "rejectable", "ack_state", "unclear",
           # ⭐ 708. Етапи: склад, хід роботи, «чи вкладається», чий я етап і кого чекаю —
           # з реєстру звʼязків і стадій етапів. Збережене назавтра брехало б: закриття
           # етапу мусило б переписати файли всіх сусідів.
           "steps", "steps_total", "steps_done", "step_now", "steps_fit",
           "step_of", "step_wait", "early_count",
           # ⭐ 709. Колонка, де задача стоїть на дошці, і її назва — з колонок проєкту й
           # стадії задачі: колонку перейменували чи прибрали — задача це бачить одразу.
           "column_id", "column_name")

# ⭐⭐⭐ КРОК B2 (14.08.2026): `links` СТАЛО ПОХІДНИМ І БІЛЬШЕ НЕ ЛЕЖИТЬ У ФАЙЛІ
# ЗАДАЧІ. Факт звʼязку живе в реєстрі `links.py` — бо він не є власністю жодної
# зі сторін. Обидва боки (`links` — куди веду я, `links_in` — хто веде до мене)
# читаються ОДНИМ запитом до реєстру, а не перебором усіх файлів задач.
# ⚠ Задача, у файлі якої ще лежить СТАРЕ поле `links`, оголошується ЗЛАМАНОЮ з
# причиною словами: мовчки прочитати його як правду означало б завести другого
# писаря звʼязків, а мовчки викинути — загубити роботу людини. Лікує це переїзд
# (`migrate_links.py`), і задача сама скаже, що його не робили.


class TaskError(Exception):
    """Відмова з причиною словами. Тиха відмова = вимкнені ворота."""


def _s(v) -> str:
    return "" if v is None else str(v).strip()


def _ids(v) -> list:
    out, seen = [], set()
    for x in (v or []):
        x = _s(x)
        if x and x not in seen:
            seen.add(x)
            out.append(x)
    return out


# ---------------------------------------------------------------------------
# ЧАС І ТЕРМІНИ
# ---------------------------------------------------------------------------
DUE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}(?:[T ]\d{2}:\d{2})?$")


def _norm_due(v) -> str:
    """Термін на диску — машинний рядок `YYYY-MM-DD` або `YYYY-MM-DDTHH:MM`.
    Людині його показує екран у форматі DD.MM.YYYY — перетворення живе там,
    у файлі стану дата лежить в одному вигляді."""
    s = _s(v).replace(" ", "T")
    if not s:
        return ""
    if not DUE_RE.match(s):
        raise TaskError("Термін «%s» не схожий на дату. Приклад: 2026-08-15 17:00" % v)
    return s


def due_from_human(text) -> str:
    """Дата, набрана людиною (DD.MM.YYYY або DD.MM.YYYY HH:MM), -> машинна.
    Порожньо, якщо це не дата.

    ЗІРКА. ОДИН ПИСАР РОЗУМІННЯ ДАТИ. Він знадобився телефону (у телеграмі
    немає нашого календаря), але живе ТУТ, поруч із `_norm_due`: щойно дату
    почне розбирати ще й пошта чи голосовий бот, вони питатимуть це саме
    місце, а не заведуть свій формат.
    """
    v = " ".join(_s(text).replace("/", ".").split())
    m = re.match(r"^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s+(\d{1,2}):(\d{2}))?$", v)
    if not m:
        # ⭐ 26.08.2026: той самий писар тепер розуміє й ЛЮДСЬКІ форми
        # («завтра», «у пʼятницю», «через 3 дні») — але лише коли ДАТОЮ Є
        # ВЕСЬ рядок. Тут питають «чи це дата?», а не «чи є тут дата?»:
        # друге вміє `find_due_in`, і плутати їх не можна — інакше поле
        # терміну почало б ковтати цілі речення.
        iso, phrase, _at = find_due_in(v)
        return iso if iso and phrase.strip().lower() == v.strip().lower() else ""
    d, mo, y = int(m.group(1)), int(m.group(2)), int(m.group(3))
    hh, mm = int(m.group(4) or 0), int(m.group(5) or 0)
    from datetime import datetime          # як і решта дат у цьому файлі
    try:
        datetime(y, mo, d, hh, mm)
    except ValueError:
        return ""            # 31.02.2026 — не дата
    # УВАГА, дорого куплено 09.08.2026: тут стояло `except Exception`, і воно
    # проковтнуло NameError від незробленого імпорту. Функція мовчки повертала
    # «це не дата» НА ВСЕ, і жодного сліду не лишалось. Мовчазний except ховає
    # не лише чужу помилку, а й твою власну — тому ловимо РІВНО ValueError.
    out = "%04d-%02d-%02d" % (y, mo, d)
    return out + ("T%02d:%02d" % (hh, mm) if (hh or mm) else "")


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЛЮДСЬКІ ФОРМИ СТРОКУ (зміна 223, 26.08.2026).
#
# ⛒ ЧОМУ ТУТ, А НЕ В НОВОМУ ФАЙЛІ. Розуміння дати в продукті має РІВНО ОДНОГО
# писаря — його вже питає телеграм, а завтра питатимуть пошта й голос. Другий
# писар слова «завтра» означав би, що за місяць екран і пошта розуміють його
# по-різному, і жоден чек цього не побачить.
#
# ⛒ ФОРМИ ДНІВ ТИЖНЯ ВИПИСАНІ ПОІМЕННО, А НЕ ШАБЛОНОМ `серед\w*`. Шаблон ловив
# би «середовище» і «середній» — тобто ставив би строк там, де людина про строк
# не казала. Перелік довший, зате він не бреше.
# ---------------------------------------------------------------------------
_WEEKDAY_OF = {}
for _i, _forms in enumerate((
        ("понеділок", "понеділка", "понеділку"),
        ("вівторок", "вівторка", "вівторку"),
        ("середа", "середу", "середи"),
        ("четвер", "четверга", "четвергу"),
        ("пʼятниця", "пʼятницю", "пʼятниці",
         "п'ятниця", "п'ятницю", "п'ятниці",
         "п\u2019ятниця", "п\u2019ятницю", "п\u2019ятниці",
         "пятниця", "пятницю", "пятниці"),
        ("субота", "суботу", "суботи"),
        ("неділя", "неділю", "неділі"))):
    for _f in _forms:
        _WEEKDAY_OF[_f] = _i

# Прийменник іде В СКЛАД знайденої фрази — щоб «до завтра» зникало з назви
# цілком, а не лишало висіти «до».
_PREP = r"(?:\b(?:до|на|у|в)\s+)?"

_NUM_DATE = re.compile(r"(?:\b(?:до|на)\s+)?\b(\d{1,2})[.\-/](\d{1,2})(?:[.\-/](\d{2,4}))?\b")
_HUMAN_DAY = re.compile(_PREP + r"\b(сьогодні|завтра|післязавтра)\b", re.I)
_HUMAN_IN = re.compile(r"\bчерез\s+(\d{1,2})\s+(день|дні|днів|тиждень|тижні|тижнів)\b", re.I)
_HUMAN_WD = re.compile(_PREP + r"\b(" + "|".join(sorted(_WEEKDAY_OF, key=len, reverse=True)) + r")\b", re.I)
_TIME_AFTER = re.compile(r"\s+(?:о|об)\s+(\d{1,2})(?::(\d{2}))?\b", re.I)


def find_due_in(text, today: str = ""):
    """Знайти НАЗВАНИЙ СТРОК усередині речення.

    Повертає (машинна дата, фраза людини, (від, до)) або ("", "", None).
    ⛒ Нічого не вгадує: не знайшов — каже «не знайшов», а не «мабуть, завтра»."""
    t = _s(text)
    today = _s(today) or clock.now()[:10]
    from datetime import datetime, timedelta
    try:
        base = datetime.strptime(today[:10], "%Y-%m-%d")
    except ValueError:
        return "", "", None
    if not t:
        return "", "", None

    best = None
    m = _NUM_DATE.search(t)
    if m:
        try:
            d, mo = int(m.group(1)), int(m.group(2))
            y = m.group(3)
            if y:
                y = int(y)
                y += 2000 if y < 100 else 0
                dt = datetime(y, mo, d)
            else:
                dt = datetime(base.year, mo, d)
                # ⭐ «15.09» без року, а він уже минув — людина каже про
                # НАСТУПНИЙ рік. Строк у минулому не є строком.
                if dt < base:
                    dt = datetime(base.year + 1, mo, d)
            best = (m.start(), m.end(), dt)
        except ValueError:
            best = None            # 31.02 або версія «1.0.24» — це не дата
    if best is None:
        m = _HUMAN_DAY.search(t)
        if m:
            add = {"сьогодні": 0, "завтра": 1, "післязавтра": 2}[m.group(1).lower()]
            best = (m.start(), m.end(), base + timedelta(days=add))
    if best is None:
        m = _HUMAN_IN.search(t)
        if m:
            unit = m.group(2).lower()
            step = 7 if unit.startswith("тиж") else 1
            best = (m.start(), m.end(), base + timedelta(days=int(m.group(1)) * step))
    if best is None:
        m = _HUMAN_WD.search(t)
        if m:
            wd = _WEEKDAY_OF.get(m.group(1).lower())
            if wd is not None:
                # найближчий ТАКИЙ день попереду; сьогоднішній — означає за тиждень
                ahead = (wd - base.weekday()) % 7 or 7
                best = (m.start(), m.end(), base + timedelta(days=ahead))
    if best is None:
        return "", "", None

    a, b, dt = best
    hh = mm = 0
    tm = _TIME_AFTER.match(t, b)
    if tm:
        _h, _m = int(tm.group(1)), int(tm.group(2) or 0)
        if _h <= 23 and _m <= 59:
            hh, mm, b = _h, _m, tm.end()
    iso = dt.strftime("%Y-%m-%d")
    if hh or mm:
        iso += "T%02d:%02d" % (hh, mm)
    return iso, t[a:b], (a, b)


def _due_key(s: str) -> str:
    """Порівнюваний вигляд: дата без часу означає кінець того дня."""
    s = _s(s)
    if not s:
        return ""
    return s if "T" in s else s + "T23:59"


# ---------------------------------------------------------------------------
# ОДИН НОРМАЛІЗАТОР
# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЗВІРКА РЕЗУЛЬТАТУ (зміна 236, 27.08.2026).
# На диску лежить ЩО ЗВІРЯЛИ (`result_id`) разом із самою звіркою — рівно як у
# перевірки (`verified_result_id`). Виконавець здав НОВИЙ результат — стара
# звірка перестає збігатися з ним і гасне САМА, без жодного коду зняття.
# ⛔ Вироку тут немає й бути не може: три поля — що просили, що здали, чого не
# видно. Приймає людина.
def _match(raw) -> dict:
    if not isinstance(raw, dict):
        return {}
    rid = _s(raw.get("result_id"))
    asked = _s(raw.get("asked"))
    given = _s(raw.get("given"))
    if not (rid and asked and given):
        return {}
    missing = [_s(x) for x in (raw.get("missing") or []) if _s(x)]
    return {"result_id": rid, "asked": asked, "given": given,
            "missing": missing, "at": _s(raw.get("at"))}


def _ack_record(raw) -> dict:
    """Запис підтвердження (706) — повний або порожній. Порожній = не просимо."""
    if not isinstance(raw, dict) or not _s(raw.get("for")):
        return {}
    state = _s(raw.get("state"))
    if state not in (ACK_PENDING, ACK_CLARIFY, ACK_UNDERSTOOD):
        state = ACK_PENDING
    try:
        asked = max(0, int(raw.get("asked") or 0))
    except (TypeError, ValueError):
        asked = 0
    return {"for": _s(raw.get("for")), "state": state, "since": _s(raw.get("since")),
            "at": _s(raw.get("at")), "question_id": _s(raw.get("question_id")),
            "asked": asked, "unclear_at": _s(raw.get("unclear_at"))}


def _normalize(raw, tid: str) -> dict:
    """Будь-який запис, хоч побитий, виходить звідси з повним набором полів.
    Зламаність — ОЗНАКА, а не окреме життя й не тиша."""
    broken, reason = False, ""
    if not isinstance(raw, dict):
        broken, reason, raw = True, "файл задачі не є записом", {}

    t = {
        "id": _s(raw.get("id")) or tid,
        "title": _s(raw.get("title")),
        "description": _s(raw.get("description")),
        "author_id": _s(raw.get("author_id")),
        "assignee_id": _s(raw.get("assignee_id")),
        "coassignee_ids": _ids(raw.get("coassignee_ids")),
        # ⭐ Перевіряючий (необовʼязково) і ЯКИЙ САМЕ результат він перевірив.
        # Старі задачі приходять сюди з порожніми полями — і поводяться точно
        # так, як поводились: перевірки в них немає.
        "verifier_id": _s(raw.get("verifier_id")),
        "verified_result_id": _s(raw.get("verified_result_id")),
        "watcher_ids": _ids(raw.get("watcher_ids")),
        "stage": _s(raw.get("stage")) or STAGE_NEW,
        # ⭐ 734: старий запис без пріоритету (чи з невідомим) — «Стандартний».
        "priority": (_s(raw.get("priority")) if _s(raw.get("priority")) in PRIORITIES
                     else PRIORITY_STANDARD),
        "due_at": _s(raw.get("due_at")),
        "checklist": [],
        "feed": [],
        "proposals": [],          # що ПРОПОНУЄ мозок; сам він нічого не змінює
        # ⭐ ФАКТ ПРОТЕРМІНУВАННЯ ЛЕЖИТЬ НА ДИСКУ (зміна 172): `overdue_at` — коли
        # платформа ПОБАЧИЛА перетин строку, `overdue_for` — ЯКИЙ саме строк було
        # перетнуто. Друге потрібне, щоб посунутий термін давав НОВИЙ факт, а не
        # мовчав під старою позначкою.
        "overdue_at": _s(raw.get("overdue_at")),
        "overdue_for": _s(raw.get("overdue_for")),
        "source": _s(raw.get("source")),          # звідки прийшла: crm, telegram, ...
        "source_ref": _s(raw.get("source_ref")),
        # ⭐ ПРОЄКТ (01.09.2026). Старі задачі приходять сюди з порожнім полем —
        # і поводяться точно так, як поводились: проєкту в них немає.
        "project_id": _s(raw.get("project_id")),
        "result_comment_id": _s(raw.get("result_comment_id")),
        "match": _match(raw.get("match")),
        "refusal_reason": _s(raw.get("refusal_reason")),
        # ⭐⭐ КРИТЕРІЙ ПРИЙМАННЯ (зміна 223): ЗА ЧИМ ми зрозуміємо, що
        # зроблено. ⛒ Це НЕ чек-лист: чек-лист каже ЯК робити, критерій —
        # ЗА ЧИМ приймемо. Одне поле на два смисли зробило б беззмістовними
        # обидва, а перевіряючому (ворота 3) звіряти результат було б ні з чим.
        "acceptance": _s(raw.get("acceptance")),
        # ⭐⭐ СТАНДАРТ ГОТОВНОСТІ (зміна 225): тип роботи і ЗНІМОК його пунктів,
        # зроблений у мить створення задачі. Знімок, а не посилання: правка
        # довідника не сміє заднім числом робити вчорашню прийняту роботу
        # неготовою. ⛒ Це НЕ чек-лист (той каже ЯК робити) і НЕ критерій
        # приймання (той про ЦЮ задачу) — це «що означає готово для роботи
        # такого типу».
        "worktype_id": _s(raw.get("worktype_id")),
        "dod": [],
        # ⭐ 706: провали перевірки (назавжди) і підтвердження виконавця.
        "failures": [],
        "ack": _ack_record(raw.get("ack")),
        # ⭐ 708 (3.5). Велика задача з етапами: `stepped` — її підзадачі є ЕТАПАМИ (по черзі),
        # `step_order` — лише ПОРЯДОК (склад етапів — у реєстрі звʼязків, «підзадача»);
        # `early` — записи «почато раніше попереднього» з поясненням за шаблоном.
        "stepped": bool(raw.get("stepped")),
        "step_order": _ids(raw.get("step_order")),
        "early": [e for e in (raw.get("early") or []) if isinstance(e, dict)],
        # ⭐ 709 (3.3). Власна колонка дошки проєкту (порожньо — основна колонка стадії).
        # Чинна, лише доки задача в стадії цієї колонки і в її проєкті (`_column_of`).
        "column": _s(raw.get("column")),
        "created_at": _s(raw.get("created_at")),
        "updated_at": _s(raw.get("updated_at")),
        "audit": [a for a in (raw.get("audit") or []) if isinstance(a, dict)][-AUDIT_KEEP:],
    }

    # ⭐ СТАРЕ ПОЛЕ НА ДИСКУ — ЦЕ НЕ ДАНІ, ЦЕ НЕЗАВЕРШЕНИЙ ПЕРЕЇЗД (крок B2).
    # Прочитати його як правду означало б мати ДВОХ писарів звʼязку (файл і
    # реєстр) — рівно те, на чому ми горіли 09-11.08. Промовчати — загубити
    # роботу людини. Тому задача каже про це вголос, а лікує `migrate_links.py`.
    if raw.get("links"):
        broken = True
        reason = reason or ("звʼязки задачі ще не переїхали до реєстру — "
                            "запустіть `migrate_links.py --apply`")

    if t["stage"] not in STAGES_ALL:
        broken, reason = True, "невідома стадія «%s»" % t["stage"]
        t["stage"] = STAGE_NEW
    if not t["title"]:
        broken, reason = True, reason or "у задачі немає назви"

    for i, raw_item in enumerate(raw.get("checklist") or []):
        if not isinstance(raw_item, dict):
            continue
        t["checklist"].append({
            "id": _s(raw_item.get("id")) or ("c%d" % (i + 1)),
            "text": _s(raw_item.get("text")),
            "done": bool(raw_item.get("done")),
            "due_at": _s(raw_item.get("due_at")),
            "assignee_id": _s(raw_item.get("assignee_id")),
        })
    for i, raw_p in enumerate(raw.get("dod") or []):
        if not isinstance(raw_p, dict):
            continue
        if not _s(raw_p.get("text")):
            continue
        t["dod"].append({"id": _s(raw_p.get("id")) or ("p%d" % (i + 1)),
                         "text": _s(raw_p.get("text")),
                         "done": bool(raw_p.get("done"))})
    for i, raw_f in enumerate(raw.get("failures") or []):
        if not isinstance(raw_f, dict):
            continue
        t["failures"].append({
            "id": _s(raw_f.get("id")) or ("f%d" % (i + 1)),
            "at": _s(raw_f.get("at")),
            "by": _s(raw_f.get("by")),
            "reason": _s(raw_f.get("reason")),
            "result_id": _s(raw_f.get("result_id")),
            "explanation": _s(raw_f.get("explanation")),
            "explained_at": _s(raw_f.get("explained_at")),
            "explained_by": _s(raw_f.get("explained_by")),
            # ⭐ 707: відповіді шаблону пояснення (причина — вибором, а не словами).
            "tpl": raw_f.get("tpl") if isinstance(raw_f.get("tpl"), dict) else {},
        })
    for i, raw_c in enumerate(raw.get("feed") or []):
        if not isinstance(raw_c, dict):
            continue
        item = {
            "id": _s(raw_c.get("id")) or ("m%d" % (i + 1)),
            "author_id": _s(raw_c.get("author_id")),
            "text": _s(raw_c.get("text")),
            "at": _s(raw_c.get("at")),
            # comment | event | fail (706: провал перевірки і пояснення — червоним)
            "kind": _s(raw_c.get("kind")) or "comment",
        }
        # ⭐ 707: коментар за шаблоном несе відповіді окремо від тексту — їх рахують.
        if isinstance(raw_c.get("tpl"), dict) and raw_c["tpl"].get("id"):
            item["tpl"] = raw_c["tpl"]
        t["feed"].append(item)

    # ⭐ ПРОПОЗИЦІЇ МОЗКУ. Лежать поруч із задачею, але НІЧОГО в ній не міняють,
    # доки людина не натисне «Прийняти». Мозок не є писарем терміну.
    for i, raw_p in enumerate(raw.get("proposals") or []):
        if not isinstance(raw_p, dict):
            continue
        t["proposals"].append({
            "id": _s(raw_p.get("id")) or ("p%d" % (i + 1)),
            "kind": _s(raw_p.get("kind")) or PROPOSAL_DUE,
            "date": _norm_due(raw_p.get("date")),
            "text": _s(raw_p.get("text"))[:600],
            "why": _s(raw_p.get("why"))[:300],
            "quote": _s(raw_p.get("quote"))[:300],
            "from_comment": _s(raw_p.get("from_comment")),
            "at": _s(raw_p.get("at")),
            "state": _s(raw_p.get("state")) or PROPOSAL_OPEN,
            "decided_by": _s(raw_p.get("decided_by")),
        })

    # Результат мусить вказувати на існуючий коментар — інакше це не вказівник.
    if t["result_comment_id"] and not any(
            c["id"] == t["result_comment_id"] for c in t["feed"]):
        broken = True
        reason = reason or "результат указує на коментар, якого немає"
        t["result_comment_id"] = ""

    t["broken"] = broken
    t["broken_reason"] = reason
    return t


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЗАЛЕЖНОСТІ (зміна 242, 27.08.2026). ДРУГА ЗАБОРОНА ЗІ ЗВІТУ — У ВИДИМІСТЬ.
#
# Звіт (task-desk-product-guide, розділ 2.3) вимагав рівно двох речей:
# «ЗАБОРОНЯТИ брати завдання А в роботу, поки Б не перейде в Done» і
# «ОБМЕЖИТИ кількість жорстких звʼязків на одну задачу».
#
# ⛔ НЕ РОБИМО НІ ТОГО, НІ ТОГО. Рішення Андрія 27.08.2026: продукт має
# полегшувати роботу з задачами, а не навпаки. Заборона тут коштувала б
# дорожче за проблему: людина, якій платформа не дала працювати, працює ПОВЗ
# платформу — і тоді ми втрачаємо не одну задачу, а весь слід. Той самий урок,
# що з лімітом незавершеного: ліміт Андрій скасував, а видимість лишив.
#
# ⛒ ТОМУ ТЕ САМЕ ЗНАННЯ МИ ПОКАЗУЄМО: чого ця робота чекає, кого тримає сама
# і чи не перетворились звʼязки на павутину, де затримка однієї задачі тягне
# за собою всі. Дії при цьому лишаються ВСІ до одної.
# ---------------------------------------------------------------------------
HARD_RELS = (links.REL_SUBTASK_OF, links.REL_BLOCKS)

# ⚠ Скільки жорстких звʼязків — уже забагато. Число з досвіду, не з закону,
# і тому воно НІЧОГО НЕ ЗАБОРОНЯЄ: перевищення лише додає рядок на екран.
HARD_MAX = 5


def _alive_open(ref: str) -> bool:
    """Чи ця сутність існує і ще не закінчена. Питає `entity` — того самого,
    кого питає екран: два писарі відповіді «чи це вже зроблено» розійшлись би
    першого ж дня."""
    return bool(ref) and entity.exists(ref) and not entity.closed(ref)


def _blocking(t: dict) -> dict:
    """ЧОГО ЧЕКАЄ ЦЯ ЗАДАЧА І КОГО ТРИМАЄ САМА — ОДИН ПИСАР ФАКТУ.

    ⭐ Перепоною вважаємо лише ту задачу, що ІСНУЄ і ЩЕ НЕ ЗАКІНЧЕНА. Закрита
    не тримає нікого: показати її як перепону означало б лякати людину
    вчорашнім днем — а саме через це «блокує» досі й не наважувались показати.
    ⛒ І САМА ЗАКРИТА ЗАДАЧА НЕ ЧЕКАЄ НІ НА КОГО: вона закінчилась. Те саме
    правило, що й у затору, і з тієї ж причини.
    ⛒ Жодне з цих полів нічого не забороняє: усі вони — для ока."""
    both = list(t.get("links") or []) + list(t.get("links_in") or [])
    hard = len([l for l in both if _s(l.get("rel")) in HARD_RELS])
    out = {"waiting_for": [], "waiting": False, "holding": [],
           "hard_links": hard, "link_web": hard > HARD_MAX}
    if _s(t.get("stage")) in STAGES_CLOSED:
        return out
    for l in (t.get("links_in") or []):
        ref = _s(l.get("ref"))
        if _s(l.get("rel")) == links.REL_BLOCKS and _alive_open(ref):
            out["waiting_for"].append(ref)
    for l in (t.get("links") or []):
        ref = _s(l.get("ref"))
        if _s(l.get("rel")) == links.REL_BLOCKS and _alive_open(ref):
            out["holding"].append(ref)
    out["waiting"] = bool(out["waiting_for"])
    return out


# ---------------------------------------------------------------------------
# ⭐⭐⭐ 708 (проєкт розробки ОТУ, 3.5 і 4.4 Б): ВЕЛИКА ЗАДАЧА З ЕТАПАМИ.
#
# Етап — ПОВНОЦІННА задача (свій виконавець, строк, перевіряючий), а «частина чого» — той
# самий звʼязок «підзадача» з реєстру (`links`): один батько, без кілець, обидва боки одним
# запитом. Другого писаря складу немає. Головна задача несе лише прапорець «мої підзадачі —
# етапи» (`stepped`) і ПОРЯДОК (`step_order`); етап, якого в порядку ще немає, стає останнім.
#
# ⛒ НАСТУПНИЙ ЕТАП — ПІСЛЯ ПОПЕРЕДНІХ (4.4 Б). Доки не закрито всі попередні, етап у роботу
# не береться (`set_stage`); почати раніше — лише «Почати раніше з поясненням» за шаблоном
# (`start_early`), і це лишається в етапі, стрічці, події й Дзеркалі. Жорсткої заборони немає
# свідомо: вона вигнала б роботу повз систему (так погоджено з ОТУ).
#
# ⛒ ГОЛОВНА ЙДЕ ЗА ЕТАПАМИ (`_steps_follow`): перший етап у роботі — головна в роботі; усі
# етапи закрито — головна закрита; етап знову відкрили — головна знову в роботі. Руками
# закрити головну, поки є живий етап, не можна.
# ---------------------------------------------------------------------------
def _tid_of(ref) -> str:
    v = _s(ref)
    return entity.ident_of(v) if entity.is_ref(v) and entity.kind_of(v) == entity.KIND_TASK else ""


def _kids_of(task_id: str, idx) -> list:
    """Номери підзадач — з реєстру звʼязків (хто вказує «я — частина цієї»)."""
    me = entity.ref(entity.KIND_TASK, task_id)
    out = []
    for l in idx.inc(me):
        k = _tid_of(l.get("ref")) if _s(l.get("rel")) == links.REL_SUBTASK_OF else ""
        if k and k not in out:
            out.append(k)
    return out


def _parent_of(t: dict) -> str:
    for l in (t.get("links") or []):
        if _s(l.get("rel")) == links.REL_SUBTASK_OF:
            return _tid_of(l.get("ref"))
    return ""


def _step_ids(parent: dict, kids: list) -> list:
    """Порядок етапів: спершу записаний, далі — нові, за номером. Записаний номер, якого вже
    немає серед підзадач, не враховується (звʼязок прибрали — етапом бути перестала)."""
    listed = [k for k in (parent.get("step_order") or []) if k in kids]
    return listed + sorted(k for k in kids if k not in listed)


def _due_of(t: dict) -> str:
    """Строк задачі так, як його бачить людина: введений, а ні — найпізніший пункт плану."""
    if _s(t.get("due_at")):
        return _s(t.get("due_at"))
    dues = [_s(c.get("due_at")) for c in (t.get("checklist") or []) if _s(c.get("due_at"))]
    return max(dues, key=_due_key) if dues else ""


def _brief(tid: str) -> dict:
    """Задача з диска без похідного — для сусідів-етапів; немає чи не читається — порожньо."""
    try:
        p = _find_path(tid)
        return _normalize(one_writer.read_json(p), tid) if p.exists() else {}
    except PermissionError:
        raise                       # ⛒ зайнятий файл — не порожній
    except Exception:
        return {}


def _step_row(k: dict, n: int, names: dict, now: str) -> dict:
    due = _due_of(k)
    st = _s(k.get("stage"))
    return {"id": _s(k.get("id")), "n": n, "title": _s(k.get("title")),
            "assignee_id": _s(k.get("assignee_id")),
            "assignee_name": names.get(_s(k.get("assignee_id")), ""),
            "stage": st, "stage_name": STAGE_NAMES.get(st, st), "due": due,
            "overdue": bool(due and st not in STAGES_CLOSED and _due_key(due) < now),
            "closed": st in STAGES_CLOSED, "done": st == STAGE_DONE,
            "early": bool(k.get("early"))}


def _steps_apply(t: dict, get, idx, names: dict, now: str) -> None:
    """Етапи — і з боку головної, і з боку етапу. `get(номер)` — задача (з уже прочитаного
    набору або з диска); порожньо — задачі немає, і етапом вона не рахується."""
    t["steps"], t["steps_total"], t["steps_done"] = [], 0, 0
    t["step_now"], t["steps_fit"], t["step_of"], t["step_wait"] = {}, {}, {}, []
    t["early_count"] = len(t.get("early") or [])
    if t.get("stepped"):
        rows = []
        for i, k_id in enumerate(_step_ids(t, _kids_of(t["id"], idx))):
            k = get(k_id)
            if k:
                rows.append(_step_row(k, len(rows) + 1, names, now))
        t["steps"] = rows
        t["steps_total"] = len([r for r in rows if r["stage"] != STAGE_CANCEL])
        t["steps_done"] = len([r for r in rows if r["done"]])
        t["step_now"] = next((r for r in rows if not r["closed"]), {})
        if rows and not _s(t.get("due_at")):
            # ⭐ Строку не вводили — він дорівнює найпізнішому етапу (як і пункту плану).
            cand = [(d, "етапи") for d in (r["due"] for r in rows) if d]
            if t.get("due_effective"):
                cand.append((t["due_effective"], t.get("due_source") or ""))
            if cand:
                t["due_effective"], t["due_source"] = max(cand, key=lambda x: _due_key(x[0]))
                due_k = _due_key(t["due_effective"])
                t["overdue"] = bool(due_k and t["stage"] not in STAGES_CLOSED and due_k < now)
                t["days_left"] = _days_left(due_k, now)
        if rows:
            why, pd = [], _due_key(t.get("due_effective") or "")
            for r in rows:
                if r["closed"]:
                    continue
                if r["due"] and pd and _due_key(r["due"]) > pd:
                    why.append("етап %d «%s» має строк %s — пізніше за строк головної задачі"
                               % (r["n"], r["title"], _human(r["due"])))
                if r["overdue"]:
                    why.append("етап %d «%s» прострочено" % (r["n"], r["title"]))
            t["steps_fit"] = {"ok": not why, "why": why}
    pid = _parent_of(t)
    par = get(pid) if pid else {}
    if par and par.get("stepped"):
        order = _step_ids(par, _kids_of(pid, idx))
        if t["id"] in order:
            pos = order.index(t["id"])
            t["step_of"] = {"id": pid, "title": _s(par.get("title")), "n": pos + 1,
                            "total": len(order)}
            for i, k_id in enumerate(order[:pos]):
                k = get(k_id)
                if k and _s(k.get("stage")) not in STAGES_CLOSED:
                    t["step_wait"].append(_step_row(k, i + 1, names, now))


def mask_steps(t: dict, seen) -> dict:
    """⛒ 708: ЧУЖЕ — ЛИШЕ ТОМУ, КОМУ ВИДНО. Етапи несуть назви сусідніх задач і головної, а
    людина бачить не всі. Хто і на якій стадії тримає роботу — лишається (це й треба знати,
    3.5); назву невидимої задачі — ні. Суддя видимості той самий — `visible_ids()`."""
    seen = set(seen or ())

    def cut(r):
        r = dict(r)
        r["hidden"] = r.get("id") not in seen
        if r["hidden"]:
            r["title"] = ""
        return r
    t["steps"] = [cut(r) for r in t.get("steps") or []]
    t["step_wait"] = [cut(r) for r in t.get("step_wait") or []]
    if t.get("step_now"):
        t["step_now"] = cut(t["step_now"])
    if t.get("step_of"):
        t["step_of"] = cut(t["step_of"])
    hidden_n = {str(r["n"]) for r in t["steps"] if r["hidden"]}
    if t.get("steps_fit") and hidden_n:
        # Причини «не вкладається» називають етапи — невидимі лише номером.
        def name_cut(m):
            return m.group(0) if m.group(1) not in hidden_n else "етап " + m.group(1)
        t["steps_fit"] = dict(t["steps_fit"], why=[
            re.sub(r"етап (\d+) «[^»]*»", name_cut, w) for w in t["steps_fit"].get("why") or []])
    return t


def _column_of(t: dict, boards=None) -> tuple:
    """⭐ 709: (id, назва) колонки, де задача стоїть на дошці. Власна колонка чинна лише в
    своїй стадії й своєму проєкті; інакше — основна колонка стадії (з назвою власника,
    якщо він її перейменував). Без проєкту — стадія. `boards` — колонки проєктів,
    прочитані один раз тим, хто читає багато задач."""
    st, pid = t["stage"], _s(t.get("project_id"))
    if not pid:
        return st, STAGE_NAMES.get(st, st)
    cache = boards if boards is not None else {}
    lay = cache.get(pid)
    if lay is None:
        lay = cache[pid] = tprj.board_columns(pid)
    want = _s(t.get("column"))
    for c in lay:
        if want and c["id"] == want and c["stage"] == st:
            return c["id"], c["name"]
    for c in lay:
        if c["id"] == st:
            return st, c["name"]
    return st, STAGE_NAMES.get(st, st)


def _derive(t: dict, names: dict, now: str, idx=None,
            limit_days: int = 0, org=None, steps: bool = True, boards=None) -> dict:
    """Похідне рахуємо ТУТ і ніде більше. На диск воно не лягає ніколи.

    ⭐ КРОК B2: `idx` — ЗНІМОК РЕЄСТРУ ЗВʼЯЗКІВ, прочитаний ОДИН раз тим, хто
    читає багато задач. Без нього кожна задача перечитувала б реєстр із диска.
    Не передали — читаємо самі: правду віддає диск, а не зручність викликача.
    ⭐ 708: `steps=False` — етапи порахує другий прохід того, хто читає весь набір."""
    t = dict(t)
    idx = links.index() if idx is None else idx
    _me = entity.ref(entity.KIND_TASK, t["id"])
    # ⭐⭐⭐ ОБИДВА БОКИ — ОДИН ЗАПИТ ДО РЕЄСТРУ. Раніше зворотний бік був
    # ПЕРЕБОРОМ УСІХ ФАЙЛІВ ЗАДАЧ і рахувався лише в `load_all`; тому картка,
    # відкрита напряму, його не бачила. Тепер він коштує стільки ж, скільки
    # прямий, і брехати про «не рахували» більше нема потреби.
    t["links"] = idx.out(_me)
    t["links_in"] = idx.inc(_me)

    # ⭐ Рішення 22: якщо термін задачі не вводила людина — він дорівнює
    # найпізнішому терміну пункту чек-листа.
    if t["due_at"]:
        t["due_effective"], t["due_source"] = t["due_at"], "людина"
    else:
        item_dues = [c["due_at"] for c in t["checklist"] if c["due_at"]]
        if item_dues:
            t["due_effective"] = max(item_dues, key=_due_key)
            t["due_source"] = "чек-лист"
        else:
            t["due_effective"], t["due_source"] = "", ""

    # ⭐ Рішення 6: протермінування — ОЗНАКА поверх стадії.
    due_k = _due_key(t["due_effective"])
    t["overdue"] = bool(due_k and t["stage"] not in STAGES_CLOSED and due_k < now)
    t["due_when"] = _due_when(due_k, t["overdue"], t["stage"] in STAGES_CLOSED, now)
    t["days_left"] = _days_left(due_k, now)

    t["stage_name"] = STAGE_NAMES.get(t["stage"], t["stage"])
    t["priority_name"] = PRIORITY_NAMES.get(t["priority"], "")
    t["column_id"], t["column_name"] = _column_of(t, boards)
    t["author_name"] = names.get(t["author_id"], "")
    t["assignee_name"] = names.get(t["assignee_id"], "")
    # ⭐ ПЕРЕВІРКА ЧИННА, ПОКИ РЕЗУЛЬТАТ ТОЙ САМИЙ. Новий результат — і ця
    # рівність розпадається сама: старе «перевірено» не засвідчує нову роботу.
    t["verifier_name"] = names.get(t["verifier_id"], "")
    t["verified"] = bool(t["verifier_id"] and t["result_comment_id"]
                         and t["verified_result_id"] == t["result_comment_id"])
    t["awaiting_verify"] = bool(t["verifier_id"] and t["result_comment_id"]
                                and not t["verified"])
    # ⭐ ЗВІРКА ЧИННА, ПОКИ РЕЗУЛЬТАТ ТОЙ САМИЙ — та сама рівність, що й у
    # перевірки. Здали новий результат — стара звірка більше не про нього, і
    # показувати її означало б видавати вчорашній висновок за сьогоднішній.
    t["match_fresh"] = bool(t["match"] and t["result_comment_id"]
                            and t["match"].get("result_id") == t["result_comment_id"])
    # ⭐ ЗАТОР — ЦЕ ФАКТ, А НЕ ВИРОК. «Стоїть N днів» рахується від останнього
    # руху; закрита задача не стоїть — вона закінчилась.
    t["idle_days"] = _days_between(t["updated_at"] or t["created_at"], now)
    t["stuck"] = _is_stuck(t, limit_days)
    # ⭐ ЗАЛЕЖНОСТІ — ФАКТ, А НЕ ПЕРЕПОНА (зміна 242): чого чекає, кого тримає,
    # чи не павутина. Жодна дія на ці поля не дивиться — і це навмисно.
    t.update(_blocking(t))
    # ⭐⭐⭐ ПЕРЕВІРЯЄ КЕРІВНИК — ЦЕ ЧЕРГА, А НЕ ПОРУШЕННЯ. Звіт вимагав
    # «повністю виключити керівника як обовʼязкове вузьке горло». Виключати не
    # будемо: у компанії на пʼятьох іншого перевіряючого просто немає, і
    # заборона зробила б перевірку неможливою. Показуємо ціну — вибір за
    # людиною. Правило «хто кому керівник» рахує ОДИН писар — `people`.
    t["verifier_boss"] = bool(
        t["verifier_id"] and t["assignee_id"]
        and t["verifier_id"] != t["assignee_id"]
        and people.is_manager_of(t["verifier_id"], t["assignee_id"], org))
    # ⭐⭐⭐ ВОРОТА ВХОДУ (зміна 223) — ОЗНАКА, А НЕ СТАДІЯ.
    # ⛒ Судимо ЛИШЕ доручення. Задача, яку людина записала собі, воротами
    # не міряється: це нагадування, і право на нього дав Андрій 02.08.2026.
    # ⛒ І лише ЖИВУ задачу: сира закрита задача — це вже історія, і сварити
    # за неї нема кого.
    t["for_other"] = bool(t["assignee_id"] and t["assignee_id"] != t["author_id"])
    t["unready_why"] = []
    if t["for_other"] and t["stage"] not in STAGES_CLOSED:
        if not t["acceptance"]:
            t["unready_why"].append("не сказано, за чим приймемо результат")
        if not t["due_effective"]:
            t["unready_why"].append("не названо строк")
    t["unready"] = bool(t["unready_why"])
    t["participant_ids"] = participants(t)
    t["checklist_total"] = len(t["checklist"])
    t["checklist_done"] = len([c for c in t["checklist"] if c["done"]])
    # 🩸 Рішення Андрія 26.08.2026: непозначені пункти ПОКАЗУЮТЬСЯ, але нічого
    # не зупиняють. Тому це числа для ока, а не ворота: жодна дія на них не
    # дивиться. Ми дивимось, а не перегороджуємо.
    t["dod_total"] = len(t["dod"])
    t["dod_done"] = len([p for p in t["dod"] if p["done"]])
    t["dod_left"] = t["dod_total"] - t["dod_done"]
    t["worktype_name"] = ""
    if t["worktype_id"]:
        wt = worktypes.work_type(t["worktype_id"])
        t["worktype_name"] = (wt or {}).get("name", "")
    t["open_proposals"] = [p for p in t.get("proposals", [])
                           if p["state"] == PROPOSAL_OPEN]
    t["has_proposal"] = bool(t["open_proposals"])
    t["result_text"] = ""
    if t["result_comment_id"]:
        for c in t["feed"]:
            if c["id"] == t["result_comment_id"]:
                t["result_text"] = c["text"]
                break
    # ⭐ 706. Провали — назавжди; «чи є що не прийняти» — те саме, коли є що прийняти.
    t["failed_count"] = len(t.get("failures") or [])
    t["rejectable"] = rejectable(t)
    t["ack_state"], t["unclear"] = _ack_view(t, now)
    if steps:
        _steps_apply(t, lambda k: t if k == t["id"] else _brief(k), idx, names, now)
    return t


def rejectable(t: dict) -> bool:
    """⭐ 706. НЕ ПРИЙНЯТИ МОЖНА ЛИШЕ ТЕ, ЩО ЗДАНО: задача «На перевірці» або в ній є
    результат (як і «Прийняти» — щойно є результат, рішення 27.08.2026). Нема що
    відхиляти — кнопка була б брехнею, а провал без зданої роботи — вигадкою."""
    st = _s(t.get("stage"))
    if st == STAGE_REVIEW:
        return True
    return bool(_s(t.get("result_comment_id")) and st in (STAGE_NEW, STAGE_WORK))


def _ack_view(t: dict, now: str) -> tuple:
    """(стан підтвердження, чи «незрозуміла задача») — похідне, на диск не лягає.

    «» — підтвердження не просимо: запису немає (задача собі, стара задача), він про
    іншого виконавця або задача вже не жива (закрита чи відкладена)."""
    a = t.get("ack") or {}
    if (not a or a.get("for") != _s(t.get("assignee_id"))
            or t.get("stage") in STAGES_CLOSED + (STAGE_HOLD,)):
        return "", False
    if a.get("state") == ACK_UNDERSTOOD:
        return ACK_UNDERSTOOD, False
    if a.get("state") == ACK_CLARIFY:
        reply = _ack_reply(t)
        if not reply:
            return ACK_CLARIFY, False      # мʼяч у постановника — він і так знає
        return ACK_ANSWERED, _hours_between(reply.get("at"), now) >= ACK_UNCLEAR_HOURS
    return ACK_PENDING, _hours_between(a.get("since"), now) >= ACK_UNCLEAR_HOURS


def _ack_reply(t: dict) -> dict:
    """Відповідь на питання виконавця: перший коментар ІНШОЇ людини після питання."""
    a = t.get("ack") or {}
    qid, seen = a.get("question_id"), False
    for c in t.get("feed") or []:
        if c.get("id") == qid:
            seen = True
            continue
        if seen and c.get("kind") == "comment" and c.get("author_id") \
                and c.get("author_id") != a.get("for"):
            return c
    return {}


def _hours_between(a: str, b: str) -> float:
    try:
        from datetime import datetime
        x = datetime.fromisoformat(_s(a)[:19])
        y = datetime.fromisoformat(_s(b)[:19])
        return (y - x).total_seconds() / 3600.0
    except Exception:
        return 0.0


def _due_when(due_key: str, overdue: bool, closed: bool, now: str) -> str:
    """⭐ 733 «СТРОК»: протермінована / на цьому тижні / на наступному тижні / ніде.
    Рахується тим самим «зараз», що й `overdue`, і поверх нього — один суддя, а не
    два. Тиждень — з понеділка по неділю. Закрита задача — ніде: вона вже не строк."""
    if closed or not due_key:
        return ""
    if overdue:
        return DUE_OVERDUE
    from datetime import date, timedelta
    try:
        d = date.fromisoformat(due_key[:10])
        today = date.fromisoformat(_s(now)[:10])
    except ValueError:
        return ""
    monday = today - timedelta(days=today.weekday())
    if d <= monday + timedelta(days=6):
        return DUE_THIS_WEEK
    if d <= monday + timedelta(days=13):
        return DUE_NEXT_WEEK
    return ""


def _days_left(due_key: str, now: str):
    if not due_key:
        return None
    try:
        from datetime import datetime
        a = datetime.strptime(due_key[:16], "%Y-%m-%dT%H:%M")
        b = datetime.strptime(now[:16], "%Y-%m-%dT%H:%M")
        return int((a - b).total_seconds() // 86400)
    except Exception:
        return None


def participants(t: dict) -> list:
    """Усі, хто в задачі. Порядок ролей — від сильнішої до слабшої."""
    out = []
    for x in ([t.get("author_id"), t.get("assignee_id")]
              + list(t.get("coassignee_ids") or [])
              + [t.get("verifier_id")]
              + list(t.get("watcher_ids") or [])):
        x = _s(x)
        if x and x not in out:
            out.append(x)
    return out


def own_roles(t: dict, emp_id: str) -> tuple:
    """⭐⭐⭐ УСІ ролі людини в задачі, від сильнішої до слабшої.

    08.08.2026. Раніше тут була ОДНА роль — і це був глухий кут: той, хто
    поставив задачу САМ СОБІ, ставав «виконавцем» і втрачав права постановника.
    Він не міг ні правити свою задачу, ні прийняти її: здав на перевірку — і
    приймати нікому. Для клієнта, який у системі один, це означало, що ЖОДНА
    його задача не закривається.

    Закон тепер такий самий, як у дорослих системах: **людина має стільки прав,
    скільки дають УСІ її ролі разом**. Одна роль ніколи не відбирає того, що
    дала інша."""
    emp_id = _s(emp_id)
    if not emp_id:
        return ()
    out = []
    if emp_id == _s(t.get("assignee_id")):
        out.append(ROLE_ASSIGNEE)
    if emp_id == _s(t.get("author_id")):
        out.append(ROLE_AUTHOR)
    if emp_id in (t.get("coassignee_ids") or []):
        out.append(ROLE_CO)
    if emp_id == _s(t.get("verifier_id")):
        out.append(ROLE_VERIFIER)
    if emp_id in (t.get("watcher_ids") or []):
        out.append(ROLE_WATCHER)
    return tuple(out)


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЗАМІЩЕННЯ НА ЧАС ВІДСУТНОСТІ (зміна 224, 26.08.2026) — ШАР НАД РОЛЯМИ.
#
# КОРІНЬ: права прибиті до `id` людини, а людина буває тимчасово недоступна.
# Поки Y у відпустці, його роботу веде названий ним делегат X.
#
# ⭐ ЧОМУ САМЕ ТУТ. `roles_of()` — ОДИН писар відповіді «які ролі має ця людина
# в цій задачі», і питають його ВСІ ТРОЄ: чи БАЧИТЬ (`visible_ids`), чи МОЖЕ
# (`may`/`require`) і які КНОПКИ малювати (`rights`). Тому одна правка тут
# закриває ОБИДВІ половини воріт разом. Дві правки в двох місцях дали б
# класичне півворота: право є, а задачі на екрані немає (урок 24.08.2026).
# Майбутній читач прав отримає заміщення безкоштовно — він теж спитає звідси.
#
# 🩸 Рішення Андрія 26.08.2026: делегат бере ПОВНІ права відсутнього.
# ⛒ Права АДМІНІСТРАТОРА не делегуються: адміністратор — шар НАД задачею, а не
# роль у ній, і приходить окремим прапорцем `is_admin`.
# ---------------------------------------------------------------------------
def roles_of(t: dict, emp_id: str) -> tuple:
    """Ролі СВОЇ плюс ролі тих, кого ця людина зараз заміщує."""
    out = list(own_roles(t, emp_id))
    for principal in people.principals_of(emp_id):
        for r in own_roles(t, principal):
            if r not in out:
                out.append(r)
    return tuple(out)


def deputy_for(t: dict, emp_id: str) -> list:
    """КОГО САМЕ ця людина заміщує В ЦІЙ задачі. Порожньо — звичайний випадок.

    Це і є джерело сліду «Х (заміщує Y)»: заміщення взагалі й заміщення В ЦІЙ
    задачі — різні речі, і в журнал має лягти друге."""
    return [p for p in people.principals_of(emp_id) if own_roles(t, p)]


def role_of(t: dict, emp_id: str) -> str:
    """ГОЛОВНА роль — лише щоб показати людині одним словом, хто вона тут.
    Права рахуються НЕ звідси, а з `roles_of()`: див. `may()`."""
    rr = roles_of(t, emp_id)
    return rr[0] if rr else ""


# ---------------------------------------------------------------------------
# ОДИН ЧИТАЧ
# ---------------------------------------------------------------------------
def _path(tid: str) -> Path:
    if not re.match(r"^T-\d{6}$", _s(tid)):
        raise TaskError("Номер задачі «%s» не схожий на наш (T-000001)." % tid)
    return TASKS_DIR / ("%s.json" % tid)


def _archive_path(tid: str) -> Path:
    if not re.match(r"^T-\d{6}$", _s(tid)):
        raise TaskError("Номер задачі «%s» не схожий на наш (T-000001)." % tid)
    return ARCHIVE_DIR / ("%s.json" % tid)


def _find_path(tid: str) -> Path:
    # Де ЗАРАЗ лежить задача: у живій теці чи в архіві.
    # Усі читачі ОДНІЄЇ задачі ходять сюди. Інакше після переїзду в архів
    # картка за номером «зникала б», хоча задача ціла — а це найгірший вид
    # втрати: людина бачить номер у листі й не може його відкрити.
    p = _path(tid)
    if p.exists():
        return p
    a = _archive_path(tid)
    return a if a.exists() else p


def stage_of(tid: str) -> str:
    """Стадія ОДНІЄЇ задачі — дешево, без похідних і без людей.

    ⭐ Питання «а та задача вже закрита?» ставиться на КОЖЕН звʼязок «блокує».
    Ставити його через `task()` означало б на кожну відповідь перечитувати
    оргструктуру й увесь реєстр звʼязків — і саме через цю ціну картка досі
    про закритість мовчала. Тут читається один файл і одне поле.
    ⚠ Немає файлу або він побитий — порожньо, а не аварія: питання «чи
    закрита» не має права завалити показ чужої задачі."""
    try:
        p = _find_path(tid)
    except TaskError:
        return ""
    if not p.exists():
        return ""
    try:
        return _s(one_writer.read_json(p).get("stage"))
    except PermissionError:
        raise   # ⛒ зайнятий файл — не порожній
    except Exception:
        return ""


def exists(tid: str) -> bool:
    """Чи така задача взагалі є. ФАЙЛ, а не повне читання задачі.

    🩸 27.08.2026, знайдено ЖИВИМ ПРОГОНОМ. Досі «чи існує задача» питали
    через `task()` — тобто через ПОВНЕ читання з усіма похідними. Щойно серед
    похідних зʼявилось «чого я чекаю» (яке саме й питає про існування тих
    задач), це замкнулось у ВЗАЄМНУ НЕСКІНЧЕННУ РЕКУРСІЮ: А чекає на Б, Б
    тримає А — і кожен бік читав другий цілком. Чек висів, поки його не зняли
    по таймауту.
    ⛒ Корінь не в новому полі, а в тому, що НАЙДЕШЕВШЕ ПИТАННЯ платформи
    коштувало найдорожче: `entity.exists` питають усі екрани на кожен звʼязок.
    Тепер це один погляд на диск — і для звʼязків контрагента теж."""
    try:
        return _find_path(tid).exists()
    except TaskError:
        return False


def is_closed(tid: str) -> bool:
    """Чи задача вже закінчилась. Задачі немає — не закінчилась: її просто немає,
    і видавати відсутність за завершення означало б тихо гасити перепони."""
    st = stage_of(tid)
    return bool(st) and st in STAGES_CLOSED


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЗАТОРИ (зміна 240, 27.08.2026). ДЕ РОБОТА СТОЇТЬ — І ЗА ЧИЄЮ МІРКОЮ.
#
# ⛒ НІЧОГО НЕ ЗАБОРОНЯЄМО. Затор — це ВИДИМИЙ ФАКТ про задачу, а не заборона й
# не оцінка людини: продукт має полегшувати роботу з задачами, а не додавати
# перепон (слово Андрія, 27.08.2026).
#
# ⛒ МІРКА — ВЛАСНИЙ ТЕМП КОМПАНІЇ, А НЕ ЧИСЛО З МОЄЇ ГОЛОВИ. Скільки днів —
# «довго», знає лише сама компанія: у виробництві й у юриста це різні тижні.
# Тому межа = СЕРЕДИННИЙ (медіанний) час, за який тут закривають задачі.
# Медіана, а не середнє: одна задача, що провисіла пів року, не сміє зсунути
# мірку для всіх.
#
# ⚠ ПОКИ ІСТОРІЇ МАЛО — КАЖЕМО ПРО ЦЕ ВГОЛОС І БЕРЕМО ЗАПАСНУ МІРКУ. Вигадати
# медіану з двох задач означало б видати випадковість за темп компанії.
# ---------------------------------------------------------------------------
TEMPO_MIN_DONE = 5        # менше закритих задач — своєї мірки ще немає
TEMPO_FALLBACK = 7        # запасна мірка в днях, поки історія не набралась
TEMPO_LOOK_BACK = 30      # по скількох останніх закритих рахуємо темп

# ⛒⛒⛒ НИЖНЯ МЕЖА (27.08.2026, знайдено ЖИВИМ ПРОГОНОМ на базі Андрія).
# 🩸 Медіана вийшла ОДИН ДЕНЬ — бо більшість закритих задач були пробні й
# закривались того ж дня. Мірка, чесно порахована з несправжньої історії, дала
# б «затор» кожній задачі, якої не чіпали два дні. Дошка кричала б щодня, і її
# перестали б читати — рівно те, від чого ми тікаємо.
# ⛒ Тому власний темп діє, але НЕ ОПУСКАЄТЬСЯ нижче трьох днів: мовчання
# протягом одного дня — це ще не затор, це звичайний робочий день.
TEMPO_FLOOR = 3


def _is_stuck(t: dict, limit_days: int) -> bool:
    """ЄДИНЕ місце, де вирішується «ця задача стоїть».

    ⛒ 27.08.2026: спершу це правило стояло у ДВОХ місцях — у похідних полях і
    другим проходом по списку. Мутація показала ціну: підміни одне — поведінка
    не змінюється, бо друге тримає. Два писарі одного правила — це нуль писарів:
    завтра вони розійдуться, і дошка почне казати інше, ніж картка."""
    return bool(t.get("idle_days") is not None
                and t.get("stage") not in STAGES_CLOSED
                and limit_days
                and t["idle_days"] > limit_days)


def _days_between(a: str, b: str):
    """Скільки днів між двома нашими мітками часу. Не вийшло — None, не нуль."""
    if not a or not b:
        return None
    try:
        from datetime import datetime
        x = datetime.strptime(str(a)[:16], "%Y-%m-%dT%H:%M")
        y = datetime.strptime(str(b)[:16], "%Y-%m-%dT%H:%M")
        return int((y - x).total_seconds() // 86400)
    except Exception:
        return None


# Темп міняється рідко, а питають його на кожній картці. Тому кеш із міткою
# теки задач: змінився диск — змінилась мітка, і темп перерахується сам.
_TEMPO = {"stamp": None, "val": None}


def _tempo_stamp():
    try:
        st = TASKS_DIR.stat()
        return (st.st_mtime_ns, len(list(TASKS_DIR.glob("T-*.json"))),
                len(list(ARCHIVE_DIR.glob("T-*.json"))))
    except Exception:
        return None


def tempo(rows=None) -> dict:
    """Темп компанії: {"days": межа, "own": чи це власний темп, "based_on": скільки}.

    ⛒ Рахуємо по ЗАКРИТИХ задачах: лише вони знають, скільки тут насправді
    триває робота. Живі задачі про це нічого не кажуть — вони ще тривають."""
    if rows is None:
        stamp = _tempo_stamp()
        if _TEMPO["val"] is not None and _TEMPO["stamp"] == stamp:
            return dict(_TEMPO["val"])
        # ⛒ Темп рахується по ЗАКРИТИХ задачах, а вони й переїжджають в архів.
        # Тому тут архів читається — але рідко: відповідь тримається в кеші й
        # перераховується лише коли змінився диск (зміна 279).
        rows = load_all(include_closed=True, include_archive=True)
        out = _tempo_from(rows)
        _TEMPO["stamp"], _TEMPO["val"] = stamp, out
        return dict(out)
    return _tempo_from(rows)


def _tempo_from(rows) -> dict:
    spans = []
    for t in rows:
        if t.get("stage") not in STAGES_CLOSED:
            continue
        d = _days_between(t.get("created_at"), t.get("updated_at"))
        if d is not None and d >= 0:
            spans.append(d)
    spans = spans[-TEMPO_LOOK_BACK:]
    if len(spans) < TEMPO_MIN_DONE:
        return {"days": TEMPO_FALLBACK, "own": False, "based_on": len(spans)}
    spans.sort()
    mid = spans[len(spans) // 2]
    return {"days": max(TEMPO_FLOOR, int(mid)), "own": True,
            "based_on": len(spans)}


def load_all(include_closed: bool = True, include_archive: bool = False) -> list:
    """ЄДИНЕ місце, де читається диск задач. Далі всі беруть правду звідси.

    ⛒ `include_archive` за замовчуванням ВИМКНЕНИЙ — у цьому й весь виграш
    зміни 279: щоденний екран не платить за задачі, закриті пів року тому."""
    TASKS_DIR.mkdir(parents=True, exist_ok=True)
    now = clock.now()[:16]
    names = {e["id"]: e.get("full_name", "") for e in people.employees(True)}
    idx = links.index()               # реєстр звʼязків читаємо ОДИН раз на весь обхід
    org = people.load()               # оргструктуру — теж один раз на весь обхід
    boards = {}                       # ⭐ 709: колонки проєктів — раз на проєкт
    everyone = []
    paths = [(p, False) for p in TASKS_DIR.glob("T-*.json")]
    if include_archive:
        ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
        paths += [(p, True) for p in ARCHIVE_DIR.glob("T-*.json")]
    for p, from_archive in sorted(paths, key=lambda x: x[0].stem):
        tid = p.stem
        try:
            raw = one_writer.read_json(p)
        except PermissionError:
            raise   # ⛒ зайнятий файл — не порожній
        except Exception as e:
            raw = {"title": "", "audit": []}
            t = _normalize(raw, tid)
            t["broken"], t["broken_reason"] = True, "файл не прочитався: %s" % e
        else:
            t = _normalize(raw, tid)
        # ⛒ Ознака місця: рахується з того, у якій теці лежить файл (зміна 280).
        t["archived"] = bool(from_archive)
        everyone.append(_derive(t, names, now, idx, 0, org, steps=False, boards=boards))

    # ⭐ 708: ЕТАПИ ДРУГИМ ПРОХОДОМ — сусіди-етапи вже прочитані; диск — лише для архівних.
    by_id = {t["id"]: t for t in everyone}
    for t in everyone:
        _steps_apply(t, lambda k: by_id.get(k) or _brief(k), idx, names, now)

    # ⭐ ЗАТОРИ ДРУГИМ ПРОХОДОМ, І ЦЕ НЕ ЛІНОЩІ: мірку «довго» знає лише ВЕСЬ
    # набір задач, а не окрема з них. Порахувати її під час першого проходу
    # означало б питати темп у півсписку.
    _lim = _tempo_from(everyone)["days"]
    for t in everyone:
        t["stuck"] = _is_stuck(t, _lim)

    # ⭐⭐⭐ ЗВОРОТНИЙ БІК РАХУЄМО, А НЕ ЗБЕРІГАЄМО — і тепер РЕЄСТРОМ, а не
    # перебором чужих файлів (крок B2). Звʼязок лежить рівно один раз, і обидва
    # боки читаються з одного місця; другого писаря однієї правди не існує.
    # ⚠ Читається ДО відсіву закритих: закрита задача, яка блокує живу, — це
    # саме те, що людині треба побачити.
    out = [t for t in everyone
           if include_closed or t["stage"] not in STAGES_CLOSED]
    out.sort(key=lambda t: t["id"], reverse=True)
    return out


def task(tid: str, incoming: bool = False) -> dict:
    """Одна задача — з обома боками звʼязків.

    ⭐ КРОК B2: параметр `incoming` лишений заради старих викликачів і БІЛЬШЕ
    НІЧОГО НЕ ВМИКАЄ. Раніше зворотний бік коштував перебору всіх файлів задач,
    і тому був окремим — свідомо дорожчим — шляхом. Тепер це один запит до
    реєстру, і ділити читання на «дешеве без зворотного боку» та «дороге зі
    зворотним» стало брехнею про ціну."""
    p = _find_path(tid)
    if not p.exists():
        raise TaskError("Задачі %s немає." % tid)
    now = clock.now()[:16]
    names = {e["id"]: e.get("full_name", "") for e in people.employees(True)}
    # ⭐ Мірку «довго» бере той самий писар темпу, що й список: два числа
    # одного правила розійшлись би, і картка казала б інше, ніж дошка.
    return _derive(_normalize(one_writer.read_json(p), tid),
                   names, now, None, tempo()["days"], people.load())


def next_id() -> str:
    """Номер рахуємо з наявних файлів — щоб не заводити ДРУГОГО писаря лічильника."""
    TASKS_DIR.mkdir(parents=True, exist_ok=True)
    top = 0
    # ⛒ І архів теж: інакше після переїзду закритих задач лічильник почав би
    # видавати номери, які вже існують (зміна 279).
    for p in list(TASKS_DIR.glob("T-*.json")) + list(ARCHIVE_DIR.glob("T-*.json")):
        try:
            top = max(top, int(p.stem.split("-")[1]))
        except Exception:
            continue
    return "T-%06d" % (top + 1)


# ---------------------------------------------------------------------------
# ⛒ АРХІВ: ПЕРЕЇЗД ЗАКРИТИХ ЗАДАЧ (зміна 279, 29.08.2026)
# ---------------------------------------------------------------------------
def _unarchive(tid: str) -> bool:
    """Повернути задачу з архіву в живу теку. Задача існує в одному місці."""
    try:
        a = _archive_path(tid)
    except TaskError:
        return False
    if not a.exists():
        return False
    TASKS_DIR.mkdir(parents=True, exist_ok=True)
    one_writer.replace_with_patience(a, _path(tid))
    return True


def archive_sweep(force: bool = False) -> int:
    """Закриті задачі, яким більше ARCHIVE_AFTER_DAYS днів, їдуть в архів.

    ⛒ Не частіше ніж раз на добу: інакше кожне відкриття екрана платило б за
    перебір теки ще й тут. Мітка — файл із датою останнього обходу.
    Повертає, скільки задач переїхало."""
    TASKS_DIR.mkdir(parents=True, exist_ok=True)
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    stamp = ARCHIVE_DIR / ".swept"
    today = clock.now()[:10]
    if not force:
        try:
            if stamp.exists() and one_writer.read_text(stamp).strip() == today:
                return 0
        except PermissionError:
            raise   # ⛒ зайнятий файл — не порожній
        except Exception:
            pass
    now = clock.now()
    moved = 0
    for p in sorted(TASKS_DIR.glob("T-*.json")):
        try:
            raw = one_writer.read_json(p)
        except PermissionError:
            raise   # ⛒ зайнятий файл — не порожній
        except Exception:
            continue                      # побитий файл лишається на місці
        if _s(raw.get("stage")) not in STAGES_CLOSED:
            continue
        days = _days_between(raw.get("updated_at"), now)
        if days is None or days < ARCHIVE_AFTER_DAYS:
            continue
        try:
            one_writer.replace_with_patience(p, ARCHIVE_DIR / p.name)
            moved += 1
        except Exception:
            continue
    try:
        one_writer.write_text(stamp, today)
    except Exception:
        pass
    return moved


def archive_count() -> int:
    """Скільки задач лежить в архіві. Для екрана й для чеків."""
    ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
    return len(list(ARCHIVE_DIR.glob("T-*.json")))


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ОДНА ФУНКЦІЯ ВИДИМОСТІ НА ВЕСЬ ПРОДУКТ
# ---------------------------------------------------------------------------
def visible_ids(emp_id: str, tasks: list = None) -> set:
    """Хто що взагалі БАЧИТЬ (це не те саме, що «що можна ЗРОБИТИ»).

    - працівник бачить свої задачі: постановник · виконавець · співвиконавець ·
      спостерігач;
    - керівник додатково бачить усе, що доручено, виконується або створено його
      підлеглими на ВСІХ рівнях униз (ланцюг береться з дерева підрозділів,
      другого списку підлеглих не існує);
    - головний директор — не окремий випадок у коді: він керівник кореневого
      підрозділу, і правило керівника вже дає йому всю компанію.

    Фільтр екрана може лише ЗВУЗИТИ цей набір, ніколи не розширити."""
    emp_id = _s(emp_id)
    tasks = load_all() if tasks is None else tasks
    if not emp_id:
        return set()
    mine = set(people.subordinates_of(emp_id) or [])
    seen = set()
    for t in tasks:
        if role_of(t, emp_id):
            seen.add(t["id"])
            continue
        for sub in mine:
            role = role_of(t, sub)
            if not role:
                continue
            if role == ROLE_WATCHER and not MANAGER_SEES_WATCHER_ONLY:
                continue
            seen.add(t["id"])
            break
    return seen


def visible_tasks(emp_id: str, include_closed: bool = True,
                  include_archive: bool = False) -> list:
    tasks = load_all(include_closed=include_closed,
                     include_archive=include_archive)
    ok = visible_ids(emp_id, tasks)
    return [t for t in tasks if t["id"] in ok]


# ---------------------------------------------------------------------------
# ОДИН ПИСАР
# ---------------------------------------------------------------------------
def _strip_derived(t: dict) -> dict:
    return {k: v for k, v in t.items() if k not in DERIVED}


def _reason(kind: str, det: dict, t: dict) -> str:
    """ОДИН ПИСАР СЛІДУ. Рядок у `audit` більше не приходить ззовні готовим
    текстом — він НАРОДЖУЄТЬСЯ з події. Тому слід у задачі й повідомлення в чат
    не можуть розійтись: у них одне джерело — вид і деталі."""
    if kind == events.KIND_CREATED:
        return "задачу створено"
    if kind == events.KIND_COMMENT:
        return "коментар"
    if kind == events.KIND_RESULT:
        return "додано результат" if det.get("with_text") else "позначено результат"
    if kind == events.KIND_VERIFIED:
        return "результат перевірено"
    if kind == events.KIND_STAGE:
        st = _s(det.get("stage"))
        return "стадія → %s%s%s" % (STAGE_NAMES.get(st, st),
                                    " (за етапами)" if det.get("by_steps") else "",
                                    (" · колонка «%s»" % _s(det.get("column")))
                                    if _s(det.get("column")) else "")
    if kind == events.KIND_EARLY:
        return "етап %s почато раніше попереднього: %s" % (det.get("n") or "?",
                                                          _s(det.get("text"))[:200])
    if kind == events.KIND_STEP_READY:
        return "попередні етапи завершено — етап %s можна брати в роботу" % (det.get("n") or "?")
    if kind == events.KIND_DELEGATED:
        return "передано виконавцю"
    if kind == events.KIND_REFUSED:
        return "відмова з причиною"
    if kind == events.KIND_UPDATED:
        return "задачу змінено: " + " · ".join(det.get("said") or [])
    if kind == events.KIND_PROPOSAL:
        if _s(det.get("kind_of")) == PROPOSAL_ACCEPT:
            return "пропозиція критерію приймання"
        return "пропозиція терміну %s" % _human(_s(det.get("date")))
    if kind == events.KIND_PROPOSAL_DONE:
        return "пропозицію %s" % ("прийнято" if det.get("accepted") else "відхилено")
    if kind == events.KIND_CHECKLIST:
        return "пункт плану"
    if kind == events.KIND_DOD:
        return "стандарт готовності: %s" % ("позначено" if det.get("done")
                                            else "знято позначку")
    if kind == events.KIND_LINKED:
        return "звʼязок — %s" % tlinks.phrase(det.get("rel"), det.get("ref"))
    if kind == events.KIND_UNLINKED:
        return "звʼязок прибрано — %s" % tlinks.phrase(det.get("rel"), det.get("ref"))
    if kind == events.KIND_OVERDUE:
        return "строк %s минув" % _human(_s(det.get("due")))
    if kind == events.KIND_FAILED:
        return "не пройшла перевірку (%s-й раз): %s" % (det.get("n") or "?",
                                                        _s(det.get("reason"))[:200])
    if kind == events.KIND_EXPLAINED:
        return "пояснення до провалу перевірки; задача знову в роботі"
    if kind == events.KIND_UNDERSTOOD:
        return "виконавець зрозумів задачу" + ("" if det.get("first") else " (після уточнення)")
    if kind == events.KIND_CLARIFY:
        return "виконавець просить уточнити задачу"
    if kind == events.KIND_UNCLEAR:
        return "незрозуміла задача: виконавець не підтвердив її за добу"
    return events.KIND_NAMES.get(kind, kind)


def save(t: dict, actor_id: str, ev) -> dict:
    """Кожна зміна лишає слід І народжує подію. Писар один — тому ні журнал
    задачі, ні сповіщення не розʼїжджаються.

    ⭐⭐⭐ ТРЕТІЙ ПАРАМЕТР — ПОДІЯ, А НЕ ТЕКСТ ПРИЧИНИ. Так «повідомити» перестало
    бути окремим кроком поруч зі збереженням, який можна забути в одному з
    одинадцяти місць: **без події задача просто не збережеться**. Правило в
    промпті — прохання; ворота — це коли інакше не виходить фізично."""
    kind, det = events.parts(ev)
    TASKS_DIR.mkdir(parents=True, exist_ok=True)
    clean = _strip_derived(t)
    p = _path(clean["id"])
    # ⛒ ЗАКОН АРХІВУ: задача існує РІВНО В ОДНОМУ МІСЦІ. Якщо правлять архівну
    # задачу — вона ПОВЕРТАЄТЬСЯ в живу теку, а не роздвоюється (зміна 279).
    _unarchive(clean["id"])
    before = {}
    if p.exists():
        try:
            before = one_writer.read_json(p)
        except PermissionError:
            raise   # ⛒ зайнятий файл — не порожній
        except Exception as e:
            raise TaskError("Задача %s на диску не читається: %s" % (clean["id"], e))
    clean["updated_at"] = clock.now()
    # ⛒⛒ 709: КОЛОНКА ЖИВЕ В СВОЇЙ СТАДІЇ Й СВОЄМУ ПРОЄКТІ. Стадію міняє не одна дія
    # (перевірка, «Не прийняти», пояснення, етапи, відмова) — тому правило стоїть у
    # писаря, а не в кожній із них: змінилась стадія, а колонку ніхто не ставив заново, —
    # задача в основній колонці нової стадії; повернення в роботу не воскрешає стару.
    if before and _s(clean.get("column")) and (
            (_s(before.get("stage")) != _s(clean.get("stage"))
             and _s(clean.get("column")) == _s(before.get("column")))
            or _s(before.get("project_id")) != _s(clean.get("project_id"))):
        clean["column"] = ""
    _ack_on_assign(before, clean, _s(actor_id))
    clean["audit"] = (clean.get("audit") or [])[-AUDIT_KEEP:]
    # ⭐⭐⭐ СЛІД ЗАМІЩЕННЯ РАХУЄ САМЕ ЗБЕРЕЖЕННЯ (зміна 224). Не окремий виклик
    # поруч, який можна забути в одному з двадцяти місць, а частина запису:
    # «Петренко (заміщує Іваненка): стадія → Виконано». Те саме йде в подію,
    # тому рот скаже те саме, що й журнал задачі.
    stand_for = deputy_for(clean, _s(actor_id))
    said = _reason(kind, det, clean)
    if stand_for:
        who = _who(stand_for)      # ОДИН писар імен для людського тексту
        said = "заміщує %s · %s" % (who, said)
        det = dict(det)
        det["on_behalf_of"] = list(stand_for)
    clean["audit"].append({"at": clock.now(), "who": _s(actor_id),
                           "for": list(stand_for), "what": said[:300]})
    one_writer.write_json(p, clean)
    aud = audience(before, clean, kind, _s(actor_id))
    try:
        events.emit(kind, clean["id"], _s(actor_id), det, aud["now"],
                    title=_s(clean.get("title")), digest=aud["digest"])
    except Exception as e:
        # Задача вже на диску. Подію НЕ ковтаємо мовчки: лишаємо слід, з якого
        # її можна повторити, і кажемо вголос. Тихий успіх убиває продукт.
        events.lost({"kind": kind, "task_id": clean["id"], "actor_id": _s(actor_id),
                     "details": det, "to": aud["now"],
                     "task_title": _s(clean.get("title"))},
                    "не вдалося записати подію: %s" % e)
    _to_protocol(clean, actor_id, kind, det, bool(before))
    return task(clean["id"])


def _ack_on_assign(before: dict, clean: dict, actor_id: str) -> None:
    """⭐⭐ 706. ОДИН ПИСАР «ВИКОНАВЕЦЬ МАЄ ПІДТВЕРДИТИ». Задача дісталась новому
    виконавцю — хоч створенням, хоч передачею, хоч правкою, хоч ботом, — і саме тут
    на нього лягає «не підтверджено». Двері, які забули б це зробити, неможливі:
    повз `save()` задача не зберігається.

    Не просимо, коли виконавця нема, коли це задача собі або без постановника
    (питати уточнення нема в кого), і коли людина взяла задачу сама."""
    new = _s(clean.get("assignee_id"))
    old = _s((before or {}).get("assignee_id")) if before else None
    if old == new:
        return
    author = _s(clean.get("author_id"))
    if not new or not author or new == author or new == actor_id:
        clean["ack"] = {}
        return
    clean["ack"] = {"for": new, "state": ACK_PENDING, "since": clock.now(), "at": "",
                    "question_id": "", "asked": 0, "unclear_at": ""}


def _lateness(due_iso: str, done_iso: str) -> tuple:
    """(підсумок словами, днів запізнення) для факту закриття задачі.

    ⭐ ЧОМУ ЦЕ ФАКТ, А НЕ РОЗБІР ТЕКСТУ (зміна 173). «Відсоток своєчасного
    виконання» — те, заради чого Андрій просив рейтинг. Якби він рахувався
    пошуком слова в примітці, це був би рівно наш власний заборонений «чек по
    рядку в тексті»: варто комусь переписати формулювання — і відсоток мовчки
    поїде. Тому висновок робиться ТУТ, один раз, з двох дат.

    ⚠ СТРОКУ МОГЛО НЕ БУТИ, і це не «вчасно». Задача-нагадування без терміну
    не має чого порушувати — вигадати їй «вчасно» означало б завищити рейтинг
    того, хто просто не ставить строків."""
    from datetime import datetime          # як і решта дат у цьому файлі
    due, done = _s(due_iso), _s(done_iso)
    if not due:
        return ("строку не було", 0)
    try:
        d1 = datetime.fromisoformat(due[:19] if len(due) >= 19 else due[:10])
        d2 = datetime.fromisoformat(done[:19] if len(done) >= 19 else done[:10])
    except Exception:
        return ("строку не було", 0)
    if d2 <= d1:
        return ("вчасно", 0)
    late = (d2.date() - d1.date()).days
    return ("із запізненням", max(late, 0))


def _to_protocol(clean: dict, actor_id, kind: str, det: dict, existed: bool) -> None:
    """ТОЧКА ВРІЗКИ №2 — ЗАДАЧІ (хребет, 13.08.2026).

    ⛒ НЕРВ (`taskdesk_events`) ЗАЛИШАЄТЬСЯ НЕРВОМ. Він веде чергу доставки й
    курсори ротів — навантажити його ще й платформною аналітикою означало б
    зробити з одного механізму два. Тому він просто ще одне ДЖЕРЕЛО протоколу.

    ⭐ Створення і зміна — РІЗНІ дієслова, бо це різні відповіді на питання «де
    робота застрягає»: народження задачі і рух по ній рахуються окремо. Різницю
    знає рівно це місце (`before` уже прочитано з диска), тому вгадувати не треба.

    ⚠ Ніколи не кидає: задача вже на диску."""
    # ⭐ КРОК B2: ЗВʼЯЗОК ЗВІТУЄ САМ РЕЄСТР (`link.created` / `link.removed`) —
    # бо звʼязок тепер буває не лише в задачі. Написати ще й звідси означало б
    # ДВА рядки протоколу на одну дію, і будь-який підрахунок «скільки звʼязків
    # завели» подвоївся б. Старі рядки `task.linked` / `task.unlinked` лишаються
    # у словнику назавжди і читаються звітом: журнал append-only не переписують.
    if kind in (events.KIND_LINKED, events.KIND_UNLINKED):
        return
    try:
        ref = entity.ref(entity.KIND_TASK, _s(clean.get("id")))
        who = entity.person_of_employee(_s(actor_id))
        # ⚠ МАШИННИЙ ФАКТ НЕ ВІДКРИВАЄ КРОКУ РОБОТИ. Сторож строків обходить сотні
        # задач підряд; якби кожна лишалась у контексті потоку, наступний запис
        # приписався б випадковій сусідці.
        if kind != events.KIND_OVERDUE:
            protocol.bind(task=ref)
            if who:
                protocol.bind(actor=who)
        act = protocol.A_TASK_CHANGED if existed else protocol.A_TASK_CREATED
        outcome = protocol.OUT_OK
        about = []
        source = ""
        note_over = ""

        # ⭐⭐⭐ РЯДОК НАЗИВАЄ ОБИДВІ СТОРОНИ (зміна 173, 14.08.2026).
        # КОРІНЬ. Постановник у протоколі був завжди — це `актор`. А виконавця
        # не було НІДЕ: журнал казав «Петренко поставив задачу» і не казав
        # КОМУ. Через це не збиралась пара «хто → кому», а без неї немає ні
        # рейтингу постановників, ні виконавської дисципліни підрозділу —
        # рівно того, заради чого Андрій просив протокол (14.08.2026).
        # ⛒ ВИКОНАВЦЯ ПИШЕМО ЛИШЕ ТУДИ, ДЕ ПИТАННЯ «КОМУ» МАЄ СЕНС: народження
        # задачі · рух по стадіях (зокрема закриття) · зміна виконавця ·
        # протермінування · відмова. Вішати його на КОЖЕН коментар означало б
        # роздути журнал і зробити «дій по людині» мірою балакучості, а не роботи.
        # ⛒ І ЛИШЕ ІДЕНТИЧНІСТЬ (`person:emp-…`), А НЕ КОПІЯ ПОЛІВ. Підрозділ,
        # посада, керівник живуть у `taskdesk_people` і приєднуються ПРИ
        # ЧИТАННІ звіту. Якби відділ лягав копією в рядок, то переведення
        # людини в інший відділ змусило б увесь торішній журнал брехати.
        _SIDED = (events.KIND_CREATED, events.KIND_STAGE, events.KIND_DELEGATED,
                  events.KIND_OVERDUE, events.KIND_REFUSED,
                  # ⭐ 706: провал перевірки — питання «на кому висіло» тут головне.
                  events.KIND_FAILED, events.KIND_EXPLAINED,
                  # ⭐ 708: ранній початок етапу — теж «на кому висить».
                  events.KIND_EARLY)
        if kind in _SIDED:
            _ass = entity.person_of_employee(_s(clean.get("assignee_id")))
            if _ass:
                about = [_ass]

        if kind == events.KIND_REFUSED:
            outcome = "%s: %s" % (protocol.OUT_REFUSED,
                                  _s(det.get("reason")) or "виконавець відмовився")
        elif kind == events.KIND_STAGE and _s(det.get("stage")) == STAGE_DONE:
            # ⭐ ЗАКРИТТЯ — ОКРЕМЕ ДІЄСЛОВО, А ПІДСУМОК — ГОТОВИЙ ВИСНОВОК.
            # Раніше це був звичайний `task.changed` із приміткою «стадія →
            # Виконана»: щоб порахувати відсоток вчасних, звіту довелося б
            # шукати підрядок у тексті. Тепер «вчасно / із запізненням» стоїть
            # у самому рядку, і формулювання можна міняти без шкоди рахунку.
            act = protocol.A_TASK_DONE
            _verdict, _days = _lateness(_s(clean.get("due_at")), clock.now())
            # ⛒ ВЕРДИКТ — У ПІДСУМОК, А НЕ В ТЕКСТ. Примітка лишається для ока
            # людини; рахує звіт САМЕ підсумок (`protocol.OUT_LATE`), тому
            # формулювання можна переписати, не зламавши жодного відсотка.
            if _verdict == "із запізненням":
                outcome = "%s: %s" % (protocol.OUT_LATE,
                                      "строк %s, прострочено на %d дн."
                                      % (_human(_s(clean.get("due_at"))), _days))
            note_over = ("виконано %s" % _verdict
                         + (" на %d дн." % _days if _days else ""))
        elif kind == events.KIND_OVERDUE:
            act = protocol.A_TASK_OVERDUE
            # Протермінування — це межа ЧАСУ, яка обірвала роботу, а не поломка
            # і не відмова: у словнику підсумків це рівно `stopped`.
            outcome = "%s: %s" % (protocol.OUT_STOPPED,
                                  "строк %s минув" % _human(_s(det.get("due"))))
            # ⚠ ДІЯЧА-ЛЮДИНИ ТУТ НЕМАЄ І ВИГАДУВАТИ ЙОГО НЕ МОЖНА. Хто це зробив,
            # каже ДЖЕРЕЛО: сама платформа. Підставити сюди виконавця означало б
            # записати в журнал, ніби він щось зробив, — а він саме що НЕ зробив.
            # ⭐ І ЦЕ НЕ СУПЕРЕЧИТЬ ВИКОНАВЦЮ В `about` (173): «діяч» відповідає
            # на питання ХТО ЗРОБИВ, а «про кого» — НА КОМУ ВИСІЛО. Друге для
            # протермінування якраз і є суттю рядка, і мовчати про це не можна:
            # інакше «де підрозділ гальмує» не порахувати взагалі.
            source = protocol.S_SYSTEM
        # 🩸 І КОНТЕКСТ КРОКУ СЮДИ НЕ ЗАЛІЗЕ. Порожній діяч доповнюється тим, хто
        # діяв на цьому потоці востаннє, — і рядок «строк минув» дістав би імʼя
        # людини, яка саме що НІЧОГО не робила. Той самий клас, що й ціна кроку,
        # приписана останньому прогону (зміна 169).
        protocol.write(act, ref, actor=who, about=about, outcome=outcome,
                       source=source, note=note_over or _reason(kind, det, clean),
                       use_context=(kind != events.KIND_OVERDUE))
    except Exception:
        pass


def _require_may_set(actor_id: str, target_id: str) -> None:
    """ВОРОТА ПОВНОВАЖЕНЬ — ОДНІ НА ВСІ ДВЕРІ.

    ⛒ Чому тут, а не в екрані: екранів у нас уже три (консоль, картка задачі,
    телеграм-пульт), і кожен наступний забув би спитати. Ядро задач — єдине
    вузьке місце, через яке фізично проходить будь-яка постановка."""
    # ⛒ БЕЗ `try/except` НА ІМПОРТІ: мовчазний except тут означав би ворота,
    # які тихо зникають, щойно в судді зʼявиться друкарська помилка. Хай падає
    # вголос — це дешевше за тихо роздані повноваження.
    import taskdesk_roles as roles
    try:
        roles.require_set_task(actor_id, target_id)
    except roles.RoleError as e:
        # Відмова їде людині ТИМИ САМИМИ словами, якими її сформулював суддя
        # повноважень: другого формулювання однієї відмови не буває.
        raise TaskError(str(e))


def _require_sod(verifier_id: str, assignee_id: str, co_ids, who: str = "") -> None:
    """⛒ SoD — ОДИН ПИСАР ПРАВИЛА «сам себе не перевіряють».

    Питають його ВСІ двері, через які склад задачі може змінитись: створення,
    правка, зміна виконавця. Правило написане один раз, бо переписане вдруге
    рано чи пізно розійдеться з першим — і одна з дверей почне пускати."""
    v = _s(verifier_id)
    if not v:
        return
    a = _s(assignee_id)
    if v == a:
        raise TaskError(
            "%s не може бути одночасно виконавцем і перевіряючим: перевірка, "
            "яку людина ставить сама собі, нічого не засвідчує."
            % (_who([v]) or "Ця людина"))
    if v in _ids(co_ids):
        raise TaskError(
            "%s працює над задачею як співвиконавець, тож перевіряти її "
            "результат не може." % (_who([v]) or "Ця людина"))


def _require_worker(emp_id: str, what: str):
    """Виконавцем-людиною може бути ВИКЛЮЧНО активний працівник компанії."""
    emp = people.employee(emp_id)
    if not emp:
        # ⭐ 24.08.2026. У порожній системі «не знайдено» — це не відповідь.
        # Перший крок називає ОДИН писар (`people.setup_state`), тому екран,
        # постановка задачі й телеграм кажуть людині те саме.
        st = people.setup_state(emp_id)
        if not st["ready"]:
            raise TaskError(st["hint"])
        raise TaskError("Працівника для ролі «%s» не знайдено." % what)
    if not people.can_receive_tasks(emp_id):
        raise TaskError("%s не може отримувати задачі: працівник звільнений."
                        % emp.get("full_name", what))
    return emp


def _human(iso: str) -> str:
    """Термін у сліді — очима людини (DD.MM.YYYY), а не як на диску."""
    v = _s(iso)
    if len(v) < 10:
        return v
    out = "%s.%s.%s" % (v[8:10], v[5:7], v[0:4])
    return (out + " " + v[11:16]) if len(v) >= 16 else out


def _who(ids) -> str:
    """Імена людей для тексту, який ЧИТАЄ людина.

    ⚠ ЗНАЙДЕНО ЧЕКОМ 24.08.2026 (зміна 207). Тут стояло
    `people.employee(i).get(...)` — і будь-який порожній або невідомий номер
    ронив усю дію з `AttributeError` замість того, щоб дати текст. Лікуємо не
    один випадок, а КЛАС: порожні номери відкидаємо, невідомого називаємо його
    ж номером. Відмова чи слід не сміють падати через те, що когось звільнили
    або поле лишили порожнім."""
    out = []
    for i in (ids or []):
        i = _s(i)
        if not i:
            continue
        out.append((people.employee(i) or {}).get("full_name") or i)
    return ", ".join(out)


def _require_worktype(type_id: str) -> str:
    """Тип роботи НЕ обовʼязковий: без нього платформа працює рівно так, як
    працювала. Але названий тип мусить існувати й бути у вибору — інакше в
    задачі лишився б номер, за яким нічого немає, і стандарт мовчав би."""
    type_id = _s(type_id)
    if not type_id:
        return ""
    wt = worktypes.work_type(type_id)
    if not wt:
        raise TaskError("Такого типу роботи немає.")
    if not wt["active"]:
        raise TaskError("Тип роботи «%s» прибрано з вибору — оберіть інший."
                        % wt["name"])
    return type_id


def _check_checklist_due(due_task: str, checklist: list):
    """Пункт із терміном ЗА МЕЖЕЮ терміну задачі — відмова з причиною."""
    if not due_task:
        return
    limit = _due_key(due_task)
    for c in checklist:
        if c.get("due_at") and _due_key(c["due_at"]) > limit:
            raise TaskError(
                "Пункт «%s» має термін пізніший за термін задачі. "
                "Або перенесіть пункт, або посуньте термін задачі."
                % (c.get("text") or c.get("id")))


def _viewer(actor_id: str, is_admin: bool = False) -> "tprj.Viewer":
    """⭐ 705: хто дивиться на проєкти. Проєкти своїх задач рахуються ліниво й
    лише з тих задач, які людина БАЧИТЬ (одна функція видимості)."""
    actor_id = _s(actor_id)
    return tprj.Viewer(actor_id, is_admin,
                       lambda: {_s(t.get("project_id")) for t in visible_tasks(actor_id)
                                if _s(t.get("project_id"))})


def projects_for(actor_id: str, is_admin: bool = False) -> list:
    """Перелік проєктів, які людина має право обрати в НОВІЙ задачі. Судить
    `taskdesk_projects` (705): видимий і активний."""
    return tprj.for_pick(_viewer(actor_id, is_admin))


def _require_project(actor_id: str, project_id: str, is_admin: bool = False,
                     keep: str = "") -> str:
    """Ворота проєкту задачі. Порожньо — дозволено: задача без проєкту лишається
    звичайною задачею (4.3 Б). `keep` — проєкт, що вже стоїть у задачі: правка
    задачі неактивного чи архівного проєкту не ламається."""
    try:
        return tprj.require_for_task(_viewer(actor_id, is_admin), project_id, keep)
    except tprj.ProjectError as e:
        raise TaskError(str(e))


def project_name(project_id: str) -> str:
    """Назва проєкту для екрана. ⭐ ВИДАЛЕНИЙ ПРОЄКТ НЕ ЛАМАЄ ЗАДАЧУ: мітка
    лишається, а людина бачить чесне «проєкт видалено»; архівний — «(в архіві)»."""
    return tprj.display_name(project_id)


def create(actor_id: str, title: str, assignee_id: str = "", due_at: str = "",
           description: str = "", coassignee_ids=None, watcher_ids=None,
           checklist=None, source: str = "", source_ref: str = "",
           verifier_id: str = "", worktype_id: str = "",
           project_id: str = "", is_admin: bool = False, priority: str = "") -> dict:
    """Обовʼязкова лише НАЗВА.

    ⭐ Постановник має право записати задачу СОБІ й без терміну — як нагадування.
    Цієї можливості його позбавляти не можна (слова Андрія, 02.08.2026)."""
    title = _s(title)
    if not title:
        raise TaskError("У задачі має бути назва.")
    actor_id = _s(actor_id)
    if not actor_id:
        raise TaskError("Не видно, хто ставить задачу.")
    _require_worker(actor_id, "постановник")

    assignee_id = _s(assignee_id) or actor_id
    _require_worker(assignee_id, "виконавець")
    # ⭐⭐⭐ ЕТАП 2 (24.08.2026). ХТО КОМУ МАЄ ПРАВО СТАВИТИ ЗАДАЧУ.
    # Доти воріт не було зовсім: будь-який працівник міг поставити задачу
    # будь-кому. Малій компанії це не муляє, держзамовник питає першим.
    # Судить ОДИН писар повноважень — `taskdesk_roles`, — і його ж питають
    # телеграм і майбутній мобільний. Другого шляху завести задачу немає.
    _require_may_set(actor_id, assignee_id)

    co = [x for x in _ids(coassignee_ids) if x != assignee_id]
    for x in co:
        _require_worker(x, "співвиконавець")
        # ⛒ Співвиконавець — це РЕСУРС, доданий постановником (рішення 19), але
        # людині все одно лягає робота. Отже те саме питання про повноваження.
        _require_may_set(actor_id, x)
    watchers = [x for x in _ids(watcher_ids) if x != assignee_id and x not in co]

    # ⭐ ПЕРЕВІРЯЮЧИЙ — НЕОБОВʼЯЗКОВО. Порожньо — і задача поводиться точно так,
    # як усі задачі до 24.08.2026.
    # ⛒ ЧОМУ ТУТ НЕ ПИТАЄМО МАТРИЦЮ ПОВНОВАЖЕНЬ. Матриця судить ПОСТАНОВКУ
    # задач («хто кому може ставити»), а призначення перевіряючого — інша вісь.
    # Тягнути сюди чужий дозвіл означало б судити одну дію правилом іншої. Свій
    # дозвіл зʼявиться РАЗОМ зі своїми воротами, не раніше: дозвіл, якого ніхто
    # не питає, — декорація.
    verifier_id = _s(verifier_id)
    if verifier_id:
        _require_worker(verifier_id, "перевіряючий")
    _require_sod(verifier_id, assignee_id, co)

    items = []
    for i, c in enumerate(checklist or []):
        if not _s((c or {}).get("text")):
            continue
        items.append({"id": "c%d" % (i + 1), "text": _s(c.get("text")),
                      "done": False, "due_at": _norm_due(c.get("due_at")),
                      "assignee_id": _s(c.get("assignee_id"))})
    due_at = _norm_due(due_at)
    _check_checklist_due(due_at, items)

    # ⭐⭐ ЗНІМОК СТАНДАРТУ ГОТОВНОСТІ РОБИТЬСЯ ТУТ — у ЄДИНИХ дверях, якими
    # задача народжується (екран, один рядок, телеграм, пошта, розклад).
    # Тому новий вхід отримає стандарт безкоштовно, а забути його неможливо.
    worktype_id = _require_worktype(worktype_id)
    dod = worktypes.snapshot(worktype_id)

    # ⭐⭐ ПРОЄКТ ПИТАЄТЬСЯ ТУТ — у ЄДИНИХ дверях, якими задача народжується.
    # Тому телеграм, пошта й розклад дістануть поле безкоштовно, а забути його
    # неможливо: іншого шляху завести задачу немає.
    project_id = _require_project(actor_id, project_id, is_admin)   # ⭐ 705: адміністратор
    priority = _require_priority(priority)                          # ⭐ 734

    # ⭐⭐⭐ ДЖЕРЕЛО СТАВИТЬ ТОЙ, ХТО КРОК ВІДКРИВ (зміна 173, 14.08.2026).
    # КОРІНЬ. Поле `source` лежало в КОЖНІЙ задачі з першого дня — і його не
    # писав НІХТО й не читав НІХТО (перевірено по всьому коду 14.08). Рівно та
    # сама історія, що з `links` у зміні 172. Мертве поле гірше за відсутнє:
    # наступний, хто його прочитає, дістане порожньо і чесно вирішить, що
    # задача взялась нізвідки.
    # ⛒ Але писати його РУКАМИ в кожному вході (телеграм, пошта, розклад, CRM)
    # означало б завести стільки писарів, скільки дверей, — і перший же новий
    # вхід тихо забув би. Тому джерело береться з ВІДКРИТОГО КРОКУ: двері вже
    # назвали себе для протоколу (`telegram_bot._open_step`, закон зміни 169),
    # і задача бере ту саму правду з того самого місця. Один писар на всіх.
    # ⚠ ЯВНО ПЕРЕДАНЕ ПЕРЕМАГАЄ: викликач, який ЗНАЄ джерело точніше за крок,
    # не мусить із ним боротись.
    # ⛔ У КАРТЦІ ЦЬОГО НЕ ПОКАЗУЄМО — слово Андрія 14.08: «позначати ворота, через
    # які зайшла задача, не обовʼязково для операційного процесу». Поле живе для
    # аналітики, а не для екрана.
    src = _s(source)
    if not src:
        try:
            src = _s(protocol.context().get("source"))
        except Exception:
            src = ""
    t = _normalize({
        "id": next_id(), "title": title, "description": _s(description),
        "author_id": actor_id, "assignee_id": assignee_id,
        "coassignee_ids": co, "watcher_ids": watchers,
        "verifier_id": verifier_id,
        "stage": STAGE_NEW, "due_at": due_at, "checklist": items,
        "worktype_id": worktype_id, "dod": dod,
        "feed": [], "created_at": clock.now(),
        "source": src, "source_ref": _s(source_ref),
        "project_id": project_id, "priority": priority,
    }, next_id())
    return save(t, actor_id, events.event(events.KIND_CREATED))


def _require_priority(value) -> str:
    """⭐ 734: порожньо — «Стандартний»; невідоме — відмова словами, а не тихе «стандартний»
    (людина вибрала щось і думала б, що воно стоїть)."""
    v = _s(value) or PRIORITY_STANDARD
    if v not in PRIORITIES:
        raise TaskError("Пріоритету «%s» немає. Є такі: %s." % (
            v, ", ".join([PRIORITY_NAMES[p] for p in PRIORITIES])))
    return v


def comment(tid: str, actor_id: str, text: str, as_result: bool = False,
            is_admin: bool = False, match: dict = None, tpl: dict = None) -> dict:
    """Стрічка — це середовище задачі: вказівки, питання й матеріали результату
    живуть в одному місці. Позначка «це результат» ставиться на КОМЕНТАРІ.
    ⭐ 707: `tpl` — відповіді шаблону (їх складає лише `comment_by_template`)."""
    t = task(tid)
    actor_id = _s(actor_id)
    require(t, actor_id, ACT_COMMENT, is_admin)
    text = _s(text)
    if not text:
        raise TaskError("Порожній коментар не додається.")
    raw = _strip_derived(t)
    cid = "m%d" % (len(raw["feed"]) + 1)
    item = {"id": cid, "author_id": actor_id, "text": text,
            "at": clock.now(), "kind": "comment"}
    extra = {}
    if tpl:
        item["tpl"] = tpl
        extra = {"tpl": _tpl_event(tpl), "project_id": _s(t.get("project_id"))}
    raw["feed"].append(item)
    ev = events.event(events.KIND_COMMENT, comment_id=cid, text=text[:300], **extra)
    if as_result:
        require(t, actor_id, ACT_RESULT, is_admin)
        _require_explained(t)
        raw["result_comment_id"] = cid
        # ⭐ ЗВІРКУ ПРИВʼЯЗУЄ ПИСАР, А НЕ ТОЙ, ХТО ЇЇ ПРИНІС. Мозок знає, ЩО він
        # порівняв; ЯКИЙ це результат — знає лише той, хто його щойно записав.
        # Дозволь принести `result_id` ззовні — і перше ж розходження видало б
        # звірку чужого результату за звірку цього.
        # ⚠ ЗАТИРАЄМО ЛИШЕ ТОДІ, КОЛИ Є ЧИМ. Спершу я писав сюди порожнє,
        # коли звірки немає, — і стара звірка ЗНИКАЛА з файла. Тоді `match_fresh`
        # не тримав нічого: гасив не він, а затирання. Тепер запис живе, як живе
        # `verified_result_id`: він далі каже, ЯКИЙ результат звіряли, а рівність
        # із поточним сама показує, що він уже не про нього.
        if match:
            raw["match"] = _attach_match(match, cid)
        ev = events.event(events.KIND_RESULT, comment_id=cid, text=text[:300],
                          with_text=True)
    return save(raw, actor_id, ev)


def _tpl_event(record: dict) -> dict:
    """Що з відповідей шаблону їде в подію: назва і причини (вибори) — для дзеркала."""
    return {"id": _s(record.get("id")), "name": _s(record.get("name")),
            "answers": templates.reasons_of(record)}


def comment_by_template(tid: str, actor_id: str, template_id: str, answers,
                        is_admin: bool = False) -> dict:
    """⭐⭐ 707 (3.7): «ДОДАТИ ЗА ШАБЛОНОМ». Поля судить довідник (`taskdesk_templates.fill`),
    і коментар лягає вже впорядкованим: текст для ока і відповіді окремо — для лічби.
    Права — ті самі, що в звичайного коментаря."""
    t = task(tid)
    require(t, actor_id, ACT_COMMENT, is_admin)
    try:
        got = templates.fill(template_id, answers, templates.PURPOSE_ANY)
    except templates.TemplateError as e:
        raise TaskError(str(e))
    return comment(tid, actor_id, got["text"], False, is_admin, tpl=got["record"])


def _attach_match(match, result_id: str) -> dict:
    """Звірка стає чинною лише разом з номером результату, до якого належить."""
    if not isinstance(match, dict) or not match:
        return {}
    return _match({"result_id": result_id,
                   "asked": match.get("asked"),
                   "given": match.get("given"),
                   "missing": match.get("missing") or [],
                   "at": clock.now()})


def mark_result(tid: str, actor_id: str, comment_id: str,
                is_admin: bool = False, match: dict = None) -> dict:
    t = task(tid)
    require(t, actor_id, ACT_RESULT, is_admin)
    _require_explained(t)
    if not any(c["id"] == _s(comment_id) for c in t["feed"]):
        raise TaskError("Такого коментаря в задачі немає.")
    raw = _strip_derived(t)
    raw["result_comment_id"] = _s(comment_id)
    if match:
        raw["match"] = _attach_match(match, _s(comment_id))
    return save(raw, actor_id, events.event(events.KIND_RESULT,
                                            comment_id=_s(comment_id)))


# Хто має право перевести задачу в стадію. Постановник веде приймання,
# виконавець і співвиконавці — хід роботи.
# ⭐ Перевіряючий повертає роботу на доопрацювання САМ: інакше він мусив би
# просити про це постановника, і ланка, задумана як економія, стала б чергою.
STAGE_RIGHTS = {
    STAGE_WORK: (ROLE_ASSIGNEE, ROLE_CO, ROLE_AUTHOR, ROLE_VERIFIER),
    STAGE_REVIEW: (ROLE_ASSIGNEE, ROLE_CO),
    STAGE_DONE: (ROLE_AUTHOR,),
    STAGE_HOLD: (ROLE_AUTHOR,),
    STAGE_CANCEL: (ROLE_AUTHOR,),
    STAGE_NEW: (ROLE_AUTHOR,),
    # ⛒ 706: у «Не пройшла перевірку» стадією не переводять — лише «Не прийняти».
    STAGE_FAILED: (),
}


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ОДНА ТАБЛИЦЯ ПРАВ НА ВЕСЬ TASK DESK (08.08.2026, вимога Андрія)
#
# Досі кожна дія перевіряла права САМА, всередині себе, а екран малював кнопки
# за власними «якщо». Це ДВА ПИСАРІ ОДНІЄЇ ПРАВДИ: варто розійтись — і людина
# бачить кнопку, яка відмовить, або НЕ бачить дії, на яку має право. Той самий
# клас, що й видимість: її вже сторожить ОДНА функція `visible_ids()`.
#
# Тепер право оголошене рівно тут, а питають його троє: сама дія, відмова
# словами і екран (через `rights()` у відповіді сервера).
#
# ⭐ АДМІНІСТРАТОР — НЕ РОЛЬ У ЗАДАЧІ, А ШАР НАД НЕЮ. Тому він приходить
# окремим прапорцем `is_admin`, а не підмішується до ролей: у задачі його може
# не бути взагалі. І шар цей ВУЗЬКИЙ — рівно те, що назвав Андрій: правити,
# скасувати, змінити виконавця. Позначати результат замість виконавця він не
# може: інакше «доказ виконання» перестав би бути доказом.
# ---------------------------------------------------------------------------
ACT_EDIT = "edit"
ACT_REASSIGN = "reassign"
ACT_CANCEL = "cancel"
ACT_COMMENT = "comment"
ACT_RESULT = "result"
ACT_CHECK = "check"
ACT_DOD = "dod"      # позначити пункт стандарту готовності
ACT_REFUSE = "refuse"
ACT_VERIFY = "verify"
# ⭐ 706. «Не прийняти» (з причиною), «Пояснити й повернути в роботу», «Зрозумів задачу»
# (і «Потрібне уточнення» — те саме право: обидві — відповідь виконавця на постановку).
ACT_REJECT = "reject"
ACT_EXPLAIN = "explain"
ACT_ACK = "ack"
# ⭐ 708 (3.5): етапи головної веде її постановник; почати етап раніше попереднього (з
# поясненням) — той, хто його робить, або постановник.
ACT_STEPS = "steps"
ACT_EARLY = "early"


def stage_action(stage: str) -> str:
    """Скасування — не «ще одна стадія», а окрема дія: у неї свої права.
    Так само «Не пройшла перевірку» (706): туди веде лише «Не прийняти»."""
    if stage == STAGE_FAILED:
        return ACT_REJECT
    return ACT_CANCEL if stage == STAGE_CANCEL else "stage:" + _s(stage)


ACTION_ROLES = {
    ACT_EDIT: (ROLE_AUTHOR,),
    ACT_REASSIGN: (ROLE_ASSIGNEE, ROLE_AUTHOR),
    ACT_CANCEL: (ROLE_AUTHOR,),
    ACT_COMMENT: (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_WATCHER),
    ACT_RESULT: (ROLE_ASSIGNEE, ROLE_CO),
    ACT_CHECK: (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    # ⭐ Стандарт позначає той, хто РОБИТЬ роботу, і той, хто за неї
    # відповідає. Перевіряючому позначати за виконавця не можна: він
    # засвідчує результат, а не робить його.
    ACT_DOD: (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    ACT_REFUSE: (ROLE_ASSIGNEE, ROLE_CO),
    # ⛒ Підтвердити перевірку може ЛИШЕ той, кого на неї призначили. Ні
    # постановник, ні виконавець сюди не входять: перевірка, яку ставить собі
    # сам учасник роботи, нічого не засвідчує.
    ACT_VERIFY: (ROLE_VERIFIER,),
    # ⭐ 706 (3.4): не приймає перевіряючий — або постановник. Постановника не
    # відсторонено й там, де є перевіряючий: приймає роботу саме він (`STAGE_DONE`),
    # і без права не прийняти в нього лишився б глухий кут — прийняти погане або
    # мовчати. Виконавець і спостерігач сюди не входять.
    ACT_REJECT: (ROLE_VERIFIER, ROLE_AUTHOR),
    ACT_EXPLAIN: (ROLE_ASSIGNEE, ROLE_CO),
    # ⭐ 706 (3.6): «зрозумів» каже ТОЙ, НА КОМУ ВІДПОВІДАЛЬНІСТЬ, — виконавець.
    ACT_ACK: (ROLE_ASSIGNEE,),
    ACT_STEPS: (ROLE_AUTHOR,),
    ACT_EARLY: (ROLE_ASSIGNEE, ROLE_CO, ROLE_AUTHOR),
}
for _st in STAGES_ALL:                       # стадії беруть права зі STAGE_RIGHTS
    ACTION_ROLES.setdefault(stage_action(_st), STAGE_RIGHTS.get(_st, ()))

ACTION_NAMES = {
    ACT_EDIT: "змінювати текст, терміни й склад задачі",
    ACT_REASSIGN: "змінювати виконавця",
    ACT_CANCEL: "скасувати задачу",
    ACT_COMMENT: "коментувати задачу",
    ACT_RESULT: "позначати результат",
    ACT_CHECK: "вести пункти плану",
    ACT_DOD: "позначати стандарт готовності",
    ACT_REFUSE: "відмовитись від задачі",
    ACT_VERIFY: "підтверджувати перевірку результату",
    ACT_REJECT: "не приймати результат (з причиною)",
    ACT_EXPLAIN: "пояснювати провал перевірки й повертати задачу в роботу",
    ACT_ACK: "підтверджувати, що задачу зрозуміло, або просити уточнення",
    ACT_STEPS: "додавати й переставляти етапи великої задачі",
    ACT_EARLY: "починати етап раніше попереднього (з поясненням)",
}
for _st in STAGES_ALL:
    ACTION_NAMES.setdefault(stage_action(_st),
                            "переводити задачу в «%s»" % STAGE_NAMES[_st])

# ---------------------------------------------------------------------------
# ⭐⭐⭐ АДМІНІСТРАТОР МОЖЕ ВСЕ (рішення Андрія 09.08.2026 — СКАСОВУЄ його ж
# рішення від 08.08).
#
# 08.08 цей шар був ВУЗЬКИЙ (правити · скасувати · змінити виконавця), і причина
# була така: «позначати результат замість виконавця адміністратор не може,
# інакше доказ виконання перестане бути доказом».
#
# ЩО ЗМІНИЛО РІШЕННЯ. Андрій на живому впіймав глухий кут: він адміністратор і
# власник платформи, але прийняти задачу не міг, бо приймає ПОСТАНОВНИК. Це не
# примха — це цілий КЛАС: пішов у відпустку постановник, звільнився виконавець,
# і задача застрягає назавжди, бо єдина людина з правом недосяжна.
#
# ⭐ ЧОМУ СТАРА ПРИЧИНА НЕ ВТРАЧЕНА. Доказ виконання тримався не на ЗАБОРОНІ, а
# на СЛІДІ: `save()` пише в журнал задачі, ХТО саме зробив дію. Якщо результат
# позначив адміністратор, у журналі стоїть його імʼя, а не виконавцеве. Доказ не
# зник — він ПІДПИСАНИЙ. А `rights()` окремо називає, які дії людина має САМЕ
# як адміністратор, щоб вона тиснула кнопку свідомо.
#
# ⚠ ТОМУ ЦЕЙ ПЕРЕЛІК БІЛЬШЕ НЕ ПИШУТЬ РУКАМИ: він дорівнює ВСІМ оголошеним
# діям. Нова дія отримує адмінське право сама — інакше через місяць знову
# зʼявився б глухий кут у дії, яку забули сюди вписати.
# ---------------------------------------------------------------------------
ADMIN_ACTIONS = tuple(ACTION_NAMES)


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ХТО ПРО ЩО ДІЗНАЄТЬСЯ. Друга таблиця на ТИХ САМИХ ролях, навмисно поруч
# із таблицею прав: «кого повідомити» не сміє розповзтися по екранах і ротах.
#
# Спостерігач не отримує кожен коментар і кожну галочку в плані. Бот, який
# шумить, вимикають — і тоді нерв марний.
# ---------------------------------------------------------------------------
KIND_ROLES = {
    events.KIND_CREATED:       (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER,
                                ROLE_WATCHER),
    events.KIND_COMMENT:       (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    # ⭐ ПРО ГОТОВИЙ РЕЗУЛЬТАТ ПЕРЕВІРЯЮЧИЙ МУСИТЬ ДІЗНАТИСЬ ПЕРШИМ: інакше
    # ланка, яку ввімкнули заради якості, перетворюється на мовчазний затор —
    # робота зроблена, а той, хто її дивиться, про це не знає.
    events.KIND_RESULT:        (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER,
                                ROLE_WATCHER),
    events.KIND_VERIFIED:      (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER),
    events.KIND_STAGE:         (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER,
                                ROLE_WATCHER),
    events.KIND_DELEGATED:     (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER,
                                ROLE_WATCHER),
    events.KIND_REFUSED:       (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER,
                                ROLE_WATCHER),
    events.KIND_UPDATED:       (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER,
                                ROLE_WATCHER),
    events.KIND_PROPOSAL:      (ROLE_AUTHOR, ROLE_ASSIGNEE),
    events.KIND_PROPOSAL_DONE: (ROLE_AUTHOR, ROLE_ASSIGNEE),
    events.KIND_CHECKLIST:     (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    events.KIND_DOD:           (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER),
    events.KIND_LINKED:        (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    events.KIND_UNLINKED:      (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO),
    # ⭐ ПРО СТРОК, ЩО МИНУВ, ЗНАЄ ТОЙ, КОГО ЗА НЬОГО ПИТАЮТЬ, І ТОЙ, ХТО ЙОГО
    # ПОСТАВИВ. Спостерігача сюди не беремо: сигнал, який приходить усім, швидко
    # перестають читати всі.
    events.KIND_OVERDUE:       (ROLE_ASSIGNEE, ROLE_CO, ROLE_AUTHOR),
    # ⭐ 706. Провал бачать усі, хто бачить стадію. Пояснення — ті, від кого чекають
    # рішення. Ясність постановки — питання ДО ПОСТАНОВНИКА, і лише до нього.
    events.KIND_FAILED:        (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER,
                                ROLE_WATCHER),
    events.KIND_EXPLAINED:     (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER),
    events.KIND_UNDERSTOOD:    (ROLE_AUTHOR,),
    events.KIND_CLARIFY:       (ROLE_AUTHOR,),
    events.KIND_UNCLEAR:       (ROLE_AUTHOR,),
    # ⭐ 708. Ранній початок етапу бачать усі, хто бачить стадію; «можна брати» — лише ті,
    # хто етап робить: решті він нічого не каже.
    events.KIND_EARLY:         (ROLE_AUTHOR, ROLE_ASSIGNEE, ROLE_CO, ROLE_VERIFIER,
                                ROLE_WATCHER),
    events.KIND_STEP_READY:    (ROLE_ASSIGNEE, ROLE_CO),
}


def recipients(before: dict, after: dict, kind: str, actor_id: str) -> list:
    """ЄДИНА відповідь «кого це стосується». Її питає `save()`, і більше ніхто
    не має права рахувати адресатів сам.

    ⭐ ОБʼЄДНАННЯ учасників ДО і ПІСЛЯ зміни. Інакше людина, яку щойно прибрали
    із задачі, не дізналася б, що її прибрали, а той, кого щойно додали, — що
    він зʼявився.

    ⭐ СОБІ НЕ ПИШЕМО: хто зробив дію, той про неї повідомлення не отримує.
    Мозок (`AI_ACTOR`) людиною не є, тож із його пропозицій не виключається
    ніхто."""
    allowed = KIND_ROLES.get(kind, ())
    actor_id = _s(actor_id)
    out = []
    # ⭐ ЗАМІЩЕННЯ (зміна 224): делегат бере права відсутнього — отже мусить і
    # ЗНАТИ, що сталося. Права без сповіщення — та сама половина воріт: людина
    # може все, але дізнається про це, лише відкривши екран сама.
    who = participants(after) + participants(before)
    for p in list(who):
        dep = people.deputy_of(p).get("id")
        if dep and dep not in who:
            who.append(dep)
    for emp in who:
        if emp in out or emp == actor_id:
            continue
        rr = tuple(roles_of(after, emp)) + tuple(roles_of(before, emp))
        if any(r in allowed for r in rr):
            out.append(emp)
    return out


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЗВЕДЕННЯ ЗАМІСТЬ ПʼЯТНАДЦЯТИ СПОВІЩЕНЬ (зміна 241, 27.08.2026).
#
# Зі звіту дослівно: замість пʼятнадцяти окремих сповіщень людина має отримати
# ОДНЕ зведення за проміжок. Телеграм-пульт найшвидше перетворюється на шум,
# який вимикають, — а вимкнений пульт не сповіщає ні про що взагалі.
#
# ⛒ МЕЖА ПРОХОДИТЬ ПО РОЛІ, А НЕ ПО ВИДУ ПОДІЇ:
#   • від кого чекають ДІЇ (постановник, виконавець, співвиконавець,
#     перевіряючий) — сповіщення ОДРАЗУ, як і було;
#   • кого лише ПОВІДОМЛЯЮТЬ (спостерігач) — ЗВЕДЕННЯ раз на проміжок.
# Спостерігач нічого не мусить робити просто зараз: негайність для нього — це
# переривання без причини.
#
# ⛒ І ОДИН ПИСАР АУДИТОРІЇ. Спокуса — завести другу функцію «а кому в
# зведення». Тоді два переліки розійшлися б на першій же новій ролі, і людина
# або отримувала б двічі, або не отримувала взагалі.
# ---------------------------------------------------------------------------
def audience(before: dict, after: dict, kind: str, actor_id: str) -> dict:
    """Кого сповіщати ОДРАЗУ, а кого — у зведенні. Одна відповідь, один обхід."""
    everyone = recipients(before, after, kind, actor_id)
    now, later = [], []
    for emp in everyone:
        rr = set(roles_of(after, emp)) | set(roles_of(before, emp))
        # Лише спостерігач — отже дії від нього не чекають.
        (later if rr and rr <= {ROLE_WATCHER} else now).append(emp)
    return {"now": now, "digest": later}


def may(t: dict, emp_id: str, action: str, is_admin: bool = False) -> bool:
    """ЄДИНА відповідь «чи можна». Її питають і код дії, і кнопки на екрані.

    ⭐ Ролей у людини може бути кілька — і тоді діє ТА, ЩО ДАЄ БІЛЬШЕ. Питати
    лише «головну» роль означало б відбирати права, які дала інша."""
    # ⛒⛒⛒ 27.08.2026 (знайшов Андрій живим прогоном). ПЕРЕВІРКИ НЕМАЄ ТАМ, ДЕ
    # НЕМАЄ ПЕРЕВІРЯЮЧОГО — і запасні двері адміністратора тут не двері, бо
    # немає кімнати. Раніше адміністратор бачив «Перевірив, годиться» на задачі,
    # де сама ж картка писала «Перевіряє результат: ніхто». Натиснув — у стрічку
    # лягло «Результат перевірено», і БІЛЬШЕ НІЧОГО, бо засвідчувати нема перед
    # ким. Кнопка, яка нічого не робить, бреше не менше за кнопку, що відмовить.
    # ⚠ Влада адміністратора не звужена: він і далі підтверджує перевірку скрізь,
    # де перевіряючого ПРИЗНАЧИЛИ. Прибрано лише дію, якої не існує.
    if action == ACT_VERIFY and not _s(t.get("verifier_id")):
        return False
    if is_admin and action in ADMIN_ACTIONS:
        return True
    allowed = ACTION_ROLES.get(action, ())
    return any(r in allowed for r in roles_of(t, emp_id))


def require(t: dict, emp_id: str, action: str, is_admin: bool = False):
    """Відмова завжди називає ПРИЧИНУ і того, хто б це зміг."""
    if may(t, emp_id, action, is_admin):
        return
    rr = roles_of(t, emp_id)
    who = ACTION_ROLES.get(action, ())
    what = ACTION_NAMES.get(action, action)
    allowed = " або ".join([ROLE_NAMES[r] for r in who]) if who else "ніхто"
    if action in ADMIN_ACTIONS:
        allowed += " або адміністратор"
    if not rr:
        raise TaskError("Ви не учасник цієї задачі, тож %s не можете. Це може %s."
                        % (what, allowed))
    mine = " і ".join([ROLE_NAMES[r] for r in rr])
    raise TaskError("Ви — %s, тож %s не можете. Це може %s."
                    % (mine, what, allowed))


def rights(t: dict, emp_id: str, is_admin: bool = False) -> dict:
    """Що САМЕ може ця людина з цією задачею — для екрана. Кнопка, якої тут
    немає, не малюється: кнопка, що відмовить, бреше не менше за її відсутність.

    ⭐ `by_admin` — дії, які людина має НЕ за своєю роллю в задачі, а лише як
    адміністратор. Влада без цього рядка була б тихою: людина тиснула б
    «Прийняти», не знаючи, що вона щойно зробила це ЗАМІСТЬ постановника, і
    саме її імʼя лишиться в журналі."""
    out = {a: may(t, emp_id, a, is_admin) for a in ACTION_NAMES}
    out["is_admin"] = bool(is_admin)
    out["by_admin"] = {a: (bool(is_admin) and may(t, emp_id, a, True)
                           and not may(t, emp_id, a, False))
                       for a in ACTION_NAMES}
    # ⭐ ТА САМА ЧЕСНІСТЬ ДЛЯ ЗАМІЩЕННЯ (зміна 224). Влада, про яку не сказали,
    # тиха: людина натиснула б «Прийняти», не знаючи, що зробила це замість
    # іншого — і в журналі лишиться саме її імʼя.
    stand_for = deputy_for(t, emp_id)
    own = {a: any(r in ACTION_ROLES.get(a, ()) for r in own_roles(t, emp_id))
           for a in ACTION_NAMES}
    out["deputy_for"] = stand_for
    out["by_deputy"] = {a: (bool(stand_for) and may(t, emp_id, a, False)
                            and not own[a])
                        for a in ACTION_NAMES}
    return out


def verify(tid: str, actor_id: str, is_admin: bool = False) -> dict:
    """⭐⭐⭐ «ПЕРЕВІРИВ, ГОДИТЬСЯ» — ОДНА ДІЯ ОДНІЄЇ ЛЮДИНИ.

    Ланка навмисно коротка: підтвердження — це одна кнопка, а не стадія й не
    ланцюг узгоджень. Незгода — «Не прийняти» з причиною (`reject`, 706): доти це
    було повернення «На доопрацювання» з коментарем, і провал не лишав сліду.

    ⛒ ПЕРЕВІРЯЄМО КОНКРЕТНИЙ РЕЗУЛЬТАТ: на диск лягає ЙОГО номер, а не
    прапорець. Нема результату — нема чого засвідчувати."""
    t = task(tid)
    require(t, actor_id, ACT_VERIFY, is_admin)
    if not t["result_comment_id"]:
        raise TaskError("Перевіряти поки нема чого: виконавець ще не позначив "
                        "жоден коментар як результат.")
    if t["verified"]:
        return t                       # двічі підтверджена перевірка — те саме
    raw = _strip_derived(t)
    raw["verified_result_id"] = t["result_comment_id"]
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": "Результат перевірено: годиться.",
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_VERIFIED,
                                            comment_id=t["result_comment_id"],
                                            **_who_where(t)))


def set_stage(tid: str, actor_id: str, stage: str, is_admin: bool = False,
              column: dict = None) -> dict:
    """⭐ ВОРОТА: завершити задачу без результату НЕ МОЖНА.

    Це не прапорець-прохання у формі, а умова закриття в коді: інакше «доказ
    виконання» тримається на добрій волі того, хто тисне кнопку.

    ⭐ ДРУГІ ВОРОТА (24.08.2026) — ЛИШЕ ТАМ, ДЕ ЇХ УВІМКНУЛИ: якщо в задачі є
    перевіряючий, приймати її, доки перевірку не підтверджено, зарано. Немає
    перевіряючого — ці ворота мовчать, і закриття лишається таким, як було."""
    stage = _s(stage)
    if stage not in STAGES_ALL:
        raise TaskError("Невідома стадія «%s». Відомі: %s"
                        % (stage, ", ".join(STAGE_NAMES[s] for s in STAGES_ALL)))
    t = task(tid)
    # ⛒⛒ 706: «Не пройшла перевірку» — лише кнопкою «Не прийняти» з причиною. Прямої
    # дороги немає нікому, адміністраторові теж: провал без причини — не провал.
    if stage == STAGE_FAILED:
        raise TaskError("У «Не пройшла перевірку» задача потрапляє лише через "
                        "«Не прийняти» — з причиною.")
    require(t, actor_id, stage_action(stage), is_admin)
    # ⛒⛒ 706: ПОВЕРНУТИ ЗДАНУ РОБОТУ — ЦЕ «НЕ ПРИЙНЯТИ». Доти постановник і
    # перевіряючий повертали «На доопрацювання» стадією, і провал не лишав сліду.
    # Забрати з перевірки собі може лише той, хто роботу робить, — це не провал.
    doers = {ROLE_ASSIGNEE, ROLE_CO}
    if (t["stage"] == STAGE_REVIEW and stage == STAGE_WORK
            and not doers & set(roles_of(t, actor_id))):
        raise TaskError("Щоб повернути здану роботу, натисніть «Не прийняти» і "
                        "напишіть причину: так провал перевірки лишиться в історії.")
    # ⛒ Із «Не пройшла перевірку» в роботу — лише поясненням виконавця; постановник
    # може відкласти чи скасувати задачу.
    if t["stage"] == STAGE_FAILED and stage not in (STAGE_HOLD, STAGE_CANCEL):
        raise TaskError("Задача не пройшла перевірку і чекає пояснення виконавця: "
                        "«Пояснити й повернути в роботу».")
    # ⛒⛒ 708 (4.4 Б): етап, що ще не почався, не рушає, доки не закрито попередні. Вихід
    # названо — «Почати раніше з поясненням»; уже початий (є запис) рухається вільно.
    if (stage in STEP_ACTIVE and t["stage"] in (STAGE_NEW, STAGE_HOLD)
            and t.get("step_wait") and not t.get("early")):
        raise TaskError(_wait_words(t))
    # ⛒⛒ 708: головну задачу закривають етапи. Поки є живий етап — відмова з ним; усі
    # закрито — результату не треба: результат головної — її етапи.
    by_steps = bool(t.get("steps"))
    if stage == STAGE_DONE and by_steps:
        left = [r for r in t["steps"] if not r["closed"]]
        if left:
            raise TaskError("Головна задача закривається, коли завершено всі етапи. Лишилось: %s."
                            % "; ".join(step_words(r) for r in left))
    if stage == STAGE_DONE and not t["result_comment_id"] and not by_steps:
        raise TaskError("Задачу не завершити без результату: виконавець має "
                        "позначити коментар зі зробленим як результат.")
    if stage == STAGE_DONE and t["verifier_id"] and not t["verified"] and not by_steps:
        raise TaskError(
            "Результат цієї задачі перевіряє %s. Приймати її можна після того, "
            "як перевірку підтверджено." % (t["verifier_name"] or "інша людина"))
    raw = _strip_derived(t)
    raw["stage"] = stage
    # ⭐ 709: `column` — власна колонка проєкту, у яку задачу перенесли (`set_column`
    # уже звірив, що вона цієї стадії й цього проєкту); без неї — основна колонка.
    col = column or {}
    raw["column"] = _s(col.get("id"))
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": "Стадія: %s" % STAGE_NAMES[stage] + (
                            " · колонка «%s»" % col["name"] if col else ""),
                        "at": clock.now(), "kind": "event"})
    # ⭐ 706: на кому висіла робота і чий проєкт — дзеркало судить «з першого разу»
    # у мить приймання, і вгадувати це згодом із сьогоднішнього файла не мусить.
    extra = {"column": col["name"]} if col else {}
    out = save(raw, actor_id, events.event(events.KIND_STAGE, stage=stage,
                                           **_who_where(t), **extra))
    return task(tid) if _steps_follow(out, actor_id) else out


def set_column(tid: str, actor_id: str, column_id: str, is_admin: bool = False) -> dict:
    """⭐⭐ 709 (3.3): ПЕРЕНЕСТИ ЗАДАЧУ В КОЛОНКУ ДОШКИ ПРОЄКТУ.

    ⛒ Колонка іншої стадії — це зміна стадії: ті самі двері `set_stage`, ті самі права,
    ворота й подія «стадія», тож сповіщення й статистика не знають про колонки нічого.
    ⛒ Колонка тієї самої стадії — лише місце на дошці: право — те саме, що перевести в
    цю стадію, подія — «правка», а не «стадія» (стадія не змінилась, і казати людям
    «стадія → У роботі» вдруге було б неправдою)."""
    t = task(tid)
    pid = _s(t.get("project_id"))
    if not pid:
        raise TaskError("Задача %s без проєкту: колонки є лише на дошці проєкту. Стадію "
                        "задачі змінюють, як завжди." % t["id"])
    cid = _s(column_id)
    col = next((c for c in tprj.board_columns(pid) if c["id"] == cid), None)
    if col is None:
        raise TaskError("На дошці проєкту «%s» такої колонки немає — оновіть сторінку."
                        % project_name(pid))
    if col["stage"] != t["stage"]:
        return set_stage(tid, actor_id, col["stage"], is_admin,
                         column=None if col["base"] else col)
    if col["id"] == t["column_id"]:
        return t
    require(t, actor_id, stage_action(t["stage"]), is_admin)
    raw = _strip_derived(t)
    raw["column"] = "" if col["base"] else col["id"]
    _feed_event(raw, actor_id, "Колонка: «%s»." % col["name"])
    return save(raw, actor_id, events.event(events.KIND_UPDATED,
                                            said=["колонка «%s»" % col["name"]]))


def column_load(project_id: str, column_id: str) -> int:
    """⭐ 709: скільки живих задач стоїть у колонці проєкту — рахуємо ВСІ, а не видимі
    тому, хто питає: колонку з чужою задачею прибирати так само не можна."""
    pid, cid = _s(project_id), _s(column_id)
    return len([t for t in load_all(include_closed=True)
                if _s(t.get("project_id")) == pid and t["column_id"] == cid])


# ---------------------------------------------------------------------------
# ⭐⭐⭐ 708: ЕТАПИ — ДІЇ (див. шапку розділу етапів біля `_steps_apply`).
# ---------------------------------------------------------------------------
STEP_ACTIVE = (STAGE_WORK, STAGE_REVIEW, STAGE_DONE)   # «рушати» — це сюди


def step_words(r: dict) -> str:
    """«етап 1 — Ірина Коваль, Нова» — одне формулювання на відмову, стрічку й бот.
    ⛒ БЕЗ НАЗВИ ЕТАПУ: стрічку й відмову читає той, кому сусідній етап може бути не видно,
    а збережений текст заднім числом не сховаєш. Назву показує картка — і лише видимим."""
    return "етап %d — %s, %s" % (r.get("n") or 0,
                                 _s(r.get("assignee_name")) or "без виконавця",
                                 _s(r.get("stage_name")))


def _wait_words(t: dict) -> str:
    return ("Попередній етап ще не завершено: %s. Етапи йдуть по черзі; почати раніше можна "
            "лише з поясненням за шаблоном — «Почати раніше з поясненням»."
            % "; ".join(step_words(r) for r in t.get("step_wait") or []))


def _feed_event(raw: dict, actor_id: str, text: str, kind: str = "event") -> None:
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": text, "at": clock.now(), "kind": kind})


def _steps_follow(step: dict, actor_id: str) -> bool:
    """ГОЛОВНА ЙДЕ ЗА ЕТАПАМИ, а наступний етап дізнається, що черга його.

    Викликає той, хто змінив стадію етапу, — уже ПІСЛЯ запису етапу (спершу правда, потім
    наслідок). Права тут не питаються: це не дія людини, а наслідок її дії; у журналі стоїть
    той, чия дія це спричинила. True — щось записано."""
    so = (step or {}).get("step_of") or {}
    pid = _s(so.get("id"))
    if not pid:
        return False
    try:
        p = task(pid)
    except TaskError:
        return False
    rows = p.get("steps") or []
    if not rows:
        return False
    did = False
    live = [r for r in rows if not r["closed"]]
    moved = [r for r in rows if r["stage"] not in (STAGE_NEW, STAGE_HOLD, STAGE_CANCEL)]
    target, text = "", ""
    if not live and any(r["done"] for r in rows) and p["stage"] not in STAGES_CLOSED:
        target, text = STAGE_DONE, "Усі етапи завершено — головна задача закрита."
    elif live and p["stage"] == STAGE_DONE:
        target, text = STAGE_WORK, ("Етап знову відкрито (%s) — головна задача знову в роботі."
                                    % step_words(live[0]))
    elif moved and p["stage"] == STAGE_NEW:
        target, text = STAGE_WORK, ("Робота почалась: %s — головна задача теж у роботі."
                                    % step_words(moved[0]))
    if target:
        raw = _strip_derived(p)
        raw["stage"] = target
        _feed_event(raw, actor_id, text)
        save(raw, actor_id, events.event(events.KIND_STAGE, stage=target, by_steps=True,
                                         **_who_where(p)))
        did = True
    # Наступний етап: перший живий після цього, якщо перед ним усе закрито і він ще не почався.
    if _s(step.get("stage")) in STAGES_CLOSED:
        ids = [r["id"] for r in rows]
        me = ids.index(step["id"]) if step.get("id") in ids else -1
        nxt = next((r for r in rows[me + 1:] if not r["closed"]), None) if me >= 0 else None
        if (nxt and nxt["stage"] == STAGE_NEW
                and all(r["closed"] for r in rows[:rows.index(nxt)])):
            k = task(nxt["id"])
            raw = _strip_derived(k)
            _feed_event(raw, actor_id, "Попередні етапи завершено — можна брати в роботу.")
            save(raw, actor_id, events.event(events.KIND_STEP_READY, n=nxt["n"], parent_id=pid,
                                             **_who_where(k)))
            did = True
    return did


def _step_parent(parent_id: str, actor_id: str, is_admin: bool) -> dict:
    p = task(parent_id)
    require(p, actor_id, ACT_STEPS, is_admin)
    if p["stage"] in STAGES_CLOSED:
        raise TaskError("Головна задача вже закрита — етапи в ній не змінюють.")
    return p


def add_step(parent_id: str, actor_id: str, title: str, assignee_id: str = "",
             due_at: str = "", verifier_id: str = "", description: str = "",
             is_admin: bool = False) -> dict:
    """«ДОДАТИ ЕТАП»: нова задача тими самими єдиними дверима (`create` — права, SoD, проєкт
    головної), звʼязок «підзадача» в реєстр і місце в черзі — останнє. Перший етап робить
    задачу великою; підзадачі, що вже були, стають етапами перед ним, за номером."""
    p = _step_parent(parent_id, actor_id, is_admin)
    kid = create(actor_id, title, assignee_id, due_at, description, verifier_id=verifier_id,
                 project_id=p["project_id"], is_admin=is_admin)
    try:
        links.add(entity.ref(entity.KIND_TASK, kid["id"]), links.REL_SUBTASK_OF,
                  entity.ref(entity.KIND_TASK, p["id"]),
                  by=entity.person_of_employee(_s(actor_id)))
    except links.LinkError as ex:
        raise TaskError("Задачу %s створено, але етапом вона не стала: %s" % (kid["id"], ex))
    raw = _strip_derived(p)
    if p.get("stepped"):
        order = [r["id"] for r in p.get("steps") or []]
    else:
        order = sorted(k for k in _kids_of(p["id"], links.index()) if k != kid["id"])
    order.append(kid["id"])
    raw["stepped"], raw["step_order"] = True, order
    n = len(order)
    who = _who([kid["assignee_id"]])
    # ⛒ Номером, не назвою: стрічку головної читає й той, кому сам етап не видно (`step_words`).
    _feed_event(raw, actor_id, "Додано етап %d (%s) — %s%s." % (
        n, kid["id"], who, (", до " + _human(kid["due_at"])) if kid["due_at"] else ""))
    return save(raw, actor_id, events.event(events.KIND_UPDATED,
                                            said=["додано етап %d — %s" % (n, who)]))


def move_step(parent_id: str, actor_id: str, step_id: str, up: bool = True,
              is_admin: bool = False) -> dict:
    """Переставити етап на місце вище чи нижче. Черга судиться за новим порядком одразу."""
    p = _step_parent(parent_id, actor_id, is_admin)
    order = [r["id"] for r in p.get("steps") or []]
    step_id = _s(step_id)
    if step_id not in order:
        raise TaskError("Такого етапу в цій задачі немає.")
    i = order.index(step_id)
    j = i - 1 if up else i + 1
    if not 0 <= j < len(order):
        raise TaskError("Етап уже %s." % ("перший" if up else "останній"))
    order[i], order[j] = order[j], order[i]
    raw = _strip_derived(p)
    raw["stepped"], raw["step_order"] = True, order
    _feed_event(raw, actor_id, "Етап %d (%s) переставлено на місце %d." % (i + 1, step_id, j + 1))
    return save(raw, actor_id, events.event(events.KIND_UPDATED,
                                            said=["етап %d — на місце %d" % (i + 1, j + 1)]))


def start_early(tid: str, actor_id: str, template_id: str = "", answers=None,
                text: str = "", is_admin: bool = False) -> dict:
    """«ПОЧАТИ РАНІШЕ З ПОЯСНЕННЯМ» (4.4 Б): етап у роботу, хоч попередній не завершено, —
    лише за шаблоном раннього початку (причина вибором — її рахує Дзеркало). Вільний текст —
    тільки коли довідник шаблонів не читається з диска: застряглий етап гірший за
    непорахований виняток. Запис — у етапі (`early`), червоним рядком у стрічці й подією."""
    t = task(tid)
    require(t, actor_id, ACT_EARLY, is_admin)
    if not t.get("step_of"):
        raise TaskError("Це не етап великої задачі: почати раніше нема чого — беріть у роботу "
                        "як звичайно.")
    if t["stage"] not in (STAGE_NEW, STAGE_HOLD) or t.get("early"):
        raise TaskError("Етап уже почато — пояснювати ранній початок нема чого.")
    if not t.get("step_wait"):
        raise TaskError("Попередні етапи вже завершено: беріть у роботу як звичайно.")
    text, record = _s(text), {}
    found = templates.templates(purpose=templates.PURPOSE_EARLY)
    if found or _s(template_id):
        if not _s(template_id):
            raise TaskError("Почати раніше можна лише з поясненням за шаблоном: оберіть «%s» і "
                            "заповніть поля." % " / ".join(x["name"] for x in found))
        try:
            got = templates.fill(template_id, answers, templates.PURPOSE_EARLY)
        except templates.TemplateError as e:
            raise TaskError(str(e))
        text, record = got["text"], got["record"]
    if not text:
        raise TaskError("Без пояснення раніше не почати: напишіть, чому етап починаєте до "
                        "завершення попереднього.")
    # ⛒ Без назв: запис їде з карткою етапу тому, кому сусідні етапи можуть бути не видні.
    waited = [{"id": r["id"], "n": r["n"], "assignee_id": r["assignee_id"],
               "stage": r["stage"]} for r in t["step_wait"]]
    raw = _strip_derived(t)
    raw["early"] = list(raw.get("early") or []) + [{
        "at": clock.now(), "by": _s(actor_id), "text": text[:1000], "tpl": record,
        "waited": waited}]
    raw["stage"] = STAGE_WORK
    _feed_event(raw, actor_id, "Етап почато раніше попереднього (чекав: %s). Пояснення: %s."
                % ("; ".join(step_words(r) for r in t["step_wait"]),
                   text.replace("\n", "; ").rstrip(".")), kind="early")
    extra = {"tpl": _tpl_event(record)} if record else {}
    out = save(raw, actor_id, events.event(
        events.KIND_EARLY, text=text[:300], n=t["step_of"].get("n"),
        parent_id=t["step_of"].get("id"), waited=[w["n"] for w in waited],
        **_who_where(t), **extra))
    return task(tid) if _steps_follow(out, actor_id) else out


def _who_where(t: dict) -> dict:
    """Виконавець і проєкт задачі — для подій, які дзеркало рахує на людину й проєкт."""
    return {"assignee_id": _s(t.get("assignee_id")), "project_id": _s(t.get("project_id"))}


def delegate(tid: str, actor_id: str, new_assignee_id: str,
             is_admin: bool = False) -> dict:
    """⭐ Рішення 10: делегування — ТА САМА задача, змінюється виконавець.
    Один номер, одна стрічка, одна правда. Той, хто делегував, лишається в
    задачі (стає співвиконавцем), щоб не зникнути з картини перед постановником."""
    t = task(tid)
    require(t, actor_id, ACT_REASSIGN, is_admin)
    role = role_of(t, actor_id)
    new_id = _s(new_assignee_id)
    if not new_id or new_id == t["assignee_id"]:
        raise TaskError("Оберіть іншого виконавця.")
    _require_worker(new_id, "виконавець")
    # ⭐ Делегування — це та сама постановка, лише всередині живої задачі
    # (рішення 10: ТА САМА задача, змінюється виконавець). Отже ті самі ворота.
    _require_may_set(actor_id, new_id)
    # ⛒ SoD і тут: не можна віддати роботу тому, хто цю ж роботу перевіряє.
    # Двері не зникають — постановник чи адміністратор спершу міняє
    # перевіряючого, і делегування проходить.
    _require_sod(t["verifier_id"], new_id, t["coassignee_ids"])
    raw = _strip_derived(t)
    old = raw["assignee_id"]
    raw["assignee_id"] = new_id
    if old and old != new_id and role == ROLE_ASSIGNEE and old not in raw["coassignee_ids"]:
        raw["coassignee_ids"].append(old)
    raw["watcher_ids"] = [w for w in raw["watcher_ids"] if w != new_id]
    raw["coassignee_ids"] = [c for c in raw["coassignee_ids"] if c != new_id]
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": "Виконавець: %s" % people.employee(new_id).get("full_name", new_id),
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_DELEGATED,
                                            old_assignee_id=old,
                                            new_assignee_id=new_id))


def refuse(tid: str, actor_id: str, reason: str,
           is_admin: bool = False) -> dict:
    """⭐ Рішення 11-12: прямий підлеглий НЕ МАЄ права відмовитись від задачі
    свого керівника — для нього легальний вихід це КЛАПАН (коментар керівнику,
    чого бракує). Відмова лишається тільки для «чужих» задач і завжди з причиною."""
    t = task(tid)
    require(t, actor_id, ACT_REFUSE, is_admin)
    reason = _s(reason)
    if not reason:
        raise TaskError("Відмова без причини не приймається.")
    if people.is_manager_of(t["author_id"], actor_id):
        raise TaskError(
            "Це задача вашого керівника — від неї не відмовляються. "
            "Напишіть у стрічці, чого вам бракує: керівник змінить термін, "
            "додасть ресурс або передасть задачу іншому.")
    raw = _strip_derived(t)
    raw["refusal_reason"] = reason
    raw["stage"] = STAGE_HOLD
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": "Відмова від задачі. Причина: %s" % reason,
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_REFUSED,
                                            reason=reason[:300]))


# ---------------------------------------------------------------------------
# ⭐⭐⭐ 706 (проєкт розробки ОТУ, 3.4): «НЕ ПРОЙШЛА ПЕРЕВІРКУ».
#
# Провал — ЗАПИС у задачі (`failures`): хто не прийняв, коли, з якою причиною, ЯКИЙ
# результат відхилено і — згодом — пояснення виконавця. Лічильник на картці — довжина
# цього переліку; червоні рядки стрічки — його слід для ока. Дзеркало рахує подію.
# ---------------------------------------------------------------------------
def _require_explained(t: dict) -> None:
    """Здати новий результат у задачі, що не пройшла перевірку, можна лише після
    пояснення: інакше пояснення перетворилось би на необовʼязкове."""
    if t.get("stage") == STAGE_FAILED:
        raise TaskError("Задача не пройшла перевірку. Спершу поясніть чому — "
                        "«Пояснити й повернути в роботу», — тоді здавайте результат.")


def _feed_fail(raw: dict, actor_id: str, text: str) -> None:
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": text, "at": clock.now(), "kind": "fail"})


def reject(tid: str, actor_id: str, reason: str, is_admin: bool = False) -> dict:
    """«НЕ ПРИЙНЯТИ» — з причиною, обовʼязково. Задача йде в «Не пройшла перевірку».

    ⭐ РЕЗУЛЬТАТ ЗНІМАЄТЬСЯ, а його номер лягає в запис провалу. Інакше відхилений
    результат лишився б «результатом», і постановник міг би за хвилину прийняти рівно
    те, що щойно не прийняли. Перевірка й звірка, привʼязані до номера результату,
    перестають діяти самі — без жодного коду зняття."""
    t = task(tid)
    require(t, actor_id, ACT_REJECT, is_admin)
    reason = _s(reason)
    if not reason:
        raise TaskError("Не прийняти без причини не можна: напишіть, чого бракує "
                        "або що не так.")
    if not t["rejectable"]:
        raise TaskError("Не приймати поки нема чого: роботу ще не здали — немає ні "
                        "результату, ні стадії «На перевірці».")
    raw = _strip_derived(t)
    n = len(raw.get("failures") or []) + 1
    raw.setdefault("failures", []).append({
        "id": "f%d" % n, "at": clock.now(), "by": _s(actor_id), "reason": reason[:1000],
        "result_id": _s(t["result_comment_id"]), "explanation": "",
        "explained_at": "", "explained_by": ""})
    raw["result_comment_id"] = ""
    raw["stage"] = STAGE_FAILED
    _feed_fail(raw, actor_id, "Не пройшла перевірку (%d-й раз). Причина: %s" % (n, reason))
    return save(raw, actor_id, events.event(events.KIND_FAILED, reason=reason[:300], n=n,
                                            **_who_where(t)))


def explain(tid: str, actor_id: str, text: str = "", is_admin: bool = False,
            template_id: str = "", answers=None) -> dict:
    """«ПОЯСНИТИ Й ПОВЕРНУТИ В РОБОТУ» — пояснення виконавця до провалу.

    Пояснення лягає в ТОЙ САМИЙ запис провалу (причина і відповідь на неї — поруч,
    як їх читатиме керівник на планерці) і червоним рядком у стрічку.
    ⭐⭐ 707 (3.7): ЛИШЕ ЗА ШАБЛОНОМ пояснення провалу — причину вибирають зі списку,
    тож її можна порахувати. Вільний текст лишається тільки тоді, коли довідник не
    читається з диска: застрягла задача гірша за непорахований провал."""
    t = task(tid)
    require(t, actor_id, ACT_EXPLAIN, is_admin)
    text = _s(text)
    if t["stage"] != STAGE_FAILED:
        raise TaskError("Пояснювати нема чого: задача зараз не в «Не пройшла перевірку».")
    record = {}
    fails = templates.templates(purpose=templates.PURPOSE_FAIL)
    if fails or _s(template_id):
        if not _s(template_id):
            raise TaskError("Пояснення пишеться за шаблоном: оберіть «%s» і заповніть поля."
                            % " / ".join(x["name"] for x in fails))
        try:
            got = templates.fill(template_id, answers, templates.PURPOSE_FAIL)
        except templates.TemplateError as e:
            raise TaskError(str(e))
        text, record = got["text"], got["record"]
    if not text:
        raise TaskError("Без пояснення в роботу не повернути: напишіть, чому задача "
                        "не пройшла перевірку і що робите далі.")
    raw = _strip_derived(t)
    fl = raw.get("failures") or []
    if fl:
        fl[-1].update({"explanation": text[:1000], "explained_at": clock.now(),
                       "explained_by": _s(actor_id), "tpl": record})
    raw["stage"] = STAGE_WORK
    _feed_fail(raw, actor_id, "Пояснення виконавця: %s. Задача знову в роботі."
               % text.replace("\n", "; ").rstrip("."))
    extra = {"tpl": _tpl_event(record)} if record else {}
    return save(raw, actor_id, events.event(events.KIND_EXPLAINED, text=text[:300],
                                            n=len(fl), **_who_where(t), **extra))


# ---------------------------------------------------------------------------
# ⭐⭐⭐ 706 (3.6): «Я ЗРОЗУМІВ ЗАДАЧУ». Нічого не забороняє — робити задачу можна й
# без підтвердження. Воно робить ВИДИМИМ, на кому мовчання: «не підтверджено
# виконавцем» — на ньому; «чекає уточнення» — на постановнику; доба без жодного
# слова — «незрозуміла задача», і це питання до того, хто ставив.
# ---------------------------------------------------------------------------
def _require_ack_open(t: dict) -> None:
    if t["ack_state"] == ACK_UNDERSTOOD:
        raise TaskError("Ви вже підтвердили, що задачу зрозуміло.")
    if not t["ack_state"]:
        raise TaskError("Ця задача підтвердження не чекає.")


def acknowledge(tid: str, actor_id: str, is_admin: bool = False) -> dict:
    """«Зрозумів задачу». `first` у події — чи без жодного уточнення: це рахує
    дзеркало на ПОСТАНОВНИКА (хто ставить задачі зрозуміло)."""
    t = task(tid)
    require(t, actor_id, ACT_ACK, is_admin)
    _require_ack_open(t)
    raw = _strip_derived(t)
    a = dict(raw["ack"])
    a.update({"state": ACK_UNDERSTOOD, "at": clock.now()})
    raw["ack"] = a
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": "Виконавець підтвердив: задачу зрозуміло.",
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_UNDERSTOOD,
                                            first=not a.get("asked"),
                                            author_id=t["author_id"]))


def clarify(tid: str, actor_id: str, question: str, is_admin: bool = False) -> dict:
    """«Потрібне уточнення» — питання постановнику: коментарем у стрічці (там, де
    розмова про задачу) і сповіщенням йому. Задача чекає відповіді, а не мовчить."""
    t = task(tid)
    require(t, actor_id, ACT_ACK, is_admin)
    _require_ack_open(t)
    question = _s(question)
    if not question:
        raise TaskError("Напишіть, що саме незрозуміло: питання піде постановнику.")
    raw = _strip_derived(t)
    cid = "m%d" % (len(raw["feed"]) + 1)
    raw["feed"].append({"id": cid, "author_id": _s(actor_id),
                        "text": "Потрібне уточнення: %s" % question,
                        "at": clock.now(), "kind": "comment"})
    a = dict(raw["ack"])
    a.update({"state": ACK_CLARIFY, "question_id": cid, "asked": int(a.get("asked") or 0) + 1})
    raw["ack"] = a
    return save(raw, actor_id, events.event(events.KIND_CLARIFY, comment_id=cid,
                                            text=question[:300], author_id=t["author_id"]))


def mark_unclear(t: dict, now: str = "") -> bool:
    """Сторож (`taskdesk_overdue`): «незрозуміла задача» — РІВНО РАЗ на виконавця.
    «Раз» тримається не на памʼяті процесу, а на позначці `unclear_at` у файлі."""
    if not t.get("unclear") or (t.get("ack") or {}).get("unclear_at"):
        return False
    now = now or clock.now()
    raw = _strip_derived(t)
    a = dict(raw["ack"])
    a["unclear_at"] = now
    raw["ack"] = a
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": "",
                        "text": "Незрозуміла задача: виконавець не підтвердив її за добу. "
                                "Питання — до постановника.",
                        "at": now, "kind": "event"})
    save(raw, "", events.event(events.KIND_UNCLEAR, author_id=t.get("author_id", ""),
                               hours=ACK_UNCLEAR_HOURS))
    return True


def update(tid: str, actor_id: str, is_admin: bool = False, **fields) -> dict:
    """Текст, терміни й склад задачі правлять постановник і адміністратор.
    Виконавець — ні: інакше умову роботи міняв би той, кого за неї питають.
    Хто саме має право — каже ОДНА таблиця вище, не ця функція."""
    t = task(tid)
    require(t, actor_id, ACT_EDIT, is_admin)
    raw = _strip_derived(t)
    if "title" in fields:
        title = _s(fields["title"])
        if not title:
            raise TaskError("Назву не можна прибрати.")
        raw["title"] = title
    if "description" in fields:
        raw["description"] = _s(fields["description"])
    if "acceptance" in fields:
        raw["acceptance"] = _s(fields["acceptance"])
    if "priority" in fields:                                        # ⭐ 734
        raw["priority"] = _require_priority(fields["priority"])
    # ⛒ ПРОЄКТ МІНЯЄ ТОЙ САМИЙ, ХТО ПРАВИТЬ ЗАДАЧУ. Окремої дії не заводимо:
    # два сторожі на одне правило — це нуль сторожів.
    if "project_id" in fields:
        raw["project_id"] = _require_project(actor_id, fields["project_id"], is_admin,
                                             keep=raw.get("project_id", ""))
    if "due_at" in fields:
        raw["due_at"] = _norm_due(fields["due_at"])
        _check_checklist_due(raw["due_at"], raw["checklist"])
    if "coassignee_ids" in fields:
        co = [x for x in _ids(fields["coassignee_ids"]) if x != raw["assignee_id"]]
        for x in co:
            _require_worker(x, "співвиконавець")
        raw["coassignee_ids"] = co
    if "watcher_ids" in fields:
        raw["watcher_ids"] = [x for x in _ids(fields["watcher_ids"])
                              if x != raw["assignee_id"] and x not in raw["coassignee_ids"]]
    # ⭐ ПЕРЕВІРЯЮЧОГО ПРИЗНАЧАЄ Й ЗНІМАЄ ТОЙ, ХТО ВІДПОВІДАЄ ЗА ЗАДАЧУ
    # (постановник; адміністратор — як і скрізь, поверх). Порожнє значення
    # прибирає ланку, і задача повертається до простого приймання.
    # ⛒ ЗМІНА ТИПУ — це СВІДОМА дія постановника, і саме тому вона бере
    # знімок заново. Заморожування захищає задачу від правок ДОВІДНИКА, а не
    # від того, хто за неї відповідає. Позначені пункти при цьому чесно
    # втрачаються: це вже інший стандарт, і старі позначки нічого про нього
    # не свідчать.
    if "worktype_id" in fields:
        new_type = _require_worktype(fields["worktype_id"])
        if new_type != raw["worktype_id"]:
            raw["worktype_id"] = new_type
            raw["dod"] = worktypes.snapshot(new_type)
    if "verifier_id" in fields:
        raw["verifier_id"] = _s(fields["verifier_id"])
        if raw["verifier_id"]:
            _require_worker(raw["verifier_id"], "перевіряючий")
    # ⛒ Правило одне на всі двері — і воно судить СКЛАД ПІСЛЯ правки, а не той,
    # що був: інакше нового співвиконавця можна було б тихо підсунути того, хто
    # вже стоїть перевіряючим.
    _require_sod(raw["verifier_id"], raw["assignee_id"], raw["coassignee_ids"])

    # ⭐⭐ ЗМІНА, ЯКОЇ НЕ ВИДНО ТОМУ, КОГО ВОНА СТОСУЄТЬСЯ, — ТИХА ЗМІНА.
    # Службовий журнал `audit` бачимо ми; ВИКОНАВЕЦЬ дивиться у СТРІЧКУ. Якщо
    # постановник посунув термін, а в стрічці порожньо — людина дізнається про
    # це, коли задача почервоніє. Тому кожна правка називає себе там, де на неї
    # дивляться. (Знайдено живим прогоном 08.08.2026, не чеками.)
    said = []
    if t["title"] != raw["title"]:
        said.append("назва: «%s»" % raw["title"])
    if t["due_at"] != raw["due_at"]:
        said.append("термін: %s" % (_human(raw["due_at"]) if raw["due_at"]
                                    else "прибрано, рахується з плану"))
    if t["description"] != raw["description"]:
        said.append("опис змінено")
    if t["acceptance"] != raw["acceptance"]:
        said.append("за чим приймемо: %s"
                    % (raw["acceptance"] or "не сказано"))
    if t["worktype_id"] != raw["worktype_id"]:
        wt = worktypes.work_type(raw["worktype_id"]) if raw["worktype_id"] else None
        said.append("тип роботи: %s" % ((wt or {}).get("name") or "прибрано"))
    if t["coassignee_ids"] != raw["coassignee_ids"]:
        said.append("співвиконавці: %s" % (_who(raw["coassignee_ids"]) or "нікого"))
    if t["verifier_id"] != raw["verifier_id"]:
        said.append("перевіряє результат: %s"
                    % (_who([raw["verifier_id"]]) or "ніхто, приймає постановник"))
    if t["watcher_ids"] != raw["watcher_ids"]:
        said.append("спостерігачі: %s" % (_who(raw["watcher_ids"]) or "нікого"))
    # ⭐⭐ СЛІД — ЦЕ УМОВА ЗАПИСУ, А НЕ ПРИКРАСА. Без цього рядка правка проєкту
    # лягала в `raw`, доходила до `if not said` — і функція виходила НЕ зберігши.
    # Хто додає нове поле в правку, той додає йому рядок сюди тим самим патчем.
    if t["project_id"] != raw["project_id"]:
        said.append("проєкт: %s" % (project_name(raw["project_id"]) or "прибрано"))
    if t["priority"] != raw["priority"]:                            # ⭐ 734
        said.append("пріоритет: %s" % PRIORITY_NAMES[raw["priority"]])
    if not said:
        return task(tid)                      # нічого не змінилось — і сліду не треба
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": "Задачу змінено. " + " · ".join(said),
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_UPDATED, said=list(said)))


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ЗВʼЯЗКИ ЗАДАЧ (зміна 172 → крок B2, 14.08.2026).
#
# ЩО ТУТ ЛИШИЛОСЬ ПІСЛЯ B2. Сам ФАКТ звʼязку більше не лежить у файлі задачі —
# він у реєстрі `links.py`, спільному для всіх шарів. Тут лишились рівно дві
# речі, і обидві — власність ЗАДАЧІ, а не звʼязку: **ПРАВО** (кому можна) і
# **СЛІД У СТРІЧЦІ** (щоб людина побачила це там, де вона живе).
#
# ПРАВО ТЕ САМЕ, ЩО НА ПРАВКУ ЗАДАЧІ (`ACT_EDIT`): звʼязок міняє УМОВУ роботи —
# що є частиною чого і хто на кого чекає. Виконавцю нових прав не додаємо: у
# нього для цього є стрічка й відмова з причиною. Нова таблиця прав не заводиться.
# ⛒ І РЕЄСТР ЇЇ НЕ ОБХОДИТЬ: він не питає прав і не є другим входом — права
# судить власник сутності ДО виклику, як тут.
#
# ⚠ ПОРЯДОК НАВМИСНИЙ: спершу РЕЄСТР (правда), потім стрічка задачі (розповідь
# про правду). Якщо впаде другий крок, у людини лишиться справжній звʼязок без
# рядка в стрічці — це видно й лікується. Зворотний порядок дав би рядок про
# звʼязок, якого немає, тобто тиху брехню в очі.
# ---------------------------------------------------------------------------
def link(tid: str, actor_id: str, ref, rel: str, is_admin: bool = False) -> dict:
    """Звʼязати задачу з іншою задачею, контрагентом або прогоном."""
    t = task(tid)
    require(t, actor_id, ACT_EDIT, is_admin)
    me = entity.ref(entity.KIND_TASK, t["id"])
    try:
        row = links.add(me, rel, ref, by=entity.person_of_employee(_s(actor_id)))
    except links.LinkError as ex:
        raise TaskError(str(ex))
    value, r = row["to"], row["rel"]
    raw = _strip_derived(t)
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1),
                        "author_id": _s(actor_id),
                        "text": "Звʼязок — %s" % tlinks.phrase(r, value),
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_LINKED, ref=value, rel=r))


def unlink(tid: str, actor_id: str, ref, rel: str, is_admin: bool = False) -> dict:
    """Прибрати звʼязок. ⚠ Прибирається РІВНО той, який назвали: пара «на що» +
    «який». Видалення, яке вгадує форму, — окремий клас біди (урок 10.08)."""
    t = task(tid)
    require(t, actor_id, ACT_EDIT, is_admin)
    me = entity.ref(entity.KIND_TASK, t["id"])
    try:
        row = links.remove(me, rel, ref, by=entity.person_of_employee(_s(actor_id)))
    except links.LinkError as ex:
        raise TaskError(str(ex))
    value, r = row["to"], row["rel"]
    raw = _strip_derived(t)
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1),
                        "author_id": _s(actor_id),
                        "text": "Звʼязок прибрано — %s" % tlinks.phrase(r, value),
                        "at": clock.now(), "kind": "event"})
    return save(raw, actor_id, events.event(events.KIND_UNLINKED, ref=value, rel=r))


# ---------------------------------------------------------------------------
# ⭐⭐⭐ ПРОПОЗИЦІЇ МОЗКУ. Мозок сюди НЕ ХОДИТЬ — він живе в `taskdesk_ai.py` і
# лише ПРИНОСИТЬ готову пропозицію. Цей файл її записує, показує й застосовує.
# Термін від того не отримує другого писаря: коли людина тисне «Прийняти»,
# зміну робить ТА САМА `update()` під ТИМИ САМИМИ правами, і в журналі стоїть
# ЛЮДИНА, а не машина.
# ---------------------------------------------------------------------------
def add_proposal(tid: str, kind: str, date: str, why: str, quote: str,
                 from_comment: str = "", text: str = "") -> dict:
    """Записати пораду мозку. Нічого в задачі не змінює.

    ⭐ ДВА ВИДИ, ОДИН МЕХАНІЗМ: термін і критерій приймання. Порожня
    пропозиція не приймається в ЖОДНОМУ виді — порада без змісту лише
    привчає людину тиснути «Відхилити» не читаючи."""
    kind = _s(kind)
    if kind not in PROPOSAL_KINDS:
        raise TaskError("Невідомий вид пропозиції «%s»." % kind)
    date = _norm_due(date) if kind == PROPOSAL_DUE else ""
    text = _s(text)[:600] if kind == PROPOSAL_ACCEPT else ""
    if kind == PROPOSAL_DUE and not date:
        raise TaskError("Пропозиція терміну без дати не приймається.")
    if kind == PROPOSAL_ACCEPT and not text:
        raise TaskError("Пропозиція критерію без тексту не приймається.")
    t = task(tid)
    raw = _strip_derived(t)
    raw.setdefault("proposals", [])
    # Та сама дата, яку вже пропонували або вже відхилили, вдруге не спливає.
    for p in raw["proposals"]:
        if p.get("kind") != kind:
            continue
        same = (_norm_due(p.get("date")) == date if kind == PROPOSAL_DUE
                else _s(p.get("text")) == text)
        if same:
            return t
    pid = "p%d" % (len(raw["proposals"]) + 1)
    raw["proposals"].append({
        "id": pid, "kind": kind, "date": date, "text": text,
        "why": _s(why)[:300],
        "quote": _s(quote)[:300], "from_comment": _s(from_comment),
        "at": clock.now(), "state": PROPOSAL_OPEN, "decided_by": "",
    })
    line = ("Пропозиція: посунути термін на %s. %s" % (_human(date), _s(why))
            if kind == PROPOSAL_DUE
            else "Пропозиція: за чим приймемо результат — «%s». %s"
                 % (text, _s(why)))
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": AI_ACTOR,
                        "text": line,
                        "at": clock.now(), "kind": "event"})
    return save(raw, AI_ACTOR, events.event(events.KIND_PROPOSAL,
                                            proposal_id=pid, date=date,
                                            text=text, kind_of=kind,
                                            why=_s(why)[:300]))


def resolve_proposal(tid: str, actor_id: str, proposal_id: str, accept: bool,
                     is_admin: bool = False) -> dict:
    """Прийняти або відхилити пораду. Прийняти може ТІЛЬКИ той, хто й так має
    право правити задачу — інакше мозок став би обхідним шляхом повз права."""
    t = task(tid)
    require(t, actor_id, ACT_EDIT, is_admin)
    pid = _s(proposal_id)
    found = [p for p in t.get("proposals", []) if p["id"] == pid]
    if not found:
        raise TaskError("Такої пропозиції в задачі немає.")
    p = found[0]
    if p["state"] != PROPOSAL_OPEN:
        raise TaskError("Цю пропозицію вже %s."
                        % ("прийнято" if p["state"] == PROPOSAL_ACCEPTED else "відхилено"))
    raw = _strip_derived(t)
    for q in raw["proposals"]:
        if q["id"] == pid:
            q["state"] = PROPOSAL_ACCEPTED if accept else PROPOSAL_DECLINED
            q["decided_by"] = _s(actor_id)
    if accept:
        done_line = ("Пропозицію прийнято: термін %s." % _human(p["date"])
                     if p["kind"] == PROPOSAL_DUE
                     else "Пропозицію прийнято: приймаємо за «%s»." % p.get("text", ""))
    else:
        done_line = ("Пропозицію відхилено (термін лишається)."
                     if p["kind"] == PROPOSAL_DUE
                     else "Пропозицію відхилено (критерій лишається як був).")
    raw["feed"].append({"id": "m%d" % (len(raw["feed"]) + 1), "author_id": _s(actor_id),
                        "text": done_line,
                        "at": clock.now(), "kind": "event"})
    save(raw, actor_id, events.event(events.KIND_PROPOSAL_DONE, proposal_id=pid,
                                     accepted=bool(accept), date=p["date"]))
    if not accept:
        return task(tid)
    # ⭐ Саму зміну робить ТА САМА update() — щоб термін не отримав другого писаря
    # і щоб спрацювали всі її ворота (пункти плану, слід у стрічці).
    if p["kind"] == PROPOSAL_ACCEPT:
        return update(tid, actor_id, is_admin, acceptance=p.get("text", ""))
    return update(tid, actor_id, is_admin, due_at=p["date"])


def check_item(tid: str, actor_id: str, item_id: str, done: bool,
               is_admin: bool = False) -> dict:
    t = task(tid)
    require(t, actor_id, ACT_CHECK, is_admin)
    raw = _strip_derived(t)
    found = False
    for c in raw["checklist"]:
        if c["id"] == _s(item_id):
            c["done"], found = bool(done), True
    if not found:
        raise TaskError("Такого пункту в задачі немає.")
    return save(raw, actor_id, events.event(events.KIND_CHECKLIST,
                                            item_id=_s(item_id), done=bool(done)))


def check_dod(tid: str, actor_id: str, point_id: str, done: bool,
              is_admin: bool = False) -> dict:
    """Позначити пункт стандарту готовності.

    🩸 Рішення Андрія 26.08.2026: непозначені пункти ПОКАЗУЮТЬСЯ, але нічого не
    зупиняють. Тому тут немає жодних воріт на стадію: людина здає роботу тоді,
    коли вважає за потрібне, а незакриті пункти просто ВИДНО — і їй, і тому, хто
    приймає. Ми дивимось, а не перегороджуємо."""
    t = task(tid)
    require(t, actor_id, ACT_DOD, is_admin)
    raw = _strip_derived(t)
    found = False
    for p in raw["dod"]:
        if p["id"] == _s(point_id):
            p["done"], found = bool(done), True
    if not found:
        raise TaskError("Такого пункту стандарту в задачі немає.")
    return save(raw, actor_id, events.event(events.KIND_DOD,
                                            point_id=_s(point_id),
                                            done=bool(done)))


# ---------------------------------------------------------------------------
# ДОШКА — те, що бачить екран. Фільтр лише ЗВУЖУЄ видимість.
# ---------------------------------------------------------------------------
def _layout_columns(by_stage: list, layout: list) -> list:
    """⭐ 709: дошка ПРОЄКТУ — колонки власника (`layout`) у його порядку. Кожна основна
    стадія розкладається по своїх колонках за `column_id` задачі; «Не пройшла перевірку»
    стоїть між перевіркою і завершенням, побічні — як досі, лише непорожні."""
    out = []
    for c in by_stage:
        st = c["stage"]
        own = [x for x in layout if x["stage"] == st]
        if not own:
            out.append(dict(c, id=st))
            continue
        ids = {x["id"] for x in own}
        for x in own:
            out.append({"id": x["id"], "stage": st, "name": x["name"],
                        "tasks": [t for t in c["tasks"]
                                  if (t.get("column_id") if t.get("column_id") in ids else st)
                                  == x["id"]]})
    return out


def board(emp_id: str, scope: str = "all", show_closed: bool = False,
          narrow=None, show_archive: bool = False, layout=None) -> dict:
    """scope: all | mine (я виконавець) | i_set (я поставив) | overdue

    ⭐⭐⭐ `narrow` — це фільтр екрана. Він отримує вже ВИДИМІ задачі й може лише
    ЗМЕНШИТИ їх число. Це не домовленість, а ворота: якщо після нього зʼявився
    хоч один номер, якого не було, робота зупиняється з причиною. Інакше екран
    з фільтром став би другим входом повз `visible_ids()`."""
    # ⛒ Переїзд закритих задач в архів запускається саме тут — там, де людина
    # відкриває екран, і не частіше ніж раз на добу (зміна 279).
    archive_sweep()
    tasks = visible_tasks(emp_id, include_closed=True,
                          include_archive=show_archive)
    seen = {t["id"] for t in tasks}
    for t in tasks:
        mask_steps(t, seen)          # ⛒ 708: назви невидимих етапів і головної — ні
    if narrow is not None:
        allowed = {t["id"] for t in tasks}
        tasks = list(narrow(tasks))
        extra = sorted({t["id"] for t in tasks} - allowed)
        if extra:
            raise TaskError("Фільтр не має права додавати задачі, лише звужувати. "
                            "Зайві: %s" % ", ".join(extra[:5]))
    if scope == "mine":
        tasks = [t for t in tasks if t["assignee_id"] == emp_id]
    elif scope == "i_set":
        tasks = [t for t in tasks if t["author_id"] == emp_id]
    elif scope == "overdue":
        tasks = [t for t in tasks if t["overdue"]]
    if not show_closed:
        # ⛒ ЗМІНА 280. Архівну задачу тут пропускає її ВЛАСНА ознака, а не
        # тихо ввімкнена чужа галочка: «шукати й в архіві» не має права
        # показувати живі закриті задачі, про які вона нічого не обіцяла.
        tasks = [t for t in tasks
                 if t["stage"] not in STAGES_CLOSED or scope == "overdue"
                 or t.get("archived")]
    cols = []
    # ⭐ 706: колонка «Не пройшла перевірку» стоїть завжди, як і основна лінія:
    # порожня вона каже керівникові добру новину, а не зникає.
    for st in STAGES_ALL:
        in_st = [t for t in tasks if t["stage"] == st]
        if st in STAGES_SIDE and not in_st:
            continue
        cols.append({"stage": st, "name": STAGE_NAMES[st], "tasks": in_st})
    if layout:
        cols = _layout_columns(cols, layout)
    for c in cols:
        c.setdefault("id", c["stage"])
    return {
        "columns": cols,
        "total": len(tasks),
        "overdue": len([t for t in tasks if t["overdue"]]),
        "broken": [t["id"] for t in tasks if t["broken"]],
    }
