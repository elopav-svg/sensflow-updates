# -*- coding: utf-8 -*-
"""deal_stages.py — ⭐⭐⭐ СТАДІЇ УГОД — ДАНІ КЛІЄНТА, ПРАВИЛА — ЗА ЗНАЧЕННЯМ СТАДІЇ (зміна 738, 10.10.2026).

🩸 ЩО БУЛО. Воронка була переліком НАЗВ у коді (`deals.STAGES`), а правила — словниками за назвою:
імовірність прогнозу, вимога суми й паперу, «з якої стадії» форми оплати, «не в роботі», борг, облік
абонплати, виручка місяця. У кожного клієнта своя воронка (Каспер: «Відвантажено/Оплачено» замість
«Активних клієнтів», без «Пілотного випробування»), а перейменувати стадію означало б зламати правила,
що трималися за її назву.

⛒ РІШЕННЯ (модель погоджено словом Андрія 09.10.2026):
  * стадії — ДАНІ клієнта: постійний внутрішній номер (`id`), назва — лише підпис; змінює їх ЛИШЕ
    адміністратор; один суддя перед записом (`check`); видалити — лише стадію без угод; попередня версія
    лишається (відкат `restore`);
  * правило судить ЗНАЧЕННЯ стадії (`kind`): звичайна, укладення угоди, чекаємо оплати, виграна,
    програна, архів «Успіх», архів «Провал». Немає стадії з потрібним значенням — правило не діє;
  * архів ділиться на «Успіх» і «Провал» — закриті угоди, зазвичай сховані; обидві обовʼязкові
    (угоді завжди є куди піти);
  * перехід: нинішні стадії — стартова модель кожного клієнта; угоди переводяться на номери стадій
    при першому читанні, з копією реєстру до переведення (`deals.before_stages_738.json`).
Модуль чистий: працює з даними, які йому дав `deals` (писар реєстру один — `deals`).
"""
import copy
import re

KINDS = ("open", "contract", "await_pay", "won", "lost", "archive_won", "archive_lost")
KIND_NAMES = {
    "open": "звичайна",
    "contract": "укладення угоди (потрібні сума й папір)",
    "await_pay": "чекаємо оплати (потрібен папір)",
    "won": "виграна — угода закрита, клієнт платить",
    "lost": "програна — клієнт не в роботі",
    "archive_won": "архів: успіх",
    "archive_lost": "архів: провал",
}
# Хто вже не в роботі: «Сума угод у роботі», борг, прогноз їх не рахують.
NOT_IN_WORK = ("lost", "archive_won", "archive_lost")
ARCHIVE = ("archive_won", "archive_lost")
# Значення, що вимагають паперу закриття, — у порядку руху угоди (форма оплати каже, з якого).
PAPER_KINDS = ("contract", "await_pay", "won")
REQUIRES = {"contract": ("amount", "paper"), "await_pay": ("paper",), "won": ("paper",)}
# Обовʼязкові значення: угоді завжди є куди піти в архів.
MANDATORY = ("archive_won", "archive_lost")

MAX_STAGES = 30
MAX_NAME = 40
HISTORY_KEEP = 20

# Стартова модель — нинішня воронка (до 738) з проставленими значеннями. Імовірності — ті самі, що
# були (`STAGE_PROB` до 738; стадії без імовірності мали 0). «Архів» ділиться на «Успіх» і «Провал».
LEGACY_ARCHIVE = "Архів"
DEFAULT = [
    ("s1", "Новий клієнт", "open", 0.10),
    ("s2", "Збір даних", "open", 0.0),
    ("s3", "Кваліфікація", "open", 0.0),
    ("s4", "Перемовини", "open", 0.30),
    ("s5", "Пілотне випробування", "open", 0.50),
    ("s6", "Укладення угоди", "contract", 0.70),
    ("s7", "Чекаємо оплати", "await_pay", 0.90),
    ("s8", "Активні клієнти", "won", 1.0),
    ("s9", "Неактивні клієнти", "lost", 0.0),
    ("s10", "Успіх", "archive_won", 0.0),
    ("s11", "Провал", "archive_lost", 0.0),
]


class StageError(Exception):
    """Відмова з причиною словами."""


def _s(v) -> str:
    return ("" if v is None else str(v)).strip()


def default_stages() -> list:
    return [{"id": i, "name": n, "kind": k, "prob": p} for i, n, k, p in DEFAULT]


# ── ЧИТАННЯ ВОРОНКИ ──────────────────────────────────────────────────────────
def stages_of(d: dict) -> list:
    """Стадії реєстру (у порядку воронки). Реєстр без воронки — стартова модель."""
    pl = ((d or {}).get("settings") or {}).get("pipeline") or {}
    st = pl.get("stages")
    return copy.deepcopy(st) if isinstance(st, list) and st else default_stages()


def by_id(stages: list) -> dict:
    return {s["id"]: s for s in stages}


def ids_of_kind(stages: list, *kinds) -> list:
    return [s["id"] for s in stages if s.get("kind") in kinds]


def first_of_kind(stages: list, kind: str) -> str:
    ids = ids_of_kind(stages, kind)
    return ids[0] if ids else ""


def default_id(stages: list) -> str:
    """Стадія нової угоди — перша в порядку воронки серед відкритих (звичайна)."""
    for s in stages:
        if s.get("kind") == "open":
            return s["id"]
    return stages[0]["id"]


def resolve(stages: list, value) -> str:
    """Номер стадії за номером або назвою (без регістру); "" — немає такої."""
    v = _s(value)
    if not v:
        return ""
    for s in stages:
        if s["id"] == v:
            return v
    low = v.lower()
    for s in stages:
        if s["name"].lower() == low:
            return s["id"]
    return ""


def name_of(stages: list, sid: str) -> str:
    s = by_id(stages).get(_s(sid))
    return s["name"] if s else ""


def kind_of(stages: list, sid: str) -> str:
    s = by_id(stages).get(_s(sid))
    return s["kind"] if s else ""


def prob_of(stages: list, sid: str) -> float:
    s = by_id(stages).get(_s(sid))
    try:
        return float(s.get("prob") or 0) if s else 0.0
    except (TypeError, ValueError):
        return 0.0


# ── СУДДЯ ПРАВКИ ─────────────────────────────────────────────────────────────
def check(new_stages, old_stages: list, used: dict, known=()) -> list:
    """Нова воронка — або відмова словами. `used` — {номер стадії: скільки угод}; `known` — номери зі
    старих версій воронки (відкат повертає видалену стадію під її ж номером).

    Новий рядок без номера дістає новий постійний номер; номер старої стадії не міняється ніколи і
    не видається вдруге (дати заходу угод тримаються за номер)."""
    if not isinstance(new_stages, list) or not new_stages:
        raise StageError("Воронка порожня: потрібна хоча б одна стадія.")
    if len(new_stages) > MAX_STAGES:
        raise StageError("Забагато стадій: %d, межа %d." % (len(new_stages), MAX_STAGES))
    old = by_id(old_stages)
    known = set(known) | set(old)
    nums = [int(m.group(1)) for m in (re.match(r"^s(\d+)$", i) for i in known) if m]
    nxt = max(nums + [len(DEFAULT)]) + 1
    out, names, ids = [], set(), set()
    for i, raw in enumerate(new_stages, 1):
        if not isinstance(raw, dict):
            raise StageError("Рядок %d воронки не читається." % i)
        name = _s(raw.get("name"))
        if not name:
            raise StageError("Стадія %d без назви: впишіть назву." % i)
        if len(name) > MAX_NAME:
            raise StageError("Назва «%s…» задовга: межа %d знаків." % (name[:20], MAX_NAME))
        if name.lower() in names:
            raise StageError("Дві стадії з назвою «%s»: назви мусять різнитися." % name)
        names.add(name.lower())
        kind = _s(raw.get("kind"))
        if kind not in KINDS:
            raise StageError("Стадія «%s»: невідоме значення «%s». Платформа знає: %s."
                             % (name, kind, ", ".join(KIND_NAMES[k] for k in KINDS)))
        try:
            prob = float(raw.get("prob") if raw.get("prob") not in (None, "") else 0)
        except (TypeError, ValueError):
            raise StageError("Стадія «%s»: імовірність не число." % name)
        if prob > 1:
            prob = prob / 100.0                   # людина вписала відсотки
        if not 0 <= prob <= 1:
            raise StageError("Стадія «%s»: імовірність має бути від 0 до 100 %%." % name)
        if kind in ("won",):
            prob = 1.0
        if kind in NOT_IN_WORK:
            prob = 0.0
        sid = _s(raw.get("id"))
        if sid:
            if sid not in known:
                raise StageError("Стадії з номером «%s» у воронці немає — оновіть сторінку." % sid)
            if sid in ids:
                raise StageError("Стадія «%s» у переліку двічі." % name)
        else:
            sid = "s%d" % nxt
            nxt += 1
        ids.add(sid)
        row = {"id": sid, "name": name, "kind": kind, "prob": round(prob, 4)}
        if old.get(sid, {}).get("legacy"):
            row["legacy"] = old[sid]["legacy"]
        out.append(row)
    for k in MANDATORY:
        if not any(s["kind"] == k for s in out):
            raise StageError("У воронці мусить бути стадія зі значенням «%s» — угоді завжди має бути "
                             "куди піти в архів." % KIND_NAMES[k])
    if not any(s["kind"] == "open" for s in out):
        raise StageError("Потрібна хоча б одна звичайна стадія — з неї починається нова угода.")
    gone = [old[i] for i in old if i not in ids]
    busy = [s for s in gone if used.get(s["id"])]
    if busy:
        raise StageError("Не можна видалити стадію з угодами: %s. Спершу переведіть угоди на іншу "
                         "стадію." % ", ".join("«%s» (%d)" % (s["name"], used[s["id"]]) for s in busy))
    # Стадія з угодами не може стати архівною чи вийти з архіву мовчки: угоди змінили б «архівність».
    flips = [s for s in out if s["id"] in old and used.get(s["id"])
             and (s["kind"] in ARCHIVE) != (old[s["id"]]["kind"] in ARCHIVE)]
    if flips:
        raise StageError("Стадія з угодами не може перейти в архів чи з архіву: %s. Переведіть угоди "
                         "або оберіть інше значення." % ", ".join("«%s»" % s["name"] for s in flips))
    return out


# ── ПЕРЕХІД (один раз на реєстр) ─────────────────────────────────────────────
def ensure(d: dict, now: str, ever_won=lambda row: False) -> bool:
    """Реєстр без воронки — дістає стартову модель, угоди — номери стадій. True — реєстр змінено.

    `ever_won(row)` — чи заходила угода колись на «Активні клієнти» (для поділу старого «Архіву»)."""
    settings = d.setdefault("settings", {})
    if isinstance(settings.get("pipeline"), dict) and settings["pipeline"].get("stages"):
        return False
    stages = default_stages()
    for s in stages:
        s["legacy"] = s["name"]
    settings["pipeline"] = {"version": 1, "at": now, "by": "перехід 738", "stages": stages}
    settings.setdefault("pipeline_history", [])
    name2id = {s["name"]: s["id"] for s in stages}
    won_arch, lost_arch = first_of_kind(stages, "archive_won"), first_of_kind(stages, "archive_lost")
    for row in (d.get("deals") or {}).values():
        if not isinstance(row, dict) or _s(row.get("stage_id")):
            continue
        old = _s(row.get("stage"))
        if old == LEGACY_ARCHIVE or (row.get("archived") and old not in name2id):
            sid = won_arch if ever_won(row) else lost_arch
        else:
            sid = name2id.get(old) or default_id(stages)
        row["stage_id"] = sid
        row["stage"] = name_of(stages, sid)
        sa = row.get("stage_at") or {}
        if isinstance(sa, dict) and sa:
            row["stage_at"] = {(name2id.get(k) or (lost_arch if k == LEGACY_ARCHIVE else k)): v
                               for k, v in sa.items()}
    return True


def save(d: dict, new_stages: list, now: str, by: str) -> dict:
    """Записати нову воронку в реєстр (уже засуджену `check`): попередня — в історію; назви угод —
    за номерами."""
    settings = d.setdefault("settings", {})
    cur = settings.get("pipeline") or {"version": 0, "stages": default_stages()}
    hist = list(settings.get("pipeline_history") or [])
    hist.append(copy.deepcopy(cur))
    settings["pipeline_history"] = hist[-HISTORY_KEEP:]
    settings["pipeline"] = {"version": int(cur.get("version") or 0) + 1, "at": now, "by": by,
                            "stages": new_stages}
    for row in (d.get("deals") or {}).values():
        if isinstance(row, dict):
            row["stage"] = name_of(new_stages, row.get("stage_id")) or row.get("stage")
    return settings["pipeline"]
